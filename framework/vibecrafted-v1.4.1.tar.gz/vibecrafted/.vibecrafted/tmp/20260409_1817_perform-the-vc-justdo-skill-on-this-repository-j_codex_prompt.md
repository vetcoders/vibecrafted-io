Perform the vc-justdo skill on this repository.

justdo telemetry smoke
