Perform the vc-workflow skill on this repository.

workflow telemetry smoke
