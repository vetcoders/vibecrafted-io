Perform the vc-followup skill on this repository.

Check runtime
