Perform the vc-dou skill on this repository.

dou telemetry smoke
