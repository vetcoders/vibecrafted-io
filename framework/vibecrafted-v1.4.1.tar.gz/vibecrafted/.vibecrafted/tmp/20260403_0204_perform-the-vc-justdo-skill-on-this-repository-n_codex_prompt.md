Perform the vc-justdo skill on this repository.

Napraw po discover drogą dry-run findingsy z precommit i prepush hooks
