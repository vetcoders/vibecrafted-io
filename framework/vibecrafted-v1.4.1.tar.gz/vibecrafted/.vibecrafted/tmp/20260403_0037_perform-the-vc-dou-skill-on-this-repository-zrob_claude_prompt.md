Perform the vc-dou skill on this repository.

Zrobilimy testowo build ~/Libraxis/alacritty dla potrzeb frameworka. Zbudowalimy i zasignowalimy też Zellij. Planem jest dowiezienie uczciwej wersji 1.2.1 która działa. Pora na prunning i przejście przez runtime od a do z po kodzie. dzialaj w trybie _Wszystko gotowe? Ja wam pokażę, że nie :P_ Najpierw shipujemy do końca 1.2.1, a zellij i alacritty idą do nowego repo. Co znajdziesz - od razu poprawiaj. Nie  mnożymy długu tylko frajde ze stanu jaki mamy.
