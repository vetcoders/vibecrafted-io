Perform the vc-hydrate skill on this repository.
