Perform the vc-dou skill on this repository.

Zrobilimy testowo build ~/Libraxis/alacritty dla potrzeb frameworka. Zbudowalimy i zasignowalimy też Zellij. Wszystko działa! Pora na prunning i shipping repo. dzialaj w trybie _Wszystko gotowe? Ja wam pokażę, że nie :P_ Co znajdziesz - od razu poprawiaj. Nie  mnożymy długu tylko frajde ze stanu jaki mamy.
