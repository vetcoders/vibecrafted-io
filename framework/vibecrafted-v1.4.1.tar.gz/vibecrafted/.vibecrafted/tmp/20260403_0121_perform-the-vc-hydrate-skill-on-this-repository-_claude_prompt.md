Perform the vc-hydrate skill on this repository.

musimy uprz
vc-hydrate claude --prompt musimy
