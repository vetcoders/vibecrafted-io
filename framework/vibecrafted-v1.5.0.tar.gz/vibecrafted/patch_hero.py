import sys

target = "/Users/polyversai/Libraxis/01_deployed_libraxis_vm/vibecrafted-io/site/src/components/sections/HeroSection.astro"

with open(target, "r") as f:
    text = f.read()

text = text.replace(
    '<span class="manifesto-title__framework-accent">Release</span> Engine',
    '<span class="manifesto-title__framework-accent">Founders\'</span> Framework'
)

new_quote = '{lang === "en" ? <Fragment set:html={`A framework that wrote its own code through <span class="manifesto-quote__accent">𝚅𝚒𝚋𝚎𝚌𝚛𝚊𝚏𝚝𝚜𝚖𝚊𝚗𝚜𝚑𝚒𝚙</span>.`} /> : <Fragment set:html={`Framework, który napisał swój własny kod przez <span class="manifesto-quote__accent">𝚅𝚒𝚋𝚎𝚌𝚛𝚊𝚏𝚝𝚜𝚖𝚊𝚗𝚜𝚑𝚒𝚙</span>.`} /> }'
text = text.replace('{hero.quote}', new_quote)

with open(target, "w") as f:
    f.write(text)
