import os

def split_file(path, chunks):
    with open(path, "r", encoding="utf-8") as f:
        lines = f.readlines()
        
    for outfile, line_ranges in chunks.items():
        with open(outfile, "w", encoding="utf-8") as out:
            for r in line_ranges:
                start, end = r
                out.writelines(lines[start-1:end])
                out.write("\n")

split_file("skills/vc-agents/scripts/lib/launcher.sh", {
    "skills/vc-agents/scripts/lib/launcher_watch.sh": [(1, 2), (3, 140)],
    "skills/vc-agents/scripts/lib/launcher_terminal.sh": [(1, 2), (258, 352)],
    "skills/vc-agents/scripts/lib/launcher.sh": [(1, 2), (142, 256), (354, 421)]
})

split_file("skills/vc-agents/scripts/lib/session.sh", {
    "skills/vc-agents/scripts/lib/session_ambient.sh": [(1, 2), (22, 55), (93, 115)],
    "skills/vc-agents/scripts/lib/session.sh": [(1, 2), (3, 20), (57, 91), (117, 263), (264, 264)]
})

split_file("skills/vc-agents/scripts/lib/zellij.sh", {
    "skills/vc-agents/scripts/lib/zellij_monitor.sh": [(1, 2), (3, 87)],
    "skills/vc-agents/scripts/lib/zellij.sh": [(1, 2), (89, 250)]
})

