import sys

file_path = "/Users/polyversai/Libraxis/vc-runtime/vibecrafted-io/site/src/components/InstallerWizard.svelte"

with open(file_path, "r", encoding="utf-8") as f:
    content = f.read()

replacements = [
    (
        "terminalKicker: 'Preview of the guided install',",
        "terminalKicker: 'Install preview',"
    ),
    (
        "terminalBody: 'The bootstrap opens the local browser installer, then the real output continues in that surface.',",
        "terminalBody: 'The startup script opens the local browser installer, and all further progress continues there.',"
    ),
    (
        "welcomeCta: 'See the guided path',",
        "welcomeCta: 'See the install flow',"
    ),
    (
        "label: 'Browser-first path',\n      value: 'The guided installer runs in the browser after the bootstrap handoff, and that browser surface owns the live output.',",
        "label: 'Browser-first',\n      value: 'The installer runs in your browser after a quick startup, showing you the real-time progress.',"
    ),
    (
        "label: 'Bootstrap handoff',\n      value: 'The shell command is only the short launcher that stages the local control plane and opens the guided installer.',",
        "label: 'Terminal handoff',\n      value: 'The terminal command is just a quick launcher that prepares the local files and opens the browser interface.',"
    ),
    (
        "label: 'One mutation engine',\n      value: 'The browser path still runs the same repo-owned installer truth used by automation and local checkouts.',",
        "label: 'Same engine',\n      value: 'The browser mode uses the exact same installer logic as our automated scripts and local setups.',"
    ),
    (
        "label: 'Consent boundary',\n      value: 'The flow explains itself first and only asks right before the install begins.',",
        "label: 'Clear consent',\n      value: 'The installer explains every step first and asks for your permission right before making changes.',"
    ),
    (
        "title: 'Browser-first guided install',\n        body: [\n          'The public front door is the guided browser installer, not a wall of terminal output.',\n          'The bootstrap command only hands off into the local guided surface, where the real install runs and streams live.',\n        ],\n        hint: 'Browser first. Same installer truth underneath.',",
        "title: 'Browser-first install',\n        body: [\n          'The public entry point is the browser installer, not a wall of terminal text.',\n          'The startup command just opens the local browser view, where the actual installation happens and streams live.',\n        ],\n        hint: 'Browser first. Same installer engine underneath.',"
    ),
    (
        "title: 'What the guided path actually does',\n        body: [],\n        items: [\n          { icon: '\\u21B3', name: 'Local handoff', desc: 'The bootstrap stages the control plane locally and opens the guided installer in your browser.' },\n          { icon: '\\u25C8', name: 'Foundations', desc: 'loctree, aicx-mcp, prview, ScreenScribe' },\n          { icon: '\\u21CB', name: 'Live output', desc: 'Real staged steps and real output stream in the browser instead of disappearing into shell noise.' },\n          { icon: '\\u2318', name: 'Same engine', desc: 'The browser surface still wraps the same repo-owned installer truth and helper wiring.' },\n        ],\n        hint: 'One browser surface, one installer backend',",
        "title: 'What this mode actually does',\n        body: [],\n        items: [\n          { icon: '\\u21B3', name: 'Local startup', desc: 'The command prepares the local files and opens the installer in your browser.' },\n          { icon: '\\u25C8', name: 'Foundations', desc: 'loctree, aicx-mcp, prview, ScreenScribe' },\n          { icon: '\\u21CB', name: 'Live progress', desc: 'Actual steps and live updates stream in the browser instead of getting lost in the terminal.' },\n          { icon: '\\u2318', name: 'Same mechanism', desc: 'The browser view still wraps the exact same installer logic and helpers.' },\n        ],\n        hint: 'One browser interface, one installation engine',"
    ),
    (
        "title: 'Prerequisites',\n        body: [\n          'The guided installer checks your machine shape before the mutation steps begin.',\n          'Optional tools are surfaced clearly so you know what is missing before you launch install.',\n        ],",
        "title: 'Your environment',\n        body: [\n          'The installer checks your system before starting any steps that modify your machine.',\n          'Missing optional tools are shown clearly, so you know what you might need before starting the install.',\n        ],"
    ),
    (
        "hint: 'Explain first, mutate second',",
        "hint: 'Explain first, make changes later',"
    ),
    (
        "title: 'Bootstrap the guided install',\n        body: [\n          'Use the bootstrap command to open the local guided installer surface.',\n          'From there the install stays in-browser, shows live output, and only asks right before the real mutation begins.',\n        ],\n        hint: 'Preview below shows the bootstrap handoff into the browser installer',",
        "title: 'Run the installer',\n        body: [\n          'Use the startup command to open the local installer in your browser.',\n          'From there the process stays in the browser, shows live progress, and asks for confirmation right before making real changes.',\n        ],\n        hint: 'The preview below shows the transition into the browser installer',"
    ),
    (
        "title: 'After the guided run finishes',\n        body: [\n          'The command deck becomes available on your machine after the browser-guided flow exits cleanly. Start here:',\n        ],",
        "title: 'After the installation finishes',\n        body: [\n          'The command deck becomes available locally after the browser installation completes successfully. Start here:',\n        ],"
    ),
    (
        "hint: 'Start with doctor after the browser-guided install',",
        "hint: 'Start with doctor after the installation',"
    ),
    (
        "'[bootstrap] Staging local control plane under ~/.vibecrafted/tools/vibecrafted-main',",
        "'[bootstrap] Preparing local files under ~/.vibecrafted/tools/vibecrafted-main',"
    ),
    (
        "'[bootstrap] Opening guided installer at http://127.0.0.1:48217',",
        "'[bootstrap] Opening browser installer at http://127.0.0.1:48217',"
    ),
    (
        "'[browser] This flow stays read-only until you launch install.',",
        "'[browser] This view remains read-only until you start the installation.',"
    ),
    (
        "'[browser] Launch guided install',",
        "'[browser] Start installation',"
    ),
    (
        "'[browser] Streaming repo-owned installer output...',",
        "'[browser] Streaming real installer output...',",
    )
]

for old, new in replacements:
    if old not in content:
        print(f"WARNING: String not found: {old}")
    content = content.replace(old, new)

with open(file_path, "w", encoding="utf-8") as f:
    f.write(content)

print("Done replacing.")
