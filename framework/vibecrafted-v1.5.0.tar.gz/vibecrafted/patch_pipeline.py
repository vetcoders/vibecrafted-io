import sys
import re

target = "/Users/polyversai/Libraxis/01_deployed_libraxis_vm/vibecrafted-io/site/src/components/sections/PipelineSection.astro"

with open(target, "r") as f:
    text = f.read()

# I will replace `<article class="pipeline-note">` with the number injected.
parts = text.split('<article class="pipeline-note">')
if len(parts) == 4:
    text = parts[0] + '<article class="pipeline-note">\n                <span class="pipeline-num">01</span>' + parts[1] + '<article class="pipeline-note">\n                <span class="pipeline-num">02</span>' + parts[2] + '<article class="pipeline-note">\n                <span class="pipeline-num">03</span>' + parts[3]

with open(target, "w") as f:
    f.write(text)
