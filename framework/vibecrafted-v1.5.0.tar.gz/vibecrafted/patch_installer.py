import re

with open("scripts/installer_gui.py", "r") as f:
    content = f.read()

# 1. CSS body
content = re.sub(
    r"body \{\s*margin: 0;\s*min-height: 100vh;",
    "body {\n                margin: 0;\n                height: 100vh;\n                overflow: hidden;\n                display: flex;\n                align-items: center;\n                justify-content: center;",
    content
)

# 2. CSS .shell
content = re.sub(
    r"\.shell \{\s*width: min\(1180px, calc\(100vw - 32px\)\);\s*margin: 24px auto;\s*padding: 28px;",
    ".shell {\n                width: min(1180px, calc(100vw - 32px));\n                max-height: calc(100vh - 32px);\n                display: flex;\n                flex-direction: column;\n                overflow: hidden;\n                margin: 0 auto;\n                padding: 20px;",
    content
)

# 3. CSS .hero
content = re.sub(
    r"\.hero \{\s*display: grid;\s*gap: 18px;\s*grid-template-columns: minmax\(0, 1\.4fr\) minmax\(280px, 0\.9fr\);\s*align-items: stretch;\s*margin-bottom: 24px;\s*\}",
    ".hero {\n                display: grid;\n                gap: 14px;\n                grid-template-columns: minmax(0, 1.4fr) minmax(280px, 0.9fr);\n                align-items: stretch;\n                margin-bottom: 14px;\n                flex-shrink: 0;\n              }",
    content
)

# 4. CSS .panel, .hero-copy, .hero-side
content = re.sub(
    r"\.hero-copy,\s*\.hero-side,\s*\.panel \{\s*padding: 24px;",
    ".hero-copy,\n              .hero-side,\n              .panel {\n                padding: 16px;",
    content
)

# 5. CSS h1
content = re.sub(
    r"h1 \{\s*margin: 10px 0 14px;\s*font-size: clamp\(34px, 6vw, 58px\);",
    "h1 {\n                margin: 6px 0 10px;\n                font-size: clamp(24px, 4vw, 36px);",
    content
)

# 6. CSS .page-grid
content = re.sub(
    r"\.page-grid \{\s*display: grid;\s*gap: 20px;\s*grid-template-columns: minmax\(0, 1\.35fr\) minmax\(320px, 0\.95fr\);\s*\}",
    ".page-grid {\n                display: grid;\n                gap: 16px;\n                grid-template-columns: minmax(0, 1.35fr) minmax(320px, 0.95fr);\n                flex: 1;\n                min-height: 0;\n                overflow: hidden;\n              }",
    content
)

# 7. Add flex to .panel
content = re.sub(
    r"\.panel \{\s*padding: 16px;\s*border: 1px solid var\(--border\);\s*border-radius: 24px;\s*background: var\(--panel\);\s*\}",
    ".panel {\n                padding: 16px;\n                border: 1px solid var(--border);\n                border-radius: 24px;\n                background: var(--panel);\n                display: flex;\n                flex-direction: column;\n                overflow: hidden;\n              }",
    content
)

# 8. CSS .category-grid
content = re.sub(
    r"\.category-grid \{\s*display: grid;\s*gap: 14px;\s*margin-top: 18px;\s*\}",
    ".category-grid {\n                display: grid;\n                gap: 10px;\n                margin-top: 10px;\n                flex: 1;\n                overflow-y: auto;\n                padding-right: 4px;\n              }",
    content
)

# 9. CSS .log-box
content = re.sub(
    r"\.log-box \{\s*margin-top: 14px;\s*padding: 16px;\s*border-radius: 18px;",
    ".log-box {\n                margin-top: 12px;\n                padding: 12px;\n                border-radius: 14px;\n                flex: 1;\n                min-height: 0;\n                display: flex;\n                flex-direction: column;\n                overflow: hidden;",
    content
)

# 10. CSS .log-box pre
content = re.sub(
    r"\.log-box pre \{\s*margin: 0;\s*white-space: pre-wrap;",
    ".log-box pre {\n                margin: 0;\n                white-space: pre-wrap;\n                flex: 1;\n                overflow-y: auto;\n                display: flex;\n                flex-direction: column;\n                justify-content: flex-end;",
    content
)

# 11. HTML Remove .hero-list
content = re.sub(
    r"<ul class=\"hero-list\">.*?</ul>",
    "",
    content,
    flags=re.DOTALL
)

# 12. HTML Remove .steps
content = re.sub(
    r"<ol class=\"steps\">.*?</ol>",
    "",
    content,
    flags=re.DOTALL
)

# 13. HTML Remove .footer-note
content = re.sub(
    r"<p class=\"footer-note\">.*?</p>",
    "",
    content,
    flags=re.DOTALL
)

with open("scripts/installer_gui.py", "w") as f:
    f.write(content)

