import sys
import re

target = "/Users/polyversai/Libraxis/01_deployed_libraxis_vm/vibecrafted-io/site/src/styles/global.css"

with open(target, "r") as f:
    text = f.read()

# Add framework-strip to mobile overflow
text = text.replace('.skills-track, .card-strip {', '.skills-track, .card-strip, .framework-strip, .docs-grid {')

with open(target, "w") as f:
    f.write(text)
