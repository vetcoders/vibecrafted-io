import sys
import re

target = "/Users/polyversai/Libraxis/01_deployed_libraxis_vm/vibecrafted-io/site/src/styles/global.css"

with open(target, "r") as f:
    text = f.read()

# 1. Pipeline
# Remove linear-gradient from .pipeline-section
text = re.sub(r'(\.pipeline-section\s*\{[^}]*)background:\s*linear-gradient[^;]+;', r'\1', text)
# Add .pipeline-num styling
pipeline_num_css = """
.pipeline-num {
    display: block;
    color: var(--copper);
    font-family: var(--font-mono);
    font-size: 0.85rem;
    letter-spacing: 0.05em;
    margin-bottom: var(--space-xs);
    opacity: 0.8;
}
"""
text = text.replace('.pipeline-note h3 {', pipeline_num_css + '\n.pipeline-note h3 {')

# 2. Quickstart Hero (.docs-hero)
# Change background from var(--docs-hero-surface) to var(--glass-panel-bg)
text = re.sub(r'background:\s*var\(--docs-hero-surface\);', r'background: var(--glass-panel-bg);', text)
# Add border to it
text = re.sub(r'border:\s*1px\s+solid\s+var\(--glass-panel-border\);', r'border: 1px solid var(--glass-panel-border);', text)

# 3. Skills Carousel cards (.card--accent-*)
# Make sure .card uses glass panel bg. It already does!
# .card { background: var(--glass-panel-bg); border: 1px solid var(--glass-panel-border); ... }

# 4. Mobile Overflow
mobile_overflow_css = """
.mermaid, .mmd-shell {
    max-width: 100%;
    overflow-x: auto;
}
.skills-track, .card-strip {
    max-width: 100%;
    overflow-x: auto;
    -webkit-overflow-scrolling: touch;
}
"""
text += "\n" + mobile_overflow_css

with open(target, "w") as f:
    f.write(text)
