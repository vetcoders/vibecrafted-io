import sys
import shutil

files = [
    "/Users/polyversai/.vibecrafted/artifacts/VetCoders/vibecrafted/2026_0412/marbles/reports/20260412_1836_marbles-ancestor_L1_gemini.md",
    "/Users/polyversai/.vibecrafted/artifacts/VetCoders/vibecrafted/2026_0412/marbles/reports/20260412_1853_marbles-ancestor_L2_gemini.md",
    "/Users/polyversai/.vibecrafted/artifacts/VetCoders/vibecrafted/2026_0412/marbles/reports/20260412_1902_marbles-ancestor_L3_gemini.md"
]

out_names = ["L1.md", "L2.md", "L3.md"]

for src, dst in zip(files, out_names):
    try:
        shutil.copy(src, dst)
        print(f"Copied {src} to {dst}")
    except Exception as e:
        print(f"Error copying {src}: {e}")
