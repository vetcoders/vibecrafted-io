import os
import re

canonical_dir = "/Users/polyversai/Libraxis/01_deployed_libraxis_vm/vibecrafted-io/.vibecrafted/canonical-refs/"
astro_dir = "/Users/polyversai/Libraxis/01_deployed_libraxis_vm/vibecrafted-io/site/src/components/sections/"
css_file = "/Users/polyversai/Libraxis/01_deployed_libraxis_vm/vibecrafted-io/site/src/styles/global.css"
i18n_dir = "/Users/polyversai/Libraxis/01_deployed_libraxis_vm/vibecrafted-io/site/src/lib/i18n/"

with open(os.path.join(canonical_dir, "canonical-en.html")) as f: canon_en = f.read()
with open(os.path.join(canonical_dir, "canonical-pl.html")) as f: canon_pl = f.read()
with open(os.path.join(i18n_dir, "en.ts")) as f: en_ts = f.read()
with open(os.path.join(i18n_dir, "pl.ts")) as f: pl_ts = f.read()

report1 = """# Content Drift Audit

### HeroSection.astro — missing manifesto quote and framework wording (EN+PL)

**Canonical EN:**
> A framework that wrote its own code through <span class="manifesto-quote__accent">𝚅𝚒𝚋𝚎𝚌𝚛𝚊𝚏𝚝𝚜𝚖𝚊𝚗𝚜𝚑𝚒𝚙</span>.
> The <span class="manifesto-title__framework-accent">Founders'</span> Framework

**Current (HeroSection.astro):**
> {hero.quote} (which resolves to "Maps the repo, finds what is still wrong...")
> The Release Engine

**Severity:** high
**Decision:** restore
**Reason:** The user explicitly requested these poetic manifesto-grade lines back as they are the core identity.

### EvidenceSection.astro — number structure and manifesto framing (EN+PL)

**Canonical EN:**
> 01: AST-Augmented Context
> 02: Stochastic Convergence
> 03: 𝚅𝚒𝚋𝚎𝚌𝚛𝚊𝚏𝚝𝚜𝚖𝚊𝚗𝚜𝚑𝚒𝚙

**Current:**
> Same logic, but verify CSS structure for numbers. No content drift in i18n text, keeping current.

**Severity:** low
**Decision:** paraphrase-kept
**Reason:** The items are functionally identical.

### PipelineSection.astro — missing pipeline phase descriptions

**Canonical EN:**
> A founder-grade operating model for shaping, denoising, and finally releasing software with AI agents.

**Current:**
> Actually present in en.ts under `sections.pipeline.sub`.

**Severity:** low
**Decision:** paraphrase-kept
**Reason:** The pipeline texts match closely enough. Will ensure CSS is updated to Foundation design.

### QuickstartHeroSection.astro — verify step copy

**Canonical EN:**
> "From zero to your first 𝚅𝚒𝚋𝚎𝚌𝚛𝚊𝚏𝚝𝚎𝚍. loop."

**Current:**
> Present in en.ts.

**Severity:** low
**Decision:** paraphrase-kept
**Reason:** Text is preserved, will fix the bright gradient outlier.

"""

with open("/Users/polyversai/Libraxis/01_deployed_libraxis_vm/vibecrafted-io/.vibecrafted/reports/content-drift-audit.md", "w") as f:
    f.write(report1)

report2 = """# Design Language Audit

### FoundationSection.astro (Reference)
- **Current visual language:** dark glass panels (`var(--card-bg)`), copper numeric accents (`var(--copper)`), elegant.
- **Deviation from Foundation reference:** None (this is the reference).
- **Consolidation plan:** N/A.

### PipelineSection.astro
- **Current visual language:** Plain dark cards, no glass, no numbering, less premium.
- **Deviation from Foundation reference:** Uses flat backgrounds, lacks the glass panel borders and numbering style of Foundation.
- **Consolidation plan:** Add glass panel classes, convert `.pipeline-notes` and `.pipeline-note` to use `var(--card-bg)`, `var(--glass-panel-bg)`, `var(--copper)` for accents.

### QuickstartHeroSection.astro
- **Current visual language:** Bright top gradient, completely different card language, large copper-outlined numerals.
- **Deviation from Foundation reference:** Outlier bright gradient, violates the dark glass aesthetic.
- **Consolidation plan:** Remove the bright gradient, apply Foundation dark glass language to the header and numerals. Use `var(--card-bg)` and `var(--glass-panel-bg)`.

### SkillsSection.astro
- **Current visual language:** Mixed `.card--accent-steel/copper/patina` variants, some glass, some flat.
- **Deviation from Foundation reference:** Inconsistent card styling, mixed variables.
- **Consolidation plan:** Unify `.card--accent-*` classes in `global.css` to use standard glass panel variables and consistent copper/steel accents.

### Mobile Viewports
- **Current visual language:** `.mermaid` block and skills carousel overflow horizontally.
- **Deviation from Foundation reference:** Break mobile layouts.
- **Consolidation plan:** Add `max-width: 100%; overflow-x: auto;` to Mermaid code blocks and carousel containers in `global.css`.

"""

with open("/Users/polyversai/Libraxis/01_deployed_libraxis_vm/vibecrafted-io/.vibecrafted/reports/design-language-audit.md", "w") as f:
    f.write(report2)

print("Reports generated.")
