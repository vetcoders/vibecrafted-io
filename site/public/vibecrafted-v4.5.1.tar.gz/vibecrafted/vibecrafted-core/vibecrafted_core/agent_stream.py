"""Parse agent streaming-json output (Claude/Codex/Gemini/Junie/Grok/Kimi) into pane text."""

from __future__ import annotations

import json
import os
import re
import shlex
import time
import tomllib
from collections import OrderedDict
from collections.abc import Mapping, Sequence
from pathlib import Path
from typing import Any

from .telemetry import estimate_cost_usd, is_model_name

ANSI_PATTERN = re.compile(r"\x1b\[[0-9;?]*[A-Za-z]")
SESSION_PATTERN = re.compile(
    r"(?:^|\[[0-9]{2}:[0-9]{2}:[0-9]{2}\]\s+)session:\s*([A-Za-z0-9][A-Za-z0-9._:-]*)",
    re.MULTILINE,
)
TOKEN_PATTERN = re.compile(
    r"tokens:\s*([0-9]+)\s+in(?:\s*\(([0-9]+)\s+cached\))?\s*/\s*([0-9]+)\s+out",
    re.IGNORECASE,
)
# Plain `model: X` is prose. Only a timestamped provider header names the model,
# and only when it starts a line after ANSI stripping and leading whitespace.
# A header quoted mid-sentence, or after `>`, is prose. Same anchor as spawn.py.
TIMESTAMPED_MODEL_PATTERN = re.compile(
    r"(?m)^[^\S\r\n]*\[[0-9]{2}:[0-9]{2}:[0-9]{2}\]\s+model:[ \t]*([^\r\n]*)$",
    re.IGNORECASE,
)
MODEL_ENV_VARS = (
    "VIBECRAFTED_PARENT_MODEL",
    "CLAUDE_MODEL",
    "CODEX_MODEL",
    "GEMINI_MODEL",
    "GROK_MODEL",
    "JUNIE_MODEL",
    "AGY_MODEL",
    "KIMI_MODEL",
    "COPILOT_MODEL",
    "CURSOR_MODEL",
    "OMP_MODEL",
)
GROK_IGNORABLE_TRANSPORT_ERROR = "worker quit with fatal: Transport channel closed"
# Every provider spelling of a token count. A usage dict carrying none of these
# is not a usage event — zero must stay a measurement, not a default.
_USAGE_KEYS = (
    "input_tokens",
    "inputTokens",
    "prompt_tokens",
    "cached_input_tokens",
    "cache_read_input_tokens",
    "cacheReadInputTokens",
    "cacheReadTokens",
    "cacheInputTokens",
    "cached_prompt_tokens",
    "cache_read_tokens",
    "cache_creation_input_tokens",
    "cacheCreateTokens",
    "cacheWriteTokens",
    "output_tokens",
    "outputTokens",
    "completion_tokens",
)
# A tool payload is the agent's own text. Nothing inside it is telemetry.
# Same set as spawn._TOOL_PAYLOAD_KEYS; kept here so the two modules do not import each other.
_TOOL_PAYLOAD_KEYS = frozenset(
    {
        "input",
        "arguments",
        "args",
        "parameters",
        "tool_input",
        "tool_call",
        "toolCall",
    }
)
_MODEL_USAGE_KEYS = frozenset({"modelUsage", "model_usage"})


def _telemetry_children(key: str, value: object) -> tuple[dict[str, Any], ...]:
    """Dicts under ``key`` that may still carry a model or a cost.

    Walk dicts. Enter a list only under ``modelUsage`` / ``model_usage``.
    Never enter a tool payload.
    """
    if key in _TOOL_PAYLOAD_KEYS:
        return ()
    if key in _MODEL_USAGE_KEYS and isinstance(value, list):
        return tuple(item for item in value if isinstance(item, dict))
    if isinstance(value, dict):
        return (value,)
    return ()


def stamp() -> str:
    """Return the current local time as ``HH:MM:SS``."""
    return time.strftime("%H:%M:%S", time.localtime())


def tool_tag(name: str) -> str:
    """Render a cyan ``[HH:MM:SS name]`` tag used to mark tool-call lines in the pane."""
    return f"\x1b[36m[{stamp()} {name}]\x1b[0m "


# One tool call stays a single clipped line. Two or more consecutive calls
# collapse to one summary so a Bash/MCP burst cannot fill the pane with
# empty timestamps.
_TOOL_LINE_LIMIT = 60
_TWO_WORD_HEADS = frozenset({"aicx"})
_PARTIAL_TOOL_FIELD = re.compile(
    r'"(?:command|cmd|query|pattern|file_path|path|url)"\s*:\s*"((?:\\.|[^"\\])*)'
)


class _ToolNote:
    """One tool/MCP/command call held until the burst ends."""

    __slots__ = ("detail", "name", "stamp")

    def __init__(self, stamp: str, name: str, detail: str) -> None:
        self.stamp = stamp
        self.name = name
        self.detail = detail


def _clip_visible(text: str, limit: int = _TOOL_LINE_LIMIT) -> str:
    """Clip ``text`` to ``limit`` visible characters, ignoring ANSI and newlines."""
    visible = ANSI_PATTERN.sub("", text).replace("\n", " ").strip()
    if len(visible) <= limit:
        return visible
    return visible[: limit - 3].rstrip() + "..."


def _unescape_partial(value: str) -> str:
    try:
        return json.loads(f'"{value}"')
    except json.JSONDecodeError:
        return value.replace("\\n", "\n").replace('\\"', '"')


def _command_text(value: Any) -> str:
    """Pull the operator-visible command or argument out of a tool input."""
    if isinstance(value, dict):
        for key in ("command", "cmd", "query", "pattern", "file_path", "path", "url"):
            text = _stringish(value.get(key))
            if text:
                return text
        arguments = value.get("arguments")
        if isinstance(arguments, str) and arguments.strip().startswith("{"):
            try:
                return _command_text(json.loads(arguments))
            except json.JSONDecodeError:
                return arguments
        nested = value.get("input")
        if nested is not None and nested is not value:
            return _command_text(nested)
        return ""
    if isinstance(value, str) and value.strip().startswith("{"):
        try:
            parsed = json.loads(value)
        except json.JSONDecodeError:
            return value
        if isinstance(parsed, dict):
            return _command_text(parsed)
    return _stringish(value)


def _detail_from_partial(blob: str) -> str:
    """Read a command field out of a still-streaming tool-input JSON fragment."""
    match = _PARTIAL_TOOL_FIELD.search(blob)
    if match is None:
        return ""
    return _unescape_partial(match.group(1)).strip()


def _command_head(detail: str) -> str:
    """First meaningful argv token, keeping ``aicx <sub>`` as one head."""
    text = detail.strip()
    if text.startswith("$ "):
        text = text[2:].strip()
    if not text:
        return ""
    try:
        tokens = shlex.split(text)
    except ValueError:
        tokens = text.split()
    cleaned: list[str] = []
    for token in tokens:
        if not cleaned and "=" in token and not token.startswith("-"):
            continue
        cleaned.append(token)
    if not cleaned:
        return ""
    if cleaned[0] in _TWO_WORD_HEADS and len(cleaned) > 1:
        return f"{cleaned[0]} {cleaned[1]}"
    return cleaned[0]


def render_tool_burst(notes: Sequence[_ToolNote]) -> str:
    """Render one tool call clipped to 60 visible characters, or one burst summary.

    A burst is ``from [HH:MM:SS] to [HH:MM:SS] 12x Bash: grep 8, loct 2``.
    The calls stay in the summary; they are not dropped and not printed as
    a column of bare timestamps.
    """
    if not notes:
        return ""
    if len(notes) == 1:
        note = notes[0]
        body = f"[{note.stamp} {note.name}]"
        if note.detail:
            body = f"{body} {note.detail}"
        return f"\n\x1b[36m{_clip_visible(body)}\x1b[0m\n"
    by_name: OrderedDict[str, list[_ToolNote]] = OrderedDict()
    for note in notes:
        by_name.setdefault(note.name, []).append(note)
    parts: list[str] = []
    for name, group in by_name.items():
        order: list[str] = []
        counts: dict[str, int] = {}
        for note in group:
            head = _command_head(note.detail)
            if not head:
                continue
            if head not in counts:
                order.append(head)
                counts[head] = 0
            counts[head] += 1
        if order:
            breakdown = ", ".join(f"{head} {counts[head]}" for head in order)
            parts.append(f"{len(group)}x {name}: {breakdown}")
        else:
            parts.append(f"{len(group)}x {name}")
    summary = f"from [{notes[0].stamp}] to [{notes[-1].stamp}] " + "; ".join(parts)
    return f"\n\x1b[36m{summary}\x1b[0m\n"


def _stringish(value: Any) -> str:
    """Best-effort coercion of an event field to display text.

    Unwraps common envelope dicts (message/error/detail/text/content) and
    returns "" for a recognized-but-empty envelope, treating it as noise
    (e.g. grok's ``{"type":"text","text":""}`` heartbeats).
    """
    if value is None:
        return ""
    if isinstance(value, str):
        return value
    if isinstance(value, (int, float, bool)):
        return str(value)
    if isinstance(value, dict):
        # message/error/detail are the classic envelopes; text/content cover
        # grok tool_call blocks ({"type":"content","content":{"type":"text",
        # "text":...}}) which otherwise degrade to json.dumps noise.
        keys = ("message", "error", "detail", "text", "content")
        inner = next((value[k] for k in keys if value.get(k)), None)
        if inner is not None and inner is not value:
            return _stringish(inner)
        if any(k in value for k in keys):
            # A recognized envelope whose payload is empty is noise, not data
            # (grok emits {"type":"text","text":""} heartbeats mid-stream).
            return ""
        return json.dumps(value, ensure_ascii=False)
    if isinstance(value, list):
        return ", ".join(_stringish(item) for item in value)
    return json.dumps(value, ensure_ascii=False)


def _truncate_block(text: str, *, max_chars: int = 4000) -> str:
    """Dim-render ``text``, truncating long command/tool output for the pane."""
    lines = text.splitlines()
    if len(text) > max_chars:
        preview = text[:max_chars]
        return f"\x1b[2m{preview}\n  ... ({len(text)} chars)\x1b[0m\n"
    if len(lines) > 12:
        preview = "\n".join(lines[:5])
        return f"\x1b[2m{preview}\n  ... ({len(lines)} lines)\x1b[0m\n"
    return f"\x1b[2m{text}\x1b[0m\n"


def is_grok_ignorable_transport_error(text: str) -> bool:
    """Return True for grok transport-closed noise caused by an auth/DNS/TCP failure.

    These lines are expected retry chatter, not a real turn failure worth
    surfacing to the pane.
    """
    clean = ANSI_PATTERN.sub("", text or "")
    if GROK_IGNORABLE_TRANSPORT_ERROR not in clean:
        return False
    return any(
        marker in clean
        for marker in (
            "AuthorizationRequired",
            "AuthRequired",
            "tcp connect error",
            "dns error",
        )
    )


def _as_int(value: Any) -> int:
    """Coerce ``value`` to int, defaulting to 0 for None/unparseable input."""
    try:
        return int(value or 0)
    except (TypeError, ValueError):
        return 0


def _as_float(value: Any) -> float | None:
    """Coerce ``value`` to a float rounded to 6dp, or None for empty/unparseable input."""
    if value in (None, ""):
        return None
    try:
        return round(float(value), 6)
    except (TypeError, ValueError):
        return None


def _clean_model(value: object) -> str:
    """Return a real model label, or "" when ``value`` is missing or not a model."""
    raw = str(value or "").strip()
    return raw if is_model_name(raw) else ""


def _command_model(command: Sequence[str] | None) -> str:
    """Extract a ``--model``/``-m``/``--model=`` value from a launch command argv."""
    if not command:
        return ""
    items = [str(item) for item in command]
    for index, item in enumerate(items):
        if item in {"--model", "-m"} and index + 1 < len(items):
            model = _clean_model(items[index + 1])
            if model:
                return model
        if item.startswith("--model="):
            model = _clean_model(item.split("=", 1)[1])
            if model:
                return model
    return ""


def _codex_config_model(env: Mapping[str, str]) -> str:
    """Read the default model from ``$CODEX_HOME/config.toml``; "" if unset/unreadable."""
    codex_home = Path(env.get("CODEX_HOME") or Path.home() / ".codex")
    config = codex_home / "config.toml"
    try:
        with config.open("rb") as handle:
            loaded = tomllib.load(handle)
    except (OSError, tomllib.TOMLDecodeError):
        return ""
    if isinstance(loaded, dict):
        return _clean_model(loaded.get("model"))
    return ""


def resolve_default_model(
    agent: str,
    *,
    command: Sequence[str] | None = None,
    env: Mapping[str, str] | None = None,
) -> str:
    """Resolve command, explicit generic override, selected provider env, then config.

    Another provider's ambient model is never this agent's default. An explicit
    empty environment must also stay empty rather than fall back to the host.
    """
    model = _command_model(command)
    if model:
        return model
    source_env = os.environ if env is None else env
    agent = agent.strip().lower()
    for key in ("VIBECRAFTED_PARENT_MODEL", f"{agent.upper()}_MODEL"):
        if key not in MODEL_ENV_VARS:
            continue
        model = _clean_model(source_env.get(key))
        if model:
            return model
    if agent == "codex":
        return _codex_config_model(source_env)
    return ""


class AgentStreamParser:
    """Stateful per-agent parser turning streaming-json lines into human-readable text.

    Accumulates session id, model id, token counts, and cost as a side
    effect of ``feed_line`` so callers can read telemetry after the stream.
    """

    def __init__(self, agent: str, *, default_model: str = "") -> None:
        """Initialize parser state for a supported agent stream."""
        self.agent = agent
        self.session_id = ""
        self._rendered_session_ids: set[str] = set()
        self.model_id = _clean_model(default_model)
        self.tokens_input = 0
        self.tokens_cached_input = 0
        self.tokens_cache_write: int | None = None
        self.tokens_output = 0
        # Provider usage events actually observed; 0 means "never reported",
        # which the close path records as unknown rather than zero tokens.
        self.usage_events = 0
        self.cost_usd: float | None = None
        self.cost_source: str | None = None
        # Final assistant answer of a stream that reports one (agy
        # `result.response`; kimi content; omp authoritative message_end).
        self.final_response: str = ""
        self._omp_text_buffer = ""
        self._omp_text_streamed = False
        self._tool_burst: list[_ToolNote] = []
        self._tool_partial = ""

    def _note_tool(self, name: str, detail: str = "") -> None:
        """Hold one tool, MCP, or command call until the burst ends."""
        self._tool_burst.append(
            _ToolNote(stamp(), (name or "?").strip() or "?", detail.strip())
        )
        self._tool_partial = ""

    def _absorb_tool_input(self, fragment: str) -> None:
        """Attach a streaming tool-input fragment to the open call."""
        if not fragment or not self._tool_burst:
            return
        self._tool_partial += fragment
        detail = _detail_from_partial(self._tool_partial)
        if detail:
            self._tool_burst[-1].detail = detail

    def flush_tool_burst(self) -> str:
        """Render and clear the held tool burst. Empty when nothing is held."""
        notes = self._tool_burst
        self._tool_burst = []
        self._tool_partial = ""
        return render_tool_burst(notes)

    def _emit(self, text: str) -> str:
        """Flush a held tool burst, then the agent's reasoning or result text."""
        if not text:
            return ""
        return self.flush_tool_burst() + text

    def feed_line(self, chunk: bytes) -> str:
        """Decode one line of agent output and render it to human-readable text.

        Non-JSON lines fall through to plain-text scanning for session, token,
        and timestamped model headers. A cost is read only from a JSON event.
        """
        text = chunk.decode("utf-8", errors="replace")
        if self.agent == "grok" and is_grok_ignorable_transport_error(text):
            return ""
        stripped = text.lstrip()
        if not stripped.startswith("{"):
            self._scan_text(text)
            return text
        try:
            event = json.loads(text)
        except json.JSONDecodeError:
            self._scan_text(text)
            return text
        if not isinstance(event, dict):
            return ""
        return self._format_json_event(event)

    def resume_command(self, root: str | Path) -> str:
        """Build the shell command an operator would run to resume this agent's session."""
        session = self.session_id or "<session_id>"
        root_text = str(root)
        if self.agent == "claude":
            return f"cd {root_text} && claude --resume {session}"
        if self.agent == "codex":
            return f"cd {root_text} && codex resume {session}"
        if self.agent == "gemini":
            return f"cd {root_text} && gemini --resume {session}"
        if self.agent == "agy":
            return f"cd {root_text} && agy --conversation {session}"
        if self.agent == "kimi":
            return f"cd {root_text} && kimi -S {session}"
        if self.agent == "omp":
            return f"cd {root_text} && omp --resume {session}"
        if self.agent == "copilot":
            return f"cd {root_text} && copilot --resume {session}"
        if self.agent == "junie":
            return f"cd {root_text} && junie --resume --session-id {session}"
        if self.agent == "grok":
            return f"cd {root_text} && grok --resume {session}"
        if self.agent == "cursor":
            return f"cd {root_text} && cursor-agent --resume {session}"
        return f"cd {root_text} && vc-resume --session {session}"

    def _scan_text(self, text: str) -> None:
        """Scan a plain-text line for session id, tokens, and a timestamped model.

        Cost is never taken from prose. A model is taken only from
        ``[HH:MM:SS] model: X`` after ANSI stripping, and only when X is a
        real model name. A later invalid header does not clear a known model.
        """
        clean = ANSI_PATTERN.sub("", text or "")
        session_matches = SESSION_PATTERN.findall(clean)
        if session_matches:
            self.session_id = session_matches[-1]
        for raw_in, raw_cached, raw_out in TOKEN_PATTERN.findall(clean):
            self.tokens_input += int(raw_in)
            self.tokens_cached_input += int(raw_cached or 0)
            self.tokens_output += int(raw_out)
            self.usage_events += 1
        for match in TIMESTAMPED_MODEL_PATTERN.finditer(clean):
            candidate = match.group(1).strip()
            if is_model_name(candidate):
                self.model_id = candidate

    def _take_model(self, value: object) -> bool:
        """Store ``value`` when it is a real model name. Invalid text does not stick."""
        if not isinstance(value, str):
            return False
        text = value.strip()
        if not is_model_name(text):
            return False
        self.model_id = text
        return True

    def _record_model(self, event: dict[str, Any]) -> None:
        """Capture the first real model id in ``event``.

        No-op once ``self.model_id`` is already set — first valid sighting wins.
        An invalid string does not occupy the slot, so a later valid field can.
        Tool payloads are not entered. A list is entered only under modelUsage.
        """
        if self.model_id or not isinstance(event, dict):
            return
        for key in ("model", "model_id", "modelId", "model_name", "modelName"):
            if self._take_model(event.get(key)):
                return
        message = event.get("message")
        if isinstance(message, dict):
            for key in ("model", "model_id", "modelId", "model_name", "modelName"):
                if self._take_model(message.get(key)):
                    return
        model_usage = event.get("modelUsage") or event.get("model_usage")
        if (
            isinstance(model_usage, dict)
            and model_usage
            and self._take_model(next(iter(model_usage)))
        ):
            return
        if isinstance(model_usage, list):
            for item in model_usage:
                if isinstance(item, dict) and self._take_model(
                    item.get("model") or item.get("model_id")
                ):
                    return
        for key, value in event.items():
            for child in _telemetry_children(key, value):
                self._record_model(child)
                if self.model_id:
                    return

    def _record_usage(self, usage: dict[str, Any]) -> None:
        """Accumulate input/cached-input/cache-write/output token counts from a usage dict.

        Handles each provider's differing key names for the same fields. Only
        a dict carrying at least one token field counts as a usage event.
        """
        if any(usage.get(key) is not None for key in _USAGE_KEYS):
            self.usage_events += 1
        self.tokens_input += _as_int(
            usage.get("input_tokens")
            or usage.get("inputTokens")
            or usage.get("prompt_tokens")
        )
        cached_input = usage.get("cached_input_tokens")
        if cached_input is None:
            cached_input = usage.get("cache_read_input_tokens")
        if cached_input is None:
            cached_input = usage.get("cacheReadInputTokens")
        if cached_input is None:
            cached_input = usage.get("cacheReadTokens")
        if cached_input is None:
            cached_input = usage.get("cacheInputTokens")
        if cached_input is None:
            cached_input = usage.get("cached_prompt_tokens")
        if cached_input is None:
            cached_input = usage.get("cache_read_tokens")
        self.tokens_cached_input += _as_int(cached_input)
        cache_write = usage.get("cache_creation_input_tokens")
        if cache_write is None:
            cache_write = usage.get("cacheCreateTokens")
        if cache_write is None:
            cache_write = usage.get("cacheWriteTokens")
        if cache_write is not None:
            self.tokens_cache_write = (self.tokens_cache_write or 0) + _as_int(
                cache_write
            )
        self.tokens_output += _as_int(
            usage.get("output_tokens")
            or usage.get("outputTokens")
            or usage.get("completion_tokens")
        )

    def _record_cost(self, event: dict[str, Any]) -> None:
        """Capture a provider-reported cost field from ``event`` into ``self.cost_usd``."""
        cost = _as_float(
            event.get("total_cost_usd")
            or event.get("cost_usd")
            or event.get("cost")
            or event.get("total_cost")
        )
        if cost is not None:
            self.cost_usd = cost
            self.cost_source = "provider_reported"

    def _record_nested_telemetry(self, event: dict[str, Any]) -> None:
        """Walk ``event`` for modelUsage/usage/cost (junie/grok shapes).

        Dicts are walked. A list is entered only under modelUsage, and only
        by the list arm above — those items are not queued again. Tool
        payloads are not entered. Falls back to :func:`estimate_cost_usd`
        when no provider-reported cost was found.
        """
        self._record_model(event)
        pending: list[dict[str, Any]] = [event]
        while pending:
            current = pending.pop()
            model_usage = current.get("modelUsage") or current.get("model_usage")
            if isinstance(model_usage, list):
                for usage in model_usage:
                    if isinstance(usage, dict):
                        self._record_usage(usage)
                        cost = _as_float(usage.get("cost") or usage.get("cost_usd"))
                        if cost is not None:
                            self.cost_usd = round((self.cost_usd or 0) + cost, 6)
                            self.cost_source = "provider_reported"
            usage = current.get("usage") or current.get("stats")
            if isinstance(usage, dict):
                self._record_usage(usage)
            self._record_cost(current)
            for key, value in current.items():
                if key in _MODEL_USAGE_KEYS and isinstance(value, list):
                    continue
                pending.extend(_telemetry_children(key, value))
        if self.cost_usd is None or (self.cost_source or "").startswith("estimated:"):
            self.cost_usd, self.cost_source = estimate_cost_usd(
                self.model_id,
                tokens_input=self.tokens_input,
                tokens_cached_input=self.tokens_cached_input,
                tokens_output=self.tokens_output,
            )

    def _session_banner(self, session_id: str, suffix: str = "") -> str:
        """Render the one-time yellow ``session: <id> model: <model>`` banner line.

        Returns "" for an already-rendered session id so the banner only
        appears once per session.
        """
        if not session_id or session_id == "?":
            return ""
        self.session_id = session_id
        if session_id in self._rendered_session_ids:
            return ""
        self._rendered_session_ids.add(session_id)
        model_suffix = f" model: {self.model_id}" if self.model_id else ""
        return self._emit(
            f"\x1b[33m[{stamp()}] session: {session_id}{model_suffix}\x1b[0m{suffix}\n"
        )

    def _format_json_event(self, event: dict[str, Any]) -> str:
        """Dispatch a decoded JSON event to the formatter for ``self.agent``."""
        if self.agent == "agy" and "event" in event:
            return self._format_agy_event(event)
        if self.agent == "kimi":
            return self._format_kimi_event(event)
        if self.agent == "omp":
            return self._format_omp_event(event)
        if self.agent == "copilot":
            return self._format_copilot_event(event)
        if self.agent in {"claude", "agy", "cursor"}:
            if self.agent == "cursor":
                thinking = self._format_cursor_thinking(event)
                if thinking is not None:
                    return self._emit(thinking) if thinking else ""
            return self._format_claude_event(event)
        if self.agent == "codex":
            return self._format_codex_event(event)
        if self.agent == "gemini":
            return self._format_gemini_event(event)
        if self.agent == "junie":
            return self._format_junie_event(event)
        if self.agent == "grok":
            return self._format_grok_event(event)
        return ""

    def _format_omp_event(self, event: dict[str, Any]) -> str:
        """Render one omp ``--mode json`` event (session/message/tool/turn).

        omp 18.11.0 print mode (``omp -p --mode json``, prompt on stdin or
        argv) speaks NDJSON keyed by ``type``. ``session`` opens the stream
        and carries the native session id (``id``) — the stream's only
        identity carrier, so the banner adopts it for resume
        (``omp --resume <id>``). Assistant ``message_start`` provides the
        ``provider``/``model`` but only partial usage. ``message_end`` owns
        authoritative per-message usage and final content, including error
        finalization. ``message_update`` carries printable incremental deltas,
        not usage snapshots or done/error payloads. ``turn_end`` and
        ``agent_end`` repeat completed messages and must not account them again.
        ``tool_execution_*`` carry ``toolName``/``args``/``result`` with
        ``isError`` on end.
        """
        event_type = str(event.get("type") or "")
        if event_type == "session":
            return self._session_banner(str(event.get("id") or ""))
        if event_type in {"message_start", "message_end"}:
            message = event.get("message")
            if not isinstance(message, dict) or message.get("role") != "assistant":
                return ""
            provider = str(message.get("provider") or "").strip()
            model = str(message.get("model") or "").strip()
            if model:
                candidate = f"{provider}/{model}" if provider else model
                if is_model_name(candidate):
                    self.model_id = candidate
            if event_type == "message_start":
                self._omp_text_buffer = ""
                self._omp_text_streamed = False
                return ""
            # OMP dispatches directly here, not through nested telemetry.
            # Account only this completed assistant message, never its copies
            # in turn_end/agent_end or any in-progress message_update.
            usage = message.get("usage")
            if isinstance(usage, dict):
                self._record_usage(
                    {
                        "input_tokens": usage.get("input"),
                        "cached_input_tokens": usage.get("cacheRead"),
                        "cache_creation_input_tokens": usage.get("cacheWrite"),
                        "output_tokens": usage.get("output"),
                    }
                )
                cost = usage.get("cost")
                if isinstance(cost, dict):
                    total = cost.get("total")
                    if isinstance(total, (int, float)):
                        self.cost_usd = (self.cost_usd or 0.0) + float(total)
                        self.cost_source = "provider_reported"
            content = message.get("content")
            text = ""
            if isinstance(content, list):
                text = "\n".join(
                    str(block.get("text") or "")
                    for block in content
                    if isinstance(block, dict) and block.get("type") == "text"
                )
                self.final_response = text
            rendered = "" if self._omp_text_streamed else self._emit(text)
            self._omp_text_streamed = False
            if message.get("stopReason") in {"error", "aborted"}:
                error = str(message.get("errorMessage") or "").strip()
                if error:
                    rendered += self._emit(
                        f"\n\x1b[31m[{stamp()} error] {error}\x1b[0m\n"
                    )
            return rendered
        if event_type == "message_update":
            sub = event.get("assistantMessageEvent")
            if not isinstance(sub, dict):
                return ""
            sub_type = str(sub.get("type") or "")
            if sub_type == "thinking_delta":
                text = str(sub.get("delta") or "")
                return self._emit(f"\x1b[2m{text}\x1b[0m") if text else ""
            if sub_type == "text_start":
                self._omp_text_buffer = ""
                return ""
            if sub_type == "text_delta":
                text = str(sub.get("delta") or "")
                if not text:
                    return ""
                self._omp_text_buffer += text
                self._omp_text_streamed = True
                return self._emit(text)
            if sub_type == "text_end":
                content = str(sub.get("content") or "") or self._omp_text_buffer
                if content:
                    self.final_response = content
                return ""
            return ""
        if event_type == "tool_execution_start":
            self._note_tool(
                _stringish(event.get("toolName")) or "?",
                _command_text(event.get("args")),
            )
            return ""
        if event_type == "tool_execution_end":
            if event.get("isError"):
                name = _stringish(event.get("toolName")) or "tool"
                return self._emit(f"\n\x1b[31m[{stamp()} error] {name} failed\x1b[0m\n")
            return ""
        return ""

    def _format_copilot_event(self, event: dict[str, Any]) -> str:
        """Render Copilot CLI JSONL while retaining native session truth."""
        kind = str(event.get("type") or "")
        data = event.get("data")
        if not isinstance(data, dict):
            data = event
        if kind == "session.start":
            self._take_model(data.get("selectedModel"))
            session = str(data.get("sessionId") or "")
            return self._session_banner(session)
        if kind == "result":
            # Prompt-mode JSONL closes with a top-level result carrying the
            # native session ID; session.start is in the persisted events file
            # but is not emitted on stdout by Copilot CLI 1.0.89-7.
            return self._session_banner(str(event.get("sessionId") or ""))
        if kind == "session.model_change":
            self._take_model(data.get("newModel"))
            return ""
        if kind == "assistant.message":
            self._take_model(data.get("model"))
            content = data.get("content")
            if isinstance(content, str) and content.strip():
                self.final_response = content
                return self._emit(f"\n{content}\n")
            return ""
        if kind == "assistant.message_delta":
            # The complete assistant.message is the durable answer. Rendering
            # both forms would duplicate text and last-message extraction.
            return ""
        if kind in {"tool.execution_start", "tool.execution_started"}:
            name = str(data.get("toolName") or data.get("name") or "tool")
            self._note_tool(name)
            return ""
        if kind == "session.shutdown":
            metrics = data.get("modelMetrics")
            if isinstance(metrics, dict):
                for model, metric in metrics.items():
                    if not isinstance(metric, dict):
                        continue
                    self._take_model(model)
            # modelMetrics is cumulative over the native session. A resumed
            # run cannot attribute that total to this invocation. The
            # harness-usage adapter checks the full session window first.
            return ""
        if kind in {"session.error", "assistant.error"}:
            message = str(data.get("message") or data.get("error") or "unknown")
            return self._emit(f"\n\x1b[31m[{stamp()} error] {message}\x1b[0m\n")
        return ""

    def _format_cursor_thinking(self, event: dict[str, Any]) -> str | None:
        """Render cursor-agent stream-json thinking deltas; None if not a thinking event."""
        if str(event.get("type") or "") != "thinking":
            return None
        text = str(event.get("text") or "")
        if str(event.get("subtype") or "") == "delta" and text:
            return f"\x1b[2m{text}\x1b[0m"
        return ""

    def _format_claude_event(self, event: dict[str, Any]) -> str:
        """Render one Claude/Agy streaming-json event (system/assistant/stream/result)."""
        self._record_model(event)
        event_type = str(event.get("type") or "")
        session_id = event.get("session_id")
        if isinstance(session_id, str) and session_id:
            self.session_id = session_id

        if (
            event_type == "system"
            and session_id
            and str(event.get("subtype") or "init") == "init"
        ):
            return self._session_banner(str(session_id))

        if event_type == "assistant":
            out: list[str] = []
            if isinstance(session_id, str) and session_id:
                out.append(self._session_banner(session_id))
            message = event.get("message") or {}
            content = message.get("content") if isinstance(message, dict) else None
            if isinstance(content, list):
                for item in content:
                    if not isinstance(item, dict):
                        continue
                    if item.get("type") == "text":
                        text = str(item.get("text") or "")
                        if text:
                            out.append(self._emit("\n" + text + "\n"))
                    elif item.get("type") == "thinking":
                        thinking = str(item.get("thinking") or "").strip()
                        if thinking:
                            out.append(self._emit(f"\n\x1b[2m{thinking}\x1b[0m\n"))
                    elif item.get("type") == "tool_use":
                        self._note_tool(
                            str(item.get("name") or "?"),
                            _command_text(item.get("input")),
                        )
            return "".join(out)

        if event_type == "stream_event":
            stream = event.get("event") or {}
            if not isinstance(stream, dict):
                return ""
            if stream.get("type") == "content_block_delta":
                delta = stream.get("delta") or {}
                if not isinstance(delta, dict):
                    return ""
                if delta.get("type") == "text_delta":
                    return self._emit(str(delta.get("text") or ""))
                if delta.get("type") == "thinking_delta":
                    thinking = str(delta.get("thinking") or "")
                    return self._emit(f"\x1b[2m{thinking}\x1b[0m") if thinking else ""
                if delta.get("type") == "input_json_delta":
                    self._absorb_tool_input(str(delta.get("partial_json") or ""))
                    return ""
            if stream.get("type") == "content_block_start":
                block = stream.get("content_block") or {}
                if isinstance(block, dict) and block.get("type") == "tool_use":
                    self._note_tool(
                        str(block.get("name") or "?"),
                        _command_text(block.get("input")),
                    )
                    return ""
            return ""

        if event_type == "result":
            usage = event.get("usage")
            if isinstance(usage, dict):
                self._record_usage(usage)
            self._record_cost(event)
            return self._emit(
                f"\n\x1b[32m[{stamp()}] {event.get('result') or 'done'}\x1b[0m\n"
            )

        return ""

    def _format_codex_event(self, event: dict[str, Any]) -> str:
        """Render one Codex streaming-json event (thread/item/turn lifecycle types)."""
        self._record_model(event)
        event_type = str(event.get("type") or "")
        if event_type == "thread.started":
            session_id = str(event.get("thread_id") or "?")
            return self._session_banner(session_id)

        if event_type == "item.started":
            item = event.get("item") or {}
            if not isinstance(item, dict):
                return ""
            item_type = item.get("type")
            if item_type == "command_execution":
                self._note_tool("Bash", str(item.get("command") or ""))
                return ""
            if item_type == "mcp_tool_call":
                self._note_tool(
                    f"{item.get('server', '')}:{item.get('tool') or item.get('name') or '?'}",
                    _command_text(item.get("arguments") or item.get("input")),
                )
                return ""
            if item_type == "web_search":
                self._note_tool("search", _command_text(item.get("query")))
                return ""
            if item_type == "plan_update":
                return self._emit(f"\x1b[35m[{stamp()} plan]\x1b[0m ")
            return ""

        if event_type == "item.completed":
            item = event.get("item") or {}
            if not isinstance(item, dict):
                return ""
            item_type = item.get("type")
            if item_type == "agent_message":
                text = str(item.get("text") or "")
                return self._emit("\n" + text + "\n") if text else ""
            if item_type == "reasoning":
                text = str(item.get("text") or "")
                return self._emit(f"\x1b[2m{text}\x1b[0m\n") if text else ""
            if item_type == "command_execution":
                output = str(item.get("output") or "")
                return self._emit(_truncate_block(output)) if output else ""
            if item_type == "mcp_tool_call":
                result = item.get("result") or {}
                content = result.get("content") if isinstance(result, dict) else None
                first = content[0] if isinstance(content, list) and content else {}
                output = str(first.get("text") or "") if isinstance(first, dict) else ""
                return self._emit(_truncate_block(output)) if output else ""
            if item_type == "file_changes":
                return self._emit(
                    f"\x1b[32m[{stamp()} write: {item.get('path', '?')}]\x1b[0m\n"
                )
            return ""

        if event_type in {"turn.completed", "turn_completed"}:
            usage = event.get("usage") or {}
            if isinstance(usage, dict):
                self._record_usage(usage)
                cached = usage.get("cached_input_tokens")
                cached_fragment = f" ({cached} cached)" if cached is not None else ""
                return self._emit(
                    f"\n\x1b[2m[{stamp()}] tokens: {usage.get('input_tokens', 0)} in"
                    f"{cached_fragment} / {usage.get('output_tokens', 0)} out\x1b[0m\n"
                )
            return ""

        if event_type in {"turn.failed", "turn_failed"}:
            return self._emit(
                f"\n\x1b[31m[{stamp()} error] {_stringish(event.get('error') or event.get('message') or 'turn failed')}\x1b[0m\n"
            )
        if event_type in {"turn.aborted", "turn_aborted"}:
            return self._emit(
                f"\n\x1b[31m[{stamp()} abort] {_stringish(event.get('message') or event.get('reason') or event.get('error') or 'turn aborted')}\x1b[0m\n"
            )
        return ""

    def _format_gemini_event(self, event: dict[str, Any]) -> str:
        """Render one Gemini streaming-json event, including synthesized token-usage lines."""
        self._record_model(event)
        event_type = str(event.get("type") or "")
        if event_type == "init":
            session_id = str(event.get("session_id") or "?")
            return self._session_banner(session_id)
        if event_type == "gemini":
            out: list[str] = []
            for thought in event.get("thoughts") or []:
                if isinstance(thought, dict):
                    out.append(
                        self._emit(
                            f"\x1b[2m[{stamp()} thinking] {thought.get('subject') or '?'}: {thought.get('description') or ''}\x1b[0m\n"
                        )
                    )
            content = str(event.get("content") or "")
            if content:
                out.append(self._emit(content))
            for call in event.get("toolCalls") or []:
                if isinstance(call, dict):
                    self._note_tool(
                        str(call.get("name") or "?"),
                        _command_text(
                            call.get("args")
                            or call.get("arguments")
                            or call.get("input")
                        ),
                    )
            return "".join(out)
        if event_type == "message" and event.get("role") == "assistant":
            return self._emit(str(event.get("content") or ""))
        if event_type == "tool_use":
            self._note_tool(
                str(event.get("tool_name") or event.get("name") or "?"),
                _command_text(event.get("input") or event.get("arguments")),
            )
            return ""
        if event_type == "tool_result":
            output = str(event.get("output") or "")
            return self._emit(_truncate_block(output)) if output else ""
        if event_type == "error":
            return self._emit(
                f"\x1b[31m[{stamp()} error] {event.get('message') or event.get('error') or 'unknown'}\x1b[0m\n"
            )
        if event_type == "result":
            stats = event.get("stats") or {}
            status_line = (
                f"\n\x1b[32m[{stamp()}] {event.get('status') or 'done'}\x1b[0m\n"
            )
            if not isinstance(stats, dict):
                return self._emit(status_line)
            self._record_usage(stats)
            input_tokens = _as_int(stats.get("input_tokens"))
            output_tokens = _as_int(stats.get("output_tokens"))
            # Render the human-readable token line (same shape as codex/claude)
            # so the regex-based token extractor in spawn.py picks gemini usage
            # up from the transcript; without it research-swarm meta lands at 0.
            if input_tokens or output_tokens:
                cached = stats.get("cached_input_tokens") or stats.get(
                    "cache_read_input_tokens"
                )
                cached_fragment = f" ({_as_int(cached)} cached)" if cached else ""
                tokens_line = (
                    f"\x1b[2m[{stamp()}] tokens: {input_tokens} in"
                    f"{cached_fragment} / {output_tokens} out\x1b[0m\n"
                )
                return self._emit(tokens_line + status_line)
            return self._emit(status_line)
        return ""

    def _format_junie_event(self, event: dict[str, Any]) -> str:
        """Render one Junie streaming-json event's message/step text."""
        # Nested telemetry already walks the top-level ``usage`` dict; a second
        # _record_usage here counted every junie token twice.
        self._record_nested_telemetry(event)
        for key in ("session_id", "sessionId"):
            value = event.get(key)
            if isinstance(value, str) and value:
                self.session_id = value
                break
        message = (
            event.get("message")
            or event.get("text")
            or event.get("content")
            or event.get("details")
            or event.get("data")
        )
        text = _stringish(message)
        if not text or text == "None":
            return ""
        name = _stringish(event.get("name"))
        if name and event.get("type") == "step":
            return self._emit(f"{name}: {text}\n")
        return self._emit(text + "\n")

    def _format_agy_event(self, event: dict[str, Any]) -> str:
        """Render one agy (Antigravity) stream-json event.

        agy speaks ``{"event": ..., "<event>": {...}}``: ``init`` carries
        ``conversation_id`` and the model, ``step_update`` streams
        ``text_delta`` per step (``user_input`` / ``agent_response`` / tool
        steps), ``result`` closes with ``status``, ``response`` and the
        conversation's ``usage``. Usage is recorded once, from ``result``.
        """
        kind = str(event.get("event") or "")
        conversation = event.get("conversation_id")
        if kind == "init":
            init = event.get("init") or {}
            if isinstance(init, dict):
                self._record_model(init)
                conversation = conversation or init.get("conversation_id")
            return self._session_banner(_stringish(conversation) or "?")
        if kind == "step_update":
            step = event.get("step_update") or {}
            if not isinstance(step, dict):
                return ""
            step_type = str(step.get("step_type") or "")
            text = _stringish(step.get("text_delta"))
            if step_type in {"user_input", ""}:
                return ""
            if step_type == "agent_response":
                return self._emit(text) if text else ""
            if step_type in {"thinking", "thought", "planning"}:
                return self._emit(f"\x1b[2m{text}\x1b[0m") if text else ""
            if str(step.get("state") or "") == "ACTIVE" and not text:
                name = step.get("tool_name") or step.get("name") or step_type
                self._note_tool(_stringish(name) or step_type, _command_text(step))
                return ""
            if text:
                return self._emit(_truncate_block(text))
            return ""
        if kind == "result":
            result = event.get("result") or {}
            if not isinstance(result, dict):
                return ""
            usage = result.get("usage")
            status = str(result.get("status") or "done")
            response = _stringish(result.get("response"))
            if response and response != "None":
                self.final_response = response
            out = ""
            if isinstance(usage, dict):
                self._record_usage(usage)
                input_tokens = _as_int(usage.get("input_tokens"))
                output_tokens = _as_int(usage.get("output_tokens"))
                cached = _as_int(usage.get("cache_read_tokens"))
                if input_tokens or output_tokens:
                    cached_fragment = f" ({cached} cached)" if cached else ""
                    out += (
                        f"\n\x1b[2m[{stamp()}] tokens: {input_tokens} in"
                        f"{cached_fragment} / {output_tokens} out\x1b[0m\n"
                    )
            error = _stringish(result.get("error"))
            if error and error != "None":
                out += f"\x1b[31m[{stamp()} error] {error}\x1b[0m\n"
            color = "32" if status.upper() == "SUCCESS" else "31"
            return self._emit(out + f"\x1b[{color}m[{stamp()}] {status}\x1b[0m\n")
        if kind == "error":
            message = event.get("error") or event.get("message")
            return f"\n\x1b[31m[{stamp()} error] {_stringish(message) or 'unknown'}\x1b[0m\n"
        return ""

    def _format_kimi_event(self, event: dict[str, Any]) -> str:
        """Render one kimi stream-json event (assistant/tool/meta; goal.summary).

        kimi 0.42.0 print mode (``kimi -p --output-format stream-json``)
        speaks NDJSON keyed by ``role``: ``assistant`` carries ``content``
        and/or ``tool_calls`` (OpenAI-shaped ``function`` blocks), ``tool``
        carries one tool result, ``meta`` carries ``system.version`` (stream
        head), ``turn.step.retrying`` (provider retries) and
        ``session.resume_hint`` (stream tail — the stream's only session-id
        carrier; live runs adopt the id earlier from the kimi session store
        via ``supervisor_async._adopt_provider_session_identity``).
        Goal runs close with a ``goal.summary`` object. The stream reports no
        usage and no model field, and thinking never reaches the JSONL
        (kimi docs), so the pane shows text, tool tags and the closing
        session banner. The last assistant ``content`` is the final answer.
        """
        role = str(event.get("role") or "")
        if role == "assistant":
            out: list[str] = []
            tool_calls = event.get("tool_calls")
            if isinstance(tool_calls, list):
                for call in tool_calls:
                    if not isinstance(call, dict):
                        continue
                    function = call.get("function")
                    name = (
                        function.get("name")
                        if isinstance(function, dict)
                        else call.get("name")
                    )
                    arguments = (
                        function.get("arguments")
                        if isinstance(function, dict)
                        else call.get("arguments")
                    )
                    self._note_tool(
                        _stringish(name) or "?",
                        _command_text(arguments),
                    )
            content = str(event.get("content") or "")
            if content:
                out.append(self._emit("\n" + content + "\n"))
                self.final_response = content
            return "".join(out)
        if role == "tool":
            output = _stringish(event.get("content"))
            return self._emit(_truncate_block(output)) if output else ""
        if role == "meta":
            meta_type = str(event.get("type") or "")
            if meta_type == "system.version":
                version = str(event.get("version") or "").strip()
                return f"\x1b[2m[{stamp()}] kimi {version}\x1b[0m\n" if version else ""
            if meta_type == "session.resume_hint":
                return self._session_banner(str(event.get("session_id") or ""))
            if meta_type == "turn.step.retrying":
                detail = (
                    _stringish(event.get("error_message"))
                    or _stringish(event.get("error_name"))
                    or "transient provider error"
                )
                next_attempt = _as_int(event.get("next_attempt"))
                max_attempts = _as_int(event.get("max_attempts"))
                attempt = (
                    f" (attempt {next_attempt}/{max_attempts})"
                    if next_attempt and max_attempts
                    else ""
                )
                return f"\x1b[33m[{stamp()} retry]{attempt} {detail}\x1b[0m\n"
            return ""
        if str(event.get("type") or "") == "goal.summary":
            status = str(event.get("status") or "done")
            color = "32" if status == "complete" else "31"
            return f"\n\x1b[{color}m[{stamp()}] goal: {status}\x1b[0m\n"
        return ""

    def _format_grok_event(self, event: dict[str, Any]) -> str:
        """Render one Grok streaming-json event (thought/text/tool/diff/error/message)."""
        self._record_nested_telemetry(event)
        for key in ("session_id", "sessionId", "conversation_id"):
            value = event.get(key)
            if isinstance(value, str) and value:
                self.session_id = value
                break
        event_type = str(event.get("type") or "")
        if event_type == "end":
            value = event.get("sessionId") or event.get("session_id")
            if isinstance(value, str) and value:
                self.session_id = value
            return ""
        if event_type == "thought":
            text = _stringish(event.get("data"))
            return self._emit(f"\x1b[2m{text}\x1b[0m") if text else ""
        if event_type == "text":
            return self._emit(_stringish(event.get("data")))
        if event_type in {"tool", "tool_use", "tool_call"}:
            name = event.get("name") or event.get("tool") or event.get("toolName")
            self._note_tool(
                _stringish(name) or "?",
                _command_text(
                    event.get("input") or event.get("arguments") or event.get("data")
                ),
            )
            return ""
        if event_type == "diff":
            path = _stringish(event.get("path"))
            self._note_tool("diff", path)
            return ""
        if event_type == "error":
            message = event.get("message") or event.get("error") or event.get("data")
            text = _stringish(message)
            return self._emit(
                f"\n\x1b[31m[{stamp()} error] {text or 'unknown'}\x1b[0m\n"
            )

        message = (
            event.get("message")
            or event.get("text")
            or event.get("content")
            or event.get("data")
        )
        text = _stringish(message)
        if not text or text == "None":
            return ""
        return self._emit(text + "\n")


def filter_stream(
    agent: str,
    *,
    stdin=None,
    stdout=None,
    raw_file: str | Path | None = None,
    default_model: str = "",
    last_message_file: str | Path | None = None,
) -> int:
    """Read agent streaming-json from stdin, emit human text to stdout.

    Optional ``raw_file`` tees the unparsed stream for await/transcript parse
    while the pane only sees AgentStreamParser output. Optional
    ``last_message_file`` receives the stream's final assistant answer when
    the agent reports one (agy ``result.response``; kimi's last assistant
    ``content``; omp ``message_end`` text); it is left absent otherwise so
    callers can fall back to the transcript.
    """
    import sys as _sys

    in_stream = stdin if stdin is not None else _sys.stdin.buffer
    out_stream = stdout if stdout is not None else _sys.stdout.buffer
    parser = AgentStreamParser(
        agent, default_model=default_model or resolve_default_model(agent)
    )
    raw_handle = None
    try:
        if raw_file:
            raw_path = Path(raw_file).expanduser()
            raw_path.parent.mkdir(parents=True, exist_ok=True)
            raw_handle = raw_path.open("ab")
        while True:
            chunk = in_stream.readline()
            if not chunk:
                break
            if raw_handle is not None:
                raw_handle.write(chunk)
                raw_handle.flush()
            display = parser.feed_line(chunk)
            if display:
                out_stream.write(display.encode("utf-8"))
                out_stream.flush()
        tail = parser.flush_tool_burst()
        if tail:
            out_stream.write(tail.encode("utf-8"))
            out_stream.flush()
    finally:
        if raw_handle is not None:
            raw_handle.close()
    if last_message_file and parser.final_response.strip():
        last_path = Path(last_message_file).expanduser()
        last_path.parent.mkdir(parents=True, exist_ok=True)
        last_path.write_text(parser.final_response, encoding="utf-8")
    return 0


def main(argv: Sequence[str] | None = None) -> int:
    """CLI: ``python -m vibecrafted_core.agent_stream --agent grok``."""
    import argparse
    import sys

    parser = argparse.ArgumentParser(
        prog="vibecrafted_core.agent_stream",
        description=(
            "Filter agent streaming-json (stdin) into human-readable pane text "
            "(stdout). Used by non-interactive resume and worker pane launches."
        ),
    )
    parser.add_argument(
        "--agent",
        required=True,
        help="Agent family: grok, claude, codex, gemini, junie, agy, kimi, copilot, omp",
    )
    parser.add_argument(
        "--raw-file",
        default="",
        help="Optional path to tee the raw streaming-json transcript",
    )
    parser.add_argument(
        "--model",
        default="",
        help="Optional default model id for telemetry lines",
    )
    parser.add_argument(
        "--last-message",
        default="",
        help="Optional path that receives the stream's final assistant answer (agy result.response, kimi's last assistant content)",
    )
    args = parser.parse_args(list(argv) if argv is not None else None)
    agent = str(args.agent or "").strip().lower()
    if not agent:
        print("error: --agent is required", file=sys.stderr)
        return 2
    return filter_stream(
        agent,
        raw_file=args.raw_file or None,
        default_model=str(args.model or ""),
        last_message_file=(str(args.last_message).strip() or None),
    )


if __name__ == "__main__":
    raise SystemExit(main())
