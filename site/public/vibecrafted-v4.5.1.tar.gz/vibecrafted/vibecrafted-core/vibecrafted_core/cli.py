"""Vibecrafted core entrypoint: routes ``vibecrafted``/shell-wrapper argv to the
Python launch/observe/await surface or falls back to the legacy bash deck."""

from __future__ import annotations

import argparse
import json
import os
import stat
import subprocess
import sys
import time
from collections.abc import Sequence
from pathlib import Path
from typing import Any

from . import doctor as doctor_module
from .agent_stream import ANSI_PATTERN, AgentStreamParser, resolve_default_model
from .control_plane import (
    RunNotResolved,
    lookup_run,
    resolve_run,
    sync_state,
)
from .help_surface import AGENT_SELECTOR, CORE_SURFACE_COMMANDS
from .package_resources import deck_path, package_root
from .repo_selection import (
    RepoSelectionError,
    add_repo_arguments,
    parse_worktree_flag,
    select_repository,
)
from .runtime_paths import is_operator_home_root, resolve_operator_launch_root
from .server_observation import (
    ServerObservationError,
)
from .server_observation import (
    await_run as await_run_from_server,
)
from .server_observation import (
    observe_run as observe_run_from_server,
)
from .server_observation import (
    resolve_run_id as resolve_server_run_id,
)
from .telemetry import is_unknown, run_telemetry_from_meta, unknown_reason
from .usage_reporting import UsageReportQueryError, build_usage_report
from .workflow import (
    classify_resume_identity,
    find_run_for_identity_token,
    launch_workflow,
    looks_like_control_plane_run_id,
    manual_resume_session,
    normalize_launch_spec,
    operator_continue_run,
    read_prompt_stream,
    recover_launch_receipt,
    resolve_fork_source,
    resolve_session_selection,
)

AGENTS = {
    "claude",
    "codex",
    "agy",
    "junie",
    "grok",
    "cursor",
    "kimi",
    "copilot",
    "omp",
    "swarm",
}
RESEARCH_ARITY = {"uno": 1, "duo": 2, "trio": 3}
LAUNCHERS = (
    "audit",
    "canary",
    "decorate",
    "delegate",
    "dou",
    "followup",
    "hydrate",
    "implement",
    "intents",
    "justdo",
    "marbles",
    "ownership",
    "partner",
    "paste",
    "polarize",
    "prune",
    "release",
    "research",
    "review",
    "scaffold",
    "trust",
    "guard",
    "workflow",
)
# No skill aliases: each LAUNCHERS name is its own skill id (ADR-0001: justdo
# is not implement). Keep the map only for legacy shell-wrapper renames if any.
LAUNCH_ALIASES: dict[str, str] = {}
# These installed names are symlinks to the ``vibecrafted`` Python entrypoint,
# but their behavior is still owned by the shell deck. Preserve the invoked
# name as an explicit deck verb instead of silently treating the first user
# argument as the command.
SHELL_WRAPPER_VERBS = {
    "telemetry": "telemetry",
    "vc-await": "await",
    "vc-canary": "canary",
    "vc-capabilities": "capabilities",
    "vc-claims": "claims",
    "vc-dashboard": "dashboard",
    "vc-dispatch": "dispatch",
    "vc-doctor": "doctor",
    "vc-fork": "fork",
    "vc-help": "help",
    "vc-init": "init",
    "vc-justdo": "justdo",
    "vc-message": "message",
    "vc-observe": "observe",
    "vc-operator": "operator",
    "vc-receipt": "receipt",
    "vc-reinstall": "reinstall",
    "vc-resume": "resume",
    "vc-resume-session": "resume-session",
    "vc-scaffold-doctor": "scaffold-doctor",
    "vc-settlements": "settlements",
    "vc-start": "start",
    "vc-status": "status",
    "vc-stop": "stop",
    "vc-uninstall": "uninstall",
    "vc-update": "update",
    "vc-workspace": "workspace",
}
SUCCESS_STATES = {"report_validated", "completed", "closed"}
TERMINAL_STATES = {
    "blocked",
    "closed",
    "completed",
    "contract_failed",
    "failed",
    "ghost",
    "report_invalid",
    "report_missing",
    "report_validated",
    "stopped",
    "timed_out",
}
_INSTALLER_LEASE_FD_ENV = "VIBECRAFTED_INSTALL_LEASE_FD"
_INSTALLER_LOCK_NAME = ".vibecrafted-install.lock"
_EX_TEMPFAIL = 75


def python_owned_commands() -> frozenset[str]:
    """Commands ``cli.main`` keeps instead of delegating to the shell deck.

    ``CORE_SURFACE_COMMANDS`` is the compact-help subset the deck must also
    route. Internal verbs (fork-source, acp, …) stay here and unpublished.
    """
    return frozenset(
        {
            "acp",
            "capabilities",
            "config",
            "control-plane-revalidate",
            "dispatch",
            "doctor",
            "fork-source",
            "fork-session",
            "paste",
            "procs",
            "reap",
            "receipt",
            "reinstall",
            "session-source",
            "settle",
            "ship",
            "stop",
            "usage",
        }
        | set(LAUNCHERS)
        | set(CORE_SURFACE_COMMANDS)
    )


def _invoke_owned_main(main_fn: Any, argv: Sequence[str]) -> int:
    """Run an owned argparse/main that may raise ``SystemExit`` on ``--help``."""
    try:
        result = main_fn(list(argv))
    except SystemExit as exc:
        code = exc.code
        if code is None:
            return 0
        if isinstance(code, int):
            return code
        return 1
    return int(result or 0)


def _render_core_surface_help(topic: str) -> int:
    """Render ``help <core-surface-verb>`` from the verb's owner."""
    from .help_surface import render_message_help, render_resume_session_help

    if topic == "resume-session":
        print(render_resume_session_help(), end="")
        return 0
    if topic == "message":
        print(render_message_help(), end="")
        return 0
    if topic == "relocate":
        from .relocate import main as relocate_main

        return _invoke_owned_main(relocate_main, ["--help"])
    if topic == "reinstall":
        from .reinstall_clean import main as reinstall_main

        return _invoke_owned_main(reinstall_main, ["--help"])
    if topic == "claims":
        from .repository_claims import claims_cli_main

        return _invoke_owned_main(claims_cli_main, ["--help"])
    if topic == "pr-closure":
        from .pr_closure import main as pr_closure_main

        return _invoke_owned_main(pr_closure_main, ["--help"])
    if topic == "settlements":
        parser = _build_parser()
        return _invoke_owned_main(
            lambda argv: parser.parse_args(argv) or 0, ["settlements", "--help"]
        )
    raise ValueError(f"unsupported core surface help topic: {topic}")


def _normalize_research_arity_args(args: Sequence[str]) -> list[str]:
    """Expand the stable uno/duo/trio contract before argparse sees agents.

    Omitting these keywords leaves YAML ``lanes`` / ``lane_count`` in charge,
    including four-agent rosters. The keywords only pin exact positional arity.
    """
    normalized = list(args)
    if len(normalized) < 2 or normalized[0] != "research":
        return normalized
    keyword = normalized[1]
    expected = RESEARCH_ARITY.get(keyword)
    if expected is None:
        return normalized

    agents: list[str] = []
    cursor = 2
    while cursor < len(normalized) and not normalized[cursor].startswith("-"):
        agents.append(normalized[cursor])
        cursor += 1
    if len(agents) != expected:
        raise ValueError(
            f"{keyword} expects exactly {expected} agent(s), got {len(agents)}"
        )
    unsupported = [agent for agent in agents if agent not in AGENTS - {"swarm"}]
    if unsupported:
        raise ValueError(f"Unsupported research agent: {unsupported[0]}")
    return ["research", *agents, *normalized[cursor:]]


def _installer_lease_pass_fds(tools_home: Path) -> tuple[int, ...]:
    """Validate an inherited installer coordination fd and return it to pass through.

    Returns an empty tuple when no lease fd is present. Raises ``OSError`` if the
    fd is set but does not verifiably own ``tools_home``'s install lock file
    (regular file, same uid, single hardlink, same device/inode) — a forged or
    stale descriptor must never be forwarded to the deck subprocess.
    """
    raw_descriptor = os.environ.get(_INSTALLER_LEASE_FD_ENV)
    if not raw_descriptor:
        return ()
    if os.name != "posix":
        raise OSError("installer coordination descriptors require POSIX")
    try:
        descriptor = int(raw_descriptor)
    except ValueError as exc:
        raise OSError("invalid installer coordination descriptor") from exc
    if descriptor < 0:
        raise OSError("invalid installer coordination descriptor")

    lock_path = tools_home.resolve(strict=False) / _INSTALLER_LOCK_NAME
    try:
        opened = os.fstat(descriptor)
        named = os.stat(lock_path, follow_symlinks=False)
    except OSError as exc:
        raise OSError(
            f"installer coordination lease is unavailable at {lock_path}"
        ) from exc
    if (
        not stat.S_ISREG(opened.st_mode)
        or not stat.S_ISREG(named.st_mode)
        or opened.st_uid != os.geteuid()
        or named.st_uid != os.geteuid()
        or opened.st_nlink != 1
        or named.st_nlink != 1
        or (opened.st_dev, opened.st_ino) != (named.st_dev, named.st_ino)
    ):
        raise OSError(f"installer coordination descriptor does not own {lock_path}")
    return (descriptor,)


def _add_launch_parser(sub: argparse._SubParsersAction, name: str) -> None:
    """Register one LAUNCHERS subcommand with its shared and per-skill flags."""
    run = sub.add_parser(name, help=f"launch vc-{name} through core runtime")
    if name == "research":
        run.add_argument("agent", nargs="*")
    else:
        run.add_argument("agent", nargs="?")
    if name == "paste":
        run.add_argument("--skill", default="workflow")
        add_repo_arguments(run)
        run.add_argument("--print-prompt", action="store_true")
        run.add_argument("--dry-run", action="store_true")
        run.add_argument("--json", action="store_true")
        return
    run.add_argument("-p", "--prompt", default=None)
    run.add_argument("-f", "--file", default="")
    run.add_argument(
        "--prompt-stdin",
        action="store_true",
        help="read the prompt from stdin and keep it out of argv/temp files",
    )
    run.add_argument(
        "--runtime", default="", help="presentation: headless, visible or terminal"
    )
    run.add_argument(
        "--execution-runtime", choices=["living-tree", "local-worktrees"], default=""
    )
    run.add_argument("--base", default="")
    add_repo_arguments(run)
    run.add_argument(
        "--worktree",
        nargs="?",
        const="true",
        default="",
        metavar="true|false",
        help="run the worker in a fresh linked checkout of the selected repository",
    )
    run.add_argument(
        "--permissions",
        default="",
        metavar="bypass|auto|accept-edits|read-only",
        help=(
            "permission policy enforced by the agent's own CLI "
            "(default: durable per-agent, then global config, else auto; bypass "
            "only when selected); refused before launch when the installed CLI "
            "cannot enforce it"
        ),
    )
    run.add_argument(
        "--sandbox",
        nargs="?",
        const="true",
        default="",
        metavar="true|false",
        help=(
            "require (true) or refuse (false) the agent CLI's own sandbox; "
            "refused before launch when the installed CLI cannot enforce it"
        ),
    )
    run.add_argument(
        "--remediate-trust-block",
        action="store_true",
        help=(
            "Founder-authorized continuation on a recorded trust BLOCK; "
            "does not rewrite the journal or report PASS"
        ),
    )
    run.add_argument(
        "--remediation-reason",
        default="",
        help="Required with --remediate-trust-block; recorded on the launch receipt",
    )
    run.add_argument(
        "--remediation-task",
        default="",
        metavar="repair|admission",
        help="Bounded task identity for --remediate-trust-block (repair or admission)",
    )
    run.add_argument("--mode", default="")
    run.add_argument("--count", type=int)
    run.add_argument("--depth", type=int)
    run.add_argument("--model", default=None)
    run.add_argument(
        "--effort",
        default="",
        metavar="low|medium|high|…",
        help=(
            "reasoning-effort pin carried to the agent CLI (claude, agy, "
            "junie, grok; codex via -c model_reasoning_effort). Effort is a "
            "cost control: without a pin the provider CLI picks its own "
            "default. Agents without an effort control record a receipted "
            "skip instead of refusing the launch."
        ),
    )
    run.add_argument(
        "--mcp-config",
        default="",
        metavar="PATH.json",
        help=(
            "strict MCP profile: expose only its mcpServers; freeze it for "
            "native continuations (supported direct agent workflows only)"
        ),
    )
    run.add_argument(
        "--session",
        default="",
        help=(
            "continue this provider-native session (id|current|last); "
            "never a control-plane run id"
        ),
    )
    if name == "research":
        run.add_argument("--synthesizer", default="")
        run.add_argument("--synthesizer-model", default="")
    run.add_argument(
        "--await",
        dest="await_completion",
        action="store_true",
        help="emit the receipt, then wait for the run and return its result",
    )
    run.add_argument("--source-dir", default="")
    run.add_argument("--json", action="store_true")


def _build_parser() -> argparse.ArgumentParser:
    """Assemble the full argparse tree for every python-owned subcommand."""
    parser = argparse.ArgumentParser(
        prog="vibecrafted",
        description="Vibecrafted core command surface.",
    )
    sub = parser.add_subparsers(dest="command")
    sub.add_parser("dispatch", help="run or validate a dispatch plan")
    ship = sub.add_parser(
        "ship",
        help="lifecycle launcher, DeliverySeal issuer, and roadmap projection",
    )
    ship.add_argument(
        "ship_argv",
        nargs=argparse.REMAINDER,
        help="ship subcommand args (see vibecrafted ship --help / vc-ship)",
    )
    claims = sub.add_parser("claims", help="atomic local repository-mutation claims")
    claims.add_argument(
        "claims_argv",
        nargs=argparse.REMAINDER,
        help="claims subcommand args (see vibecrafted claims --help)",
    )
    revalidate = sub.add_parser("control-plane-revalidate", help=argparse.SUPPRESS)
    revalidate.add_argument("--run-id", required=True)
    revalidate.add_argument("--json", action="store_true")
    doctor = sub.add_parser("doctor", help="verify installed Vibecrafted runtime")
    doctor.add_argument("--json", action="store_true")
    doctor.add_argument(
        "--verbose",
        action="store_true",
        help="list every passing check too; the default shows the verdict and problems only",
    )
    doctor.add_argument(
        "--release",
        action="store_true",
        help=(
            "probe GitHub Latest (gh release view --json tagName) and the "
            "latest Release source gate conclusion against the local VERSION "
            "file; mismatch is red and names the tag/publish operator button"
        ),
    )
    doctor.add_argument(
        "--quarantine-legacy-runs",
        action="store_true",
        help=(
            "one-shot migration: mark terminal runs without worker_pgid as "
            "reaper_ownership=legacy; best-effort recover pgid for live runs "
            "only when SPAWN_RUN_ID is positively visible"
        ),
    )
    receipt = sub.add_parser(
        "receipt",
        help=(
            "delivery/runtime receipt for fleet tools "
            "(source ↔ installed chain; never guesses from cwd)"
        ),
    )
    receipt.add_argument(
        "--json",
        action="store_true",
        help="machine-readable vibecrafted.delivery_receipt.v1",
    )
    capabilities = sub.add_parser(
        "capabilities",
        help="describe workflow execution contracts (versioned, machine-readable)",
    )
    capabilities.add_argument("--json", action="store_true")
    config = sub.add_parser(
        "config",
        help="product configuration ownership and explicit shell onboarding",
    )
    config_sub = config.add_subparsers(dest="config_action")
    config_sub.add_parser(
        "install",
        help="retired: repair the verified Runtime Pack with make install",
    )
    config_zshrc = config_sub.add_parser(
        "ensure-zshrc",
        help="idempotent host ~/.zshrc onboarding (create or fenced append)",
    )
    config_zshrc.add_argument("--dry-run", action="store_true")
    reap = sub.add_parser(
        "reap",
        help="terminate processes that outlived their run (survivors of terminal runs)",
    )
    reap.add_argument(
        "--dry-run",
        action="store_true",
        help="print the would-kill table with ownership evidence, signal nothing",
    )
    reap.add_argument("--json", action="store_true")
    reap.add_argument(
        "--resettle",
        action="store_true",
        help=(
            "re-run settlement over retained control_plane/runs snapshots "
            "(honest: automatic FINALIZED only from a sealed delivery or an "
            "explicit worker attestation; a traced operator waive remains an "
            "override; never from bare exit 0)"
        ),
    )
    settle = sub.add_parser(
        "settle",
        help="settlement board maintenance (resettle retained snapshots)",
    )
    settle.add_argument(
        "--resettle",
        action="store_true",
        help="re-classify retained snapshots from existing axes (no invented f)",
    )
    settle.add_argument(
        "--dry-run",
        action="store_true",
        help="count would-rewrite only; do not write snapshots",
    )
    settle.add_argument("--json", action="store_true")
    workspace = sub.add_parser(
        "workspace",
        help=(
            "canonical Vibecrafted Workspace catalog "
            "(create|list|select|show|bury|recover|migrate|materialize|"
            "settlement-counts)"
        ),
    )
    workspace.add_argument(
        "workspace_argv",
        nargs=argparse.REMAINDER,
        help="workspace subcommand args (see vibecrafted workspace --help)",
    )
    settlements = sub.add_parser(
        "settlements",
        help=(
            "read-only settlement ledger query "
            "(summary | list | inspect); never invents f"
        ),
    )
    settlements_sub = settlements.add_subparsers(dest="settlements_action")
    settlements_summary = settlements_sub.add_parser(
        "summary",
        help="durable f/x/n lower-bound plus revalidation inventory",
    )
    settlements_summary.add_argument("--json", action="store_true")
    settlements_summary.add_argument(
        "--workspace-id",
        default="",
        help="scope f/x/n projection to one workspace_id (Cut A)",
    )
    settlements_list = settlements_sub.add_parser(
        "list",
        help="list or group latest-by-run settlements",
    )
    settlements_list.add_argument(
        "--bucket",
        choices=("f", "x", "n"),
        help="filter to TUI bucket f, x, or n",
    )
    settlements_list.add_argument(
        "--revalidatable",
        action="store_true",
        help="only runs with report+transcript still on disk",
    )
    settlements_list.add_argument(
        "--group",
        default="",
        help="comma-separated fields: agent,skill,reason,root,state,verdict",
    )
    settlements_list.add_argument("--limit", type=int, default=None)
    settlements_list.add_argument("--json", action="store_true")
    settlements_inspect = settlements_sub.add_parser(
        "inspect",
        help="inspect one run_id from the ledger + control-plane enrichment",
    )
    settlements_inspect.add_argument("run_id")
    settlements_inspect.add_argument("--json", action="store_true")
    procs = sub.add_parser(
        "procs",
        help="identity-qualified process snapshot/terminate for vc-procs TUI",
    )
    procs_sub = procs.add_subparsers(dest="procs_action")
    procs_sub.add_parser("snapshot", help="JSON process snapshot")
    term = procs_sub.add_parser("terminate", help="TERM→KILL with identity proof")
    term.add_argument("--pid", type=int, required=True)
    term.add_argument("--expected-start", required=True)
    term.add_argument("--expected-command-sha256", required=True)
    term.add_argument("--expected-run-id", default="")
    resume = sub.add_parser(
        "resume-session",
        help="continue one explicit provider session as a tracked headless run",
    )
    resume.add_argument(
        "agent",
        choices=sorted(AGENTS - {"swarm"}),
        help="provider owning the explicit session id",
    )
    resume.add_argument("--agent-session-id", required=True)
    prompt_input = resume.add_mutually_exclusive_group(required=True)
    prompt_input.add_argument("-p", "--prompt", default="")
    prompt_input.add_argument("-f", "--prompt-file", default="")
    prompt_input.add_argument(
        "--prompt-stdin",
        action="store_true",
        help="read the continuation prompt from stdin (keeps it out of argv)",
    )
    add_repo_arguments(resume)
    resume.add_argument("--source-dir", default="")
    resume.add_argument("--model", default=None)
    resume.add_argument(
        "--permissions",
        default="",
        metavar="bypass|auto|accept-edits|read-only",
        help="current explicit policy; omitted inherits the session's admitted one",
    )
    resume.add_argument(
        "--sandbox",
        nargs="?",
        const="true",
        default="",
        metavar="true|false",
        help="current explicit sandbox; omitted inherits the session's admitted one",
    )
    resume.add_argument("--json", action="store_true")
    fork_source = sub.add_parser(
        "fork-source",
        help="resolve the provider session a `vibecrafted fork` branches from",
    )
    fork_source.add_argument(
        "agent",
        choices=sorted(AGENTS - {"swarm"}),
        help="provider that owns the source session",
    )
    fork_source.add_argument("--run-id", default="")
    fork_source.add_argument("--session", default="")
    fork_source.add_argument("--json", action="store_true")
    fork_source.add_argument("--root", default="")
    session_source = sub.add_parser(
        "session-source", help="resolve shared provider session selector"
    )
    session_source.add_argument("agent", choices=sorted(AGENTS - {"swarm"}))
    session_source.add_argument("--session", required=True)
    session_source.add_argument("--root", required=True)
    session_source.add_argument("--id-only", action="store_true")
    session_source.add_argument("--infer-recorded-root", action="store_true")
    session_source.add_argument("--session-selection", type=json.loads, default=None)
    task_fork = sub.add_parser("fork-session", help="tracked native task fork")
    task_fork.add_argument("agent", choices=sorted(AGENTS - {"swarm"}))
    task_fork.add_argument("--session", required=True)
    task_fork.add_argument("--session-selection", type=json.loads, default=None)
    task_fork.add_argument("--parent-run-id", default="")
    task_fork.add_argument("--root", required=True)
    task_fork.add_argument("--model", default=None)
    task_fork.add_argument("--base", default="")
    task_fork.add_argument("--permissions", default="")
    task_fork.add_argument("--worktree", default=None)
    task_fork.add_argument("--execution-runtime", default="")
    task_fork.add_argument("--source-dir", default="")
    inputs = task_fork.add_mutually_exclusive_group(required=True)
    inputs.add_argument("--file", default="")
    inputs.add_argument("--prompt-stdin", action="store_true")
    message = sub.add_parser(
        "message",
        help="persist and inspect run-addressed provider steering receipts",
    )
    message.add_argument("--run-id", default="")
    message.add_argument(
        "--connect-container",
        action="store_true",
        help="host recovery: reconnect an existing live container run; serve its inbox until interrupted or the owner exits",
    )
    message.add_argument(
        "--session", default="", help="exact recorded runtime or provider session ID"
    )
    message.add_argument("--file", default="", help="UTF-8 message body file")
    message.add_argument(
        "--receive",
        action="store_true",
        help="recipient checkpoint: read unacknowledged inbox and queue messages; inspect attached receipts by id",
    )
    message.add_argument(
        "--ack", metavar="MESSAGE_ID", default="", help="acknowledge one inbox message"
    )
    message.add_argument("--idempotency-key", default="")
    message.add_argument(
        "--retry",
        action="store_true",
        help=(
            "retry only an unresolved or failed receipt; "
            "provider_accepted is never resubmitted"
        ),
    )
    message.add_argument(
        "--inspect",
        metavar="MESSAGE_ID",
        default="",
        help="read one durable provider-message receipt",
    )
    message.add_argument(
        "--mark-context-injected",
        metavar="MESSAGE_ID",
        default="",
        help="record that one inbox receipt was attached to a tool response",
    )
    message.add_argument(
        "--nonce",
        default="",
        help="injection nonce stored with context_injected",
    )
    message.add_argument("--json", action="store_true")
    for name in LAUNCHERS:
        _add_launch_parser(sub, name)
    return parser


def _default_runtime(explicit_runtime: str, root: str = "") -> str:
    """Resolve launch surface: explicit presentation or headless.

    DELIBERATE REVERSAL of 141a19d / 3d794af (July 2026): those commits made
    dispatched workers prefer a visible ``terminal`` tab — either by
    inheriting an in-frame session env (``VC_FRAME_SESSION_NAME`` /
    ``ZELLIJ_SESSION_NAME``) or by discovering a live repo-bound vc-frame
    session — because headless dispatch left the operator blind. That
    visibility gap is now closed by the LIVE bucket viewer opened alongside
    every headless launch (see the ``Live runs`` bucket wiring / commit
    7be422aa, cut c1-live-bucket-viewer): the operator watches a
    ``tail -F``/``observe`` viewer tab instead of the worker itself owning a
    pane. Do NOT restore the env/live-session branches as a "fix" — that
    would resurrect worker tabs landing in the operator's own session
    (the exact bug Cut A / c1 closed). ``root`` is kept in the signature for
    call-site compatibility even though this function no longer consults it.
    """
    runtime = str(explicit_runtime or "").strip()
    if runtime:
        return runtime
    return "headless"


def _argv_names_stopped_run(argv: Sequence[str]) -> bool:
    """True when argv names a control-plane run (``--run-id`` / ``--last``)."""
    return any(
        token == "--last" or token == "--run-id" or token.startswith("--run-id=")
        for token in argv
    )


def _normalize_raw_args(raw_args: list[str]) -> list[str]:
    """Canonicalize leading pairs so later dispatch sees one shape.

    ``<agent> <launcher>`` becomes ``<launcher> <agent>``.
    ``resume <agent> --run-id|--last`` becomes ``<agent> resume …`` so the
    stopped-run flag is not delegated to the deck (which historically had no
    ``--run-id`` and swallowed it) or to ``_build_parser`` (no ``resume``
    subcommand). ``--session`` / bare resume stay resume-first for the deck.
    """
    if len(raw_args) >= 2 and raw_args[0] in AGENTS and raw_args[1] in LAUNCHERS:
        return [raw_args[1], raw_args[0], *raw_args[2:]]
    if (
        len(raw_args) >= 2
        and raw_args[0] == "resume"
        and raw_args[1] in AGENTS
        and _argv_names_stopped_run(raw_args[2:])
    ):
        return [raw_args[1], "resume", *raw_args[2:]]
    return raw_args


def _field(payload: dict[str, Any], name: str, default: str = "") -> str:
    """Coerce a payload value to ``str``, substituting ``default`` when falsy."""
    return str(payload.get(name) or default)


def _clip_line(line: str, *, max_chars: int = 500) -> str:
    """Truncate a display line to ``max_chars``, appending an ellipsis when cut."""
    if len(line) <= max_chars:
        return line
    return line[: max_chars - 1] + "…"


# Per-token streamers (grok emits one JSON event per token, e.g.
# {"type":"thought","data":"Good"}) render to far fewer lines than raw events:
# whole sentences coalesce into a single rendered line. Cutting the raw tail to
# `max_lines` BEFORE rendering would leave ~40 tokens (~1.5 sentences) of
# visibility, so we feed the parser a much wider raw tail and window to
# `max_lines` only AFTER rendering. 2000 raw lines comfortably covers 40
# rendered lines even at one-token-per-event rates while capping the
# render-feed cost on huge transcripts.
RAW_TAIL_LINES = 2000
# Default one-shot window for ``observe --tail`` / ``--head`` when the count
# is omitted (the historical observe tail size).
OBSERVE_WINDOW_LINES = 40


def _read_transcript_lines(path: str) -> tuple[list[str] | None, str]:
    """Read a transcript into raw lines. ``(None, error_code)`` on failure."""
    if not path:
        return None, "missing_path"
    transcript = Path(path).expanduser()
    try:
        if not transcript.is_file():
            return None, "missing_file"
        lines = transcript.read_text(encoding="utf-8", errors="replace").splitlines()
    except OSError as exc:
        return None, f"read_error:{type(exc).__name__}"
    if not lines:
        return None, "empty"
    return lines, ""


def _render_agent_lines(lines: list[str], agent: str) -> tuple[list[str], bool]:
    """Render raw transcript lines through the agent's stream parser.

    Returns the rendered lines (coalesced, ANSI-stripped, clipped, blanks
    dropped) plus whether any JSON event line was seen — so callers can tell
    "plain text, pass it through raw" apart from "JSON with no renderable
    events".
    """
    parser = AgentStreamParser(agent, default_model=resolve_default_model(agent))
    chunks: list[str] = []
    saw_json = False
    for line in lines:
        if line.lstrip().startswith("{"):
            saw_json = True
        chunks.append(parser.feed_line((line + "\n").encode("utf-8")))
    # Coalesce first: parser fragments without trailing newlines (grok thought
    # tokens) must merge into full lines before any windowing happens.
    rendered: list[str] = []
    for rendered_line in "".join(chunks).splitlines():
        clean = rendered_line.strip()
        if clean and ANSI_PATTERN.sub("", clean).strip():
            rendered.append(_clip_line(clean))
    return rendered, saw_json


def _tail_lines(
    path: str, *, agent: str = "", max_lines: int = 40
) -> tuple[list[str], str]:
    """Return the last ``max_lines`` of a transcript, rendered through the agent's
    stream parser when ``agent`` is given. Second element is an error code
    (``""`` on success) rather than a raised exception."""
    lines, error = _read_transcript_lines(path)
    if lines is None:
        return [], error
    if not agent:
        return [_clip_line(line) for line in lines[-max_lines:]], ""
    rendered, saw_json = _render_agent_lines(lines[-RAW_TAIL_LINES:], agent)
    if rendered:
        return rendered[-max_lines:], ""
    if saw_json:
        return [], "no_renderable_events"
    return [_clip_line(line) for line in lines[-max_lines:]], ""


def _head_lines(
    path: str, *, agent: str = "", max_lines: int = 40
) -> tuple[list[str], str]:
    """Return the first ``max_lines`` of a transcript — the ``_tail_lines``
    mirror. The agent-aware path renders a bounded raw head window (first
    ``RAW_TAIL_LINES`` raw lines) and windows to ``max_lines`` only AFTER
    rendering, so per-token streams still coalesce. Error codes match
    ``_tail_lines``."""
    lines, error = _read_transcript_lines(path)
    if lines is None:
        return [], error
    if not agent:
        return [_clip_line(line) for line in lines[:max_lines]], ""
    rendered, saw_json = _render_agent_lines(lines[:RAW_TAIL_LINES], agent)
    if rendered:
        return rendered[:max_lines], ""
    if saw_json:
        return [], "no_renderable_events"
    return [_clip_line(line) for line in lines[:max_lines]], ""


def _run_succeeded(run: dict[str, Any]) -> bool:
    """True when the run reached a success state with a clean artifact gate."""
    state = str(run.get("state") or "")
    errors = [str(item) for item in (run.get("artifact_errors") or []) if str(item)]
    return (
        state in SUCCESS_STATES and run.get("artifact_ok") is not False and not errors
    )


def _run_terminal(run: dict[str, Any]) -> bool:
    """True when the run's state, liveness, or exit code marks it finished."""
    if str(run.get("state") or "") in TERMINAL_STATES:
        return True
    if str(run.get("liveness") or "") == "terminal":
        return True
    return run.get("exit_code") is not None


def _print_launch_receipt(payload: dict[str, Any]) -> None:
    """Print the human-readable launch receipt block for a freshly spawned run."""
    run_id = _field(payload, "run_id")
    agent = _field(payload, "agent")
    print("==================== VIBECRAFTED LAUNCH RECEIPT ====================")
    print(f"run_id:     {run_id}")
    print(f"agent:      {agent}")
    print(f"skill:      {_field(payload, 'skill')}")
    print(f"root:       {_field(payload, 'root')}")
    for key in (
        "repo_requested",
        "repo_kind",
        "base_requested",
        "resolved_ref",
        "baseline_sha",
        "runtime_class",
        "presentation",
        "model_requested",
        "model_source",
    ):
        if payload.get(key):
            print(f"{key}: {payload[key]}")
    if payload.get("worktree"):
        print(f"worktree:   {_field(payload, 'worktree_branch')}")
        print(f"parent:     {_field(payload, 'parent_root')}")
        print(f"baseline:   {_field(payload, 'worktree_baseline_sha')}")
    controls = payload.get("execution_controls")
    if isinstance(controls, dict):
        requested = str(controls.get("permissions_requested") or "") or "(default)"
        print(
            f"permissions: {controls.get('permissions_effective', '')}"
            f"  (requested: {requested})"
        )
        sandbox_requested = str(controls.get("sandbox_requested") or "") or "(default)"
        print(
            f"sandbox:    {controls.get('sandbox_effective', '')}"
            f"  (requested: {sandbox_requested})"
        )
    guard_info = payload.get("guard")
    if isinstance(guard_info, dict) and guard_info:
        print(
            f"guard:      {guard_info.get('continuation', '')}"
            f"  (trust {guard_info.get('blocking_verdict') or 'unchanged'}"
            f" {str(guard_info.get('blocking_sha') or '')[:12]})"
        )
        if guard_info.get("remediation_task"):
            print(f"remediation-task: {guard_info.get('remediation_task')}")
        if guard_info.get("remediation_reason"):
            print(f"remediation-reason: {guard_info.get('remediation_reason')}")
    print(f"dispatch:   {_field(payload, 'dispatch', '0')}")
    print(f"status:     {_field(payload, 'status', 'launching')}")
    reasons = _launch_receipt_reasons(payload)
    if reasons:
        print(f"reasons:    {'; '.join(reasons)}")
    print(f"control:    {_field(payload, 'control')}")
    print(f"report:     {_field(payload, 'report')}")
    print(f"transcript: {_field(payload, 'transcript')}")
    print(f"observe:    vibecrafted observe {agent} --run-id {run_id}")
    print(
        f"await (ARM NOW, supervisor-side): vibecrafted await {agent} --run-id {run_id}"
    )
    print("=====================================================================")


def _emit_launch_result(
    result: dict[str, Any], *, json_mode: bool, await_completion: bool = False
) -> int:
    """Write exactly one launch receipt to stdout. Never exit 0 on empty stdout.

    Diagnostics go to stderr. A run that already mutated control-plane state
    must still emit ``run_id`` so a retry can resolve it instead of guessing.
    """
    from .workflow import _json_plain, machine_launch_receipt

    receipt = machine_launch_receipt(result)
    run_id = str(receipt.get("run_id") or "")
    if json_mode:
        payload = _json_plain(result)
        if not isinstance(payload, dict):
            payload = {}
        payload.update(receipt)
        try:
            text = json.dumps(
                payload, ensure_ascii=False, indent=None if await_completion else 2
            )
        except (TypeError, ValueError):
            text = json.dumps(
                receipt, ensure_ascii=False, indent=None if await_completion else 2
            )
        if not str(text).strip():
            print("error: launch produced an empty receipt", file=sys.stderr)
            if run_id:
                print(f"run_id: {run_id}", file=sys.stderr)
            return _EX_TEMPFAIL if run_id else 1
        try:
            sys.stdout.write(text if text.endswith("\n") else f"{text}\n")
            sys.stdout.flush()
        except BrokenPipeError:
            print(
                f"error: stdout closed after launch; run_id={run_id or 'unknown'}",
                file=sys.stderr,
            )
            return _EX_TEMPFAIL if run_id else 1
    else:
        try:
            _print_launch_receipt(result)
            sys.stdout.flush()
        except BrokenPipeError:
            print(
                f"error: stdout closed after launch; run_id={run_id or 'unknown'}",
                file=sys.stderr,
            )
            return _EX_TEMPFAIL if run_id else 1
        if not await_completion:
            _watch_launch_startup(result)
    if receipt["accepted"] and not run_id:
        print("error: accepted launch missing run_id", file=sys.stderr)
        return 1
    if not receipt["accepted"]:
        return 1
    if await_completion:
        from .wrappers import (
            _await_run_forever,
            _completion_exit_code,
            _print_completed,
        )

        completion = _await_run_forever(run_id, heartbeat=not json_mode)
        if json_mode:
            print(
                json.dumps({**completion, "run_id": run_id}, ensure_ascii=False),
                flush=True,
            )
            return _completion_exit_code(completion)
        return _print_completed(run_id, completion)
    return 0


# Parity contract with the shell launcher's `spawn_watch_startup`
# (runtime/scripts/lib/launcher_watch.sh): same markers, same short window.
# The core dispatch path carried no such guard, so a fresh machine's first
# run — always unauthenticated — printed a receipt that reads like success
# while the worker had already died on "Not logged in".
STARTUP_FAILURE_HINTS: tuple[tuple[str, str], ...] = (
    ("Not logged in", "run `{agent}` once and complete the login, then retry"),
    ("Please run /login", "run `{agent}` once and complete the login, then retry"),
    ("Permission denied", "check file permissions for the run root"),
    ("command not found", "the agent CLI is not on PATH — vibecrafted doctor"),
)
STARTUP_HEALTHY_MARKERS: tuple[str, ...] = ('"type":"user"', '"type":"assistant"')


def _watch_launch_startup(
    payload: dict[str, Any], seconds: float | None = None
) -> None:
    """Report a worker that died in its first seconds instead of leaving the
    receipt as the last word. Silent when the worker starts working."""
    if seconds is None:
        try:
            seconds = float(os.environ.get("VIBECRAFTED_SPAWN_WATCH_SECONDS", "6"))
        except ValueError:
            seconds = 6.0
    transcript = str(payload.get("transcript") or "")
    # `accepted` may be absent OR present-but-null; only an explicit False
    # means the launch was refused and there is nothing to watch.
    if seconds <= 0 or not transcript or payload.get("accepted") is False:
        return
    agent = str(payload.get("agent") or "the agent")
    path = Path(transcript)
    deadline = time.monotonic() + seconds
    while time.monotonic() < deadline:
        try:
            text = path.read_text(encoding="utf-8", errors="replace")
        except OSError:
            text = ""
        for marker, hint in STARTUP_FAILURE_HINTS:
            if marker in text:
                # Flush the receipt first: piped stdout is block-buffered while
                # stderr is not, so the warning would otherwise surface above
                # the receipt it is meant to qualify.
                sys.stdout.flush()
                print(
                    f"\n⚠  Worker stopped right after launch: {marker}",
                    file=sys.stderr,
                )
                print(f"   Fix: {hint.format(agent=agent)}", file=sys.stderr)
                print(f"   Transcript: {transcript}", file=sys.stderr)
                return
        if any(marker in text for marker in STARTUP_HEALTHY_MARKERS):
            return  # the worker is producing turns — leave it alone
        time.sleep(0.25)


def _launch_receipt_reasons(payload: dict[str, Any]) -> list[str]:
    raw = payload.get("reasons") or payload.get("block_reasons")
    if isinstance(raw, str):
        reasons = [raw]
    elif isinstance(raw, (list, tuple)):
        reasons = [str(item) for item in raw if str(item).strip()]
    else:
        reasons = []
    direct = str(payload.get("reason") or "").strip()
    if direct and direct not in reasons:
        reasons.append(direct)
    failure_card = payload.get("failure_card")
    if isinstance(failure_card, dict):
        card_reason = str(
            failure_card.get("reason") or failure_card.get("message") or ""
        ).strip()
        if card_reason and card_reason not in reasons:
            reasons.append(card_reason)
    return reasons


def _print_resume_session_receipt(payload: dict[str, Any]) -> None:
    """Print the manual explicit-resume receipt, or a rejection notice to stderr."""
    if not payload.get("accepted"):
        reason = _field(payload, "reason", "launch_rejected")
        print(
            f"error: explicit session continuation rejected: {reason}", file=sys.stderr
        )
        detail = _field(payload, "detail")
        if detail:
            print(f"detail: {detail}", file=sys.stderr)
        return
    run_id = _field(payload, "run_id")
    agent = _field(payload, "agent")
    print("=============== MANUAL EXPLICIT RESUME RECEIPT ===============")
    print(f"run_id:             {run_id}")
    print(f"agent:              {agent}")
    print(f"agent_session_id:   {_field(payload, 'agent_session_id')}")
    print(f"runtime_session_id: {_field(payload, 'runtime_session_id')}")
    print(f"resume_mode:        {_field(payload, 'resume_mode')}")
    print("runtime:            headless")
    print(f"root:               {_field(payload, 'root')}")
    print(f"status:             {_field(payload, 'status', 'launching')}")
    print(f"control:            {_field(payload, 'control')}")
    print(f"transcript:         {_field(payload, 'transcript')}")
    print(f"observe:            vibecrafted observe {agent} --run-id {run_id}")
    print(f"await:              vibecrafted await {agent} --run-id {run_id}")
    print("===============================================================")


def _resolve_resume_repository_selection(
    agent: str, session: str, args: argparse.Namespace, *, label: str
) -> tuple[str, dict[str, Any]]:
    """An explicit repository binds; an exact native identity owns its default."""
    explicit = bool(args.repo or args.root)
    if explicit:
        repository = select_repository(args.repo, args.root, label=label)
        fallback = repository.path
    else:
        fallback = resolve_operator_launch_root()
    selection = resolve_session_selection(
        agent, session, fallback, infer_recorded_root=not explicit
    )
    repository = select_repository(
        args.repo, args.root, fallback=selection["selection_root"], label=label
    )
    return repository.path, selection


def _continue_launcher_named_session(
    *,
    parser: argparse.ArgumentParser,
    args: argparse.Namespace,
    source_dir: str,
    prompt: str,
    research_agents: tuple[str, ...],
) -> int:
    """Route ``<skill> --session`` onto the same native resume as ``resume``."""

    session = str(getattr(args, "session", "") or "").strip()
    command = str(args.command)
    if command == "research" or research_agents:
        print(
            "error: --session continues one provider session; "
            "research is a multi-agent swarm. "
            "Use: vibecrafted resume <agent> --session <provider-uuid>",
            file=sys.stderr,
        )
        return 2
    runtime = str(getattr(args, "runtime", "") or "").strip()
    if runtime and runtime != "headless":
        print(
            "error: --session continuation is headless-only; "
            "omit --runtime or pass --runtime headless",
            file=sys.stderr,
        )
        return 2
    if str(getattr(args, "execution_runtime", "") or "").strip() == "local-worktrees":
        print(
            "error: --session continues the selected checkout; "
            "worktree overrides require vibecrafted fork",
            file=sys.stderr,
        )
        return 2
    try:
        if parse_worktree_flag(
            getattr(args, "worktree", ""), label=f"vibecrafted {command}"
        ):
            print(
                "error: --session continues the selected checkout; "
                "worktree overrides require vibecrafted fork",
                file=sys.stderr,
            )
            return 2
    except RepoSelectionError as exc:
        print(f"error: {exc}", file=sys.stderr)
        return 2
    agent = str(args.agent or "").strip()
    if not agent:
        parser.error(f"{command} --session requires an agent")
    kind = classify_resume_identity(session)
    if kind in {"run_id", "vibecrafted_session"} or looks_like_control_plane_run_id(
        session
    ):
        _print_identity_mixup("run_id" if kind == "run_id" else kind, session)
        return 2
    prompt_file = str(getattr(args, "file", "") or "").strip()
    if prompt and prompt_file:
        print(
            "error: use one of --prompt or --file with --session",
            file=sys.stderr,
        )
        return 2
    source_path = ""
    if prompt_file:
        path = Path(prompt_file).expanduser()
        try:
            prompt = path.read_bytes().decode("utf-8")
            source_path = str(path.resolve())
        except OSError as exc:
            print(f"error: {type(exc).__name__}: {exc}", file=sys.stderr)
            return 2
    try:
        resume_root, selection = _resolve_resume_repository_selection(
            agent, session, args, label=f"{command} --session"
        )
    except (RepoSelectionError, ValueError) as exc:
        print(f"error: {exc}", file=sys.stderr)
        return 2
    if is_operator_home_root(resume_root):
        print(
            "error: refusing to launch against the home directory; "
            "open a workspace in Vibecrafted or pass --repo",
            file=sys.stderr,
        )
        return 2
    resume_result = manual_resume_session(
        agent,
        selection["agent_session_id"],
        source_dir,
        prompt=prompt,
        root=resume_root,
        model=args.model,
        source_text=prompt,
        skill=LAUNCH_ALIASES.get(command, command),
        launch_meta={"session_selection": selection},
        source_path=source_path,
        permissions=str(getattr(args, "permissions", "") or ""),
        sandbox=getattr(args, "sandbox", "") or None,
        mcp_config=str(getattr(args, "mcp_config", "") or ""),
    )
    if args.await_completion:
        return _emit_launch_result(
            resume_result, json_mode=bool(args.json), await_completion=True
        )
    if args.json:
        print(json.dumps(resume_result, ensure_ascii=False, indent=2))
    else:
        _print_resume_session_receipt(resume_result)
    return 0 if resume_result.get("accepted") else 1


def _print_launch_input_error(*, command: str, agent: str | None, message: str) -> None:
    """Print a launch-spec validation failure with usage hints to stderr."""
    base = f"vibecrafted {command} {agent or AGENT_SELECTOR}"
    print(f"error: {message}", file=sys.stderr)
    print(file=sys.stderr)
    print("Provide work for the agent with one of:", file=sys.stderr)
    print(f"  {base} --prompt 'what to do'", file=sys.stderr)
    print(f"  {base} --file /path/to/brief.md", file=sys.stderr)


def _pid_alive(pid: object) -> bool:
    """True when a pid exists (signal-0 probe); ``PermissionError`` still counts as alive."""
    if not isinstance(pid, (str, int)):
        return False
    try:
        resolved = int(pid)
        if resolved <= 0:
            return False
        os.kill(resolved, 0)
    except (ProcessLookupError, ValueError, TypeError):
        return False
    except PermissionError:
        return True  # exists but owned by another user
    return True


def _pgid_alive(pgid: object) -> bool:
    """True when a process group exists (signal-0 probe via ``killpg``)."""
    if not isinstance(pgid, (str, int)):
        return False
    try:
        resolved = int(pgid)
        if resolved <= 0:
            return False
        os.killpg(resolved, 0)
    except (ProcessLookupError, ValueError, TypeError):
        return False
    except PermissionError:
        return True
    return True


def _apply_live_liveness(run: dict[str, Any] | None) -> dict[str, Any] | None:
    """Override stale liveness with the detached worker's real OS identity.

    A headless worker survives its short-lived dispatcher by design. Prefer its
    process group/pid and consult launcher_pid only before worker identity has
    been seeded. This avoids both false death after dispatcher exit and stale
    "active" output after the actual worker disappears.
    """
    if not run:
        return run
    if _run_terminal(run):
        return run

    worker_probes = []
    if run.get("worker_pgid") not in (None, ""):
        worker_probes.append(_pgid_alive(run.get("worker_pgid")))
    if run.get("worker_pid") not in (None, ""):
        worker_probes.append(_pid_alive(run.get("worker_pid")))
    if worker_probes:
        if any(worker_probes):
            return run
    else:
        launcher_pid = run.get("launcher_pid")
        if not launcher_pid or _pid_alive(launcher_pid):
            return run

    run = dict(run)
    run["liveness"] = "pid_gone"
    run["liveness_note"] = (
        "process proof is gone while metadata remains non-terminal; "
        "projection is not yet reconciled — inspect transcript/report before recovery"
    )
    return run


def _run_for_agent(
    agent: str, run_id: str, *, last: bool = False
) -> dict[str, Any] | None:
    """Resolve one agent's run: by explicit id, or its most recent run when ``last``."""
    # With an explicit run id the scoped, lockless lookup is the whole answer.
    # The old unconditional full sync_state() here queued every await/observe
    # behind the global board lock — during an install/doctor full sync that
    # meant ControlPlaneLockBusy on every await inside the sync window.
    if run_id:
        return _apply_live_liveness(lookup_run(run_id))
    if not last:
        return None
    snapshot = sync_state()
    for key in ("active_runs", "recent_runs"):
        for run in snapshot.get(key) or []:
            if str(run.get("agent") or "") == agent:
                return _apply_live_liveness(dict(run))
    return None


def _observed_telemetry(run: dict[str, Any]) -> dict[str, Any]:
    """Usage, cost, failure cause and provider session of an observed run.

    Read-only: the run's own meta when it recorded telemetry, otherwise a lazy
    derivation from its transcript (``source: transcript(lazy)``). Someone
    else's closed run is never rewritten by looking at it.
    """
    run_id = str(run.get("run_id") or "")
    meta: dict[str, Any] = {}
    transcript: Path | None = None
    if run_id:
        try:
            resolved = resolve_run(run_id)
        except (RunNotResolved, ValueError):
            resolved = None
        if resolved is not None:
            transcript = resolved.transcript
            if resolved.meta is not None:
                try:
                    loaded = json.loads(resolved.meta.read_text(encoding="utf-8"))
                except (OSError, ValueError):
                    loaded = {}
                meta = loaded if isinstance(loaded, dict) else {}
    if transcript is None:
        raw = str(run.get("latest_transcript") or run.get("transcript") or "")
        transcript = Path(raw) if raw else None
    subject = {"run_id": run_id, "agent": run.get("agent") or "", **meta}
    if subject.get("exit_code") is None:
        subject["exit_code"] = run.get("exit_code")
    return run_telemetry_from_meta(subject, transcript=transcript)


def _print_run_telemetry(telemetry: dict[str, Any]) -> None:
    """Print exit cause, usage, cost and provider session lines."""
    exit_code = telemetry.get("exit_code")
    failure = telemetry.get("failure")
    if exit_code is not None:
        cause = ""
        if isinstance(failure, dict):
            summary = str(failure.get("summary") or "")
            prefix = f"exit_code={exit_code} "
            cause = " " + summary.removeprefix(prefix)
        print(f"exit:       {exit_code}{cause}")
    if isinstance(failure, dict):
        evidence = failure.get("evidence")
        where = (
            f"evidence unknown ({unknown_reason(evidence)})"
            if not isinstance(evidence, dict) or is_unknown(evidence)
            else f"evidence {evidence.get('path')}:{evidence.get('line')}"
        )
        print(
            f"failure:    {failure.get('kind')} · {where} · source: {failure.get('source')}"
        )
    usage = telemetry.get("usage") or {}
    total = usage.get("tokens_total")
    if is_unknown(total):
        usage_text = f"unknown ({unknown_reason(total)})"
    else:
        usage_text = (
            f"{total} {usage.get('unit') or 'tokens'} (in {usage.get('tokens_input')}"
            f" / cached {usage.get('tokens_cached_input')}"
            f" / out {usage.get('tokens_output')})"
        )
    print(f"usage:      {usage_text} · source: {usage.get('source')}")
    cost = telemetry.get("cost") or {}
    amount = cost.get("amount")
    cost_text = (
        f"unknown ({unknown_reason(amount)})"
        if is_unknown(amount)
        else f"{amount} {cost.get('unit') or cost.get('currency') or ''}".rstrip()
    )
    print(f"cost:       {cost_text} · source: {cost.get('source')}")
    session = telemetry.get("provider_session_id")
    session_text = (
        f"unknown ({unknown_reason(session)})" if is_unknown(session) else str(session)
    )
    print(f"provider_session_id: {session_text}")


def _print_run_status(
    run: dict[str, Any],
    *,
    include_tail: bool = True,
    telemetry: dict[str, Any] | None = None,
) -> None:
    """Print the standard multi-line run status block, optionally with transcript tail."""
    state = str(run.get("state") or "")
    print(f"run_id:     {run.get('run_id') or ''}")
    print(f"state:      {state}")
    print(f"agent:      {run.get('agent') or ''}")
    print(f"skill:      {run.get('skill') or ''}")
    print(f"root:       {run.get('root') or ''}")
    print(f"liveness:   {run.get('liveness') or ''}")
    if run.get("liveness_note"):
        print(f"note:       {run.get('liveness_note')}")
    if run.get("last_error") and state not in {"completed", "report_validated"}:
        print(f"last_error: {run.get('last_error')}")
    print(f"report:     {run.get('latest_report') or run.get('report') or ''}")
    transcript = str(run.get("latest_transcript") or run.get("transcript") or "")
    print(f"transcript: {transcript}")
    if telemetry is not None:
        _print_run_telemetry(telemetry)
    if not include_tail:
        return
    tail, tail_error = _tail_lines(transcript, agent=str(run.get("agent") or ""))
    if tail:
        print("transcript_tail:")
        for line in tail:
            print(f"  {line}")
    else:
        print(f"transcript_tail: unavailable ({tail_error})")


# Backlog rendered lines a watch prints before following (``tail -f`` parity).
OBSERVE_WATCH_BACKLOG_LINES = 10


def _read_new_chunk(path: str, position: int) -> tuple[str, int]:
    """Read text appended to ``path`` since byte ``position``.

    A missing/unreadable file yields no text and keeps the position; a file
    that shrank below ``position`` (rotation/truncation) restarts at 0.
    """
    if not path:
        return "", position
    transcript = Path(path).expanduser()
    try:
        size = transcript.stat().st_size
        if size < position:
            position = 0
        if size == position:
            return "", position
        with transcript.open("rb") as handle:
            handle.seek(position)
            chunk = handle.read()
    except OSError:
        return "", position
    return chunk.decode("utf-8", errors="replace"), position + len(chunk)


def _observe_watch(
    agent: str,
    run_id: str,
    observation: dict[str, Any],
    *,
    interval: float,
    json_output: bool,
    telemetry: dict[str, Any],
) -> int:
    """Follow a run's transcript until the run turns terminal.

    Prints a short rendered backlog, then streams appended lines through the
    agent's stream parser (raw pass-through for plain-text transcripts).
    Terminal truth refreshes from the local control-plane record
    (``lookup_run``) every interval; the initial server observation seeds it.
    Ctrl-C detaches — the run continues. Exit 0 when the run terminal state
    is a success, 1 when it terminally failed.
    """
    run = dict(observation.get("run") or {})
    transcript = str(run.get("latest_transcript") or run.get("transcript") or "")
    terminal = bool(observation.get("terminal")) or _run_terminal(run)
    parser: AgentStreamParser | None = None
    if agent:
        parser = AgentStreamParser(agent, default_model=resolve_default_model(agent))
    position = 0
    carry = ""
    saw_json = False
    backlog_done = False

    def emit(line: str) -> None:
        if json_output:
            print(
                json.dumps(
                    {
                        "schema": "vibecrafted.observe-event.v1",
                        "run_id": run_id,
                        "line": line,
                    },
                    ensure_ascii=False,
                ),
                flush=True,
            )
        else:
            print(f"  {line}", flush=True)

    if json_output:
        print(
            json.dumps(
                {
                    "schema": "vibecrafted.observe-watch.v1",
                    "event": "begin",
                    "run_id": run_id,
                    "agent": agent,
                    "transcript": transcript,
                    "terminal": terminal,
                    "telemetry": telemetry,
                },
                ensure_ascii=False,
            )
        )
    else:
        _print_run_status(run, include_tail=False, telemetry=telemetry)
        print(
            f"watch:      following {transcript or '(transcript not yet created)'}"
            f" every {interval:g}s — Ctrl-C detaches, the run continues"
        )

    def drain() -> None:
        nonlocal position, carry, saw_json, backlog_done
        if not transcript:
            return
        if not backlog_done:
            # Mid-stream attach: show the recent backlog, then follow from EOF.
            # The incremental parser starts here — backlog lines come from a
            # fresh _tail_lines render, so no partial parser state is needed.
            backlog_done = True
            backlog, _error = _tail_lines(
                transcript, agent=agent, max_lines=OBSERVE_WATCH_BACKLOG_LINES
            )
            for line in backlog:
                emit(line)
            try:
                position = Path(transcript).expanduser().stat().st_size
            except OSError:
                position = 0
            return
        text, position = _read_new_chunk(transcript, position)
        if not text:
            return
        raw_lines = (carry + text).split("\n")
        carry = raw_lines.pop()  # incomplete trailing line waits for its "\n"
        if not raw_lines:
            return
        if parser is None:
            for raw in raw_lines:
                if raw.strip():
                    emit(_clip_line(raw.strip()))
            return
        chunks: list[str] = []
        for raw in raw_lines:
            if raw.lstrip().startswith("{"):
                saw_json = True
            chunks.append(parser.feed_line((raw + "\n").encode("utf-8")))
        rendered: list[str] = []
        for rendered_line in "".join(chunks).splitlines():
            clean = rendered_line.strip()
            if clean and ANSI_PATTERN.sub("", clean).strip():
                rendered.append(_clip_line(clean))
        if rendered:
            for line in rendered:
                emit(line)
        elif not saw_json:
            for raw in raw_lines:
                if raw.strip():
                    emit(_clip_line(raw.strip()))

    try:
        while True:
            drain()
            if terminal:
                state = str(run.get("state") or run.get("liveness") or "terminal")
                if json_output:
                    print(
                        json.dumps(
                            {
                                "schema": "vibecrafted.observe-watch.v1",
                                "event": "terminal",
                                "run_id": run_id,
                                "state": state,
                                "telemetry": _observed_telemetry(run),
                            },
                            ensure_ascii=False,
                        )
                    )
                else:
                    _print_run_telemetry(_observed_telemetry(run))
                    print(f"watch:      run {run_id} is terminal ({state}); detached")
                return 0 if _run_succeeded(run) else 1
            time.sleep(interval)
            fresh = lookup_run(run_id)
            if fresh is None:
                continue
            fresh = _apply_live_liveness(fresh)
            run = dict(fresh or run)
            terminal = _run_terminal(run)
            latest = str(run.get("latest_transcript") or run.get("transcript") or "")
            if latest and latest != transcript:
                # The run record learned a (different) transcript path: re-attach
                # from the top of the new file with fresh parser state.
                transcript = latest
                position = 0
                carry = ""
                saw_json = False
                backlog_done = False
                parser = (
                    AgentStreamParser(agent, default_model=resolve_default_model(agent))
                    if agent
                    else None
                )
    except KeyboardInterrupt:
        if not json_output:
            print(
                f"watch:      detached from {run_id}; the run continues",
                file=sys.stderr,
            )
        return 0


def _print_identity_mixup(kind: str, token: str) -> None:
    """Explain a --run-id/--session mixup in operator language."""
    found = find_run_for_identity_token(token)
    found_id = str((found or {}).get("run_id") or "")
    provider = str((found or {}).get("agent_session_id") or "").strip()
    runtime = str(
        (found or {}).get("runtime_session_id")
        or (found or {}).get("vibecrafted_session_id")
        or ""
    ).strip()
    if kind == "run_id":
        print(
            f"That is a control-plane run id, not a provider session: {token}",
            file=sys.stderr,
        )
        print(
            f"  Use: vibecrafted resume <agent> --run-id {token}",
            file=sys.stderr,
        )
        return
    if kind == "provider_session":
        print(
            f"That is a provider session, not a control-plane run id: {token}",
            file=sys.stderr,
        )
        print(
            f"  Use: vibecrafted resume <agent> --session {token}",
            file=sys.stderr,
        )
        if found_id:
            print(
                f"  Or resume the tracked run: vibecrafted resume <agent> --run-id {found_id}",
                file=sys.stderr,
            )
        return
    if kind == "vibecrafted_session":
        print(
            "That is a Vibecrafted runtime session id "
            "(VIBECRAFTED_SESSION_ID), not a provider session and not a run id:",
            file=sys.stderr,
        )
        print(f"  {token}", file=sys.stderr)
        if found_id:
            print(
                f"  Use: vibecrafted resume <agent> --run-id {found_id}",
                file=sys.stderr,
            )
        if provider and provider != runtime:
            print(
                f"  Provider session: vibecrafted resume <agent> --session {provider}",
                file=sys.stderr,
            )
        return
    print(
        f"That token is not a control-plane run id: {token}",
        file=sys.stderr,
    )
    print(
        "  Control-plane run:  vibecrafted resume <agent> --run-id work-YYMMDD-HHMMSS-xxxxx",
        file=sys.stderr,
    )
    print(
        "  Provider session:   vibecrafted resume <agent> --session <provider-uuid>",
        file=sys.stderr,
    )


def _agent_resume(agent: str, argv: Sequence[str]) -> int:
    """``vibecrafted resume <agent>``: continue a stopped control-plane run."""
    parser = argparse.ArgumentParser(prog=f"vibecrafted resume {agent}")
    parser.add_argument("--run-id", default="")
    parser.add_argument("--last", action="store_true", help=argparse.SUPPRESS)
    parser.add_argument("--session", default="")
    parser.add_argument("-p", "--prompt", default="")
    parser.add_argument("-f", "--file", dest="prompt_file", default="")
    parser.add_argument("--prompt-stdin", action="store_true")
    add_repo_arguments(parser)
    parser.add_argument("--source-dir", default="")
    parser.add_argument("--model", default=None)
    parser.add_argument("--base", default="")
    parser.add_argument("--json", action="store_true")
    args = parser.parse_args(list(argv))
    if args.model == "":
        parser.error("CLI --model must be non-empty")

    resume_root = ""
    if str(args.repo or "").strip() or str(args.root or "").strip():
        # An explicit repository must exist and must not conflict; an absent one
        # deliberately stays empty so the parent run's recorded root wins.
        try:
            resume_root = select_repository(
                args.repo, args.root, label=f"resume {agent}"
            ).path
        except RepoSelectionError as exc:
            print(f"error: {exc}", file=sys.stderr)
            return 2

    session = str(args.session or "").strip()
    run_id = str(args.run_id or "").strip()
    if sum((bool(session), bool(run_id), bool(args.last))) > 1:
        parser.error("choose one identity: --session or --run-id")
    if args.last:
        parser.error("--last is retired for resume; use --session last")
    if session and not run_id:
        kind = classify_resume_identity(session)
        if kind in {"run_id", "vibecrafted_session"} or looks_like_control_plane_run_id(
            session
        ):
            _print_identity_mixup("run_id" if kind == "run_id" else kind, session)
            if kind == "run_id" or looks_like_control_plane_run_id(session):
                print(
                    f"  Hint: vibecrafted resume {agent} --run-id {session}",
                    file=sys.stderr,
                )
            return 2
        print(
            "Provider-session resume lives on the deck:",
            file=sys.stderr,
        )
        print(
            f"  vibecrafted resume {agent} --session {session}",
            file=sys.stderr,
        )
        print(
            f"Stopped-run resume: vibecrafted resume {agent} --run-id <work-...>",
            file=sys.stderr,
        )
        return 2

    if run_id:
        kind = classify_resume_identity(run_id)
        if kind in {"provider_session", "vibecrafted_session"}:
            _print_identity_mixup(kind, run_id)
            return 2
    elif args.last:
        run = _run_for_agent(agent, "", last=True)
        if run is None:
            print(
                f"No recent {agent} run to resume. Pass --run-id.",
                file=sys.stderr,
            )
            return 1
        run_id = str(run.get("run_id") or "")
    else:
        print(
            "Resume a stopped run with --run-id <work-...>; use --session last for scoped native history.",
            file=sys.stderr,
        )
        print(
            f"  vibecrafted resume {agent} --run-id <work-...>",
            file=sys.stderr,
        )
        print(
            f"  Provider session: vibecrafted resume {agent} --session <provider-uuid>",
            file=sys.stderr,
        )
        return 2

    prompt = str(args.prompt or "")
    if args.prompt_stdin:
        if prompt or args.prompt_file:
            parser.error("--prompt-stdin conflicts with --prompt/--file")
        prompt = read_prompt_stream(sys.stdin)
    if args.prompt_file:
        try:
            prompt = Path(args.prompt_file).expanduser().read_bytes().decode("utf-8")
        except OSError as exc:
            print(f"error: cannot read --file: {exc}", file=sys.stderr)
            return 2

    result = operator_continue_run(
        run_id,
        source_dir=args.source_dir or package_root(),
        prompt=prompt,
        expected_agent=agent,
        root=resume_root,
        model=args.model,
        plan_text=prompt if args.prompt_file else "",
        source_path=str(Path(args.prompt_file).expanduser().resolve())
        if args.prompt_file
        else "",
        base=args.base,
    )
    if args.json:
        print(json.dumps(result, ensure_ascii=False, indent=2, default=str))
    elif result.get("accepted"):
        child = str(result.get("run_id") or "")
        print("=============== OPERATOR CONTINUE RECEIPT ===============")
        print(f"resume_of:          {result.get('resume_of') or run_id}")
        print(f"run_id:             {child}")
        print(f"agent:              {result.get('agent') or agent}")
        print(f"resume_mode:        {result.get('resume_mode') or ''}")
        print(f"root:               {result.get('root') or ''}")
        if result.get("agent_session_id"):
            print(f"agent_session_id:   {result.get('agent_session_id')}")
        print(f"observe:            vibecrafted observe {agent} --run-id {child}")
        print(f"await:              vibecrafted await {agent} --run-id {child}")
        print("=========================================================")
        _watch_launch_startup(result)
    else:
        reason = str(result.get("reason") or "refused")
        print(f"error: cannot resume run {run_id}: {reason}", file=sys.stderr)
        detail = str(result.get("detail") or "").strip()
        if detail:
            print(f"detail: {detail}", file=sys.stderr)
        hint = str(result.get("hint") or "").strip()
        if hint:
            print(f"hint: {hint}", file=sys.stderr)
    return 0 if result.get("accepted") else 1


def _agent_observe(agent: str, argv: Sequence[str]) -> int:
    """Follow one run: a live transcript watch by default, bounded one-shot
    windows via ``--tail N`` / ``--head N``."""
    parser = argparse.ArgumentParser(prog=f"vibecrafted observe {agent}")
    parser.add_argument("--run-id", default="")
    parser.add_argument("--last", action="store_true")
    parser.add_argument("--json", action="store_true")
    window = parser.add_mutually_exclusive_group()
    window.add_argument(
        "--tail",
        nargs="?",
        const=OBSERVE_WINDOW_LINES,
        default=None,
        type=int,
        metavar="N",
        help=(
            f"one-shot: print the last N rendered transcript lines "
            f"(default {OBSERVE_WINDOW_LINES})"
        ),
    )
    window.add_argument(
        "--head",
        nargs="?",
        const=OBSERVE_WINDOW_LINES,
        default=None,
        type=int,
        metavar="N",
        help=(
            f"one-shot: print the first N rendered transcript lines "
            f"(default {OBSERVE_WINDOW_LINES})"
        ),
    )
    window.add_argument(
        "--watch",
        action="store_true",
        help="follow transcript events live until the run is terminal (default)",
    )
    parser.add_argument(
        "--interval",
        type=float,
        default=1.0,
        metavar="SECONDS",
        help="watch poll interval in seconds (default 1.0)",
    )
    args = parser.parse_args(list(argv))
    for name in ("tail", "head"):
        value = getattr(args, name)
        if value is not None and value <= 0:
            parser.error(f"--{name} expects a positive line count")
    if args.interval <= 0:
        parser.error("--interval expects a positive number of seconds")
    try:
        run_id = resolve_server_run_id(agent, args.run_id, last=args.last)
        observation = observe_run_from_server(run_id) if run_id else {}
    except ServerObservationError as exc:
        print(f"observe: {exc}", file=sys.stderr)
        return 2
    run = observation.get("run") if isinstance(observation, dict) else None
    if not isinstance(run, dict):
        print("No run found. Pass --run-id or --last.", file=sys.stderr)
        return 1
    telemetry = _observed_telemetry(run)
    if args.tail is not None or args.head is not None:
        which = "tail" if args.tail is not None else "head"
        count = args.tail if args.tail is not None else args.head
        transcript = str(run.get("latest_transcript") or run.get("transcript") or "")
        if which == "tail":
            lines, window_error = _tail_lines(transcript, agent=agent, max_lines=count)
        else:
            lines, window_error = _head_lines(transcript, agent=agent, max_lines=count)
        if args.json:
            payload = dict(observation)
            payload["telemetry"] = telemetry
            payload[f"transcript_{which}"] = lines
            if window_error:
                payload[f"transcript_{which}_error"] = window_error
            print(json.dumps(payload, ensure_ascii=False, indent=2, sort_keys=True))
            return 0
        _print_run_status(run, include_tail=False, telemetry=telemetry)
        if lines:
            print(f"transcript_{which}:")
            for line in lines:
                print(f"  {line}")
        else:
            print(f"transcript_{which}: unavailable ({window_error})")
        return 0
    return _observe_watch(
        agent,
        run_id,
        observation,
        interval=float(args.interval),
        json_output=bool(args.json),
        telemetry=telemetry,
    )


def _usage_cell(value: object) -> str:
    """Compact table cell: a number/string, or "unknown"."""
    if is_unknown(value) or value in (None, ""):
        return "unknown"
    return str(value)


def _usage_main(argv: Sequence[str]) -> int:
    """``vibecrafted usage``: per-run tokens, cost (with unit and source) and failure."""
    parser = argparse.ArgumentParser(
        prog="vibecrafted usage",
        description=(
            "Per-run usage: tokens (or unknown with a reason), cost with its "
            "unit and source, and the failure cause. Read-only; runs closed "
            "before telemetry existed are derived from their transcripts."
        ),
    )
    parser.add_argument("--run-id", action="append", default=[], help="repeatable")
    parser.add_argument("--since", default="", help="window such as 30m, 24h, 7d")
    parser.add_argument("--json", action="store_true")
    try:
        args = parser.parse_args(list(argv))
    except SystemExit as exc:
        return int(exc.code or 0)
    try:
        report = build_usage_report(run_ids=args.run_id, since=args.since)
    except UsageReportQueryError as exc:
        print(f"usage: {exc}", file=sys.stderr)
        return 2
    except (RunNotResolved, ValueError) as exc:
        print(f"usage: {exc}", file=sys.stderr)
        return 1
    rows = report["runs"]
    if args.json:
        print(json.dumps(report, ensure_ascii=False, indent=2, sort_keys=True))
        return 0
    header = ("run_id", "agent", "model", "tokens", "cost", "failure")
    table = [header]
    for row in rows:
        cost = row["cost"]
        unit = cost.get("unit") or cost.get("currency") or ""
        amount = cost.get("amount")
        cost_cell = (
            "unknown"
            if is_unknown(amount)
            else f"{amount} {unit} ({cost.get('source')})"
        )
        table.append(
            (
                str(row["run_id"]),
                str(row["agent"] or "unknown"),
                _usage_cell(row["model"]),
                _usage_cell(row["tokens"].get("tokens_total")),
                cost_cell,
                str(row["failure_kind"] or "-"),
            )
        )
    widths = [max(len(line[index]) for line in table) for index in range(len(header))]
    for line in table:
        print(
            "  ".join(cell.ljust(width) for cell, width in zip(line, widths)).rstrip()
        )
    totals = report["totals"]
    costs = " · ".join(
        f"{amount} {unit}" for unit, amount in totals["cost_by_unit"].items()
    )
    tokens = (
        "none known"
        if totals["runs_tokens_unknown"] == totals["runs"]
        else f"{totals['tokens_total_known']} known"
    )
    print(
        f"totals: {totals['runs']} runs · tokens {tokens}"
        f" ({totals['runs_tokens_unknown']} unknown) · cost {costs or 'none known'}"
        f" ({totals['runs_cost_unknown']} unknown)"
    )
    return 0


def _observe_resolved(run_id: str, *, json_output: bool) -> int:
    """Fallback observe path: resolve a run directly from runtime_runs/artifacts
    on disk when the control-plane projection has no record of it yet."""
    try:
        resolved = resolve_run(run_id)
    except RunNotResolved as exc:
        print(str(exc), file=sys.stderr)
        return 1
    if json_output:
        print(
            json.dumps(
                {
                    "run_id": resolved.run_id,
                    "source": resolved.source,
                    "run_dir": str(resolved.run_dir),
                    "meta": str(resolved.meta) if resolved.meta else "",
                    "transcript": str(resolved.transcript)
                    if resolved.transcript
                    else "",
                    "report": str(resolved.report) if resolved.report else "",
                },
                ensure_ascii=False,
                indent=2,
                sort_keys=True,
            )
        )
        return 0
    print(f"run_id:     {resolved.run_id}")
    print(f"source:     {resolved.source}")
    print(f"run_dir:    {resolved.run_dir}")
    print(f"report:     {resolved.report or ''}")
    print(f"transcript: {resolved.transcript or ''}")
    if resolved.transcript:
        tail, tail_error = _tail_lines(str(resolved.transcript))
        if tail:
            print("transcript_tail:")
            for line in tail:
                print(f"  {line}")
        else:
            print(f"transcript_tail: unavailable ({tail_error})")
    return 0


def _agent_await(agent: str, argv: Sequence[str]) -> int:
    """Subscribe to the dispatcher UDS; vc-server is not part of wake delivery."""
    parser = argparse.ArgumentParser(prog=f"vibecrafted await {agent}")
    parser.add_argument("--run-id", default="")
    parser.add_argument("--last", action="store_true")
    parser.add_argument(
        "--timeout",
        type=float,
        default=300,
        help="idle window in seconds — resets on movement or a live worker",
    )
    parser.add_argument("--interval", type=float, default=5)
    parser.add_argument("--status-interval", type=float, default=60)
    parser.add_argument(
        "--stale-after",
        type=float,
        default=600,
        help="deprecated: superseded by the liveness-aware idle window",
    )
    parser.add_argument(
        "--hard-cap",
        type=float,
        default=None,
        help="optional absolute wall-clock deadline in seconds",
    )
    parser.add_argument("--json", action="store_true")
    args = parser.parse_args(list(argv))
    run_id = str(args.run_id or "").strip()
    if not run_id and args.last:
        state = sync_state()
        candidates = list(state.get("active_runs") or []) + list(
            state.get("recent_runs") or []
        )
        run_id = next(
            (
                str(run.get("run_id") or "")
                for run in candidates
                if str(run.get("agent") or "") == agent
            ),
            "",
        )
    if not run_id:
        print("No run found. Pass --run-id or --last.", file=sys.stderr)
        return 1
    result = await_run_from_server(
        run_id,
        idle_timeout_seconds=args.timeout,
        interval_seconds=args.interval,
        hard_cap_seconds=args.hard_cap,
    )
    if args.json:
        print(json.dumps(result, ensure_ascii=False, indent=2, sort_keys=True))
        final_run = result.get("run")
        return (
            0
            if result.get("completed")
            and result.get("outcome") == "terminal"
            and isinstance(final_run, dict)
            and _run_succeeded(final_run)
            else 1
        )
    final_run = dict(result.get("run") or {})
    reason = str(result.get("reason") or "")
    if result.get("completed"):
        worker_alive = bool(result.get("worker_alive"))
        terminal_evidence = bool(
            final_run and _run_terminal(final_run) and not worker_alive
        )
        if terminal_evidence and final_run and not _run_succeeded(final_run):
            print(f"await: terminal failure ({reason})")
            _print_run_status(final_run)
            return 1
        if not terminal_evidence:
            print(
                f"await: non-terminal completion disagreement ({reason})",
                file=sys.stderr,
            )
            if final_run:
                _print_run_status(final_run)
            return 3
        print(f"await: completed ({reason})")
        if final_run:
            _print_run_status(final_run)
        return 0
    if not result.get("found"):
        print(f"await: run disappeared: {run_id}", file=sys.stderr)
        return 1
    print(f"await: timed out ({reason})")
    if final_run:
        _print_run_status(final_run)
    return 1


def _cmd_resettle(args: argparse.Namespace) -> int:
    """Honest re-settlement of retained control_plane/runs snapshots."""
    from .lifecycle_delivery import resettle_retained_snapshots

    result = resettle_retained_snapshots(
        force=True,
        dry_run=bool(getattr(args, "dry_run", False)),
    )
    if getattr(args, "json", False):
        print(json.dumps(result, ensure_ascii=False, indent=2))
        return 0 if result.get("ok") else 1
    before = result.get("before") or {}
    after = result.get("after") or {}
    print(
        "resettle "
        f"scanned={result.get('scanned', 0)} "
        f"rewritten={result.get('rewritten', 0)} "
        f"unchanged={result.get('unchanged', 0)} "
        f"skipped={result.get('skipped', 0)}"
        + (" (dry-run)" if result.get("dry_run") else "")
    )
    print(
        f"before: f={before.get('f', 0)} x={before.get('x', 0)} "
        f"n={before.get('n', 0)} invalid={before.get('invalid', 0)}"
    )
    print(
        f"after:  f={after.get('f', 0)} x={after.get('x', 0)} "
        f"n={after.get('n', 0)} invalid={after.get('invalid', 0)}"
    )
    print(
        "note: automatic FINALIZED comes only from a sealed delivery or an "
        "explicit worker attestation (finalized: true + claim); a traced "
        "operator waive remains an explicit override; never from bare exit 0"
    )
    return 0 if result.get("ok") else 1


def main(argv: Sequence[str] | None = None) -> int:
    """Top-level ``vibecrafted`` entrypoint: dispatches to python subcommands,
    the legacy bash deck, or the acp/dispatch/stop/observe/await verbs based
    on the invoked name and leading argv token."""
    raw_args = list(sys.argv[1:] if argv is None else argv)
    invoked_as = Path(sys.argv[0]).name if argv is None else "vibecrafted"
    shell_wrapper_verb = SHELL_WRAPPER_VERBS.get(invoked_as) if argv is None else None
    if shell_wrapper_verb:
        raw_args = [shell_wrapper_verb, *raw_args]
    raw_args = _normalize_raw_args(raw_args)

    # `--version` / `-v` / `version` report the INSTALLED runtime version — the
    # one `vibecrafted start` / `vc-start` actually runs — read straight from the
    # package. Never delegate to the legacy bash deck: its `_version()` resolves
    # VERSION from the current working directory (`repo_root/VERSION`), so invoked
    # from inside a checkout it reports that checkout's version, not the installed
    # one. The package is what executes, so its `__version__` is the honest answer.
    if raw_args and raw_args[0] in {"-v", "--version", "version"}:
        from . import __version__

        print(f"vibecrafted {__version__}")
        return 0

    # Help is a product surface, not argparse fallout.  Resolve it before the
    # shell-deck compatibility router or any workflow runtime is imported so
    # every installed entrypoint teaches the same contract.  ``help --all``
    # deliberately stays with the deck: it is the long operational reference.
    from . import __version__

    help_version = os.environ.get("VIBECRAFTED_HELP_VERSION", "").strip() or __version__
    from .help_surface import (
        has_workflow_help,
        render_message_help,
        render_resume_session_help,
        render_root_help,
        render_workflow_help,
    )

    if not raw_args or raw_args[0] in {"-h", "--help"}:
        print(render_root_help(help_version), end="")
        return 0
    if raw_args[0] == "help":
        if len(raw_args) == 1:
            print(render_root_help(help_version), end="")
            return 0
        topic = raw_args[1].removeprefix("vc-")
        if topic in CORE_SURFACE_COMMANDS:
            return _render_core_surface_help(topic)
        if topic not in {"--all", "--full"} and has_workflow_help(topic):
            print(render_workflow_help(topic), end="")
            return 0
    if raw_args[0] == "resume-session" and any(
        arg in {"-h", "--help"} for arg in raw_args[1:]
    ):
        print(render_resume_session_help(), end="")
        return 0
    if raw_args[0] == "message" and any(
        arg in {"-h", "--help"} for arg in raw_args[1:]
    ):
        print(render_message_help(), end="")
        return 0
    if raw_args[0] in LAUNCHERS:
        workflow_args = raw_args[1:]
        help_requested = (
            bool(workflow_args)
            and workflow_args[0] == "help"
            or any(arg in {"-h", "--help"} for arg in workflow_args)
        )
        if help_requested:
            print(render_workflow_help(raw_args[0]), end="")
            return 0

    if raw_args and raw_args[0] == "agents":
        from .help_surface import render_agents_help

        print(render_agents_help(), end="")
        return 0

    try:
        raw_args = _normalize_research_arity_args(raw_args)
    except ValueError as exc:
        print(f"vibecrafted research: {exc}", file=sys.stderr)
        return 2

    python_commands = python_owned_commands()
    agent_python_verbs = {"observe", "await", "stop", "resume"}
    is_lifecycle = shell_wrapper_verb is not None
    if raw_args and shell_wrapper_verb is None:
        first = raw_args[0]
        second = raw_args[1] if len(raw_args) > 1 else ""
        if first in AGENTS and second in agent_python_verbs:
            # Core owns agent observe/await/stop/resume (read-follows-write via
            # resolve_run); never delegate these to the legacy deck/observe.sh.
            is_lifecycle = False
        elif first not in python_commands and not first.startswith("-"):
            is_lifecycle = True

    if raw_args and raw_args[0] == "partner":
        # Partner is init-family: always the interactive TTY/frame launcher.
        # --prompt/--file are extra seed context, never launch_workflow.
        is_lifecycle = True

    if sys.platform == "win32" and raw_args and raw_args[0] == "server":
        from .windows_server import main as windows_server_main

        return windows_server_main(raw_args[1:])

    if sys.platform == "win32" and is_lifecycle:
        # Native aliases keep their Python owner. POSIX-only verbs cannot
        # execute the bash deck through Windows CreateProcess (WinError 193).
        if raw_args[0] in python_commands:
            is_lifecycle = False
        else:
            print(
                f"error: {raw_args[0]} uses the POSIX command deck and is not "
                "supported on Windows. Use WSL2 for this command; native "
                "Runtime Pack commands include doctor and server.",
                file=sys.stderr,
            )
            return 2

    if is_lifecycle:
        from .runtime_paths import vibecrafted_tools_home

        tools_home = vibecrafted_tools_home()
        deck = tools_home / "vibecrafted-current" / "scripts" / "vibecrafted"
        if not deck.is_file():
            deck = deck_path()
        if deck.is_file():
            try:
                lease_pass_fds = _installer_lease_pass_fds(tools_home)
            except OSError as exc:
                print(
                    f"error: cannot preserve installer coordination lease: {exc}",
                    file=sys.stderr,
                )
                return _EX_TEMPFAIL
            if lease_pass_fds:
                res = subprocess.run(
                    [str(deck), *raw_args],
                    check=False,
                    pass_fds=lease_pass_fds,
                )
            else:
                res = subprocess.run([str(deck), *raw_args], check=False)
            return res.returncode
        if shell_wrapper_verb is not None:
            print(
                f"error: {invoked_as} cannot find the runtime deck at {deck}",
                file=sys.stderr,
            )
            return 1

    if raw_args and raw_args[0] == "acp":
        try:
            from vibecrafted_acp.server import main as acp_main
        except ModuleNotFoundError:
            print(
                "error: vibecrafted-acp is not installed; install the "
                "vibecrafted-acp workspace package",
                file=sys.stderr,
            )
            return 1
        return acp_main(raw_args[1:])

    if raw_args and raw_args[0] == "dispatch":
        from .dispatch.cli import main as dispatch_main

        return dispatch_main(raw_args[1:])
    if raw_args and raw_args[0] == "pr-closure":
        from .pr_closure import main as pr_closure_main

        return _invoke_owned_main(pr_closure_main, raw_args[1:])
    if raw_args and raw_args[0] == "ship":
        from .ship import main as ship_main

        return ship_main(raw_args[1:])
    if raw_args and raw_args[0] == "claims":
        from .repository_claims import claims_cli_main

        return _invoke_owned_main(claims_cli_main, raw_args[1:])
    if raw_args and raw_args[0] == "usage":
        return _usage_main(raw_args[1:])
    if raw_args and raw_args[0] == "control-plane-revalidate":
        parser = _build_parser()
        args = parser.parse_args(raw_args)
        run = lookup_run(str(args.run_id))
        payload = {
            "schema": "vibecrafted.control-plane-revalidation.v1",
            "run_id": str(args.run_id),
            "found": run is not None,
            "run": run,
        }
        if args.json:
            print(json.dumps(payload, ensure_ascii=False, indent=2, sort_keys=True))
        elif run is not None:
            _print_run_status(run, include_tail=False)
        else:
            print(f"run not found: {args.run_id}", file=sys.stderr)
        # Exit contract: 0 means the canonical writer performed the lookup and
        # the payload is the answer (`found` true/false). vc-server maps any
        # non-zero exit to "writer unavailable" (HTTP 503), so a legitimately
        # absent run must not exit 1 — that is a clean 404, not a disagreement.
        return 0
    if raw_args and raw_args[0] == "relocate":
        from .relocate import main as relocate_main

        return _invoke_owned_main(relocate_main, raw_args[1:])
    if raw_args and raw_args[0] == "reinstall":
        from .reinstall_clean import main as reinstall_main

        return _invoke_owned_main(reinstall_main, raw_args[1:])
    if raw_args and raw_args[0] == "stop":
        from .wrappers import stop_main

        return stop_main(raw_args[1:])
    if len(raw_args) >= 2 and raw_args[0] in AGENTS and raw_args[1] == "stop":
        from .wrappers import stop_main

        return stop_main(["--agent", raw_args[0], *raw_args[2:]])
    if len(raw_args) >= 2 and raw_args[0] in AGENTS and raw_args[1] == "resume":
        return _agent_resume(raw_args[0], raw_args[2:])
    if len(raw_args) >= 2 and raw_args[0] in AGENTS and raw_args[1] == "observe":
        return _agent_observe(raw_args[0], raw_args[2:])
    if len(raw_args) >= 2 and raw_args[0] in AGENTS and raw_args[1] == "await":
        return _agent_await(raw_args[0], raw_args[2:])

    parser = _build_parser()
    args = parser.parse_args(raw_args)
    if getattr(args, "model", None) == "":
        parser.error("CLI --model must be non-empty")
    if not args.command:
        parser.print_help()
        return 0
    if args.command == "config":
        from .vc_frame_delivery import ensure_zshrc

        action = getattr(args, "config_action", None)
        if action == "ensure-zshrc":
            result = ensure_zshrc(dry_run=bool(getattr(args, "dry_run", False)))
            print(f"ensure-zshrc: {result['action']} -> {result['path']}")
            return 0
        if action == "install":
            print(
                "config install has been retired. Product configuration is owned "
                "by the Runtime Pack installer. Run make install from the "
                "Vibecrafted checkout with your verified Runtime Pack. "
                "No configuration was delivered.",
                file=sys.stderr,
            )
            return 2
        print("usage: vibecrafted config ensure-zshrc [--dry-run]", file=sys.stderr)
        return 2
    if args.command == "receipt":
        from .runtime_receipt import receipt_main

        return receipt_main(["--json"] if args.json else [])
    if args.command == "doctor":
        if getattr(args, "quarantine_legacy_runs", False):
            from .run_reaper import quarantine_legacy_runs

            quarantine = quarantine_legacy_runs()
            payload = quarantine.as_dict()
            if args.json:
                print(json.dumps(payload, ensure_ascii=False, indent=2))
            else:
                print(
                    "quarantine-legacy-runs: "
                    f"changed={payload['changed']} "
                    f"marked_legacy={len(payload['marked_legacy'])} "
                    f"recovered_pgid={len(payload['recovered_pgid'])} "
                    f"skipped_live={len(payload['skipped_live'])} "
                    f"skipped_has_pgid={len(payload['skipped_has_pgid'])} "
                    f"already_legacy={len(payload['already_legacy'])} "
                    f"parse_errors={len(payload['parse_errors'])}"
                )
                for run_id in payload["marked_legacy"]:
                    print(f"  legacy: {run_id}")
                for row in payload["recovered_pgid"]:
                    print(
                        f"  recovered: {row.get('run_id')} "
                        f"worker_pgid={row.get('worker_pgid')}"
                    )
                for err in payload["parse_errors"]:
                    print(f"  parse_error: {err}")
            return 0
        findings = doctor_module.doctor_run(
            release=bool(getattr(args, "release", False))
        )
        summary = doctor_module.doctor_summary(findings)
        from .runtime_receipt import build_receipt, render_receipt_text

        delivery_receipt = build_receipt()
        summary["delivery_receipt"] = delivery_receipt
        if args.json:
            print(json.dumps(summary, ensure_ascii=False, indent=2))
        elif getattr(args, "verbose", False):
            for finding in summary["findings"]:
                print(
                    f"{finding['level']}: {finding['component']} - {finding['message']}"
                )
            print(
                f"summary: {summary['ok']} ok, {summary['warnings']} warnings, "
                f"{summary['failures']} failures"
            )
            print()
            print(render_receipt_text(delivery_receipt), end="")
        else:
            # Summary-first for humans (CLI_PRODUCT_SPEC §6.4): the verdict and
            # the problems carry the answer; the passing ledger lives under
            # --verbose and the machine shape under --json.
            problems = [
                f for f in summary["findings"] if f["level"] in ("fail", "warn")
            ]
            # Cold Windows install reads the default text, not --verbose.
            # These ok lines are the publication declaration that POSIX
            # surfaces are absent. Hiding them makes a native pack look complete.
            declarations = [
                f
                for f in summary["findings"]
                if f["level"] == "ok" and "not supported on Windows" in f["message"]
            ]
            checks = len(summary["findings"])
            version = next(
                (
                    f["message"]
                    for f in summary["findings"]
                    if f["component"] == "version" and f["level"] == "ok"
                ),
                "",
            )
            if problems:
                print(
                    f"⚒ doctor — {checks} checks: {summary['ok']} ok · "
                    f"{summary['warnings']} warnings · {summary['failures']} failures"
                )
                print()
                for finding in problems:
                    print(
                        f"{finding['level']}: {finding['component']} - {finding['message']}"
                    )
            else:
                verdict = f"⚒ doctor — {checks} checks, all ok"
                if version:
                    verdict += f" · vibecrafted {version}"
                print(verdict)
            for finding in declarations:
                print(
                    f"{finding['level']}: {finding['component']} - {finding['message']}"
                )
            print()
            print("details: vibecrafted doctor --verbose")
            print()
            print(render_receipt_text(delivery_receipt), end="")
        return 0 if summary["failures"] == 0 else 1
    if args.command == "reap":
        if getattr(args, "resettle", False):
            return _cmd_resettle(args)
        from .run_reaper import main as reap_main

        reap_argv: list[str] = []
        if args.dry_run:
            reap_argv.append("--dry-run")
        if args.json:
            reap_argv.append("--json")
        return reap_main(reap_argv)
    if args.command == "settle":
        if not getattr(args, "resettle", False):
            print(
                "usage: vibecrafted settle --resettle [--dry-run] [--json]",
                file=sys.stderr,
            )
            return 2
        return _cmd_resettle(args)
    if args.command == "workspace":
        from .workspace_catalog import workspace_cli_main

        argv = list(getattr(args, "workspace_argv", []) or [])
        # argparse REMAINDER may keep a leading "--".
        if argv and argv[0] == "--":
            argv = argv[1:]
        return workspace_cli_main(argv)
    if args.command == "settlements":
        from .settlements_query import (
            SettlementsQueryError,
            inspect_settlement,
            list_settlements,
            render_settlements_inspect_text,
            render_settlements_list_text,
            render_settlements_summary_text,
            settlements_summary,
        )

        action = getattr(args, "settlements_action", None)
        if action is None:
            print(
                "usage: vibecrafted settlements summary [--json] [--workspace-id UUID]\n"
                "       vibecrafted settlements list "
                "[--bucket f|x|n] [--revalidatable] "
                "[--group agent,skill,reason,root] [--limit N] [--json]\n"
                "       vibecrafted settlements inspect <run_id> [--json]",
                file=sys.stderr,
            )
            return 2
        try:
            if action == "summary":
                workspace_id = str(getattr(args, "workspace_id", "") or "").strip()
                if workspace_id:
                    from .workspace_catalog import settlement_counts_for_workspace

                    payload = settlement_counts_for_workspace(workspace_id)
                    print(json.dumps(payload, ensure_ascii=False, indent=2))
                    return 0
                payload = settlements_summary()
                if getattr(args, "json", False):
                    print(json.dumps(payload, ensure_ascii=False, indent=2))
                else:
                    print(render_settlements_summary_text(payload))
                return 0
            if action == "list":
                payload = list_settlements(
                    bucket=getattr(args, "bucket", None),
                    revalidatable=bool(getattr(args, "revalidatable", False)),
                    group=getattr(args, "group", None) or None,
                    limit=getattr(args, "limit", None),
                )
                if getattr(args, "json", False):
                    print(json.dumps(payload, ensure_ascii=False, indent=2))
                else:
                    print(render_settlements_list_text(payload))
                return 0
            if action == "inspect":
                payload = inspect_settlement(str(args.run_id))
                if getattr(args, "json", False):
                    print(
                        json.dumps(payload, ensure_ascii=False, indent=2, default=str)
                    )
                else:
                    print(render_settlements_inspect_text(payload))
                return 0
        except SettlementsQueryError as exc:
            print(f"error: {exc}", file=sys.stderr)
            return 2
        print(
            "usage: vibecrafted settlements {summary|list|inspect}",
            file=sys.stderr,
        )
        return 2
    if args.command == "procs":
        from .process_control import main as procs_main

        action = getattr(args, "procs_action", None) or "snapshot"
        if action == "snapshot":
            return procs_main(["snapshot", "--json"])
        if action == "terminate":
            return procs_main(
                [
                    "terminate",
                    "--pid",
                    str(args.pid),
                    "--expected-start",
                    args.expected_start,
                    "--expected-command-sha256",
                    args.expected_command_sha256,
                    "--expected-run-id",
                    args.expected_run_id or "",
                    "--json",
                ]
            )
        print("usage: vibecrafted procs {snapshot|terminate}", file=sys.stderr)
        return 2
    if args.command == "capabilities":
        from .workflow_capabilities import (
            render_capabilities_lines,
            workflow_capabilities_payload,
        )

        capabilities_payload = workflow_capabilities_payload()
        if args.json:
            print(
                json.dumps(
                    capabilities_payload, ensure_ascii=False, indent=2, sort_keys=True
                )
            )
        else:
            for line in render_capabilities_lines(capabilities_payload):
                print(line)
        return 0
    if args.command == "message":
        # In a container run the host remains the only owner. Never fall back
        # to a guest-local outbox if the relay is unavailable or an unsupported
        # action was requested.
        from .container_message_bridge import guest_bridge_selected
        from .message_control import (
            MessageControlError,
            acknowledge_message,
            inspect_message,
            mark_context_injected,
            receive_messages,
            send_message,
        )

        guest_bridge = guest_bridge_selected(args.run_id or "")
        if args.connect_container:
            if (
                guest_bridge
                or not args.run_id
                or any(
                    (
                        args.session,
                        args.file,
                        args.receive,
                        args.ack,
                        args.inspect,
                        args.retry,
                        args.mark_context_injected,
                        args.nonce,
                        args.idempotency_key,
                    )
                )
            ):
                print(
                    "error: connect_container_requires_host_run_id_only",
                    file=sys.stderr,
                )
                return 2
            from .container_connection import connect_container

            try:
                connect_container(
                    args.run_id,
                    ready=lambda status: print(json.dumps(status), flush=True),
                )
            except KeyboardInterrupt:
                return 0
            except (
                OSError,
                ValueError,
                RuntimeError,
                subprocess.SubprocessError,
            ) as exc:
                print(f"error: {exc}", file=sys.stderr)
                return 2
            return 0
        if guest_bridge and not (args.receive or args.ack or args.inspect):
            print("error: bridge_action_unsupported", file=sys.stderr)
            return 2

        if args.inspect:
            try:
                if guest_bridge:
                    from .container_message_bridge import guest_request

                    result = guest_request(
                        action="inspect",
                        run_id=args.run_id or "",
                        session=args.session or "",
                        message_id=args.inspect,
                    )
                else:
                    result = inspect_message(args.inspect)
            except MessageControlError as exc:
                print(f"error: {exc}", file=sys.stderr)
                return 2
            if result is None:
                print(f"message not found: {args.inspect}", file=sys.stderr)
                return 1
            print(json.dumps(result, ensure_ascii=False, indent=2, sort_keys=True))
            return 0
        if args.mark_context_injected:
            try:
                if args.receive or args.ack or args.file or args.inspect:
                    raise MessageControlError(
                        "mark_conflicts_with_other_message_action"
                    )
                result = mark_context_injected(args.mark_context_injected, args.nonce)
            except MessageControlError as exc:
                print(f"error: {exc}", file=sys.stderr)
                return 2
            print(json.dumps(result, ensure_ascii=False, indent=2, sort_keys=True))
            return 0
        if args.receive or args.ack:
            try:
                if args.receive and args.ack:
                    raise MessageControlError("choose_receive_or_ack")
                if args.file or args.inspect:
                    raise MessageControlError(
                        "inbox_action_conflicts_with_send_or_inspect"
                    )
                if guest_bridge:
                    from .container_message_bridge import guest_request

                    result = guest_request(
                        action="receive" if args.receive else "ack",
                        run_id=args.run_id or "",
                        session=args.session or "",
                        message_id=args.ack or "",
                    )
                else:
                    result = (
                        receive_messages(run_id=args.run_id, session=args.session)
                        if args.receive
                        else acknowledge_message(
                            args.ack, run_id=args.run_id, session=args.session
                        )
                    )
            except MessageControlError as exc:
                print(f"error: {exc}", file=sys.stderr)
                return 2
            print(json.dumps(result, ensure_ascii=False, indent=2, sort_keys=True))
            return 0
        if (args.run_id or args.session) and args.file:
            try:
                raw = Path(args.file).expanduser().read_bytes()
            except OSError as exc:
                print(
                    f"error: message_file_unreadable:{type(exc).__name__}",
                    file=sys.stderr,
                )
                return 2
            try:
                text = raw.decode("utf-8")
            except UnicodeDecodeError:
                print("error: message_file_not_utf8", file=sys.stderr)
                return 2
            try:
                result = send_message(
                    run_id=args.run_id,
                    session=args.session,
                    text=text,
                    idempotency_key=args.idempotency_key,
                    retry=bool(args.retry),
                )
            except MessageControlError as exc:
                print(f"error: {exc}", file=sys.stderr)
                return 2
            if args.json:
                print(json.dumps(result, ensure_ascii=False, indent=2, sort_keys=True))
            else:
                print(
                    f"message_id: {result['message_id']}\n"
                    f"run_id: {result['run_id']}\n"
                    f"provider: {result['provider']}\n"
                    f"delivery_state: {result['delivery_state']}\n"
                    f"agent_ack_state: {result.get('agent_ack_state', 'unobserved')}"
                )
                receiver = (
                    result.get("receiver_command")
                    or f"vibecrafted message --run-id {result['run_id']} --receive"
                )
                print(f"receiver_command: {receiver}")
                print(
                    result.get("delivery_notice")
                    or "Recipient checkpoint required until ACK; queue acceptance is not context receipt."
                )
                failure = result.get("failure") or {}
                if failure:
                    print(f"failure_reason: {failure.get('reason', 'unknown')}")
                    diagnostic = failure.get("diagnostic") or {}
                    if diagnostic:
                        print(
                            f"failure_category: {diagnostic['category']}\nnext_action: {diagnostic['action']}"
                        )
            return (
                0
                if result["delivery_state"]
                in {"provider_accepted", "inbox_pending", "agent_acknowledged"}
                else 1
            )
        print(
            "usage: vibecrafted message (--run-id ID | --session ID) --file FILE | --receive | --ack MESSAGE_ID | --inspect MESSAGE_ID | --mark-context-injected MESSAGE_ID --nonce NONCE",
            file=sys.stderr,
        )
        return 2
    if args.command == "resume-session":
        prompt = str(args.prompt or "")
        if args.prompt_stdin:
            prompt = read_prompt_stream(sys.stdin)
        elif args.prompt_file:
            prompt_path = Path(args.prompt_file).expanduser()
            try:
                prompt = prompt_path.read_bytes().decode("utf-8")
            except OSError as exc:
                resume_result: dict[str, Any] = {
                    "schema": "vibecrafted.manual_explicit_resume.v1",
                    "accepted": False,
                    "reason": "prompt_file_unreadable",
                    "retryable": False,
                    "terminal": True,
                    "resume_mode": "manual_explicit",
                    "agent": args.agent,
                    "agent_session_id": args.agent_session_id,
                    "detail": f"{type(exc).__name__}: {exc}",
                }
                if args.json:
                    print(json.dumps(resume_result, ensure_ascii=False, indent=2))
                else:
                    _print_resume_session_receipt(resume_result)
                return 2
        try:
            resume_root, selection = _resolve_resume_repository_selection(
                args.agent, args.agent_session_id, args, label="resume-session"
            )
        except (RepoSelectionError, ValueError) as exc:
            print(f"error: {exc}", file=sys.stderr)
            return 2
        if is_operator_home_root(resume_root):
            print(
                "error: refusing to launch against the home directory; "
                "open a workspace in Vibecrafted or pass --repo",
                file=sys.stderr,
            )
            return 2
        resume_result = manual_resume_session(
            args.agent,
            selection["agent_session_id"],
            args.source_dir or package_root(),
            prompt=prompt,
            root=resume_root,
            model=args.model,
            source_text=prompt,
            launch_meta={"session_selection": selection},
            source_path=str(Path(args.prompt_file).expanduser().resolve())
            if args.prompt_file
            else "",
            permissions=args.permissions,
            sandbox=args.sandbox or None,
        )
        if args.json:
            print(json.dumps(resume_result, ensure_ascii=False, indent=2))
        else:
            _print_resume_session_receipt(resume_result)
        return 0 if resume_result.get("accepted") else 1
    if args.command == "fork-session":
        from .workflow import manual_fork_session

        try:
            prompt = (
                Path(args.file).expanduser().read_bytes().decode("utf-8")
                if args.file
                else read_prompt_stream(sys.stdin)
            )
            result = manual_fork_session(
                args.agent,
                args.session,
                args.source_dir or package_root(),
                prompt=prompt,
                root=args.root,
                model=args.model,
                base=args.base,
                worktree=args.worktree,
                execution_runtime=args.execution_runtime,
                source_path=args.file,
                parent_run_id=args.parent_run_id,
                permissions=args.permissions,
                session_selection=args.session_selection,
            )
        except (ValueError, OSError) as exc:
            print(f"error: {exc}", file=sys.stderr)
            return 2
        print(json.dumps(result, ensure_ascii=False, default=str))
        return 0 if result.get("accepted") else 2
    if args.command == "session-source":
        from .workflow import resolve_session_selection

        try:
            result = resolve_session_selection(
                args.agent,
                args.session,
                args.root,
                infer_recorded_root=args.infer_recorded_root,
                selection=args.session_selection,
            )
        except ValueError as exc:
            print(f"error: {exc}", file=sys.stderr)
            return 2
        print(result["agent_session_id"] if args.id_only else json.dumps(result))
        return 0
    if args.command == "fork-source":
        from .workflow import resolve_session_selection

        fork_result = resolve_fork_source(
            args.agent, run_id=args.run_id, session=args.session
        )
        if args.root and not (args.session and args.run_id):
            try:
                if args.session in {"current", "last", "previous"}:
                    fork_result = resolve_session_selection(
                        args.agent, args.session, args.root
                    )
                elif fork_result.get("accepted"):
                    selected_root = args.root
                    if selected_root == "auto":
                        selected_root = fork_result.get("source_root") or str(
                            Path.cwd()
                        )
                    original = fork_result
                    fork_result = resolve_session_selection(
                        args.agent, original["agent_session_id"], selected_root
                    )
                    if args.run_id:
                        fork_result.update(
                            session_selector="run-id",
                            identity_source="run_meta",
                            source_run_id=args.run_id,
                        )
                if fork_result.get("accepted"):
                    capability = resolve_fork_source(
                        args.agent, session=fork_result["agent_session_id"]
                    )
                    if not capability.get("accepted"):
                        fork_result = capability
            except ValueError as exc:
                fork_result = {
                    "accepted": False,
                    "reason": "session_selection_failed",
                    "detail": str(exc),
                }
        if args.json:
            print(json.dumps(fork_result, ensure_ascii=False, indent=2))
        elif fork_result.get("accepted"):
            print(f"agent:              {fork_result.get('agent')}")
            print(f"agent_session_id:   {fork_result.get('agent_session_id')}")
            print(f"source_run_id:      {fork_result.get('source_run_id') or ''}")
            print(f"identity_source:    {fork_result.get('identity_source')}")
            print(f"native_fork:        {fork_result.get('native_fork')}")
        else:
            print(
                f"error: cannot resolve fork source: {fork_result.get('reason')}",
                file=sys.stderr,
            )
            for key in ("detail", "hint"):
                value = str(fork_result.get(key) or "").strip()
                if value:
                    print(f"{key}: {value}", file=sys.stderr)
        return 0 if fork_result.get("accepted") else 2
    if args.command == "paste":
        from .paste import run_namespace

        try:
            args.root = select_repository(
                args.repo, args.root, fallback=Path.cwd, label="paste"
            ).path
        except RepoSelectionError as exc:
            print(f"error: {exc}", file=sys.stderr)
            return 2
        return run_namespace(args, source_dir=package_root())

    source_dir = args.source_dir or package_root()
    prompt = str(args.prompt or "")
    if args.prompt_stdin:
        if prompt or args.file:
            parser.error("--prompt-stdin cannot be combined with --prompt or --file")
        prompt = read_prompt_stream(sys.stdin)
    agent_arg = args.agent
    research_agents = ()
    if args.command == "research" and isinstance(agent_arg, list):
        research_agents = tuple(agent_arg) if len(agent_arg) > 1 else ()
    try:
        parse_worktree_flag(
            getattr(args, "worktree", ""), label=f"vibecrafted {args.command}"
        )
        launch_root = args.repo or args.root or str(Path.cwd())
    except RepoSelectionError as exc:
        print(f"error: {exc}", file=sys.stderr)
        return 2
    if is_operator_home_root(launch_root):
        print(
            "error: refusing to launch against the home directory; "
            "open a workspace in Vibecrafted or pass --repo",
            file=sys.stderr,
        )
        return 2
    session = str(getattr(args, "session", "") or "").strip()
    if session:
        return _continue_launcher_named_session(
            parser=parser,
            args=args,
            source_dir=source_dir,
            prompt=prompt,
            research_agents=research_agents,
        )
    payload = {
        "skill": LAUNCH_ALIASES.get(args.command, args.command),
        "agent": args.agent,
        "prompt": prompt,
        "input_explicit": args.prompt is not None
        or bool(args.file)
        or args.prompt_stdin,
        "file": args.file,
        "runtime": _default_runtime(args.runtime, launch_root),
        "root": args.root,
        "repo": args.repo,
        "repo_selector": True,
        "worktree": args.worktree,
        "runtime_class": args.execution_runtime,
        "base": args.base,
        "permissions": getattr(args, "permissions", ""),
        "sandbox": getattr(args, "sandbox", ""),
        "remediate_trust_block": bool(getattr(args, "remediate_trust_block", False)),
        "remediation_reason": getattr(args, "remediation_reason", ""),
        "remediation_task": getattr(args, "remediation_task", ""),
        "mode": args.mode or args.command,
        "count": args.count,
        "depth": args.depth,
        "model": args.model,
        "effort": getattr(args, "effort", ""),
        "mcp_config": getattr(args, "mcp_config", ""),
        "research_agents": research_agents,
        "synthesizer": getattr(args, "synthesizer", ""),
        "synthesizer_model": getattr(args, "synthesizer_model", ""),
    }
    try:
        spec = normalize_launch_spec(payload, source_dir)
    except ValueError as exc:
        _print_launch_input_error(
            command=str(args.command), agent=args.agent, message=str(exc)
        )
        return 2
    try:
        result = launch_workflow(spec, source_dir)
    except (OSError, TypeError, ValueError, RuntimeError) as exc:
        print(
            f"error: launch raised {type(exc).__name__}: {exc}",
            file=sys.stderr,
        )
        recovered = recover_launch_receipt(spec)
        if recovered and recovered.get("run_id"):
            result = recovered
        else:
            result = {
                "accepted": False,
                "run_id": "",
                "agent": spec.agent,
                "skill": spec.skill,
                "root": spec.root,
                "status": "failed",
                "error": f"{type(exc).__name__}: {exc}",
            }
            from .guard import GuardRefusal, launch_disclosure

            if isinstance(exc, GuardRefusal):
                result["reason"] = exc.decision.reason
                disclosure = launch_disclosure(exc.decision)
                if disclosure:
                    result["guard"] = disclosure
    return _emit_launch_result(
        result, json_mode=bool(args.json), await_completion=args.await_completion
    )


if __name__ == "__main__":
    raise SystemExit(main())
