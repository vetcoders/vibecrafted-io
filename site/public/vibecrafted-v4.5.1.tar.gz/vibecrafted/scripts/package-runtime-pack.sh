#!/usr/bin/env bash
set -euo pipefail

die() { printf 'Runtime Pack packaging failed: %s\n' "$*" >&2; exit 1; }

REPO_ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
# shellcheck source=/dev/null
. "$REPO_ROOT/scripts/lib/macho-signing.sh"

payload_root=""
output=""
source_revision=""
terminal_revision=""
frame_revision=""
version=""
platform=""
architecture=""
codesign_identity=""
codesign_keychain=""
while (($#)); do
  case "$1" in
    --payload-root)
      (($# >= 2)) || die "--payload-root requires a path"
      payload_root="$2"
      shift 2
      ;;
    --output)
      (($# >= 2)) || die "--output requires a path"
      output="$2"
      shift 2
      ;;
    --source-revision|--terminal-revision|--frame-revision|--version|--platform|--architecture)
      (($# >= 2)) || die "$1 requires a value"
      case "$1" in
        --source-revision) source_revision="$2" ;;
        --terminal-revision) terminal_revision="$2" ;;
        --frame-revision) frame_revision="$2" ;;
        --version) version="$2" ;;
        --platform) platform="$2" ;;
        --architecture) architecture="$2" ;;
      esac
      shift 2
      ;;
    --codesign-identity)
      (($# >= 2)) || die "--codesign-identity requires a value"
      codesign_identity="$2"
      shift 2
      ;;
    --codesign-keychain)
      (($# >= 2)) || die "--codesign-keychain requires a value"
      codesign_keychain="$2"
      shift 2
      ;;
    --help|-h)
      printf 'usage: %s --payload-root <dir> --output <RuntimePack.tar.gz> --source-revision <sha> --terminal-revision <sha> --frame-revision <sha> --version <version> --platform <platform> --architecture <arch> [--codesign-identity <identity> [--codesign-keychain <path>]]\n' "$0"
      exit 0
      ;;
    *) die "unknown argument: $1" ;;
  esac
done

for required_value in output source_revision terminal_revision frame_revision version platform architecture; do
  [[ -n "${!required_value}" ]] || die "--$required_value is required"
done
[[ -n "$payload_root" ]] || die "--payload-root is required"

work="$(mktemp -d "${TMPDIR:-/tmp}/vibecrafted-runtime-pack-build.XXXXXX")"
# Trap-only cleanup follows the installer's bounded, status-preserving pattern.
# shellcheck disable=SC2329,SC2317
cleanup_runtime_pack() {
  local status=$?
  local _attempt
  if [[ -n "${work:-}" && -d "$work" ]]; then
    for _attempt in 1 2 3; do
      if rm -rf -- "$work" 2>/dev/null; then
        break
      fi
      sleep 0.05
    done
    if [[ -d "$work" ]]; then
      printf 'Runtime Pack build warning: could not remove temporary directory: %s\n' \
        "$work" >&2
    fi
  fi
  return "$status"
}
trap cleanup_runtime_pack EXIT
trap 'exit 130' INT
trap 'exit 143' TERM
trap 'exit 129' HUP
root="$work/VibecraftedRuntime"
mkdir -p "$root"
payload_root="$(cd "$payload_root" 2>/dev/null && pwd -P)" \
  || die "cannot resolve payload root"
cp -R "$payload_root/." "$root/"

# Finder metadata is mutable host state, not product input. Remove it at the
# final byte-owner boundary; the closed provenance writer below rejects a race
# that recreates it before inventory, and tar excludes a later race.
find "$root" -type f -name '.DS_Store' -delete

if find "$root" -type l -print -quit | grep -q .; then
  die "standalone Runtime Pack contains symlinks"
fi
for required in \
  VERSION bin/python3 bin/vibecrafted bin/vc-start bin/voc bin/vc-o \
  bin/vc-admin bin/vc-procs bin/vc-terminal bin/vc-frame \
  bin/scaffold-doctor \
  bin/control-observe \
  libexec/vc-frame libexec/vc-terminal \
  scripts/vibecrafted scripts/vetcoders_install.py \
  scripts/vc-terminal-product-entry.sh \
  vibecrafted-mcp/vibecrafted_mcp bin/vibecrafted-mcp \
  vibecrafted-core/vibecrafted_core/runtime_pack_contract.py; do
  [[ -e "$root/$required" ]] || die "standalone Runtime Pack is missing $required"
done

# The pack staging tree is the final byte owner. Sign only after every helper
# has reached its canonical Runtime Pack path, then verify those exact bytes
# before provenance captures them and before tar creates the carrier.
if [[ -n "$codesign_identity" ]]; then
  [[ "$platform" == "darwin-arm64" ]] \
    || die "--codesign-identity is valid only for a Darwin Runtime Pack"
  # The static linter cannot see that the sourced helper consumes these globals.
  # This sourced helper publishes a caller-visible result or status; its consumer lives outside this
  # file, so deleting the binding would break the shared helper contract.
  # shellcheck disable=SC2034
  SIGNING_IDENTITY="$codesign_identity"
  CODESIGN_KEYCHAIN_ARGS=()
  if [[ -n "$codesign_keychain" ]]; then
    # This sourced helper publishes a caller-visible result or status; its consumer lives outside
    # this file, so deleting the binding would break the shared helper contract.
    # shellcheck disable=SC2034
    CODESIGN_KEYCHAIN_ARGS=(--keychain "$codesign_keychain")
  fi
  host_entitlements="$work/host-entitlements.plist"
  PYTHONPATH="$REPO_ROOT/vibecrafted-core" "$REPO_ROOT/scripts/project-python" \
    "$REPO_ROOT/scripts/unified_product_manifest.py" host-permissions \
    --runtime-root "$root" --entitlements-output "$host_entitlements" >/dev/null
  sign_macho_tree "$root" "" "$root/libexec/vc-terminal" "$host_entitlements" \
    || die "could not sign final Runtime Pack Mach-O payload"
  # Seal any nested helper bundles inside-out, retaining the policy assigned
  # above. The flat terminal is internal code, not a second GUI app identity.
  sign_macho_app_bundles "$root" \
    || die "could not seal the final Runtime Pack .app bundles"
  verify_macho_tree "$root" 1 \
    || die "final Runtime Pack Mach-O signature preflight failed"
  PYTHONPATH="$REPO_ROOT/vibecrafted-core" "$REPO_ROOT/scripts/project-python" \
    "$REPO_ROOT/scripts/unified_product_manifest.py" host-permissions \
    --runtime-root "$root" --verify-only --verify-signatures >/dev/null
elif [[ -n "$codesign_keychain" ]]; then
  die "--codesign-keychain requires --codesign-identity"
fi

# Signing above takes minutes; Finder writes .DS_Store into any staging
# directory the operator happens to have open. That metadata is never a
# product input, so sweep it once more at the last sanctioned mutation point.
# Any file that appears after this line still fails the closed inventory.
find "$root" -type f -name '.DS_Store' -delete

# The release builder records the executable manifest (write-foundations)
# before it signs Mach-O files. This pack staging tree is the final byte owner,
# so rebind the manifest only after the last signing mutation and fail closed
# if anything changes again before provenance captures the payload.
PYTHONPATH="$root/vibecrafted-core" "$root/bin/python3" \
  -m vibecrafted_core.runtime_pack_contract refresh-foundations \
  --root "$root" >/dev/null

PYTHONPATH="$root/vibecrafted-core" "$root/bin/python3" \
  -m vibecrafted_core.runtime_pack_contract write \
  --root "$root" \
  --carrier-basename "$(basename "$output")" \
  --version "$version" \
  --platform "$platform" \
  --architecture "$architecture" \
  --source-revision "$source_revision" \
  --terminal-revision "$terminal_revision" \
  --frame-revision "$frame_revision" >/dev/null

mkdir -p "$(dirname "$output")"
candidate="$work/$(basename "$output")"
COPYFILE_DISABLE=1 tar --no-xattrs \
  --exclude='.DS_Store' --exclude='*/.DS_Store' \
  -czf "$candidate" -C "$work" VibecraftedRuntime
mv "$candidate" "$output"
(
  cd "$(dirname "$output")"
  if command -v shasum >/dev/null 2>&1; then
    shasum -a 256 "$(basename "$output")" > "$(basename "$output").sha256"
  else
    sha256sum "$(basename "$output")" > "$(basename "$output").sha256"
  fi
)
printf '%s\n' "$output"
