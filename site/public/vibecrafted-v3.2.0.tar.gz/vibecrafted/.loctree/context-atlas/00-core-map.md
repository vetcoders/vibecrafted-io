# Core Map

Project: `/Users/maciejgad/vc-workspace/vetcoders/vibecrafted`
Snapshot: `feat/runtime-integration@9f3d1d6`

This card tells you where you are, what is risky, and what actions are safe next.

```json
{
  "action": {
    "likely_tests": [],
    "next_safe_commands": [],
    "verification_gates": []
  },
  "authority": {
    "aicx_agent": [],
    "aicx_failure": [],
    "aicx_operator": [],
    "loctree_derived": [],
    "repo_verified": [
      "risk.cache_scope"
    ],
    "semantic_guess": [],
    "stale_or_unknown": [
      "action.verification_gates"
    ]
  },
  "project": {
    "branch": "feat/runtime-integration",
    "canonical_root": "/Users/maciejgad/vc-workspace/vetcoders/vibecrafted",
    "commit": "9f3d1d6",
    "snapshot_id": "feat_runtime-integration@9f3d1d6"
  },
  "risk": {
    "cache_scope": "MissingSnapshot",
    "cache_scope_authority": "repo_verified",
    "dirty_worktree": false,
    "high_fan_in": [],
    "hotspots": [],
    "snapshot_health": "missing_snapshot",
    "stale_snapshot": false
  },
  "schema_version": "1.0"
}
```

## What this card does not cover

This Core Map does not include dependency consumers, runtime entrypoints, or prior decisions. For code changes, read `01-structural-map.md` next.
