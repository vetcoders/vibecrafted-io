# Structural Map

Project: `/Users/polyversai/Libraxis/vc-runtime/vibecrafted`
Snapshot: `feat/runtime-integration@4e5faf4`

This card contains dependency and symbol topology for the selected scope.

```json
{
  "consumers": [
    {
      "authority": "repo_verified",
      "file": "bin/vc-agents",
      "import_kind": "direct",
      "imports_used": [
        "supervised_skill_main"
      ]
    },
    {
      "authority": "repo_verified",
      "file": "bin/vc-audit",
      "import_kind": "direct",
      "imports_used": [
        "audit_main"
      ]
    },
    {
      "authority": "repo_verified",
      "file": "bin/vc-dou",
      "import_kind": "direct",
      "imports_used": [
        "dou_main"
      ]
    },
    {
      "authority": "repo_verified",
      "file": "bin/vc-followup",
      "import_kind": "direct",
      "imports_used": [
        "supervised_skill_main"
      ]
    },
    {
      "authority": "repo_verified",
      "file": "bin/vc-hydrate",
      "import_kind": "direct",
      "imports_used": [
        "hydrate_main"
      ]
    },
    {
      "authority": "repo_verified",
      "file": "bin/vc-implement",
      "import_kind": "direct",
      "imports_used": [
        "supervised_skill_main"
      ]
    },
    {
      "authority": "repo_verified",
      "file": "bin/vc-marbles",
      "import_kind": "direct",
      "imports_used": [
        "marbles_main"
      ]
    },
    {
      "authority": "repo_verified",
      "file": "bin/vc-polarize",
      "import_kind": "direct",
      "imports_used": [
        "polarize_main"
      ]
    },
    {
      "authority": "repo_verified",
      "file": "bin/vc-prune",
      "import_kind": "direct",
      "imports_used": [
        "supervised_skill_main"
      ]
    },
    {
      "authority": "repo_verified",
      "file": "bin/vc-research",
      "import_kind": "direct",
      "imports_used": [
        "research_main"
      ]
    },
    {
      "authority": "repo_verified",
      "file": "bin/vc-research-await",
      "import_kind": "direct",
      "imports_used": [
        "research_await_main"
      ]
    },
    {
      "authority": "repo_verified",
      "file": "bin/vc-research-synthesize",
      "import_kind": "direct",
      "imports_used": [
        "research_synthesize_main"
      ]
    },
    {
      "authority": "repo_verified",
      "file": "bin/vc-review",
      "import_kind": "direct",
      "imports_used": [
        "supervised_skill_main"
      ]
    },
    {
      "authority": "repo_verified",
      "file": "bin/vc-scaffold",
      "import_kind": "direct",
      "imports_used": [
        "supervised_skill_main"
      ]
    },
    {
      "authority": "repo_verified",
      "file": "bin/vibecrafted-resume",
      "import_kind": "direct",
      "imports_used": [
        "resume_main"
      ]
    },
    {
      "authority": "repo_verified",
      "file": "scripts/control_plane_state.py",
      "import_kind": "direct",
      "imports_used": [
        "annotations",
        "control_plane"
      ]
    },
    {
      "authority": "repo_verified",
      "file": "scripts/installer_gui.py",
      "import_kind": "transitive",
      "imports_used": [
        "annotations",
        "Any",
        "launch_workflow",
        "normalize_launch_spec",
        "sync_state",
        "read_version_file",
        "vibecrafted_home",
        "xdg_config_home"
      ]
    },
    {
      "authority": "repo_verified",
      "file": "scripts/runtime_paths.py",
      "import_kind": "reexport",
      "imports_used": []
    },
    {
      "authority": "repo_verified",
      "file": "scripts/vetcoders_install.py",
      "import_kind": "transitive",
      "imports_used": [
        "read_version_file",
        "vibecrafted_launcher_bin",
        "vibecrafted_runtime_home",
        "vibecrafted_runtime_bin",
        "vibecrafted_tools_home",
        "vibecrafted_home",
        "xdg_config_home"
      ]
    },
    {
      "authority": "repo_verified",
      "file": "tests/agent_dispatch_test.py",
      "import_kind": "direct",
      "imports_used": [
        "annotations",
        "agent_dispatch"
      ]
    },
    {
      "authority": "repo_verified",
      "file": "tests/tui/test_default_runtime.py",
      "import_kind": "direct",
      "imports_used": [
        "annotations",
        "cli"
      ]
    },
    {
      "authority": "repo_verified",
      "file": "tests/tui/test_keys.py",
      "import_kind": "transitive",
      "imports_used": [
        "read_version_file",
        "vibecrafted_home"
      ]
    },
    {
      "authority": "repo_verified",
      "file": "tests/tui/test_research_terminal_safety.py",
      "import_kind": "direct",
      "imports_used": [
        "_launcher_paths"
      ]
    },
    {
      "authority": "repo_verified",
      "file": "vibecrafted-app/mux-agent/src/danger.rs",
      "import_kind": "direct",
      "imports_used": [
        "safe_copy_file",
        "safe_read_to_string"
      ]
    },
    {
      "authority": "repo_verified",
      "file": "vibecrafted-app/mux-agent/src/ipc/handlers.rs",
      "import_kind": "direct",
      "imports_used": [
        "scan_hosts"
      ]
    },
    {
      "authority": "repo_verified",
      "file": "vibecrafted-app/mux-agent/src/lib.rs",
      "import_kind": "reexport",
      "imports_used": [
        "CliOptions",
        "Config",
        "ResolvedParams",
        "ServerConfig",
        "resolve_params_multi",
        "config"
      ]
    },
    {
      "authority": "repo_verified",
      "file": "vibecrafted-app/mux-agent/src/main.rs",
      "import_kind": "direct",
      "imports_used": [
        "expand_path",
        "load_config",
        "resolve_params",
        "config"
      ]
    },
    {
      "authority": "repo_verified",
      "file": "vibecrafted-app/mux-agent/src/multi.rs",
      "import_kind": "direct",
      "imports_used": [
        "ResolvedParams"
      ]
    },
    {
      "authority": "repo_verified",
      "file": "vibecrafted-app/mux-agent/src/multi_tui.rs",
      "import_kind": "direct",
      "imports_used": [
        "StatusLevel"
      ]
    },
    {
      "authority": "repo_verified",
      "file": "vibecrafted-app/mux-agent/src/mux_gen.rs",
      "import_kind": "direct",
      "imports_used": [
        "Config",
        "ServerConfig",
        "expand_path"
      ]
    },
    {
      "authority": "repo_verified",
      "file": "vibecrafted-app/mux-agent/src/runtime/client.rs",
      "import_kind": "direct",
      "imports_used": [
        "HANDSHAKE_TIMEOUT",
        "MuxState",
        "Pending",
        "StatusSnapshot",
        "error_response",
        "publish_status",
        "set_id"
      ]
    },
    {
      "authority": "repo_verified",
      "file": "vibecrafted-app/mux-agent/src/runtime/heartbeat.rs",
      "import_kind": "direct",
      "imports_used": [
        "HeartbeatMetrics",
        "MuxState",
        "StatusSnapshot",
        "publish_status"
      ]
    },
    {
      "authority": "repo_verified",
      "file": "vibecrafted-app/mux-agent/src/runtime/mod.rs",
      "import_kind": "direct",
      "imports_used": [
        "ResolvedParams"
      ]
    },
    {
      "authority": "repo_verified",
      "file": "vibecrafted-app/mux-agent/src/runtime/server.rs",
      "import_kind": "direct",
      "imports_used": [
        "MuxState",
        "ServerStatus",
        "StatusSnapshot",
        "publish_status",
        "set_id"
      ]
    },
    {
      "authority": "repo_verified",
      "file": "vibecrafted-app/mux-agent/src/runtime/status.rs",
      "import_kind": "direct",
      "imports_used": [
        "MuxState",
        "ServerStatus",
        "StatusLevel",
        "StatusSnapshot"
      ]
    },
    {
      "authority": "repo_verified",
      "file": "vibecrafted-app/mux-agent/src/runtime/tests.rs",
      "import_kind": "direct",
      "imports_used": [
        "CliOptions",
        "Config",
        "ResolvedParams",
        "ServerConfig",
        "expand_path",
        "load_config",
        "resolve_params"
      ]
    },
    {
      "authority": "repo_verified",
      "file": "vibecrafted-app/mux-agent/src/scan.rs",
      "import_kind": "direct",
      "imports_used": [
        "Config",
        "ServerConfig",
        "expand_path",
        "safe_copy_file",
        "safe_read_to_string"
      ]
    },
    {
      "authority": "repo_verified",
      "file": "vibecrafted-app/mux-agent/src/tray.rs",
      "import_kind": "direct",
      "imports_used": [
        "ServerStatus",
        "StatusSnapshot"
      ]
    },
    {
      "authority": "repo_verified",
      "file": "vibecrafted-app/mux-agent/src/tray_dashboard.rs",
      "import_kind": "transitive",
      "imports_used": []
    },
    {
      "authority": "repo_verified",
      "file": "vibecrafted-app/mux-agent/src/wizard/mod.rs",
      "import_kind": "direct",
      "imports_used": [
        "expand_path"
      ]
    },
    {
      "authority": "repo_verified",
      "file": "vibecrafted-app/mux-agent/src/wizard/persist.rs",
      "import_kind": "direct",
      "imports_used": [
        "expand_path"
      ]
    },
    {
      "authority": "repo_verified",
      "file": "vibecrafted-app/mux-agent/src/wizard/services.rs",
      "import_kind": "direct",
      "imports_used": [
        "ServerConfig",
        "expand_path"
      ]
    },
    {
      "authority": "repo_verified",
      "file": "vibecrafted-app/mux-agent/src/wizard/types.rs",
      "import_kind": "direct",
      "imports_used": [
        "ServerConfig"
      ]
    },
    {
      "authority": "repo_verified",
      "file": "vibecrafted-app/mux-agent/src/wizard/ui.rs",
      "import_kind": "direct",
      "imports_used": [
        "HostKind"
      ]
    },
    {
      "authority": "repo_verified",
      "file": "vibecrafted-app/shell-agent/app/Vibecrafted/AppDelegate.swift",
      "import_kind": "direct",
      "imports_used": []
    },
    {
      "authority": "repo_verified",
      "file": "vibecrafted-app/shell-agent/app/Vibecrafted/Views/InspectorViewController.swift",
      "import_kind": "direct",
      "imports_used": []
    },
    {
      "authority": "repo_verified",
      "file": "vibecrafted-app/shell-agent/app/Vibecrafted/Views/MissionControlViewController.swift",
      "import_kind": "direct",
      "imports_used": []
    },
    {
      "authority": "repo_verified",
      "file": "vibecrafted-core/tests/dispatch/test_cli.py",
      "import_kind": "direct",
      "imports_used": [
        "annotations",
        "cli"
      ]
    },
    {
      "authority": "repo_verified",
      "file": "vibecrafted-core/tests/dispatch/test_schema.py",
      "import_kind": "direct",
      "imports_used": [
        "Baton",
        "CutState",
        "Matcher",
        "STATE_VERIFIED",
        "Verdict",
        "VerifierEvidence"
      ]
    },
    {
      "authority": "repo_verified",
      "file": "vibecrafted-core/tests/dispatch/test_supervisor.py",
      "import_kind": "direct",
      "imports_used": [
        "annotations",
        "workflow"
      ]
    },
    {
      "authority": "repo_verified",
      "file": "vibecrafted-core/tests/dispatch/test_verify.py",
      "import_kind": "direct",
      "imports_used": [
        "STATE_FAILED",
        "STATE_UNKNOWN",
        "STATE_VERIFIED",
        "Cut",
        "Matcher",
        "Verify"
      ]
    },
    {
      "authority": "repo_verified",
      "file": "vibecrafted-core/tests/test_agent_stream.py",
      "import_kind": "direct",
      "imports_used": [
        "_extract_tokens"
      ]
    },
    {
      "authority": "repo_verified",
      "file": "vibecrafted-core/tests/test_agy_junie_pipeline.py",
      "import_kind": "direct",
      "imports_used": [
        "annotations",
        "workflow"
      ]
    },
    {
      "authority": "repo_verified",
      "file": "vibecrafted-core/tests/test_aicx_sync.py",
      "import_kind": "direct",
      "imports_used": [
        "annotations",
        "Any",
        "aicx_sync"
      ]
    },
    {
      "authority": "repo_verified",
      "file": "vibecrafted-core/tests/test_capabilities.py",
      "import_kind": "direct",
      "imports_used": [
        "annotations",
        "capabilities"
      ]
    },
    {
      "authority": "repo_verified",
      "file": "vibecrafted-core/tests/test_cli.py",
      "import_kind": "direct",
      "imports_used": [
        "annotations",
        "cli",
        "__version__"
      ]
    },
    {
      "authority": "repo_verified",
      "file": "vibecrafted-core/tests/test_compact_hooks.py",
      "import_kind": "direct",
      "imports_used": [
        "annotations",
        "compact_hooks"
      ]
    },
    {
      "authority": "repo_verified",
      "file": "vibecrafted-core/tests/test_control_plane.py",
      "import_kind": "direct",
      "imports_used": [
        "annotations",
        "control_plane",
        "workflow"
      ]
    },
    {
      "authority": "repo_verified",
      "file": "vibecrafted-core/tests/test_cron.py",
      "import_kind": "direct",
      "imports_used": [
        "annotations",
        "cron"
      ]
    },
    {
      "authority": "repo_verified",
      "file": "vibecrafted-core/tests/test_doctor.py",
      "import_kind": "direct",
      "imports_used": [
        "annotations",
        "doctor"
      ]
    },
    {
      "authority": "repo_verified",
      "file": "vibecrafted-core/tests/test_git.py",
      "import_kind": "direct",
      "imports_used": [
        "annotations",
        "git"
      ]
    },
    {
      "authority": "repo_verified",
      "file": "vibecrafted-core/tests/test_lifecycle_runner.py",
      "import_kind": "direct",
      "imports_used": [
        "annotations",
        "ship",
        "wrappers"
      ]
    },
    {
      "authority": "repo_verified",
      "file": "vibecrafted-core/tests/test_loop_ship.py",
      "import_kind": "direct",
      "imports_used": [
        "annotations",
        "loop",
        "ship"
      ]
    },
    {
      "authority": "repo_verified",
      "file": "vibecrafted-core/tests/test_memex_client.py",
      "import_kind": "direct",
      "imports_used": [
        "annotations",
        "Any",
        "memex_client"
      ]
    },
    {
      "authority": "repo_verified",
      "file": "vibecrafted-core/tests/test_perception.py",
      "import_kind": "direct",
      "imports_used": [
        "annotations",
        "perception"
      ]
    },
    {
      "authority": "repo_verified",
      "file": "vibecrafted-core/tests/test_sandbox_adapter.py",
      "import_kind": "direct",
      "imports_used": [
        "annotations",
        "control_plane"
      ]
    },
    {
      "authority": "repo_verified",
      "file": "vibecrafted-core/tests/test_supervisor.py",
      "import_kind": "direct",
      "imports_used": [
        "annotations",
        "control_plane",
        "append_event"
      ]
    },
    {
      "authority": "repo_verified",
      "file": "vibecrafted-core/tests/test_supervisor_async.py",
      "import_kind": "direct",
      "imports_used": [
        "annotations",
        "dispatcher",
        "validate_artifacts",
        "read_event_tail",
        "RunState",
        "transition_allowed",
        "AsyncSupervisor"
      ]
    },
    {
      "authority": "repo_verified",
      "file": "vibecrafted-core/tests/test_ui.py",
      "import_kind": "direct",
      "imports_used": [
        "annotations",
        "ui"
      ]
    },
    {
      "authority": "repo_verified",
      "file": "vibecrafted-core/tests/test_workflow.py",
      "import_kind": "direct",
      "imports_used": [
        "annotations",
        "Any",
        "workflow"
      ]
    },
    {
      "authority": "repo_verified",
      "file": "vibecrafted-core/tests/test_workflow_registry.py",
      "import_kind": "direct",
      "imports_used": [
        "annotations",
        "workflow"
      ]
    },
    {
      "authority": "repo_verified",
      "file": "vibecrafted-core/tests/test_workflow_runtime.py",
      "import_kind": "direct",
      "imports_used": [
        "annotations",
        "workflow_runtime"
      ]
    },
    {
      "authority": "repo_verified",
      "file": "vibecrafted-core/tests/test_wrappers.py",
      "import_kind": "direct",
      "imports_used": [
        "annotations",
        "wrappers",
        "workflow"
      ]
    },
    {
      "authority": "repo_verified",
      "file": "vibecrafted-core/vibecrafted_core/__init__.py",
      "import_kind": "reexport",
      "imports_used": [
        "read_version_file",
        "resolve_env_path",
        "vibecrafted_home",
        "xdg_config_home"
      ]
    },
    {
      "authority": "repo_verified",
      "file": "vibecrafted-core/vibecrafted_core/capabilities.py",
      "import_kind": "direct",
      "imports_used": [
        "vibecrafted_launcher_bin"
      ]
    },
    {
      "authority": "repo_verified",
      "file": "vibecrafted-core/vibecrafted_core/cli.py",
      "import_kind": "direct",
      "imports_used": [
        "deck_path",
        "stop_main"
      ]
    },
    {
      "authority": "repo_verified",
      "file": "vibecrafted-core/vibecrafted_core/compact_hooks.py",
      "import_kind": "direct",
      "imports_used": [
        "vibecrafted_home"
      ]
    },
    {
      "authority": "repo_verified",
      "file": "vibecrafted-core/vibecrafted_core/control_plane.py",
      "import_kind": "direct",
      "imports_used": [
        "vibecrafted_home"
      ]
    },
    {
      "authority": "repo_verified",
      "file": "vibecrafted-core/vibecrafted_core/cron.py",
      "import_kind": "direct",
      "imports_used": [
        "vibecrafted_home"
      ]
    },
    {
      "authority": "repo_verified",
      "file": "vibecrafted-core/vibecrafted_core/dispatch/__init__.py",
      "import_kind": "reexport",
      "imports_used": [
        "Baton",
        "Common",
        "Cut",
        "CutState",
        "Dispatch",
        "Matcher",
        "Meta",
        "Phase",
        "Policy",
        "Recovery",
        "Verdict",
        "VerifierEvidence",
        "Verify"
      ]
    },
    {
      "authority": "repo_verified",
      "file": "vibecrafted-core/vibecrafted_core/dispatch/cli.py",
      "import_kind": "direct",
      "imports_used": [
        "Dispatch",
        "STATE_VERIFIED"
      ]
    },
    {
      "authority": "repo_verified",
      "file": "vibecrafted-core/vibecrafted_core/dispatch/doctor.py",
      "import_kind": "direct",
      "imports_used": [
        "Dispatch"
      ]
    },
    {
      "authority": "repo_verified",
      "file": "vibecrafted-core/vibecrafted_core/dispatch/schema.py",
      "import_kind": "direct",
      "imports_used": [
        "CRITICAL_FAIL_POLICIES",
        "MATCHER_TYPES",
        "READ_MUTATIONS",
        "SCHEMA_VERSION",
        "TIMEOUT_POLICIES",
        "Baton",
        "Common",
        "Cut",
        "Dispatch",
        "Matcher",
        "Meta",
        "Phase",
        "Policy",
        "Recovery",
        "Verify"
      ]
    },
    {
      "authority": "repo_verified",
      "file": "vibecrafted-core/vibecrafted_core/dispatch/supervisor.py",
      "import_kind": "direct",
      "imports_used": [
        "STATE_FAILED",
        "STATE_PENDING",
        "STATE_UNKNOWN",
        "STATE_VERIFIED",
        "STATE_WORKER_DONE",
        "Baton",
        "Cut",
        "Dispatch",
        "Verdict"
      ]
    },
    {
      "authority": "repo_verified",
      "file": "vibecrafted-core/vibecrafted_core/dispatch/verify.py",
      "import_kind": "direct",
      "imports_used": [
        "STATE_FAILED",
        "STATE_UNKNOWN",
        "STATE_VERIFIED",
        "Cut",
        "Verdict",
        "VerifierEvidence",
        "Verify"
      ]
    },
    {
      "authority": "repo_verified",
      "file": "vibecrafted-core/vibecrafted_core/sandbox/msbserver_lifecycle.py",
      "import_kind": "direct",
      "imports_used": [
        "vibecrafted_home"
      ]
    },
    {
      "authority": "repo_verified",
      "file": "vibecrafted-core/vibecrafted_core/sandbox/policy.py",
      "import_kind": "direct",
      "imports_used": [
        "vibecrafted_home"
      ]
    },
    {
      "authority": "repo_verified",
      "file": "vibecrafted-core/vibecrafted_core/workflow.py",
      "import_kind": "direct",
      "imports_used": [
        "_stdin_command"
      ]
    },
    {
      "authority": "repo_verified",
      "file": "vibecrafted-core/vibecrafted_core/workflow_runtime.py",
      "import_kind": "direct",
      "imports_used": [
        "_stdin_command"
      ]
    },
    {
      "authority": "repo_verified",
      "file": "vibecrafted-core/vibecrafted_core/workflows/registry.py",
      "import_kind": "direct",
      "imports_used": [
        "vibecrafted_tools_home"
      ]
    },
    {
      "authority": "repo_verified",
      "file": "vibecrafted-core/vibecrafted_core/wrappers.py",
      "import_kind": "direct",
      "imports_used": [
        "Supervisor"
      ]
    },
    {
      "authority": "repo_verified",
      "file": "vibecrafted-mcp/vibecrafted_mcp/server.py",
      "import_kind": "direct",
      "imports_used": [
        "annotations",
        "Any",
        "capabilities",
        "control_plane",
        "doctor",
        "git",
        "workflow"
      ]
    }
  ],
  "entrypoints": [
    {
      "authority": "repo_verified",
      "kinds": [
        "script"
      ],
      "path": "scripts/control_plane_state.py"
    },
    {
      "authority": "repo_verified",
      "kinds": [
        "script"
      ],
      "path": "scripts/installer_gui.py"
    },
    {
      "authority": "repo_verified",
      "kinds": [
        "script"
      ],
      "path": "scripts/vetcoders_install.py"
    },
    {
      "authority": "repo_verified",
      "kinds": [
        "main",
        "async_main"
      ],
      "path": "vibecrafted-app/mux-agent/src/main.rs"
    },
    {
      "authority": "repo_verified",
      "kinds": [
        "script"
      ],
      "path": "vibecrafted-core/vibecrafted_core/cli.py"
    },
    {
      "authority": "repo_verified",
      "kinds": [
        "script"
      ],
      "path": "vibecrafted-core/vibecrafted_core/compact_hooks.py"
    },
    {
      "authority": "repo_verified",
      "kinds": [
        "script"
      ],
      "path": "vibecrafted-core/vibecrafted_core/control_plane.py"
    },
    {
      "authority": "repo_verified",
      "kinds": [
        "script"
      ],
      "path": "vibecrafted-core/vibecrafted_core/cron.py"
    },
    {
      "authority": "repo_verified",
      "kinds": [
        "script"
      ],
      "path": "vibecrafted-core/vibecrafted_core/dispatch/cli.py"
    },
    {
      "authority": "repo_verified",
      "kinds": [
        "script"
      ],
      "path": "vibecrafted-core/vibecrafted_core/dispatch/doctor.py"
    },
    {
      "authority": "repo_verified",
      "kinds": [
        "script"
      ],
      "path": "vibecrafted-core/vibecrafted_core/perception.py"
    },
    {
      "authority": "repo_verified",
      "kinds": [
        "script"
      ],
      "path": "vibecrafted-core/vibecrafted_core/spawn.py"
    },
    {
      "authority": "repo_verified",
      "kinds": [
        "script"
      ],
      "path": "vibecrafted-core/vibecrafted_core/workflow_runtime.py"
    },
    {
      "authority": "repo_verified",
      "kinds": [
        "script"
      ],
      "path": "vibecrafted-mcp/vibecrafted_mcp/server.py"
    }
  ],
  "files": [
    {
      "authority": "repo_verified",
      "depth": 1,
      "language": "py",
      "loc": 12,
      "path": "bin/vc-agents",
      "role": "consumer"
    },
    {
      "authority": "repo_verified",
      "depth": 1,
      "language": "py",
      "loc": 12,
      "path": "bin/vc-audit",
// truncated: 3389 more line(s); run `loct context --full --json` for raw data

```

## What this card does not cover

This Structural Map does not include runtime behavior, env contracts, or verification gates. Read `02-runtime-map.md` and `04-verification-gates.md` before changing behavior.
