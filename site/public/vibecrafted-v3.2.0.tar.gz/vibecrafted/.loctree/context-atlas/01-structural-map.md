# Structural Map

Project: `/Users/maciejgad/vc-workspace/vetcoders/vibecrafted`
Snapshot: `feat/runtime-integration@9f3d1d6`

This card contains dependency and symbol topology for the selected scope.

```json
{
  "consumers": [],
  "entrypoints": [],
  "files": [],
  "imports": [],
  "symbols": []
}
```

## What this card does not cover

This Structural Map does not include runtime behavior, env contracts, or verification gates. Read `02-runtime-map.md` and `04-verification-gates.md` before changing behavior.
