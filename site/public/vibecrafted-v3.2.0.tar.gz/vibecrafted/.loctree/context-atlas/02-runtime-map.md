# Runtime Map

Project: `/Users/polyversai/Libraxis/vc-runtime/vibecrafted`
Snapshot: `feat/runtime-integration@4e5faf4`

This card contains runtime signals derived from semantic facts and framework bridges.

```json
{
  "dispatch_edges": [],
  "env_contracts": [
    {
      "authority": "loctree_derived",
      "name": "VIBECRAFTED_HOME",
      "occurrences": [
        {
          "access_kind": "os.environ.get",
          "file": "plugins/iterm2/vibecrafted_iterm2/vc_launcher.py",
          "line": 63,
          "required": true
        },
        {
          "access_kind": "os.environ[]",
          "file": "vibecrafted-core/vibecrafted_core/runtime_paths.py",
          "line": 30,
          "required": true
        },
        {
          "access_kind": "os.environ[]",
          "file": "vibecrafted-core/vibecrafted_core/runtime_paths.py",
          "line": 31,
          "required": true
        },
        {
          "access_kind": "os.environ[]",
          "file": "vibecrafted-mcp/tests/test_server.py",
          "line": 108,
          "required": true
        },
        {
          "access_kind": "os.environ[]",
          "file": "vibecrafted-mcp/tests/test_server.py",
          "line": 109,
          "required": true
        },
        {
          "access_kind": "os.environ[]",
          "file": "vibecrafted-mcp/tests/test_server.py",
          "line": 117,
          "required": true
        },
        {
          "access_kind": "os.environ.get",
          "file": "vibecrafted-mcp/vibecrafted_mcp/server.py",
          "line": 58,
          "required": true
        },
        {
          "access_kind": "os.environ[]",
          "file": "vibecrafted-mcp/vibecrafted_mcp/server.py",
          "line": 59,
          "required": true
        },
        {
          "access_kind": "os.environ[]",
          "file": "vibecrafted-mcp/vibecrafted_mcp/server.py",
          "line": 66,
          "required": true
        }
      ],
      "required": true,
      "required_for": [],
      "used_in_files": [
        "vibecrafted-core/vibecrafted_core/runtime/helpers/vetcoders-runtime-core.sh",
        "vibecrafted-core/vibecrafted_core/runtime/scripts/gemini_spawn.sh",
        "vibecrafted-core/vibecrafted_core/runtime/scripts/lib/lock.sh",
        "vibecrafted-core/vibecrafted_core/runtime/scripts/lib/session.sh",
        "vibecrafted-core/vibecrafted_core/runtime/scripts/lib/util.sh",
        "vibecrafted-core/vibecrafted_core/runtime/scripts/marbles_ctl.sh",
        "vibecrafted-core/vibecrafted_core/runtime/scripts/marbles_spawn.sh",
        "vibecrafted-core/vibecrafted_core/runtime/scripts/vibecrafted-await-watch.sh",
        "vibecrafted-core/vibecrafted_core/runtime/shell/lib/dispatch.sh",
        "vibecrafted-core/vibecrafted_core/runtime/shell/lib/dispatch_wrappers.sh",
        "vibecrafted-core/vibecrafted_core/runtime/shell/lib/marbles.sh",
        "vibecrafted-core/vibecrafted_core/runtime/shell/lib/observe.sh",
        "vibecrafted-core/vibecrafted_core/runtime/shell/lib/ulimits.sh",
        "vibecrafted-core/vibecrafted_core/runtime/shell/vetcoders.sh",
        "vibecrafted-core/vibecrafted_core/runtime/vc-operator/mission-control/common.sh",
        "scripts/install-runtime.sh",
        "plugins/iterm2/vibecrafted_iterm2/vc_launcher.py",
        "vibecrafted-core/vibecrafted_core/runtime_paths.py",
        "vibecrafted-mcp/tests/test_server.py",
        "vibecrafted-mcp/vibecrafted_mcp/server.py"
      ]
    },
    {
      "authority": "loctree_derived",
      "name": "VIBECRAFTED_RUN_ID",
      "occurrences": [
        {
          "access_kind": "os.environ.get",
          "file": "vibecrafted-core/vibecrafted_core/spawn.py",
          "line": 847,
          "required": true
        },
        {
          "access_kind": "os.environ.get",
          "default": "\"workflow-runtime\"",
          "file": "vibecrafted-core/vibecrafted_core/workflow_runtime.py",
          "line": 51,
          "required": false
        },
        {
          "access_kind": "os.environ.get",
          "file": "vibecrafted-core/vibecrafted_core/wrappers.py",
          "line": 121,
          "required": true
        },
        {
          "access_kind": "os.environ.get",
          "file": "vibecrafted-core/vibecrafted_core/wrappers.py",
          "line": 145,
          "required": true
        },
        {
          "access_kind": "os.environ.get",
          "file": "vibecrafted-core/vibecrafted_core/wrappers.py",
          "line": 270,
          "required": true
        }
      ],
      "required": true,
      "required_for": [],
      "used_in_files": [
        "vibecrafted-core/vibecrafted_core/runtime/scripts/lib/launcher.sh",
        "vibecrafted-core/vibecrafted_core/runtime/scripts/lib/paths.sh",
        "vibecrafted-core/vibecrafted_core/runtime/scripts/lib/session_ambient.sh",
        "vibecrafted-core/vibecrafted_core/runtime/scripts/lib/vc_frame.sh",
        "vibecrafted-core/vibecrafted_core/spawn.py",
        "vibecrafted-core/vibecrafted_core/workflow_runtime.py",
        "vibecrafted-core/vibecrafted_core/wrappers.py"
      ]
    }
  ],
  "framework_hints": [
    {
      "authority": "loctree_derived",
      "detail": "Defined inside inherent `impl HostKind` block; reached via method-call syntax.",
      "file": "vibecrafted-app/mux-agent/src/scan.rs",
      "kind": "rust:inherent_impl_method",
      "line": null,
      "symbol": "vibecrafted-app/mux-agent/src/scan.rs::as_label"
    },
    {
      "authority": "loctree_derived",
      "detail": "Defined inside inherent `impl HostKind` block; reached via method-call syntax.",
      "file": "vibecrafted-app/mux-agent/src/scan.rs",
      "kind": "rust:inherent_impl_method",
      "line": null,
      "symbol": "vibecrafted-app/mux-agent/src/scan.rs::display_name"
    },
    {
      "authority": "loctree_derived",
      "detail": "Defined inside inherent `impl DiscoveredMcp` block; reached via method-call syntax.",
      "file": "vibecrafted-app/mux-agent/src/scan.rs",
      "kind": "rust:inherent_impl_method",
      "line": null,
      "symbol": "vibecrafted-app/mux-agent/src/scan.rs::into_host_service"
    },
    {
      "authority": "loctree_derived",
      "detail": "Defined inside inherent `impl MuxState` block; reached via method-call syntax.",
      "file": "vibecrafted-app/mux-agent/src/state.rs",
      "kind": "rust:inherent_impl_method",
      "line": null,
      "symbol": "vibecrafted-app/mux-agent/src/state.rs::buffer_message"
    },
    {
      "authority": "loctree_derived",
      "detail": "Defined inside inherent `impl MuxState` block; reached via method-call syntax.",
      "file": "vibecrafted-app/mux-agent/src/state.rs",
      "kind": "rust:inherent_impl_method",
      "line": null,
      "symbol": "vibecrafted-app/mux-agent/src/state.rs::complete_handshake"
    },
    {
      "authority": "loctree_derived",
      "detail": "Defined inside inherent `impl MuxState` block; reached via method-call syntax.",
      "file": "vibecrafted-app/mux-agent/src/state.rs",
      "kind": "rust:inherent_impl_method",
      "line": null,
      "symbol": "vibecrafted-app/mux-agent/src/state.rs::get_handshake_mut"
    },
    {
      "authority": "loctree_derived",
      "detail": "Defined inside inherent `impl MuxState` block; reached via method-call syntax.",
      "file": "vibecrafted-app/mux-agent/src/state.rs",
      "kind": "rust:inherent_impl_method",
      "line": null,
      "symbol": "vibecrafted-app/mux-agent/src/state.rs::is_handshake_complete"
    },
    {
      "authority": "loctree_derived",
      "detail": "Defined inside inherent `impl MuxState` block; reached via method-call syntax.",
      "file": "vibecrafted-app/mux-agent/src/state.rs",
      "kind": "rust:inherent_impl_method",
      "line": null,
      "symbol": "vibecrafted-app/mux-agent/src/state.rs::is_handshake_timed_out"
    },
    {
      "authority": "loctree_derived",
      "detail": "Defined inside inherent `impl MuxState` block; reached via method-call syntax.",
      "file": "vibecrafted-app/mux-agent/src/state.rs",
      "kind": "rust:inherent_impl_method",
      "line": null,
      "symbol": "vibecrafted-app/mux-agent/src/state.rs::mark_handshake_complete"
    },
    {
      "authority": "loctree_derived",
      "detail": "Defined inside inherent `impl MuxState` block; reached via method-call syntax.",
      "file": "vibecrafted-app/mux-agent/src/state.rs",
      "kind": "rust:inherent_impl_method",
      "line": null,
      "symbol": "vibecrafted-app/mux-agent/src/state.rs::new"
    },
    {
      "authority": "loctree_derived",
      "detail": "Defined inside inherent `impl MuxState` block; reached via method-call syntax.",
      "file": "vibecrafted-app/mux-agent/src/state.rs",
      "kind": "rust:inherent_impl_method",
      "line": null,
      "symbol": "vibecrafted-app/mux-agent/src/state.rs::next_request_id"
    },
    {
      "authority": "loctree_derived",
      "detail": "Defined inside inherent `impl MuxState` block; reached via method-call syntax.",
      "file": "vibecrafted-app/mux-agent/src/state.rs",
      "kind": "rust:inherent_impl_method",
      "line": null,
      "symbol": "vibecrafted-app/mux-agent/src/state.rs::register_client"
    },
    {
      "authority": "loctree_derived",
      "detail": "Defined inside inherent `impl MuxState` block; reached via method-call syntax.",
      "file": "vibecrafted-app/mux-agent/src/state.rs",
      "kind": "rust:inherent_impl_method",
      "line": null,
      "symbol": "vibecrafted-app/mux-agent/src/state.rs::unregister_client"
    },
    {
      "authority": "repo_verified",
      "detail": null,
      "file": "vibecrafted-core/vibecrafted_core/spawn.py",
      "kind": "entrypoint",
      "line": null,
      "symbol": "script"
    }
  ],
  "idiom_tags": [
    {
      "authority": "semantic_guess",
      "classifier": "rust:inherent_impl_method",
      "name": "as_label",
      "reasoning": "Defined inside inherent `impl HostKind` block; reached via method-call syntax.",
      "runtime_role": "library_helper",
      "source": "inferred_from_code",
      "symbol": "vibecrafted-app/mux-agent/src/scan.rs::as_label"
    },
    {
      "authority": "semantic_guess",
      "classifier": "rust:inherent_impl_method",
      "name": "display_name",
      "reasoning": "Defined inside inherent `impl HostKind` block; reached via method-call syntax.",
      "runtime_role": "library_helper",
      "source": "inferred_from_code",
      "symbol": "vibecrafted-app/mux-agent/src/scan.rs::display_name"
    },
    {
      "authority": "semantic_guess",
      "classifier": "rust:inherent_impl_method",
      "name": "into_host_service",
      "reasoning": "Defined inside inherent `impl DiscoveredMcp` block; reached via method-call syntax.",
      "runtime_role": "library_helper",
      "source": "inferred_from_code",
      "symbol": "vibecrafted-app/mux-agent/src/scan.rs::into_host_service"
    },
    {
      "authority": "semantic_guess",
      "classifier": "rust:inherent_impl_method",
      "name": "buffer_message",
      "reasoning": "Defined inside inherent `impl MuxState` block; reached via method-call syntax.",
      "runtime_role": "library_helper",
      "source": "inferred_from_code",
      "symbol": "vibecrafted-app/mux-agent/src/state.rs::buffer_message"
    },
    {
      "authority": "semantic_guess",
      "classifier": "rust:inherent_impl_method",
      "name": "complete_handshake",
      "reasoning": "Defined inside inherent `impl MuxState` block; reached via method-call syntax.",
      "runtime_role": "library_helper",
      "source": "inferred_from_code",
      "symbol": "vibecrafted-app/mux-agent/src/state.rs::complete_handshake"
    },
    {
      "authority": "semantic_guess",
      "classifier": "rust:inherent_impl_method",
      "name": "get_handshake_mut",
      "reasoning": "Defined inside inherent `impl MuxState` block; reached via method-call syntax.",
      "runtime_role": "library_helper",
      "source": "inferred_from_code",
      "symbol": "vibecrafted-app/mux-agent/src/state.rs::get_handshake_mut"
    },
    {
      "authority": "semantic_guess",
      "classifier": "rust:inherent_impl_method",
      "name": "is_handshake_complete",
      "reasoning": "Defined inside inherent `impl MuxState` block; reached via method-call syntax.",
      "runtime_role": "library_helper",
      "source": "inferred_from_code",
      "symbol": "vibecrafted-app/mux-agent/src/state.rs::is_handshake_complete"
    },
    {
      "authority": "semantic_guess",
      "classifier": "rust:inherent_impl_method",
      "name": "is_handshake_timed_out",
      "reasoning": "Defined inside inherent `impl MuxState` block; reached via method-call syntax.",
      "runtime_role": "library_helper",
      "source": "inferred_from_code",
      "symbol": "vibecrafted-app/mux-agent/src/state.rs::is_handshake_timed_out"
    },
    {
      "authority": "semantic_guess",
      "classifier": "rust:inherent_impl_method",
      "name": "mark_handshake_complete",
      "reasoning": "Defined inside inherent `impl MuxState` block; reached via method-call syntax.",
      "runtime_role": "library_helper",
      "source": "inferred_from_code",
      "symbol": "vibecrafted-app/mux-agent/src/state.rs::mark_handshake_complete"
    },
    {
      "authority": "loctree_derived",
      "classifier": "library_helper",
      "name": "new",
      "reasoning": "Idiomatic Rust constructor convention; called via Type::new(...) across the ecosystem.",
      "runtime_role": "library_helper",
      "source": "embedded_default",
      "symbol": "vibecrafted-app/mux-agent/src/state.rs::new"
    },
    {
      "authority": "semantic_guess",
      "classifier": "rust:inherent_impl_method",
      "name": "next_request_id",
      "reasoning": "Defined inside inherent `impl MuxState` block; reached via method-call syntax.",
      "runtime_role": "library_helper",
      "source": "inferred_from_code",
      "symbol": "vibecrafted-app/mux-agent/src/state.rs::next_request_id"
    },
    {
      "authority": "semantic_guess",
      "classifier": "rust:inherent_impl_method",
      "name": "register_client",
      "reasoning": "Defined inside inherent `impl MuxState` block; reached via method-call syntax.",
      "runtime_role": "library_helper",
      "source": "inferred_from_code",
      "symbol": "vibecrafted-app/mux-agent/src/state.rs::register_client"
    },
    {
      "authority": "semantic_guess",
      "classifier": "rust:inherent_impl_method",
      "name": "unregister_client",
      "reasoning": "Defined inside inherent `impl MuxState` block; reached via method-call syntax.",
      "runtime_role": "library_helper",
      "source": "inferred_from_code",
      "symbol": "vibecrafted-app/mux-agent/src/state.rs::unregister_client"
    },
    {
      "authority": "loctree_derived",
      "classifier": "primary_entrypoint",
      "name": "main",
      "reasoning": "Convention entrypoint called from `if __name__ == '__main__':` blocks and `console_scripts` entry points.",
      "runtime_role": "primary_entrypoint",
      "source": "embedded_default",
      "symbol": "vibecrafted-core/vibecrafted_core/spawn.py::main"
    }
  ],
  "reachability": [
    {
      "authority": "semantic_guess",
      "reached": true,
      "reason": "idiom_runtime_role:library_helper",
      "symbol": "vibecrafted-app/mux-agent/src/scan.rs::as_label"
    },
    {
      "authority": "semantic_guess",
      "reached": true,
      "reason": "idiom_runtime_role:library_helper",
      "symbol": "vibecrafted-app/mux-agent/src/scan.rs::display_name"
    },
    {
      "authority": "semantic_guess",
      "reached": true,
      "reason": "idiom_runtime_role:library_helper",
      "symbol": "vibecrafted-app/mux-agent/src/scan.rs::into_host_service"
    },
    {
      "authority": "semantic_guess",
      "reached": true,
      "reason": "idiom_runtime_role:library_helper",
      "symbol": "vibecrafted-app/mux-agent/src/state.rs::buffer_message"
    },
    {
      "authority": "semantic_guess",
      "reached": true,
      "reason": "idiom_runtime_role:library_helper",
      "symbol": "vibecrafted-app/mux-agent/src/state.rs::complete_handshake"
    },
    {
      "authority": "semantic_guess",
      "reached": true,
      "reason": "idiom_runtime_role:library_helper",
      "symbol": "vibecrafted-app/mux-agent/src/state.rs::get_handshake_mut"
    },
    {
      "authority": "semantic_guess",
      "reached": true,
      "reason": "idiom_runtime_role:library_helper",
      "symbol": "vibecrafted-app/mux-agent/src/state.rs::is_handshake_complete"
    },
    {
      "authority": "semantic_guess",
      "reached": true,
      "reason": "idiom_runtime_role:library_helper",
      "symbol": "vibecrafted-app/mux-agent/src/state.rs::is_handshake_timed_out"
    },
    {
      "authority": "semantic_guess",
      "reached": true,
      "reason": "idiom_runtime_role:library_helper",
      "symbol": "vibecrafted-app/mux-agent/src/state.rs::mark_handshake_complete"
    },
    {
      "authority": "semantic_guess",
      "reached": true,
      "reason": "idiom_runtime_role:library_helper",
      "symbol": "vibecrafted-app/mux-agent/src/state.rs::new"
    },
    {
      "authority": "semantic_guess",
      "reached": true,
      "reason": "idiom_runtime_role:library_helper",
      "symbol": "vibecrafted-app/mux-agent/src/state.rs::next_request_id"
    },
    {
      "authority": "semantic_guess",
      "reached": true,
      "reason": "idiom_runtime_role:library_helper",
      "symbol": "vibecrafted-app/mux-agent/src/state.rs::register_client"
    },
    {
      "authority": "semantic_guess",
      "reached": true,
      "reason": "idiom_runtime_role:library_helper",
      "symbol": "vibecrafted-app/mux-agent/src/state.rs::unregister_client"
    },
    {
      "authority": "semantic_guess",
      "reached": true,
      "reason": "idiom_runtime_role:primary_entrypoint",
      "symbol": "vibecrafted-core/vibecrafted_core/spawn.py::main"
    }
  ],
  "tauri_commands": [],
  "tauri_events": []
}
```

## What this card does not cover

This Runtime Map does not include prior decisions or full risk history. Read `03-memory-trail.md` when continuing work and `05-risk-register.md` before release decisions.
