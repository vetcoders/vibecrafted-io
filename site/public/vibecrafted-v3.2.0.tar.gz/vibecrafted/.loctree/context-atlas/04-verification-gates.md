# Verification Gates

Project: `/Users/maciejgad/vc-workspace/vetcoders/vibecrafted`
Snapshot: `feat/runtime-integration@9f3d1d6`

This card lists likely verification commands and tests derived from the current context.

```json
{
  "likely_tests": [],
  "next_safe_commands": [],
  "risk": {
    "cache_scope": "MissingSnapshot",
    "cache_scope_authority": "repo_verified",
    "dirty_worktree": false,
    "high_fan_in": [],
    "hotspots": [],
    "snapshot_health": "missing_snapshot",
    "stale_snapshot": false
  }
}
```

## What this card does not cover

This Verification Gates card does not prove correctness by itself. Run the commands before release or submit.
