# Verification Gates

Project: `/Users/polyversai/Libraxis/vc-runtime/vibecrafted`
Snapshot: `feat/runtime-integration@4e5faf4`

This card lists likely verification commands and tests derived from the current context.

```json
{
  "likely_tests": [
    "tests/agent_dispatch_test.py",
    "tests/tui/test_default_runtime.py",
    "tests/tui/test_keys.py",
    "tests/tui/test_research_terminal_safety.py",
    "vibecrafted-app/tui-agent/tests/state_contract.rs",
    "vibecrafted-core/tests/dispatch/test_cli.py",
    "vibecrafted-core/tests/dispatch/test_doctor.py",
    "vibecrafted-core/tests/dispatch/test_schema.py",
    "vibecrafted-core/tests/dispatch/test_supervisor.py",
    "vibecrafted-core/tests/dispatch/test_verify.py"
  ],
  "next_safe_commands": [
    "loct slice vibecrafted-core/vibecrafted_core/__init__.py",
    "loct impact vibecrafted-core/vibecrafted_core/__init__.py",
    "loct find annotations"
  ],
  "risk": {
    "cache_scope": "Clean",
    "cache_scope_authority": "repo_verified",
    "dirty_worktree": false,
    "high_fan_in": [
      {
        "authority": "loctree_derived",
        "file": "vibecrafted-core/vibecrafted_core/__init__.py",
        "importers": 27,
        "threshold": 10
      },
      {
        "authority": "loctree_derived",
        "file": "vibecrafted-core/vibecrafted_core/wrappers.py",
        "importers": 17,
        "threshold": 10
      },
      {
        "authority": "loctree_derived",
        "file": "vibecrafted-app/mux-agent/src/config.rs",
        "importers": 13,
        "threshold": 10
      },
      {
        "authority": "loctree_derived",
        "file": "vibecrafted-app/mux-agent/src/state.rs",
        "importers": 12,
        "threshold": 10
      },
      {
        "authority": "loctree_derived",
        "file": "vibecrafted-app/mux-agent/src/scan.rs",
        "importers": 10,
        "threshold": 10
      },
      {
        "authority": "loctree_derived",
        "file": "vibecrafted-core/vibecrafted_core/dispatch/model.py",
        "importers": 10,
        "threshold": 10
      },
      {
        "authority": "loctree_derived",
        "file": "vibecrafted-core/vibecrafted_core/runtime_paths.py",
        "importers": 10,
        "threshold": 10
      }
    ],
    "hotspots": [
      {
        "authority": "loctree_derived",
        "file": "vibecrafted-core/vibecrafted_core/__init__.py",
        "importers": 27
      },
      {
        "authority": "loctree_derived",
        "file": "vibecrafted-core/vibecrafted_core/wrappers.py",
        "importers": 17
      },
      {
        "authority": "loctree_derived",
        "file": "vibecrafted-app/mux-agent/src/config.rs",
        "importers": 13
      },
      {
        "authority": "loctree_derived",
        "file": "vibecrafted-app/mux-agent/src/state.rs",
        "importers": 12
      },
      {
        "authority": "loctree_derived",
        "file": "vibecrafted-app/mux-agent/src/scan.rs",
        "importers": 10
      },
      {
        "authority": "loctree_derived",
        "file": "vibecrafted-core/vibecrafted_core/dispatch/model.py",
        "importers": 10
      },
      {
        "authority": "loctree_derived",
        "file": "vibecrafted-core/vibecrafted_core/runtime_paths.py",
        "importers": 10
      },
      {
        "authority": "loctree_derived",
        "file": "vibecrafted-core/vibecrafted_core/spawn.py",
        "importers": 9
      }
    ],
    "snapshot_health": "fresh",
    "stale_snapshot": false
  }
}
```

## What this card does not cover

This Verification Gates card does not prove correctness by itself. Run the commands before release or submit.
