# Risk Register

Project: `/Users/polyversai/Libraxis/vc-runtime/vibecrafted`
Snapshot: `feat/runtime-integration@4e5faf4`

This card collects risk signals and recommended actions for the current context scope.

```json
{
  "action": {
    "likely_tests": [
      "tests/agent_dispatch_test.py",
      "tests/tui/test_default_runtime.py",
      "tests/tui/test_keys.py",
      "tests/tui/test_research_terminal_safety.py",
      "vibecrafted-app/tui-agent/tests/state_contract.rs",
      "vibecrafted-core/tests/dispatch/test_cli.py",
      "vibecrafted-core/tests/dispatch/test_doctor.py",
      "vibecrafted-core/tests/dispatch/test_schema.py",
      "vibecrafted-core/tests/dispatch/test_supervisor.py",
      "vibecrafted-core/tests/dispatch/test_verify.py"
    ],
    "next_safe_commands": [
      "loct slice vibecrafted-core/vibecrafted_core/__init__.py",
      "loct impact vibecrafted-core/vibecrafted_core/__init__.py",
      "loct find annotations"
    ],
    "power_path": [
      {
        "command": "loct slice vibecrafted-core/vibecrafted_core/__init__.py",
        "reason": "Slice this file to inspect its direct dependencies and immediate consumers before editing."
      },
      {
        "command": "loct impact vibecrafted-core/vibecrafted_core/__init__.py",
        "reason": "Assess the transitive blast radius and downstream consumers of this file before modifying."
      },
      {
        "command": "loct body annotations",
        "reason": "View the definition body of symbol 'annotations' to understand its implementation structure."
      },
      {
        "command": "loct find --literal annotations",
        "reason": "Execute a literal exact-identifier scan for 'annotations' to find exact matches across the codebase."
      },
      {
        "command": "loct occurrences annotations",
        "reason": "Perform a literal boundary-sensitive occurrences scan for 'annotations' to locate all references."
      },
      {
        "command": "loct follow",
        "reason": "Pursue unified structural signals (dead exports, import cycles, twins) to ensure health."
      },
      {
        "command": "loct slice vibecrafted-core/vibecrafted_core/wrappers.py",
        "reason": "Slice this file to inspect its direct dependencies and immediate consumers before editing."
      },
      {
        "command": "loct impact vibecrafted-core/vibecrafted_core/wrappers.py",
        "reason": "Assess the transitive blast radius and downstream consumers of this file before modifying."
      },
      {
        "command": "loct body repo_root",
        "reason": "View the definition body of symbol 'repo_root' to understand its implementation structure."
      },
      {
        "command": "loct find --literal repo_root",
        "reason": "Execute a literal exact-identifier scan for 'repo_root' to find exact matches across the codebase."
      },
      {
        "command": "loct occurrences repo_root",
        "reason": "Perform a literal boundary-sensitive occurrences scan for 'repo_root' to locate all references."
      },
      {
        "command": "loct slice vibecrafted-app/mux-agent/src/config.rs",
        "reason": "Slice this file to inspect its direct dependencies and immediate consumers before editing."
      },
      {
        "command": "loct impact vibecrafted-app/mux-agent/src/config.rs",
        "reason": "Assess the transitive blast radius and downstream consumers of this file before modifying."
      },
      {
        "command": "loct body expand_path",
        "reason": "View the definition body of symbol 'expand_path' to understand its implementation structure."
      },
      {
        "command": "loct find --literal expand_path",
        "reason": "Execute a literal exact-identifier scan for 'expand_path' to find exact matches across the codebase."
      },
      {
        "command": "loct occurrences expand_path",
        "reason": "Perform a literal boundary-sensitive occurrences scan for 'expand_path' to locate all references."
      },
      {
        "command": "loct slice vibecrafted-app/mux-agent/src/state.rs",
        "reason": "Slice this file to inspect its direct dependencies and immediate consumers before editing."
      },
      {
        "command": "loct impact vibecrafted-app/mux-agent/src/state.rs",
        "reason": "Assess the transitive blast radius and downstream consumers of this file before modifying."
      },
      {
        "command": "loct body new",
        "reason": "View the definition body of symbol 'new' to understand its implementation structure."
      },
      {
        "command": "loct find --literal new",
        "reason": "Execute a literal exact-identifier scan for 'new' to find exact matches across the codebase."
      },
      {
        "command": "loct occurrences new",
        "reason": "Perform a literal boundary-sensitive occurrences scan for 'new' to locate all references."
      },
      {
        "command": "loct slice vibecrafted-app/mux-agent/src/scan.rs",
        "reason": "Slice this file to inspect its direct dependencies and immediate consumers before editing."
      },
      {
        "command": "loct impact vibecrafted-app/mux-agent/src/scan.rs",
        "reason": "Assess the transitive blast radius and downstream consumers of this file before modifying."
      },
      {
        "command": "loct body as_label",
        "reason": "View the definition body of symbol 'as_label' to understand its implementation structure."
      },
      {
        "command": "loct find --literal as_label",
        "reason": "Execute a literal exact-identifier scan for 'as_label' to find exact matches across the codebase."
      },
      {
        "command": "loct occurrences as_label",
        "reason": "Perform a literal boundary-sensitive occurrences scan for 'as_label' to locate all references."
      },
      {
        "command": "loct slice vibecrafted-core/vibecrafted_core/dispatch/model.py",
        "reason": "Slice this file to inspect its direct dependencies and immediate consumers before editing."
      },
      {
        "command": "loct impact vibecrafted-core/vibecrafted_core/dispatch/model.py",
        "reason": "Assess the transitive blast radius and downstream consumers of this file before modifying."
      },
      {
        "command": "loct body Meta",
        "reason": "View the definition body of symbol 'Meta' to understand its implementation structure."
      },
      {
        "command": "loct find --literal Meta",
        "reason": "Execute a literal exact-identifier scan for 'Meta' to find exact matches across the codebase."
      },
      {
        "command": "loct occurrences Meta",
        "reason": "Perform a literal boundary-sensitive occurrences scan for 'Meta' to locate all references."
      },
      {
        "command": "loct slice vibecrafted-core/vibecrafted_core/runtime_paths.py",
        "reason": "Slice this file to inspect its direct dependencies and immediate consumers before editing."
      },
      {
        "command": "loct impact vibecrafted-core/vibecrafted_core/runtime_paths.py",
        "reason": "Assess the transitive blast radius and downstream consumers of this file before modifying."
      },
      {
        "command": "loct body read_version_file",
        "reason": "View the definition body of symbol 'read_version_file' to understand its implementation structure."
      },
      {
        "command": "loct find --literal read_version_file",
        "reason": "Execute a literal exact-identifier scan for 'read_version_file' to find exact matches across the codebase."
      },
      {
        "command": "loct occurrences read_version_file",
        "reason": "Perform a literal boundary-sensitive occurrences scan for 'read_version_file' to locate all references."
      },
      {
        "command": "loct slice vibecrafted-core/vibecrafted_core/spawn.py",
        "reason": "Slice this file to inspect its direct dependencies and immediate consumers before editing."
      },
      {
        "command": "loct impact vibecrafted-core/vibecrafted_core/spawn.py",
        "reason": "Assess the transitive blast radius and downstream consumers of this file before modifying."
      },
      {
        "command": "loct body SpawnHandle",
        "reason": "View the definition body of symbol 'SpawnHandle' to understand its implementation structure."
      },
      {
        "command": "loct find --literal SpawnHandle",
        "reason": "Execute a literal exact-identifier scan for 'SpawnHandle' to find exact matches across the codebase."
      },
      {
        "command": "loct occurrences SpawnHandle",
        "reason": "Perform a literal boundary-sensitive occurrences scan for 'SpawnHandle' to locate all references."
      }
    ],
    "verification_gates": [
      "mypy ."
    ]
  },
  "authority": {
    "aicx_agent": [
      "memory.entries.d9b62a5a-197c-4dd8-8-h13c039::outcome",
      "memory.entries.019ecb2f-35db-7952-8-h302f60::task",
      "memory.entries.d9b62a5a-197c-4dd8-8-h13c039::outcome",
      "memory.entries.019ecb2f-35db-7952-8-h302f60::outcome",
      "memory.entries.019ecb2f-35db-7952-8-h302f60::outcome",
      "memory.entries.019ecb2f-35db-7952-8-h302f60::task",
      "memory.entries.d9b62a5a-197c-4dd8-8-h13c039::outcome",
      "memory.entries.d9b62a5a-197c-4dd8-8-h13c039::outcome",
      "memory.entries.019ecb2f-35db-7952-8-h302f60::outcome",
      "memory.entries.019ecb2f-35db-7952-8-h302f60::outcome",
      "memory.entries.019ecb2f-35db-7952-8-h302f60::outcome",
      "memory.entries.019ecb2f-35db-7952-8-h302f60::outcome",
      "memory.entries.019ecb2f-35db-7952-8-h302f60::task",
      "memory.entries.d9b62a5a-197c-4dd8-8-h13c039::outcome",
      "memory.entries.d9b62a5a-197c-4dd8-8-h13c039::outcome",
      "memory.entries.d9b62a5a-197c-4dd8-8-h13c039::outcome",
      "memory.entries.d9b62a5a-197c-4dd8-8-h13c039::outcome",
      "memory.entries.d9b62a5a-197c-4dd8-8-h13c039::outcome",
      "memory.entries.d9b62a5a-197c-4dd8-8-h13c039::outcome",
      "memory.entries.d9b62a5a-197c-4dd8-8-h13c039::outcome",
      "memory.entries.019ecb2f-35db-7952-8-h302f60::outcome",
      "memory.entries.019ecb2f-35db-7952-8-h302f60::outcome",
      "memory.entries.019ecb2f-35db-7952-8-h302f60::outcome",
      "memory.entries.019ecb2f-35db-7952-8-h302f60::outcome",
      "memory.entries.019ecb2f-35db-7952-8-h302f60::outcome",
      "memory.entries.019ecb2f-35db-7952-8-h302f60::outcome",
      "memory.entries.019ecb2f-35db-7952-8-h302f60::task",
      "memory.entries.d9b62a5a-197c-4dd8-8-h13c039::outcome",
      "memory.entries.d9b62a5a-197c-4dd8-8-h13c039::outcome",
      "memory.entries.d9b62a5a-197c-4dd8-8-h13c039::outcome",
      "memory.entries.d9b62a5a-197c-4dd8-8-h13c039::outcome",
      "memory.entries.d9b62a5a-197c-4dd8-8-h13c039::outcome",
      "memory.entries.d9b62a5a-197c-4dd8-8-h13c039::outcome",
      "memory.entries.d9b62a5a-197c-4dd8-8-h13c039::outcome"
    ],
    "aicx_failure": [],
    "aicx_operator": [
      "memory.entries.f17d7869-26c3-463e-9-h16fb9c::decision",
      "memory.entries.019ecb2f-35db-7952-8-h302f60::intent",
      "memory.entries.f17d7869-26c3-463e-9-h16fb9c::decision",
      "memory.entries.f17d7869-26c3-463e-9-h16fb9c::decision",
      "memory.entries.d9b62a5a-197c-4dd8-8-h13c039::intent",
      "memory.entries.019ecb2f-35db-7952-8-h302f60::intent",
      "memory.entries.f17d7869-26c3-463e-9-h16fb9c::decision",
      "memory.entries.f17d7869-26c3-463e-9-h16fb9c::decision",
      "memory.entries.d9b62a5a-197c-4dd8-8-h13c039::intent",
      "memory.entries.019ecb2f-35db-7952-8-h302f60::intent",
      "memory.entries.019ecb2f-35db-7952-8-h302f60::intent",
      "memory.entries.0ab8e4a5-b6da-4c9d-a-h34aca9::decision",
      "memory.entries.f17d7869-26c3-463e-9-h16fb9c::decision",
      "memory.entries.f17d7869-26c3-463e-9-h16fb9c::decision",
      "memory.entries.f17d7869-26c3-463e-9-h16fb9c::decision",
      "memory.entries.d9b62a5a-197c-4dd8-8-h13c039::intent"
    ],
    "loctree_derived": [
      "runtime.idiom_tags.vibecrafted-app/mux-agent/src/state.rs::new::new",
      "runtime.idiom_tags.vibecrafted-core/vibecrafted_core/spawn.py::main::main",
      "runtime.env_contracts.VIBECRAFTED_HOME",
      "runtime.env_contracts.VIBECRAFTED_RUN_ID",
      "runtime.framework_hints.rust:inherent_impl_method.vibecrafted-app/mux-agent/src/scan.rs::as_label",
      "runtime.framework_hints.rust:inherent_impl_method.vibecrafted-app/mux-agent/src/scan.rs::display_name",
      "runtime.framework_hints.rust:inherent_impl_method.vibecrafted-app/mux-agent/src/scan.rs::into_host_service",
      "runtime.framework_hints.rust:inherent_impl_method.vibecrafted-app/mux-agent/src/state.rs::buffer_message",
      "runtime.framework_hints.rust:inherent_impl_method.vibecrafted-app/mux-agent/src/state.rs::complete_handshake",
      "runtime.framework_hints.rust:inherent_impl_method.vibecrafted-app/mux-agent/src/state.rs::get_handshake_mut",
      "runtime.framework_hints.rust:inherent_impl_method.vibecrafted-app/mux-agent/src/state.rs::is_handshake_complete",
      "runtime.framework_hints.rust:inherent_impl_method.vibecrafted-app/mux-agent/src/state.rs::is_handshake_timed_out",
      "runtime.framework_hints.rust:inherent_impl_method.vibecrafted-app/mux-agent/src/state.rs::mark_handshake_complete",
      "runtime.framework_hints.rust:inherent_impl_method.vibecrafted-app/mux-agent/src/state.rs::new",
      "runtime.framework_hints.rust:inherent_impl_method.vibecrafted-app/mux-agent/src/state.rs::next_request_id",
      "runtime.framework_hints.rust:inherent_impl_method.vibecrafted-app/mux-agent/src/state.rs::register_client",
      "runtime.framework_hints.rust:inherent_impl_method.vibecrafted-app/mux-agent/src/state.rs::unregister_client",
      "risk.hotspots.vibecrafted-core/vibecrafted_core/__init__.py",
      "risk.hotspots.vibecrafted-core/vibecrafted_core/wrappers.py",
      "risk.hotspots.vibecrafted-app/mux-agent/src/config.rs",
      "risk.hotspots.vibecrafted-app/mux-agent/src/state.rs",
      "risk.hotspots.vibecrafted-app/mux-agent/src/scan.rs",
      "risk.hotspots.vibecrafted-core/vibecrafted_core/dispatch/model.py",
      "risk.hotspots.vibecrafted-core/vibecrafted_core/runtime_paths.py",
      "risk.hotspots.vibecrafted-core/vibecrafted_core/spawn.py",
      "risk.high_fan_in.vibecrafted-core/vibecrafted_core/__init__.py",
      "risk.high_fan_in.vibecrafted-core/vibecrafted_core/wrappers.py",
      "risk.high_fan_in.vibecrafted-app/mux-agent/src/config.rs",
      "risk.high_fan_in.vibecrafted-app/mux-agent/src/state.rs",
      "risk.high_fan_in.vibecrafted-app/mux-agent/src/scan.rs",
      "risk.high_fan_in.vibecrafted-core/vibecrafted_core/dispatch/model.py",
      "risk.high_fan_in.vibecrafted-core/vibecrafted_core/runtime_paths.py",
      "action.likely_tests.tests/agent_dispatch_test.py",
      "action.likely_tests.tests/tui/test_default_runtime.py",
      "action.likely_tests.tests/tui/test_keys.py",
      "action.likely_tests.tests/tui/test_research_terminal_safety.py",
      "action.likely_tests.vibecrafted-app/tui-agent/tests/state_contract.rs",
      "action.likely_tests.vibecrafted-core/tests/dispatch/test_cli.py",
      "action.likely_tests.vibecrafted-core/tests/dispatch/test_doctor.py",
      "action.likely_tests.vibecrafted-core/tests/dispatch/test_schema.py",
      "action.likely_tests.vibecrafted-core/tests/dispatch/test_supervisor.py",
      "action.likely_tests.vibecrafted-core/tests/dispatch/test_verify.py",
      "action.next_safe_commands.loct slice vibecrafted-core/vibecrafted_core/__init__.py",
      "action.next_safe_commands.loct impact vibecrafted-core/vibecrafted_core/__init__.py",
      "action.next_safe_commands.loct find annotations",
      "action.verification_gates.mypy ."
    ],
    "repo_verified": [
      "runtime.framework_hints.entrypoint.script",
      "risk.cache_scope"
    ],
    "semantic_guess": [
      "runtime.idiom_tags.vibecrafted-app/mux-agent/src/scan.rs::as_label::as_label",
      "runtime.idiom_tags.vibecrafted-app/mux-agent/src/scan.rs::display_name::display_name",
      "runtime.idiom_tags.vibecrafted-app/mux-agent/src/scan.rs::into_host_service::into_host_service",
      "runtime.idiom_tags.vibecrafted-app/mux-agent/src/state.rs::buffer_message::buffer_message",
      "runtime.idiom_tags.vibecrafted-app/mux-agent/src/state.rs::complete_handshake::complete_handshake",
      "runtime.idiom_tags.vibecrafted-app/mux-agent/src/state.rs::get_handshake_mut::get_handshake_mut",
      "runtime.idiom_tags.vibecrafted-app/mux-agent/src/state.rs::is_handshake_complete::is_handshake_complete",
      "runtime.idiom_tags.vibecrafted-app/mux-agent/src/state.rs::is_handshake_timed_out::is_handshake_timed_out",
      "runtime.idiom_tags.vibecrafted-app/mux-agent/src/state.rs::mark_handshake_complete::mark_handshake_complete",
      "runtime.idiom_tags.vibecrafted-app/mux-agent/src/state.rs::next_request_id::next_request_id",
      "runtime.idiom_tags.vibecrafted-app/mux-agent/src/state.rs::register_client::register_client",
      "runtime.idiom_tags.vibecrafted-app/mux-agent/src/state.rs::unregister_client::unregister_client",
      "runtime.reachability.reached.vibecrafted-app/mux-agent/src/scan.rs::as_label",
      "runtime.reachability.reached.vibecrafted-app/mux-agent/src/scan.rs::display_name",
      "runtime.reachability.reached.vibecrafted-app/mux-agent/src/scan.rs::into_host_service",
      "runtime.reachability.reached.vibecrafted-app/mux-agent/src/state.rs::buffer_message",
      "runtime.reachability.reached.vibecrafted-app/mux-agent/src/state.rs::complete_handshake",
      "runtime.reachability.reached.vibecrafted-app/mux-agent/src/state.rs::get_handshake_mut",
      "runtime.reachability.reached.vibecrafted-app/mux-agent/src/state.rs::is_handshake_complete",
      "runtime.reachability.reached.vibecrafted-app/mux-agent/src/state.rs::is_handshake_timed_out",
      "runtime.reachability.reached.vibecrafted-app/mux-agent/src/state.rs::mark_handshake_complete",
      "runtime.reachability.reached.vibecrafted-app/mux-agent/src/state.rs::new",
      "runtime.reachability.reached.vibecrafted-app/mux-agent/src/state.rs::next_request_id",
      "runtime.reachability.reached.vibecrafted-app/mux-agent/src/state.rs::register_client",
      "runtime.reachability.reached.vibecrafted-app/mux-agent/src/state.rs::unregister_client",
      "runtime.reachability.reached.vibecrafted-core/vibecrafted_core/spawn.py::main"
    ],
    "stale_or_unknown": []
  },
  "risk": {
    "cache_scope": "Clean",
    "cache_scope_authority": "repo_verified",
    "dirty_worktree": false,
    "high_fan_in": [
      {
        "authority": "loctree_derived",
        "file": "vibecrafted-core/vibecrafted_core/__init__.py",
        "importers": 27,
        "threshold": 10
      },
      {
        "authority": "loctree_derived",
        "file": "vibecrafted-core/vibecrafted_core/wrappers.py",
        "importers": 17,
        "threshold": 10
      },
      {
        "authority": "loctree_derived",
        "file": "vibecrafted-app/mux-agent/src/config.rs",
        "importers": 13,
        "threshold": 10
      },
      {
        "authority": "loctree_derived",
        "file": "vibecrafted-app/mux-agent/src/state.rs",
        "importers": 12,
        "threshold": 10
      },
      {
        "authority": "loctree_derived",
        "file": "vibecrafted-app/mux-agent/src/scan.rs",
        "importers": 10,
        "threshold": 10
      },
      {
        "authority": "loctree_derived",
        "file": "vibecrafted-core/vibecrafted_core/dispatch/model.py",
        "importers": 10,
        "threshold": 10
      },
      {
        "authority": "loctree_derived",
        "file": "vibecrafted-core/vibecrafted_core/runtime_paths.py",
        "importers": 10,
        "threshold": 10
      }
    ],
    "hotspots": [
      {
        "authority": "loctree_derived",
        "file": "vibecrafted-core/vibecrafted_core/__init__.py",
        "importers": 27
      },
      {
        "authority": "loctree_derived",
        "file": "vibecrafted-core/vibecrafted_core/wrappers.py",
        "importers": 17
      },
      {
        "authority": "loctree_derived",
        "file": "vibecrafted-app/mux-agent/src/config.rs",
        "importers": 13
      },
      {
        "authority": "loctree_derived",
        "file": "vibecrafted-app/mux-agent/src/state.rs",
        "importers": 12
      },
      {
        "authority": "loctree_derived",
        "file": "vibecrafted-app/mux-agent/src/scan.rs",
        "importers": 10
      },
      {
        "authority": "loctree_derived",
        "file": "vibecrafted-core/vibecrafted_core/dispatch/model.py",
        "importers": 10
      },
      {
        "authority": "loctree_derived",
        "file": "vibecrafted-core/vibecrafted_core/runtime_paths.py",
        "importers": 10
      },
      {
        "authority": "loctree_derived",
        "file": "vibecrafted-core/vibecrafted_core/spawn.py",
        "importers": 9
      }
    ],
    "snapshot_health": "fresh",
    "stale_snapshot": false
  }
}
```

## What this card does not cover

This Risk Register does not include full source content. Use `loct slice`/`loct impact` for exact file-level surgery.
