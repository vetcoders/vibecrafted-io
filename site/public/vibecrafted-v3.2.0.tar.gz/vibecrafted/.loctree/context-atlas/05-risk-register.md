# Risk Register

Project: `/Users/maciejgad/vc-workspace/vetcoders/vibecrafted`
Snapshot: `feat/runtime-integration@9f3d1d6`

This card collects risk signals and recommended actions for the current context scope.

```json
{
  "action": {
    "likely_tests": [],
    "next_safe_commands": [],
    "verification_gates": []
  },
  "authority": {
    "aicx_agent": [],
    "aicx_failure": [],
    "aicx_operator": [],
    "loctree_derived": [],
    "repo_verified": [
      "risk.cache_scope"
    ],
    "semantic_guess": [],
    "stale_or_unknown": [
      "action.verification_gates"
    ]
  },
  "risk": {
    "cache_scope": "MissingSnapshot",
    "cache_scope_authority": "repo_verified",
    "dirty_worktree": false,
    "high_fan_in": [],
    "hotspots": [],
    "snapshot_health": "missing_snapshot",
    "stale_snapshot": false
  }
}
```

## What this card does not cover

This Risk Register does not include full source content. Use `loct slice`/`loct impact` for exact file-level surgery.
