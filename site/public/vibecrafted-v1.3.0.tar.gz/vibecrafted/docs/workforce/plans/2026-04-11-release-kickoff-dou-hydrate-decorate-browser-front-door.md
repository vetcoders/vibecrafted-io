---
agent: codex
focus: release kickoff through dou-hydrate-decorate
priority: P0
status: pending
created: 2026-04-11T00:00:00+02:00
---

# Release Kickoff Through DoU, Hydrate, Decorate

Przeprowadź pełną sekwencję `vc-dou -> vc-hydrate -> vc-decorate` na tym repo i zostaw je w stanie realnego pre-release kick-offu.

## Repo i powierzchnie

Główne repo:
- `~/Libraxis/vibecrafted`

Powiązany portal / landing / public face:
- `~/Libraxis/01_deployed_libraxis_vm/vibecrafted-io/`

Referencje intencji instalatora:
- `~/Libraxis/01_deployed_libraxis_vm/rmcp-memex`
- `../TwinSweep`

Kanoniczne referencje instalatora:
- `docs/installer/0_welcome_step.zsh.md`
- `docs/installer/1_Explain_step.zsh.md`
- `docs/installer/2_listing.zsh.md`
- `docs/installer/3_examine.zsh.md`
- `docs/installer/4_result.zsh.md`
- `docs/installer/5_installation.zsh.md`
- `docs/installer/DESIGN.md`
- `docs/installer/REFERENCE.md`
- `docs/installer/SCAFFOLD.md`

## Najważniejsza intencja

To NIE jest zadanie o kolejnym runtime refactorze.
To jest zadanie o domknięciu produktu do release’u.

Celem jest:
- spolaryzować i wyostrzyć publiczną obietnicę produktu
- doprowadzić publiczny surface, install path i kickoff artifacts do stanu launch-ready
- zostawić repo w stanie przedprodukcyjnym, gotowym do skutecznego kick-offu
- usunąć rozjazd między tym, co produkt obiecuje, a tym, co realnie dowozi

Jeśli jakaś funkcjonalność jest istotnie wartościowa, ale niedomaga, wolno ją poprawić lub przeimplementować we właściwy sposób.
Ale nie wolno odpływać w przypadkowe surgery na runtime, marbles, common.sh, watcherach, spawnach itp., jeśli nie służy to bezpośrednio release pathowi.

## Ważny stan wejściowy

Browser/front-door installer path już działa.
Traktuj to jako ważny sygnał kierunkowy, nie jako eksperyment do zastąpienia.

To znaczy:
- effortless browser/front-door jest obecnie preferowaną ścieżką wejścia
- nie cofaj tego do samego TUI-only flow
- nie buduj nowej równoległej architektury instalatora
- TUI/CLI ma pozostać truthful engine / deeper operator path
- browser/front-door ma być doprowadzony do releaseowego poziomu jakości i spójności
- browser GUI ma być **one-page wizardem bez scrollowania**

## Mandatory entry: AICX first, then regular refresh

Na starcie i w trakcie pracy regularnie korzystaj z `aicx-mcp`.
To jest główne źródło intencji twórców.

Szukaj szczególnie:
- intencji wokół `dou / hydrate / decorate`
- intencji wokół release prep / kickoff / marketplace / submission
- intencji wokół instalatora TUI/GUI
- relacji między:
  - wizard/TUI z `rmcp-memex`
  - effortless GUI/front-door z `../TwinSweep`
  - mockami z `docs/installer/*`

Nie zgaduj intencji, jeśli możesz ją odzyskać z AICX.

## Installer decision contract

Masz zbadać intencje odnośnie instalatora TUI/GUI i ich związku z:
- TUI z `rmcp-memex`
- python/swift GUI z `../TwinSweep`

Następnie wybierz i dowieź JEDNĄ bardziej effortless opcję z tych dwóch, zgodną z mockami w `docs/installer`.

Ważne:
- jeśli browser/front-door już działa i jest zgodny z intencją effortless path, traktuj to jako aktualnie wygrany kierunek
- nie przepalaj czasu na nowy wielki rewrite TUI, jeśli nie jest to najwyższy leverage dla release
- skup się na tym, by install path był spójny, prawdziwy, zrozumiały i gotowy do pokazania ludziom
- browser GUI ma pozostać one-page wizardem bez scrollowania

## Główne zadania

### 1. DoU na całej powierzchni produktu

Zrób prawdziwy audit repo + install path + public surface + marketplace readiness:
- repo health
- docs i onboarding
- installability
- representation surface
- discoverability
- commercial readiness
- credibility gaps
- submission readiness

### 2. Hydrate

Na podstawie DoU domknij brakujące rzeczy, szczególnie:
- release kickoff pack
- marketplace / submission forms / listing drafts
- positioning copy
- public install path
- onboarding / quick start
- landing / showcase / representation layer
- SEO / meta / social preview / docs cohesion
- release-facing docs i handoff artifacts

### 3. Decorate

Dopracuj tylko to, co zwiększa coherence i premium feel release surface:
- landing
- install front door
- docs / quick start / public-facing surfaces
- CLI / installer output tam, gdzie wpływa na perception i trust

Nie dekoruj chaosu.
Najpierw spójność, potem polish.

## Research requirement

Zbadaj aktualne marketplaces / submission surfaces dla podobnych awesome AI tools i przygotuj:
- listę sensownych target marketplaces
- wymagane metadata / forms
- submission-ready copy
- opis pozycji produktu względem podobnych narzędzi

To ma być praktyczne, nie akademickie.

## Scope discipline

IN SCOPE:
- release readiness
- installer/front-door truth
- public promise
- landing / docs / kickoff artifacts
- marketplace / submission pack
- coherence polish na surfaces związanych z release

OUT OF SCOPE:
- przypadkowe refaktory runtime core
- broad marbles surgery
- common.sh modularization dla samej modularization
- watcher/spawn refactors, jeśli nie są bezpośrednio wymagane przez release/install path
- budowanie równoległego alternatywnego systemu

## Living tree rule

To żywe repo.
Nie revertuj cudzych zmian bez potrzeby.
Pracuj precyzyjnie i czytaj aktualny stan przed edycją.

## Delivery standard

Nie kończ na planie ani analizie.
Masz dowieźć realne zmiany w repo i zostawić je w stanie pre-release.

Na końcu dostarcz:
1. krótkie executive summary
2. co zostało dowiezione
3. co jest launch-ready
4. co jeszcze wymaga ręcznego ruchu człowieka
5. gdzie leżą:
   - kickoff pack
   - submission forms / listing drafts
   - install front door artifacts
   - najważniejsze release docs

## Verification

Zweryfikuj realnie:
- public/install/front-door path
- quick start
- docs spójność
- release surface
- najważniejsze testy / gates adekwatne do zmian

Jeśli coś nie przechodzi, nie zamiataj tego.
Nazwij to wprost.

## Meta rule

Najlepszy wynik tego zadania wygląda tak:
repo nie jest „bardziej technicznie interesujące”.
Repo jest bardziej gotowe do pokazania światu, zainstalowania, zrozumienia i uruchomienia.
