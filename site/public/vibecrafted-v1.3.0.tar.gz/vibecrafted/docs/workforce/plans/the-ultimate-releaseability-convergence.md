---
agent: codex
focus: releaseability convergence
priority: P0
status: active
created: 2026-04-10T14:05:00+02:00
---

# The Ultimate Releaseability Convergence

## Mission

Turn Vibecrafted from a repo that works for its authors into a product runtime
that remains truthful, updateable, recoverable, and operable for real users on
real machines over time.

This is not a patch train. This is convergence on one coherent product shape:
one runtime truth, one operator truth, one install/update truth, one release
truth.

## Destination

The finished system has the following properties, all at once:

- Runtime orchestration tells the truth under stress. Failed starts do not
  masquerade as progress, fallback artifacts do not drive completion, and every
  surface agrees on the current state.
- Operator session management is thin, explicit, and native to Zellij. There is
  one canonical repo/run operator session, dashboards are layouts or tabs inside
  that truth, and the framework stops inventing sibling session semantics that
  Zellij itself does not own.
- The install surface is first-class for curl-or-bash users. A user without
  `.git/` has a sanctioned forward path to new releases and hotfixes.
- The update path replaces drift instead of accumulating it. Orphaned runtime
  files do not survive silently across reinstalls and updates.
- Doctor verifies the runtime that users actually execute, not only the shape
  of symlinks and binaries.
- Releaseability is proven across machines, shells, terminal states, and live
  agent workloads, not inferred from one author workstation and one green local
  pytest run.

## Product Truth

Vibecrafted is releaseable only when all of these are true:

- A troubled run is legible: which round is alive, which attempt failed, why it
  failed, what recovery action is active, and where the operator can inspect
  transcript and report truth.
- The framework does not create contradictory Zellij realities. There is one
  canonical operator session contract, and dashboard commands act as thin repo
  flavored wrappers around native Zellij capabilities instead of a shadow
  session manager.
- `vibecrafted update` is real for installed users, not only for git checkouts.
- `install.sh` resolves latest release truth by default instead of pinning a
  stale archive forever.
- Update and install semantics distinguish between additive first install and
  replacement-grade update, with deletion or rollback protection where needed.
- `doctor` can detect runtime drift, stale installed files, incompatible CLI
  stream contracts, and broken spawn pipelines before a user loses a work
  session.
- Release readiness is validated with cross-machine and headless smoke, not
  only with author-local tests.

## Non-Negotiable Invariants

- Shell remains the implementation language for orchestration.
- `common.sh` stays the stable consumer contract while internals modularize.
- `meta.json` is authoritative for attempt truth.
- `state.json` is authoritative for run truth.
- Fallback reports are forensic only.
- Zellij remains the session source of truth.
- Vibecrafted adds repo context, layout taste, and operator ergonomics, but it
  does not fake a second session model.
- Curl-or-bash users are first-class citizens, not second-class repo readers.

## Required Convergence

### 1. Truthful Self-Healing Runtime

The runtime must implement the self-healing contract already emerging from
today's work:

- first startup probe at 10 seconds
- transcript growth probe at 60 seconds
- immediate classification for explicit auth failures
- retry same round, not fake advancement
- bounded retry budget
- round-local handoff only after retry exhaustion
- no contradictory launcher, watcher, transcript, or dashboard messaging

### 2. Single Session Semantics

Session handling must converge on one model:

- one canonical operator session per repo or active run
- `vibecrafted start` and workflow entry commands attach or create that truth
- dashboard surfaces become layout or tab views inside that same truth
- list, attach, and switch delegate transparently to Zellij semantics
- mission-control panes remain monitors, not fake session authorities

### 3. Real Update Path For Installed Users

The product must expose a real update channel:

- `vibecrafted update` works without `.git/`
- installed version is compared against latest release truth
- latest release resolution is dynamic
- update stages a new runtime cleanly, verifies it, and flips atomically
- stale files do not survive by accident

### 4. Doctor As Runtime Auditor

Doctor must become a live runtime auditor, not a symlink census:

- detect runtime tree drift versus dev tree or staged release payload
- detect stale installed files after update
- smoke-test spawn pipeline end to end with controlled fake agents
- validate CLI stream compatibility for current Codex, Claude, and Gemini
- surface headless and `TERM=dumb` sensitivity explicitly

### 5. Release Gates That Reflect Reality

Release readiness must be proven through:

- multi-machine smoke
- non-interactive and headless smoke
- Zellij and non-Zellij launch paths
- installed-runtime smoke for curl-or-bash users
- live stream bridge compatibility
- update path verification from an already installed older release

## Scope

Primary surfaces likely to participate:

- `scripts/vibecrafted`
- `install.sh`
- `Makefile`
- `scripts/vetcoders_install.py`
- `skills/vc-agents/shell/vetcoders.sh`
- `skills/vc-agents/scripts/common.sh`
- `skills/vc-agents/scripts/lib/*.sh`
- `skills/vc-agents/scripts/*_spawn.sh`
- `skills/vc-agents/scripts/marbles_*.sh`
- `config/zellij/layouts/*.kdl`
- `tests/tui/*.py`
- portable and doctor gates

## Verification Standard

This effort is complete only when the system can survive the following without
lying:

- SSH-auth failure for an agent CLI
- malformed or evolving live stream payloads
- stale installed runtime files from previous versions
- dashboard and operator session churn
- headless or dumb-terminal startup
- an installed user updating forward without repository access

## Source Material

Today's intent landscape to honor and converge:

- [2026-04-10-runtime-self-healing-and-modularization.md](/Users/polyversai/Libraxis/vibecrafted/docs/superpowers/plans/2026-04-10-runtime-self-healing-and-modularization.md)
- [2026-04-09-common-sh-modularization-design.md](/Users/polyversai/Libraxis/vibecrafted/docs/superpowers/specs/2026-04-09-common-sh-modularization-design.md)
- [2026-04-09-marbles-steering-design.md](/Users/polyversai/Libraxis/vibecrafted/docs/superpowers/specs/2026-04-09-marbles-steering-design.md)
- [2026-04-09-commit-labels-design.md](/Users/polyversai/Libraxis/vibecrafted/docs/superpowers/specs/2026-04-09-commit-labels-design.md)

## Finish Condition

Vibecrafted is done only when a user can install it without source, update it
without folklore, operate it without session schizophrenia, and trust it when a
run goes wrong.
