---
agent: codex
focus: runtime self-healing and modularization
priority: P0
status: active
created: 2026-04-10T02:05:00+02:00
---

# Vibecrafted Runtime Self-Healing and Modularization

## Mission

Turn the Vibecrafted orchestration runtime into a shell-native system that tells
the truth under stress and heals locally before it escalates. The runtime must
stop confusing activity with health, stop advancing rounds to hide failed
starts, and stop letting launcher, watcher, and fallback artifacts contradict
one another.

## Current Truth

The foundation is partly there already:

- `common.sh` is now a real aggregator over `lib/*.sh`.
- GOD / ANCESTOR / CHILDREN plan steering is real.
- `meta.json` keyed by `run_id` is the authoritative lookup surface for loop
  artifacts.
- Failed child-loop scheduling can now materialize a truthful failed loop
  instead of degrading into `meta-missing` fiction.
- `--file` is a real input mode and no longer silently degrades into prompt text.
- temp command paths are normalized and no longer leak `T//...` ugliness.

But the runtime is still not self-healing in the intended sense:

- there is no same-round attempt ledger
- there is no `3x retry same round` policy
- there is no round-local agent handoff after retry exhaustion
- startup monitoring still prints UX that is too optimistic and too generic
- dashboard hints still print unconditionally, even on obvious failure
- duplicate/contradictory operator output is not fully eliminated
- commit-label and agent-ownership telemetry remain a design, not a runtime fact

## Destination

The finished runtime behaves like this:

- A round owns one or more attempts. Round number advances only after a real
  successful completion.
- The first startup probe fires at 10 seconds and answers one question only:
  did any real agent activity begin?
- The second probe fires at 60 seconds and answers one question only:
  is the authoritative transcript still growing?
- Explicit auth failures fail the current attempt immediately; they do not wait
  for the 60-second growth probe.
- A stalled attempt retries the same round.
- Retry budget is 3 attempts per round.
- After the retry budget is exhausted, only that same round may hand off to the
  next healthy agent in the pool.
- If the handoff agent succeeds, the next round returns to the normal steering
  source of truth.
- If every eligible agent fails that round, the run ends as failed.
- `meta.json` is the sole authority for attempt state, transcript path, report
  path, session id, and completion telemetry.
- `state.json` is the run ledger: rounds, attempts, ownership, recovery action,
  and final run status.
- Fallback reports are forensic artifacts only. They never drive `done`,
  progression, or convergence on their own.
- Startup monitor, launcher, watcher, and convergence report cannot contradict
  each other.
- Operator output answers: which round, which attempt, which agent, what
  failure, what recovery action, which transcript, which report.

## Scope

Runtime code:

- `skills/vc-agents/scripts/common.sh`
- `skills/vc-agents/scripts/lib/*.sh`
- `skills/vc-agents/scripts/marbles_spawn.sh`
- `skills/vc-agents/scripts/marbles_watcher.sh`
- `skills/vc-agents/scripts/marbles_next.sh`
- `skills/vc-agents/scripts/claude_spawn.sh`
- `skills/vc-agents/scripts/codex_spawn.sh`
- `skills/vc-agents/scripts/gemini_spawn.sh`
- `skills/vc-agents/shell/vetcoders.sh`

Primary verification:

- `tests/tui/test_spawn_common.py`
- `tests/tui/test_marbles_runtime.py`
- `tests/tui/test_operator_mode.py`
- any adjacent portable/runtime gates needed to prove the shell contract

## Non-Negotiable Invariants

- A failed attempt never pretends to be a finished round.
- A round advances only after authoritative completion.
- Recovery actions belong to the current round, not to a fake next round.
- Operator-facing text must describe reality, not optimism.
- Shell remains the implementation language.
- `source "$SCRIPT_DIR/common.sh"` remains the stable consumer contract.

## Structural Target

`common.sh` remains a thin entry surface. Runtime concerns must stay separable:

- path and store resolution
- metadata and run ledger truth
- prompt and report contract generation
- session and ambient-run identity
- launcher execution and exit handling
- zellij and terminal integration
- startup monitoring and transcript-growth probes
- retry / attempt / handoff policy
- lock management
- frontier and shell helpers

The recovery policy must live in a modular runtime surface, not as accidental
behavior smeared across unrelated scripts.

## Acceptance

This work is only done when all of the following are true:

- simulated Claude auth failure over SSH fails the current attempt immediately
- simulated Codex auth failure over SSH fails the current attempt immediately
- simulated silent startup with no transcript growth fails after the 60-second
  probe
- the runtime retries the same round up to 3 times before any handoff
- after retry exhaustion, only the current round may switch agents
- if the handoff agent also fails, the run ends as failed without pretending
  progress
- no launcher can print `Startup check: passed` after the runtime already knows
  the attempt failed
- no monitor or launcher prints duplicate session or error lines
- no user-facing command leaks bare zellij return values as launch feedback
- explicit `--file` remains truthful
- all consumer scripts still source `common.sh` unchanged

## Test Contract

Tests must cover:

- immediate auth-failure classification
- 10-second first-activity probe
- 60-second transcript-growth failure
- same-round retry accounting
- same-round handoff after retry exhaustion
- truthful failure when child spawn dies before its own `meta.json`
- no advancement on failed fallback report
- no contradictory startup/failure messaging
- truthful CLI handling of `--file` vs prompt input

## Source Material

Use these as historical design baselines, but trust code and live instrumentation
over stale prose:

- [2026-04-09-common-sh-modularization-design.md](/Users/polyversai/Libraxis/vibecrafted/docs/superpowers/specs/2026-04-09-common-sh-modularization-design.md)
- [2026-04-09-marbles-steering-design.md](/Users/polyversai/Libraxis/vibecrafted/docs/superpowers/specs/2026-04-09-marbles-steering-design.md)
- [2026-04-09-commit-labels-design.md](/Users/polyversai/Libraxis/vibecrafted/docs/superpowers/specs/2026-04-09-commit-labels-design.md)

## Finish Condition

The runtime is finished only when an operator can watch a troubled run and see
one coherent truth: what attempt is alive, why the last one died, whether the
system is retrying or handing off, and when the run is truly over.
