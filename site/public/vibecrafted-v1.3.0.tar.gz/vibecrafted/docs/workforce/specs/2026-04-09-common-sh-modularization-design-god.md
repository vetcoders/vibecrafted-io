# common.sh Modularization — Unix Way

**Date:** 2026-04-09
**Status:** Approved (execute AFTER GOD/ANCESTOR/CHILDREN implementation lands)
**Branch:** release/v1.2.1
**Scope:** `skills/vc-agents/scripts/common.sh` → `skills/vc-agents/scripts/lib/*.sh`
**Depends on:** `2026-04-09-marbles-steering-design.md` (must be merged first)

## Problem 

`common.sh` is a god object. It contains ~1000 lines spanning 8+ unrelated
domains: path resolution, meta.json management, Zellij integration, lock
management, launcher generation, prompt building, session initialization,
and frontier config resolution.

Every spawn script sources the entire file. Every modification risks unintended
side effects across unrelated domains. Testing individual concerns is impossible
without loading everything.

This violates the Unix principle: do one thing and do it right.

## Design

### Directory structure

```
skills/vc-agents/scripts/
  common.sh                 <- thin aggregator, sources lib/*.sh
  lib/
    paths.sh                <- spawn_slug_from_path, spawn_abspath, spawn_repo_root,
                               spawn_store_dir, spawn_effective_store_dir,
                               spawn_marbles_store_dir, spawn_link_repo_artifacts
    meta.sh                 <- spawn_write_meta, spawn_finish_meta
    prompt.sh               <- spawn_build_runtime_prompt, spawn_write_frontmatter,
                               spawn_write_command_script
    session.sh              <- spawn_init_session, spawn_prepare_paths,
                               spawn_scan_active, spawn_effective_run_id,
                               spawn_generate_run_id, spawn_has_ambient_run_context,
                               spawn_normalize_ambient_context
    launcher.sh             <- spawn_generate_launcher, spawn_launch,
                               spawn_launch_headless, spawn_print_launch,
                               spawn_open_terminal, spawn_open_iterm
    zellij.sh               <- spawn_in_zellij_pane, spawn_in_zellij_context,
                               spawn_in_target_zellij_session, spawn_pane_direction,
                               spawn_in_operator_session, spawn_effective_operator_session,
                               spawn_open_startup_monitor_pane, spawn_workflow_label
    lock.sh                 <- spawn_create_run_lock, spawn_effective_run_lock
    frontier.sh             <- spawn_frontier_root, spawn_frontier_candidates,
                               spawn_preferred_shell
    ancestor.sh             <- NEW: _read_ancestor_frontmatter, _check_ancestor_mtime,
                               _write_ancestor_agent (from GOD/ANCESTOR impl)
    rotation.sh             <- NEW: _rotation_next_agent, _rotation_schedule
                               (from rotation impl)
    util.sh                 <- spawn_shell_quote, spawn_die, spawn_require_file,
                               spawn_require_command, spawn_require_positive_int,
                               spawn_validate_runtime, spawn_timestamp,
                               spawn_framework_version, spawn_org_repo
```

### common.sh becomes aggregator

```bash
#!/usr/bin/env bash
# common.sh — thin aggregator, sources all library modules.
# Consumer interface unchanged: `source "$SCRIPT_DIR/common.sh"`

_SPAWN_LIB_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/lib" && pwd)"

# Load order matters: util first (no deps), then paths, then the rest.
source "$_SPAWN_LIB_DIR/util.sh"
source "$_SPAWN_LIB_DIR/paths.sh"
source "$_SPAWN_LIB_DIR/meta.sh"
source "$_SPAWN_LIB_DIR/frontier.sh"
source "$_SPAWN_LIB_DIR/lock.sh"
source "$_SPAWN_LIB_DIR/prompt.sh"
source "$_SPAWN_LIB_DIR/session.sh"
source "$_SPAWN_LIB_DIR/launcher.sh"
source "$_SPAWN_LIB_DIR/zellij.sh"
source "$_SPAWN_LIB_DIR/ancestor.sh"
source "$_SPAWN_LIB_DIR/rotation.sh"
```

Explicit load order instead of glob — dependencies are clear and predictable.

### Consumer interface

**Zero changes.** Every script that does `source "$SCRIPT_DIR/common.sh"` keeps
working. The split is invisible to consumers.

### Dependency graph between modules

```
util.sh          <- no deps (pure functions)
paths.sh         <- util.sh
frontier.sh      <- util.sh
meta.sh          <- util.sh
lock.sh          <- util.sh, paths.sh
prompt.sh        <- util.sh, meta.sh
session.sh       <- util.sh, paths.sh, meta.sh, lock.sh, frontier.sh
launcher.sh      <- util.sh, prompt.sh
zellij.sh        <- util.sh, launcher.sh, session.sh
ancestor.sh      <- util.sh
rotation.sh      <- util.sh, ancestor.sh
```

No cycles. `util.sh` is the leaf. `zellij.sh` is the most connected.

### Extraction rules

1. **Cut, don't copy.** Move functions out of common.sh, do not duplicate.
2. **Preserve function signatures exactly.** No renames during extraction.
3. **No new abstractions.** This is a refactor, not a redesign.
4. **Tests must pass after each module extraction.** Don't batch.
5. **Commit per module.** `[agent/run_id] Extract paths.sh from common.sh`

### What NOT to do

- Do not rename functions (the `spawn_` prefix is the namespace, keep it)
- Do not add new functionality during extraction
- Do not change variable names or calling conventions
- Do not create helper wrappers "for cleanliness"
- Do not merge this with any other change

## Verification

After extraction:
1. `make check` — shell lint clean
2. `make test` — all tests pass
3. `bash scripts/check-portable.sh` — portable checks pass
4. Verify `source common.sh` still works from all consumers:
   ```bash
   grep -rl 'source.*common.sh' skills/vc-agents/scripts/ | \
     xargs -I{} bash -n {}
   ```
5. `wc -l` per module — no module exceeds 200 lines. If it does, it needs
   further splitting.

## Execution order

1. Wait for Codex to finish GOD/ANCESTOR/CHILDREN + rotation implementation
2. Run `vc-init` on the result to assess the new common.sh state
3. Extract modules one at a time, test after each
4. Commit per module with proper labels

This is a pure refactor. No behavior change. No new features.
