# Marbles Steering Architecture: GOD / ANCESTOR / CHILDREN

**Date:** 2026-04-09
**Status:** Partially landed; steering core is real, rotation/fallback sections are still aspirational
**Branch:** historical `release/v1.2.1` narrative; verify against live runtime before acting
**Scope:** `skills/vc-agents/scripts/marbles_*.sh`, `common.sh`

## Problem

The marbles runtime has a structural slug mismatch between watcher and spawn.
The L-plan copy strategy (`marbles-${plan_slug}_L${n}.md`) creates filenames
that, when re-slugified by the spawn, diverge from the watcher's expected slug.
Root cause: double `marbles-` prefix + truncation at 60 chars produces different
slugs depending on which file you slugify.

Fix A (meta.json lookup by `run_id`) mitigates this, but the pattern fallback
is broken for long prompt names. If meta.json fails to write, the watcher hangs
until timeout.

Additionally, the current plan system has zero steering capability: the same
plan content is copied verbatim to every loop. For 50-loop runs this is wasteful
-- the operator cannot adjust focus mid-run.

## Current Reality — 2026-04-10

This design is only partly implemented. The runtime already uses the
GOD/ANCESTOR/CHILDREN shape, but the advanced steering and recovery story in
this document is not fully real yet.

Landed in code:

- `god.md`, `ancestor.md`, and per-loop child plans exist.
- `state.json` carries `god_plan` and `ancestor_plan`.
- `ancestor.md` is the stable steering file and child plans are copied from it.
- `marbles_watcher.sh` and `marbles_next.sh` resolve loop artifacts via
  `meta.json` keyed by `run_id`, not by slug pattern matching.
- Hooks are agent-agnostic and carry `state_dir` instead of threading agent and
  original plan through the entire chain.

Still not landed:

- rotation modes (`single|duo|trio|multi`)
- `ancestor_mtime`, `rotation_pool`, and `agent_source` tracking in `state.json`
- automatic handoff to the next healthy agent when a scheduled one is down
- retry budgeting and same-round attempt logic
- commit label enforcement described later in this file

Read this document as "implemented steering core + unfinished recovery and
rotation roadmap", not as a claim that the full behavior already exists.

## Design

### Plan hierarchy

```
GOD (immutable)           <-- original user prompt, never modified
  |
  +-> ANCESTOR (mutable)  <-- live steering surface, operator edits between loops
  |     |
  |     +-> L1 (child)    <-- ANCESTOR@spawn_time + exit contract
  |     +-> L2 (child)    <-- ANCESTOR@spawn_time (may have changed)
  |     +-> L3 (child)    <-- ANCESTOR@spawn_time (changed again)
  |
  +-> CONVERGENCE.md      <-- summary referencing all children
```

### File layout

```
$state_dir/                          # ~/.vibecrafted/marbles/$run_id/
  god.md                             # immutable, timestamped frontmatter
  ancestor.md                        # STABLE path, operator-editable
  state.json                         # adds god_plan, ancestor_plan fields

$store/plans/
  marbles-${ancestor_slug}_L1.md     # child, slug from ANCESTOR@spawn_time
  marbles-${ancestor_slug}_L2.md     # fresh slug if ANCESTOR changed
```

### ANCESTOR frontmatter contract

```yaml
---
agent: codex
focus: installer portability
priority: P0
model: claude-sonnet-4-6   # optional, agent-specific override
---

The actual task content follows here.
Operator edits this between loops to steer the next iteration.
```

Fields read by watcher/next before each loop:
- `agent` -- which spawn script to invoke (codex/claude/gemini)
- `focus` -- recorded in state.json per-loop for audit trail
- `model` -- optional, passed to spawn as model override

### Slug contract

ANCESTOR lives at a STABLE path (`$state_dir/ancestor.md`).
`spawn_slug_from_path("ancestor.md")` always produces `"ancestor"`.
No truncation, no double-prefix, no divergence.

Child filenames: `marbles-ancestor_L${n}.md` -- short, predictable.

### Path resolution: meta.json only

Pattern-based fallback (`find -name "*_marbles-${slug}_L${n}_${agent}.md"`) is
removed from both `marbles_watcher.sh` and `marbles_next.sh`. Meta.json keyed
by `run_id` is the sole path resolution mechanism. This is justified because:

1. Slug can change between loops (operator steered ANCESTOR)
2. Pattern matching was already broken for long names
3. Meta.json is written at spawn init, before the agent starts work

### Argument chain simplification

**Current:** agent is threaded as positional arg through entire hook chain:
```
marbles_spawn.sh --agent codex
  -> watcher(run_id, agent, original_plan, count, ...)
    -> hook -> marbles_next.sh agent plan count current run_id ...
```

**New:** ANCESTOR is the source of truth; `state_dir` replaces agent+plan args:
```
marbles_spawn.sh --agent codex    # sets initial ANCESTOR frontmatter
  -> watcher(run_id, state_dir, count, root, runtime, store, lock)
    -> hook -> marbles_next.sh state_dir count current run_id root runtime scripts lock store
      marbles_next reads: agent = parse_frontmatter("agent", ancestor)
      -> ${agent}_spawn.sh ...
```

Hooks become agent-agnostic. They do not encode the agent name.

### state.json additions

```json
{
  "god_plan": "/path/to/state_dir/god.md",
  "ancestor_plan": "/path/to/state_dir/ancestor.md",
  "loops": [
    {
      "loop": 1,
      "agent": "codex",
      "focus": "installer",
      "ancestor_slug": "ancestor",
      "status": "done",
      "report": "...",
      "session_id": "..."
    }
  ]
}
```

### Operator workflow

```bash
# Start 50-loop run
vc-marbles codex --count 50 --prompt 'fix all P0 bugs in installer'

# Marbles creates:
#   ~/.vibecrafted/marbles/marb-143215/god.md        (immutable)
#   ~/.vibecrafted/marbles/marb-143215/ancestor.md   (editable)

# L1-L5 run with codex fixing P0 bugs...

# Operator steers between L5 and L6:
vim ~/.vibecrafted/marbles/marb-143215/ancestor.md
# Changes agent to gemini, focus to accessibility

# L6+ runs gemini on accessibility -- zero restart

# Operator checks trajectory:
cat ~/.vibecrafted/marbles/marb-143215/state.json | python3 -m json.tool
```

### GOD plan purpose

GOD is never used as spawn input. It serves as:
- Audit reference: what the operator originally intended
- Convergence context: diff(GOD, final ANCESTOR) = story of intent evolution
- Debugging: "why did the run go this direction?"

## Agent Rotation

### Modes

| Mode | Flag | Behavior | Example (6 loops, initial=codex) |
|------|------|----------|----------------------------------|
| `single` | default | one agent, all loops | C C C C C C |
| `duo` | `--rotation duo` | two agents alternate | C X C X C X |
| `trio` | `--rotation trio` | three agents, round-robin | C X G C X G |
| `multi` | `--rotation multi` | random from pool | G C C X G C |

Default pool order: codex, claude, gemini. The `--agent` flag sets the starting
agent. For `duo`, the second agent is the next in pool order (wrapping).

### ANCESTOR override trumps rotation

Rotation is a SUGGESTION. ANCESTOR is TRUTH.

```
if ANCESTOR.mtime changed since last loop:
    agent = read from ANCESTOR frontmatter   # user steered manually
    record agent_source = "user"
else:
    agent = rotation_schedule[loop_nr]        # auto-rotate
    update ANCESTOR frontmatter with new agent  # transparency
    record agent_source = "rotation"
```

Operator can break rotation at any point by editing ANCESTOR. Rotation resumes
on the next loop if ANCESTOR is not touched again.

### Implementation

`marbles_spawn.sh`:
- Add `--rotation single|duo|trio|multi` flag (default: `single`)
- Store `rotation` and `rotation_pool` in state.json
- Record `ancestor_mtime` after creating ANCESTOR

`marbles_next.sh`:
- Before spawning next loop, compare current ANCESTOR mtime vs stored mtime
- If unchanged: apply rotation schedule, write new agent into ANCESTOR frontmatter
- If changed: respect user's pick, reset mtime tracking
- Record `agent_source: "rotation"|"user"` in per-loop state

`state.json` additions:
```json
{
  "rotation": "trio",
  "rotation_pool": ["codex", "claude", "gemini"],
  "ancestor_mtime": "2026-04-09T14:32:15Z",
  "loops": [
    {"loop": 1, "agent": "codex", "agent_source": "rotation", ...},
    {"loop": 2, "agent": "claude", "agent_source": "rotation", ...},
    {"loop": 3, "agent": "codex", "agent_source": "user", ...}
  ]
}
```

### Agent availability fallback

If the scheduled agent is not available (CLI missing, API key error), rotation
skips to the next agent in pool. The existing `_fallback_agent` mechanism in
`marbles_watcher.sh` already handles this pattern (stall detection → cycle to
next agent). Wire the rotation pool into that fallback path.

### Commit labels

Every agent commit MUST have a labeled subject:
`[<agent>/<run_id>]` as prefix, e.g.: `[codex/marb-143215-001] Fix shell portability`

Injected via `spawn_build_runtime_prompt()` in the exit contract:
```
Every commit you make MUST have a subject starting with: [<agent>/<run_id>]
```

Verified in success_hook (warning only, not blocking).
See companion spec: `docs/superpowers/specs/2026-04-09-commit-labels-design.md`

## Already applied (this session, do NOT redo)

These fixes were made during the init audit and are already in the working tree:

- `common.sh` `spawn_pane_direction`: `SPAWN_LOOP_NR=0` now treated as "no loop" → non-marbles spawns get `new-tab` instead of `right`
- `common.sh` `spawn_write_command_script`: removed `trap 'rm -f "$0"' EXIT` so Zellij re-run works
- `common.sh` mktemp paths: changed from `$TMPDIR` to `$VIBECRAFTED_HOME/tmp/` for session persistence
- `Makefile:33`: `$VIBECRAFTED_ROOT` → `$$VIBECRAFTED_ROOT`
- `skills/foundations/vc-screenscribe/SKILL.md:16`: `VibeCraft` → `Vibecrafted.`
- `skills/foundations/vc-prview/SKILL.md:395`: `VibeCraft` → `Vibecrafted.`

## Files changed

| File | Change |
|------|--------|
| `marbles_spawn.sh` | Create god.md + ancestor.md; spawn L1 from ancestor; pass state_dir to watcher and hooks |
| `marbles_watcher.sh` | Read agent/focus from ANCESTOR frontmatter per loop; drop pattern fallback; use state_dir arg |
| `marbles_next.sh` | Read ANCESTOR for agent+content; fresh slug from ancestor; rebuild hooks with state_dir |
| `marbles_watcher.sh` `_bg_poll_verification` | Drop slug-based pattern, match via meta.json only |
| `Makefile:33` | Fix `$VIBECRAFTED_ROOT` -> `$$VIBECRAFTED_ROOT` (P0 from drift audit) |
| `skills/foundations/vc-screenscribe/SKILL.md:16` | `VibeCraft` -> `Vibecrafted.` |
| `skills/foundations/vc-prview/SKILL.md:395` | `VibeCraft` -> `Vibecrafted.` |

## Files NOT changed

- `common.sh` -- `spawn_slug_from_path`, `spawn_write_meta` remain unchanged
- `marbles_ctl.sh` -- pause/stop/resume semantics unaffected
- `marbles_plan.sh` -- only used for `--depth` mode, output becomes GOD input
- Agent spawn scripts (`*_spawn.sh`) -- no change, called with same interface

## Backward compatibility

The `--no-watch` legacy path in `marbles_spawn.sh` gets the same GOD/ANCESTOR
treatment. The old argument-based API is replaced entirely -- there is no
compatibility shim. Existing locks and state files from prior runs are unaffected
(different run_ids, different state directories).

## Test impact

Tests in `tests/tui/test_marbles_runtime.py` will need updates to reflect:
- New watcher argument signature (state_dir instead of agent+plan)
- New hook argument signature
- GOD/ANCESTOR file creation assertions
- ANCESTOR frontmatter parsing assertions

## Prerequisites

Before ANY implementation work, run `vc-init` to establish full structural
awareness of the codebase. This is mandatory — do not skip it.

## Quality gates

- `make check` -- shell lint pass
- `make test` -- pytest pass (updated tests)
- Manual: 3-loop marbles run with mid-run ANCESTOR edit confirming agent switch
