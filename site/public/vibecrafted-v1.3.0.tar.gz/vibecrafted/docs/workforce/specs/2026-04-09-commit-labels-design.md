# Mandatory Agent Commit Labels

**Date:** 2026-04-09
**Status:** Pending; design exists, runtime implementation is still missing
**Branch:** historical `release/v1.2.1` narrative; verify against live runtime before acting
**Scope:** `skills/vc-agents/scripts/common.sh`

## Problem

Living Tree means agents work on a shared worktree concurrently. But there is
no enforced convention for attributing commits to agents. When three agents
commit to the same branch in a marbles run, `git log` is a wall of unsigned,
unlabeled commits. You cannot tell which agent did what, revert a specific
agent's work, or track convergence per-agent.

"Living Tree" is not "nobody takes responsibility." It is "commit YOUR changes,
be aware of theirs."

## Current Reality — 2026-04-10

This document describes a desired contract, not current runtime truth.

What is true now:

- Agent prompts already carry report-path and frontmatter instructions.
- Marbles runs and normal spawns already carry `SPAWN_AGENT` and `SPAWN_RUN_ID`
  in the environment, so the data needed for labels exists.

What is not true yet:

- `spawn_build_runtime_prompt()` does not currently inject the commit label
  contract.
- `spawn_generate_launcher()` does not verify the last commit subject against an
  expected label.
- There is no test asserting labeled commit prompts or warning behavior.

Treat this as an unapplied design spec until the prompt and launcher paths
actually enforce or at least warn on the contract.

## Design

### Commit message format

Every agent commit MUST have a labeled subject:

```
[codex/marb-143215-001] Fix shell portability in install.sh
```

Format: `[<agent>/<run_id>]` as prefix in the commit subject line.

- `agent`: codex, claude, or gemini
- `run_id`: the `SPAWN_RUN_ID` value (e.g., `marb-143215-001`, `impl-162800`)

### Source of the label

Both values already exist in the spawn environment:

- `SPAWN_AGENT` — set in `spawn_init_session`
- `SPAWN_RUN_ID` — set in `spawn_init_session`

The label string: `[${SPAWN_AGENT}/${SPAWN_RUN_ID}]`

### Injection point

**`spawn_build_runtime_prompt()`** in `common.sh` (line 978-988).

This function already appends the report path instruction to every agent prompt.
Add the commit label requirement in the same block:

```bash
cat >> "$runtime_file" <<EOF_PROMPT

## Commit Contract

Every commit you make MUST have a subject starting with this exact label:
\`[${SPAWN_AGENT}/${SPAWN_RUN_ID:-unknown}]\`

Example:
\`[${SPAWN_AGENT}/${SPAWN_RUN_ID:-unknown}] Fix installer path resolution\`

This is mandatory. Do not skip this label. Do not modify it.

At the end of the task, write your final human-readable report to this exact path:
Report path: $report_path
...
EOF_PROMPT
```

The commit contract goes BEFORE the report instruction because committing
happens before reporting.

### Verification (success_hook)

Add a check in the common success hook path. After the agent finishes, verify
that at least one commit exists with the expected label:

```bash
# In spawn_generate_launcher success path:
if command -v git >/dev/null 2>&1 && git rev-parse --git-dir >/dev/null 2>&1; then
  expected_label="[${SPAWN_AGENT}/${SPAWN_RUN_ID:-unknown}]"
  last_subject="$(git log -1 --format=%s 2>/dev/null || true)"
  if [[ -n "$last_subject" && ! "$last_subject" == *"$expected_label"* ]]; then
    printf '\033[33m[warn]\033[0m Agent committed without label: %s\n' "$expected_label"
    printf '  last commit: %s\n' "$last_subject"
  fi
fi
```

This is a WARNING, not a blocker. We log it so the operator sees it.
We do NOT amend commits (per CLAUDE.md git safety rules).

### What this enables

```bash
# All commits from a specific agent
git log --grep='\[codex/' --oneline

# All commits from a specific marbles run
git log --grep='marb-143215' --oneline

# Count commits per agent
git log --oneline | grep -oP '\[\w+/' | sort | uniq -c

# Revert all of gemini's work from a run
git log --grep='\[gemini/marb-143215' --format=%H | xargs git revert
```

## Files changed

| File | Change |
|------|--------|
| `common.sh` `spawn_build_runtime_prompt()` | Inject commit label contract before report instruction |
| `common.sh` `spawn_generate_launcher()` | Add label verification in success path (warning only) |

## Files NOT changed

- Agent spawn scripts (`*_spawn.sh`) — no change needed
- Exit contracts in marbles plans — they already say "COMMIT: mandatory"; the label is now injected automatically via runtime prompt
- Pre-commit hooks — no enforcement at git level (operator's manual commits should not be blocked)

## Backward compatibility

Agents that ignore the label instruction still commit normally. The success_hook
emits a warning but does not block. No existing workflow breaks.

## Test impact

- `tests/tui/test_spawn_common.py` — add assertion that runtime prompt contains commit label
- Optional: test that success_hook warns on unlabeled commits
