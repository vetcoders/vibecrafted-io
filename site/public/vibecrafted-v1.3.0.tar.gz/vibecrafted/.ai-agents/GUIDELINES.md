# Repository Guidelines

## Product
This repo is the canonical source for the Vibecrafted (formerly VetCoders) skill stack, installer, and shell glue. The real product is the installable system that centralizes artifacts under `~/.vibecrafted` (syncing this repo into `~/.vibecrafted/skills` or `~/.agents/skills`) and exposes runtime-specific views across different agent environments.

## Architecture
Treat the repo as three connected surfaces. First: `skills/vc-*` directories (migrated from `vetcoders-*`) are the canonical authored instructions. Second: `skills/vc-agents/` plus the root `scripts/` directory form the runtime layer that installs, verifies, and launches external agents. Third: `docs/` (including `VIBECRAFTED.md`), `README.md`, and the installer UI are the public packaging surface and must stay aligned with the actual runtime paths. This `GUIDELINES.md` file is the repo-local operational reference for agents.

## Quality Gates (verified 2026-03-26)
- `python3 scripts/vetcoders_install.py doctor` — pass (`43 ok, 1 warnings, 0 failures`)
- `bash scripts/check-portable.sh` — pass (`portable checks passed`)
- `pytest tests/` — fail (known issue in agent runs: `io.UnsupportedOperation: redirected stdin is pseudofile` when testing TUI flows in `tests/tui/test_keys.py`)

These are the primary verified gates. Truth lives in installability (`scripts/vetcoders_install.py` / `scripts/setup_vibecraft.py`) and portable runtime smoke.

## Conventions
Use the repo as the source of truth, not the installed copies in home directories. When renaming skills or changing routing doctrine, update the docs and installer surface in the same pass to reflect the "vibecrafted" naming and path structures. Commit history uses short imperative English subjects, often with narrow product wording instead of rigid conventional prefixes. Keep docs concise and operational.

## Critical Files
- `scripts/setup_vibecraft.py` & `scripts/vetcoders_install.py` — installer and doctor truth; changes affect every install path.
- `skills/vc-agents/scripts/install.sh` and `skills/vc-agents/shell/vetcoders.zsh` — external agent runtime and helper exposure.
- `docs/VIBECRAFTED.md` and `README.md` — public promise and core philosophy.
- `skills/vc-init/SKILL.md` — foundational bootstrap doctrine used across the suite.

## Known Issues
- `pytest` commands targeting `tests/tui/` currently fail when run by agents due to missing interactive TTY/stdin.
- `loctree` gives thin structural signal here because the repo is docs/script/skill heavy; rely more on direct file inspection and `rg` for finding paths.
- The project is actively mid-migration to the `vibecrafted` terminology and `~/.vibecrafted` centralized paths; watch out for stale references to old paths.