import sys

with open('scripts/vetcoders_install.py') as f:
    text = f.read()

# Add GoBack Exception
text = text.replace(
    'def ask_yn(',
    'class GoBack(Exception):\n    pass\n\ndef ask_yn('
)

# Patch ask_yn to handle 'b' or ESC or LEFT
ask_yn_old = """def ask_yn(prompt: str, default: bool = True) -> bool:
    \"\"\"Ask yes/no question. Returns default in non-interactive mode.\"\"\"
    if not _IS_TTY:
        return default
    suffix = " [Y/n] " if default else " [y/N] "
    try:
        answer = input(bold(prompt) + suffix).strip().lower()
    except (EOFError, KeyboardInterrupt):
        print()
        return default
    if not answer:
        return default
    return answer.startswith("y")"""

ask_yn_new = """def ask_yn(prompt: str, default: bool = True) -> bool:
    \"\"\"Ask yes/no question interactively.\"\"\"
    if not _IS_TTY:
        return default

    try:
        import termios
        import tty
    except ImportError:
        suffix = " [Y/n] " if default else " [y/N] "
        try:
            answer = input(bold(prompt) + suffix + dim("(type 'b' to go back) ")).strip().lower()
        except (EOFError, KeyboardInterrupt):
            print()
            return default
        if answer == 'b':
            raise GoBack()
        if not answer:
            return default
        return answer.startswith("y")

    import termios
    import tty

    current_val = default
    print(bold(prompt))
    print(dim("  (Use LEFT/RIGHT or Y/N, ENTER to confirm, ESC/BACKSPACE to go back)"))

    def render():
        sys.stdout.write("\\033[1A\\033[2K\\r")
        y_marker = green("[Y]") if current_val else dim(" y ")
        n_marker = red("[N]") if not current_val else dim(" n ")
        sys.stdout.write(f"  {y_marker}  {n_marker}\\n")
        sys.stdout.flush()

    print()
    render()

    fd = sys.stdin.fileno()
    old_settings = termios.tcgetattr(fd)
    try:
        tty.setcbreak(fd)
        while True:
            char = _read_key()
            if char in ('\\n', '\\r'):
                break
            elif char.lower() == 'y':
                current_val = True
                break
            elif char.lower() == 'n':
                current_val = False
                break
            elif char == '\\x1b[D': # Left
                current_val = True
                render()
            elif char == '\\x1b[C': # Right
                current_val = False
                render()
            elif char in ('\\x08', '\\x7f', '\\x1b', 'b', 'B'): # Backspace, Esc, or B
                raise GoBack()
            elif char == '\\x03': # Ctrl+C
                raise KeyboardInterrupt
    except KeyboardInterrupt:
        sys.stdout.write("\\n")
        return default
    finally:
        termios.tcsetattr(fd, termios.TCSADRAIN, old_settings)

    return current_val"""

text = text.replace(ask_yn_old, ask_yn_new)

# Add GoBack support to ask_choice
text = text.replace(
    'elif char == \'\\x03\': # Ctrl+C\n                raise KeyboardInterrupt',
    'elif char in (\'\\x08\', \'\\x7f\', \'\\x1b\', \'b\', \'B\'): # Backspace, Esc, or b\n                raise GoBack()\n            elif char == \'\\x03\': # Ctrl+C\n                raise KeyboardInterrupt'
)
# same for fallback of ask_choice
text = text.replace(
    'answer = input(dim(f"  Choice [1-{len(options)}, default {default + 1}]: ")).strip()',
    'answer = input(dim(f"  Choice [1-{len(options)}, default {default + 1}] (type \'b\' to go back): ")).strip()\n        if answer.lower() == "b": raise GoBack()'
)

# And to ask_multi fallback
text = text.replace(
    'answer = input(dim("  Selection: ")).strip()',
    'answer = input(dim("  Selection (or \'b\' to go back): ")).strip()\n        if answer.lower() == "b": raise GoBack()'
)

with open('scripts/vetcoders_install.py', 'w') as f:
    f.write(text)
