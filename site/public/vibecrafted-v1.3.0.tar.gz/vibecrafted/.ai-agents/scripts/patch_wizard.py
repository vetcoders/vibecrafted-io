import re

with open("scripts/vetcoders_install.py") as f:
    text = f.read()

# We can replace the interactive sequence with a while True loop and a step variable.
# It's better to just write the new loop and insert it.

new_block = """    # --- Interactive Wizard ---
    step = 0
    selected_skills = list(skill_names)
    all_runtimes = [rt for rt in AGENT_RUNTIMES if rt != "gemini"]
    install_shell = cli_with_shell
    installed_foundations: Dict[str, Dict] = {}

    while True:
        try:
            if step == 0:
                # --- Selective install ---
                if cli_skill_filter:
                    unknown = [s for s in cli_skill_filter if s not in skill_names]
                    if unknown:
                        print(yellow(f"Unknown skills (skipped): {', '.join(unknown)}"))
                    selected_skills = [s for s in cli_skill_filter if s in skill_names]
                    if not selected_skills:
                        print(red("No valid skills selected."))
                        return 1
                    step = 1
                elif advanced and interactive:
                    defaults = [s in selected_skills for s in skill_names]
                    result = ask_multi("Select skills to install:", skill_names, defaults)
                    selected_skills = [n for n, sel in zip(skill_names, result) if sel]
                    if not selected_skills:
                        print(red("No skills selected."))
                        return 1
                    print()
                    step = 1
                else:
                    step = 1

            elif step == 1:
                # --- System check (only show once) ---
                sys_deps = detect_system_deps()
                missing_critical = [cmd for cmd in ("zsh", "python3", "git", "rsync") if not sys_deps.get(cmd)]
                if missing_critical:
                    print(bold("System check:"))
                    print(red(f"Missing critical dependencies: {', '.join(missing_critical)}"))
                    print("Install them before continuing.")
                    return 1
                step = 2
            
            elif step == 2:
                # --- Agent runtimes ---
                available_runtimes = detect_agent_runtimes()
                
                if cli_tools:
                    all_runtimes = [rt for rt in cli_tools if rt in AGENT_RUNTIMES]
                    step = 3
                elif interactive and not advanced:
                    print(bold("Agent runtimes:"))
                    for rt, path in available_runtimes.items():
                        if path:
                            print(f"  {OK} {rt} -> {dim(path)}")
                        else:
                            print(f"  {OPT} {rt} {dim('(not installed)')}")
                    print()
                    print(dim("  Note: gemini-cli in some versions duplicates the workflows, inheriting"))
                    print(dim("  skills from the other agents. Gemini symlinks skipped by default."))
                    create_all = ask_yn("Create symlink views for default runtimes (codex, claude)?", default=True)
                    if not create_all:
                        defaults = [rt in all_runtimes for rt in AGENT_RUNTIMES]
                        result = ask_multi("Select runtimes for symlink views:", AGENT_RUNTIMES, defaults)
                        all_runtimes = [rt for rt, sel in zip(AGENT_RUNTIMES, result) if sel]
                    print()
                    step = 3
                elif advanced and interactive:
                    print(bold("Agent runtimes:"))
                    for rt, path in available_runtimes.items():
                        if path:
                            print(f"  {OK} {rt} -> {dim(path)}")
                        else:
                            print(f"  {OPT} {rt} {dim('(not installed)')}")
                    print()
                    print(dim("  Note: gemini-cli in some versions duplicates the workflows, inheriting"))
                    print(dim("  skills from the other agents. Gemini symlinks skipped by default."))
                    defaults = [rt in all_runtimes for rt in AGENT_RUNTIMES]
                    result = ask_multi("Select runtimes for symlink views:", AGENT_RUNTIMES, defaults)
                    all_runtimes = [rt for rt, sel in zip(AGENT_RUNTIMES, result) if sel]
                    print()
                    step = 3
                else:
                    step = 3

            elif step == 3:
                # --- Runtime Foundations ---
                missing_foundations: List[Foundation] = []
                for f in FOUNDATIONS:
                    if not f.is_installed() and f.required:
                        missing_foundations.append(f)

                has_cargo = detect_cargo()
                if missing_foundations and has_cargo and interactive:
                    print(bold("Runtime Foundations:"))
                    for f in missing_foundations:
                        if "crates" in f.channels:
                            label = "required" if f.required else "optional"
                            if ask_yn(f"Install {f.name} via cargo? ({label})", default=f.required):
                                success = install_foundation_cargo(f, dry_run=dry_run)
                                channel = "crates"
                                installed_foundations[f.name] = {
                                    "channel": channel,
                                    "success": success,
                                }
                                if success:
                                    print(f"  {OK} {f.name} installed")
                                else:
                                    print(f"  {MISS} {f.name} installation failed")
                    print()
                step = 4

            elif step == 4:
                # --- Shell helpers ---
                if not cli_with_shell and interactive:
                    install_shell = ask_yn("Install zsh shell helpers (codex-implement, claude-plan, etc.)?", default=install_shell)
                    print()
                
                if install_shell:
                    conflicts = scan_helper_conflicts()
                    if conflicts:
                        should_proceed = report_helper_conflicts(conflicts, interactive)
                        if not should_proceed:
                            install_shell = False
                
                step = 5

            elif step == 5:
                # Setup all states for Confirm phase
                for f in FOUNDATIONS:
                    if f.name not in installed_foundations:
                        path = f.is_installed()
                        installed_foundations[f.name] = {
                            "channel": "pre-existing" if path else "not-installed",
                            "path": path or "",
                        }
                break

        except GoBack:
            if step > 0:
                if step == 4 and not interactive:
                    step = max(0, step - 2)
                elif step == 3 and not (missing_foundations and has_cargo and interactive):
                    step = max(0, step - 2)
                elif step == 2 and cli_tools:
                    step = max(0, step - 2)
                elif step == 1 and not (advanced and interactive):
                    step = 0
                else:
                    step -= 1
            else:
                pass # Can't go back from step 0"""

start_marker = "    # --- Selective install ---"
end_marker = "    # --- Confirm ---"

start_idx = text.find(start_marker)
end_idx = text.find(end_marker)

if start_idx != -1 and end_idx != -1:
    text = text[:start_idx] + new_block + "\n" + text[end_idx:]
    with open("scripts/vetcoders_install.py", "w") as f:
        f.write(text)
    print("Patched.")
else:
    print("Could not find markers.")
