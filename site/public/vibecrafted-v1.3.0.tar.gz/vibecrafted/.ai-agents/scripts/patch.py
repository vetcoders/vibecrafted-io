import re

with open('scripts/vetcoders_install.py') as f:
    text = f.read()

# We can raise a GoBack exception from the ask_* functions when the user presses 'B' or 'Backspace' or Esc
text = text.replace('class InstallState:', 'class GoBack(Exception):\n    pass\n\n@dataclass\nclass InstallState:')
text = text.replace('def _read_key() -> str:', 'def _read_key() -> str:') # just anchor
with open('test_back.py', 'w') as f:
    f.write(text)
