import sys

with open("scripts/vetcoders_install.py") as f:
    text = f.read()

start_marker = "    # --- Selective install ---"
end_marker = "    # --- Confirm ---"

start_idx = text.find(start_marker)
end_idx = text.find(end_marker)

old_block = text[start_idx:end_idx]

# We are going to build a simple interactive wizard with step tracking.
# We need to make sure we clear the screen (or print empty lines) when navigating back, 
# but for CLI it's usually enough to just re-print the prompt.

new_block = """    # --- Interactive Wizard ---
    step = 0
    selected_skills = list(skill_names)
    all_runtimes = [rt for rt in AGENT_RUNTIMES if rt != "gemini"]
    install_shell = cli_with_shell
    installed_foundations: Dict[str, Dict] = {}

    while True:
        try:
            if step == 0:
                # Skills selection
                if cli_skill_filter:
                    unknown = [s for s in cli_skill_filter if s not in skill_names]
                    if unknown:
                        print(yellow(f"Unknown skills (skipped): {', '.join(unknown)}"))
                    selected_skills = [s for s in cli_skill_filter if s in skill_names]
                    if not selected_skills:
                        print(red("No valid skills selected."))
                        return 1
                    step += 1
                elif advanced and interactive:
                    defaults = [s in selected_skills for s in skill_names]
                    result = ask_multi("Select skills to install:", skill_names, defaults)
                    selected_skills = [n for n, sel in zip(skill_names, result) if sel]
                    if not selected_skills:
                        print(red("No skills selected."))
                        return 1
                    print()
                    step += 1
                else:
                    step += 1

            elif step == 1:
                # System check (static output, just flows through unless error)
                if not getattr(args, '_sys_checked', False):
                    print(bold("System check:"))
                    sys_deps = detect_system_deps()
                    for cmd, path in sys_deps.items():
                        if path:
                            print(f"  {OK} {cmd} -> {dim(path)}")
                        else:
                            print(f"  {MISS} {cmd}")
                
                    osascript = detect_osascript()
                    if osascript:
                        print(f"  {OK} osascript -> {dim(osascript)}")
                    else:
                        print(f"  {OPT} osascript {dim('(headless spawn still works)')}")
                    print()
                
                    missing_critical = [cmd for cmd in ("zsh", "python3", "git", "rsync") if not sys_deps.get(cmd)]
                    if missing_critical:
                        print(red(f"Missing critical dependencies: {', '.join(missing_critical)}"))
                        print("Install them before continuing.")
                        return 1
                    args._sys_checked = True
                step += 1

            elif step == 2:
                # Runtimes
                if not getattr(args, '_rt_checked', False):
                    print(bold("Agent runtimes:"))
                    available_runtimes = detect_agent_runtimes()
                    for rt, path in available_runtimes.items():
                        if path:
                            print(f"  {OK} {rt} -> {dim(path)}")
                        else:
                            print(f"  {OPT} {rt} {dim('(not installed)')}")
                    print()
                    args._rt_checked = True

                if cli_tools:
                    all_runtimes = [rt for rt in cli_tools if rt in AGENT_RUNTIMES]
                    step += 1
                elif interactive and not advanced:
                    print(dim("  Note: gemini-cli in some versions duplicates the workflows, inheriting"))
                    print(dim("  skills from the other agents. Gemini symlinks skipped by default."))
                    create_all = ask_yn("Create symlink views for default runtimes (codex, claude)?", default=True)
                    if not create_all:
                        defaults = [rt in all_runtimes for rt in AGENT_RUNTIMES]
                        result = ask_multi("Select runtimes for symlink views:", AGENT_RUNTIMES, defaults)
                        all_runtimes = [rt for rt, sel in zip(AGENT_RUNTIMES, result) if sel]
                    print()
                    step += 1
                elif advanced and interactive:
                    print(dim("  Note: gemini-cli in some versions duplicates the workflows, inheriting"))
                    print(dim("  skills from the other agents. Gemini symlinks skipped by default."))
                    defaults = [rt in all_runtimes for rt in AGENT_RUNTIMES]
                    result = ask_multi("Select runtimes for symlink views:", AGENT_RUNTIMES, defaults)
                    all_runtimes = [rt for rt, sel in zip(AGENT_RUNTIMES, result) if sel]
                    print()
                    step += 1
                else:
                    step += 1

            elif step == 3:
                # Foundations
                if not getattr(args, '_fnd_checked', False):
                    print(bold("Runtime Foundations:"))
                    missing_foundations: List[Foundation] = []
                    for f in FOUNDATIONS:
                        path = f.is_installed()
                        if path:
                            print(f"  {OK} {f.name} -> {dim(path)}")
                            print(f"       {dim(f.description)}")
                        elif f.required:
                            print(f"  {MISS} {f.name} — {f.description}")
                            print(f"       {dim(f.install_hint())}")
                            missing_foundations.append(f)
                        else:
                            print(f"  {OPT} {f.name} — {f.description}")
                            print(f"       {dim(f.install_hint())}")
                    print()
                    args._missing_foundations = missing_foundations
                    args._fnd_checked = True

                missing_foundations = args._missing_foundations
                has_cargo = detect_cargo()
                
                if missing_foundations and has_cargo and interactive:
                    for f in missing_foundations:
                        if "crates" in f.channels:
                            label = "required" if f.required else "optional"
                            if ask_yn(f"Install {f.name} via cargo? ({label})", default=f.required):
                                success = install_foundation_cargo(f, dry_run=dry_run)
                                installed_foundations[f.name] = {
                                    "channel": "crates",
                                    "success": success,
                                }
                                if success:
                                    print(f"  {OK} {f.name} installed")
                                else:
                                    print(f"  {MISS} {f.name} installation failed")
                    print()
                elif missing_foundations and not has_cargo and interactive:
                    if getattr(args, '_fnd_warn_done', False) == False:
                        print(yellow("cargo not found — cannot auto-install foundations."))
                        print(dim("Install cargo (rustup) first, or install foundations manually."))
                        args._fnd_warn_done = True
                
                step += 1

            elif step == 4:
                # Shell helpers
                if not cli_with_shell and interactive:
                    install_shell = ask_yn("Install zsh shell helpers (codex-implement, claude-plan, etc.)?", default=install_shell)
                    print()
                
                if install_shell:
                    conflicts = scan_helper_conflicts()
                    if conflicts:
                        should_proceed = report_helper_conflicts(conflicts, interactive)
                        if not should_proceed:
                            install_shell = False
                step += 1
                
            elif step == 5:
                # Post-wizard setup
                for f in FOUNDATIONS:
                    if f.name not in installed_foundations:
                        path = f.is_installed()
                        installed_foundations[f.name] = {
                            "channel": "pre-existing" if path else "not-installed",
                            "path": path or "",
                        }
                break

        except GoBack:
            # Re-evaluate previous interactive steps to find the closest one
            if step == 4:
                # Going back from shell helpers
                if missing_foundations and has_cargo and interactive:
                    step = 3
                else:
                    step = 2
            elif step == 3:
                # Going back from foundations
                if cli_tools:
                    step = 0 if (advanced and interactive) else 0 # actually 0
                else:
                    step = 2
            elif step == 2:
                # Going back from runtimes
                if advanced and interactive:
                    step = 0
                else:
                    print(dim("  (Cannot go back further)"))
            elif step == 0:
                print(dim("  (Cannot go back further)"))
"""

text = text[:start_idx] + new_block + "\n" + text[end_idx:]

with open("scripts/vetcoders_install.py", "w") as f:
    f.write(text)

