    # --- Selective install ---
    selected_skills = list(skill_names)
    if cli_skill_filter:
        # CLI --skill flags take precedence
        unknown = [s for s in cli_skill_filter if s not in skill_names]
        if unknown:
            print(yellow(f"Unknown skills (skipped): {', '.join(unknown)}"))
        selected_skills = [s for s in cli_skill_filter if s in skill_names]
        if not selected_skills:
            print(red("No valid skills selected."))
            return 1
    elif advanced and interactive:
        defaults = [True] * len(skill_names)
        result = ask_multi("Select skills to install:", skill_names, defaults)
        selected_skills = [n for n, sel in zip(skill_names, result) if sel]
        if not selected_skills:
            print(red("No skills selected."))
            return 1
        print()

    # --- Detect system ---
    print(bold("System check:"))
    sys_deps = detect_system_deps()
    for cmd, path in sys_deps.items():
        if path:
            print(f"  {OK} {cmd} -> {dim(path)}")
        else:
            print(f"  {MISS} {cmd}")

    osascript = detect_osascript()
    if osascript:
        print(f"  {OK} osascript -> {dim(osascript)}")
    else:
        print(f"  {OPT} osascript {dim('(headless spawn still works)')}")
    print()

    # Missing critical deps
    missing_critical = [cmd for cmd in ("zsh", "python3", "git", "rsync") if not sys_deps.get(cmd)]
    if missing_critical:
        print(red(f"Missing critical dependencies: {', '.join(missing_critical)}"))
        print("Install them before continuing.")
        return 1

    # --- Agent runtimes ---
    print(bold("Agent runtimes:"))
    available_runtimes = detect_agent_runtimes()
    for rt, path in available_runtimes.items():
        if path:
            print(f"  {OK} {rt} -> {dim(path)}")
        else:
            print(f"  {OPT} {rt} {dim('(not installed)')}")
    print()

    # Choose runtimes for symlink views
    all_runtimes = [rt for rt in AGENT_RUNTIMES if rt != "gemini"]
    if cli_tools:
        # CLI --tool flags take precedence
        all_runtimes = [rt for rt in cli_tools if rt in AGENT_RUNTIMES]
    elif interactive and not advanced:
        print(dim("  Note: gemini-cli in some versions duplicates the workflows, inheriting"))
        print(dim("  skills from the other agents. Gemini symlinks skipped by default."))
        create_all = ask_yn("Create symlink views for default runtimes (codex, claude)?", default=True)
        if not create_all:
            defaults = [bool(available_runtimes.get(rt)) and rt != "gemini" for rt in AGENT_RUNTIMES]
            result = ask_multi("Select runtimes for symlink views:", AGENT_RUNTIMES, defaults)
            all_runtimes = [rt for rt, sel in zip(AGENT_RUNTIMES, result) if sel]
        print()
    elif advanced and interactive:
        print(dim("  Note: gemini-cli in some versions duplicates the workflows, inheriting"))
        print(dim("  skills from the other agents. Gemini symlinks skipped by default."))
        defaults = [rt != "gemini" for rt in AGENT_RUNTIMES]
        result = ask_multi("Select runtimes for symlink views:", AGENT_RUNTIMES, defaults)
        all_runtimes = [rt for rt, sel in zip(AGENT_RUNTIMES, result) if sel]
        print()

    # --- Runtime Foundations ---
    print(bold("Runtime Foundations:"))
    missing_foundations: List[Foundation] = []
    for f in FOUNDATIONS:
        path = f.is_installed()
        if path:
            print(f"  {OK} {f.name} -> {dim(path)}")
            print(f"       {dim(f.description)}")
        elif f.required:
            print(f"  {MISS} {f.name} — {f.description}")
            print(f"       {dim(f.install_hint())}")
            missing_foundations.append(f)
        else:
            print(f"  {OPT} {f.name} — {f.description}")
            print(f"       {dim(f.install_hint())}")
    print()

    # Offer to install missing foundations
    has_cargo = detect_cargo()
    installed_foundations: Dict[str, Dict] = {}
    if missing_foundations and has_cargo and interactive:
        for f in missing_foundations:
            if "crates" in f.channels:
                label = "required" if f.required else "optional"
                if ask_yn(f"Install {f.name} via cargo? ({label})", default=f.required):
                    success = install_foundation_cargo(f, dry_run=dry_run)
                    channel = "crates"
                    installed_foundations[f.name] = {
                        "channel": channel,
                        "success": success,
                    }
                    if success:
                        print(f"  {OK} {f.name} installed")
                    else:
                        print(f"  {MISS} {f.name} installation failed")
        print()
    elif missing_foundations and not has_cargo:
        print(yellow("cargo not found — cannot auto-install foundations."))
        print(dim("Install cargo (rustup) first, or install foundations manually:"))
        for f in missing_foundations:
            print(f"  {f.install_hint()}")
        print()

    # Record all foundations state
    for f in FOUNDATIONS:
        if f.name not in installed_foundations:
            path = f.is_installed()
            installed_foundations[f.name] = {
                "channel": "pre-existing" if path else "not-installed",
                "path": path or "",
            }

    # --- Shell helpers ---
    install_shell = cli_with_shell  # --with-shell flag
    if not install_shell and interactive:
        install_shell = ask_yn("Install zsh shell helpers (codex-implement, claude-plan, etc.)?", default=True)
        print()

    # --- Helper conflict check ---
    if install_shell:
        conflicts = scan_helper_conflicts()
        if conflicts:
            should_proceed = report_helper_conflicts(conflicts, interactive)
            if not should_proceed:
                install_shell = False


