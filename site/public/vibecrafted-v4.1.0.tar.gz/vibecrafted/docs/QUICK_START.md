# Quick Start

## 1. Install

**macOS and Linux:**

```bash
curl -fsSL https://vibecrafted.io/install.sh | bash
```

**Windows** — install WSL2 once, then use the same bootstrap inside it:

```powershell
wsl --install
wsl bash -c 'curl -fsSL https://vibecrafted.io/install.sh | bash'
```

**From source:**

```bash
git clone https://github.com/vetcoders/vibecrafted.git
cd vibecrafted && make install
```

On macOS the intended end-user artifact is one signed and notarized
`Vibecrafted_<version>-<YYYYMMDD>-<sha8>.dmg` from the
[latest release](https://github.com/vetcoders/vibecrafted/releases/latest),
verified against its adjacent `.dmg.sha256`. No published release carries a DMG
yet — use the bootstrap until one does. The build path exists but has not been
exercised since the runtime layout changed, so treat it as unproven rather than
ready. Every channel and its status: [INSTALL.md](INSTALL.md).

## 2. Verify

```bash
vibecrafted doctor
vibecrafted version
```

`doctor` separates broken from merely absent. Yellow on a fresh install usually
means an optional foundation you have not installed yet — expected, not a
defect. Red means act.

## 3. Orient your agent

From any repository:

```bash
vibecrafted init claude
# or
vibecrafted init codex
```

Both forms recover intentions through AICX, map the living tree through Loctree,
and check runtime truth before work begins.

If the agent CLI is not installed, `init` names the gap and prints the exact
install command rather than exiting silently. Vibecrafted drives agent CLIs; it
does not bundle them. See [First run](public/getting-started/first-run.md).

## 4. Build something

```bash
vibecrafted implement codex --prompt "Add user authentication with JWT"
```

No terminal UI required — dispatch, then observe:

```bash
vibecrafted observe <run-id>
```

Use `vibecrafted help` for the full operator surface.

## Developer checkout path

`make install`, `make install-auto` and the source bootstrap are the same
runtime the public installer stages, plus the build, test and release targets.
Run `make help-dev` for the full inventory, or read
[Build from source](public/getting-started/build-from-source.md).
