# Structural Map · vibecrafted-core @ release/3.7.1@ec76061f
Freshness: fresh - card matches the loaded snapshot authority.
Full payload: 01-structural-map.full.json

This card contains dependency and symbol topology for the selected scope.

## Hubs (fan-in ≥ 10) — domain owner: this card

no hubs above fan-in threshold — corpus: 3
no hotspots in pack — corpus: 0

## Consumers per hub (DECISION-COMPLETE: all edges inline, grouped)

vibecrafted_core/delivery/model.py ← vibecrafted_core/product_contract.py
vibecrafted_core/delivery/seal.py ← vibecrafted_core/product_contract.py

## Import graph — shape

2 edges resolved from 19 imports · 3 files · 7 symbols · 0 slice consumers
File clusters: vibecrafted_core (3)
structural entrypoints: vibecrafted_core/product_contract.py [script]

## Reachability — domain owner: this card

reachable: 1 of 1 reachability claims
no unreachable surfaces — claims: 1

## Authority — domain owner: this card

authority:RepoVerified 2 · LoctreeDerived 5 · AicxOperator 0 · AicxAgent 0 · AicxFailure 0 · SemanticGuess 1 · StaleOrUnknown 0

## What this card does not cover

This Structural Map does not include runtime behavior, env contracts, or verification gates. Read `02-runtime-map.md` and `04-verification-gates.md` before changing behavior.
