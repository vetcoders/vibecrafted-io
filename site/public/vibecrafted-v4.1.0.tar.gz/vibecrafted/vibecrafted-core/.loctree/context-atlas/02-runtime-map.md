# Runtime Map · vibecrafted-core @ release/3.7.1@ec76061f
Freshness: fresh - card matches the loaded snapshot authority.
Full payload: 02-runtime-map.full.json

This card contains runtime signals derived from semantic facts and framework bridges.

## Entrypoints

entry:vibecrafted_core/product_contract.py · symbols: entrypoint:script

## Env Contracts

no env contracts in scope; missing data does not prove zero

## Framework Hints

no framework hints in pack — corpus: 1
idiom-tags: 1 · full list: 02-runtime-map.full.json#idiom_tags
tauri: commands 0 · events 0

## Dispatch Edges

no dispatch edges in pack — corpus: 0

reachability → 01-structural-map.md §Reachability (reachability domain owner)

## What this card does not cover

This Runtime Map does not include prior decisions or full risk history. Read `03-intent-map.md` when continuing work and `05-risk-register.md` before release decisions.
