# Verification Gates · vibecrafted-core @ release/3.7.1@ec76061f
Freshness: fresh - card matches the loaded snapshot authority.
Full payload: 04-verification-gates.full.json

This card lists verification gates and likely tests derived from the current context.

## Gates

gate:pytest

## Likely Tests

test:tests/delivery/test_delivery_doctor.py
test:tests/dispatch/test_doctor.py

## Downstream Checks

no downstream checks data in pack — corpus: 0
snapshot risk (stale/dirty) before release → 05-risk-register.md (freshness domain owner)

## What this card does not cover

This Verification Gates card does not prove correctness by itself. Run the commands before release or submit.
