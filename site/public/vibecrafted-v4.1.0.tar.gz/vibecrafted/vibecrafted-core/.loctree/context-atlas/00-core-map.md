# Core Map · vibecrafted-core @ release/3.7.1@ec76061f
Freshness: fresh - card matches the loaded snapshot authority.
Full payload: 00-core-map.full.json

This card tells you where you are, what is risky, and what actions are safe next.

## Identity

repo_id: vibecrafted-core
branch: release/3.7.1
snapshot_commit: ec76061f
snapshot_id: release_3.7.1@ec76061f
store_revision: unavailable — ContextPack v1 does not carry an AICX store revision
overlay_revision: unavailable — loctree.overlay.intent.v1 is not wired into the pack (M1-01)
anchor_catalog_revision: unavailable — anchor catalog is emitted by `loct anchors`; the pack does not carry it

## Freshness

fresh - card matches the loaded snapshot authority.
cache/snapshot details → 05-risk-register.md §Cache & Snapshot Health (freshness domain owner)

## Risk Summary

no fan-in risks in pack — hotspots: 0 → 01-structural-map.md

authority (per-label counters) → 01-structural-map.md §Authority (authority domain owner)

## Safe Next Commands

loct find ProductContractError
loct slice vibecrafted_core/product_contract.py — Slice this file to inspect its direct dependencies and immediate consumers before editing.
loct body ProductContractError — View the definition body of symbol 'ProductContractError' to understand its implementation structure.
loct find --literal ProductContractError — Execute a literal exact-identifier scan for 'ProductContractError' to find exact matches across the codebase.
loct occurrences ProductContractError — Perform a literal boundary-sensitive occurrences scan for 'ProductContractError' to locate all references.
loct follow — Pursue unified structural signals (dead exports, import cycles, twins) to ensure health.

## What this card does not cover

This Core Map does not include dependency consumers, runtime entrypoints, or prior decisions. For code changes, read `01-structural-map.md` next.
