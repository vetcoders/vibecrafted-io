# Risk Register · vibecrafted-core @ release/3.7.1@ec76061f
Freshness: fresh - card matches the loaded snapshot authority.
Full payload: 05-risk-register.full.json

This card collects risk signals and recommended actions for the current context scope.

hotspots + hubs (fan-in) → 01-structural-map.md §Hubs (hotspots and hubs domain owner)
authority (per-label counters) → 01-structural-map.md §Authority (authority domain owner)

## Cache & Snapshot Health

snapshot_health: fresh
cache_scope: Clean
stale_snapshot: false · dirty_worktree: false

## Stale Assumptions

no registered stale assumptions in pack — corpus: 0

## Actions

executable actions (safe next + power-path, 6 items) → 00-core-map.md (safe next commands domain owner)

## What this card does not cover

This Risk Register does not include full source content. Use `loct slice`/`loct impact` for exact file-level surgery.
