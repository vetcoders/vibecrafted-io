# Structural Map · vibecrafted-server @ fix/the-rest-of-findings@c7ce9f29
Freshness: fresh - card matches the loaded snapshot authority.
Full payload: 01-structural-map.full.json

This card contains dependency and symbol topology for the selected scope.

## Hubs (fan-in ≥ 10) — domain owner: this card

no hubs above fan-in threshold — corpus: 7

hotspots:control-core/src/model.rs · importers 3 · mitigation: `loct slice` before edit, `loct impact` before delete
hotspots:control-core/src/events.rs · importers 2 · mitigation: `loct slice` before edit, `loct impact` before delete
hotspots:control-core/src/read.rs · importers 1 · mitigation: `loct slice` before edit, `loct impact` before delete
hotspots:web/src/control/events_sse.rs · importers 1 · mitigation: `loct slice` before edit, `loct impact` before delete

## Consumers per hub (DECISION-COMPLETE: all edges inline, grouped)

control-core/src/model.rs ← control-core/src/{events.rs,lib.rs,read.rs}
control-core/src/events.rs ← control-core/src/{lib.rs,read.rs}
control-core/src/read.rs ← control-core/src/lib.rs
control-core/src/scaffold.rs ← control-core/src/lib.rs

## Import graph — shape

8 edges resolved from 52 imports · 7 files · 182 symbols · 4 slice consumers
File clusters: control-core (5) · web (2)
structural entrypoints: none in slice

## Reachability — domain owner: this card

reachable: 2 of 2 reachability claims
no unreachable surfaces — claims: 2

## Authority — domain owner: this card

authority:RepoVerified 1 · LoctreeDerived 16 · AicxOperator 0 · AicxAgent 0 · AicxFailure 0 · SemanticGuess 2 · StaleOrUnknown 0

## What this card does not cover

This Structural Map does not include runtime behavior, env contracts, or verification gates. Read `02-runtime-map.md` and `04-verification-gates.md` before changing behavior.
