# Core Map · vibecrafted-server @ fix/the-rest-of-findings@c7ce9f29
Freshness: fresh - card matches the loaded snapshot authority.
Full payload: 00-core-map.full.json

This card tells you where you are, what is risky, and what actions are safe next.

## Identity

repo_id: vibecrafted-server
branch: fix/the-rest-of-findings
snapshot_commit: c7ce9f29
snapshot_id: fix_the-rest-of-findings@c7ce9f29
store_revision: unavailable — ContextPack v1 does not carry an AICX store revision
overlay_revision: unavailable — loctree.overlay.intent.v1 is not wired into the pack (M1-01)
anchor_catalog_revision: unavailable — anchor catalog is emitted by `loct anchors`; the pack does not carry it

## Freshness

fresh - card matches the loaded snapshot authority.
cache/snapshot details → 05-risk-register.md §Cache & Snapshot Health (freshness domain owner)

## Risk Summary

no fan-in risks in pack — hotspots: 4 → 01-structural-map.md

authority (per-label counters) → 01-structural-map.md §Authority (authority domain owner)

## Safe Next Commands

loct find ConnectionWindow
loct slice control-core/src/events.rs — Slice this file to inspect its direct dependencies and immediate consumers before editing.
loct impact control-core/src/events.rs — Assess the transitive blast radius and downstream consumers of this file before modifying.
loct slice control-core/src/lib.rs — Slice this file to inspect its direct dependencies and immediate consumers before editing.
loct body ConnectionWindow — View the definition body of symbol 'ConnectionWindow' to understand its implementation structure.
loct find --literal ConnectionWindow — Execute a literal exact-identifier scan for 'ConnectionWindow' to find exact matches across the codebase.
loct occurrences ConnectionWindow — Perform a literal boundary-sensitive occurrences scan for 'ConnectionWindow' to locate all references.
loct follow — Pursue unified structural signals (dead exports, import cycles, twins) to ensure health.
loct body offset — View the definition body of symbol 'offset' to understand its implementation structure.
loct find --literal offset — Execute a literal exact-identifier scan for 'offset' to find exact matches across the codebase.
loct occurrences offset — Perform a literal boundary-sensitive occurrences scan for 'offset' to locate all references.
loct slice control-core/src/read.rs — Slice this file to inspect its direct dependencies and immediate consumers before editing.
loct impact control-core/src/read.rs — Assess the transitive blast radius and downstream consumers of this file before modifying.
loct body vibecrafted_home — View the definition body of symbol 'vibecrafted_home' to understand its implementation structure.
loct find --literal vibecrafted_home — Execute a literal exact-identifier scan for 'vibecrafted_home' to find exact matches across the codebase.
loct occurrences vibecrafted_home — Perform a literal boundary-sensitive occurrences scan for 'vibecrafted_home' to locate all references.
loct slice control-core/src/model.rs — Slice this file to inspect its direct dependencies and immediate consumers before editing.
loct impact control-core/src/model.rs — Assess the transitive blast radius and downstream consumers of this file before modifying.
loct body as_str — View the definition body of symbol 'as_str' to understand its implementation structure.
loct find --literal as_str — Execute a literal exact-identifier scan for 'as_str' to find exact matches across the codebase.
loct occurrences as_str — Perform a literal boundary-sensitive occurrences scan for 'as_str' to locate all references.
loct slice web/src/control/events_sse.rs — Slice this file to inspect its direct dependencies and immediate consumers before editing.
loct impact web/src/control/events_sse.rs — Assess the transitive blast radius and downstream consumers of this file before modifying.
loct body events_sse — View the definition body of symbol 'events_sse' to understand its implementation structure.
loct find --literal events_sse — Execute a literal exact-identifier scan for 'events_sse' to find exact matches across the codebase.
loct occurrences events_sse — Perform a literal boundary-sensitive occurrences scan for 'events_sse' to locate all references.

## What this card does not cover

This Core Map does not include dependency consumers, runtime entrypoints, or prior decisions. For code changes, read `01-structural-map.md` next.
