# Runtime Map · vibecrafted-server @ fix/the-rest-of-findings@c7ce9f29
Freshness: fresh - card matches the loaded snapshot authority.
Full payload: 02-runtime-map.full.json

This card contains runtime signals derived from semantic facts and framework bridges.

## Entrypoints

no runtime entrypoints in pack — corpus: 0

## Env Contracts

no env contracts in scope; missing data does not prove zero

## Framework Hints

no framework hints in pack — corpus: 0
idiom-tags: 2 · full list: 02-runtime-map.full.json#idiom_tags
tauri: commands 0 · events 0

## Dispatch Edges

no dispatch edges in pack — corpus: 0

reachability → 01-structural-map.md §Reachability (reachability domain owner)

## What this card does not cover

This Runtime Map does not include prior decisions or full risk history. Read `03-intent-map.md` when continuing work and `05-risk-register.md` before release decisions.
