# Loctree Context Atlas

Project: `/Volumes/vc-workspace/vetcoders/vibecrafted-suite/vibecrafted/vibecrafted-server`
Snapshot: `fix/the-rest-of-findings@c7ce9f29`
Generated: `2026-08-05T07:56:02.382848Z`

Active identity: `task-1ac7b260d9780b81` (`task`)

This atlas is precomputed repository understanding. It contains the repo map an agent would otherwise have to rediscover manually through search/open cycles.

Tokens are cheaper than wrong assumptions.

## Persisted atlas identities

The flat cards in this directory are a compatibility view of the active identity. Scope-keyed atlases below remain independently addressable.

| Identity | Kind | Selectors | Task | Snapshot | Manifest |
|---|---|---|---|---|---|
| `task-1ac7b260d9780b81` | `task` | `—` | `Bug: podczas kolejkowania wiadomości i użycia Stop dla aktywnego streamu aplikacja resetuje response_id. Znajdź logikę queue/stop/stream i lifecycle response_id.` | `fix/the-rest-of-findings@c7ce9f29` | `/Volumes/vc-workspace/vetcoders/vibecrafted-suite/vibecrafted/vibecrafted-server/.loctree/context-atlas/runs/task-1ac7b260d9780b81/manifest.md` |

## Recommended Reading Path

| Step | File | Lines | Why read it | Saves you from |
|---:|---|---:|---|---|
| 0 | `00-core-map.md` | 59 lines | Repo identity, current risk, authority labels, safe next commands. | wrong project state, stale assumptions, unsafe first actions |
| 1 | `01-structural-map.md` | 40 lines | Files, symbols, imports, consumers, entrypoints; read before edits/refactors. | missed consumers, wrong impact, blind dependency edits |
| 2 | `02-runtime-map.md` | 29 lines | Runtime behavior, framework hints, env contracts, reachability. | wrong tests, hidden runtime coupling, config mistakes |
| 3 | `03-intent-map.md` | 29 lines | Formative decisions, intents, anti-recommendations, and superseded history pinned to structure (aicx overlay). | repeated work, re-decided decisions, revived refuted approaches |
| 4 | `04-verification-gates.md` | 27 lines | Commands and likely tests most relevant to validate changes. | wrong validation path, skipped downstream checks, false confidence |
| 5 | `05-risk-register.md` | 26 lines | Hotspots, cache/snapshot health, stale assumptions, next risk-reducing actions. | release blockers, high fan-in surprises, stale-cache decisions |

## Domain owners

One domain = one owner (source of truth: `domain_owners` in manifest.json; section headers project that map). Other cards reference a domain in one line; they never duplicate it.

00-core-map: identity · safe_next_commands
01-structural-map: authority · edges · hotspots · hubs · import_graph · reachability
02-runtime-map: dispatch · entrypoints · env_contracts · framework_hints
03-intent-map: intent
04-verification-gates: gates · likely_tests
05-risk-register: actions · freshness · stale_assumptions

## Completeness

Current reading state: `0/6` context cards read.
A broad repo-level answer is incomplete until at least `00-core-map.md`, `01-structural-map.md`, and `02-runtime-map.md` have been read.
