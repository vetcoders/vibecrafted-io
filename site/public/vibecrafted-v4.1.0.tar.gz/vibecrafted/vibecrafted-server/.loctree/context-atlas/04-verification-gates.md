# Verification Gates · vibecrafted-server @ fix/the-rest-of-findings@c7ce9f29
Freshness: fresh - card matches the loaded snapshot authority.
Full payload: 04-verification-gates.full.json

This card lists verification gates and likely tests derived from the current context.

## Gates

gate:cargo check --workspace
gate:cargo clippy --workspace --all-targets -- -D warnings
gate:cargo test --workspace

## Likely Tests

test:control-core/tests/lifecycle_runs_eye.rs
test:control-core/tests/runtime_runs_eye.rs
test:control-core/tests/scaffold_artifacts.rs
test:control-core/tests/schema_fidelity.rs

## Downstream Checks

no downstream checks data in pack — corpus: 0
snapshot risk (stale/dirty) before release → 05-risk-register.md (freshness domain owner)

## What this card does not cover

This Verification Gates card does not prove correctness by itself. Run the commands before release or submit.
