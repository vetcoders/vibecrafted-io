# Intent Map · vibecrafted-server @ fix/the-rest-of-findings@c7ce9f29
Freshness: fresh - card matches the loaded snapshot authority.
Full payload: 03-intent-map.full.json

This card pins recorded decisions and intents (aicx overlay v1) to the structure they shaped.
Source: aicx overlay v1 · no overlay document (cold store)
Evidence drill-down: `aicx read <ref>` · Markers: ✓ current · ⊘ superseded · ✗ anti-recommendation || evidence: [V] verified · [U] unverified · [R] refuted

intent layer stale (no overlay cache yet) — refresh: `aicx overlay --repo /Volumes/vc-workspace/vetcoders/vibecrafted-suite/vibecrafted/vibecrafted-server --format json`

## Per-hub — formative decisions (fan-in ≥ 10)

no registered per-hub decisions — corpus: 0 overlay entries

## Repo-wide

no repo-wide entries — corpus: 0

## Anti-recommendations (AicxFailure)

no anti-recommendations — corpus: 0

## Superseded (history — 1 line/entry)

no superseded entries — corpus: 0

## What this card does not cover

This Intent Map does not replace repo-verified facts and carries only above-threshold attributions (unresolved candidates live in the payload only). Re-check structural/runtime cards before editing.
