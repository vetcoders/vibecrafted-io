Potwierdzone z npm registry:

@loctree/aicx platform packages

┌────────────────────────┬─────────┐
│ Package                │ Status  │
├────────────────────────┼─────────┤
│ aicx-darwin-arm64      │ 0.12.1  │
├────────────────────────┼─────────┤
│ aicx-linux-x64-gnu     │ 0.12.1  │
├────────────────────────┼─────────┤
│ aicx-win32-x64-gnu     │ 0.12.1  │
├────────────────────────┼─────────┤
│ aicx-linux-arm64-gnu   │ MISSING │
├────────────────────────┼─────────┤
│ aicx-linux-aarch64-gnu │ MISSING │
├────────────────────────┼─────────┤
│ aicx-linux-arm64       │ MISSING │
└────────────────────────┴─────────┘

@loctree/loct (dla porównania)

┌──────────────────────┬─────────┐
│ Package              │ Status  │
├──────────────────────┼─────────┤
│ loct meta            │ 0.13.1  │
├──────────────────────┼─────────┤
│ loct-darwin-arm64    │ 0.13.1  │
├──────────────────────┼─────────┤
│ loct-linux-x64-gnu   │ 0.13.1  │
├──────────────────────┼─────────┤
│ loct-linux-arm64-gnu │ MISSING │
└──────────────────────┴─────────┘

Więc: Mac z npm i -g działa, ARM Linux (vetcoders) z npm — nie (ani aicx, ani loct).  
Nasze binarki z root@vetcoders to osobny tor (vendor/tarball), dopóki nie dodacie linux-arm64-gnu do matrix + publish.

Buildy aicx/loctree w świeżych clone’ach dalej lecą (kompilacja).