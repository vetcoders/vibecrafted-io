# Loctree Context Pack

## Project Identity

- **Root**: `/Users/maciejgad/vc-workspace/vetcoders/vibecrafted`
- **Branch**: `feat/runtime-integration`
- **Commit**: `480ffb8`
- **Snapshot**: `feat_runtime-integration@480ffb8`

## Where You Are

### Files

| Path | Role | Language | LOC | Authority |
|---|---|---|---|---|
| `bin/vc-agents` | `Consumer` | py | 12 | *RepoVerified* |
| `bin/vc-followup` | `Consumer` | py | 12 | *RepoVerified* |
| `bin/vc-implement` | `Consumer` | py | 12 | *RepoVerified* |
| `bin/vc-marbles` | `Consumer` | py | 12 | *RepoVerified* |
| `bin/vc-prune` | `Consumer` | py | 12 | *RepoVerified* |
| `bin/vc-research` | `Consumer` | py | 12 | *RepoVerified* |
| `bin/vc-research-await` | `Consumer` | py | 12 | *RepoVerified* |
| `bin/vc-research-synthesize` | `Consumer` | py | 12 | *RepoVerified* |
| `bin/vc-review` | `Consumer` | py | 12 | *RepoVerified* |
| `bin/vc-scaffold` | `Consumer` | py | 12 | *RepoVerified* |
| `bin/vibecrafted-resume` | `Consumer` | py | 12 | *RepoVerified* |
| `scripts/control_plane_state.py` | `Consumer` | py | 31 | *RepoVerified* |
| `scripts/installer_gui.py` | `Consumer` | py | 2709 | *RepoVerified* |
| `scripts/runtime_paths.py` | `Consumer` | py | 12 | *RepoVerified* |
| `scripts/vetcoders_install.py` | `Consumer` | py | 5764 | *RepoVerified* |
| `tests/agent_dispatch_test.py` | `Consumer` | py | 276 | *RepoVerified* |
| `tests/tui/test_keys.py` | `Consumer` | py | 255 | *RepoVerified* |
| `tests/tui/test_research_terminal_safety.py` | `Consumer` | py | 112 | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/config.rs` | `Target` | rs | 520 | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/danger.rs` | `Consumer` | rs | 878 | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/ipc/handlers.rs` | `Consumer` | rs | 76 | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/lib.rs` | `Consumer` | rs | 629 | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/main.rs` | `Consumer` | rs | 187 | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/multi.rs` | `Consumer` | rs | 126 | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/multi_tui.rs` | `Consumer` | rs | 397 | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/mux_gen.rs` | `Consumer` | rs | 787 | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/runtime/client.rs` | `Consumer` | rs | 372 | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/runtime/heartbeat.rs` | `Consumer` | rs | 430 | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/runtime/mod.rs` | `Consumer` | rs | 416 | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/runtime/server.rs` | `Consumer` | rs | 350 | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/runtime/status.rs` | `Consumer` | rs | 363 | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/runtime/tests.rs` | `Consumer` | rs | 1080 | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/scan.rs` | `Consumer` | rs | 1534 | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/state.rs` | `Target` | rs | 381 | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/tray.rs` | `Consumer` | rs | 338 | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/tray_dashboard.rs` | `Consumer` | rs | 331 | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/wizard/mod.rs` | `Consumer` | rs | 389 | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/wizard/persist.rs` | `Consumer` | rs | 697 | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/wizard/services.rs` | `Consumer` | rs | 504 | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/wizard/types.rs` | `Consumer` | rs | 227 | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/wizard/ui.rs` | `Consumer` | rs | 801 | *RepoVerified* |
| `vibecrafted-app/shell-agent/app/Vibecrafted/Views/InspectorViewController.swift` | `Consumer` | swift | 150 | *RepoVerified* |
| `vibecrafted-core/tests/dispatch/test_cli.py` | `Consumer` | py | 100 | *RepoVerified* |
| `vibecrafted-core/tests/dispatch/test_schema.py` | `Consumer` | py | 192 | *RepoVerified* |
| `vibecrafted-core/tests/dispatch/test_supervisor.py` | `Consumer` | py | 538 | *RepoVerified* |
| `vibecrafted-core/tests/dispatch/test_verify.py` | `Consumer` | py | 249 | *RepoVerified* |
| `vibecrafted-core/tests/test_agy_junie_pipeline.py` | `Consumer` | py | 53 | *RepoVerified* |
| `vibecrafted-core/tests/test_aicx_sync.py` | `Consumer` | py | 536 | *RepoVerified* |
| `vibecrafted-core/tests/test_capabilities.py` | `Consumer` | py | 217 | *RepoVerified* |
| `vibecrafted-core/tests/test_cli.py` | `Consumer` | py | 474 | *RepoVerified* |
| `vibecrafted-core/tests/test_compact_hooks.py` | `Consumer` | py | 190 | *RepoVerified* |
| `vibecrafted-core/tests/test_control_plane.py` | `Consumer` | py | 684 | *RepoVerified* |
| `vibecrafted-core/tests/test_cron.py` | `Consumer` | py | 160 | *RepoVerified* |
| `vibecrafted-core/tests/test_doctor.py` | `Consumer` | py | 48 | *RepoVerified* |
| `vibecrafted-core/tests/test_git.py` | `Consumer` | py | 39 | *RepoVerified* |
| `vibecrafted-core/tests/test_loop_ship.py` | `Consumer` | py | 71 | *RepoVerified* |
| `vibecrafted-core/tests/test_memex_client.py` | `Consumer` | py | 397 | *RepoVerified* |
| `vibecrafted-core/tests/test_sandbox_adapter.py` | `Consumer` | py | 212 | *RepoVerified* |
| `vibecrafted-core/tests/test_supervisor.py` | `Consumer` | py | 239 | *RepoVerified* |
| `vibecrafted-core/tests/test_supervisor_async.py` | `Consumer` | py | 478 | *RepoVerified* |
| `vibecrafted-core/tests/test_ui.py` | `Consumer` | py | 64 | *RepoVerified* |
| `vibecrafted-core/tests/test_workflow.py` | `Consumer` | py | 731 | *RepoVerified* |
| `vibecrafted-core/tests/test_workflow_registry.py` | `Consumer` | py | 78 | *RepoVerified* |
| `vibecrafted-core/tests/test_workflow_runtime.py` | `Consumer` | py | 340 | *RepoVerified* |
| `vibecrafted-core/tests/test_wrappers.py` | `Consumer` | py | 100 | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/__init__.py` | `Target` | py | 111 | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/agent_dispatch.py` | `Dependency` | py | 296 | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/agent_stream.py` | `Dependency` | py | 509 | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/artifacts.py` | `Dependency` | py | 134 | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/capabilities.py` | `Dependency` | py | 333 | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/cli.py` | `Consumer` | py | 422 | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/compact_hooks.py` | `Consumer` | py | 475 | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/control_plane.py` | `Dependency` | py | 1267 | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/cron.py` | `Consumer` | py | 373 | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/dispatch/__init__.py` | `Consumer` | py | 71 | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/dispatch/cli.py` | `Consumer` | py | 239 | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/dispatch/doctor.py` | `Consumer` | py | 82 | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/dispatch/model.py` | `Target` | py | 255 | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/dispatch/schema.py` | `Consumer` | py | 508 | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/dispatch/supervisor.py` | `Consumer` | py | 776 | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/dispatch/verify.py` | `Consumer` | py | 217 | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/doctor.py` | `Dependency` | py | 86 | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/events.py` | `Dependency` | py | 24 | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/git.py` | `Dependency` | py | 192 | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/lifecycle.py` | `Dependency` | py | 175 | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/runtime_paths.py` | `Dependency` | py | 53 | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/sandbox/__init__.py` | `Dependency` | py | 12 | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/sandbox/adapter.py` | `Dependency` | py | 228 | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/sandbox/msbserver_lifecycle.py` | `Dependency` | py | 157 | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/sandbox/policy.py` | `Dependency` | py | 131 | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/spawn.py` | `Dependency` | py | 1141 | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/supervisor_async.py` | `Dependency` | py | 605 | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/workflow.py` | `Dependency` | py | 1429 | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/workflow_runtime.py` | `Dependency` | py | 935 | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/workflows/__init__.py` | `Dependency` | py | 21 | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/workflows/registry.py` | `Consumer` | py | 204 | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/wrappers.py` | `Target` | py | 440 | *RepoVerified* |
| `vibecrafted-mcp/vibecrafted_mcp/server.py` | `Consumer` | py | 801 | *RepoVerified* |

### Symbols

| File | Name | Kind | Export Type | Line | Authority |
|---|---|---|---|---|---|
| `vibecrafted-app/mux-agent/src/config.rs` | `CliOptions` | trait | named | 179 | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/config.rs` | `Config` | struct | named | 12 | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/config.rs` | `ResolvedParams` | struct | named | 41 | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/config.rs` | `ServerConfig` | struct | named | 17 | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/config.rs` | `expand_path` | function | named | 64 | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/config.rs` | `load_config` | function | named | 151 | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/config.rs` | `resolve_params` | function | named | 299 | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/config.rs` | `resolve_params_multi` | function | named | 203 | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/config.rs` | `safe_copy` | function | named | 175 | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/config.rs` | `safe_copy_file` | function | named | 131 | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/config.rs` | `safe_read_to_string` | function | named | 118 | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/config.rs` | `vetted_existing_file` | function | named | 87 | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/scan.rs` | `Confidence` | enum | named | 157 | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/scan.rs` | `ConfigSchema` | enum | named | 144 | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/scan.rs` | `ConflictReport` | struct | named | 211 | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/scan.rs` | `ConflictVariant` | struct | named | 217 | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/scan.rs` | `DiscoveredMcp` | struct | named | 547 | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/scan.rs` | `DiscoveredMcpSource` | enum | named | 541 | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/scan.rs` | `HostFile` | struct | named | 165 | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/scan.rs` | `HostFormat` | enum | named | 132 | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/scan.rs` | `HostKind` | enum | named | 83 | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/scan.rs` | `HostService` | struct | named | 182 | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/scan.rs` | `MergeOutcome` | struct | named | 203 | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/scan.rs` | `RewireArgs` | struct | named | 39 | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/scan.rs` | `RewireOutcome` | struct | named | 225 | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/scan.rs` | `ScanArgs` | struct | named | 17 | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/scan.rs` | `ScanResult` | struct | named | 195 | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/scan.rs` | `StatusArgs` | struct | named | 61 | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/scan.rs` | `as_label` | function | named | 99 | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/scan.rs` | `build_manifest` | function | named | 735 | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/scan.rs` | `default_sources` | function | named | 240 | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/scan.rs` | `discover_hosts` | function | named | 365 | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/scan.rs` | `discover_vibecrafted_mcp` | function | named | 569 | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/scan.rs` | `discover_vibecrafted_mcp_with` | function | named | 576 | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/scan.rs` | `display_name` | function | named | 114 | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/scan.rs` | `format_for_host` | function | named | 728 | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/scan.rs` | `generate_snippet` | function | named | 774 | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/scan.rs` | `host_file_from_custom_path` | function | named | 375 | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/scan.rs` | `into_host_service` | function | named | 556 | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/scan.rs` | `merge_services` | function | named | 628 | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/scan.rs` | `resolve_host_from_args` | function | named | 940 | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/scan.rs` | `resolve_status_host` | function | named | 958 | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/scan.rs` | `rewire_host` | function | named | 838 | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/scan.rs` | `run_rewire_cmd` | function | named | 1040 | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/scan.rs` | `run_scan_cmd` | function | named | 976 | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/scan.rs` | `run_status_cmd` | function | named | 1062 | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/scan.rs` | `scan_host_file` | function | named | 419 | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/scan.rs` | `scan_hosts` | function | named | 527 | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/scan.rs` | `serialize_config` | function | named | 922 | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/scan.rs` | `serialize_snippet` | function | named | 931 | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/scan.rs` | `write_with_backup` | function | named | 904 | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/state.rs` | `ClientHandshake` | struct | named | 138 | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/state.rs` | `HANDSHAKE_TIMEOUT` | decl | named | 45 | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/state.rs` | `HealthStatus` | type | named | 36 | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/state.rs` | `HeartbeatMetrics` | struct | named | 127 | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/state.rs` | `MuxState` | struct | named | 98 | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/state.rs` | `MuxStateConfig` | struct | named | 146 | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/state.rs` | `Pending` | struct | named | 82 | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/state.rs` | `ServerStatus` | enum | named | 11 | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/state.rs` | `StatusLevel` | enum | named | 29 | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/state.rs` | `StatusSnapshot` | struct | named | 56 | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/state.rs` | `buffer_message` | function | named | 246 | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/state.rs` | `complete_handshake` | function | named | 228 | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/state.rs` | `error_response` | function | named | 263 | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/state.rs` | `get_handshake_mut` | function | named | 252 | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/state.rs` | `is_handshake_complete` | function | named | 232 | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/state.rs` | `is_handshake_timed_out` | function | named | 238 | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/state.rs` | `mark_handshake_complete` | function | named | 219 | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/state.rs` | `new` | function | named | 160 | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/state.rs` | `next_request_id` | function | named | 213 | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/state.rs` | `publish_status` | function | named | 305 | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/state.rs` | `register_client` | function | named | 190 | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/state.rs` | `reset_state` | function | named | 328 | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/state.rs` | `set_id` | function | named | 257 | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/state.rs` | `snapshot_for_state` | function | named | 274 | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/state.rs` | `unregister_client` | function | named | 206 | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/__init__.py` | `Any` | reexport | named | 3 | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/__init__.py` | `ArtifactValidation` | reexport | named | 25 | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/__init__.py` | `AsyncRunHandle` | reexport | named | 39 | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/__init__.py` | `AsyncSupervisor` | reexport | named | 39 | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/__init__.py` | `Event` | reexport | named | 5 | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/__init__.py` | `EventKind` | reexport | named | 26 | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/__init__.py` | `RunState` | reexport | named | 26 | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/__init__.py` | `RunStatus` | reexport | named | 5 | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/__init__.py` | `ToolCapability` | reexport | named | 18 | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/__init__.py` | `WorkflowLaunchSpec` | __all__ | named |  | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/__init__.py` | `annotations` | reexport | named | 1 | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/__init__.py` | `append_event` | reexport | named | 17 | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/__init__.py` | `await_launch_truth` | __all__ | named |  | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/__init__.py` | `await_run` | reexport | named | 5 | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/__init__.py` | `build_launch_command` | __all__ | named |  | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/__init__.py` | `control_plane_home` | reexport | named | 5 | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/__init__.py` | `doctor_run` | reexport | named | 23 | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/__init__.py` | `doctor_summary` | reexport | named | 23 | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/__init__.py` | `event_stream_path` | reexport | named | 5 | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/__init__.py` | `foundation_capabilities` | reexport | named | 18 | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/__init__.py` | `is_final_state` | reexport | named | 26 | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/__init__.py` | `is_negative_state` | reexport | named | 26 | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/__init__.py` | `launch_workflow` | __all__ | named |  | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/__init__.py` | `lookup_run` | reexport | named | 5 | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/__init__.py` | `normalize_launch_spec` | __all__ | named |  | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/__init__.py` | `probe_tool` | reexport | named | 18 | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/__init__.py` | `read_event_tail` | reexport | named | 5 | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/__init__.py` | `read_version_file` | reexport | named | 33 | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/__init__.py` | `repo_full` | reexport | named | 24 | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/__init__.py` | `repo_full_summary` | reexport | named | 24 | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/__init__.py` | `resolve_env_path` | reexport | named | 33 | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/__init__.py` | `retry_run` | __all__ | named |  | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/__init__.py` | `run_snapshot_dir` | reexport | named | 5 | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/__init__.py` | `stop_run` | __all__ | named |  | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/__init__.py` | `subscribe_events` | reexport | named | 5 | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/__init__.py` | `sync_state` | reexport | named | 5 | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/__init__.py` | `transition_allowed` | reexport | named | 26 | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/__init__.py` | `validate_artifacts` | reexport | named | 25 | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/__init__.py` | `vibecrafted_home` | reexport | named | 33 | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/__init__.py` | `vibecrafted_launcher` | __all__ | named |  | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/__init__.py` | `xdg_config_home` | reexport | named | 33 | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/control_plane.py` | `Event` | class | named | 114 | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/control_plane.py` | `RunStatus` | class | named | 87 | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/control_plane.py` | `await_run` | def | named | 1206 | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/control_plane.py` | `cli` | def | named | 1249 | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/control_plane.py` | `control_plane_home` | def | named | 123 | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/control_plane.py` | `ensure_session_id` | def | named | 216 | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/control_plane.py` | `event_stream_path` | def | named | 131 | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/control_plane.py` | `lookup_run` | def | named | 1200 | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/control_plane.py` | `normalize_run_root` | def | named | 207 | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/control_plane.py` | `operator_session_name` | def | named | 498 | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/control_plane.py` | `read_event_tail` | def | named | 1076 | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/control_plane.py` | `record_stop_transition` | def | named | 966 | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/control_plane.py` | `run_snapshot_dir` | def | named | 127 | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/control_plane.py` | `subscribe_events` | def | named | 1089 | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/control_plane.py` | `sync_state` | def | named | 1133 | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/dispatch/model.py` | `Baton` | class | named | 203 | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/dispatch/model.py` | `Common` | class | named | 44 | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/dispatch/model.py` | `Cut` | class | named | 107 | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/dispatch/model.py` | `CutState` | class | named | 175 | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/dispatch/model.py` | `Dispatch` | class | named | 245 | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/dispatch/model.py` | `Matcher` | class | named | 55 | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/dispatch/model.py` | `Meta` | class | named | 23 | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/dispatch/model.py` | `Phase` | class | named | 49 | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/dispatch/model.py` | `Policy` | class | named | 33 | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/dispatch/model.py` | `Recovery` | class | named | 100 | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/dispatch/model.py` | `Verdict` | class | named | 147 | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/dispatch/model.py` | `VerifierEvidence` | class | named | 125 | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/dispatch/model.py` | `Verify` | class | named | 85 | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/dispatch/model.py` | `matchers_from_expect` | def | named | 73 | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/runtime_paths.py` | `read_version_file` | def | named | 7 | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/runtime_paths.py` | `resolve_env_path` | def | named | 14 | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/runtime_paths.py` | `vibecrafted_home` | def | named | 29 | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/runtime_paths.py` | `vibecrafted_launcher_bin` | def | named | 52 | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/runtime_paths.py` | `vibecrafted_runtime_bin` | def | named | 46 | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/runtime_paths.py` | `vibecrafted_runtime_home` | def | named | 35 | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/runtime_paths.py` | `vibecrafted_tools_home` | def | named | 39 | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/runtime_paths.py` | `xdg_config_home` | def | named | 21 | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/runtime_paths.py` | `xdg_data_home` | def | named | 25 | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/wrappers.py` | `agents_main` | def | named | 163 | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/wrappers.py` | `deck_path` | def | named | 33 | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/wrappers.py` | `followup_main` | def | named | 167 | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/wrappers.py` | `implement_main` | def | named | 171 | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/wrappers.py` | `marbles_main` | def | named | 175 | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/wrappers.py` | `prune_main` | def | named | 179 | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/wrappers.py` | `repo_root` | def | named | 29 | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/wrappers.py` | `research_await_main` | def | named | 270 | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/wrappers.py` | `research_main` | def | named | 221 | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/wrappers.py` | `research_synthesize_main` | def | named | 291 | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/wrappers.py` | `resume_main` | def | named | 324 | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/wrappers.py` | `review_main` | def | named | 183 | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/wrappers.py` | `sandbox_main` | def | named | 397 | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/wrappers.py` | `scaffold_main` | def | named | 187 | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/wrappers.py` | `stop_main` | def | named | 349 | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/wrappers.py` | `supervised_skill_main` | def | named | 106 | *RepoVerified* |

### Imports

| File | Source | Kind | Resolution | Authority |
|---|---|---|---|---|
| `vibecrafted-app/mux-agent/src/config.rs` | `anyhow` | static | unknown | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/config.rs` | `serde` | static | unknown | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/config.rs` | `std::collections::HashMap` | static | unknown | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/config.rs` | `std::fs` | static | unknown | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/config.rs` | `std::fs::File` | static | unknown | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/config.rs` | `std::io` | static | unknown | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/config.rs` | `std::path` | static | unknown | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/config.rs` | `std::time::Duration` | static | unknown | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/scan.rs` | `anyhow` | static | unknown | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/scan.rs` | `clap::Args` | static | unknown | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/scan.rs` | `crate::config` | static | unknown | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/scan.rs` | `serde` | static | unknown | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/scan.rs` | `std::collections` | static | unknown | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/scan.rs` | `std::fs` | static | unknown | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/scan.rs` | `std::path` | static | unknown | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/scan.rs` | `std::process` | static | unknown | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/state.rs` | `serde` | static | unknown | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/state.rs` | `serde_json::Value` | static | unknown | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/state.rs` | `std::collections::HashMap` | static | unknown | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/state.rs` | `std::sync::Arc` | static | unknown | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/state.rs` | `std::time` | static | unknown | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/state.rs` | `tokio::sync` | static | unknown | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/__init__.py` | `.artifacts` | static | local | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/__init__.py` | `.capabilities` | static | local | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/__init__.py` | `.control_plane` | static | local | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/__init__.py` | `.doctor` | static | local | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/__init__.py` | `.events` | static | local | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/__init__.py` | `.git` | static | local | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/__init__.py` | `.lifecycle` | static | local | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/__init__.py` | `.runtime_paths` | static | local | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/__init__.py` | `.supervisor_async` | static | local | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/__init__.py` | `__future__` | static | unknown | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/__init__.py` | `typing` | static | stdlib | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/control_plane.py` | `argparse` | static | stdlib | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/control_plane.py` | `contextlib` | static | stdlib | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/control_plane.py` | `datetime` | static | stdlib | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/control_plane.py` | `errno` | static | stdlib | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/control_plane.py` | `fcntl` | static | unknown | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/control_plane.py` | `.runtime_paths` | static | local | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/control_plane.py` | `__future__` | static | unknown | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/control_plane.py` | `dataclasses` | static | stdlib | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/control_plane.py` | `pathlib` | static | stdlib | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/control_plane.py` | `typing` | static | stdlib | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/control_plane.py` | `json` | static | stdlib | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/control_plane.py` | `os` | static | stdlib | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/control_plane.py` | `time` | static | stdlib | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/control_plane.py` | `uuid` | static | stdlib | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/dispatch/model.py` | `__future__` | static | unknown | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/dispatch/model.py` | `collections.abc` | static | stdlib | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/dispatch/model.py` | `dataclasses` | static | stdlib | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/dispatch/model.py` | `typing` | static | stdlib | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/dispatch/model.py` | `json` | static | stdlib | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/dispatch/model.py` | `re` | static | stdlib | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/runtime_paths.py` | `__future__` | static | unknown | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/runtime_paths.py` | `pathlib` | static | stdlib | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/runtime_paths.py` | `os` | static | stdlib | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/wrappers.py` | `argparse` | static | stdlib | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/wrappers.py` | `.events` | static | local | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/wrappers.py` | `.spawn` | static | local | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/wrappers.py` | `.workflow` | static | local | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/wrappers.py` | `__future__` | static | unknown | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/wrappers.py` | `pathlib` | static | stdlib | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/wrappers.py` | `typing` | static | stdlib | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/wrappers.py` | `vibecrafted_core.sandbox` | static | local | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/wrappers.py` | `vibecrafted_core.sandbox.policy` | static | local | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/wrappers.py` | `json` | static | stdlib | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/wrappers.py` | `os` | static | stdlib | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/wrappers.py` | `re` | static | stdlib | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/wrappers.py` | `subprocess` | static | stdlib | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/wrappers.py` | `sys` | static | stdlib | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/wrappers.py` | `time` | static | stdlib | *RepoVerified* |

### Consumers

| File | Import Kind | Imports Used | Authority |
|---|---|---|---|
| `bin/vc-agents` | `Direct` | supervised_skill_main | *RepoVerified* |
| `bin/vc-followup` | `Direct` | supervised_skill_main | *RepoVerified* |
| `bin/vc-implement` | `Direct` | supervised_skill_main | *RepoVerified* |
| `bin/vc-marbles` | `Direct` | supervised_skill_main | *RepoVerified* |
| `bin/vc-prune` | `Direct` | supervised_skill_main | *RepoVerified* |
| `bin/vc-research` | `Direct` | research_main | *RepoVerified* |
| `bin/vc-research-await` | `Direct` | research_await_main | *RepoVerified* |
| `bin/vc-research-synthesize` | `Direct` | research_synthesize_main | *RepoVerified* |
| `bin/vc-review` | `Direct` | supervised_skill_main | *RepoVerified* |
| `bin/vc-scaffold` | `Direct` | supervised_skill_main | *RepoVerified* |
| `bin/vibecrafted-resume` | `Direct` | resume_main | *RepoVerified* |
| `scripts/control_plane_state.py` | `Direct` | annotations, control_plane | *RepoVerified* |
| `scripts/installer_gui.py` | `Transitive` | annotations, Any, launch_workflow, normalize_launch_spec, sync_state, read_version_file, vibecrafted_home, xdg_config_home | *RepoVerified* |
| `scripts/runtime_paths.py` | `Reexport` |  | *RepoVerified* |
| `scripts/vetcoders_install.py` | `Transitive` | read_version_file, vibecrafted_launcher_bin, vibecrafted_runtime_home, vibecrafted_runtime_bin, vibecrafted_tools_home, vibecrafted_home, xdg_config_home | *RepoVerified* |
| `tests/agent_dispatch_test.py` | `Direct` | annotations, agent_dispatch | *RepoVerified* |
| `tests/tui/test_keys.py` | `Transitive` | read_version_file, vibecrafted_home | *RepoVerified* |
| `tests/tui/test_research_terminal_safety.py` | `Direct` | _launcher_paths | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/danger.rs` | `Direct` | safe_copy_file, safe_read_to_string | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/ipc/handlers.rs` | `Direct` | scan_hosts | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/lib.rs` | `Reexport` | CliOptions, Config, ResolvedParams, ServerConfig, resolve_params_multi, config | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/main.rs` | `Direct` | expand_path, load_config, resolve_params, config | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/multi.rs` | `Direct` | ResolvedParams | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/multi_tui.rs` | `Direct` | StatusLevel | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/mux_gen.rs` | `Direct` | Config, ServerConfig, expand_path | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/runtime/client.rs` | `Direct` | HANDSHAKE_TIMEOUT, MuxState, Pending, StatusSnapshot, error_response, publish_status, set_id | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/runtime/heartbeat.rs` | `Direct` | HeartbeatMetrics, MuxState, StatusSnapshot, publish_status | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/runtime/mod.rs` | `Direct` | ResolvedParams | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/runtime/server.rs` | `Direct` | MuxState, ServerStatus, StatusSnapshot, publish_status, set_id | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/runtime/status.rs` | `Direct` | MuxState, ServerStatus, StatusLevel, StatusSnapshot | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/runtime/tests.rs` | `Direct` | CliOptions, Config, ResolvedParams, ServerConfig, expand_path, load_config, resolve_params | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/scan.rs` | `Direct` | Config, ServerConfig, expand_path, safe_copy_file, safe_read_to_string | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/tray.rs` | `Direct` | ServerStatus, StatusSnapshot | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/tray_dashboard.rs` | `Transitive` |  | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/wizard/mod.rs` | `Direct` | expand_path | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/wizard/persist.rs` | `Direct` | expand_path | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/wizard/services.rs` | `Direct` | ServerConfig, expand_path | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/wizard/types.rs` | `Direct` | ServerConfig | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/wizard/ui.rs` | `Direct` | HostKind | *RepoVerified* |
| `vibecrafted-app/shell-agent/app/Vibecrafted/Views/InspectorViewController.swift` | `Direct` |  | *RepoVerified* |
| `vibecrafted-core/tests/dispatch/test_cli.py` | `Direct` | annotations, cli | *RepoVerified* |
| `vibecrafted-core/tests/dispatch/test_schema.py` | `Direct` | Baton, CutState, Matcher, STATE_VERIFIED, Verdict, VerifierEvidence | *RepoVerified* |
| `vibecrafted-core/tests/dispatch/test_supervisor.py` | `Direct` | annotations, workflow | *RepoVerified* |
| `vibecrafted-core/tests/dispatch/test_verify.py` | `Direct` | STATE_FAILED, STATE_UNKNOWN, STATE_VERIFIED, Cut, Matcher, Verify | *RepoVerified* |
| `vibecrafted-core/tests/test_agy_junie_pipeline.py` | `Direct` | annotations, workflow | *RepoVerified* |
| `vibecrafted-core/tests/test_aicx_sync.py` | `Direct` | annotations, Any, aicx_sync | *RepoVerified* |
| `vibecrafted-core/tests/test_capabilities.py` | `Direct` | annotations, capabilities | *RepoVerified* |
| `vibecrafted-core/tests/test_cli.py` | `Direct` | annotations, cli | *RepoVerified* |
| `vibecrafted-core/tests/test_compact_hooks.py` | `Direct` | annotations, compact_hooks | *RepoVerified* |
| `vibecrafted-core/tests/test_control_plane.py` | `Direct` | annotations, control_plane, workflow | *RepoVerified* |
| `vibecrafted-core/tests/test_cron.py` | `Direct` | annotations, cron | *RepoVerified* |
| `vibecrafted-core/tests/test_doctor.py` | `Direct` | annotations, doctor | *RepoVerified* |
| `vibecrafted-core/tests/test_git.py` | `Direct` | annotations, git | *RepoVerified* |
| `vibecrafted-core/tests/test_loop_ship.py` | `Direct` | annotations, loop, ship | *RepoVerified* |
| `vibecrafted-core/tests/test_memex_client.py` | `Direct` | annotations, Any, memex_client | *RepoVerified* |
| `vibecrafted-core/tests/test_sandbox_adapter.py` | `Direct` | annotations, control_plane | *RepoVerified* |
| `vibecrafted-core/tests/test_supervisor.py` | `Direct` | annotations, control_plane, append_event | *RepoVerified* |
| `vibecrafted-core/tests/test_supervisor_async.py` | `Direct` | annotations, dispatcher, validate_artifacts, read_event_tail, RunState, transition_allowed, AsyncSupervisor | *RepoVerified* |
| `vibecrafted-core/tests/test_ui.py` | `Direct` | annotations, ui | *RepoVerified* |
| `vibecrafted-core/tests/test_workflow.py` | `Direct` | annotations, Any, workflow | *RepoVerified* |
| `vibecrafted-core/tests/test_workflow_registry.py` | `Direct` | annotations, workflow | *RepoVerified* |
| `vibecrafted-core/tests/test_workflow_runtime.py` | `Direct` | annotations, workflow_runtime | *RepoVerified* |
| `vibecrafted-core/tests/test_wrappers.py` | `Direct` | annotations, wrappers, workflow | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/__init__.py` | `Reexport` | read_version_file, resolve_env_path, vibecrafted_home, xdg_config_home | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/capabilities.py` | `Direct` | vibecrafted_launcher_bin | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/cli.py` | `Direct` | stop_main | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/compact_hooks.py` | `Direct` | vibecrafted_home | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/control_plane.py` | `Direct` | vibecrafted_home | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/cron.py` | `Direct` | vibecrafted_home | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/dispatch/__init__.py` | `Reexport` | Baton, Common, Cut, CutState, Dispatch, Matcher, Meta, Phase, Policy, Recovery, Verdict, VerifierEvidence, Verify | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/dispatch/cli.py` | `Direct` | Dispatch, STATE_VERIFIED | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/dispatch/doctor.py` | `Direct` | Dispatch | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/dispatch/schema.py` | `Direct` | CRITICAL_FAIL_POLICIES, MATCHER_TYPES, READ_MUTATIONS, SCHEMA_VERSION, TIMEOUT_POLICIES, Baton, Common, Cut, Dispatch, Matcher, Meta, Phase, Policy, Recovery, Verify | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/dispatch/supervisor.py` | `Direct` | STATE_FAILED, STATE_PENDING, STATE_UNKNOWN, STATE_VERIFIED, STATE_WORKER_DONE, Baton, Cut, Dispatch, Verdict | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/dispatch/verify.py` | `Direct` | STATE_FAILED, STATE_UNKNOWN, STATE_VERIFIED, Cut, Verdict, VerifierEvidence, Verify | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/sandbox/msbserver_lifecycle.py` | `Direct` | vibecrafted_home | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/sandbox/policy.py` | `Direct` | vibecrafted_home | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/spawn.py` | `Direct` | ensure_session_id, normalize_run_root | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/supervisor_async.py` | `Direct` | ensure_session_id, normalize_run_root | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/workflow.py` | `Direct` | await_run, control_plane_home, ensure_session_id, lookup_run, normalize_run_root, operator_session_name, record_stop_transition, run_snapshot_dir, sync_state | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/workflows/registry.py` | `Direct` | vibecrafted_tools_home | *RepoVerified* |
| `vibecrafted-mcp/vibecrafted_mcp/server.py` | `Direct` | annotations, Any, capabilities, control_plane, doctor, git, workflow | *RepoVerified* |

### Entrypoints

| Path | Kinds | Authority |
|---|---|---|
| `scripts/control_plane_state.py` | script | *RepoVerified* |
| `scripts/installer_gui.py` | script | *RepoVerified* |
| `scripts/vetcoders_install.py` | script | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/main.rs` | main, async_main | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/cli.py` | script | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/compact_hooks.py` | script | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/control_plane.py` | script | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/cron.py` | script | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/dispatch/cli.py` | script | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/dispatch/doctor.py` | script | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/spawn.py` | script | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/workflow_runtime.py` | script | *RepoVerified* |
| `vibecrafted-mcp/vibecrafted_mcp/server.py` | script | *RepoVerified* |

## Runtime Slice

### Idiom Tags

- **as_label** (`vibecrafted-app/mux-agent/src/scan.rs::as_label`): Defined inside inherent `impl HostKind` block; reached via method-call syntax. (Role: library_helper, Source: inferred_from_code) *SemanticGuess*
- **display_name** (`vibecrafted-app/mux-agent/src/scan.rs::display_name`): Defined inside inherent `impl HostKind` block; reached via method-call syntax. (Role: library_helper, Source: inferred_from_code) *SemanticGuess*
- **into_host_service** (`vibecrafted-app/mux-agent/src/scan.rs::into_host_service`): Defined inside inherent `impl DiscoveredMcp` block; reached via method-call syntax. (Role: library_helper, Source: inferred_from_code) *SemanticGuess*
- **buffer_message** (`vibecrafted-app/mux-agent/src/state.rs::buffer_message`): Defined inside inherent `impl MuxState` block; reached via method-call syntax. (Role: library_helper, Source: inferred_from_code) *SemanticGuess*
- **complete_handshake** (`vibecrafted-app/mux-agent/src/state.rs::complete_handshake`): Defined inside inherent `impl MuxState` block; reached via method-call syntax. (Role: library_helper, Source: inferred_from_code) *SemanticGuess*
- **get_handshake_mut** (`vibecrafted-app/mux-agent/src/state.rs::get_handshake_mut`): Defined inside inherent `impl MuxState` block; reached via method-call syntax. (Role: library_helper, Source: inferred_from_code) *SemanticGuess*
- **is_handshake_complete** (`vibecrafted-app/mux-agent/src/state.rs::is_handshake_complete`): Defined inside inherent `impl MuxState` block; reached via method-call syntax. (Role: library_helper, Source: inferred_from_code) *SemanticGuess*
- **is_handshake_timed_out** (`vibecrafted-app/mux-agent/src/state.rs::is_handshake_timed_out`): Defined inside inherent `impl MuxState` block; reached via method-call syntax. (Role: library_helper, Source: inferred_from_code) *SemanticGuess*
- **mark_handshake_complete** (`vibecrafted-app/mux-agent/src/state.rs::mark_handshake_complete`): Defined inside inherent `impl MuxState` block; reached via method-call syntax. (Role: library_helper, Source: inferred_from_code) *SemanticGuess*
- **new** (`vibecrafted-app/mux-agent/src/state.rs::new`): Idiomatic Rust constructor convention; called via Type::new(...) across the ecosystem. (Role: library_helper, Source: embedded_default) *LoctreeDerived*
- **next_request_id** (`vibecrafted-app/mux-agent/src/state.rs::next_request_id`): Defined inside inherent `impl MuxState` block; reached via method-call syntax. (Role: library_helper, Source: inferred_from_code) *SemanticGuess*
- **register_client** (`vibecrafted-app/mux-agent/src/state.rs::register_client`): Defined inside inherent `impl MuxState` block; reached via method-call syntax. (Role: library_helper, Source: inferred_from_code) *SemanticGuess*
- **unregister_client** (`vibecrafted-app/mux-agent/src/state.rs::unregister_client`): Defined inside inherent `impl MuxState` block; reached via method-call syntax. (Role: library_helper, Source: inferred_from_code) *SemanticGuess*

### Reachability

- `vibecrafted-app/mux-agent/src/scan.rs::as_label`: Reached (idiom_runtime_role:library_helper) *SemanticGuess*
- `vibecrafted-app/mux-agent/src/scan.rs::display_name`: Reached (idiom_runtime_role:library_helper) *SemanticGuess*
- `vibecrafted-app/mux-agent/src/scan.rs::into_host_service`: Reached (idiom_runtime_role:library_helper) *SemanticGuess*
- `vibecrafted-app/mux-agent/src/state.rs::buffer_message`: Reached (idiom_runtime_role:library_helper) *SemanticGuess*
- `vibecrafted-app/mux-agent/src/state.rs::complete_handshake`: Reached (idiom_runtime_role:library_helper) *SemanticGuess*
- `vibecrafted-app/mux-agent/src/state.rs::get_handshake_mut`: Reached (idiom_runtime_role:library_helper) *SemanticGuess*
- `vibecrafted-app/mux-agent/src/state.rs::is_handshake_complete`: Reached (idiom_runtime_role:library_helper) *SemanticGuess*
- `vibecrafted-app/mux-agent/src/state.rs::is_handshake_timed_out`: Reached (idiom_runtime_role:library_helper) *SemanticGuess*
- `vibecrafted-app/mux-agent/src/state.rs::mark_handshake_complete`: Reached (idiom_runtime_role:library_helper) *SemanticGuess*
- `vibecrafted-app/mux-agent/src/state.rs::new`: Reached (idiom_runtime_role:library_helper) *SemanticGuess*
- `vibecrafted-app/mux-agent/src/state.rs::next_request_id`: Reached (idiom_runtime_role:library_helper) *SemanticGuess*
- `vibecrafted-app/mux-agent/src/state.rs::register_client`: Reached (idiom_runtime_role:library_helper) *SemanticGuess*
- `vibecrafted-app/mux-agent/src/state.rs::unregister_client`: Reached (idiom_runtime_role:library_helper) *SemanticGuess*

### Env Contracts

- `VIBECRAFTED_HOME` used in 20 files *LoctreeDerived*
- `VIBECRAFTED_RUN_ID` used in 6 files *LoctreeDerived*

### Framework Hints

- `rust:inherent_impl_method` at `vibecrafted-app/mux-agent/src/scan.rs`: vibecrafted-app/mux-agent/src/scan.rs::as_label *LoctreeDerived*
- `rust:inherent_impl_method` at `vibecrafted-app/mux-agent/src/scan.rs`: vibecrafted-app/mux-agent/src/scan.rs::display_name *LoctreeDerived*
- `rust:inherent_impl_method` at `vibecrafted-app/mux-agent/src/scan.rs`: vibecrafted-app/mux-agent/src/scan.rs::into_host_service *LoctreeDerived*
- `rust:inherent_impl_method` at `vibecrafted-app/mux-agent/src/state.rs`: vibecrafted-app/mux-agent/src/state.rs::buffer_message *LoctreeDerived*
- `rust:inherent_impl_method` at `vibecrafted-app/mux-agent/src/state.rs`: vibecrafted-app/mux-agent/src/state.rs::complete_handshake *LoctreeDerived*
- `rust:inherent_impl_method` at `vibecrafted-app/mux-agent/src/state.rs`: vibecrafted-app/mux-agent/src/state.rs::get_handshake_mut *LoctreeDerived*
- `rust:inherent_impl_method` at `vibecrafted-app/mux-agent/src/state.rs`: vibecrafted-app/mux-agent/src/state.rs::is_handshake_complete *LoctreeDerived*
- `rust:inherent_impl_method` at `vibecrafted-app/mux-agent/src/state.rs`: vibecrafted-app/mux-agent/src/state.rs::is_handshake_timed_out *LoctreeDerived*
- `rust:inherent_impl_method` at `vibecrafted-app/mux-agent/src/state.rs`: vibecrafted-app/mux-agent/src/state.rs::mark_handshake_complete *LoctreeDerived*
- `rust:inherent_impl_method` at `vibecrafted-app/mux-agent/src/state.rs`: vibecrafted-app/mux-agent/src/state.rs::new *LoctreeDerived*
- `rust:inherent_impl_method` at `vibecrafted-app/mux-agent/src/state.rs`: vibecrafted-app/mux-agent/src/state.rs::next_request_id *LoctreeDerived*
- `rust:inherent_impl_method` at `vibecrafted-app/mux-agent/src/state.rs`: vibecrafted-app/mux-agent/src/state.rs::register_client *LoctreeDerived*
- `rust:inherent_impl_method` at `vibecrafted-app/mux-agent/src/state.rs`: vibecrafted-app/mux-agent/src/state.rs::unregister_client *LoctreeDerived*
- `entrypoint` at `vibecrafted-core/vibecrafted_core/control_plane.py`: script *RepoVerified*

## Risk Slice

- Cache Scope: `DirtyWorktree` *RepoVerified*
- Snapshot Health: `dirty`
- Stale Snapshot: false
- Dirty Worktree: true

### Hotspots

| File | Importers | Authority |
|---|---|---|
| `vibecrafted-core/vibecrafted_core/__init__.py` | 24 | *LoctreeDerived* |
| `vibecrafted-app/mux-agent/src/config.rs` | 13 | *LoctreeDerived* |
| `vibecrafted-core/vibecrafted_core/wrappers.py` | 13 | *LoctreeDerived* |
| `vibecrafted-app/mux-agent/src/state.rs` | 12 | *LoctreeDerived* |
| `vibecrafted-app/mux-agent/src/scan.rs` | 10 | *LoctreeDerived* |
| `vibecrafted-core/vibecrafted_core/dispatch/model.py` | 10 | *LoctreeDerived* |
| `vibecrafted-core/vibecrafted_core/runtime_paths.py` | 9 | *LoctreeDerived* |
| `vibecrafted-core/vibecrafted_core/control_plane.py` | 7 | *LoctreeDerived* |

### High Fan-In

| File | Importers | Authority |
|---|---|---|
| `vibecrafted-core/vibecrafted_core/__init__.py` | 24 | *LoctreeDerived* |
| `vibecrafted-app/mux-agent/src/config.rs` | 13 | *LoctreeDerived* |
| `vibecrafted-core/vibecrafted_core/wrappers.py` | 13 | *LoctreeDerived* |
| `vibecrafted-app/mux-agent/src/state.rs` | 12 | *LoctreeDerived* |
| `vibecrafted-app/mux-agent/src/scan.rs` | 10 | *LoctreeDerived* |
| `vibecrafted-core/vibecrafted_core/dispatch/model.py` | 10 | *LoctreeDerived* |

## Action Slice

### Power Path

- `loct slice vibecrafted-core/vibecrafted_core/__init__.py`: Slice this file to inspect its direct dependencies and immediate consumers before editing.
- `loct impact vibecrafted-core/vibecrafted_core/__init__.py`: Assess the transitive blast radius and downstream consumers of this file before modifying.
- `loct body annotations`: View the definition body of symbol 'annotations' to understand its implementation structure.
- `loct find --literal annotations`: Execute a literal exact-identifier scan for 'annotations' to find exact matches across the codebase.
- `loct occurrences annotations`: Perform a literal boundary-sensitive occurrences scan for 'annotations' to locate all references.
- `loct follow`: Pursue unified structural signals (dead exports, import cycles, twins) to ensure health.
- `loct slice vibecrafted-app/mux-agent/src/config.rs`: Slice this file to inspect its direct dependencies and immediate consumers before editing.
- `loct impact vibecrafted-app/mux-agent/src/config.rs`: Assess the transitive blast radius and downstream consumers of this file before modifying.
- `loct body expand_path`: View the definition body of symbol 'expand_path' to understand its implementation structure.
- `loct find --literal expand_path`: Execute a literal exact-identifier scan for 'expand_path' to find exact matches across the codebase.
- `loct occurrences expand_path`: Perform a literal boundary-sensitive occurrences scan for 'expand_path' to locate all references.
- `loct slice vibecrafted-core/vibecrafted_core/wrappers.py`: Slice this file to inspect its direct dependencies and immediate consumers before editing.
- `loct impact vibecrafted-core/vibecrafted_core/wrappers.py`: Assess the transitive blast radius and downstream consumers of this file before modifying.
- `loct body repo_root`: View the definition body of symbol 'repo_root' to understand its implementation structure.
- `loct find --literal repo_root`: Execute a literal exact-identifier scan for 'repo_root' to find exact matches across the codebase.
- `loct occurrences repo_root`: Perform a literal boundary-sensitive occurrences scan for 'repo_root' to locate all references.
- `loct slice vibecrafted-app/mux-agent/src/state.rs`: Slice this file to inspect its direct dependencies and immediate consumers before editing.
- `loct impact vibecrafted-app/mux-agent/src/state.rs`: Assess the transitive blast radius and downstream consumers of this file before modifying.
- `loct body new`: View the definition body of symbol 'new' to understand its implementation structure.
- `loct find --literal new`: Execute a literal exact-identifier scan for 'new' to find exact matches across the codebase.
- `loct occurrences new`: Perform a literal boundary-sensitive occurrences scan for 'new' to locate all references.
- `loct slice vibecrafted-app/mux-agent/src/scan.rs`: Slice this file to inspect its direct dependencies and immediate consumers before editing.
- `loct impact vibecrafted-app/mux-agent/src/scan.rs`: Assess the transitive blast radius and downstream consumers of this file before modifying.
- `loct body as_label`: View the definition body of symbol 'as_label' to understand its implementation structure.
- `loct find --literal as_label`: Execute a literal exact-identifier scan for 'as_label' to find exact matches across the codebase.
- `loct occurrences as_label`: Perform a literal boundary-sensitive occurrences scan for 'as_label' to locate all references.
- `loct slice vibecrafted-core/vibecrafted_core/dispatch/model.py`: Slice this file to inspect its direct dependencies and immediate consumers before editing.
- `loct impact vibecrafted-core/vibecrafted_core/dispatch/model.py`: Assess the transitive blast radius and downstream consumers of this file before modifying.
- `loct body Meta`: View the definition body of symbol 'Meta' to understand its implementation structure.
- `loct find --literal Meta`: Execute a literal exact-identifier scan for 'Meta' to find exact matches across the codebase.
- `loct occurrences Meta`: Perform a literal boundary-sensitive occurrences scan for 'Meta' to locate all references.
- `loct slice vibecrafted-core/vibecrafted_core/runtime_paths.py`: Slice this file to inspect its direct dependencies and immediate consumers before editing.
- `loct impact vibecrafted-core/vibecrafted_core/runtime_paths.py`: Assess the transitive blast radius and downstream consumers of this file before modifying.
- `loct body read_version_file`: View the definition body of symbol 'read_version_file' to understand its implementation structure.
- `loct find --literal read_version_file`: Execute a literal exact-identifier scan for 'read_version_file' to find exact matches across the codebase.
- `loct occurrences read_version_file`: Perform a literal boundary-sensitive occurrences scan for 'read_version_file' to locate all references.
- `loct slice vibecrafted-core/vibecrafted_core/control_plane.py`: Slice this file to inspect its direct dependencies and immediate consumers before editing.
- `loct impact vibecrafted-core/vibecrafted_core/control_plane.py`: Assess the transitive blast radius and downstream consumers of this file before modifying.
- `loct body RunStatus`: View the definition body of symbol 'RunStatus' to understand its implementation structure.
- `loct find --literal RunStatus`: Execute a literal exact-identifier scan for 'RunStatus' to find exact matches across the codebase.
- `loct occurrences RunStatus`: Perform a literal boundary-sensitive occurrences scan for 'RunStatus' to locate all references.

### Next Safe Commands

```bash
loct slice vibecrafted-core/vibecrafted_core/__init__.py
loct impact vibecrafted-core/vibecrafted_core/__init__.py
loct find annotations
```

### Verification Gates

```bash
mypy .
```

### Likely Tests

- `plugins/iterm2/tests/test_iterm2_plugin.py`
- `tests/agent_dispatch_test.py`
- `tests/tui/test_keys.py`
- `tests/tui/test_research_terminal_safety.py`
- `vibecrafted-app/tui-agent/tests/state_contract.rs`
- `vibecrafted-core/tests/dispatch/test_cli.py`
- `vibecrafted-core/tests/dispatch/test_schema.py`
- `vibecrafted-core/tests/dispatch/test_supervisor.py`
- `vibecrafted-core/tests/dispatch/test_verify.py`
- `vibecrafted-core/tests/test_agy_junie_pipeline.py`

## Memory Slice

_Empty_

## Authority Slice

- Repo Verified: 2
- Loctree Derived: 44
- AICX Operator: 0
- AICX Agent: 0
- AICX Failure: 0
- Semantic Guess: 25
- Stale Or Unknown: 0

