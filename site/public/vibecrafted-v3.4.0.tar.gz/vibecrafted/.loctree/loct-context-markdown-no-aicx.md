# Loctree Context · vibecrafted @ feat/runtime-integration · 2026-06-15T12:37:55.635569Z

_710 files · 468 import edges · snapshot fresh · dirty worktree_

## TL;DR — read this first

**What this is.** `vibecrafted` repository — current focus: _Runtime Integration_.

**Where you stand.** Branch `feat/runtime-integration`, dirty worktree, snapshot fresh.
Last 5 commits: `480ffb8 [codex/implement] fix(runtime): centralize launcher ulimit hardening` · `3e9ea7a [claude/vc-implement] fix(spawn): read run-closure footer tokens for all agents` · `dadcbd4 [claude/vc-implement] fix(agent-stream): render gemini token line for spawn extractor`

**Top 3 things to know before editing.**
1. Hub `vibecrafted-core/vibecrafted_core/__init__.py` has 24 importers — touching it = wide blast radius (of 30 ranked hubs). (LoctreeDerived)
2. 6 high-fan-in file(s) exceed threshold — review impact before edits. (LoctreeDerived)
3. Env var `VIBECRAFTED_HOME` is read by 27 file(s) in scope — verify before refactoring config flow. (LoctreeDerived)

**Snapshot facts.** 30 hubs · 20 idiom tag(s) · 0 dispatch edge(s) · 2 env contract(s) · 0 memory entries · 91 authority claim(s).

**What's stale.** None.

## Where You Are

### Hubs — touch = blast radius

| File | Importers | Authority |
|---|---:|---|
| `vibecrafted-core/vibecrafted_core/__init__.py` | 24 | LoctreeDerived |
| `vibecrafted-app/mux-agent/src/config.rs` | 13 | LoctreeDerived |
| `vibecrafted-core/vibecrafted_core/wrappers.py` | 13 | LoctreeDerived |
| `vibecrafted-app/mux-agent/src/state.rs` | 12 | LoctreeDerived |
| `vibecrafted-app/mux-agent/src/scan.rs` | 10 | LoctreeDerived |
| `vibecrafted-core/vibecrafted_core/dispatch/model.py` | 10 | LoctreeDerived |
| `vibecrafted-core/vibecrafted_core/runtime_paths.py` | 9 | LoctreeDerived |
| `vibecrafted-app/tray-agent/src/types.rs` | 8 | LoctreeDerived |

### Cycles

- not_measured (run `loct cycles` for current measurement) (LoctreeDerived)

### Recently active surface (last 24h)

- `.gitignore` (RepoVerified)
- `Makefile` (RepoVerified)
- `config/zellij/layouts/operator.kdl` (RepoVerified)
- `runtime/scripts/common.sh` (RepoVerified)
- `runtime/scripts/lib/launcher.sh` (RepoVerified)
- `runtime/scripts/lib/ulimits.sh` (RepoVerified)
- `runtime/scripts/lib/zellij.sh` (RepoVerified)
- `runtime/shell/lib/dashboard.sh` (RepoVerified)
- `runtime/shell/lib/ulimits.sh` (RepoVerified)
- `runtime/shell/lib/zellij.sh` (RepoVerified)

### Risk metrics

- dead_exports: not_measured (use-graph counts `pub use` re-exports as live — known limitation; run `loct dead` for current count) (RepoVerified)
- twins: not_measured (run `loct twins` for a context-classified pass) (RepoVerified)
- cache_scope: `DirtyWorktree` (RepoVerified)
- high_fan_in: 6 files over threshold 10 (LoctreeDerived)

## What's Live

### Idiom tag clusters (top 10 by hit count)

- `idiom:rust-inherent-impl` (19 hits) — method-call reachability via inherent impls (SemanticGuess)

### Dispatch edges (top 5 by reach)

- _no dispatch edges in scope_ (LoctreeDerived)

### Env contracts (vars used in scope)

- `VIBECRAFTED_HOME` — used in 27 file(s) (LoctreeDerived)
- `VIBECRAFTED_RUN_ID` — used in 7 file(s) (LoctreeDerived)

### Reachability (top 5 widely-reached symbols)

- `vibecrafted-app/mux-agent/src/scan.rs::as_label` — reason: `idiom_runtime_role:library_helper` (SemanticGuess)
- `vibecrafted-app/mux-agent/src/scan.rs::display_name` — reason: `idiom_runtime_role:library_helper` (SemanticGuess)
- `vibecrafted-app/mux-agent/src/scan.rs::into_host_service` — reason: `idiom_runtime_role:library_helper` (SemanticGuess)
- `vibecrafted-app/mux-agent/src/state.rs::buffer_message` — reason: `idiom_runtime_role:library_helper` (SemanticGuess)
- `vibecrafted-app/mux-agent/src/state.rs::complete_handshake` — reason: `idiom_runtime_role:library_helper` (SemanticGuess)

## Memory

_AICX overlay disabled by `--no-aicx`; memory overlay intentionally omitted._ (RepoVerified)

## Action

### Power Path (suggested next steps)

- `loct slice vibecrafted-core/vibecrafted_core/__init__.py`: Slice this file to inspect its direct dependencies and immediate consumers before editing.
- `loct impact vibecrafted-core/vibecrafted_core/__init__.py`: Assess the transitive blast radius and downstream consumers of this file before modifying.
- `loct body annotations`: View the definition body of symbol 'annotations' to understand its implementation structure.
- `loct find --literal annotations`: Execute a literal exact-identifier scan for 'annotations' to find exact matches across the codebase.
- `loct occurrences annotations`: Perform a literal boundary-sensitive occurrences scan for 'annotations' to locate all references.
- `loct follow`: Pursue unified structural signals (dead exports, import cycles, twins) to ensure health.
- `loct slice vibecrafted-app/mux-agent/src/config.rs`: Slice this file to inspect its direct dependencies and immediate consumers before editing.
- `loct impact vibecrafted-app/mux-agent/src/config.rs`: Assess the transitive blast radius and downstream consumers of this file before modifying.
- `loct body expand_path`: View the definition body of symbol 'expand_path' to understand its implementation structure.
- `loct find --literal expand_path`: Execute a literal exact-identifier scan for 'expand_path' to find exact matches across the codebase.
- `loct occurrences expand_path`: Perform a literal boundary-sensitive occurrences scan for 'expand_path' to locate all references.
- `loct slice vibecrafted-core/vibecrafted_core/wrappers.py`: Slice this file to inspect its direct dependencies and immediate consumers before editing.
- `loct impact vibecrafted-core/vibecrafted_core/wrappers.py`: Assess the transitive blast radius and downstream consumers of this file before modifying.
- `loct body repo_root`: View the definition body of symbol 'repo_root' to understand its implementation structure.
- `loct find --literal repo_root`: Execute a literal exact-identifier scan for 'repo_root' to find exact matches across the codebase.
- `loct occurrences repo_root`: Perform a literal boundary-sensitive occurrences scan for 'repo_root' to locate all references.
- `loct slice vibecrafted-app/mux-agent/src/state.rs`: Slice this file to inspect its direct dependencies and immediate consumers before editing.
- `loct impact vibecrafted-app/mux-agent/src/state.rs`: Assess the transitive blast radius and downstream consumers of this file before modifying.
- `loct body new`: View the definition body of symbol 'new' to understand its implementation structure.
- `loct find --literal new`: Execute a literal exact-identifier scan for 'new' to find exact matches across the codebase.
- `loct occurrences new`: Perform a literal boundary-sensitive occurrences scan for 'new' to locate all references.
- `loct slice vibecrafted-app/mux-agent/src/scan.rs`: Slice this file to inspect its direct dependencies and immediate consumers before editing.
- `loct impact vibecrafted-app/mux-agent/src/scan.rs`: Assess the transitive blast radius and downstream consumers of this file before modifying.
- `loct body as_label`: View the definition body of symbol 'as_label' to understand its implementation structure.
- `loct find --literal as_label`: Execute a literal exact-identifier scan for 'as_label' to find exact matches across the codebase.
- `loct occurrences as_label`: Perform a literal boundary-sensitive occurrences scan for 'as_label' to locate all references.
- `loct slice vibecrafted-core/vibecrafted_core/dispatch/model.py`: Slice this file to inspect its direct dependencies and immediate consumers before editing.
- `loct impact vibecrafted-core/vibecrafted_core/dispatch/model.py`: Assess the transitive blast radius and downstream consumers of this file before modifying.
- `loct body Meta`: View the definition body of symbol 'Meta' to understand its implementation structure.
- `loct find --literal Meta`: Execute a literal exact-identifier scan for 'Meta' to find exact matches across the codebase.
- `loct occurrences Meta`: Perform a literal boundary-sensitive occurrences scan for 'Meta' to locate all references.
- `loct slice vibecrafted-core/vibecrafted_core/runtime_paths.py`: Slice this file to inspect its direct dependencies and immediate consumers before editing.
- `loct impact vibecrafted-core/vibecrafted_core/runtime_paths.py`: Assess the transitive blast radius and downstream consumers of this file before modifying.
- `loct body read_version_file`: View the definition body of symbol 'read_version_file' to understand its implementation structure.
- `loct find --literal read_version_file`: Execute a literal exact-identifier scan for 'read_version_file' to find exact matches across the codebase.
- `loct occurrences read_version_file`: Perform a literal boundary-sensitive occurrences scan for 'read_version_file' to locate all references.
- `loct slice vibecrafted-app/tray-agent/src/types.rs`: Slice this file to inspect its direct dependencies and immediate consumers before editing.
- `loct impact vibecrafted-app/tray-agent/src/types.rs`: Assess the transitive blast radius and downstream consumers of this file before modifying.
- `loct body tooltip`: View the definition body of symbol 'tooltip' to understand its implementation structure.
- `loct find --literal tooltip`: Execute a literal exact-identifier scan for 'tooltip' to find exact matches across the codebase.
- `loct occurrences tooltip`: Perform a literal boundary-sensitive occurrences scan for 'tooltip' to locate all references.

### Next safe commands (grounded, ≤3)

```bash
loct slice vibecrafted-core/vibecrafted_core/__init__.py
loct impact vibecrafted-core/vibecrafted_core/__init__.py
loct find annotations
```

### Verification gates (run before any commit)

- `mypy .` (SemanticGuess)

### Likely tests for current scope

- `plugins/iterm2/tests/test_iterm2_plugin.py` (LoctreeDerived)
- `tests/agent_dispatch_test.py` (LoctreeDerived)
- `tests/tui/test_keys.py` (LoctreeDerived)
- `tests/tui/test_research_terminal_safety.py` (LoctreeDerived)
- `vibecrafted-app/tray-agent/tests/spawn_update_render_test.rs` (LoctreeDerived)
- `vibecrafted-app/tui-agent/tests/state_contract.rs` (LoctreeDerived)
- `vibecrafted-core/tests/dispatch/test_cli.py` (LoctreeDerived)
- `vibecrafted-core/tests/dispatch/test_schema.py` (LoctreeDerived)
- `vibecrafted-core/tests/dispatch/test_supervisor.py` (LoctreeDerived)
- `vibecrafted-core/tests/dispatch/test_verify.py` (LoctreeDerived)

## Authority Index

_91 total claims tagged with provenance._

- **RepoVerified** (1) — AST + git state derivation
- **LoctreeDerived** (51) — snapshot edges + idiom catalogs
- **AicxOperator** (0) — operator decisions / intents from AICX
- **AicxAgent** (0) — agent outcomes (verify before propagating)
- **AicxFailure** (0) — anti-recommendations (avoid repeating)
- **SemanticGuess** (39) — heuristic only, low trust
- **StaleOrUnknown** (0) — explicit "we don't know"


---

*`loct context` rendered in 12096ms · sections: where=39L · live=23L · memory=4L · `--full` for full ContextPack data · `--file <X>` to narrow scope*
