# Loctree Context Pack

## Project Identity

- **Root**: `/Users/maciejgad/vc-workspace/VetCoders/vibecrafted`
- **Branch**: `release/v3.0.0-dev`
- **Commit**: `f35e903`
- **Snapshot**: `release_v3.0.0-dev@f35e903`

## Where You Are

### Files

| Path | Role | Language | LOC | Authority |
|---|---|---|---|---|
| `../runtime/scripts/lib/zellij.sh` | `Target` | shell | 659 | *RepoVerified* |
| `templates/hooks/install.sh` | `Target` | shell | 364 | *RepoVerified* |
| `templates/hooks/lib/core.sh` | `Target` | shell | 389 | *RepoVerified* |
| `tests/agent_dispatch_test.py` | `Consumer` | py | 276 | *RepoVerified* |
| `tests/race_protection_test.sh` | `Target` | shell | 352 | *RepoVerified* |
| `vibecrafted-core/tests/test_agy_junie_pipeline.py` | `Consumer` | py | 57 | *RepoVerified* |
| `vibecrafted-core/tests/test_aicx_sync.py` | `Consumer` | py | 536 | *RepoVerified* |
| `vibecrafted-core/tests/test_control_plane.py` | `Consumer` | py | 125 | *RepoVerified* |
| `vibecrafted-core/tests/test_doctor.py` | `Consumer` | py | 41 | *RepoVerified* |
| `vibecrafted-core/tests/test_git.py` | `Consumer` | py | 39 | *RepoVerified* |
| `vibecrafted-core/tests/test_iterm2_osc.py` | `Consumer` | py | 218 | *RepoVerified* |
| `vibecrafted-core/tests/test_iterm2_plugin.py` | `Consumer` | py | 378 | *RepoVerified* |
| `vibecrafted-core/tests/test_iterm2_profiles.py` | `Consumer` | py | 516 | *RepoVerified* |
| `vibecrafted-core/tests/test_memex_client.py` | `Consumer` | py | 397 | *RepoVerified* |
| `vibecrafted-core/tests/test_sandbox_adapter.py` | `Consumer` | py | 196 | *RepoVerified* |
| `vibecrafted-core/tests/test_supervisor.py` | `Consumer` | py | 105 | *RepoVerified* |
| `vibecrafted-core/tests/test_workflow.py` | `Consumer` | py | 66 | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/__init__.py` | `Target` | py | 151 | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/agent_dispatch.py` | `Target` | py | 296 | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/control_plane.py` | `Dependency` | py | 653 | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/doctor.py` | `Dependency` | py | 82 | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/events.py` | `Dependency` | py | 24 | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/git.py` | `Dependency` | py | 192 | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/runtime_paths.py` | `Dependency` | py | 28 | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/sandbox/adapter.py` | `Consumer` | py | 228 | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/sandbox/msbserver_lifecycle.py` | `Consumer` | py | 157 | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/sandbox/policy.py` | `Consumer` | py | 131 | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/spawn.py` | `Consumer` | py | 384 | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/workflow.py` | `Dependency` | py | 155 | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/wrappers.py` | `Consumer` | py | 315 | *RepoVerified* |
| `vibecrafted-mcp/vibecrafted_mcp/server.py` | `Consumer` | py | 358 | *RepoVerified* |

### Symbols

| File | Name | Kind | Export Type | Line | Authority |
|---|---|---|---|---|---|
| `../runtime/scripts/lib/zellij.sh` | `VIBECRAFTED_OPERATOR_SESSION` | env | named | 459 | *RepoVerified* |
| `../runtime/scripts/lib/zellij.sh` | `spawn_acquire_zellij_launch_slot` | function | named | 52 | *RepoVerified* |
| `../runtime/scripts/lib/zellij.sh` | `spawn_await_watch_pane` | function | named | 418 | *RepoVerified* |
| `../runtime/scripts/lib/zellij.sh` | `spawn_current_focused_pane_id` | function | named | 190 | *RepoVerified* |
| `../runtime/scripts/lib/zellij.sh` | `spawn_current_tab_id` | function | named | 100 | *RepoVerified* |
| `../runtime/scripts/lib/zellij.sh` | `spawn_current_tab_name` | function | named | 273 | *RepoVerified* |
| `../runtime/scripts/lib/zellij.sh` | `spawn_current_zellij_session_name` | function | named | 10 | *RepoVerified* |
| `../runtime/scripts/lib/zellij.sh` | `spawn_effective_operator_session` | function | named | 14 | *RepoVerified* |
| `../runtime/scripts/lib/zellij.sh` | `spawn_in_marbles_tab` | function | named | 278 | *RepoVerified* |
| `../runtime/scripts/lib/zellij.sh` | `spawn_in_operator_session` | function | named | 444 | *RepoVerified* |
| `../runtime/scripts/lib/zellij.sh` | `spawn_in_target_zellij_session` | function | named | 39 | *RepoVerified* |
| `../runtime/scripts/lib/zellij.sh` | `spawn_in_zellij_context` | function | named | 4 | *RepoVerified* |
| `../runtime/scripts/lib/zellij.sh` | `spawn_in_zellij_pane` | function | named | 345 | *RepoVerified* |
| `../runtime/scripts/lib/zellij.sh` | `spawn_pane_direction` | function | named | 246 | *RepoVerified* |
| `../runtime/scripts/lib/zellij.sh` | `spawn_probe` | function | named | 504 | *RepoVerified* |
| `../runtime/scripts/lib/zellij.sh` | `spawn_probe_notify` | function | named | 641 | *RepoVerified* |
| `../runtime/scripts/lib/zellij.sh` | `spawn_probe_watch` | function | named | 565 | *RepoVerified* |
| `../runtime/scripts/lib/zellij.sh` | `spawn_release_zellij_launch_slot` | function | named | 94 | *RepoVerified* |
| `../runtime/scripts/lib/zellij.sh` | `spawn_tab_id_by_name` | function | named | 135 | *RepoVerified* |
| `../runtime/scripts/lib/zellij.sh` | `spawn_zellij_launch_lock_key` | function | named | 47 | *RepoVerified* |
| `templates/hooks/install.sh` | `activator_husky` | function | named | 236 | *RepoVerified* |
| `templates/hooks/install.sh` | `activator_lefthook` | function | named | 198 | *RepoVerified* |
| `templates/hooks/install.sh` | `activator_manual` | function | named | 294 | *RepoVerified* |
| `templates/hooks/install.sh` | `activator_precommit` | function | named | 264 | *RepoVerified* |
| `templates/hooks/install.sh` | `do_cp` | function | named | 95 | *RepoVerified* |
| `templates/hooks/install.sh` | `do_mkdir` | function | named | 104 | *RepoVerified* |
| `templates/hooks/install.sh` | `say` | function | named | 94 | *RepoVerified* |
| `templates/hooks/lib/core.sh` | `husky_apply_defaults` | function | named | 51 | *RepoVerified* |
| `templates/hooks/lib/core.sh` | `husky_current_branch` | function | named | 112 | *RepoVerified* |
| `templates/hooks/lib/core.sh` | `husky_err` | function | named | 105 | *RepoVerified* |
| `templates/hooks/lib/core.sh` | `husky_hash_file` | function | named | 145 | *RepoVerified* |
| `templates/hooks/lib/core.sh` | `husky_info` | function | named | 102 | *RepoVerified* |
| `templates/hooks/lib/core.sh` | `husky_init` | function | named | 385 | *RepoVerified* |
| `templates/hooks/lib/core.sh` | `husky_is_blocked` | function | named | 349 | *RepoVerified* |
| `templates/hooks/lib/core.sh` | `husky_is_excluded` | function | named | 336 | *RepoVerified* |
| `templates/hooks/lib/core.sh` | `husky_is_protected_branch` | function | named | 116 | *RepoVerified* |
| `templates/hooks/lib/core.sh` | `husky_load_config` | function | named | 39 | *RepoVerified* |
| `templates/hooks/lib/core.sh` | `husky_log` | function | named | 101 | *RepoVerified* |
| `templates/hooks/lib/core.sh` | `husky_ok` | function | named | 103 | *RepoVerified* |
| `templates/hooks/lib/core.sh` | `husky_repo_root` | function | named | 24 | *RepoVerified* |
| `templates/hooks/lib/core.sh` | `husky_run_advisory` | function | named | 321 | *RepoVerified* |
| `templates/hooks/lib/core.sh` | `husky_run_local_extensions` | function | named | 370 | *RepoVerified* |
| `templates/hooks/lib/core.sh` | `husky_run_step` | function | named | 254 | *RepoVerified* |
| `templates/hooks/lib/core.sh` | `husky_run_strict_step` | function | named | 288 | *RepoVerified* |
| `templates/hooks/lib/core.sh` | `husky_step` | function | named | 106 | *RepoVerified* |
| `templates/hooks/lib/core.sh` | `husky_strict_failed` | function | named | 312 | *RepoVerified* |
| `templates/hooks/lib/core.sh` | `husky_warn` | function | named | 104 | *RepoVerified* |
| `templates/hooks/lib/core.sh` | `husky_warn_mode_active` | function | named | 129 | *RepoVerified* |
| `templates/hooks/lib/core.sh` | `husky_warns_archive` | function | named | 155 | *RepoVerified* |
| `templates/hooks/lib/core.sh` | `husky_warns_clear_for_hook` | function | named | 209 | *RepoVerified* |
| `templates/hooks/lib/core.sh` | `husky_warns_dir` | function | named | 140 | *RepoVerified* |
| `templates/hooks/lib/core.sh` | `husky_warns_print_backlog` | function | named | 216 | *RepoVerified* |
| `templates/hooks/lib/core.sh` | `husky_warns_rotate` | function | named | 180 | *RepoVerified* |
| `templates/hooks/lib/core.sh` | `husky_warns_signature_pending` | function | named | 197 | *RepoVerified* |
| `tests/race_protection_test.sh` | `check` | function | named | 54 | *RepoVerified* |
| `tests/race_protection_test.sh` | `setup_repo` | function | named | 35 | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/__init__.py` | `Any` | reexport | named | 3 | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/__init__.py` | `Event` | reexport | named | 5 | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/__init__.py` | `PROFILE_SPECS` | __all__ | named |  | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/__init__.py` | `ProfileSpec` | __all__ | named |  | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/__init__.py` | `RunStatus` | reexport | named | 5 | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/__init__.py` | `WorkflowLaunchSpec` | reexport | named | 26 | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/__init__.py` | `annotations` | reexport | named | 1 | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/__init__.py` | `append_event` | reexport | named | 17 | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/__init__.py` | `await_run` | reexport | named | 5 | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/__init__.py` | `block_end` | __all__ | named |  | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/__init__.py` | `block_start` | __all__ | named |  | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/__init__.py` | `build_launch_command` | reexport | named | 26 | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/__init__.py` | `build_profiles_document` | __all__ | named |  | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/__init__.py` | `control_plane_home` | reexport | named | 5 | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/__init__.py` | `cursor_shape` | __all__ | named |  | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/__init__.py` | `custom_button` | __all__ | named |  | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/__init__.py` | `default_install_dir` | __all__ | named |  | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/__init__.py` | `doctor_run` | reexport | named | 18 | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/__init__.py` | `doctor_summary` | reexport | named | 18 | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/__init__.py` | `event_stream_path` | reexport | named | 5 | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/__init__.py` | `ftcs_command_executed` | __all__ | named |  | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/__init__.py` | `ftcs_command_finished` | __all__ | named |  | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/__init__.py` | `ftcs_command_start` | __all__ | named |  | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/__init__.py` | `ftcs_prompt` | __all__ | named |  | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/__init__.py` | `hex_to_iterm2` | __all__ | named |  | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/__init__.py` | `highlight_cursor_line` | __all__ | named |  | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/__init__.py` | `hyperlink` | __all__ | named |  | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/__init__.py` | `install_profiles` | __all__ | named |  | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/__init__.py` | `invalidate_buttons` | __all__ | named |  | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/__init__.py` | `iterm2_plugin` | __all__ | named |  | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/__init__.py` | `launch_workflow` | reexport | named | 26 | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/__init__.py` | `lookup_run` | reexport | named | 5 | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/__init__.py` | `normalize_launch_spec` | reexport | named | 26 | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/__init__.py` | `post_notification` | __all__ | named |  | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/__init__.py` | `progress` | __all__ | named |  | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/__init__.py` | `read_event_tail` | reexport | named | 5 | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/__init__.py` | `read_version_file` | reexport | named | 20 | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/__init__.py` | `remote_host` | __all__ | named |  | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/__init__.py` | `repo_full` | reexport | named | 19 | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/__init__.py` | `repo_full_summary` | reexport | named | 19 | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/__init__.py` | `request_attention` | __all__ | named |  | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/__init__.py` | `resolve_env_path` | reexport | named | 20 | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/__init__.py` | `run_snapshot_dir` | reexport | named | 5 | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/__init__.py` | `serialize` | __all__ | named |  | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/__init__.py` | `set_badge` | __all__ | named |  | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/__init__.py` | `set_colors` | __all__ | named |  | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/__init__.py` | `set_current_dir` | __all__ | named |  | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/__init__.py` | `set_mark` | __all__ | named |  | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/__init__.py` | `set_profile` | __all__ | named |  | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/__init__.py` | `set_user_var` | __all__ | named |  | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/__init__.py` | `stable_guid` | __all__ | named |  | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/__init__.py` | `steal_focus` | __all__ | named |  | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/__init__.py` | `subscribe_events` | reexport | named | 5 | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/__init__.py` | `sync_state` | reexport | named | 5 | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/__init__.py` | `uninstall_profiles` | __all__ | named |  | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/__init__.py` | `update_block` | __all__ | named |  | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/__init__.py` | `vibecrafted_home` | reexport | named | 20 | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/__init__.py` | `vibecrafted_launcher` | reexport | named | 26 | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/__init__.py` | `xdg_config_home` | reexport | named | 20 | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/agent_dispatch.py` | `ParityError` | class | named | 43 | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/agent_dispatch.py` | `check_parity` | def | named | 206 | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/agent_dispatch.py` | `detect_parent_model` | def | named | 83 | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/agent_dispatch.py` | `extract_session_id` | def | named | 97 | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/agent_dispatch.py` | `normalize_model` | def | named | 118 | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/agent_dispatch.py` | `require_parity` | def | named | 254 | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/agent_dispatch.py` | `sandbox_supported` | def | named | 113 | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/agent_dispatch.py` | `tier_family` | def | named | 201 | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/agent_dispatch.py` | `tier_rank` | def | named | 196 | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/events.py` | `append_event` | def | named | 6 | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/runtime_paths.py` | `read_version_file` | def | named | 7 | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/runtime_paths.py` | `resolve_env_path` | def | named | 14 | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/runtime_paths.py` | `vibecrafted_home` | def | named | 25 | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/runtime_paths.py` | `xdg_config_home` | def | named | 21 | *RepoVerified* |

### Imports

| File | Source | Kind | Resolution | Authority |
|---|---|---|---|---|
| `templates/hooks/install.sh` | `$SOURCE_LIB/detect.sh` | static | unknown | *RepoVerified* |
| `templates/hooks/lib/core.sh` | `$config` | static | unknown | *RepoVerified* |
| `tests/race_protection_test.sh` | `$WORKDIR/neg_a.exit` | static | unknown | *RepoVerified* |
| `tests/race_protection_test.sh` | `$WORKDIR/neg_b.exit` | static | unknown | *RepoVerified* |
| `tests/race_protection_test.sh` | `$WORKDIR/pos.exit` | static | unknown | *RepoVerified* |
| `tests/race_protection_test.sh` | `$WORKDIR/pos_c.exit` | static | unknown | *RepoVerified* |
| `tests/race_protection_test.sh` | `$WORKDIR/pos_d.exit` | static | unknown | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/__init__.py` | `.control_plane` | static | local | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/__init__.py` | `.doctor` | static | local | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/__init__.py` | `.events` | static | local | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/__init__.py` | `.git` | static | local | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/__init__.py` | `.runtime_paths` | static | local | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/__init__.py` | `.workflow` | static | local | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/__init__.py` | `__future__` | static | unknown | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/__init__.py` | `typing` | static | stdlib | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/agent_dispatch.py` | `__future__` | static | unknown | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/agent_dispatch.py` | `typing` | static | stdlib | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/agent_dispatch.py` | `os` | static | stdlib | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/agent_dispatch.py` | `re` | static | stdlib | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/agent_dispatch.py` | `sys` | static | stdlib | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/events.py` | `__future__` | static | unknown | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/events.py` | `typing` | static | stdlib | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/runtime_paths.py` | `__future__` | static | unknown | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/runtime_paths.py` | `pathlib` | static | stdlib | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/runtime_paths.py` | `os` | static | stdlib | *RepoVerified* |

### Consumers

| File | Import Kind | Imports Used | Authority |
|---|---|---|---|
| `tests/agent_dispatch_test.py` | `Direct` | annotations, agent_dispatch | *RepoVerified* |
| `vibecrafted-core/tests/test_agy_junie_pipeline.py` | `Direct` | annotations, workflow | *RepoVerified* |
| `vibecrafted-core/tests/test_aicx_sync.py` | `Direct` | annotations, Any, aicx_sync | *RepoVerified* |
| `vibecrafted-core/tests/test_control_plane.py` | `Direct` | annotations, control_plane | *RepoVerified* |
| `vibecrafted-core/tests/test_doctor.py` | `Direct` | annotations, doctor | *RepoVerified* |
| `vibecrafted-core/tests/test_git.py` | `Direct` | annotations, git | *RepoVerified* |
| `vibecrafted-core/tests/test_iterm2_osc.py` | `Direct` | annotations, iterm2_osc | *RepoVerified* |
| `vibecrafted-core/tests/test_iterm2_plugin.py` | `Direct` | annotations, Any | *RepoVerified* |
| `vibecrafted-core/tests/test_iterm2_profiles.py` | `Direct` | annotations, iterm2_profiles | *RepoVerified* |
| `vibecrafted-core/tests/test_memex_client.py` | `Direct` | annotations, Any, memex_client | *RepoVerified* |
| `vibecrafted-core/tests/test_sandbox_adapter.py` | `Direct` | annotations, control_plane | *RepoVerified* |
| `vibecrafted-core/tests/test_supervisor.py` | `Direct` | annotations, control_plane, append_event | *RepoVerified* |
| `vibecrafted-core/tests/test_workflow.py` | `Direct` | annotations, Any, workflow | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/__init__.py` | `Reexport` | append_event | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/control_plane.py` | `Direct` | vibecrafted_home | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/doctor.py` | `Direct` | vibecrafted_home | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/sandbox/adapter.py` | `Direct` | append_event | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/sandbox/msbserver_lifecycle.py` | `Direct` | vibecrafted_home | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/sandbox/policy.py` | `Direct` | vibecrafted_home | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/spawn.py` | `Direct` | append_event | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/wrappers.py` | `Direct` | append_event | *RepoVerified* |
| `vibecrafted-mcp/vibecrafted_mcp/server.py` | `Direct` | annotations, Any, control_plane, doctor, git, workflow | *RepoVerified* |

### Entrypoints

| Path | Kinds | Authority |
|---|---|---|
| `vibecrafted-core/vibecrafted_core/control_plane.py` | script | *RepoVerified* |
| `vibecrafted-mcp/vibecrafted_mcp/server.py` | script | *RepoVerified* |

## Runtime Slice

### Dispatch Edges

- `templates/hooks/install.sh`:308 -> `activator_husky` (`unknown`) *LoctreeDerived*
- `templates/hooks/install.sh`:307 -> `activator_lefthook` (`unknown`) *LoctreeDerived*
- `templates/hooks/install.sh`:310 -> `activator_manual` (`unknown`) *LoctreeDerived*
- `templates/hooks/install.sh`:309 -> `activator_precommit` (`unknown`) *LoctreeDerived*

### Reachability

- `agents/scripts/lib/zellij.sh::VIBECRAFTED_OPERATOR_SESSION`: Reached (source_include:agents/scripts/common.sh) *LoctreeDerived*
- `agents/scripts/lib/zellij.sh::spawn_acquire_zellij_launch_slot`: Reached (source_include:agents/scripts/common.sh) *LoctreeDerived*
- `agents/scripts/lib/zellij.sh::spawn_await_watch_pane`: Reached (source_include:agents/scripts/common.sh) *LoctreeDerived*
- `agents/scripts/lib/zellij.sh::spawn_current_focused_pane_id`: Reached (source_include:agents/scripts/common.sh) *LoctreeDerived*
- `agents/scripts/lib/zellij.sh::spawn_current_tab_id`: Reached (source_include:agents/scripts/common.sh) *LoctreeDerived*
- `agents/scripts/lib/zellij.sh::spawn_current_tab_name`: Reached (source_include:agents/scripts/common.sh) *LoctreeDerived*
- `agents/scripts/lib/zellij.sh::spawn_current_zellij_session_name`: Reached (source_include:agents/scripts/common.sh) *LoctreeDerived*
- `agents/scripts/lib/zellij.sh::spawn_effective_operator_session`: Reached (source_include:agents/scripts/common.sh) *LoctreeDerived*
- `agents/scripts/lib/zellij.sh::spawn_in_marbles_tab`: Reached (source_include:agents/scripts/common.sh) *LoctreeDerived*
- `agents/scripts/lib/zellij.sh::spawn_in_operator_session`: Reached (source_include:agents/scripts/common.sh) *LoctreeDerived*
- `agents/scripts/lib/zellij.sh::spawn_in_target_zellij_session`: Reached (source_include:agents/scripts/common.sh) *LoctreeDerived*
- `agents/scripts/lib/zellij.sh::spawn_in_zellij_context`: Reached (source_include:agents/scripts/common.sh) *LoctreeDerived*
- `agents/scripts/lib/zellij.sh::spawn_in_zellij_pane`: Reached (source_include:agents/scripts/common.sh) *LoctreeDerived*
- `agents/scripts/lib/zellij.sh::spawn_pane_direction`: Reached (source_include:agents/scripts/common.sh) *LoctreeDerived*
- `agents/scripts/lib/zellij.sh::spawn_probe`: Reached (source_include:agents/scripts/common.sh) *LoctreeDerived*
- `agents/scripts/lib/zellij.sh::spawn_probe_notify`: Reached (source_include:agents/scripts/common.sh) *LoctreeDerived*
- `agents/scripts/lib/zellij.sh::spawn_probe_watch`: Reached (source_include:agents/scripts/common.sh) *LoctreeDerived*
- `agents/scripts/lib/zellij.sh::spawn_release_zellij_launch_slot`: Reached (source_include:agents/scripts/common.sh) *LoctreeDerived*
- `agents/scripts/lib/zellij.sh::spawn_tab_id_by_name`: Reached (source_include:agents/scripts/common.sh) *LoctreeDerived*
- `agents/scripts/lib/zellij.sh::spawn_zellij_launch_lock_key`: Reached (source_include:agents/scripts/common.sh) *LoctreeDerived*
- `templates/hooks/install.sh::activator_husky`: Reached (dispatch_handler:case_statement:templates/hooks/install.sh) *LoctreeDerived*
- `templates/hooks/install.sh::activator_lefthook`: Reached (dispatch_handler:case_statement:templates/hooks/install.sh) *LoctreeDerived*
- `templates/hooks/install.sh::activator_manual`: Reached (dispatch_handler:case_statement:templates/hooks/install.sh) *LoctreeDerived*
- `templates/hooks/install.sh::activator_precommit`: Reached (dispatch_handler:case_statement:templates/hooks/install.sh) *LoctreeDerived*
- `templates/hooks/lib/core.sh::husky_apply_defaults`: Reached (source_include:templates/hooks/hooks/prepare-commit-msg) *LoctreeDerived*
- `templates/hooks/lib/core.sh::husky_current_branch`: Reached (source_include:templates/hooks/hooks/prepare-commit-msg) *LoctreeDerived*
- `templates/hooks/lib/core.sh::husky_err`: Reached (source_include:templates/hooks/hooks/prepare-commit-msg) *LoctreeDerived*
- `templates/hooks/lib/core.sh::husky_hash_file`: Reached (source_include:templates/hooks/hooks/prepare-commit-msg) *LoctreeDerived*
- `templates/hooks/lib/core.sh::husky_info`: Reached (source_include:templates/hooks/hooks/prepare-commit-msg) *LoctreeDerived*
- `templates/hooks/lib/core.sh::husky_init`: Reached (source_include:templates/hooks/hooks/prepare-commit-msg) *LoctreeDerived*
- `templates/hooks/lib/core.sh::husky_is_blocked`: Reached (source_include:templates/hooks/hooks/prepare-commit-msg) *LoctreeDerived*
- `templates/hooks/lib/core.sh::husky_is_excluded`: Reached (source_include:templates/hooks/hooks/prepare-commit-msg) *LoctreeDerived*
- `templates/hooks/lib/core.sh::husky_is_protected_branch`: Reached (source_include:templates/hooks/hooks/prepare-commit-msg) *LoctreeDerived*
- `templates/hooks/lib/core.sh::husky_load_config`: Reached (source_include:templates/hooks/hooks/prepare-commit-msg) *LoctreeDerived*
- `templates/hooks/lib/core.sh::husky_log`: Reached (source_include:templates/hooks/hooks/prepare-commit-msg) *LoctreeDerived*
- `templates/hooks/lib/core.sh::husky_ok`: Reached (source_include:templates/hooks/hooks/prepare-commit-msg) *LoctreeDerived*
- `templates/hooks/lib/core.sh::husky_repo_root`: Reached (source_include:templates/hooks/hooks/prepare-commit-msg) *LoctreeDerived*
- `templates/hooks/lib/core.sh::husky_run_advisory`: Reached (source_include:templates/hooks/hooks/prepare-commit-msg) *LoctreeDerived*
- `templates/hooks/lib/core.sh::husky_run_local_extensions`: Reached (source_include:templates/hooks/hooks/prepare-commit-msg) *LoctreeDerived*
- `templates/hooks/lib/core.sh::husky_run_step`: Reached (source_include:templates/hooks/hooks/prepare-commit-msg) *LoctreeDerived*
- `templates/hooks/lib/core.sh::husky_run_strict_step`: Reached (source_include:templates/hooks/hooks/prepare-commit-msg) *LoctreeDerived*
- `templates/hooks/lib/core.sh::husky_step`: Reached (source_include:templates/hooks/hooks/prepare-commit-msg) *LoctreeDerived*
- `templates/hooks/lib/core.sh::husky_strict_failed`: Reached (source_include:templates/hooks/hooks/prepare-commit-msg) *LoctreeDerived*
- `templates/hooks/lib/core.sh::husky_warn`: Reached (source_include:templates/hooks/hooks/prepare-commit-msg) *LoctreeDerived*
- `templates/hooks/lib/core.sh::husky_warn_mode_active`: Reached (source_include:templates/hooks/hooks/prepare-commit-msg) *LoctreeDerived*
- `templates/hooks/lib/core.sh::husky_warns_archive`: Reached (source_include:templates/hooks/hooks/prepare-commit-msg) *LoctreeDerived*
- `templates/hooks/lib/core.sh::husky_warns_clear_for_hook`: Reached (source_include:templates/hooks/hooks/prepare-commit-msg) *LoctreeDerived*
- `templates/hooks/lib/core.sh::husky_warns_dir`: Reached (source_include:templates/hooks/hooks/prepare-commit-msg) *LoctreeDerived*
- `templates/hooks/lib/core.sh::husky_warns_print_backlog`: Reached (source_include:templates/hooks/hooks/prepare-commit-msg) *LoctreeDerived*
- `templates/hooks/lib/core.sh::husky_warns_rotate`: Reached (source_include:templates/hooks/hooks/prepare-commit-msg) *LoctreeDerived*
- `templates/hooks/lib/core.sh::husky_warns_signature_pending`: Reached (source_include:templates/hooks/hooks/prepare-commit-msg) *LoctreeDerived*

### Env Contracts

- `ACTIVATOR` used in 1 files *LoctreeDerived*
- `AUTO` used in 1 files *LoctreeDerived*
- `BASH_SOURCE` used in 47 files *LoctreeDerived*
- `DRY_RUN` used in 1 files *LoctreeDerived*
- `FAIL` used in 5 files *LoctreeDerived*
- `FORCE` used in 1 files *LoctreeDerived*
- `GITIGNORE` used in 1 files *LoctreeDerived*
- `HELPER` used in 1 files *LoctreeDerived*
- `HERE` used in 7 files *LoctreeDerived*
- `HOOKS` used in 1 files *LoctreeDerived*
- `HOOK_FILE` used in 1 files *LoctreeDerived*
- `HOOK_FILE_B` used in 1 files *LoctreeDerived*
- `HOOK_FILE_C` used in 1 files *LoctreeDerived*
- `HUSKY_BLOCKED_PATHS` used in 1 files *LoctreeDerived*
- `HUSKY_COMMIT_MSG_ALLOW_AGENT_PREFIX` used in 2 files *LoctreeDerived*
- `HUSKY_COMMIT_MSG_CONVENTIONAL` used in 2 files *LoctreeDerived*
- `HUSKY_COMMIT_MSG_SUBJECT_MAX` used in 2 files *LoctreeDerived*
- `HUSKY_DIR` used in 1 files *LoctreeDerived*
- `HUSKY_EXCLUDE_PATHS` used in 1 files *LoctreeDerived*
- `HUSKY_POSTCOMMIT_CLAUDE_ARTIFACT_WARN` used in 2 files *LoctreeDerived*
- `HUSKY_PRECOMMIT_ENV_FILES` used in 2 files *LoctreeDerived*
- `HUSKY_PRECOMMIT_ESLINT_STAGED` used in 2 files *LoctreeDerived*
- `HUSKY_PRECOMMIT_LINT_STAGED` used in 2 files *LoctreeDerived*
- `HUSKY_PRECOMMIT_LOCT_HEALTH` used in 2 files *LoctreeDerived*
- `HUSKY_PRECOMMIT_LOCT_SUPPRESSIONS` used in 2 files *LoctreeDerived*
- `HUSKY_PRECOMMIT_LOCT_SUPPRESSIONS_BUDGET` used in 2 files *LoctreeDerived*
- `HUSKY_PRECOMMIT_PRETTIER_STAGED` used in 2 files *LoctreeDerived*
- `HUSKY_PRECOMMIT_PY_BLACK` used in 1 files *LoctreeDerived*
- `HUSKY_PRECOMMIT_PY_RUFF` used in 2 files *LoctreeDerived*
- `HUSKY_PRECOMMIT_RUSTFMT_STAGED` used in 2 files *LoctreeDerived*
- `HUSKY_PRECOMMIT_RUST_CARGO_CHECK` used in 2 files *LoctreeDerived*
- `HUSKY_PRECOMMIT_SECRETS` used in 2 files *LoctreeDerived*
- `HUSKY_PRECOMMIT_SEMGREP_STAGED` used in 2 files *LoctreeDerived*
- `HUSKY_PRECOMMIT_SH_SHELLCHECK` used in 2 files *LoctreeDerived*
- `HUSKY_PRECOMMIT_STYLELINT_STAGED` used in 2 files *LoctreeDerived*
- `HUSKY_PRECOMMIT_TSC` used in 2 files *LoctreeDerived*
- `HUSKY_PREMERGE_CLEAN_CODEX_AGENT` used in 2 files *LoctreeDerived*
- `HUSKY_PREMERGE_CLEAN_PATHS` used in 2 files *LoctreeDerived*
- `HUSKY_PREPUSH_CARGO_CLIPPY` used in 2 files *LoctreeDerived*
- `HUSKY_PREPUSH_CARGO_TEST` used in 2 files *LoctreeDerived*
- `HUSKY_PREPUSH_LOCT_COMMANDS` used in 2 files *LoctreeDerived*
- `HUSKY_PREPUSH_LOCT_CYCLES` used in 2 files *LoctreeDerived*
- `HUSKY_PREPUSH_PRETTIER_FULL` used in 2 files *LoctreeDerived*
- `HUSKY_PREPUSH_SECRETS` used in 2 files *LoctreeDerived*
- `HUSKY_PREPUSH_SEMGREP_FULL` used in 2 files *LoctreeDerived*
- `HUSKY_PREPUSH_TSC` used in 2 files *LoctreeDerived*
- `HUSKY_PREPUSH_VITEST` used in 2 files *LoctreeDerived*
- `HUSKY_REPO_ROOT` used in 2 files *LoctreeDerived*
- `HUSKY_RUST_CARGO_DIR` used in 2 files *LoctreeDerived*
- `HUSKY_STRICT` used in 1 files *LoctreeDerived*
- `HUSKY_STRICT_FAILED_FILE` used in 2 files *LoctreeDerived*
- `HUSKY_WARNS_DIR` used in 1 files *LoctreeDerived*
- `HUSKY_WARN_FORCE` used in 1 files *LoctreeDerived*
- `HUSKY_WARN_MODE_ON_FEATURE` used in 1 files *LoctreeDerived*
- `HUSKY_WARN_PROTECTED_BRANCHES` used in 1 files *LoctreeDerived*
- `HUSKY_WARN_RETENTION` used in 1 files *LoctreeDerived*
- `ITERM_SESSION_ID` used in 1 files *LoctreeDerived*
- `MSG_FILE` used in 3 files *LoctreeDerived*
- `NEG_A_HEAD_MSG` used in 1 files *LoctreeDerived*
- `NEG_REPO` used in 1 files *LoctreeDerived*
- `NEG_REPO_B` used in 1 files *LoctreeDerived*
- `NO_ACTIVATE` used in 1 files *LoctreeDerived*
- `NO_GITIGNORE` used in 1 files *LoctreeDerived*
- `PASS` used in 5 files *LoctreeDerived*
- `POS_C_CONTENT` used in 1 files *LoctreeDerived*
- `POS_C_DIFF_FILES` used in 1 files *LoctreeDerived*
- `POS_C_HEAD_SUBJECT` used in 1 files *LoctreeDerived*
- `POS_C_REPO` used in 1 files *LoctreeDerived*
- `POS_DIFF_FILES` used in 1 files *LoctreeDerived*
- `POS_D_BODY` used in 1 files *LoctreeDerived*
- `POS_D_REPO` used in 1 files *LoctreeDerived*
- `POS_D_SUBJECT` used in 1 files *LoctreeDerived*
- `POS_HEAD_PARENT_SUBJECT` used in 1 files *LoctreeDerived*
- `POS_HEAD_SUBJECT` used in 1 files *LoctreeDerived*
- `POS_REPO` used in 1 files *LoctreeDerived*
- `README_NOTICE` used in 1 files *LoctreeDerived*
- `REPO_ROOT` used in 12 files *LoctreeDerived*
- `SCRIPT_DIR` used in 23 files *LoctreeDerived*
- `SOURCE_ACTIVATORS` used in 1 files *LoctreeDerived*
- `SOURCE_CONFIG` used in 1 files *LoctreeDerived*
- `SOURCE_HOOKS` used in 1 files *LoctreeDerived*
- `SOURCE_LIB` used in 1 files *LoctreeDerived*
- `SOURCE_SCRIPTS` used in 1 files *LoctreeDerived*
- `SPAWN_AGENT` used in 11 files *LoctreeDerived*
- `SPAWN_LOOP_NR` used in 4 files *LoctreeDerived*
- `SPAWN_ROOT` used in 13 files *LoctreeDerived*
- `SPAWN_RUN_ID` used in 14 files *LoctreeDerived*
- `TARGET_CONFIG` used in 1 files *LoctreeDerived*
- `TARGET_HUSKY` used in 1 files *LoctreeDerived*
- `TARGET_LIB` used in 1 files *LoctreeDerived*
- `TARGET_LOCAL_DIR` used in 1 files *LoctreeDerived*
- `TARGET_SCRIPTS` used in 1 files *LoctreeDerived*
- `TARGET_WARNS_DIR` used in 1 files *LoctreeDerived*
- `TERM_PROGRAM` used in 3 files *LoctreeDerived*
- `TMPDIR` used in 4 files *LoctreeDerived*
- `VIBECRAFTED_HOME` used in 18 files *LoctreeDerived*
- `VIBECRAFTED_MARBLES_TAB_NAME` used in 3 files *LoctreeDerived*
- `VIBECRAFTED_OPERATOR_SESSION` used in 5 files *LoctreeDerived*
- `VIBECRAFTED_PANE_SEQ` used in 1 files *LoctreeDerived*
- `VIBECRAFTED_RUN_ID` used in 6 files *LoctreeDerived*
- `VIBECRAFTED_SPAWN_META` used in 1 files *LoctreeDerived*
- `VIBECRAFTED_SPAWN_PROBE` used in 1 files *LoctreeDerived*
- `VIBECRAFTED_SPAWN_PROBE_DELAY_SECONDS` used in 1 files *LoctreeDerived*
- `VIBECRAFTED_SPAWN_PROBE_NOTIFY` used in 1 files *LoctreeDerived*
- `VIBECRAFTED_SPAWN_PROBE_SECONDS` used in 1 files *LoctreeDerived*
- `VIBECRAFTED_SPAWN_STAGGER` used in 1 files *LoctreeDerived*
- `VIBECRAFTED_SPAWN_STAGGER_MAX_WAIT_SECONDS` used in 1 files *LoctreeDerived*
- `VIBECRAFTED_SPAWN_STAGGER_SECONDS` used in 1 files *LoctreeDerived*
- `VIBECRAFTED_ZELLIJ_CLOSE_AGENT_PANES` used in 1 files *LoctreeDerived*
- `VIBECRAFTED_ZELLIJ_KEEP_AGENT_PANES` used in 1 files *LoctreeDerived*
- `VIBECRAFTED_ZELLIJ_SPAWN_DIRECTION` used in 2 files *LoctreeDerived*
- `WORKDIR` used in 1 files *LoctreeDerived*
- `ZELLIJ` used in 2 files *LoctreeDerived*
- `ZELLIJ_PANE_ID` used in 2 files *LoctreeDerived*
- `ZELLIJ_SESSION_NAME` used in 2 files *LoctreeDerived*
- `ZELLIJ_TAB_NAME` used in 1 files *LoctreeDerived*
- `_SPAWN_LIB_DIR` used in 2 files *LoctreeDerived*

## Risk Slice

- Cache Scope: `DirtyWorktree` *RepoVerified*
- Snapshot Health: `dirty`
- Stale Snapshot: false
- Dirty Worktree: true

### Hotspots

| File | Importers | Authority |
|---|---|---|
| `vibecrafted-core/vibecrafted_core/__init__.py` | 14 | *LoctreeDerived* |
| `scripts` | 10 | *LoctreeDerived* |
| `vibecrafted-core/vibecrafted_core/events.py` | 5 | *LoctreeDerived* |
| `vibecrafted-core/vibecrafted_core/runtime_paths.py` | 5 | *LoctreeDerived* |
| `vibecrafted-core/vibecrafted_core/agent_dispatch.py` | 3 | *LoctreeDerived* |

### High Fan-In

| File | Importers | Authority |
|---|---|---|
| `vibecrafted-core/vibecrafted_core/__init__.py` | 14 | *LoctreeDerived* |
| `scripts` | 10 | *LoctreeDerived* |

## Action Slice

### Next Safe Commands

```bash
loct slice vibecrafted-core/vibecrafted_core/__init__.py
loct impact vibecrafted-core/vibecrafted_core/__init__.py
loct context --file vibecrafted-core/vibecrafted_core/__init__.py
loct slice scripts
loct impact scripts
loct context --file scripts
loct slice vibecrafted-core/vibecrafted_core/events.py
loct impact vibecrafted-core/vibecrafted_core/events.py
loct context --file vibecrafted-core/vibecrafted_core/events.py
loct slice vibecrafted-core/vibecrafted_core/runtime_paths.py
loct impact vibecrafted-core/vibecrafted_core/runtime_paths.py
loct context --file vibecrafted-core/vibecrafted_core/runtime_paths.py
loct slice vibecrafted-core/vibecrafted_core/agent_dispatch.py
loct impact vibecrafted-core/vibecrafted_core/agent_dispatch.py
loct context --file vibecrafted-core/vibecrafted_core/agent_dispatch.py
loct slice templates/hooks/lib/core.sh
loct impact templates/hooks/lib/core.sh
loct context --file templates/hooks/lib/core.sh
loct slice agents/scripts/lib/zellij.sh
loct impact agents/scripts/lib/zellij.sh
loct context --file agents/scripts/lib/zellij.sh
loct slice templates/hooks/install.sh
loct impact templates/hooks/install.sh
loct context --file templates/hooks/install.sh
loct slice tests/race_protection_test.sh
loct impact tests/race_protection_test.sh
loct context --file tests/race_protection_test.sh
```

### Verification Gates

```bash
make test
make check
mypy .
python -m pytest
```

### Likely Tests

- `tests/agent_dispatch_test.py`
- `tests/race_protection_test.sh`
- `vibecrafted-core/tests/test_agy_junie_pipeline.py`
- `vibecrafted-core/tests/test_aicx_sync.py`
- `vibecrafted-core/tests/test_control_plane.py`
- `vibecrafted-core/tests/test_doctor.py`
- `vibecrafted-core/tests/test_git.py`
- `vibecrafted-core/tests/test_iterm2_osc.py`
- `vibecrafted-core/tests/test_iterm2_plugin.py`
- `vibecrafted-core/tests/test_iterm2_profiles.py`
- `vibecrafted-core/tests/test_memex_client.py`
- `vibecrafted-core/tests/test_sandbox_adapter.py`
- `vibecrafted-core/tests/test_supervisor.py`
- `vibecrafted-core/tests/test_workflow.py`

## Memory Slice

| Kind | Agent | Date | Relevance | Text | Authority | Source Chunk |
|---|---|---|---|---|---|---|
| `outcome` | `claude` | 2026-05-17 | 9 | **Cut N landed mid-Cut-O** — task-notification for Cut N likely arriving soon (or already arrived during Cut O's run). git log will confirm. The sync auto-pickup of `docs/ITERM2.md` is empirical proof Cut N completed enough to commit the new doc file. Two Wave 4/5 plans closed via concurrent dispatch. | *AicxAgent* | `chunk:73867c79` |
| `outcome` | `claude` | 2026-05-17 | 7 | Skill mówi wyraźnie: "find and read it in full — `master-dispatch.md`, per-prompt bodies, `docs/backlog/<YYYY-MM-DD>-<slug>.md`". Init pokazał, że **META_22 session miała 22 plany, 14 done, 3 active, 7 unstarted** — ale to było 2026-05-12, pięć dni temu. Co zmieniło się od tamtego do teraz, czy 7 unstartowanych zostało zamknietych, czy są nowe plany — to muszę zlokalizować. | *AicxAgent* | `chunk:ebf60f75` |
| `outcome` | `claude` | 2026-05-17 | 7 | "markdown": "# Loctree Context · vibecrafted @ release/v1.7.1 · 2026-05-17T10:41:40.346696Z\n\n_0 files · 0 import edges · snapshot fresh · clean worktree_\n\n## TL;DR — read this first\n\n**What this is.** `vibecrafted` repository (0 files, 0 import edges).\n\n**Where you stand.** Branch `release/v1.7.1`, clean worktree, snapshot fresh.\nActive intent (AICX): \"Done: [vibecrafted-loct-context.md](/tmp/vibecrafted-loct-context.md)\" — codex on 2026-05-12. | *AicxAgent* | `chunk:94b9897c` |
| `outcome` | `claude` | 2026-05-16 | 7 | content: {"oracle_status":{"source_layer":"layer_1_canonical_corpus","backend":"filesystem_fuzzy","index_kind":"none","fallback_reason":"fallback_filesystem_fuzzy: content index unavailable","derived_view":"none_filesystem_scan","store_root":"/Users/maciejgad/.aicx","indexed_count":0,"scanned_count":8738,"candidate_count":10,"source_paths_verified":true,"stale_or_unknown":true,"loctree_scope_safe":false,"loctree_scope_note":"unsafe_for_scope_narrowing … | *AicxAgent* | `chunk:573f0db4` |
| `outcome` | `claude` | 2026-05-24 | 6 | 25: args "-lc" "for root in \"${VIBECRAFTED_HOME:-$HOME/.vibecrafted}/tools/vibecrafted-current/config/zellij\" \"${VIBECRAFTED_ROOT:+$VIBECRAFTED_ROOT/config/zellij}\" \"./config/zellij\"; do if [[ -n \"$root\" && -x \"$root/aicx-status.sh\" ]]; then exec \"$root/aicx-status.sh\"; fi; done; printf 'aicx: status helper not found\\n'; sleep 86400" | *AicxAgent* | `chunk:59b8032f` |
| `outcome` | `claude` | 2026-05-24 | 6 | 26: args "-lc" "for root in \"${VIBECRAFTED_HOME:-$HOME/.vibecrafted}/tools/vibecrafted-current/config/zellij\" \"${VIBECRAFTED_ROOT:+$VIBECRAFTED_ROOT/config/zellij}\" \"./config/zellij\"; do if [[ -n \"$root\" && -x \"$root/aicx-status.sh\" ]]; then exec \"$root/aicx-status.sh\"; fi; done; printf 'aicx: status helper not found\\n'; sleep 86400" | *AicxAgent* | `chunk:59b8032f` |
| `outcome` | `claude` | 2026-05-24 | 6 | 27: args "-lc" "for root in \"${VIBECRAFTED_HOME:-$HOME/.vibecrafted}/tools/vibecrafted-current/config/zellij\" \"${VIBECRAFTED_ROOT:+$VIBECRAFTED_ROOT/config/zellij}\" \"./config/zellij\"; do if [[ -n \"$root\" && -x \"$root/aicx-status.sh\" ]]; then exec \"$root/aicx-status.sh\"; fi; done; printf 'aicx: status helper not found\\n'; sleep 86400" | *AicxAgent* | `chunk:59b8032f` |
| `outcome` | `claude` | 2026-05-23 | 6 | 25: args "-lc" "for root in \"${VIBECRAFTED_HOME:-$HOME/.vibecrafted}/tools/vibecrafted-current/config/zellij\" \"${VIBECRAFTED_ROOT:+$VIBECRAFTED_ROOT/config/zellij}\" \"./config/zellij\"; do if [[ -n \"$root\" && -x \"$root/aicx-status.sh\" ]]; then exec \"$root/aicx-status.sh\"; fi; done; printf 'aicx: status helper not found\\n'; sleep 86400" | *AicxAgent* | `chunk:e4427bc7` |
| `outcome` | `claude` | 2026-05-23 | 6 | 26: args "-lc" "for root in \"${VIBECRAFTED_HOME:-$HOME/.vibecrafted}/tools/vibecrafted-current/config/zellij\" \"${VIBECRAFTED_ROOT:+$VIBECRAFTED_ROOT/config/zellij}\" \"./config/zellij\"; do if [[ -n \"$root\" && -x \"$root/aicx-status.sh\" ]]; then exec \"$root/aicx-status.sh\"; fi; done; printf 'aicx: status helper not found\\n'; sleep 86400" | *AicxAgent* | `chunk:e4427bc7` |
| `outcome` | `claude` | 2026-05-23 | 6 | 27: args "-lc" "for root in \"${VIBECRAFTED_HOME:-$HOME/.vibecrafted}/tools/vibecrafted-current/config/zellij\" \"${VIBECRAFTED_ROOT:+$VIBECRAFTED_ROOT/config/zellij}\" \"./config/zellij\"; do if [[ -n \"$root\" && -x \"$root/aicx-status.sh\" ]]; then exec \"$root/aicx-status.sh\"; fi; done; printf 'aicx: status helper not found\\n'; sleep 86400" | *AicxAgent* | `chunk:e4427bc7` |
| `outcome` | `claude` | 2026-05-23 | 6 | **Dlaczego to się stało** — to było **marble wave** (`reports/marbles/`). Marble worker (vc-marbles skill) z definicji robi *deliberate over-correction* — wpieniąć kulki w każdom dziurę. Tu plan był "agent-native runtime stack — widget visibility layer". Marble worker dowiózł całe 13 plików z **36 testami**. Tylko że te 36 assertions testują że **widget się spawnuje** + **output ma format** + **host mapping działa** + **layout się parsuje** — czyli … | *AicxAgent* | `chunk:eb2e32f0` |
| `outcome` | `claude` | 2026-05-17 | 6 | **Cut N landed mid-Cut-O** — task-notification for Cut N likely arriving soon (or already arrived during Cut O's run). git log will confirm. The sync auto-pickup of `docs/ITERM2.md` is empirical proof Cut N completed enough to commit the new doc file. Two Wave 4/5 plans closed via concurrent dispatch. | *AicxAgent* | `chunk:73867c79` |
| `outcome` | `claude` | 2026-05-17 | 6 | WHY: <status>completed</status> \| <result>All green post-commit: 16 bash + 36 pytest (Plan 08), 140 total pytest cases across `vibecrafted-core/tests/` (zero regressions). | *AicxAgent* | `chunk:73867c79` |
| `outcome` | `claude` | 2026-05-24 | 5 | 25: args "-lc" "for root in \"${VIBECRAFTED_HOME:-$HOME/.vibecrafted}/tools/vibecrafted-current/config/zellij\" \"${VIBECRAFTED_ROOT:+$VIBECRAFTED_ROOT/config/zellij}\" \"./config/zellij\"; do if [[ -n \"$root\" && -x \"$root/aicx-status.sh\" ]]; then exec \"$root/aicx-status.sh\"; fi; done; printf 'aicx: status helper not found\\n'; sleep 86400" | *AicxAgent* | `chunk:59b8032f` |
| `outcome` | `claude` | 2026-05-24 | 5 | 26: args "-lc" "for root in \"${VIBECRAFTED_HOME:-$HOME/.vibecrafted}/tools/vibecrafted-current/config/zellij\" \"${VIBECRAFTED_ROOT:+$VIBECRAFTED_ROOT/config/zellij}\" \"./config/zellij\"; do if [[ -n \"$root\" && -x \"$root/aicx-status.sh\" ]]; then exec \"$root/aicx-status.sh\"; fi; done; printf 'aicx: status helper not found\\n'; sleep 86400" | *AicxAgent* | `chunk:59b8032f` |
| `outcome` | `claude` | 2026-05-24 | 5 | 27: args "-lc" "for root in \"${VIBECRAFTED_HOME:-$HOME/.vibecrafted}/tools/vibecrafted-current/config/zellij\" \"${VIBECRAFTED_ROOT:+$VIBECRAFTED_ROOT/config/zellij}\" \"./config/zellij\"; do if [[ -n \"$root\" && -x \"$root/aicx-status.sh\" ]]; then exec \"$root/aicx-status.sh\"; fi; done; printf 'aicx: status helper not found\\n'; sleep 86400" | *AicxAgent* | `chunk:59b8032f` |
| `outcome` | `claude` | 2026-05-24 | 5 | 28: args "-lc" "for root in \"${VIBECRAFTED_HOME:-$HOME/.vibecrafted}/tools/vibecrafted-current/config/zellij\" \"${VIBECRAFTED_ROOT:+$VIBECRAFTED_ROOT/config/zellij}\" \"./config/zellij\"; do if [[ -n \"$root\" && -x \"$root/loctree-drift.sh\" ]]; then exec \"$root/loctree-drift.sh\"; fi; done; printf 'loctree: drift helper not found\\n'; sleep 86400" | *AicxAgent* | `chunk:59b8032f` |
| `outcome` | `claude` | 2026-05-24 | 5 | 29: args "-lc" "for root in \"${VIBECRAFTED_HOME:-$HOME/.vibecrafted}/tools/vibecrafted-current/config/zellij\" \"${VIBECRAFTED_ROOT:+$VIBECRAFTED_ROOT/config/zellij}\" \"./config/zellij\"; do if [[ -n \"$root\" && -x \"$root/loctree-drift.sh\" ]]; then exec \"$root/loctree-drift.sh\"; fi; done; printf 'loctree: drift helper not found\\n'; sleep 86400" | *AicxAgent* | `chunk:59b8032f` |
| `outcome` | `claude` | 2026-05-24 | 5 | 30: args "-lc" "for root in \"${VIBECRAFTED_HOME:-$HOME/.vibecrafted}/tools/vibecrafted-current/config/zellij\" \"${VIBECRAFTED_ROOT:+$VIBECRAFTED_ROOT/config/zellij}\" \"./config/zellij\"; do if [[ -n \"$root\" && -x \"$root/loctree-drift.sh\" ]]; then exec \"$root/loctree-drift.sh\"; fi; done; printf 'loctree: drift helper not found\\n'; sleep 86400" | *AicxAgent* | `chunk:59b8032f` |
| `outcome` | `claude` | 2026-05-23 | 5 | 25: args "-lc" "for root in \"${VIBECRAFTED_HOME:-$HOME/.vibecrafted}/tools/vibecrafted-current/config/zellij\" \"${VIBECRAFTED_ROOT:+$VIBECRAFTED_ROOT/config/zellij}\" \"./config/zellij\"; do if [[ -n \"$root\" && -x \"$root/aicx-status.sh\" ]]; then exec \"$root/aicx-status.sh\"; fi; done; printf 'aicx: status helper not found\\n'; sleep 86400" | *AicxAgent* | `chunk:e4427bc7` |
| `outcome` | `claude` | 2026-05-23 | 5 | 26: args "-lc" "for root in \"${VIBECRAFTED_HOME:-$HOME/.vibecrafted}/tools/vibecrafted-current/config/zellij\" \"${VIBECRAFTED_ROOT:+$VIBECRAFTED_ROOT/config/zellij}\" \"./config/zellij\"; do if [[ -n \"$root\" && -x \"$root/aicx-status.sh\" ]]; then exec \"$root/aicx-status.sh\"; fi; done; printf 'aicx: status helper not found\\n'; sleep 86400" | *AicxAgent* | `chunk:e4427bc7` |
| `outcome` | `claude` | 2026-05-23 | 5 | 27: args "-lc" "for root in \"${VIBECRAFTED_HOME:-$HOME/.vibecrafted}/tools/vibecrafted-current/config/zellij\" \"${VIBECRAFTED_ROOT:+$VIBECRAFTED_ROOT/config/zellij}\" \"./config/zellij\"; do if [[ -n \"$root\" && -x \"$root/aicx-status.sh\" ]]; then exec \"$root/aicx-status.sh\"; fi; done; printf 'aicx: status helper not found\\n'; sleep 86400" | *AicxAgent* | `chunk:e4427bc7` |
| `outcome` | `claude` | 2026-05-23 | 5 | 28: args "-lc" "for root in \"${VIBECRAFTED_HOME:-$HOME/.vibecrafted}/tools/vibecrafted-current/config/zellij\" \"${VIBECRAFTED_ROOT:+$VIBECRAFTED_ROOT/config/zellij}\" \"./config/zellij\"; do if [[ -n \"$root\" && -x \"$root/loctree-drift.sh\" ]]; then exec \"$root/loctree-drift.sh\"; fi; done; printf 'loctree: drift helper not found\\n'; sleep 86400" | *AicxAgent* | `chunk:e4427bc7` |
| `outcome` | `claude` | 2026-05-23 | 5 | 29: args "-lc" "for root in \"${VIBECRAFTED_HOME:-$HOME/.vibecrafted}/tools/vibecrafted-current/config/zellij\" \"${VIBECRAFTED_ROOT:+$VIBECRAFTED_ROOT/config/zellij}\" \"./config/zellij\"; do if [[ -n \"$root\" && -x \"$root/loctree-drift.sh\" ]]; then exec \"$root/loctree-drift.sh\"; fi; done; printf 'loctree: drift helper not found\\n'; sleep 86400" | *AicxAgent* | `chunk:e4427bc7` |
| `outcome` | `claude` | 2026-05-23 | 5 | 30: args "-lc" "for root in \"${VIBECRAFTED_HOME:-$HOME/.vibecrafted}/tools/vibecrafted-current/config/zellij\" \"${VIBECRAFTED_ROOT:+$VIBECRAFTED_ROOT/config/zellij}\" \"./config/zellij\"; do if [[ -n \"$root\" && -x \"$root/loctree-drift.sh\" ]]; then exec \"$root/loctree-drift.sh\"; fi; done; printf 'loctree: drift helper not found\\n'; sleep 86400" | *AicxAgent* | `chunk:e4427bc7` |
| `outcome` | `claude` | 2026-05-17 | 5 | **Cut N landed mid-Cut-O** — task-notification for Cut N likely arriving soon (or already arrived during Cut O's run). git log will confirm. The sync auto-pickup of `docs/ITERM2.md` is empirical proof Cut N completed enough to commit the new doc file. Two Wave 4/5 plans closed via concurrent dispatch. | *AicxAgent* | `chunk:73867c79` |
| `outcome` | `claude` | 2026-05-24 | 4 | 25: args "-lc" "for root in \"${VIBECRAFTED_HOME:-$HOME/.vibecrafted}/tools/vibecrafted-current/config/zellij\" \"${VIBECRAFTED_ROOT:+$VIBECRAFTED_ROOT/config/zellij}\" \"./config/zellij\"; do if [[ -n \"$root\" && -x \"$root/aicx-status.sh\" ]]; then exec \"$root/aicx-status.sh\"; fi; done; printf 'aicx: status helper not found\\n'; sleep 86400" | *AicxAgent* | `chunk:59b8032f` |
| `outcome` | `claude` | 2026-05-24 | 4 | 26: args "-lc" "for root in \"${VIBECRAFTED_HOME:-$HOME/.vibecrafted}/tools/vibecrafted-current/config/zellij\" \"${VIBECRAFTED_ROOT:+$VIBECRAFTED_ROOT/config/zellij}\" \"./config/zellij\"; do if [[ -n \"$root\" && -x \"$root/aicx-status.sh\" ]]; then exec \"$root/aicx-status.sh\"; fi; done; printf 'aicx: status helper not found\\n'; sleep 86400" | *AicxAgent* | `chunk:59b8032f` |
| `outcome` | `claude` | 2026-05-24 | 4 | 27: args "-lc" "for root in \"${VIBECRAFTED_HOME:-$HOME/.vibecrafted}/tools/vibecrafted-current/config/zellij\" \"${VIBECRAFTED_ROOT:+$VIBECRAFTED_ROOT/config/zellij}\" \"./config/zellij\"; do if [[ -n \"$root\" && -x \"$root/aicx-status.sh\" ]]; then exec \"$root/aicx-status.sh\"; fi; done; printf 'aicx: status helper not found\\n'; sleep 86400" | *AicxAgent* | `chunk:59b8032f` |
| `outcome` | `claude` | 2026-05-24 | 4 | 28: args "-lc" "for root in \"${VIBECRAFTED_HOME:-$HOME/.vibecrafted}/tools/vibecrafted-current/config/zellij\" \"${VIBECRAFTED_ROOT:+$VIBECRAFTED_ROOT/config/zellij}\" \"./config/zellij\"; do if [[ -n \"$root\" && -x \"$root/loctree-drift.sh\" ]]; then exec \"$root/loctree-drift.sh\"; fi; done; printf 'loctree: drift helper not found\\n'; sleep 86400" | *AicxAgent* | `chunk:59b8032f` |
| `outcome` | `claude` | 2026-05-24 | 4 | 29: args "-lc" "for root in \"${VIBECRAFTED_HOME:-$HOME/.vibecrafted}/tools/vibecrafted-current/config/zellij\" \"${VIBECRAFTED_ROOT:+$VIBECRAFTED_ROOT/config/zellij}\" \"./config/zellij\"; do if [[ -n \"$root\" && -x \"$root/loctree-drift.sh\" ]]; then exec \"$root/loctree-drift.sh\"; fi; done; printf 'loctree: drift helper not found\\n'; sleep 86400" | *AicxAgent* | `chunk:59b8032f` |
| `outcome` | `claude` | 2026-05-24 | 4 | 30: args "-lc" "for root in \"${VIBECRAFTED_HOME:-$HOME/.vibecrafted}/tools/vibecrafted-current/config/zellij\" \"${VIBECRAFTED_ROOT:+$VIBECRAFTED_ROOT/config/zellij}\" \"./config/zellij\"; do if [[ -n \"$root\" && -x \"$root/loctree-drift.sh\" ]]; then exec \"$root/loctree-drift.sh\"; fi; done; printf 'loctree: drift helper not found\\n'; sleep 86400" | *AicxAgent* | `chunk:59b8032f` |
| `outcome` | `claude` | 2026-05-24 | 4 | content: Task #6 created successfully: Verify: zellij setup --check + smoke tests green | *AicxAgent* | `chunk:075189ea` |
| `outcome` | `claude` | 2026-05-23 | 4 | 25: args "-lc" "for root in \"${VIBECRAFTED_HOME:-$HOME/.vibecrafted}/tools/vibecrafted-current/config/zellij\" \"${VIBECRAFTED_ROOT:+$VIBECRAFTED_ROOT/config/zellij}\" \"./config/zellij\"; do if [[ -n \"$root\" && -x \"$root/aicx-status.sh\" ]]; then exec \"$root/aicx-status.sh\"; fi; done; printf 'aicx: status helper not found\\n'; sleep 86400" | *AicxAgent* | `chunk:e4427bc7` |
| `outcome` | `claude` | 2026-05-23 | 4 | 26: args "-lc" "for root in \"${VIBECRAFTED_HOME:-$HOME/.vibecrafted}/tools/vibecrafted-current/config/zellij\" \"${VIBECRAFTED_ROOT:+$VIBECRAFTED_ROOT/config/zellij}\" \"./config/zellij\"; do if [[ -n \"$root\" && -x \"$root/aicx-status.sh\" ]]; then exec \"$root/aicx-status.sh\"; fi; done; printf 'aicx: status helper not found\\n'; sleep 86400" | *AicxAgent* | `chunk:e4427bc7` |
| `outcome` | `claude` | 2026-05-23 | 4 | 27: args "-lc" "for root in \"${VIBECRAFTED_HOME:-$HOME/.vibecrafted}/tools/vibecrafted-current/config/zellij\" \"${VIBECRAFTED_ROOT:+$VIBECRAFTED_ROOT/config/zellij}\" \"./config/zellij\"; do if [[ -n \"$root\" && -x \"$root/aicx-status.sh\" ]]; then exec \"$root/aicx-status.sh\"; fi; done; printf 'aicx: status helper not found\\n'; sleep 86400" | *AicxAgent* | `chunk:e4427bc7` |
| `outcome` | `claude` | 2026-05-23 | 4 | 28: args "-lc" "for root in \"${VIBECRAFTED_HOME:-$HOME/.vibecrafted}/tools/vibecrafted-current/config/zellij\" \"${VIBECRAFTED_ROOT:+$VIBECRAFTED_ROOT/config/zellij}\" \"./config/zellij\"; do if [[ -n \"$root\" && -x \"$root/loctree-drift.sh\" ]]; then exec \"$root/loctree-drift.sh\"; fi; done; printf 'loctree: drift helper not found\\n'; sleep 86400" | *AicxAgent* | `chunk:e4427bc7` |
| `outcome` | `claude` | 2026-05-23 | 4 | 29: args "-lc" "for root in \"${VIBECRAFTED_HOME:-$HOME/.vibecrafted}/tools/vibecrafted-current/config/zellij\" \"${VIBECRAFTED_ROOT:+$VIBECRAFTED_ROOT/config/zellij}\" \"./config/zellij\"; do if [[ -n \"$root\" && -x \"$root/loctree-drift.sh\" ]]; then exec \"$root/loctree-drift.sh\"; fi; done; printf 'loctree: drift helper not found\\n'; sleep 86400" | *AicxAgent* | `chunk:e4427bc7` |
| `outcome` | `claude` | 2026-05-23 | 4 | 30: args "-lc" "for root in \"${VIBECRAFTED_HOME:-$HOME/.vibecrafted}/tools/vibecrafted-current/config/zellij\" \"${VIBECRAFTED_ROOT:+$VIBECRAFTED_ROOT/config/zellij}\" \"./config/zellij\"; do if [[ -n \"$root\" && -x \"$root/loctree-drift.sh\" ]]; then exec \"$root/loctree-drift.sh\"; fi; done; printf 'loctree: drift helper not found\\n'; sleep 86400" | *AicxAgent* | `chunk:e4427bc7` |
| `outcome` | `claude` | 2026-05-23 | 4 | content: Task #6 created successfully: Verify: zellij setup --check + smoke tests green | *AicxAgent* | `chunk:63292df8` |
| `outcome` | `claude` | 2026-05-23 | 4 | **Dlaczego to się stało** — to było **marble wave** (`reports/marbles/`). Marble worker (vc-marbles skill) z definicji robi *deliberate over-correction* — wpieniąć kulki w każdom dziurę. Tu plan był "agent-native runtime stack — widget visibility layer". Marble worker dowiózł całe 13 plików z **36 testami**. Tylko że te 36 assertions testują że **widget się spawnuje** + **output ma format** + **host mapping działa** + **layout się parsuje** — czyli … | *AicxAgent* | `chunk:eb2e32f0` |
| `outcome` | `claude` | 2026-05-17 | 4 | Skill mówi wyraźnie: "find and read it in full — `master-dispatch.md`, per-prompt bodies, `docs/backlog/<YYYY-MM-DD>-<slug>.md`". Init pokazał, że **META_22 session miała 22 plany, 14 done, 3 active, 7 unstarted** — ale to było 2026-05-12, pięć dni temu. Co zmieniło się od tamtego do teraz, czy 7 unstartowanych zostało zamknietych, czy są nowe plany — to muszę zlokalizować. | *AicxAgent* | `chunk:ebf60f75` |
| `outcome` | `claude` | 2026-05-17 | 4 | **Active: 1** — Cut C (Codex external `operator/.app`) ~7h+ elapsed. Crash report just shared by operator pokazuje dylib bundling + Team ID alignment gaps not yet closed — Cut C może still być pracujący na tym OR completed with explicit blockers w report. Auto-notify pending. | *AicxAgent* | `chunk:73867c79` |
| `outcome` | `claude` | 2026-05-17 | 4 | **Cut N landed mid-Cut-O** — task-notification for Cut N likely arriving soon (or already arrived during Cut O's run). git log will confirm. The sync auto-pickup of `docs/ITERM2.md` is empirical proof Cut N completed enough to commit the new doc file. Two Wave 4/5 plans closed via concurrent dispatch. | *AicxAgent* | `chunk:73867c79` |
| `outcome` | `claude` | 2026-05-17 | 4 | **Verification.** `pnpm check` 0/0/0; `pnpm run build` green (40 pages, +1 vs Plan 19's 39 — that's the new docs surface; V2 search + scroll-flow smoke tests pass); `shellcheck` clean; `xmllint --noou...[truncated] | *AicxAgent* | `chunk:73867c79` |
| `outcome` | `claude` | 2026-05-17 | 4 | <summary>Agent "Cut Q: Plan 08 AICX sync v2" completed</summary> | *AicxAgent* | `chunk:73867c79` |
| `outcome` | `claude` | 2026-05-17 | 4 | WHY: <status>completed</status> \| <result>All green post-commit: 16 bash + 36 pytest (Plan 08), 140 total pytest cases across `vibecrafted-core/tests/` (zero regressions). | *AicxAgent* | `chunk:73867c79` |
| `outcome` | `claude` | 2026-05-17 | 4 | "markdown": "# Loctree Context · vibecrafted @ release/v1.7.1 · 2026-05-17T10:41:40.346696Z\n\n_0 files · 0 import edges · snapshot fresh · clean worktree_\n\n## TL;DR — read this first\n\n**What this is.** `vibecrafted` repository (0 files, 0 import edges).\n\n**Where you stand.** Branch `release/v1.7.1`, clean worktree, snapshot fresh.\nActive intent (AICX): \"Done: [vibecrafted-loct-context.md](/tmp/vibecrafted-loct-context.md)\" — codex on 2026-05-12. | *AicxAgent* | `chunk:94b9897c` |
| `outcome` | `claude` | 2026-05-16 | 4 | content: {"path":"/Users/maciejgad/.aicx/store/Szowesgad/CodeScribe-Transcripts/2026_0124/conversations/codescribe/2026_0124_codescribe_d8001b469a49_001.md","relative_path":"store/Szowesgad/CodeScribe-Transcripts/2026_0124/conversations/codescribe/2026_0124_codescribe_d8001b469a49_001.md","project":"Szowesgad/CodeScribe-Transcripts","date":"2026-01-24","kind":"conversations","agent":"codescribe","session_id":"d8001b469a49","chunk":1,"bytes":5723,"content":"[project … | *AicxAgent* | `chunk:80f71bfc` |
| `outcome` | `claude` | 2026-05-16 | 4 | content: {"oracle_status":{"source_layer":"layer_1_canonical_corpus","backend":"filesystem_fuzzy","index_kind":"none","fallback_reason":"fallback_filesystem_fuzzy: content index unavailable","derived_view":"none_filesystem_scan","store_root":"/Users/maciejgad/.aicx","indexed_count":0,"scanned_count":8738,"candidate_count":10,"source_paths_verified":true,"stale_or_unknown":true,"loctree_scope_safe":false,"loctree_scope_note":"unsafe_for_scope_narrowing … | *AicxAgent* | `chunk:573f0db4` |

### Source Chunks

_10 unique chunk(s) reachable via `aicx open <chunk:ref>` (resolved against the operator's local aicx store; absolute paths intentionally redacted to keep this context-pack commitable)._

- `chunk:573f0db4`
- `chunk:80f71bfc`
- `chunk:94b9897c`
- `chunk:73867c79`
- `chunk:ebf60f75`
- `chunk:eb2e32f0`
- `chunk:63292df8`
- `chunk:e4427bc7`
- `chunk:075189ea`
- `chunk:59b8032f`

## Authority Slice

- Repo Verified: 1
- Loctree Derived: 224
- AICX Operator: 0
- AICX Agent: 50
- AICX Failure: 0
- Semantic Guess: 0
- Stale Or Unknown: 0

