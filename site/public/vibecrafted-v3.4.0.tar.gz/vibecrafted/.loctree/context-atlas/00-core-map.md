# Core Map

Project: `/Users/maciejgad/vc-workspace/vetcoders/vibecrafted`
Snapshot: `feat/sdk-preparation@76ab7751`
Freshness: `fresh - card matches the loaded snapshot authority.`

This card tells you where you are, what is risky, and what actions are safe next.

```json
{
  "action": {
    "likely_tests": [
      "plugins/iterm2/tests/test_iterm2_profiles.py",
      "tests/agent_dispatch_test.py",
      "tests/tui/test_default_runtime.py",
      "tests/tui/test_vibecrafted_launcher.py",
      "vibecrafted-app/tui-agent/tests/state_contract.rs",
      "vibecrafted-core/tests/dispatch/test_cli.py",
      "vibecrafted-core/tests/dispatch/test_supervisor.py",
      "vibecrafted-core/tests/test_agy_junie_pipeline.py",
      "vibecrafted-core/tests/test_aicx_sync.py",
      "vibecrafted-core/tests/test_capabilities.py"
    ],
    "next_safe_commands": [
      "loct find test_init_claude_uses_interactive_tab_without_print_mode",
      "loct find CliOptions",
      "loct find test_hex_to_iterm2_six_digit"
    ],
    "power_path": [
      {
        "command": "loct slice tests/tui/test_vibecrafted_launcher.py",
        "reason": "Slice this file to inspect its direct dependencies and immediate consumers before editing."
      },
      {
        "command": "loct body test_init_claude_uses_interactive_tab_without_print_mode",
        "reason": "View the definition body of symbol 'test_init_claude_uses_interactive_tab_without_print_mode' to understand its implementation structure."
      },
      {
        "command": "loct find --literal test_init_claude_uses_interactive_tab_without_print_mode",
        "reason": "Execute a literal exact-identifier scan for 'test_init_claude_uses_interactive_tab_without_print_mode' to find exact matches across the codebase."
      },
      {
        "command": "loct occurrences test_init_claude_uses_interactive_tab_without_print_mode",
        "reason": "Perform a literal boundary-sensitive occurrences scan for 'test_init_claude_uses_interactive_tab_without_print_mode' to locate all references."
      },
      {
        "command": "loct follow",
        "reason": "Pursue unified structural signals (dead exports, import cycles, twins) to ensure health."
      },
      {
        "command": "loct slice vibecrafted-app/mux-agent/src/lib.rs",
        "reason": "Slice this file to inspect its direct dependencies and immediate consumers before editing."
      },
      {
        "command": "loct body CliOptions",
        "reason": "View the definition body of symbol 'CliOptions' to understand its implementation structure."
      },
      {
        "command": "loct find --literal CliOptions",
        "reason": "Execute a literal exact-identifier scan for 'CliOptions' to find exact matches across the codebase."
      },
      {
        "command": "loct occurrences CliOptions",
        "reason": "Perform a literal boundary-sensitive occurrences scan for 'CliOptions' to locate all references."
      },
      {
        "command": "loct slice plugins/iterm2/tests/test_iterm2_profiles.py",
        "reason": "Slice this file to inspect its direct dependencies and immediate consumers before editing."
      },
      {
        "command": "loct body test_hex_to_iterm2_six_digit",
        "reason": "View the definition body of symbol 'test_hex_to_iterm2_six_digit' to understand its implementation structure."
      },
      {
        "command": "loct find --literal test_hex_to_iterm2_six_digit",
        "reason": "Execute a literal exact-identifier scan for 'test_hex_to_iterm2_six_digit' to find exact matches across the codebase."
      },
      {
        "command": "loct occurrences test_hex_to_iterm2_six_digit",
        "reason": "Perform a literal boundary-sensitive occurrences scan for 'test_hex_to_iterm2_six_digit' to locate all references."
      },
      {
        "command": "loct slice vibecrafted-app/shell-agent/app/Vibecrafted/Bridge/vibecrafted_shell_ffi.swift",
        "reason": "Slice this file to inspect its direct dependencies and immediate consumers before editing."
      },
      {
        "command": "loct impact vibecrafted-app/shell-agent/app/Vibecrafted/Bridge/vibecrafted_shell_ffi.swift",
        "reason": "Assess the transitive blast radius and downstream consumers of this file before modifying."
      },
      {
        "command": "loct body RustBuffer",
        "reason": "View the definition body of symbol 'RustBuffer' to understand its implementation structure."
      },
      {
        "command": "loct find --literal RustBuffer",
        "reason": "Execute a literal exact-identifier scan for 'RustBuffer' to find exact matches across the codebase."
      },
      {
        "command": "loct occurrences RustBuffer",
        "reason": "Perform a literal boundary-sensitive occurrences scan for 'RustBuffer' to locate all references."
      },
      {
        "command": "loct slice vibecrafted-app/mux-agent/src/state.rs",
        "reason": "Slice this file to inspect its direct dependencies and immediate consumers before editing."
      },
      {
        "command": "loct impact vibecrafted-app/mux-agent/src/state.rs",
        "reason": "Assess the transitive blast radius and downstream consumers of this file before modifying."
      },
      {
        "command": "loct body new",
        "reason": "View the definition body of symbol 'new' to understand its implementation structure."
      },
      {
        "command": "loct find --literal new",
        "reason": "Execute a literal exact-identifier scan for 'new' to find exact matches across the codebase."
      },
      {
        "command": "loct occurrences new",
        "reason": "Perform a literal boundary-sensitive occurrences scan for 'new' to locate all references."
      }
    ],
    "verification_gates": [
      "mypy ."
    ]
  },
  "authority": {
    "aicx_agent": [
      "memory.entries.6bc78e30-98bc-4fd1-8-hce6e1b::outcome",
      "memory.entries.6bc78e30-98bc-4fd1-8-hce6e1b::outcome",
      "memory.entries.6bc78e30-98bc-4fd1-8-hce6e1b::outcome",
      "memory.entries.6bc78e30-98bc-4fd1-8-hce6e1b::outcome",
      "memory.entries.6bc78e30-98bc-4fd1-8-hce6e1b::outcome",
      "memory.entries.6bc78e30-98bc-4fd1-8-hce6e1b::outcome",
      "memory.entries.6bc78e30-98bc-4fd1-8-hce6e1b::outcome",
      "memory.entries.6bc78e30-98bc-4fd1-8-hce6e1b::outcome",
      "memory.entries.6bc78e30-98bc-4fd1-8-hce6e1b::outcome",
      "memory.entries.019f369f-a4a1-7fd2-b-h0ce9c4::task",
      "memory.entries.6bc78e30-98bc-4fd1-8-hce6e1b::outcome",
      "memory.entries.6bc78e30-98bc-4fd1-8-hce6e1b::outcome",
      "memory.entries.6bc78e30-98bc-4fd1-8-hce6e1b::outcome",
      "memory.entries.6bc78e30-98bc-4fd1-8-hce6e1b::outcome",
      "memory.entries.6bc78e30-98bc-4fd1-8-hce6e1b::outcome",
      "memory.entries.2603026d-0c40-4ca9-a-h075c0b::outcome",
      "memory.entries.6bc78e30-98bc-4fd1-8-hce6e1b::outcome",
      "memory.entries.6bc78e30-98bc-4fd1-8-hce6e1b::outcome",
      "memory.entries.6bc78e30-98bc-4fd1-8-hce6e1b::outcome",
      "memory.entries.6bc78e30-98bc-4fd1-8-hce6e1b::outcome",
      "memory.entries.6bc78e30-98bc-4fd1-8-hce6e1b::outcome",
      "memory.entries.6bc78e30-98bc-4fd1-8-hce6e1b::outcome",
      "memory.entries.2603026d-0c40-4ca9-a-h075c0b::outcome",
      "memory.entries.019f369f-a4a1-7fd2-b-h0ce9c4::task"
    ],
    "aicx_failure": [],
    "aicx_operator": [
      "memory.entries.6bc78e30-98bc-4fd1-8-hce6e1b::intent",
      "memory.entries.6bc78e30-98bc-4fd1-8-hce6e1b::intent",
      "memory.entries.78b63355-1429-42c4-b-h8a1d0b::intent",
      "memory.entries.6bc78e30-98bc-4fd1-8-hce6e1b::decision",
      "memory.entries.2603026d-0c40-4ca9-a-h075c0b::intent",
      "memory.entries.78b63355-1429-42c4-b-h8a1d0b::decision",
      "memory.entries.78b63355-1429-42c4-b-h8a1d0b::intent",
      "memory.entries.6bc78e30-98bc-4fd1-8-hce6e1b::intent",
      "memory.entries.6bc78e30-98bc-4fd1-8-hce6e1b::intent",
      "memory.entries.2603026d-0c40-4ca9-a-h075c0b::intent",
      "memory.entries.6bc78e30-98bc-4fd1-8-hce6e1b::decision",
      "memory.entries.6bc78e30-98bc-4fd1-8-hce6e1b::decision",
      "memory.entries.78b63355-1429-42c4-b-h8a1d0b::decision",
      "memory.entries.78b63355-1429-42c4-b-h8a1d0b::intent",
      "memory.entries.6bc78e30-98bc-4fd1-8-hce6e1b::decision",
      "memory.entries.6bc78e30-98bc-4fd1-8-hce6e1b::intent",
      "memory.entries.6bc78e30-98bc-4fd1-8-hce6e1b::intent",
      "memory.entries.6bc78e30-98bc-4fd1-8-hce6e1b::intent",
      "memory.entries.2603026d-0c40-4ca9-a-h075c0b::intent",
      "memory.entries.2603026d-0c40-4ca9-a-h075c0b::intent",
      "memory.entries.2603026d-0c40-4ca9-a-h075c0b::intent",
      "memory.entries.6bc78e30-98bc-4fd1-8-hce6e1b::decision",
      "memory.entries.6bc78e30-98bc-4fd1-8-hce6e1b::intent",
      "memory.entries.6bc78e30-98bc-4fd1-8-hce6e1b::intent",
      "memory.entries.6bc78e30-98bc-4fd1-8-hce6e1b::intent",
      "memory.entries.78b63355-1429-42c4-b-h8a1d0b::intent"
    ],
    "loctree_derived": [
      "runtime.idiom_tags.vibecrafted-app/mux-agent/src/lib.rs::new::new",
      "runtime.idiom_tags.vibecrafted-app/mux-agent/src/state.rs::new::new",
      "runtime.dispatch_edges.tests/tui/test_vibecrafted_launcher.py:1236->test_autonomous_delivery_skills_route_to_core_async_launcher",
      "runtime.reachability.reached.tests/tui/test_vibecrafted_launcher.py::test_autonomous_delivery_skills_route_to_core_async_launcher",
      "runtime.env_contracts.CAPTURE_FILE",
      "runtime.env_contracts.CURL_CAPTURE_FILE",
      "runtime.env_contracts.FAKE_CURL_ROUTES",
      "runtime.env_contracts.FAKE_VC_FRAME_LISTING",
      "runtime.env_contracts.FAKE_VC_FRAME_SESSION",
      "runtime.env_contracts.SESSION_STATE_FILE",
      "runtime.framework_hints.rust:pub_use_reexport.vibecrafted-app/mux-agent/src/lib.rs::CliOptions",
      "runtime.framework_hints.rust:pub_use_reexport.vibecrafted-app/mux-agent/src/lib.rs::Config",
      "runtime.framework_hints.rust:pub_use_reexport.vibecrafted-app/mux-agent/src/lib.rs::DEFAULT_STATUS_SOCKET",
      "runtime.framework_hints.rust:pub_use_reexport.vibecrafted-app/mux-agent/src/lib.rs::DaemonStatus",
      "runtime.framework_hints.rust:pub_use_reexport.vibecrafted-app/mux-agent/src/lib.rs::HeartbeatConfig",
      "runtime.framework_hints.rust:pub_use_reexport.vibecrafted-app/mux-agent/src/lib.rs::MAX_PENDING",
      "runtime.framework_hints.rust:pub_use_reexport.vibecrafted-app/mux-agent/src/lib.rs::MAX_QUEUE",
      "runtime.framework_hints.rust:pub_use_reexport.vibecrafted-app/mux-agent/src/lib.rs::ManagedServer",
      "runtime.framework_hints.rust:pub_use_reexport.vibecrafted-app/mux-agent/src/lib.rs::MultiServerStatus",
      "runtime.framework_hints.rust:pub_use_reexport.vibecrafted-app/mux-agent/src/lib.rs::MuxState",
      "runtime.framework_hints.rust:pub_use_reexport.vibecrafted-app/mux-agent/src/lib.rs::ResolvedParams",
      "runtime.framework_hints.rust:pub_use_reexport.vibecrafted-app/mux-agent/src/lib.rs::ServerCommand",
      "runtime.framework_hints.rust:pub_use_reexport.vibecrafted-app/mux-agent/src/lib.rs::ServerConfig",
      "runtime.framework_hints.rust:pub_use_reexport.vibecrafted-app/mux-agent/src/lib.rs::ServerRef",
      "runtime.framework_hints.rust:pub_use_reexport.vibecrafted-app/mux-agent/src/lib.rs::ServerStatus",
      "runtime.framework_hints.rust:pub_use_reexport.vibecrafted-app/mux-agent/src/lib.rs::StatusLevel",
      "runtime.framework_hints.rust:pub_use_reexport.vibecrafted-app/mux-agent/src/lib.rs::StatusSnapshot",
      "runtime.framework_hints.rust:pub_use_reexport.vibecrafted-app/mux-agent/src/lib.rs::StatusState",
      "runtime.framework_hints.rust:pub_use_reexport.vibecrafted-app/mux-agent/src/lib.rs::TuiMuxState",
      "runtime.framework_hints.rust:pub_use_reexport.vibecrafted-app/mux-agent/src/lib.rs::format_uptime",
      "runtime.framework_hints.rust:pub_use_reexport.vibecrafted-app/mux-agent/src/lib.rs::health_check",
      "runtime.framework_hints.rust:inherent_impl_method.vibecrafted-app/mux-agent/src/lib.rs::is_running",
      "runtime.framework_hints.rust:inherent_impl_method.vibecrafted-app/mux-agent/src/lib.rs::new",
      "runtime.framework_hints.rust:pub_use_reexport.vibecrafted-app/mux-agent/src/lib.rs::print_status_table",
      "runtime.framework_hints.rust:pub_use_reexport.vibecrafted-app/mux-agent/src/lib.rs::query_status",
      "runtime.framework_hints.rust:pub_use_reexport.vibecrafted-app/mux-agent/src/lib.rs::resolve_params_multi",
      "runtime.framework_hints.rust:pub_use_reexport.vibecrafted-app/mux-agent/src/lib.rs::run_multi_tui",
      "runtime.framework_hints.rust:pub_use_reexport.vibecrafted-app/mux-agent/src/lib.rs::run_mux",
      "runtime.framework_hints.rust:pub_use_reexport.vibecrafted-app/mux-agent/src/lib.rs::run_proxy",
      "runtime.framework_hints.rust:pub_use_reexport.vibecrafted-app/mux-agent/src/lib.rs::run_status_listener",
      "runtime.framework_hints.rust:inherent_impl_method.vibecrafted-app/mux-agent/src/lib.rs::service_name",
      "runtime.framework_hints.rust:inherent_impl_method.vibecrafted-app/mux-agent/src/lib.rs::shutdown",
      "runtime.framework_hints.rust:inherent_impl_method.vibecrafted-app/mux-agent/src/lib.rs::wait",
      "runtime.framework_hints.rust:inherent_impl_method.vibecrafted-app/mux-agent/src/lib.rs::with_args",
      "runtime.framework_hints.rust:inherent_impl_method.vibecrafted-app/mux-agent/src/lib.rs::with_env",
      "runtime.framework_hints.rust:inherent_impl_method.vibecrafted-app/mux-agent/src/lib.rs::with_env_var",
      "runtime.framework_hints.rust:inherent_impl_method.vibecrafted-app/mux-agent/src/lib.rs::with_heartbeat",
      "runtime.framework_hints.rust:inherent_impl_method.vibecrafted-app/mux-agent/src/lib.rs::with_heartbeat_enabled",
      "runtime.framework_hints.rust:inherent_impl_method.vibecrafted-app/mux-agent/src/lib.rs::with_heartbeat_max_failures",
      "runtime.framework_hints.rust:inherent_impl_method.vibecrafted-app/mux-agent/src/lib.rs::with_lazy_start",
      "runtime.framework_hints.rust:inherent_impl_method.vibecrafted-app/mux-agent/src/lib.rs::with_log_level",
      "runtime.framework_hints.rust:inherent_impl_method.vibecrafted-app/mux-agent/src/lib.rs::with_max_clients",
      "runtime.framework_hints.rust:inherent_impl_method.vibecrafted-app/mux-agent/src/lib.rs::with_max_request_bytes",
      "runtime.framework_hints.rust:inherent_impl_method.vibecrafted-app/mux-agent/src/lib.rs::with_max_restarts",
      "runtime.framework_hints.rust:inherent_impl_method.vibecrafted-app/mux-agent/src/lib.rs::with_request_timeout",
      "runtime.framework_hints.rust:inherent_impl_method.vibecrafted-app/mux-agent/src/lib.rs::with_restart_backoff",
      "runtime.framework_hints.rust:inherent_impl_method.vibecrafted-app/mux-agent/src/lib.rs::with_service_name",
      "runtime.framework_hints.rust:inherent_impl_method.vibecrafted-app/mux-agent/src/lib.rs::with_status_file",
      "runtime.framework_hints.rust:inherent_impl_method.vibecrafted-app/mux-agent/src/lib.rs::with_tray",
      "runtime.framework_hints.rust:inherent_impl_method.vibecrafted-app/mux-agent/src/state.rs::buffer_message",
      "runtime.framework_hints.rust:inherent_impl_method.vibecrafted-app/mux-agent/src/state.rs::complete_handshake",
      "runtime.framework_hints.rust:inherent_impl_method.vibecrafted-app/mux-agent/src/state.rs::get_handshake_mut",
      "runtime.framework_hints.rust:inherent_impl_method.vibecrafted-app/mux-agent/src/state.rs::is_handshake_complete",
      "runtime.framework_hints.rust:inherent_impl_method.vibecrafted-app/mux-agent/src/state.rs::is_handshake_timed_out",
      "runtime.framework_hints.rust:inherent_impl_method.vibecrafted-app/mux-agent/src/state.rs::mark_handshake_complete",
      "runtime.framework_hints.rust:inherent_impl_method.vibecrafted-app/mux-agent/src/state.rs::new",
      "runtime.framework_hints.rust:inherent_impl_method.vibecrafted-app/mux-agent/src/state.rs::next_request_id",
      "runtime.framework_hints.rust:inherent_impl_method.vibecrafted-app/mux-agent/src/state.rs::register_client",
      "runtime.framework_hints.rust:inherent_impl_method.vibecrafted-app/mux-agent/src/state.rs::unregister_client",
      "risk.hotspots.vibecrafted-app/mux-agent/src/state.rs",
      "risk.hotspots.vibecrafted-app/shell-agent/app/Vibecrafted/Bridge/vibecrafted_shell_ffi.swift",
      "risk.high_fan_in.vibecrafted-app/mux-agent/src/state.rs",
      "action.likely_tests.plugins/iterm2/tests/test_iterm2_profiles.py",
      "action.likely_tests.tests/agent_dispatch_test.py",
      "action.likely_tests.tests/tui/test_default_runtime.py",
      "action.likely_tests.tests/tui/test_vibecrafted_launcher.py",
      "action.likely_tests.vibecrafted-app/tui-agent/tests/state_contract.rs",
      "action.likely_tests.vibecrafted-core/tests/dispatch/test_cli.py",
      "action.likely_tests.vibecrafted-core/tests/dispatch/test_supervisor.py",
      "action.likely_tests.vibecrafted-core/tests/test_agy_junie_pipeline.py",
      "action.likely_tests.vibecrafted-core/tests/test_aicx_sync.py",
      "action.likely_tests.vibecrafted-core/tests/test_capabilities.py",
      "action.next_safe_commands.loct find test_init_claude_uses_interactive_tab_without_print_mode",
      "action.next_safe_commands.loct find CliOptions",
      "action.next_safe_commands.loct find test_hex_to_iterm2_six_digit",
      "action.verification_gates.mypy ."
    ],
    "repo_verified": [
      "risk.cache_scope"
    ],
    "semantic_guess": [
      "runtime.idiom_tags.vibecrafted-app/mux-agent/src/lib.rs::CliOptions::CliOptions",
      "runtime.idiom_tags.vibecrafted-app/mux-agent/src/lib.rs::Config::Config",
      "runtime.idiom_tags.vibecrafted-app/mux-agent/src/lib.rs::DEFAULT_STATUS_SOCKET::DEFAULT_STATUS_SOCKET",
      "runtime.idiom_tags.vibecrafted-app/mux-agent/src/lib.rs::DaemonStatus::DaemonStatus",
      "runtime.idiom_tags.vibecrafted-app/mux-agent/src/lib.rs::HeartbeatConfig::HeartbeatConfig",
      "runtime.idiom_tags.vibecrafted-app/mux-agent/src/lib.rs::MAX_PENDING::MAX_PENDING",
      "runtime.idiom_tags.vibecrafted-app/mux-agent/src/lib.rs::MAX_QUEUE::MAX_QUEUE",
      "runtime.idiom_tags.vibecrafted-app/mux-agent/src/lib.rs::ManagedServer::ManagedServer",
      "runtime.idiom_tags.vibecrafted-app/mux-agent/src/lib.rs::MultiServerStatus::MultiServerStatus",
      "runtime.idiom_tags.vibecrafted-app/mux-agent/src/lib.rs::MuxState::MuxState",
      "runtime.idiom_tags.vibecrafted-app/mux-agent/src/lib.rs::ResolvedParams::ResolvedParams",
      "runtime.idiom_tags.vibecrafted-app/mux-agent/src/lib.rs::ServerCommand::ServerCommand",
      "runtime.idiom_tags.vibecrafted-app/mux-agent/src/lib.rs::ServerConfig::ServerConfig",
      "runtime.idiom_tags.vibecrafted-app/mux-agent/src/lib.rs::ServerRef::ServerRef",
      "runtime.idiom_tags.vibecrafted-app/mux-agent/src/lib.rs::ServerStatus::ServerStatus",
      "runtime.idiom_tags.vibecrafted-app/mux-agent/src/lib.rs::StatusLevel::StatusLevel",
      "runtime.idiom_tags.vibecrafted-app/mux-agent/src/lib.rs::StatusSnapshot::StatusSnapshot",
      "runtime.idiom_tags.vibecrafted-app/mux-agent/src/lib.rs::StatusState::StatusState",
      "runtime.idiom_tags.vibecrafted-app/mux-agent/src/lib.rs::TuiMuxState::TuiMuxState",
      "runtime.idiom_tags.vibecrafted-app/mux-agent/src/lib.rs::format_uptime::format_uptime",
      "runtime.idiom_tags.vibecrafted-app/mux-agent/src/lib.rs::health_check::health_check",
      "runtime.idiom_tags.vibecrafted-app/mux-agent/src/lib.rs::is_running::is_running",
      "runtime.idiom_tags.vibecrafted-app/mux-agent/src/lib.rs::print_status_table::print_status_table",
      "runtime.idiom_tags.vibecrafted-app/mux-agent/src/lib.rs::query_status::query_status",
      "runtime.idiom_tags.vibecrafted-app/mux-agent/src/lib.rs::resolve_params_multi::resolve_params_multi",
      "runtime.idiom_tags.vibecrafted-app/mux-agent/src/lib.rs::run_multi_tui::run_multi_tui",
      "runtime.idiom_tags.vibecrafted-app/mux-agent/src/lib.rs::run_mux::run_mux",
      "runtime.idiom_tags.vibecrafted-app/mux-agent/src/lib.rs::run_proxy::run_proxy",
      "runtime.idiom_tags.vibecrafted-app/mux-agent/src/lib.rs::run_status_listener::run_status_listener",
      "runtime.idiom_tags.vibecrafted-app/mux-agent/src/lib.rs::service_name::service_name",
      "runtime.idiom_tags.vibecrafted-app/mux-agent/src/lib.rs::shutdown::shutdown",
      "runtime.idiom_tags.vibecrafted-app/mux-agent/src/lib.rs::wait::wait",
      "runtime.idiom_tags.vibecrafted-app/mux-agent/src/lib.rs::with_args::with_args",
      "runtime.idiom_tags.vibecrafted-app/mux-agent/src/lib.rs::with_env::with_env",
      "runtime.idiom_tags.vibecrafted-app/mux-agent/src/lib.rs::with_env_var::with_env_var",
      "runtime.idiom_tags.vibecrafted-app/mux-agent/src/lib.rs::with_heartbeat::with_heartbeat",
      "runtime.idiom_tags.vibecrafted-app/mux-agent/src/lib.rs::with_heartbeat_enabled::with_heartbeat_enabled",
      "runtime.idiom_tags.vibecrafted-app/mux-agent/src/lib.rs::with_heartbeat_max_failures::with_heartbeat_max_failures",
      "runtime.idiom_tags.vibecrafted-app/mux-agent/src/lib.rs::with_lazy_start::with_lazy_start",
      "runtime.idiom_tags.vibecrafted-app/mux-agent/src/lib.rs::with_log_level::with_log_level",
      "runtime.idiom_tags.vibecrafted-app/mux-agent/src/lib.rs::with_max_clients::with_max_clients",
      "runtime.idiom_tags.vibecrafted-app/mux-agent/src/lib.rs::with_max_request_bytes::with_max_request_bytes",
      "runtime.idiom_tags.vibecrafted-app/mux-agent/src/lib.rs::with_max_restarts::with_max_restarts",
      "runtime.idiom_tags.vibecrafted-app/mux-agent/src/lib.rs::with_request_timeout::with_request_timeout",
      "runtime.idiom_tags.vibecrafted-app/mux-agent/src/lib.rs::with_restart_backoff::with_restart_backoff",
      "runtime.idiom_tags.vibecrafted-app/mux-agent/src/lib.rs::with_service_name::with_service_name",
      "runtime.idiom_tags.vibecrafted-app/mux-agent/src/lib.rs::with_status_file::with_status_file",
      "runtime.idiom_tags.vibecrafted-app/mux-agent/src/lib.rs::with_tray::with_tray",
      "runtime.idiom_tags.vibecrafted-app/mux-agent/src/state.rs::buffer_message::buffer_message",
      "runtime.idiom_tags.vibecrafted-app/mux-agent/src/state.rs::complete_handshake::complete_handshake",
      "runtime.idiom_tags.vibecrafted-app/mux-agent/src/state.rs::get_handshake_mut::get_handshake_mut",
      "runtime.idiom_tags.vibecrafted-app/mux-agent/src/state.rs::is_handshake_complete::is_handshake_complete",
      "runtime.idiom_tags.vibecrafted-app/mux-agent/src/state.rs::is_handshake_timed_out::is_handshake_timed_out",
      "runtime.idiom_tags.vibecrafted-app/mux-agent/src/state.rs::mark_handshake_complete::mark_handshake_complete",
      "runtime.idiom_tags.vibecrafted-app/mux-agent/src/state.rs::next_request_id::next_request_id",
      "runtime.idiom_tags.vibecrafted-app/mux-agent/src/state.rs::register_client::register_client",
      "runtime.idiom_tags.vibecrafted-app/mux-agent/src/state.rs::unregister_client::unregister_client",
      "runtime.reachability.reached.vibecrafted-app/mux-agent/src/lib.rs::CliOptions",
      "runtime.reachability.reached.vibecrafted-app/mux-agent/src/lib.rs::Config",
      "runtime.reachability.reached.vibecrafted-app/mux-agent/src/lib.rs::DEFAULT_STATUS_SOCKET",
      "runtime.reachability.reached.vibecrafted-app/mux-agent/src/lib.rs::DaemonStatus",
      "runtime.reachability.reached.vibecrafted-app/mux-agent/src/lib.rs::HeartbeatConfig",
      "runtime.reachability.reached.vibecrafted-app/mux-agent/src/lib.rs::MAX_PENDING",
      "runtime.reachability.reached.vibecrafted-app/mux-agent/src/lib.rs::MAX_QUEUE",
      "runtime.reachability.reached.vibecrafted-app/mux-agent/src/lib.rs::ManagedServer",
      "runtime.reachability.reached.vibecrafted-app/mux-agent/src/lib.rs::MultiServerStatus",
      "runtime.reachability.reached.vibecrafted-app/mux-agent/src/lib.rs::MuxState",
      "runtime.reachability.reached.vibecrafted-app/mux-agent/src/lib.rs::ResolvedParams",
      "runtime.reachability.reached.vibecrafted-app/mux-agent/src/lib.rs::ServerCommand",
      "runtime.reachability.reached.vibecrafted-app/mux-agent/src/lib.rs::ServerConfig",
      "runtime.reachability.reached.vibecrafted-app/mux-agent/src/lib.rs::ServerRef",
      "runtime.reachability.reached.vibecrafted-app/mux-agent/src/lib.rs::ServerStatus",
      "runtime.reachability.reached.vibecrafted-app/mux-agent/src/lib.rs::StatusLevel",
      "runtime.reachability.reached.vibecrafted-app/mux-agent/src/lib.rs::StatusSnapshot",
      "runtime.reachability.reached.vibecrafted-app/mux-agent/src/lib.rs::StatusState",
      "runtime.reachability.reached.vibecrafted-app/mux-agent/src/lib.rs::TuiMuxState",
      "runtime.reachability.reached.vibecrafted-app/mux-agent/src/lib.rs::format_uptime",
      "runtime.reachability.reached.vibecrafted-app/mux-agent/src/lib.rs::health_check",
      "runtime.reachability.reached.vibecrafted-app/mux-agent/src/lib.rs::is_running",
      "runtime.reachability.reached.vibecrafted-app/mux-agent/src/lib.rs::new",
      "runtime.reachability.reached.vibecrafted-app/mux-agent/src/lib.rs::print_status_table",
      "runtime.reachability.reached.vibecrafted-app/mux-agent/src/lib.rs::query_status",
      "runtime.reachability.reached.vibecrafted-app/mux-agent/src/lib.rs::resolve_params_multi",
      "runtime.reachability.reached.vibecrafted-app/mux-agent/src/lib.rs::run_multi_tui",
      "runtime.reachability.reached.vibecrafted-app/mux-agent/src/lib.rs::run_mux",
      "runtime.reachability.reached.vibecrafted-app/mux-agent/src/lib.rs::run_proxy",
      "runtime.reachability.reached.vibecrafted-app/mux-agent/src/lib.rs::run_status_listener",
      "runtime.reachability.reached.vibecrafted-app/mux-agent/src/lib.rs::service_name",
      "runtime.reachability.reached.vibecrafted-app/mux-agent/src/lib.rs::shutdown",
      "runtime.reachability.reached.vibecrafted-app/mux-agent/src/lib.rs::wait",
      "runtime.reachability.reached.vibecrafted-app/mux-agent/src/lib.rs::with_args",
      "runtime.reachability.reached.vibecrafted-app/mux-agent/src/lib.rs::with_env",
      "runtime.reachability.reached.vibecrafted-app/mux-agent/src/lib.rs::with_env_var",
      "runtime.reachability.reached.vibecrafted-app/mux-agent/src/lib.rs::with_heartbeat",
      "runtime.reachability.reached.vibecrafted-app/mux-agent/src/lib.rs::with_heartbeat_enabled",
      "runtime.reachability.reached.vibecrafted-app/mux-agent/src/lib.rs::with_heartbeat_max_failures",
      "runtime.reachability.reached.vibecrafted-app/mux-agent/src/lib.rs::with_lazy_start",
      "runtime.reachability.reached.vibecrafted-app/mux-agent/src/lib.rs::with_log_level",
      "runtime.reachability.reached.vibecrafted-app/mux-agent/src/lib.rs::with_max_clients",
      "runtime.reachability.reached.vibecrafted-app/mux-agent/src/lib.rs::with_max_request_bytes",
      "runtime.reachability.reached.vibecrafted-app/mux-agent/src/lib.rs::with_max_restarts",
      "runtime.reachability.reached.vibecrafted-app/mux-agent/src/lib.rs::with_request_timeout",
      "runtime.reachability.reached.vibecrafted-app/mux-agent/src/lib.rs::with_restart_backoff",
      "runtime.reachability.reached.vibecrafted-app/mux-agent/src/lib.rs::with_service_name",
      "runtime.reachability.reached.vibecrafted-app/mux-agent/src/lib.rs::with_status_file",
      "runtime.reachability.reached.vibecrafted-app/mux-agent/src/lib.rs::with_tray",
      "runtime.reachability.reached.vibecrafted-app/mux-agent/src/state.rs::buffer_message",
      "runtime.reachability.reached.vibecrafted-app/mux-agent/src/state.rs::complete_handshake",
      "runtime.reachability.reached.vibecrafted-app/mux-agent/src/state.rs::get_handshake_mut",
      "runtime.reachability.reached.vibecrafted-app/mux-agent/src/state.rs::is_handshake_complete",
      "runtime.reachability.reached.vibecrafted-app/mux-agent/src/state.rs::is_handshake_timed_out",
      "runtime.reachability.reached.vibecrafted-app/mux-agent/src/state.rs::mark_handshake_complete",
      "runtime.reachability.reached.vibecrafted-app/mux-agent/src/state.rs::new",
      "runtime.reachability.reached.vibecrafted-app/mux-agent/src/state.rs::next_request_id",
      "runtime.reachability.reached.vibecrafted-app/mux-agent/src/state.rs::register_client",
      "runtime.reachability.reached.vibecrafted-app/mux-agent/src/state.rs::unregister_client"
    ],
    "stale_or_unknown": []
  },
  "project": {
    "branch": "feat/sdk-preparation",
    "canonical_root": "/Users/maciejgad/vc-workspace/vetcoders/vibecrafted",
    "commit": "76ab7751",
    "snapshot_id": "feat_sdk-preparation@76ab7751"
  },
  "risk": {
    "cache_scope": "Clean",
    "cache_scope_authority": "repo_verified",
    "dirty_worktree": false,
    "high_fan_in": [
      {
        "authority": "loctree_derived",
        "file": "vibecrafted-app/mux-agent/src/state.rs",
        "importers": 12,
        "threshold": 10
      }
    ],
    "hotspots": [
      {
        "authority": "loctree_derived",
        "file": "vibecrafted-app/mux-agent/src/state.rs",
        "importers": 12
      },
      {
        "authority": "loctree_derived",
        "file": "vibecrafted-app/shell-agent/app/Vibecrafted/Bridge/vibecrafted_shell_ffi.swift",
        "importers": 4
      }
    ],
    "snapshot_health": "fresh",
    "stale_snapshot": false
  },
  "schema_version": "1.0"
}
```

## What this card does not cover

This Core Map does not include dependency consumers, runtime entrypoints, or prior decisions. For code changes, read `01-structural-map.md` next.
