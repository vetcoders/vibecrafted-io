# Structural Map

Project: `/Users/maciejgad/vc-workspace/vetcoders/vibecrafted`
Snapshot: `feat/sdk-preparation@76ab7751`
Freshness: `fresh - card matches the loaded snapshot authority.`

This card contains dependency and symbol topology for the selected scope.

```json
{
  "consumers": [
    {
      "authority": "repo_verified",
      "file": "vibecrafted-app/mux-agent/src/lib.rs",
      "import_kind": "reexport",
      "imports_used": [
        "MuxState",
        "ServerStatus",
        "StatusLevel",
        "StatusSnapshot",
        "state"
      ]
    },
    {
      "authority": "repo_verified",
      "file": "vibecrafted-app/mux-agent/src/main.rs",
      "import_kind": "direct",
      "imports_used": [
        "state"
      ]
    },
    {
      "authority": "repo_verified",
      "file": "vibecrafted-app/mux-agent/src/multi.rs",
      "import_kind": "direct",
      "imports_used": [
        "MuxState",
        "StatusLevel"
      ]
    },
    {
      "authority": "repo_verified",
      "file": "vibecrafted-app/mux-agent/src/multi_tui.rs",
      "import_kind": "direct",
      "imports_used": [
        "StatusLevel"
      ]
    },
    {
      "authority": "repo_verified",
      "file": "vibecrafted-app/mux-agent/src/runtime/client.rs",
      "import_kind": "direct",
      "imports_used": [
        "HANDSHAKE_TIMEOUT",
        "MAX_BUFFERED_HANDSHAKE_MESSAGES",
        "MuxState",
        "Pending",
        "StatusSnapshot",
        "error_response",
        "publish_status",
        "set_id"
      ]
    },
    {
      "authority": "repo_verified",
      "file": "vibecrafted-app/mux-agent/src/runtime/heartbeat.rs",
      "import_kind": "direct",
      "imports_used": [
        "HeartbeatMetrics",
        "MuxState",
        "StatusSnapshot",
        "publish_status"
      ]
    },
    {
      "authority": "repo_verified",
      "file": "vibecrafted-app/mux-agent/src/runtime/mod.rs",
      "import_kind": "direct",
      "imports_used": [
        "MuxState",
        "MuxStateConfig",
        "StatusSnapshot",
        "error_response",
        "publish_status",
        "snapshot_for_state"
      ]
    },
    {
      "authority": "repo_verified",
      "file": "vibecrafted-app/mux-agent/src/runtime/server.rs",
      "import_kind": "direct",
      "imports_used": [
        "MuxState",
        "ServerStatus",
        "StatusSnapshot",
        "publish_status",
        "set_id"
      ]
    },
    {
      "authority": "repo_verified",
      "file": "vibecrafted-app/mux-agent/src/runtime/status.rs",
      "import_kind": "direct",
      "imports_used": [
        "MuxState",
        "ServerStatus",
        "StatusLevel",
        "StatusSnapshot"
      ]
    },
    {
      "authority": "repo_verified",
      "file": "vibecrafted-app/mux-agent/src/runtime/tests.rs",
      "import_kind": "direct",
      "imports_used": [
        "MuxState",
        "MuxStateConfig",
        "Pending",
        "ServerStatus",
        "StatusSnapshot",
        "error_response",
        "publish_status",
        "reset_state",
        "set_id",
        "snapshot_for_state"
      ]
    },
    {
      "authority": "repo_verified",
      "file": "vibecrafted-app/mux-agent/src/tray.rs",
      "import_kind": "direct",
      "imports_used": [
        "ServerStatus",
        "StatusSnapshot"
      ]
    },
    {
      "authority": "repo_verified",
      "file": "vibecrafted-app/mux-agent/src/tray_dashboard.rs",
      "import_kind": "direct",
      "imports_used": [
        "StatusLevel"
      ]
    },
    {
      "authority": "repo_verified",
      "file": "vibecrafted-app/shell-agent/app/Vibecrafted/Views/CanvasViewController.swift",
      "import_kind": "direct",
      "imports_used": []
    },
    {
      "authority": "repo_verified",
      "file": "vibecrafted-app/shell-agent/app/Vibecrafted/Views/InspectorViewController.swift",
      "import_kind": "direct",
      "imports_used": []
    },
    {
      "authority": "repo_verified",
      "file": "vibecrafted-app/shell-agent/app/Vibecrafted/Views/MissionControlViewController.swift",
      "import_kind": "direct",
      "imports_used": []
    },
    {
      "authority": "repo_verified",
      "file": "vibecrafted-app/shell-agent/app/Vibecrafted/Views/SidebarViewController.swift",
      "import_kind": "direct",
      "imports_used": []
    }
  ],
  "entrypoints": [
    {
      "authority": "repo_verified",
      "kinds": [
        "script"
      ],
      "path": "scripts/vetcoders_install.py"
    },
    {
      "authority": "repo_verified",
      "kinds": [
        "main",
        "async_main"
      ],
      "path": "vibecrafted-app/mux-agent/src/main.rs"
    }
  ],
  "files": [
    {
      "authority": "repo_verified",
      "depth": 0,
      "language": "py",
      "loc": 516,
      "path": "plugins/iterm2/tests/test_iterm2_profiles.py",
      "role": "target"
    },
    {
      "authority": "repo_verified",
      "depth": 1,
      "language": "py",
      "loc": 5969,
      "path": "scripts/vetcoders_install.py",
      "role": "dependency"
    },
    {
      "authority": "repo_verified",
      "depth": 0,
      "language": "py",
      "loc": 2770,
      "path": "tests/tui/test_vibecrafted_launcher.py",
      "role": "target"
    },
    {
      "authority": "repo_verified",
      "depth": 1,
      "language": "rs",
      "loc": 520,
      "path": "vibecrafted-app/mux-agent/src/config.rs",
      "role": "dependency"
    },
    {
      "authority": "repo_verified",
      "depth": 1,
      "language": "rs",
      "loc": 878,
      "path": "vibecrafted-app/mux-agent/src/danger.rs",
      "role": "dependency"
    },
    {
      "authority": "repo_verified",
      "depth": 2,
      "language": "rs",
      "loc": 57,
      "path": "vibecrafted-app/mux-agent/src/ipc/command.rs",
      "role": "dependency"
    },
    {
      "authority": "repo_verified",
      "depth": 2,
      "language": "rs",
      "loc": 23,
      "path": "vibecrafted-app/mux-agent/src/ipc/context.rs",
      "role": "dependency"
    },
    {
      "authority": "repo_verified",
      "depth": 2,
      "language": "rs",
      "loc": 42,
      "path": "vibecrafted-app/mux-agent/src/ipc/event.rs",
      "role": "dependency"
    },
    {
      "authority": "repo_verified",
      "depth": 2,
      "language": "rs",
      "loc": 76,
      "path": "vibecrafted-app/mux-agent/src/ipc/handlers.rs",
      "role": "dependency"
    },
    {
      "authority": "repo_verified",
      "depth": 1,
      "language": "rs",
      "loc": 10,
      "path": "vibecrafted-app/mux-agent/src/ipc/mod.rs",
      "role": "dependency"
    },
    {
      "authority": "repo_verified",
      "depth": 2,
      "language": "rs",
      "loc": 290,
      "path": "vibecrafted-app/mux-agent/src/ipc/server.rs",
      "role": "dependency"
    },
    {
      "authority": "repo_verified",
      "depth": 1,
      "language": "rs",
      "loc": 208,
      "path": "vibecrafted-app/mux-agent/src/jsonl_bridge.rs",
      "role": "dependency"
    },
    {
      "authority": "repo_verified",
      "depth": 0,
      "language": "rs",
      "loc": 629,
      "path": "vibecrafted-app/mux-agent/src/lib.rs",
      "role": "target"
    },
    {
      "authority": "repo_verified",
      "depth": 1,
      "language": "rs",
      "loc": 187,
      "path": "vibecrafted-app/mux-agent/src/main.rs",
      "role": "consumer"
    },
    {
      "authority": "repo_verified",
      "depth": 1,
      "language": "rs",
      "loc": 126,
      "path": "vibecrafted-app/mux-agent/src/multi.rs",
      "role": "dependency"
    },
    {
      "authority": "repo_verified",
      "depth": 1,
      "language": "rs",
      "loc": 397,
      "path": "vibecrafted-app/mux-agent/src/multi_tui.rs",
      "role": "dependency"
    },
    {
      "authority": "repo_verified",
      "depth": 1,
      "language": "rs",
      "loc": 787,
      "path": "vibecrafted-app/mux-agent/src/mux_gen.rs",
      "role": "dependency"
    },
    {
      "authority": "repo_verified",
      "depth": 2,
      "language": "rs",
      "loc": 384,
      "path": "vibecrafted-app/mux-agent/src/runtime/client.rs",
      "role": "dependency"
    },
    {
      "authority": "repo_verified",
      "depth": 2,
      "language": "rs",
      "loc": 430,
      "path": "vibecrafted-app/mux-agent/src/runtime/heartbeat.rs",
      "role": "dependency"
    },
    {
      "authority": "repo_verified",
      "depth": 1,
      "language": "rs",
      "loc": 416,
      "path": "vibecrafted-app/mux-agent/src/runtime/mod.rs",
      "role": "dependency"
    },
    {
      "authority": "repo_verified",
      "depth": 2,
      "language": "rs",
      "loc": 101,
      "path": "vibecrafted-app/mux-agent/src/runtime/proxy.rs",
      "role": "dependency"
    },
    {
      "authority": "repo_verified",
      "depth": 2,
      "language": "rs",
      "loc": 350,
      "path": "vibecrafted-app/mux-agent/src/runtime/server.rs",
      "role": "dependency"
    },
    {
      "authority": "repo_verified",
      "depth": 2,
      "language": "rs",
      "loc": 363,
      "path": "vibecrafted-app/mux-agent/src/runtime/status.rs",
      "role": "dependency"
    },
    {
      "authority": "repo_verified",
      "depth": 1,
      "language": "rs",
      "loc": 1080,
      "path": "vibecrafted-app/mux-agent/src/runtime/tests.rs",
      "role": "consumer"
    },
    {
      "authority": "repo_verified",
      "depth": 2,
      "language": "rs",
      "loc": 15,
      "path": "vibecrafted-app/mux-agent/src/runtime/types.rs",
      "role": "dependency"
    },
    {
      "authority": "repo_verified",
      "depth": 1,
      "language": "rs",
      "loc": 1534,
      "path": "vibecrafted-app/mux-agent/src/scan.rs",
      "role": "dependency"
    },
    {
      "authority": "repo_verified",
      "depth": 1,
      "language": "rs",
      "loc": 398,
      "path": "vibecrafted-app/mux-agent/src/state.rs",
      "role": "dependency"
    },
    {
      "authority": "repo_verified",
      "depth": 1,
      "language": "rs",
      "loc": 338,
      "path": "vibecrafted-app/mux-agent/src/tray.rs",
      "role": "dependency"
    },
    {
      "authority": "repo_verified",
      "depth": 1,
      "language": "rs",
      "loc": 331,
      "path": "vibecrafted-app/mux-agent/src/tray_dashboard.rs",
      "role": "dependency"
    },
    {
      "authority": "repo_verified",
      "depth": 2,
      "language": "rs",
      "loc": 836,
      "path": "vibecrafted-app/mux-agent/src/wizard/keys.rs",
      "role": "dependency"
    },
    {
      "authority": "repo_verified",
      "depth": 1,
      "language": "rs",
      "loc": 389,
      "path": "vibecrafted-app/mux-agent/src/wizard/mod.rs",
      "role": "dependency"
    },
    {
      "authority": "repo_verified",
      "depth": 2,
      "language": "rs",
      "loc": 697,
      "path": "vibecrafted-app/mux-agent/src/wizard/persist.rs",
      "role": "dependency"
    },
    {
      "authority": "repo_verified",
      "depth": 2,
      "language": "rs",
      "loc": 504,
      "path": "vibecrafted-app/mux-agent/src/wizard/services.rs",
      "role": "dependency"
    },
    {
      "authority": "repo_verified",
      "depth": 2,
      "language": "rs",
      "loc": 227,
      "path": "vibecrafted-app/mux-agent/src/wizard/types.rs",
      "role": "dependency"
    },
    {
      "authority": "repo_verified",
      "depth": 2,
      "language": "rs",
      "loc": 801,
      "path": "vibecrafted-app/mux-agent/src/wizard/ui.rs",
      "role": "dependency"
    },
    {
      "authority": "repo_verified",
      "depth": 0,
      "language": "swift",
      "loc": 2784,
      "path": "vibecrafted-app/shell-agent/app/Vibecrafted/Bridge/vibecrafted_shell_ffi.swift",
      "role": "target"
    },
    {
      "authority": "repo_verified",
      "depth": 1,
      "language": "swift",
      "loc": 209,
      "path": "vibecrafted-app/shell-agent/app/Vibecrafted/Views/CanvasViewController.swift",
      "role": "consumer"
    },
    {
      "authority": "repo_verified",
      "depth": 1,
      "language": "swift",
      "loc": 354,
      "path": "vibecrafted-app/shell-agent/app/Vibecrafted/Views/InspectorViewController.swift",
      "role": "consumer"
    },
    {
      "authority": "repo_verified",
      "depth": 1,
      "language": "swift",
      "loc": 637,
      "path": "vibecrafted-app/shell-agent/app/Vibecrafted/Views/MissionControlViewController.swift",
      "role": "consumer"
    },
    {
      "authority": "repo_verified",
      "depth": 1,
      "language": "swift",
      "loc": 191,
      "path": "vibecrafted-app/shell-agent/app/Vibecrafted/Views/SidebarViewController.swift",
      "role": "consumer"
    }
  ],
  "imports": [
    {
      "authority": "repo_verified",
      "file": "plugins/iterm2/tests/test_iterm2_profiles.py",
      "is_bare": true,
      "kind": "static",
      "line": 3,
      "resolution": "unknown",
      "resolved_path": null,
      "source": "__future__",
      "source_raw": "from __future__ import annotations",
      "symbols": [
        "annotations"
      ]
    },
    {
      "authority": "repo_verified",
      "file": "plugins/iterm2/tests/test_iterm2_profiles.py",
      "is_bare": true,
      "kind": "static",
      "line": 8,
      "resolution": "stdlib",
      "resolved_path": null,
      "source": "pathlib",
      "source_raw": "from pathlib import Path",
      "symbols": [
        "Path"
      ]
    },
    {
      "authority": "repo_verified",
      "file": "plugins/iterm2/tests/test_iterm2_profiles.py",
      "is_bare": true,
      "kind": "static",
      "line": 12,
      "resolution": "unknown",
      "resolved_path": null,
      "source": "vibecrafted_iterm2",
      "source_raw": "from vibecrafted_iterm2 import iterm2_profiles as profiles",
      "symbols": [
        "profiles"
      ]
    },
    {
      "authority": "repo_verified",
      "file": "plugins/iterm2/tests/test_iterm2_profiles.py",
      "is_bare": true,
      "kind": "static",
      "line": 5,
      "resolution": "stdlib",
      "resolved_path": null,
      "source": "json",
      "source_raw": "json",
      "symbols": []
    },
    {
      "authority": "repo_verified",
      "file": "plugins/iterm2/tests/test_iterm2_profiles.py",
      "is_bare": true,
      "kind": "static",
      "line": 10,
      "resolution": "unknown",
      "resolved_path": null,
      "source": "pytest",
      "source_raw": "pytest",
      "symbols": []
    },
    {
      "authority": "repo_verified",
      "file": "plugins/iterm2/tests/test_iterm2_profiles.py",
      "is_bare": true,
      "kind": "static",
      "line": 6,
      "resolution": "stdlib",
      "resolved_path": null,
      "source": "subprocess",
      "source_raw": "subprocess",
      "symbols": []
    },
    {
      "authority": "repo_verified",
      "file": "plugins/iterm2/tests/test_iterm2_profiles.py",
      "is_bare": true,
      "kind": "static",
      "line": 7,
      "resolution": "stdlib",
      "resolved_path": null,
      "source": "sys",
      "source_raw": "sys",
      "symbols": []
    },
    {
      "authority": "repo_verified",
      "file": "tests/tui/test_vibecrafted_launcher.py",
      "is_bare": true,
      "kind": "static",
      "line": 1,
      "resolution": "unknown",
      "resolved_path": null,
      "source": "__future__",
      "source_raw": "from __future__ import annotations",
      "symbols": [
        "annotations"
      ]
    },
    {
      "authority": "repo_verified",
      "file": "tests/tui/test_vibecrafted_launcher.py",
      "is_bare": true,
      "kind": "static",
      "line": 9,
      "resolution": "stdlib",
      "resolved_path": null,
      "source": "pathlib",
      "source_raw": "from pathlib import Path",
      "symbols": [
        "Path"
      ]
    },
    {
      "authority": "repo_verified",
      "file": "tests/tui/test_vibecrafted_launcher.py",
      "is_bare": true,
      "kind": "static",
      "line": 3,
      "resolution": "stdlib",
      "resolved_path": null,
      "source": "hashlib",
      "source_raw": "hashlib",
      "symbols": []
    },
    {
      "authority": "repo_verified",
      "file": "tests/tui/test_vibecrafted_launcher.py",
      "is_bare": true,
      "kind": "static",
      "line": 4,
      "resolution": "stdlib",
      "resolved_path": null,
      "source": "json",
      "source_raw": "json",
      "symbols": []
    },
    {
      "authority": "repo_verified",
      "file": "tests/tui/test_vibecrafted_launcher.py",
      "is_bare": true,
      "kind": "static",
      "line": 5,
      "resolution": "stdlib",
      "resolved_path": null,
      "source": "os",
      "source_raw": "os",
      "symbols": []
    },
    {
      "authority": "repo_verified",
      "file": "tests/tui/test_vibecrafted_launcher.py",
      "is_bare": true,
      "kind": "static",
      "line": 11,
      "resolution": "unknown",
      "resolved_path": null,
      "source": "pytest",
      "source_raw": "pytest",
      "symbols": []
    },
    {
      "authority": "repo_verified",
      "file": "tests/tui/test_vibecrafted_launcher.py",
      "is_bare": true,
      "kind": "static",
      "line": 6,
      "resolution": "stdlib",
      "resolved_path": null,
      "source": "re",
      "source_raw": "re",
      "symbols": []
    },
    {
      "authority": "repo_verified",
      "file": "tests/tui/test_vibecrafted_launcher.py",
      "is_bare": true,
      "kind": "static",
      "line": 7,
      "resolution": "stdlib",
      "resolved_path": null,
      "source": "subprocess",
      "source_raw": "subprocess",
      "symbols": []
    },
    {
      "authority": "repo_verified",
      "file": "tests/tui/test_vibecrafted_launcher.py",
      "is_bare": true,
      "kind": "static",
      "line": 8,
      "resolution": "stdlib",
      "resolved_path": null,
      "source": "sys",
      "source_raw": "sys",
      "symbols": []
    },
    {
      "authority": "repo_verified",
      "file": "vibecrafted-app/mux-agent/src/lib.rs",
      "is_bare": true,
      "kind": "static",
      "line": 54,
      "resolution": "unknown",
      "resolved_path": null,
      "source": "anyhow::Result",
      "source_raw": "anyhow::Result",
      "symbols": [
        "Result"
      ]
    },
    {
      "authority": "repo_verified",
      "file": "vibecrafted-app/mux-agent/src/lib.rs",
      "is_bare": true,
      "kind": "static",
      "line": 581,
      "resolution": "unknown",
      "resolved_path": null,
      "source": "anyhow::anyhow",
      "source_raw": "anyhow::anyhow",
      "symbols": [
        "anyhow"
      ]
    },
    {
      "authority": "repo_verified",
      "file": "vibecrafted-app/mux-agent/src/lib.rs",
      "is_bare": true,
      "kind": "static",
      "line": 545,
      "resolution": "unknown",
      "resolved_path": "vibecrafted-app/mux-agent/src/config.rs",
      "source": "config::expand_path",
      "source_raw": "config::expand_path",
      "symbols": [
        "expand_path"
      ]
    },
    {
      "authority": "repo_verified",
      "file": "vibecrafted-app/mux-agent/src/lib.rs",
      "is_bare": true,
      "kind": "static",
      "line": 91,
      "resolution": "unknown",
      "resolved_path": null,
      "source": "config",
      "source_raw": "config::{CliOptions, Config, ResolvedParams, ServerConfig, resolve_params_multi}",
      "symbols": [
        "CliOptions",
        "Config",
        "ResolvedParams",
        "ServerConfig",
        "resolve_params_multi"
      ]
    },
    {
      "authority": "repo_verified",
      "file": "vibecrafted-app/mux-agent/src/lib.rs",
      "is_bare": true,
      "kind": "static",
      "line": 492,
      "resolution": "unknown",
      "resolved_path": null,
      "source": "futures::future::join_all",
      "source_raw": "futures::future::join_all",
      "symbols": [
        "join_all"
      ]
    },
    {
      "authority": "repo_verified",
      "file": "vibecrafted-app/mux-agent/src/lib.rs",
      "is_bare": true,
      "kind": "static",
      "line": null,
      "resolution": "unknown",
      "resolved_path": "vibecrafted-app/mux-agent/src/config.rs",
      "source": "mod::config",
      "source_raw": "mod::config",
      "symbols": [
        "config"
      ]
    },
    {
      "authority": "repo_verified",
      "file": "vibecrafted-app/mux-agent/src/lib.rs",
      "is_bare": true,
      "kind": "static",
      "line": null,
      "resolution": "unknown",
      "resolved_path": "vibecrafted-app/mux-agent/src/danger.rs",
      "source": "mod::danger",
      "source_raw": "mod::danger",
      "symbols": [
        "danger"
      ]
    },
    {
      "authority": "repo_verified",
      "file": "vibecrafted-app/mux-agent/src/lib.rs",
      "is_bare": true,
      "kind": "static",
      "line": null,
      "resolution": "unknown",
      "resolved_path": "vibecrafted-app/mux-agent/src/ipc/mod.rs",
      "source": "mod::ipc",
      "source_raw": "mod::ipc",
      "symbols": [
        "ipc"
      ]
    },
    {
      "authority": "repo_verified",
      "file": "vibecrafted-app/mux-agent/src/lib.rs",
      "is_bare": true,
      "kind": "static",
      "line": null,
      "resolution": "unknown",
      "resolved_path": "vibecrafted-app/mux-agent/src/jsonl_bridge.rs",
      "source": "mod::jsonl_bridge",
      "source_raw": "mod::jsonl_bridge",
      "symbols": [
        "jsonl_bridge"
      ]
    },
    {
      "authority": "repo_verified",
      "file": "vibecrafted-app/mux-agent/src/lib.rs",
      "is_bare": true,
      "kind": "static",
      "line": null,
      "resolution": "unknown",
      "resolved_path": "vibecrafted-app/mux-agent/src/multi.rs",
      "source": "mod::multi",
      "source_raw": "mod::multi",
      "symbols": [
        "multi"
      ]
    },
    {
      "authority": "repo_verified",
      "file": "vibecrafted-app/mux-agent/src/lib.rs",
      "is_bare": true,
      "kind": "static",
      "line": null,
      "resolution": "unknown",
      "resolved_path": "vibecrafted-app/mux-agent/src/multi_tui.rs",
      "source": "mod::multi_tui",
      "source_raw": "mod::multi_tui",
      "symbols": [
        "multi_tui"
      ]
    },
    {
      "authority": "repo_verified",
      "file": "vibecrafted-app/mux-agent/src/lib.rs",
      "is_bare": true,
      "kind": "static",
      "line": null,
      "resolution": "unknown",
      "resolved_path": "vibecrafted-app/mux-agent/src/mux_gen.rs",
      "source": "mod::mux_gen",
      "source_raw": "mod::mux_gen",
      "symbols": [
        "mux_gen"
      ]
    },
    {
      "authority": "repo_verified",
      "file": "vibecrafted-app/mux-agent/src/lib.rs",
      "is_bare": true,
      "kind": "static",
      "line": null,
      "resolution": "unknown",
      "resolved_path": "vibecrafted-app/mux-agent/src/runtime/mod.rs",
      "source": "mod::runtime",
      "source_raw": "mod::runtime",
      "symbols": [
        "runtime"
      ]
    },
    {
      "authority": "repo_verified",
      "file": "vibecrafted-app/mux-agent/src/lib.rs",
      "is_bare": true,
      "kind": "static",
      "line": null,
      "resolution": "unknown",
      "resolved_path": "vibecrafted-app/mux-agent/src/scan.rs",
      "source": "mod::scan",
      "source_raw": "mod::scan",
      "symbols": [
        "scan"
      ]
    },
    {
      "authority": "repo_verified",
      "file": "vibecrafted-app/mux-agent/src/lib.rs",
      "is_bare": true,
      "kind": "static",
      "line": null,
      "resolution": "unknown",
      "resolved_path": "vibecrafted-app/mux-agent/src/state.rs",
      "source": "mod::state",
      "source_raw": "mod::state",
      "symbols": [
        "state"
      ]
    },
    {
      "authority": "repo_verified",
      "file": "vibecrafted-app/mux-agent/src/lib.rs",
      "is_bare": true,
      "kind": "static",
      "line": null,
      "resolution": "unknown",
      "resolved_path": "vibecrafted-app/mux-agent/src/tray.rs",
      "source": "mod::tray",
      "source_raw": "mod::tray",
      "symbols": [
        "tray"
      ]
    },
    {
      "authority": "repo_verified",
      "file": "vibecrafted-app/mux-agent/src/lib.rs",
      "is_bare": true,
      "kind": "static",
      "line": null,
      "resolution": "unknown",
      "resolved_path": "vibecrafted-app/mux-agent/src/tray_dashboard.rs",
      "source": "mod::tray_dashboard",
      "source_raw": "mod::tray_dashboard",
      "symbols": [
        "tray_dashboard"
      ]
    },
    {
      "authority": "repo_verified",
      "file": "vibecrafted-app/mux-agent/src/lib.rs",
      "is_bare": true,
      "kind": "static",
      "line": null,
      "resolution": "unknown",
      "resolved_path": "vibecrafted-app/mux-agent/src/wizard/mod.rs",
      "source": "mod::wizard",
      "source_raw": "mod::wizard",
      "symbols": [
        "wizard"
      ]
    },
    {
      "authority": "repo_verified",
      "file": "vibecrafted-app/mux-agent/src/lib.rs",
      "is_bare": true,
      "kind": "static",
      "line": 99,
      "resolution": "unknown",
      "resolved_path": null,
      "source": "multi",
      "source_raw": "multi::{ManagedServer, MultiServerStatus, ServerCommand, TuiMuxState, format_uptime}",
      "symbols": [
        "ManagedServer",
        "MultiServerStatus",
        "ServerCommand",
        "TuiMuxState",
        "format_uptime"
      ]
    },
    {
      "authority": "repo_verified",
      "file": "vibecrafted-app/mux-agent/src/lib.rs",
      "is_bare": true,
      "kind": "static",
      "line": 102,
      "resolution": "unknown",
      "resolved_path": "vibecrafted-app/mux-agent/src/multi_tui.rs",
      "source": "multi_tui::run_multi_tui",
      "source_raw": "multi_tui::run_multi_tui",
      "symbols": [
        "run_multi_tui"
      ]
    },
    {
      "authority": "repo_verified",
      "file": "vibecrafted-app/mux-agent/src/lib.rs",
      "is_bare": true,
      "kind": "static",
      "line": 93,
      "resolution": "unknown",
      "resolved_path": null,
      "source": "runtime",
// truncated: 3938 more line(s); read the complete payload at `01-structural-map.full.json` (sibling of this card), or run `loct context --full --json` for the whole pack

```

## What this card does not cover

This Structural Map does not include runtime behavior, env contracts, or verification gates. Read `02-runtime-map.md` and `04-verification-gates.md` before changing behavior.
