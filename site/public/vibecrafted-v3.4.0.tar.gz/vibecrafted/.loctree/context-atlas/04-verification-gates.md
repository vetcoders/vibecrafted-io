# Verification Gates

Project: `/Users/maciejgad/vc-workspace/vetcoders/vibecrafted`
Snapshot: `feat/sdk-preparation@76ab7751`
Freshness: `fresh - card matches the loaded snapshot authority.`

This card lists likely verification commands and tests derived from the current context.

```json
{
  "likely_tests": [
    "plugins/iterm2/tests/test_iterm2_profiles.py",
    "tests/agent_dispatch_test.py",
    "tests/tui/test_default_runtime.py",
    "tests/tui/test_vibecrafted_launcher.py",
    "vibecrafted-app/tui-agent/tests/state_contract.rs",
    "vibecrafted-core/tests/dispatch/test_cli.py",
    "vibecrafted-core/tests/dispatch/test_supervisor.py",
    "vibecrafted-core/tests/test_agy_junie_pipeline.py",
    "vibecrafted-core/tests/test_aicx_sync.py",
    "vibecrafted-core/tests/test_capabilities.py"
  ],
  "next_safe_commands": [
    "loct find test_init_claude_uses_interactive_tab_without_print_mode",
    "loct find CliOptions",
    "loct find test_hex_to_iterm2_six_digit"
  ],
  "risk": {
    "cache_scope": "Clean",
    "cache_scope_authority": "repo_verified",
    "dirty_worktree": false,
    "high_fan_in": [
      {
        "authority": "loctree_derived",
        "file": "vibecrafted-app/mux-agent/src/state.rs",
        "importers": 12,
        "threshold": 10
      }
    ],
    "hotspots": [
      {
        "authority": "loctree_derived",
        "file": "vibecrafted-app/mux-agent/src/state.rs",
        "importers": 12
      },
      {
        "authority": "loctree_derived",
        "file": "vibecrafted-app/shell-agent/app/Vibecrafted/Bridge/vibecrafted_shell_ffi.swift",
        "importers": 4
      }
    ],
    "snapshot_health": "fresh",
    "stale_snapshot": false
  }
}
```

## What this card does not cover

This Verification Gates card does not prove correctness by itself. Run the commands before release or submit.
