# Runtime Map

Project: `/Users/maciejgad/vc-workspace/vetcoders/vibecrafted`
Snapshot: `feat/sdk-preparation@76ab7751`
Freshness: `fresh - card matches the loaded snapshot authority.`

This card contains runtime signals derived from semantic facts and framework bridges.

```json
{
  "dispatch_edges": [
    {
      "authority": "loctree_derived",
      "dispatch_kind": "event_handler",
      "from_file": "tests/tui/test_vibecrafted_launcher.py",
      "from_line": 1236,
      "handler_file": "tests/tui/test_vibecrafted_launcher.py",
      "handler_symbol": "test_autonomous_delivery_skills_route_to_core_async_launcher"
    }
  ],
  "env_contracts": [
    {
      "authority": "loctree_derived",
      "name": "CAPTURE_FILE",
      "occurrences": [
        {
          "access_kind": "os.environ[]",
          "file": "tests/tui/test_atuin_fallback.py",
          "line": 22,
          "required": true
        },
        {
          "access_kind": "os.environ[]",
          "file": "tests/tui/test_operator_mode.py",
          "line": 49,
          "required": true
        },
        {
          "access_kind": "os.environ[]",
          "file": "tests/tui/test_operator_mode.py",
          "line": 118,
          "required": true
        },
        {
          "access_kind": "os.environ[]",
          "file": "tests/tui/test_vibecrafted_launcher.py",
          "line": 117,
          "required": true
        },
        {
          "access_kind": "os.environ[]",
          "file": "tests/tui/test_vibecrafted_launcher.py",
          "line": 274,
          "required": true
        },
        {
          "access_kind": "os.environ[]",
          "file": "tests/tui/test_vibecrafted_launcher.py",
          "line": 329,
          "required": true
        }
      ],
      "required": true,
      "required_for": [],
      "used_in_files": [
        "tests/tui/test_atuin_fallback.py",
        "tests/tui/test_operator_mode.py",
        "tests/tui/test_vibecrafted_launcher.py"
      ]
    },
    {
      "authority": "loctree_derived",
      "name": "CURL_CAPTURE_FILE",
      "occurrences": [
        {
          "access_kind": "os.environ.get",
          "file": "tests/tui/test_vibecrafted_launcher.py",
          "line": 181,
          "required": true
        }
      ],
      "required": true,
      "required_for": [],
      "used_in_files": [
        "tests/tui/test_vibecrafted_launcher.py"
      ]
    },
    {
      "authority": "loctree_derived",
      "name": "FAKE_CURL_ROUTES",
      "occurrences": [
        {
          "access_kind": "os.environ.get",
          "default": "'{}'",
          "file": "tests/tui/test_vibecrafted_launcher.py",
          "line": 180,
          "required": false
        }
      ],
      "required": false,
      "required_for": [],
      "used_in_files": [
        "tests/tui/test_vibecrafted_launcher.py"
      ]
    },
    {
      "authority": "loctree_derived",
      "name": "FAKE_VC_FRAME_LISTING",
      "occurrences": [
        {
          "access_kind": "os.environ.get",
          "default": "\"\"",
          "file": "tests/tui/test_vibecrafted_launcher.py",
          "line": 118,
          "required": false
        }
      ],
      "required": false,
      "required_for": [],
      "used_in_files": [
        "tests/tui/test_vibecrafted_launcher.py"
      ]
    },
    {
      "authority": "loctree_derived",
      "name": "FAKE_VC_FRAME_SESSION",
      "occurrences": [
        {
          "access_kind": "os.environ.get",
          "default": "\"{default_session}\"",
          "file": "tests/tui/test_operator_mode.py",
          "line": 52,
          "required": false
        },
        {
          "access_kind": "os.environ.get",
          "default": "\"{default_session}\"",
          "file": "tests/tui/test_vibecrafted_launcher.py",
          "line": 277,
          "required": false
        }
      ],
      "required": false,
      "required_for": [],
      "used_in_files": [
        "tests/tui/test_operator_mode.py",
        "tests/tui/test_vibecrafted_launcher.py"
      ]
    },
    {
      "authority": "loctree_derived",
      "name": "SESSION_STATE_FILE",
      "occurrences": [
        {
          "access_kind": "os.environ[]",
          "file": "tests/tui/test_operator_mode.py",
          "line": 50,
          "required": true
        },
        {
          "access_kind": "os.environ[]",
          "file": "tests/tui/test_operator_mode.py",
          "line": 119,
          "required": true
        },
        {
          "access_kind": "os.environ[]",
          "file": "tests/tui/test_vibecrafted_launcher.py",
          "line": 275,
          "required": true
        },
        {
          "access_kind": "os.environ[]",
          "file": "tests/tui/test_vibecrafted_launcher.py",
          "line": 330,
          "required": true
        }
      ],
      "required": true,
      "required_for": [],
      "used_in_files": [
        "tests/tui/test_operator_mode.py",
        "tests/tui/test_vibecrafted_launcher.py"
      ]
    }
  ],
  "framework_hints": [
    {
      "authority": "loctree_derived",
      "detail": "Re-exported via `pub use`; reached through downstream importers.",
      "file": "vibecrafted-app/mux-agent/src/lib.rs",
      "kind": "rust:pub_use_reexport",
      "line": null,
      "symbol": "vibecrafted-app/mux-agent/src/lib.rs::CliOptions"
    },
    {
      "authority": "loctree_derived",
      "detail": "Re-exported via `pub use`; reached through downstream importers.",
      "file": "vibecrafted-app/mux-agent/src/lib.rs",
      "kind": "rust:pub_use_reexport",
      "line": null,
      "symbol": "vibecrafted-app/mux-agent/src/lib.rs::Config"
    },
    {
      "authority": "loctree_derived",
      "detail": "Re-exported via `pub use`; reached through downstream importers.",
      "file": "vibecrafted-app/mux-agent/src/lib.rs",
      "kind": "rust:pub_use_reexport",
      "line": null,
      "symbol": "vibecrafted-app/mux-agent/src/lib.rs::DEFAULT_STATUS_SOCKET"
    },
    {
      "authority": "loctree_derived",
      "detail": "Re-exported via `pub use`; reached through downstream importers.",
      "file": "vibecrafted-app/mux-agent/src/lib.rs",
      "kind": "rust:pub_use_reexport",
      "line": null,
      "symbol": "vibecrafted-app/mux-agent/src/lib.rs::DaemonStatus"
    },
    {
      "authority": "loctree_derived",
      "detail": "Re-exported via `pub use`; reached through downstream importers.",
      "file": "vibecrafted-app/mux-agent/src/lib.rs",
      "kind": "rust:pub_use_reexport",
      "line": null,
      "symbol": "vibecrafted-app/mux-agent/src/lib.rs::HeartbeatConfig"
    },
    {
      "authority": "loctree_derived",
      "detail": "Re-exported via `pub use`; reached through downstream importers.",
      "file": "vibecrafted-app/mux-agent/src/lib.rs",
      "kind": "rust:pub_use_reexport",
      "line": null,
      "symbol": "vibecrafted-app/mux-agent/src/lib.rs::MAX_PENDING"
    },
    {
      "authority": "loctree_derived",
      "detail": "Re-exported via `pub use`; reached through downstream importers.",
      "file": "vibecrafted-app/mux-agent/src/lib.rs",
      "kind": "rust:pub_use_reexport",
      "line": null,
      "symbol": "vibecrafted-app/mux-agent/src/lib.rs::MAX_QUEUE"
    },
    {
      "authority": "loctree_derived",
      "detail": "Re-exported via `pub use`; reached through downstream importers.",
      "file": "vibecrafted-app/mux-agent/src/lib.rs",
      "kind": "rust:pub_use_reexport",
      "line": null,
      "symbol": "vibecrafted-app/mux-agent/src/lib.rs::ManagedServer"
    },
    {
      "authority": "loctree_derived",
      "detail": "Re-exported via `pub use`; reached through downstream importers.",
      "file": "vibecrafted-app/mux-agent/src/lib.rs",
      "kind": "rust:pub_use_reexport",
      "line": null,
      "symbol": "vibecrafted-app/mux-agent/src/lib.rs::MultiServerStatus"
    },
    {
      "authority": "loctree_derived",
      "detail": "Re-exported via `pub use`; reached through downstream importers.",
      "file": "vibecrafted-app/mux-agent/src/lib.rs",
      "kind": "rust:pub_use_reexport",
      "line": null,
      "symbol": "vibecrafted-app/mux-agent/src/lib.rs::MuxState"
    },
    {
      "authority": "loctree_derived",
      "detail": "Re-exported via `pub use`; reached through downstream importers.",
      "file": "vibecrafted-app/mux-agent/src/lib.rs",
      "kind": "rust:pub_use_reexport",
      "line": null,
      "symbol": "vibecrafted-app/mux-agent/src/lib.rs::ResolvedParams"
    },
    {
      "authority": "loctree_derived",
      "detail": "Re-exported via `pub use`; reached through downstream importers.",
      "file": "vibecrafted-app/mux-agent/src/lib.rs",
      "kind": "rust:pub_use_reexport",
      "line": null,
      "symbol": "vibecrafted-app/mux-agent/src/lib.rs::ServerCommand"
    },
    {
      "authority": "loctree_derived",
      "detail": "Re-exported via `pub use`; reached through downstream importers.",
      "file": "vibecrafted-app/mux-agent/src/lib.rs",
      "kind": "rust:pub_use_reexport",
      "line": null,
      "symbol": "vibecrafted-app/mux-agent/src/lib.rs::ServerConfig"
    },
    {
      "authority": "loctree_derived",
      "detail": "Re-exported via `pub use`; reached through downstream importers.",
      "file": "vibecrafted-app/mux-agent/src/lib.rs",
      "kind": "rust:pub_use_reexport",
      "line": null,
      "symbol": "vibecrafted-app/mux-agent/src/lib.rs::ServerRef"
    },
    {
      "authority": "loctree_derived",
      "detail": "Re-exported via `pub use`; reached through downstream importers.",
      "file": "vibecrafted-app/mux-agent/src/lib.rs",
      "kind": "rust:pub_use_reexport",
      "line": null,
      "symbol": "vibecrafted-app/mux-agent/src/lib.rs::ServerStatus"
    },
    {
      "authority": "loctree_derived",
      "detail": "Re-exported via `pub use`; reached through downstream importers.",
      "file": "vibecrafted-app/mux-agent/src/lib.rs",
      "kind": "rust:pub_use_reexport",
      "line": null,
      "symbol": "vibecrafted-app/mux-agent/src/lib.rs::StatusLevel"
    },
    {
      "authority": "loctree_derived",
      "detail": "Re-exported via `pub use`; reached through downstream importers.",
      "file": "vibecrafted-app/mux-agent/src/lib.rs",
      "kind": "rust:pub_use_reexport",
      "line": null,
      "symbol": "vibecrafted-app/mux-agent/src/lib.rs::StatusSnapshot"
    },
    {
      "authority": "loctree_derived",
      "detail": "Re-exported via `pub use`; reached through downstream importers.",
      "file": "vibecrafted-app/mux-agent/src/lib.rs",
      "kind": "rust:pub_use_reexport",
      "line": null,
      "symbol": "vibecrafted-app/mux-agent/src/lib.rs::StatusState"
    },
    {
      "authority": "loctree_derived",
      "detail": "Re-exported via `pub use`; reached through downstream importers.",
      "file": "vibecrafted-app/mux-agent/src/lib.rs",
      "kind": "rust:pub_use_reexport",
      "line": null,
      "symbol": "vibecrafted-app/mux-agent/src/lib.rs::TuiMuxState"
    },
    {
      "authority": "loctree_derived",
      "detail": "Re-exported via `pub use`; reached through downstream importers.",
      "file": "vibecrafted-app/mux-agent/src/lib.rs",
      "kind": "rust:pub_use_reexport",
      "line": null,
      "symbol": "vibecrafted-app/mux-agent/src/lib.rs::format_uptime"
    },
    {
      "authority": "loctree_derived",
      "detail": "Re-exported via `pub use`; reached through downstream importers.",
      "file": "vibecrafted-app/mux-agent/src/lib.rs",
      "kind": "rust:pub_use_reexport",
      "line": null,
      "symbol": "vibecrafted-app/mux-agent/src/lib.rs::health_check"
    },
    {
      "authority": "loctree_derived",
      "detail": "Defined inside inherent `impl MuxHandle` block; reached via method-call syntax.",
      "file": "vibecrafted-app/mux-agent/src/lib.rs",
      "kind": "rust:inherent_impl_method",
      "line": null,
      "symbol": "vibecrafted-app/mux-agent/src/lib.rs::is_running"
    },
    {
      "authority": "loctree_derived",
      "detail": "Defined inside inherent `impl MuxConfig` block; reached via method-call syntax.",
      "file": "vibecrafted-app/mux-agent/src/lib.rs",
      "kind": "rust:inherent_impl_method",
      "line": null,
      "symbol": "vibecrafted-app/mux-agent/src/lib.rs::new"
    },
    {
      "authority": "loctree_derived",
      "detail": "Re-exported via `pub use`; reached through downstream importers.",
      "file": "vibecrafted-app/mux-agent/src/lib.rs",
      "kind": "rust:pub_use_reexport",
      "line": null,
      "symbol": "vibecrafted-app/mux-agent/src/lib.rs::print_status_table"
    },
    {
      "authority": "loctree_derived",
      "detail": "Re-exported via `pub use`; reached through downstream importers.",
      "file": "vibecrafted-app/mux-agent/src/lib.rs",
      "kind": "rust:pub_use_reexport",
      "line": null,
      "symbol": "vibecrafted-app/mux-agent/src/lib.rs::query_status"
    },
    {
      "authority": "loctree_derived",
      "detail": "Re-exported via `pub use`; reached through downstream importers.",
      "file": "vibecrafted-app/mux-agent/src/lib.rs",
      "kind": "rust:pub_use_reexport",
      "line": null,
      "symbol": "vibecrafted-app/mux-agent/src/lib.rs::resolve_params_multi"
    },
    {
      "authority": "loctree_derived",
      "detail": "Re-exported via `pub use`; reached through downstream importers.",
      "file": "vibecrafted-app/mux-agent/src/lib.rs",
      "kind": "rust:pub_use_reexport",
      "line": null,
      "symbol": "vibecrafted-app/mux-agent/src/lib.rs::run_multi_tui"
    },
    {
      "authority": "loctree_derived",
      "detail": "Re-exported via `pub use`; reached through downstream importers.",
      "file": "vibecrafted-app/mux-agent/src/lib.rs",
      "kind": "rust:pub_use_reexport",
      "line": null,
      "symbol": "vibecrafted-app/mux-agent/src/lib.rs::run_mux"
    },
    {
      "authority": "loctree_derived",
      "detail": "Re-exported via `pub use`; reached through downstream importers.",
      "file": "vibecrafted-app/mux-agent/src/lib.rs",
      "kind": "rust:pub_use_reexport",
      "line": null,
      "symbol": "vibecrafted-app/mux-agent/src/lib.rs::run_proxy"
    },
    {
      "authority": "loctree_derived",
      "detail": "Re-exported via `pub use`; reached through downstream importers.",
      "file": "vibecrafted-app/mux-agent/src/lib.rs",
      "kind": "rust:pub_use_reexport",
      "line": null,
      "symbol": "vibecrafted-app/mux-agent/src/lib.rs::run_status_listener"
    },
    {
      "authority": "loctree_derived",
      "detail": "Defined inside inherent `impl MuxConfig` block; reached via method-call syntax.",
      "file": "vibecrafted-app/mux-agent/src/lib.rs",
      "kind": "rust:inherent_impl_method",
      "line": null,
      "symbol": "vibecrafted-app/mux-agent/src/lib.rs::service_name"
    },
    {
      "authority": "loctree_derived",
      "detail": "Defined inside inherent `impl MuxHandle` block; reached via method-call syntax.",
      "file": "vibecrafted-app/mux-agent/src/lib.rs",
      "kind": "rust:inherent_impl_method",
      "line": null,
      "symbol": "vibecrafted-app/mux-agent/src/lib.rs::shutdown"
    },
    {
      "authority": "loctree_derived",
      "detail": "Defined inside inherent `impl MuxHandle` block; reached via method-call syntax.",
      "file": "vibecrafted-app/mux-agent/src/lib.rs",
      "kind": "rust:inherent_impl_method",
      "line": null,
      "symbol": "vibecrafted-app/mux-agent/src/lib.rs::wait"
    },
    {
      "authority": "loctree_derived",
      "detail": "Defined inside inherent `impl MuxConfig` block; reached via method-call syntax.",
      "file": "vibecrafted-app/mux-agent/src/lib.rs",
      "kind": "rust:inherent_impl_method",
      "line": null,
      "symbol": "vibecrafted-app/mux-agent/src/lib.rs::with_args"
    },
    {
      "authority": "loctree_derived",
      "detail": "Defined inside inherent `impl MuxConfig` block; reached via method-call syntax.",
      "file": "vibecrafted-app/mux-agent/src/lib.rs",
      "kind": "rust:inherent_impl_method",
      "line": null,
      "symbol": "vibecrafted-app/mux-agent/src/lib.rs::with_env"
    },
    {
      "authority": "loctree_derived",
      "detail": "Defined inside inherent `impl MuxConfig` block; reached via method-call syntax.",
      "file": "vibecrafted-app/mux-agent/src/lib.rs",
      "kind": "rust:inherent_impl_method",
      "line": null,
      "symbol": "vibecrafted-app/mux-agent/src/lib.rs::with_env_var"
    },
    {
      "authority": "loctree_derived",
      "detail": "Defined inside inherent `impl MuxConfig` block; reached via method-call syntax.",
      "file": "vibecrafted-app/mux-agent/src/lib.rs",
      "kind": "rust:inherent_impl_method",
      "line": null,
      "symbol": "vibecrafted-app/mux-agent/src/lib.rs::with_heartbeat"
    },
    {
      "authority": "loctree_derived",
      "detail": "Defined inside inherent `impl MuxConfig` block; reached via method-call syntax.",
      "file": "vibecrafted-app/mux-agent/src/lib.rs",
      "kind": "rust:inherent_impl_method",
      "line": null,
      "symbol": "vibecrafted-app/mux-agent/src/lib.rs::with_heartbeat_enabled"
    },
    {
      "authority": "loctree_derived",
      "detail": "Defined inside inherent `impl MuxConfig` block; reached via method-call syntax.",
      "file": "vibecrafted-app/mux-agent/src/lib.rs",
      "kind": "rust:inherent_impl_method",
      "line": null,
      "symbol": "vibecrafted-app/mux-agent/src/lib.rs::with_heartbeat_max_failures"
    },
    {
      "authority": "loctree_derived",
      "detail": "Defined inside inherent `impl MuxConfig` block; reached via method-call syntax.",
      "file": "vibecrafted-app/mux-agent/src/lib.rs",
      "kind": "rust:inherent_impl_method",
      "line": null,
      "symbol": "vibecrafted-app/mux-agent/src/lib.rs::with_lazy_start"
    },
    {
      "authority": "loctree_derived",
      "detail": "Defined inside inherent `impl MuxConfig` block; reached via method-call syntax.",
      "file": "vibecrafted-app/mux-agent/src/lib.rs",
      "kind": "rust:inherent_impl_method",
      "line": null,
      "symbol": "vibecrafted-app/mux-agent/src/lib.rs::with_log_level"
    },
    {
      "authority": "loctree_derived",
      "detail": "Defined inside inherent `impl MuxConfig` block; reached via method-call syntax.",
      "file": "vibecrafted-app/mux-agent/src/lib.rs",
      "kind": "rust:inherent_impl_method",
      "line": null,
      "symbol": "vibecrafted-app/mux-agent/src/lib.rs::with_max_clients"
    },
    {
      "authority": "loctree_derived",
      "detail": "Defined inside inherent `impl MuxConfig` block; reached via method-call syntax.",
      "file": "vibecrafted-app/mux-agent/src/lib.rs",
      "kind": "rust:inherent_impl_method",
      "line": null,
      "symbol": "vibecrafted-app/mux-agent/src/lib.rs::with_max_request_bytes"
    },
    {
      "authority": "loctree_derived",
      "detail": "Defined inside inherent `impl MuxConfig` block; reached via method-call syntax.",
      "file": "vibecrafted-app/mux-agent/src/lib.rs",
      "kind": "rust:inherent_impl_method",
      "line": null,
      "symbol": "vibecrafted-app/mux-agent/src/lib.rs::with_max_restarts"
    },
    {
      "authority": "loctree_derived",
      "detail": "Defined inside inherent `impl MuxConfig` block; reached via method-call syntax.",
      "file": "vibecrafted-app/mux-agent/src/lib.rs",
      "kind": "rust:inherent_impl_method",
      "line": null,
      "symbol": "vibecrafted-app/mux-agent/src/lib.rs::with_request_timeout"
    },
    {
      "authority": "loctree_derived",
      "detail": "Defined inside inherent `impl MuxConfig` block; reached via method-call syntax.",
      "file": "vibecrafted-app/mux-agent/src/lib.rs",
      "kind": "rust:inherent_impl_method",
      "line": null,
      "symbol": "vibecrafted-app/mux-agent/src/lib.rs::with_restart_backoff"
    },
    {
      "authority": "loctree_derived",
      "detail": "Defined inside inherent `impl MuxConfig` block; reached via method-call syntax.",
      "file": "vibecrafted-app/mux-agent/src/lib.rs",
      "kind": "rust:inherent_impl_method",
      "line": null,
      "symbol": "vibecrafted-app/mux-agent/src/lib.rs::with_service_name"
    },
    {
      "authority": "loctree_derived",
      "detail": "Defined inside inherent `impl MuxConfig` block; reached via method-call syntax.",
      "file": "vibecrafted-app/mux-agent/src/lib.rs",
      "kind": "rust:inherent_impl_method",
      "line": null,
      "symbol": "vibecrafted-app/mux-agent/src/lib.rs::with_status_file"
    },
    {
      "authority": "loctree_derived",
      "detail": "Defined inside inherent `impl MuxConfig` block; reached via method-call syntax.",
      "file": "vibecrafted-app/mux-agent/src/lib.rs",
      "kind": "rust:inherent_impl_method",
      "line": null,
      "symbol": "vibecrafted-app/mux-agent/src/lib.rs::with_tray"
    },
    {
      "authority": "loctree_derived",
      "detail": "Defined inside inherent `impl MuxState` block; reached via method-call syntax.",
      "file": "vibecrafted-app/mux-agent/src/state.rs",
      "kind": "rust:inherent_impl_method",
      "line": null,
      "symbol": "vibecrafted-app/mux-agent/src/state.rs::buffer_message"
    },
    {
      "authority": "loctree_derived",
      "detail": "Defined inside inherent `impl MuxState` block; reached via method-call syntax.",
      "file": "vibecrafted-app/mux-agent/src/state.rs",
      "kind": "rust:inherent_impl_method",
      "line": null,
      "symbol": "vibecrafted-app/mux-agent/src/state.rs::complete_handshake"
    },
    {
      "authority": "loctree_derived",
      "detail": "Defined inside inherent `impl MuxState` block; reached via method-call syntax.",
      "file": "vibecrafted-app/mux-agent/src/state.rs",
      "kind": "rust:inherent_impl_method",
      "line": null,
      "symbol": "vibecrafted-app/mux-agent/src/state.rs::get_handshake_mut"
    },
    {
      "authority": "loctree_derived",
      "detail": "Defined inside inherent `impl MuxState` block; reached via method-call syntax.",
      "file": "vibecrafted-app/mux-agent/src/state.rs",
      "kind": "rust:inherent_impl_method",
      "line": null,
      "symbol": "vibecrafted-app/mux-agent/src/state.rs::is_handshake_complete"
    },
    {
      "authority": "loctree_derived",
      "detail": "Defined inside inherent `impl MuxState` block; reached via method-call syntax.",
      "file": "vibecrafted-app/mux-agent/src/state.rs",
      "kind": "rust:inherent_impl_method",
      "line": null,
      "symbol": "vibecrafted-app/mux-agent/src/state.rs::is_handshake_timed_out"
    },
    {
      "authority": "loctree_derived",
      "detail": "Defined inside inherent `impl MuxState` block; reached via method-call syntax.",
      "file": "vibecrafted-app/mux-agent/src/state.rs",
      "kind": "rust:inherent_impl_method",
      "line": null,
      "symbol": "vibecrafted-app/mux-agent/src/state.rs::mark_handshake_complete"
    },
    {
      "authority": "loctree_derived",
      "detail": "Defined inside inherent `impl MuxState` block; reached via method-call syntax.",
      "file": "vibecrafted-app/mux-agent/src/state.rs",
      "kind": "rust:inherent_impl_method",
      "line": null,
      "symbol": "vibecrafted-app/mux-agent/src/state.rs::new"
    },
    {
      "authority": "loctree_derived",
      "detail": "Defined inside inherent `impl MuxState` block; reached via method-call syntax.",
      "file": "vibecrafted-app/mux-agent/src/state.rs",
      "kind": "rust:inherent_impl_method",
      "line": null,
      "symbol": "vibecrafted-app/mux-agent/src/state.rs::next_request_id"
    },
    {
      "authority": "loctree_derived",
      "detail": "Defined inside inherent `impl MuxState` block; reached via method-call syntax.",
      "file": "vibecrafted-app/mux-agent/src/state.rs",
      "kind": "rust:inherent_impl_method",
      "line": null,
      "symbol": "vibecrafted-app/mux-agent/src/state.rs::register_client"
    },
    {
      "authority": "loctree_derived",
      "detail": "Defined inside inherent `impl MuxState` block; reached via method-call syntax.",
      "file": "vibecrafted-app/mux-agent/src/state.rs",
      "kind": "rust:inherent_impl_method",
      "line": null,
      "symbol": "vibecrafted-app/mux-agent/src/state.rs::unregister_client"
    }
  ],
  "idiom_tags": [
    {
      "authority": "semantic_guess",
      "classifier": "rust:pub_use_reexport",
      "name": "CliOptions",
      "reasoning": "Re-exported via `pub use`; reached through downstream importers.",
      "runtime_role": "public_entrypoint",
      "source": "inferred_from_code",
      "symbol": "vibecrafted-app/mux-agent/src/lib.rs::CliOptions"
    },
    {
      "authority": "semantic_guess",
      "classifier": "rust:pub_use_reexport",
      "name": "Config",
      "reasoning": "Re-exported via `pub use`; reached through downstream importers.",
      "runtime_role": "public_entrypoint",
      "source": "inferred_from_code",
      "symbol": "vibecrafted-app/mux-agent/src/lib.rs::Config"
    },
    {
      "authority": "semantic_guess",
      "classifier": "rust:pub_use_reexport",
      "name": "DEFAULT_STATUS_SOCKET",
      "reasoning": "Re-exported via `pub use`; reached through downstream importers.",
      "runtime_role": "public_entrypoint",
      "source": "inferred_from_code",
      "symbol": "vibecrafted-app/mux-agent/src/lib.rs::DEFAULT_STATUS_SOCKET"
    },
    {
      "authority": "semantic_guess",
      "classifier": "rust:pub_use_reexport",
      "name": "DaemonStatus",
      "reasoning": "Re-exported via `pub use`; reached through downstream importers.",
      "runtime_role": "public_entrypoint",
      "source": "inferred_from_code",
      "symbol": "vibecrafted-app/mux-agent/src/lib.rs::DaemonStatus"
    },
    {
      "authority": "semantic_guess",
      "classifier": "rust:pub_use_reexport",
      "name": "HeartbeatConfig",
      "reasoning": "Re-exported via `pub use`; reached through downstream importers.",
      "runtime_role": "public_entrypoint",
      "source": "inferred_from_code",
      "symbol": "vibecrafted-app/mux-agent/src/lib.rs::HeartbeatConfig"
    },
    {
      "authority": "semantic_guess",
      "classifier": "rust:pub_use_reexport",
      "name": "MAX_PENDING",
      "reasoning": "Re-exported via `pub use`; reached through downstream importers.",
      "runtime_role": "public_entrypoint",
      "source": "inferred_from_code",
      "symbol": "vibecrafted-app/mux-agent/src/lib.rs::MAX_PENDING"
    },
    {
      "authority": "semantic_guess",
      "classifier": "rust:pub_use_reexport",
      "name": "MAX_QUEUE",
      "reasoning": "Re-exported via `pub use`; reached through downstream importers.",
      "runtime_role": "public_entrypoint",
      "source": "inferred_from_code",
      "symbol": "vibecrafted-app/mux-agent/src/lib.rs::MAX_QUEUE"
    },
    {
      "authority": "semantic_guess",
      "classifier": "rust:pub_use_reexport",
      "name": "ManagedServer",
      "reasoning": "Re-exported via `pub use`; reached through downstream importers.",
      "runtime_role": "public_entrypoint",
      "source": "inferred_from_code",
      "symbol": "vibecrafted-app/mux-agent/src/lib.rs::ManagedServer"
    },
    {
      "authority": "semantic_guess",
      "classifier": "rust:pub_use_reexport",
      "name": "MultiServerStatus",
      "reasoning": "Re-exported via `pub use`; reached through downstream importers.",
      "runtime_role": "public_entrypoint",
      "source": "inferred_from_code",
      "symbol": "vibecrafted-app/mux-agent/src/lib.rs::MultiServerStatus"
    },
    {
      "authority": "semantic_guess",
      "classifier": "rust:pub_use_reexport",
      "name": "MuxState",
      "reasoning": "Re-exported via `pub use`; reached through downstream importers.",
      "runtime_role": "public_entrypoint",
      "source": "inferred_from_code",
      "symbol": "vibecrafted-app/mux-agent/src/lib.rs::MuxState"
    },
    {
      "authority": "semantic_guess",
      "classifier": "rust:pub_use_reexport",
      "name": "ResolvedParams",
      "reasoning": "Re-exported via `pub use`; reached through downstream importers.",
      "runtime_role": "public_entrypoint",
      "source": "inferred_from_code",
      "symbol": "vibecrafted-app/mux-agent/src/lib.rs::ResolvedParams"
    },
    {
      "authority": "semantic_guess",
      "classifier": "rust:pub_use_reexport",
      "name": "ServerCommand",
      "reasoning": "Re-exported via `pub use`; reached through downstream importers.",
      "runtime_role": "public_entrypoint",
      "source": "inferred_from_code",
      "symbol": "vibecrafted-app/mux-agent/src/lib.rs::ServerCommand"
    },
    {
      "authority": "semantic_guess",
      "classifier": "rust:pub_use_reexport",
      "name": "ServerConfig",
      "reasoning": "Re-exported via `pub use`; reached through downstream importers.",
      "runtime_role": "public_entrypoint",
      "source": "inferred_from_code",
      "symbol": "vibecrafted-app/mux-agent/src/lib.rs::ServerConfig"
    },
    {
      "authority": "semantic_guess",
      "classifier": "rust:pub_use_reexport",
      "name": "ServerRef",
      "reasoning": "Re-exported via `pub use`; reached through downstream importers.",
      "runtime_role": "public_entrypoint",
      "source": "inferred_from_code",
      "symbol": "vibecrafted-app/mux-agent/src/lib.rs::ServerRef"
    },
    {
      "authority": "semantic_guess",
      "classifier": "rust:pub_use_reexport",
      "name": "ServerStatus",
      "reasoning": "Re-exported via `pub use`; reached through downstream importers.",
      "runtime_role": "public_entrypoint",
      "source": "inferred_from_code",
      "symbol": "vibecrafted-app/mux-agent/src/lib.rs::ServerStatus"
    },
    {
      "authority": "semantic_guess",
      "classifier": "rust:pub_use_reexport",
      "name": "StatusLevel",
      "reasoning": "Re-exported via `pub use`; reached through downstream importers.",
      "runtime_role": "public_entrypoint",
      "source": "inferred_from_code",
      "symbol": "vibecrafted-app/mux-agent/src/lib.rs::StatusLevel"
    },
    {
      "authority": "semantic_guess",
      "classifier": "rust:pub_use_reexport",
      "name": "StatusSnapshot",
      "reasoning": "Re-exported via `pub use`; reached through downstream importers.",
      "runtime_role": "public_entrypoint",
      "source": "inferred_from_code",
      "symbol": "vibecrafted-app/mux-agent/src/lib.rs::StatusSnapshot"
    },
    {
      "authority": "semantic_guess",
      "classifier": "rust:pub_use_reexport",
      "name": "StatusState",
      "reasoning": "Re-exported via `pub use`; reached through downstream importers.",
      "runtime_role": "public_entrypoint",
      "source": "inferred_from_code",
      "symbol": "vibecrafted-app/mux-agent/src/lib.rs::StatusState"
    },
    {
      "authority": "semantic_guess",
      "classifier": "rust:pub_use_reexport",
      "name": "TuiMuxState",
      "reasoning": "Re-exported via `pub use`; reached through downstream importers.",
      "runtime_role": "public_entrypoint",
      "source": "inferred_from_code",
      "symbol": "vibecrafted-app/mux-agent/src/lib.rs::TuiMuxState"
    },
    {
      "authority": "semantic_guess",
      "classifier": "rust:pub_use_reexport",
      "name": "format_uptime",
      "reasoning": "Re-exported via `pub use`; reached through downstream importers.",
      "runtime_role": "public_entrypoint",
      "source": "inferred_from_code",
      "symbol": "vibecrafted-app/mux-agent/src/lib.rs::format_uptime"
    },
    {
      "authority": "semantic_guess",
      "classifier": "rust:pub_use_reexport",
      "name": "health_check",
      "reasoning": "Re-exported via `pub use`; reached through downstream importers.",
      "runtime_role": "public_entrypoint",
      "source": "inferred_from_code",
      "symbol": "vibecrafted-app/mux-agent/src/lib.rs::health_check"
    },
    {
      "authority": "semantic_guess",
      "classifier": "rust:inherent_impl_method",
      "name": "is_running",
      "reasoning": "Defined inside inherent `impl MuxHandle` block; reached via method-call syntax.",
      "runtime_role": "library_helper",
      "source": "inferred_from_code",
      "symbol": "vibecrafted-app/mux-agent/src/lib.rs::is_running"
    },
    {
      "authority": "loctree_derived",
      "classifier": "library_helper",
      "name": "new",
      "reasoning": "Idiomatic Rust constructor convention; called via Type::new(...) across the ecosystem.",
      "runtime_role": "library_helper",
      "source": "embedded_default",
      "symbol": "vibecrafted-app/mux-agent/src/lib.rs::new"
    },
    {
      "authority": "semantic_guess",
      "classifier": "rust:pub_use_reexport",
      "name": "print_status_table",
      "reasoning": "Re-exported via `pub use`; reached through downstream importers.",
      "runtime_role": "public_entrypoint",
      "source": "inferred_from_code",
      "symbol": "vibecrafted-app/mux-agent/src/lib.rs::print_status_table"
    },
    {
      "authority": "semantic_guess",
      "classifier": "rust:pub_use_reexport",
      "name": "query_status",
      "reasoning": "Re-exported via `pub use`; reached through downstream importers.",
      "runtime_role": "public_entrypoint",
      "source": "inferred_from_code",
      "symbol": "vibecrafted-app/mux-agent/src/lib.rs::query_status"
    },
    {
      "authority": "semantic_guess",
      "classifier": "rust:pub_use_reexport",
      "name": "resolve_params_multi",
      "reasoning": "Re-exported via `pub use`; reached through downstream importers.",
      "runtime_role": "public_entrypoint",
      "source": "inferred_from_code",
      "symbol": "vibecrafted-app/mux-agent/src/lib.rs::resolve_params_multi"
    },
    {
      "authority": "semantic_guess",
      "classifier": "rust:pub_use_reexport",
      "name": "run_multi_tui",
      "reasoning": "Re-exported via `pub use`; reached through downstream importers.",
      "runtime_role": "public_entrypoint",
      "source": "inferred_from_code",
      "symbol": "vibecrafted-app/mux-agent/src/lib.rs::run_multi_tui"
    },
    {
      "authority": "semantic_guess",
      "classifier": "rust:pub_use_reexport",
      "name": "run_mux",
      "reasoning": "Re-exported via `pub use`; reached through downstream importers.",
      "runtime_role": "public_entrypoint",
      "source": "inferred_from_code",
      "symbol": "vibecrafted-app/mux-agent/src/lib.rs::run_mux"
    },
    {
      "authority": "semantic_guess",
      "classifier": "rust:pub_use_reexport",
      "name": "run_proxy",
      "reasoning": "Re-exported via `pub use`; reached through downstream importers.",
      "runtime_role": "public_entrypoint",
      "source": "inferred_from_code",
      "symbol": "vibecrafted-app/mux-agent/src/lib.rs::run_proxy"
    },
    {
      "authority": "semantic_guess",
      "classifier": "rust:pub_use_reexport",
      "name": "run_status_listener",
      "reasoning": "Re-exported via `pub use`; reached through downstream importers.",
      "runtime_role": "public_entrypoint",
      "source": "inferred_from_code",
      "symbol": "vibecrafted-app/mux-agent/src/lib.rs::run_status_listener"
    },
    {
      "authority": "semantic_guess",
      "classifier": "rust:inherent_impl_method",
      "name": "service_name",
      "reasoning": "Defined inside inherent `impl MuxConfig` block; reached via method-call syntax.",
      "runtime_role": "library_helper",
      "source": "inferred_from_code",
      "symbol": "vibecrafted-app/mux-agent/src/lib.rs::service_name"
    },
    {
      "authority": "semantic_guess",
      "classifier": "rust:inherent_impl_method",
      "name": "shutdown",
      "reasoning": "Defined inside inherent `impl MuxHandle` block; reached via method-call syntax.",
      "runtime_role": "library_helper",
      "source": "inferred_from_code",
      "symbol": "vibecrafted-app/mux-agent/src/lib.rs::shutdown"
    },
    {
      "authority": "semantic_guess",
      "classifier": "rust:inherent_impl_method",
      "name": "wait",
      "reasoning": "Defined inside inherent `impl MuxHandle` block; reached via method-call syntax.",
      "runtime_role": "library_helper",
      "source": "inferred_from_code",
      "symbol": "vibecrafted-app/mux-agent/src/lib.rs::wait"
    },
    {
      "authority": "semantic_guess",
      "classifier": "rust:inherent_impl_method",
      "name": "with_args",
      "reasoning": "Defined inside inherent `impl MuxConfig` block; reached via method-call syntax.",
      "runtime_role": "library_helper",
      "source": "inferred_from_code",
      "symbol": "vibecrafted-app/mux-agent/src/lib.rs::with_args"
    },
    {
      "authority": "semantic_guess",
      "classifier": "rust:inherent_impl_method",
      "name": "with_env",
      "reasoning": "Defined inside inherent `impl MuxConfig` block; reached via method-call syntax.",
      "runtime_role": "library_helper",
      "source": "inferred_from_code",
      "symbol": "vibecrafted-app/mux-agent/src/lib.rs::with_env"
    },
    {
      "authority": "semantic_guess",
      "classifier": "rust:inherent_impl_method",
      "name": "with_env_var",
      "reasoning": "Defined inside inherent `impl MuxConfig` block; reached via method-call syntax.",
      "runtime_role": "library_helper",
      "source": "inferred_from_code",
      "symbol": "vibecrafted-app/mux-agent/src/lib.rs::with_env_var"
    },
    {
      "authority": "semantic_guess",
      "classifier": "rust:inherent_impl_method",
      "name": "with_heartbeat",
      "reasoning": "Defined inside inherent `impl MuxConfig` block; reached via method-call syntax.",
      "runtime_role": "library_helper",
      "source": "inferred_from_code",
      "symbol": "vibecrafted-app/mux-agent/src/lib.rs::with_heartbeat"
    },
    {
      "authority": "semantic_guess",
      "classifier": "rust:inherent_impl_method",
      "name": "with_heartbeat_enabled",
      "reasoning": "Defined inside inherent `impl MuxConfig` block; reached via method-call syntax.",
      "runtime_role": "library_helper",
      "source": "inferred_from_code",
      "symbol": "vibecrafted-app/mux-agent/src/lib.rs::with_heartbeat_enabled"
    },
    {
      "authority": "semantic_guess",
      "classifier": "rust:inherent_impl_method",
      "name": "with_heartbeat_max_failures",
      "reasoning": "Defined inside inherent `impl MuxConfig` block; reached via method-call syntax.",
// truncated: 550 more line(s); read the complete payload at `02-runtime-map.full.json` (sibling of this card), or run `loct context --full --json` for the whole pack

```

## What this card does not cover

This Runtime Map does not include prior decisions or full risk history. Read `03-memory-trail.md` when continuing work and `05-risk-register.md` before release decisions.
