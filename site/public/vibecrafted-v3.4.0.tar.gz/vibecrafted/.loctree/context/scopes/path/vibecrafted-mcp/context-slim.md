# Loctree Context · vibecrafted @ feat/runtime-integration · 2026-06-07T23:44:13.781385Z

_617 files · 398 import edges · snapshot fresh · dirty worktree_

## TL;DR — read this first

**What this is.** `vibecrafted` repository — current focus: _Runtime Integration_.

**Where you stand.** Branch `feat/runtime-integration`, dirty worktree, snapshot fresh.
Last 5 commits: `216f180 [claude/interactive] fix(skills): add Code-Derived Application Map to vc-justdo + vc-scaffold gates` · `60b0bde [claude/interactive] fix(install): wire shell rc on every machine for one truth after install-all` · `be044ea [claude/interactive] fix(test): stage marbles_spawn.sh under runtime/scripts in fixtures`
Active intent (AICX): "{"completed_at":1780688474,"duration_ms":33780,"last_agent_message":"Przeczytane w całości: 5 scope contextów, 814 linii.\n\nNajważniejszy obraz:\n\n- `vibecrafted-app`: największy blast radius. Szczególnie `mux-agent/src/config.rs`, `scan.rs`, `state.rs`; realne testy Rust do odpalenia przy zmianach.\n- `vibecrafted-core`: runtime serce. `__init__.py`, `events.py`, `runtime_paths.py`, `spawn.py`, `control_plane.py`, `workflow.py` są główne punkty ryzyka." — codex on 2026-06-05.
**Scope.** `path:vibecrafted-mcp` -> path:vibecrafted-mcp (8 files, fingerprint: 1adb52e31c44).

**Top 3 things to know before editing.**
1. Hub `vibecrafted-mcp/vibecrafted_mcp/server.py` has 3 importers — touching it = wide blast radius (of 30 ranked hubs). (LoctreeDerived)
2. Worktree is dirty — auto-scope mirrors uncommitted edits, not committed state. (RepoVerified)
3. Active memory says `{"completed_at":1780688474,"duration_ms":33780,"last_agent_message":"Przeczytane w całości: 5 scope contextów, 814 linii.\n\nNajważniejszy obraz:\n\n- `vibecrafted-app`: największy blast radius. Szczególnie `mux-agent/src/config.rs`, `scan.rs`, `state.rs`; realne testy Rust do odpalenia przy zmianach.\n- `vibecrafted-core`: runtime serce. `__init__.py`, `events.py`, `runtime_paths.py`, `spawn.py`, `control_plane.py`, `workflow.py` są główne punkty ryzyka.` — codex on 2026-06-05. (AicxOperator)

**Snapshot facts.** 30 hubs · 2 idiom tag(s) · 0 dispatch edge(s) · 1 env contract(s) · 50 memory entries · 90 authority claim(s).

**What's stale.** None.

## Where You Are

### Hubs — touch = blast radius

| File | Importers | Authority |
|---|---:|---|
| `vibecrafted-mcp/vibecrafted_mcp/server.py` | 3 | LoctreeDerived |
| `vibecrafted-mcp/vibecrafted_mcp/__init__.py` | 1 | LoctreeDerived |

### Cycles

- not_measured (run `loct cycles` for current measurement) (LoctreeDerived)

### Recently active surface (last 24h)

- `.github/workflows/portable.yml` (RepoVerified)
- `.gitignore` (RepoVerified)
- `.junie/plans/decompose-vetcoders-shell-runtime.md` (RepoVerified)
- `.loctignore` (RepoVerified)
- `CHANGELOG.md` (RepoVerified)
- `Makefile` (RepoVerified)
- `agents/scripts/install-shell.sh` (RepoVerified)
- `agents/scripts/lib/meta.sh` (RepoVerified)
- `agents/scripts/skills_sync.sh` (RepoVerified)
- `agents/shell/lib/atuin.sh` (RepoVerified)

### Risk metrics

- dead_exports: not_measured (use-graph counts `pub use` re-exports as live — known limitation; run `loct dead` for current count) (RepoVerified)
- twins: not_measured (run `loct twins` for a context-classified pass) (RepoVerified)
- cache_scope: `Scoped("1adb52e31c44")` (RepoVerified)
- high_fan_in: 0 over threshold 10 (LoctreeDerived)

## What's Live

### Idiom tag clusters (top 10 by hit count)

- `idiom:shell-helper` (2 hits) — main shell helpers (LoctreeDerived)

### Dispatch edges (top 5 by reach)

- _no dispatch edges in scope_ (LoctreeDerived)

### Env contracts (vars used in scope)

- `VIBECRAFTED_HOME` — used in 24 file(s) (LoctreeDerived)

### Reachability (top 5 widely-reached symbols)

- `vibecrafted-mcp/vibecrafted_mcp/__init__.py::main` — reason: `idiom_runtime_role:primary_entrypoint` (SemanticGuess)
- `vibecrafted-mcp/vibecrafted_mcp/server.py::main` — reason: `idiom_runtime_role:primary_entrypoint` (SemanticGuess)

## Memory

### Recent decisions / intents / outcomes (last 168h, top by relevance)

1. `outcome` · codex · 2026-06-05 · _{"completed_at":1780688474,"duration_ms":33780,"last_agent_message":"Przeczytane w całości: 5 scope contextów, 814 linii.\n\nNajważniejszy obraz:\n\n- `vibecrafted-app`: największy blast radius. Szczególnie `mux-agent/src/config.rs`, `scan.rs`, `state.rs`; realne testy Rust do odpalenia przy zmianach.\n- `vibecrafted-core`: runtime serce. `__init__.py`, `events.py`, `runtime_paths.py`, `spawn.py`, `control_plane.py`, `workflow.py` są główne punkty ryzyka._ (AicxAgent) — chunk: `chunk:48e118ea`
2. `outcome` · codex · 2026-06-05 · _{"call_id":"call_yw5VKW9ST4pM1a4TjNaMcj0R","changes":{"/Users/maciejgad/vc-workspace/vetcoders/vibecrafted/plans/2026-06-05-workflow-runtime-extraction.md":{"content":"---\nstatus: draft\nowner: codex\ndate: 2026-06-05\nvector: stabilize\n---\n\n# Workflow Runtime Extraction\n\n## Current State\n\nWorkflow runtime truth is split across:\n\n- `skills/<workflow>/SKILL.md`, `FLOW.md`, references, templates, and agent YAML.\n- `skills/vc-agents/shell/lib/*._ (AicxAgent) — chunk: `chunk:70c2d1cc`
3. `outcome` · codex · 2026-06-05 · _{"call_id":"call_COkyoeDnkYbIBQYkqbdTvuTR","changes":{"/Users/maciejgad/vc-workspace/vetcoders/vibecrafted/tests/tui/test_runtime_regressions.py":{"move_path":null,"type":"update","unified_diff":"@@ -104,3 +104,4 @@\n command_body = command_script.read_text(encoding=\"utf-8\")\n- assert \"codex resume sess-123 'carry on'\" in command_body\n+ assert \"codex resume sess-123\" in command_body\n+ assert \"carry on\" in command_body\n \n"}},"status":"completed","stderr":"" …_ (AicxAgent) — chunk: `chunk:64af7c87`
4. `outcome` · codex · 2026-06-05 · _{"completed_at":1780697273,"duration_ms":25193,"last_agent_message":"Tak, teraz mam już te MCP-y działające po stronie Codexa.\n\nKonkretnie: po zmianie configu i odświeżeniu tool discovery `loctree-mcp` wystawił namespace `mcp__loctree_mcp`, a realny smoke-test przeszedł:\n\n```text\nslice scripts/vetcoders_install.py\ncore_loc: 5482\ndependencies: scripts/installer_brand.py, scripts/runtime_paths.py\nconsumer: scripts/build_marketplace_bundle._ (AicxAgent) — chunk: `chunk:a5e67bf9`
5. `outcome` · codex · 2026-06-05 · _{"call_id":"call_y31zrXXdMjazsEXVZr1mTVqk","changes":{"/Users/maciejgad/vc-workspace/vetcoders/vibecrafted/docs/runtime/CONTRACT.md":{"move_path":null,"type":"update","unified_diff":"@@ -150,3 +150,3 @@\n \n-Final Markdown artifact filenames SHOULD use:\n+Final Markdown artifact filenames MUST use:\n `%Y-%m-%d_<org>_<repo>_<full_session_id>-<kind>.md`\n"}},"status":"completed","stderr":"","stdout":"Success. Updated the following files:\nM docs/runtime/CONTRACT._ (AicxAgent) — chunk: `chunk:c15b5f45`
6. `outcome` · codex · 2026-06-05 · _{"call_id":"call_J4PYyJKACIGjUaoy5EdYZVj8","changes":{"/Users/maciejgad/vc-workspace/vetcoders/vibecrafted/tests/tui/test_spawn_common.py":{"move_path":null,"type":"update","unified_diff":"@@ -817,3 +817,6 @@\n assert payload[\"artifact_stem\"].endswith(f\"_{session_id}-report\")\n- assert re.fullmatch(r\"\\d{4}-\\d{2}-\\d{2}T\\d{2}:\\d{2}:\\d{2} .+\", payload[\"date\"])\n+ assert re.fullmatch(\n+ r\"\\d{4}-\\d{2}-\\d{2}T\\d{2}:\\d{2}:\\d{2}([+-]\\d{2}:\\d{2}\|Z)\" …_ (AicxAgent) — chunk: `chunk:593db89b`
7. `outcome` · codex · 2026-06-05 · _{"call_id":"call_oH9jHbugzIty2x1ApfhmCObC","changes":{"/Users/maciejgad/vc-workspace/vetcoders/vibecrafted/tests/tui/test_runtime_regressions.py":{"move_path":null,"type":"update","unified_diff":"@@ -99,3 +99,3 @@\n \"new-tab\",\n- \"--CALL--\",\n+ \"--name\",\n ]\n"}},"status":"completed","stderr":"","stdout":"Success. Updated the following files:\nM /Users/maciejgad/vc-workspace/vetcoders/vibecrafted/tests/tui/test_runtime_regressions._ (AicxAgent) — chunk: `chunk:69eb7fe6`
8. `outcome` · codex · 2026-06-05 · _{"call_id":"call_bblBJaGbGyWr844kizcowVhV","changes":{"/Users/maciejgad/vc-workspace/vetcoders/vibecrafted/templates/hooks/config/template.husky.env":{"move_path":null,"type":"update","unified_diff":"@@ -112,3 +112,3 @@\n # Require the full agent/runtime footer used by Vibecrafted local commits:\n-# Authored-By, session_id, timestamp, and runtime.\n+# Authored-By, session_id, time, and runtime.\n HUSKY_COMMIT_MSG_REQUIRE_AGENT_RUNTIME=1\n"}},"status":"completed","stderr":"" …_ (AicxAgent) — chunk: `chunk:c0c007e3`
9. `outcome` · codex · 2026-06-05 · _{"call_id":"call_Z4pXUGGF0hMFcLXp2IQrXxjH","changes":{"/Users/maciejgad/vc-workspace/vetcoders/vibecrafted/docs/runtime/CONTRACT.md":{"move_path":null,"type":"update","unified_diff":"@@ -169,3 +169,3 @@\n status: <pending\|in-progress\|completed\|failed>\n-date: <YYYY-MM-DDTHH:MM:SS TZ>\n+date: <YYYY-MM-DDTHH:MM:SS±HH:MM>\n session_id: <full agent session id when known>\n"}},"status":"completed","stderr":"","stdout":"Success._ (AicxFailure) — chunk: `chunk:76e8bee9`
10. `outcome` · codex · 2026-06-05 · _{"call_id":"call_I9rZ8zrDTXOetB6Qp6P2vxZ1","changes":{"/Users/maciejgad/vc-workspace/vetcoders/vibecrafted/tests/tui/test_runtime_regressions.py":{"move_path":null,"type":"update","unified_diff":"@@ -82,4 +82,15 @@\n zellij_lines = zellij_capture.read_text(encoding=\"utf-8\").splitlines()\n- assert zellij_lines[:6] == [\n- \"--CALL--\",\n+ calls: list[list[str]] = []\n+ current: list[str] = []\n+ for line in zellij_lines:\n+ if line == \"--CALL--\":\n+ if current:\n+ calls._ (AicxAgent) — chunk: `chunk:425163fa`
11. `outcome` · codex · 2026-06-05 · _{"call_id":"call_Zgu0iBG7LARhjX81VPejY5ZT","changes":{"/Users/maciejgad/vc-workspace/vetcoders/vibecrafted/tests/tui/test_runtime_regressions.py":{"content":"from __future__ import annotations\n\nimport os\nimport subprocess\nfrom pathlib import Path\n\nfrom scripts import vetcoders_install\n\nREPO_ROOT = Path(__file__).resolve().parents[2]\nSHELL_SH = REPO_ROOT / \"skills\" / \"vc-agents\" / \"shell\" / \"vetcoders._ (AicxAgent) — chunk: `chunk:3ec05ea4`
12. `outcome` · codex · 2026-06-05 · _{"call_id":"call_ke1oQbf2nn1EYW8k2TbjzU9m","changes":{"/Users/maciejgad/vc-workspace/vetcoders/loctree-suite/ai-hooks/README.md":{"move_path":null,"type":"update","unified_diff":"@@ -123,3 +123,3 @@\n \"type\": \"command\",\n- \"command\": \"python3 '~/.codex/hooks/codex-post-tool-hints.py'\",\n+ \"command\": \"python3 \\\"$HOME/.codex/hooks/codex-post-tool-hints.py\\\"\",\n \"timeout\": 3\n"}},"status":"completed","stderr":"","stdout":"Success._ (AicxAgent) — chunk: `chunk:ad10031b`
13. `outcome` · codex · 2026-06-05 · _{"completed_at":1780697273,"duration_ms":25193,"last_agent_message":"Tak, teraz mam już te MCP-y działające po stronie Codexa.\n\nKonkretnie: po zmianie configu i odświeżeniu tool discovery `loctree-mcp` wystawił namespace `mcp__loctree_mcp`, a realny smoke-test przeszedł:\n\n```text\nslice scripts/vetcoders_install.py\ncore_loc: 5482\ndependencies: scripts/installer_brand.py, scripts/runtime_paths.py\nconsumer: scripts/build_marketplace_bundle._ (AicxAgent) — chunk: `chunk:a5e67bf9`
14. `outcome` · codex · 2026-06-05 · _{"call_id":"call_MI8Z3kySAETiqhxXqWqGSAtu","changes":{"/Users/maciejgad/.codex/config.toml":{"move_path":null,"type":"update","unified_diff":"@@ -58,3 +58,3 @@\n ]\n-command = \"/Users/maciejgad/.cargo/bin/aicx-mcp\"\n+command = \"aicx-mcp\"\n startup_timeout_sec = 30.0\n@@ -66,3 +66,3 @@\n ]\n-command = \"/opt/homebrew/bin/npx\"\n+command = \"npx\"\n startup_timeout_sec = 30.0\n@@ -74,3 +74,3 @@\n [mcp_servers.loctree-mcp]\n-command = \"/Users/maciejgad/._ (AicxAgent) — chunk: `chunk:6af61934`
15. `outcome` · codex · 2026-06-05 · _zsh -ic 'echo "zsh -ic PATH=$PATH"; for x in zellij vibecrafted vc-init aicx loctree-mcp; do echo "--- $x"; whence -va "$x" 2>/dev/null \|\| command -v "$x" 2>/dev/null \|\| echo MISSING; done'_ (AicxAgent) — chunk: `chunk:e09be7de`

### Source chunk pointers

_37 unique chunk(s) reachable via `aicx open <chunk:ref>` (resolved against the operator's local aicx store; absolute paths intentionally redacted to keep this context-pack commitable)._

## Action

### Next safe commands (grounded, ≤3)

```bash
loct slice vibecrafted-mcp/README.md
loct impact vibecrafted-mcp/README.md
loct context --file vibecrafted-mcp/README.md
```

### Verification gates (run before any commit)

- `make test` (SemanticGuess)
- `make check` (SemanticGuess)
- `mypy .` (SemanticGuess)
- `python -m pytest` (SemanticGuess)

### Likely tests for current scope

- `vibecrafted-mcp/tests/__init__.py` (LoctreeDerived)
- `vibecrafted-mcp/tests/conftest.py` (LoctreeDerived)
- `vibecrafted-mcp/tests/test_server.py` (LoctreeDerived)

## Authority Index

_90 total claims tagged with provenance._

- **RepoVerified** (2) — AST + git state derivation
- **LoctreeDerived** (36) — snapshot edges + idiom catalogs
- **AicxOperator** (0) — operator decisions / intents from AICX
- **AicxAgent** (48) — agent outcomes (verify before propagating)
- **AicxFailure** (2) — anti-recommendations (avoid repeating)
- **SemanticGuess** (2) — heuristic only, low trust
- **StaleOrUnknown** (0) — explicit "we don't know"


---

*`loct context` rendered in 8233ms · sections: where=33L · live=19L · memory=24L · `--full` for full ContextPack data · `--file <X>` to narrow scope*
