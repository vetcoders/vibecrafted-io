# Loctree Context · vibecrafted @ feat/runtime-integration · 2026-06-07T23:43:46.195094Z

_617 files · 398 import edges · snapshot fresh · dirty worktree_

## TL;DR — read this first

**What this is.** `vibecrafted` repository — current focus: _Runtime Integration_.

**Where you stand.** Branch `feat/runtime-integration`, dirty worktree, snapshot fresh.
Last 5 commits: `216f180 [claude/interactive] fix(skills): add Code-Derived Application Map to vc-justdo + vc-scaffold gates` · `60b0bde [claude/interactive] fix(install): wire shell rc on every machine for one truth after install-all` · `be044ea [claude/interactive] fix(test): stage marbles_spawn.sh under runtime/scripts in fixtures`
Active intent (AICX): "{"call_id":"call_yw5VKW9ST4pM1a4TjNaMcj0R","changes":{"/Users/maciejgad/vc-workspace/vetcoders/vibecrafted/plans/2026-06-05-workflow-runtime-extraction.md":{"content":"---\nstatus: draft\nowner: codex\ndate: 2026-06-05\nvector: stabilize\n---\n\n# Workflow Runtime Extraction\n\n## Current State\n\nWorkflow runtime truth is split across:\n\n- `skills/<workflow>/SKILL.md`, `FLOW.md`, references, templates, and agent YAML.\n- `skills/vc-agents/shell/lib/*." — codex on 2026-06-05.
**Scope.** `path:vibecrafted-vm` -> path:vibecrafted-vm (7 files, fingerprint: 3d79743b1e71).

**Top 3 things to know before editing.**
1. Hub `vibecrafted-vm/wizard/vc-onboard.py` has 3 importers — touching it = wide blast radius (of 30 ranked hubs). (LoctreeDerived)
2. Worktree is dirty — auto-scope mirrors uncommitted edits, not committed state. (RepoVerified)
3. Active memory says `{"call_id":"call_yw5VKW9ST4pM1a4TjNaMcj0R","changes":{"/Users/maciejgad/vc-workspace/vetcoders/vibecrafted/plans/2026-06-05-workflow-runtime-extraction.md":{"content":"---\nstatus: draft\nowner: codex\ndate: 2026-06-05\nvector: stabilize\n---\n\n# Workflow Runtime Extraction\n\n## Current State\n\nWorkflow runtime truth is split across:\n\n- `skills/<workflow>/SKILL.md`, `FLOW.md`, references, templates, and agent YAML.\n- `skills/vc-agents/shell/lib/*.` — codex on 2026-06-05. (AicxOperator)

**Snapshot facts.** 30 hubs · 3 idiom tag(s) · 0 dispatch edge(s) · 21 env contract(s) · 50 memory entries · 107 authority claim(s).

**What's stale.** None.

## Where You Are

### Hubs — touch = blast radius

| File | Importers | Authority |
|---|---:|---|
| `vibecrafted-vm/wizard/vc-onboard.py` | 3 | LoctreeDerived |
| `vibecrafted-vm/entry.sh` | 1 | LoctreeDerived |

### Cycles

- not_measured (run `loct cycles` for current measurement) (LoctreeDerived)

### Recently active surface (last 24h)

- `.github/workflows/portable.yml` (RepoVerified)
- `.gitignore` (RepoVerified)
- `.junie/plans/decompose-vetcoders-shell-runtime.md` (RepoVerified)
- `.loctignore` (RepoVerified)
- `CHANGELOG.md` (RepoVerified)
- `Makefile` (RepoVerified)
- `agents/scripts/install-shell.sh` (RepoVerified)
- `agents/scripts/lib/meta.sh` (RepoVerified)
- `agents/scripts/skills_sync.sh` (RepoVerified)
- `agents/shell/lib/atuin.sh` (RepoVerified)

### Risk metrics

- dead_exports: not_measured (use-graph counts `pub use` re-exports as live — known limitation; run `loct dead` for current count) (RepoVerified)
- twins: not_measured (run `loct twins` for a context-classified pass) (RepoVerified)
- cache_scope: `Scoped("3d79743b1e71")` (RepoVerified)
- high_fan_in: 0 over threshold 10 (LoctreeDerived)

## What's Live

### Idiom tag clusters (top 10 by hit count)

- `idiom:shell-helper` (3 hits) — log/warn/main shell helpers (LoctreeDerived)

### Dispatch edges (top 5 by reach)

- _no dispatch edges in scope_ (LoctreeDerived)

### Env contracts (vars used in scope)

- `BASH_SOURCE` — used in 60 file(s) (LoctreeDerived)
- `BLUE` — used in 1 file(s) (LoctreeDerived)
- `DEST` — used in 1 file(s) (LoctreeDerived)
- `GREEN` — used in 1 file(s) (LoctreeDerived)
- `HOSTNAME_DEFAULT` — used in 1 file(s) (LoctreeDerived)
- `LOCTREE_GPG_KEY_ID` — used in 2 file(s) (LoctreeDerived)
- `NC` — used in 1 file(s) (LoctreeDerived)
- `RUNTIME_DIR` — used in 1 file(s) (LoctreeDerived)
- `SCRIPT_DIR` — used in 26 file(s) (LoctreeDerived)
- `TAILSCALED_PID` — used in 1 file(s) (LoctreeDerived)

### Reachability (top 5 widely-reached symbols)

- `vibecrafted-vm/entry.sh::log` — reason: `dispatch_handler:case_statement:scripts/install-hammerspoon.sh` (LoctreeDerived)
- `vibecrafted-vm/entry.sh::ok` — reason: `dispatch_handler:case_statement:tests/hammerspoon_smoke.sh` (LoctreeDerived)
- `vibecrafted-vm/entry.sh::warn` — reason: `dispatch_handler:case_statement:scripts/install-foundations.sh` (LoctreeDerived)
- `vibecrafted-vm/wizard/vc-onboard.py::main` — reason: `idiom_runtime_role:primary_entrypoint` (SemanticGuess)

## Memory

### Recent decisions / intents / outcomes (last 168h, top by relevance)

1. `outcome` · codex · 2026-06-05 · _{"call_id":"call_yw5VKW9ST4pM1a4TjNaMcj0R","changes":{"/Users/maciejgad/vc-workspace/vetcoders/vibecrafted/plans/2026-06-05-workflow-runtime-extraction.md":{"content":"---\nstatus: draft\nowner: codex\ndate: 2026-06-05\nvector: stabilize\n---\n\n# Workflow Runtime Extraction\n\n## Current State\n\nWorkflow runtime truth is split across:\n\n- `skills/<workflow>/SKILL.md`, `FLOW.md`, references, templates, and agent YAML.\n- `skills/vc-agents/shell/lib/*._ (AicxAgent) — chunk: `chunk:70c2d1cc`
2. `outcome` · codex · 2026-06-05 · _{"call_id":"call_Zgu0iBG7LARhjX81VPejY5ZT","changes":{"/Users/maciejgad/vc-workspace/vetcoders/vibecrafted/tests/tui/test_runtime_regressions.py":{"content":"from __future__ import annotations\n\nimport os\nimport subprocess\nfrom pathlib import Path\n\nfrom scripts import vetcoders_install\n\nREPO_ROOT = Path(__file__).resolve().parents[2]\nSHELL_SH = REPO_ROOT / \"skills\" / \"vc-agents\" / \"shell\" / \"vetcoders._ (AicxAgent) — chunk: `chunk:3ec05ea4`
3. `outcome` · codex · 2026-06-05 · _{"completed_at":1780688474,"duration_ms":33780,"last_agent_message":"Przeczytane w całości: 5 scope contextów, 814 linii.\n\nNajważniejszy obraz:\n\n- `vibecrafted-app`: największy blast radius. Szczególnie `mux-agent/src/config.rs`, `scan.rs`, `state.rs`; realne testy Rust do odpalenia przy zmianach.\n- `vibecrafted-core`: runtime serce. `__init__.py`, `events.py`, `runtime_paths.py`, `spawn.py`, `control_plane.py`, `workflow.py` są główne punkty ryzyka._ (AicxAgent) — chunk: `chunk:48e118ea`
4. `outcome` · codex · 2026-06-05 · _{"call_id":"call_bblBJaGbGyWr844kizcowVhV","changes":{"/Users/maciejgad/vc-workspace/vetcoders/vibecrafted/templates/hooks/config/template.husky.env":{"move_path":null,"type":"update","unified_diff":"@@ -112,3 +112,3 @@\n # Require the full agent/runtime footer used by Vibecrafted local commits:\n-# Authored-By, session_id, timestamp, and runtime.\n+# Authored-By, session_id, time, and runtime.\n HUSKY_COMMIT_MSG_REQUIRE_AGENT_RUNTIME=1\n"}},"status":"completed","stderr":"" …_ (AicxAgent) — chunk: `chunk:c0c007e3`
5. `outcome` · codex · 2026-06-05 · _{"call_id":"call_TKZufkchVyxQDHUHvNlgY0x4","changes":{"/Users/maciejgad/vc-workspace/vetcoders/vibecrafted/vibecrafted-app/AGENTS.md":{"move_path":null,"type":"update","unified_diff":"@@ -132,3 +132,3 @@\n session_id: 019e93be-379d-7303-9ad4-ffae468db99f\n-timestamp: 2026_0604_1408_MDT\n+time: 2026-06-05T12:52:47-06:00\n runtime: iterm2\n"}},"status":"completed","stderr":"","stdout":"Success. Updated the following files:\nM vibecrafted-app/AGENTS._ (AicxAgent) — chunk: `chunk:ee1abbee`
6. `outcome` · codex · 2026-06-05 · _{"completed_at":1780697273,"duration_ms":25193,"last_agent_message":"Tak, teraz mam już te MCP-y działające po stronie Codexa.\n\nKonkretnie: po zmianie configu i odświeżeniu tool discovery `loctree-mcp` wystawił namespace `mcp__loctree_mcp`, a realny smoke-test przeszedł:\n\n```text\nslice scripts/vetcoders_install.py\ncore_loc: 5482\ndependencies: scripts/installer_brand.py, scripts/runtime_paths.py\nconsumer: scripts/build_marketplace_bundle._ (AicxAgent) — chunk: `chunk:a5e67bf9`
7. `outcome` · codex · 2026-06-05 · _{"call_id":"call_p9qbOIr7RiVgfjIbiBCn3Lfq","changes":{"/Users/maciejgad/vc-workspace/vetcoders/vibecrafted/scripts/hooks/commit-msg":{"move_path":null,"type":"update","unified_diff":"@@ -100,2 +100,3 @@\n printf '\\nSession id discovery:\\n' >&2\n+# shellcheck disable=SC2016\n printf '%s\\n' ' echo \"${CODEX_SESSION_ID:-${CLAUDE_CODE_SESSION_ID:-${ATUIN_SESSION:-}}}\"' >&2\n"}},"status":"completed","stderr":"","stdout":"Success._ (AicxAgent) — chunk: `chunk:33289e42`
8. `outcome` · codex · 2026-06-05 · _{"call_id":"call_yXexjmv8hLwkj6hI3AjCmK6m","changes":{"/Users/maciejgad/vc-workspace/vetcoders/vibecrafted/docs/runtime/CONTRACT.md":{"move_path":null,"type":"update","unified_diff":"@@ -231,3 +231,3 @@\n ```bash\n-PLAN=\"$VIBECRAFTED_ROOT/.vibecrafted/artifacts/<org>/<repo>/<YYYY_MMDD>/plans/<plan>.md\"\n+PLAN=\"$VIBECRAFTED_HOME/artifacts/<org>/<repo>/<YYYY_MMDD>/plans/<plan>.md\"\n bash $VIBECRAFTED_ROOT/agents/scripts/codex_spawn._ (AicxAgent) — chunk: `chunk:c15b5f45`
9. `outcome` · codex · 2026-06-05 · _{"call_id":"call_REbyqsjtwdT3GhYZxO7hcpA8","changes":{"/Users/maciejgad/vc-workspace/vetcoders/vibecrafted/agents/scripts/lib/meta.sh":{"move_path":null,"type":"update","unified_diff":"@@ -530,3 +530,3 @@\n def move_artifact(source: pathlib.Path, target: pathlib.Path) -> pathlib.Path:\n- if not str(source) or not source.exists() or same_file(source, target):\n+ if not str(source) or not source.is_file() or same_file(source, target):\n return source\n"}},"status":"completed" …_ (AicxAgent) — chunk: `chunk:593db89b`
10. `outcome` · codex · 2026-06-05 · _{"call_id":"call_Jxj2YRqlNuRSMKBeGRMgzrr9","changes":{"/Users/maciejgad/vc-workspace/vetcoders/vibecrafted/skills/vc-operator/DISPATCH.md":{"move_path":null,"type":"update","unified_diff":"@@ -224,3 +224,3 @@\n `Authored-By: claude <agents@vetcoders.io>`, `session_id: <uuid>`,\n- `timestamp: YYYY_MMDD_HHMM_TZ`, and `runtime: <runtime>`.\n+ `time: YYYY-MM-DDTHH:MM:SS±HH:MM`, and `runtime: <runtime>`._ (AicxAgent) — chunk: `chunk:ee1abbee`
11. `outcome` · codex · 2026-06-05 · _{"call_id":"call_1qHmwID1ITTfwtssFAQlGEqO","changes":{"/Users/maciejgad/vc-workspace/vetcoders/vibecrafted/scripts/hooks/commit-msg":{"move_path":null,"type":"update","unified_diff":"@@ -11,3 +11,3 @@\n # session_id: 019e93be-379d-7303-9ad4-ffae468db99f\n-# timestamp: 2026_0604_1408_MDT\n+# time: 2026-06-05T12:52:47-06:00\n # runtime: iterm2\n@@ -55,6 +55,10 @@\n \n-if ! grep -Eq '^timestamp: [0-9]{4}_[0-9]{4}_[0-9]{4}_[A-Za-z0-9_+-]+$' \"$msg_file\" …_ (AicxAgent) — chunk: `chunk:c38b08d0`
12. `outcome` · codex · 2026-06-05 · _{"call_id":"call_COkyoeDnkYbIBQYkqbdTvuTR","changes":{"/Users/maciejgad/vc-workspace/vetcoders/vibecrafted/tests/tui/test_runtime_regressions.py":{"move_path":null,"type":"update","unified_diff":"@@ -104,3 +104,4 @@\n command_body = command_script.read_text(encoding=\"utf-8\")\n- assert \"codex resume sess-123 'carry on'\" in command_body\n+ assert \"codex resume sess-123\" in command_body\n+ assert \"carry on\" in command_body\n \n"}},"status":"completed","stderr":"" …_ (AicxAgent) — chunk: `chunk:64af7c87`
13. `outcome` · codex · 2026-06-05 · _{"call_id":"call_pu7tZmrGyL29AWm94vAz8BHA","changes":{"/Users/maciejgad/vc-workspace/vetcoders/vibecrafted/skills/vc-agents/shell/lib/marbles.sh":{"move_path":null,"type":"update","unified_diff":"@@ -147,3 +147,29 @@\n local resume_prompt...[truncated]_ (AicxAgent) — chunk: `chunk:1fc23fa1`
14. `outcome` · codex · 2026-06-05 · _{"completed_at":1780698472,"duration_ms":7843,"last_agent_message":"Tak, to jest jeszcze lepsze, bo domyka ścieżkę awaryjną bez dramatu:\n\n```text\nMCP transport likely went stale/down. Refresh tool discovery with tool_search for the affected MCP, then rerun your call. Fallback to CLI <command> if still broken.\n```\n\nDla loctree konkretnie:\n\n```text\nMCP transport likely went stale/down. Refresh tool discovery with tool_search(\"loctree repo-view slice context …_ (AicxAgent) — chunk: `chunk:b86509a1`
15. `outcome` · codex · 2026-06-05 · _{"completed_at":1780696648,"duration_ms":17197,"last_agent_message":"No, nie jest ładny. Jest “działa, ale przez przypadek i zależnie od rodzaju shella”.\n\nNajgorsze sygnały:\n\n- `vibecrafted`, `vc-init`, `vc-workflow`, `vc-dashboard` są **missing** w normalnym `/bin/zsh -c`.\n- `vc-init` pojawia się dopiero w `zsh -ic` jako **shell function**, nie command.\n- `PATH` w non-interactive i interactive shellu ma inną kolejność.\n- `~/.codex/tmp/arg0/..._ (AicxAgent) — chunk: `chunk:99c4fcee`

### Source chunk pointers

_36 unique chunk(s) reachable via `aicx open <chunk:ref>` (resolved against the operator's local aicx store; absolute paths intentionally redacted to keep this context-pack commitable)._

## Action

### Next safe commands (grounded, ≤3)

```bash
loct slice vibecrafted-vm/README.md
loct impact vibecrafted-vm/README.md
loct context --file vibecrafted-vm/README.md
```

### Verification gates (run before any commit)

- `make test` (SemanticGuess)
- `make check` (SemanticGuess)
- `mypy .` (SemanticGuess)
- `python -m pytest` (SemanticGuess)

### Likely tests for current scope

- _no tests directly cover the current scope._ (LoctreeDerived)

## Authority Index

_107 total claims tagged with provenance._

- **RepoVerified** (2) — AST + git state derivation
- **LoctreeDerived** (54) — snapshot edges + idiom catalogs
- **AicxOperator** (0) — operator decisions / intents from AICX
- **AicxAgent** (48) — agent outcomes (verify before propagating)
- **AicxFailure** (2) — anti-recommendations (avoid repeating)
- **SemanticGuess** (1) — heuristic only, low trust
- **StaleOrUnknown** (0) — explicit "we don't know"


---

*`loct context` rendered in 9093ms · sections: where=33L · live=30L · memory=24L · `--full` for full ContextPack data · `--file <X>` to narrow scope*
