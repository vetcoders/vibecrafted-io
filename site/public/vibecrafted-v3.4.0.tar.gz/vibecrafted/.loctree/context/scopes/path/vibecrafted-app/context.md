# Loctree Context Pack

## Project Identity

- **Root**: `/Users/maciejgad/vc-workspace/vetcoders/vibecrafted`
- **Branch**: `feat/runtime-integration`
- **Commit**: `9f76009`
- **Snapshot**: `feat_runtime-integration@9f76009`

## Where You Are

### Files

| Path | Role | Language | LOC | Authority |
|---|---|---|---|---|
| `bin/vc-sandbox` | `Dependency` | py | 54 | *RepoVerified* |
| `plugins/iterm2/vibecrafted_iterm2/vc_launcher.py` | `Dependency` | py | 268 | *RepoVerified* |
| `plugins/iterm2/vibecrafted_iterm2/vc_status_bar.py` | `Dependency` | py | 116 | *RepoVerified* |
| `runtime/scripts/await.sh` | `Dependency` | shell | 521 | *RepoVerified* |
| `runtime/scripts/codex_stream_bridge.py` | `Dependency` | py | 199 | *RepoVerified* |
| `runtime/scripts/marbles_ctl.sh` | `Dependency` | shell | 514 | *RepoVerified* |
| `scripts/bootstrap-modal.sh` | `Dependency` | shell | 303 | *RepoVerified* |
| `scripts/build_marketplace_bundle.py` | `Dependency` | py | 309 | *RepoVerified* |
| `scripts/check_shell.py` | `Dependency` | py | 176 | *RepoVerified* |
| `scripts/control_plane_launch.py` | `Dependency` | py | 12 | *RepoVerified* |
| `scripts/control_plane_state.py` | `Dependency` | py | 31 | *RepoVerified* |
| `scripts/install-foundations.sh` | `Dependency` | shell | 779 | *RepoVerified* |
| `scripts/install-hammerspoon.sh` | `Dependency` | shell | 157 | *RepoVerified* |
| `scripts/installer/vetcoders_installer/__init__.py` | `Dependency` | py | 1229 | *RepoVerified* |
| `scripts/installer_brand.py` | `Dependency` | py | 23 | *RepoVerified* |
| `scripts/installer_gui.py` | `Dependency` | py | 2709 | *RepoVerified* |
| `scripts/runtime_paths.py` | `Dependency` | py | 12 | *RepoVerified* |
| `scripts/vc-dashboard` | `Dependency` | shell | 257 | *RepoVerified* |
| `scripts/version_bump.py` | `Dependency` | py | 65 | *RepoVerified* |
| `scripts/vetcoders_install.py` | `Dependency` | py | 5764 | *RepoVerified* |
| `scripts/vibecrafted` | `Dependency` | shell | 2619 | *RepoVerified* |
| `tools/scripts/chat/chat-cli.py` | `Dependency` | py | 424 | *RepoVerified* |
| `tools/scripts/github/repo-transfer.py` | `Dependency` | py | 900 | *RepoVerified* |
| `vibecrafted-app/AGENTS.md` | `Target` | md | 180 | *RepoVerified* |
| `vibecrafted-app/Cargo.toml` | `Target` | toml | 24 | *RepoVerified* |
| `vibecrafted-app/Makefile` | `Target` | make | 50 | *RepoVerified* |
| `vibecrafted-app/README.md` | `Target` | md | 81 | *RepoVerified* |
| `vibecrafted-app/docs/plans/PLAN_22_NEXT_OPERATOR_MISSION_CONTROL.md` | `Target` | md | 432 | *RepoVerified* |
| `vibecrafted-app/docs/plans/PLAN_23_AGENT_OPERATOR_DASHBOARD.md` | `Target` | md | 350 | *RepoVerified* |
| `vibecrafted-app/mux-agent/AI_README.md` | `Target` | md | 335 | *RepoVerified* |
| `vibecrafted-app/mux-agent/CHANGELOG.md` | `Target` | md | 172 | *RepoVerified* |
| `vibecrafted-app/mux-agent/Cargo.toml` | `Target` | toml | 66 | *RepoVerified* |
| `vibecrafted-app/mux-agent/Makefile` | `Target` | make | 109 | *RepoVerified* |
| `vibecrafted-app/mux-agent/README.md` | `Target` | md | 318 | *RepoVerified* |
| `vibecrafted-app/mux-agent/docs/WIZARD.md` | `Target` | md | 318 | *RepoVerified* |
| `vibecrafted-app/mux-agent/docs/dev/guidelines.md` | `Target` | md | 659 | *RepoVerified* |
| `vibecrafted-app/mux-agent/docs/integration.md` | `Target` | md | 343 | *RepoVerified* |
| `vibecrafted-app/mux-agent/docs/vc-agents-client-discovery-plan.md` | `Target` | md | 183 | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/bin/rmcp-mux-proxy.rs` | `Target` | rs | 101 | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/bin/rmcp-mux.rs` | `Target` | rs | 424 | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/config.rs` | `Target` | rs | 520 | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/danger.rs` | `Consumer` | rs | 878 | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/ipc/command.rs` | `Target` | rs | 57 | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/ipc/context.rs` | `Target` | rs | 23 | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/ipc/event.rs` | `Dependency` | rs | 42 | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/ipc/handlers.rs` | `Consumer` | rs | 76 | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/ipc/mod.rs` | `Consumer` | rs | 10 | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/ipc/server.rs` | `Consumer` | rs | 288 | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/jsonl_bridge.rs` | `Consumer` | rs | 208 | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/lib.rs` | `Consumer` | rs | 629 | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/main.rs` | `Consumer` | rs | 187 | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/multi.rs` | `Consumer` | rs | 126 | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/multi_tui.rs` | `Dependency` | rs | 397 | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/mux_gen.rs` | `Consumer` | rs | 787 | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/runtime/client.rs` | `Dependency` | rs | 372 | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/runtime/heartbeat.rs` | `Dependency` | rs | 430 | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/runtime/mod.rs` | `Consumer` | rs | 416 | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/runtime/proxy.rs` | `Dependency` | rs | 101 | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/runtime/server.rs` | `Dependency` | rs | 350 | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/runtime/status.rs` | `Dependency` | rs | 363 | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/runtime/tests.rs` | `Consumer` | rs | 1080 | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/runtime/types.rs` | `Dependency` | rs | 15 | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/scan.rs` | `Consumer` | rs | 1534 | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/state.rs` | `Dependency` | rs | 381 | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/tray.rs` | `Dependency` | rs | 338 | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/tray_dashboard.rs` | `Consumer` | rs | 331 | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/wizard/keys.rs` | `Dependency` | rs | 836 | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/wizard/mod.rs` | `Consumer` | rs | 389 | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/wizard/persist.rs` | `Consumer` | rs | 697 | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/wizard/services.rs` | `Consumer` | rs | 504 | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/wizard/types.rs` | `Consumer` | rs | 227 | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/wizard/ui.rs` | `Dependency` | rs | 801 | *RepoVerified* |
| `vibecrafted-app/mux-agent/tests/jsonl_bridge_test.rs` | `Target` | rs | 85 | *RepoVerified* |
| `vibecrafted-app/mux-agent/tools/githooks/pre-commit` | `Target` | shell | 26 | *RepoVerified* |
| `vibecrafted-app/mux-agent/tools/githooks/pre-push` | `Target` | shell | 45 | *RepoVerified* |
| `vibecrafted-app/mux-agent/tools/install-githooks.sh` | `Target` | shell | 19 | *RepoVerified* |
| `vibecrafted-app/mux-agent/tools/install.sh` | `Target` | shell | 86 | *RepoVerified* |
| `vibecrafted-app/mux-agent/tools/setup_hooks.sh` | `Target` | shell | 6 | *RepoVerified* |
| `vibecrafted-app/shell-agent/Makefile` | `Target` | make | 68 | *RepoVerified* |
| `vibecrafted-app/shell-agent/app/Vibecrafted/AppDelegate.swift` | `Consumer` | swift | 161 | *RepoVerified* |
| `vibecrafted-app/shell-agent/app/Vibecrafted/Bridge/vibecrafted_shell_ffi.swift` | `Dependency` | swift | 1447 | *RepoVerified* |
| `vibecrafted-app/shell-agent/app/Vibecrafted/Views/CanvasViewController.swift` | `Consumer` | swift | 179 | *RepoVerified* |
| `vibecrafted-app/shell-agent/app/Vibecrafted/Views/InspectorViewController.swift` | `Consumer` | swift | 150 | *RepoVerified* |
| `vibecrafted-app/shell-agent/app/Vibecrafted/Views/MainSplitViewController.swift` | `Dependency` | swift | 30 | *RepoVerified* |
| `vibecrafted-app/shell-agent/app/Vibecrafted/Views/MainWindowController.swift` | `Dependency` | swift | 80 | *RepoVerified* |
| `vibecrafted-app/shell-agent/app/Vibecrafted/Views/SidebarViewController.swift` | `Consumer` | swift | 145 | *RepoVerified* |
| `vibecrafted-app/shell-agent/app/Vibecrafted/main.swift` | `Dependency` | swift | 5 | *RepoVerified* |
| `vibecrafted-app/shell-agent/app/project.yml` | `Target` | yml | 70 | *RepoVerified* |
| `vibecrafted-app/shell-agent/ffi/Cargo.toml` | `Target` | toml | 21 | *RepoVerified* |
| `vibecrafted-app/shell-agent/ffi/build.rs` | `Target` | rs | 3 | *RepoVerified* |
| `vibecrafted-app/shell-agent/ffi/src/lib.rs` | `Dependency` | rs | 599 | *RepoVerified* |
| `vibecrafted-app/shell-agent/scripts/build-dmg.sh` | `Target` | shell | 110 | *RepoVerified* |
| `vibecrafted-app/shell-agent/scripts/build-rust-binaries.sh` | `Target` | shell | 31 | *RepoVerified* |
| `vibecrafted-app/shell-agent/scripts/build-rust.sh` | `Target` | shell | 18 | *RepoVerified* |
| `vibecrafted-app/shell-agent/scripts/fix-dylib-install-names.sh` | `Target` | shell | 40 | *RepoVerified* |
| `vibecrafted-app/shell-agent/scripts/normalize-bindings.sh` | `Target` | shell | 10 | *RepoVerified* |
| `vibecrafted-app/shell-agent/uniffi-bindgen/Cargo.toml` | `Target` | toml | 10 | *RepoVerified* |
| `vibecrafted-app/shell-agent/uniffi-bindgen/src/main.rs` | `Target` | rs | 3 | *RepoVerified* |
| `vibecrafted-app/tray-agent/Cargo.toml` | `Target` | toml | 30 | *RepoVerified* |
| `vibecrafted-app/tray-agent/src/bin/vc-mux-tray.rs` | `Target` | rs | 54 | *RepoVerified* |
| `vibecrafted-app/tray-agent/src/handlers.rs` | `Dependency` | rs | 259 | *RepoVerified* |
| `vibecrafted-app/tray-agent/src/icons.rs` | `Dependency` | rs | 81 | *RepoVerified* |
| `vibecrafted-app/tray-agent/src/ipc_client.rs` | `Dependency` | rs | 220 | *RepoVerified* |
| `vibecrafted-app/tray-agent/src/lib.rs` | `Dependency` | rs | 106 | *RepoVerified* |
| `vibecrafted-app/tray-agent/src/menu.rs` | `Dependency` | rs | 200 | *RepoVerified* |
| `vibecrafted-app/tray-agent/src/state.rs` | `Dependency` | rs | 84 | *RepoVerified* |
| `vibecrafted-app/tray-agent/src/types.rs` | `Dependency` | rs | 133 | *RepoVerified* |
| `vibecrafted-app/tray-agent/tests/ipc_client.rs` | `Target` | rs | 94 | *RepoVerified* |
| `vibecrafted-app/tray-agent/tests/spawn_update_render_test.rs` | `Target` | rs | 30 | *RepoVerified* |
| `vibecrafted-app/tui-agent/Cargo.toml` | `Target` | toml | 39 | *RepoVerified* |
| `vibecrafted-app/tui-agent/README.md` | `Target` | md | 114 | *RepoVerified* |
| `vibecrafted-app/tui-agent/audits/historical/2026-04-19_next-steps-agnostic.md` | `Target` | md | 54 | *RepoVerified* |
| `vibecrafted-app/tui-agent/audits/historical/2026-04-19_next-steps-ghostty.md` | `Target` | md | 49 | *RepoVerified* |
| `vibecrafted-app/tui-agent/audits/historical/2026-04-29_vc-intents.md` | `Target` | md | 72 | *RepoVerified* |
| `vibecrafted-app/tui-agent/audits/historical/2026-04-30_vc-review.md` | `Target` | md | 64 | *RepoVerified* |
| `vibecrafted-app/tui-agent/src/app.rs` | `Dependency` | rs | 1354 | *RepoVerified* |
| `vibecrafted-app/tui-agent/src/bin/vc_admin.rs` | `Target` | rs | 502 | *RepoVerified* |
| `vibecrafted-app/tui-agent/src/config.rs` | `Dependency` | rs | 237 | *RepoVerified* |
| `vibecrafted-app/tui-agent/src/launch.rs` | `Dependency` | rs | 517 | *RepoVerified* |
| `vibecrafted-app/tui-agent/src/lib.rs` | `Consumer` | rs | 905 | *RepoVerified* |
| `vibecrafted-app/tui-agent/src/main.rs` | `Target` | rs | 3 | *RepoVerified* |
| `vibecrafted-app/tui-agent/src/mission_control.rs` | `Dependency` | rs | 2706 | *RepoVerified* |
| `vibecrafted-app/tui-agent/src/mux.rs` | `Dependency` | rs | 886 | *RepoVerified* |
| `vibecrafted-app/tui-agent/src/polarize.rs` | `Dependency` | rs | 233 | *RepoVerified* |
| `vibecrafted-app/tui-agent/src/skills_catalog.rs` | `Dependency` | rs | 272 | *RepoVerified* |
| `vibecrafted-app/tui-agent/src/state.rs` | `Dependency` | rs | 468 | *RepoVerified* |
| `vibecrafted-app/tui-agent/src/ui.rs` | `Consumer` | rs | 1692 | *RepoVerified* |
| `vibecrafted-app/tui-agent/tests/launch_readiness.rs` | `Target` | rs | 379 | *RepoVerified* |
| `vibecrafted-app/tui-agent/tests/mission_control_snapshots.rs` | `Target` | rs | 835 | *RepoVerified* |
| `vibecrafted-app/tui-agent/tests/skill_launcher.rs` | `Target` | rs | 315 | *RepoVerified* |
| `vibecrafted-app/tui-agent/tests/state_contract.rs` | `Target` | rs | 1940 | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/__init__.py` | `Dependency` | py | 111 | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/agent_dispatch.py` | `Dependency` | py | 296 | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/agent_stream.py` | `Dependency` | py | 509 | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/cli.py` | `Dependency` | py | 422 | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/compact_hooks.py` | `Dependency` | py | 475 | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/control_plane.py` | `Dependency` | py | 1267 | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/cron.py` | `Dependency` | py | 373 | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/dispatch/cli.py` | `Dependency` | py | 239 | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/dispatch/doctor.py` | `Dependency` | py | 82 | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/dispatch/model.py` | `Dependency` | py | 255 | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/dispatch/schema.py` | `Dependency` | py | 508 | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/dispatch/supervisor.py` | `Dependency` | py | 776 | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/dispatcher.py` | `Dependency` | py | 129 | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/events.py` | `Dependency` | py | 24 | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/loop.py` | `Dependency` | py | 336 | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/runtime_paths.py` | `Dependency` | py | 53 | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/sandbox/__init__.py` | `Dependency` | py | 12 | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/sandbox/policy.py` | `Dependency` | py | 131 | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/ship.py` | `Dependency` | py | 98 | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/spawn.py` | `Dependency` | py | 1141 | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/supervisor_async.py` | `Dependency` | py | 605 | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/ui.py` | `Dependency` | py | 149 | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/workflow.py` | `Dependency` | py | 1429 | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/wrappers.py` | `Dependency` | py | 440 | *RepoVerified* |
| `vibecrafted-mcp/vibecrafted_mcp/server.py` | `Dependency` | py | 801 | *RepoVerified* |
| `vibecrafted-server/web/src/theme.rs` | `Dependency` | rs | 102 | *RepoVerified* |
| `vibecrafted-vm/entry.sh` | `Dependency` | shell | 128 | *RepoVerified* |
| `vibecrafted-vm/wizard/vc-onboard.py` | `Dependency` | py | 583 | *RepoVerified* |

### Symbols

| File | Name | Kind | Export Type | Line | Authority |
|---|---|---|---|---|---|
| `vibecrafted-app/Makefile` | `.PHONY` | special_target | named | 1 | *RepoVerified* |
| `vibecrafted-app/Makefile` | `HELP_C_CYAN` | var | named | 44 | *RepoVerified* |
| `vibecrafted-app/Makefile` | `HELP_C_GREEN` | var | named | 45 | *RepoVerified* |
| `vibecrafted-app/Makefile` | `HELP_C_RESET` | var | named | 47 | *RepoVerified* |
| `vibecrafted-app/Makefile` | `HELP_C_YELLOW` | var | named | 46 | *RepoVerified* |
| `vibecrafted-app/Makefile` | `app` | target | named | 31 | *RepoVerified* |
| `vibecrafted-app/Makefile` | `app-debug` | target | named | 34 | *RepoVerified* |
| `vibecrafted-app/Makefile` | `bindings` | target | named | 25 | *RepoVerified* |
| `vibecrafted-app/Makefile` | `check` | target | named | 17 | *RepoVerified* |
| `vibecrafted-app/Makefile` | `clean` | target | named | 22 | *RepoVerified* |
| `vibecrafted-app/Makefile` | `dmg` | target | named | 37 | *RepoVerified* |
| `vibecrafted-app/Makefile` | `dmg-signed` | target | named | 40 | *RepoVerified* |
| `vibecrafted-app/Makefile` | `fmt` | target | named | 5 | *RepoVerified* |
| `vibecrafted-app/Makefile` | `fmt-check` | target | named | 8 | *RepoVerified* |
| `vibecrafted-app/Makefile` | `gates` | target | named | 3 | *RepoVerified* |
| `vibecrafted-app/Makefile` | `help` | target | named | 49 | *RepoVerified* |
| `vibecrafted-app/Makefile` | `lint` | target | named | 11 | *RepoVerified* |
| `vibecrafted-app/Makefile` | `test` | target | named | 14 | *RepoVerified* |
| `vibecrafted-app/Makefile` | `workspace-check` | target | named | 19 | *RepoVerified* |
| `vibecrafted-app/Makefile` | `xcode` | target | named | 28 | *RepoVerified* |
| `vibecrafted-app/mux-agent/Makefile` | `.PHONY` | special_target | named | 3 | *RepoVerified* |
| `vibecrafted-app/mux-agent/Makefile` | `CMD` | var | named | 10 | *RepoVerified* |
| `vibecrafted-app/mux-agent/Makefile` | `CMD_ARGS` | var | named | 11 | *RepoVerified* |
| `vibecrafted-app/mux-agent/Makefile` | `CONFIG` | var | named | 7 | *RepoVerified* |
| `vibecrafted-app/mux-agent/Makefile` | `HELP_C_CYAN` | var | named | 16 | *RepoVerified* |
| `vibecrafted-app/mux-agent/Makefile` | `HELP_C_GREEN` | var | named | 17 | *RepoVerified* |
| `vibecrafted-app/mux-agent/Makefile` | `HELP_C_RESET` | var | named | 19 | *RepoVerified* |
| `vibecrafted-app/mux-agent/Makefile` | `HELP_C_YELLOW` | var | named | 18 | *RepoVerified* |
| `vibecrafted-app/mux-agent/Makefile` | `LOG_LEVEL` | var | named | 13 | *RepoVerified* |
| `vibecrafted-app/mux-agent/Makefile` | `SERVICE` | var | named | 8 | *RepoVerified* |
| `vibecrafted-app/mux-agent/Makefile` | `SHELL` | var | named | 1 | *RepoVerified* |
| `vibecrafted-app/mux-agent/Makefile` | `SOCKET` | var | named | 9 | *RepoVerified* |
| `vibecrafted-app/mux-agent/Makefile` | `STATUS_FILE` | var | named | 12 | *RepoVerified* |
| `vibecrafted-app/mux-agent/Makefile` | `build` | target | named | 54 | *RepoVerified* |
| `vibecrafted-app/mux-agent/Makefile` | `check` | target | named | 60 | *RepoVerified* |
| `vibecrafted-app/mux-agent/Makefile` | `clean-runtime` | target | named | 108 | *RepoVerified* |
| `vibecrafted-app/mux-agent/Makefile` | `clippy` | target | named | 69 | *RepoVerified* |
| `vibecrafted-app/mux-agent/Makefile` | `daemon-status` | target | named | 99 | *RepoVerified* |
| `vibecrafted-app/mux-agent/Makefile` | `dashboard` | target | named | 102 | *RepoVerified* |
| `vibecrafted-app/mux-agent/Makefile` | `fmt` | target | named | 63 | *RepoVerified* |
| `vibecrafted-app/mux-agent/Makefile` | `fmt-check` | target | named | 66 | *RepoVerified* |
| `vibecrafted-app/mux-agent/Makefile` | `gates` | target | named | 79 | *RepoVerified* |
| `vibecrafted-app/mux-agent/Makefile` | `health` | target | named | 96 | *RepoVerified* |
| `vibecrafted-app/mux-agent/Makefile` | `help` | target | named | 21 | *RepoVerified* |
| `vibecrafted-app/mux-agent/Makefile` | `proxy` | target | named | 93 | *RepoVerified* |
| `vibecrafted-app/mux-agent/Makefile` | `release` | target | named | 57 | *RepoVerified* |
| `vibecrafted-app/mux-agent/Makefile` | `run` | target | named | 87 | *RepoVerified* |
| `vibecrafted-app/mux-agent/Makefile` | `run-tray` | target | named | 90 | *RepoVerified* |
| `vibecrafted-app/mux-agent/Makefile` | `status-file-init` | target | named | 105 | *RepoVerified* |
| `vibecrafted-app/mux-agent/Makefile` | `test` | target | named | 72 | *RepoVerified* |
| `vibecrafted-app/mux-agent/Makefile` | `test-full` | target | named | 75 | *RepoVerified* |
| `vibecrafted-app/mux-agent/Makefile` | `wizard` | target | named | 81 | *RepoVerified* |
| `vibecrafted-app/mux-agent/Makefile` | `wizard-dry-run` | target | named | 84 | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/config.rs` | `CliOptions` | trait | named | 179 | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/config.rs` | `Config` | struct | named | 12 | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/config.rs` | `ResolvedParams` | struct | named | 41 | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/config.rs` | `ServerConfig` | struct | named | 17 | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/config.rs` | `expand_path` | function | named | 64 | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/config.rs` | `load_config` | function | named | 151 | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/config.rs` | `resolve_params` | function | named | 299 | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/config.rs` | `resolve_params_multi` | function | named | 203 | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/config.rs` | `safe_copy` | function | named | 175 | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/config.rs` | `safe_copy_file` | function | named | 131 | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/config.rs` | `safe_read_to_string` | function | named | 118 | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/config.rs` | `vetted_existing_file` | function | named | 87 | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/danger.rs` | `DangerAction` | struct | named | 55 | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/danger.rs` | `DangerExecutionOutcome` | struct | named | 77 | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/danger.rs` | `DangerPlan` | struct | named | 69 | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/danger.rs` | `DangerStatus` | enum | named | 43 | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/danger.rs` | `execute_plan` | function | named | 361 | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/danger.rs` | `format_preview` | function | named | 280 | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/danger.rs` | `plan_danger_rewrite` | function | named | 92 | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/danger.rs` | `plan_danger_rewrite_for_scans` | function | named | 151 | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/danger.rs` | `rollback_commands` | function | named | 405 | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/ipc/command.rs` | `ClientKind` | enum | named | 5 | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/ipc/command.rs` | `MuxControlCommand` | enum | named | 36 | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/ipc/command.rs` | `MuxControlResponse` | enum | named | 49 | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/ipc/command.rs` | `NonMuxEntry` | struct | named | 20 | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/ipc/command.rs` | `Route` | struct | named | 28 | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/ipc/command.rs` | `VerifyResult` | struct | named | 14 | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/ipc/context.rs` | `MuxControlContext` | struct | named | 11 | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/ipc/context.rs` | `new` | function | named | 17 | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/ipc/event.rs` | `IpcEvent` | enum | named | 7 | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/ipc/handlers.rs` | `handle_command` | function | named | 6 | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/ipc/mod.rs` | `ClientKind` | reexport | named |  | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/ipc/mod.rs` | `IpcEvent` | reexport | named |  | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/ipc/mod.rs` | `MuxControlCommand` | reexport | named |  | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/ipc/mod.rs` | `MuxControlContext` | reexport | named |  | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/ipc/mod.rs` | `MuxControlResponse` | reexport | named |  | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/ipc/mod.rs` | `run_server` | reexport | named |  | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/ipc/mod.rs` | `socket_path` | reexport | named |  | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/ipc/server.rs` | `run_server` | function | named | 27 | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/ipc/server.rs` | `socket_path` | function | named | 12 | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/jsonl_bridge.rs` | `run_jsonl_bridge` | function | named | 20 | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/lib.rs` | `CliOptions` | reexport | named |  | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/lib.rs` | `Config` | reexport | named |  | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/lib.rs` | `DEFAULT_STATUS_SOCKET` | reexport | named |  | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/lib.rs` | `DaemonStatus` | reexport | named |  | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/lib.rs` | `HeartbeatConfig` | reexport | named |  | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/lib.rs` | `MAX_PENDING` | reexport | named |  | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/lib.rs` | `MAX_QUEUE` | reexport | named |  | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/lib.rs` | `ManagedServer` | reexport | named |  | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/lib.rs` | `MultiServerStatus` | reexport | named |  | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/lib.rs` | `MuxConfig` | struct | named | 122 | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/lib.rs` | `MuxHandle` | struct | named | 369 | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/lib.rs` | `MuxState` | reexport | named |  | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/lib.rs` | `NAME` | decl | named | 476 | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/lib.rs` | `ResolvedParams` | reexport | named |  | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/lib.rs` | `ServerCommand` | reexport | named |  | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/lib.rs` | `ServerConfig` | reexport | named |  | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/lib.rs` | `ServerRef` | reexport | named |  | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/lib.rs` | `ServerStatus` | reexport | named |  | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/lib.rs` | `StatusLevel` | reexport | named |  | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/lib.rs` | `StatusSnapshot` | reexport | named |  | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/lib.rs` | `StatusState` | reexport | named |  | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/lib.rs` | `TuiMuxState` | reexport | named |  | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/lib.rs` | `VERSION` | decl | named | 473 | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/lib.rs` | `check_health` | function | named | 442 | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/lib.rs` | `format_uptime` | reexport | named |  | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/lib.rs` | `health_check` | reexport | named |  | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/lib.rs` | `is_running` | function | named | 386 | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/lib.rs` | `new` | function | named | 169 | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/lib.rs` | `print_status_table` | reexport | named |  | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/lib.rs` | `query_status` | reexport | named |  | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/lib.rs` | `resolve_params_multi` | reexport | named |  | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/lib.rs` | `restart_single` | function | named | 580 | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/lib.rs` | `run_multi_tui` | reexport | named |  | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/lib.rs` | `run_mux` | reexport | named |  | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/lib.rs` | `run_mux_multi` | function | named | 488 | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/lib.rs` | `run_mux_server` | function | named | 360 | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/lib.rs` | `run_mux_with_shutdown` | function | named | 432 | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/lib.rs` | `run_proxy` | reexport | named |  | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/lib.rs` | `run_status_listener` | reexport | named |  | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/lib.rs` | `service_name` | function | named | 303 | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/lib.rs` | `shutdown` | function | named | 376 | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/lib.rs` | `spawn_mux_server` | function | named | 412 | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/lib.rs` | `status_all` | function | named | 544 | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/lib.rs` | `wait` | function | named | 381 | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/lib.rs` | `with_args` | function | named | 194 | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/lib.rs` | `with_env` | function | named | 200 | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/lib.rs` | `with_env_var` | function | named | 206 | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/lib.rs` | `with_heartbeat` | function | named | 281 | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/lib.rs` | `with_heartbeat_enabled` | function | named | 297 | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/lib.rs` | `with_heartbeat_max_failures` | function | named | 288 | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/lib.rs` | `with_lazy_start` | function | named | 230 | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/lib.rs` | `with_log_level` | function | named | 224 | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/lib.rs` | `with_max_clients` | function | named | 212 | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/lib.rs` | `with_max_request_bytes` | function | named | 236 | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/lib.rs` | `with_max_restarts` | function | named | 255 | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/lib.rs` | `with_request_timeout` | function | named | 242 | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/lib.rs` | `with_restart_backoff` | function | named | 248 | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/lib.rs` | `with_service_name` | function | named | 218 | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/lib.rs` | `with_status_file` | function | named | 261 | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/lib.rs` | `with_tray` | function | named | 267 | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/multi.rs` | `ManagedServer` | struct | named | 41 | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/multi.rs` | `MultiServerStatus` | struct | named | 26 | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/multi.rs` | `ServerCommand` | enum | named | 18 | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/multi.rs` | `TuiMuxState` | struct | named | 53 | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/multi.rs` | `add_server` | function | named | 71 | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/multi.rs` | `format_uptime` | function | named | 77 | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/multi.rs` | `new` | function | named | 63 | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/multi_tui.rs` | `MultiTuiApp` | struct | named | 27 | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/multi_tui.rs` | `new` | function | named | 38 | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/multi_tui.rs` | `quit` | function | named | 109 | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/multi_tui.rs` | `run_multi_tui` | function | named | 231 | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/multi_tui.rs` | `select_next` | function | named | 83 | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/multi_tui.rs` | `select_previous` | function | named | 65 | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/multi_tui.rs` | `selected_server` | function | named | 101 | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/multi_tui.rs` | `should_quit` | function | named | 114 | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/multi_tui.rs` | `update_statuses` | function | named | 47 | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/mux_gen.rs` | `ClientInstruction` | struct | named | 184 | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/mux_gen.rs` | `MuxFiles` | struct | named | 59 | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/mux_gen.rs` | `MuxOutputs` | struct | named | 44 | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/mux_gen.rs` | `PerClientFile` | struct | named | 352 | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/mux_gen.rs` | `PerClientOutputs` | struct | named | 361 | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/mux_gen.rs` | `build_mux_outputs` | function | named | 68 | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/mux_gen.rs` | `build_per_client_outputs` | function | named | 375 | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/mux_gen.rs` | `default_mux_dir` | function | named | 32 | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/mux_gen.rs` | `default_socket_dir` | function | named | 37 | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/mux_gen.rs` | `per_client_instructions` | function | named | 476 | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/mux_gen.rs` | `safe_path_instructions` | function | named | 132 | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/mux_gen.rs` | `write_mux_outputs` | function | named | 103 | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/mux_gen.rs` | `write_per_client_outputs` | function | named | 448 | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/runtime/client.rs` | `handle_client` | function | named | 29 | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/runtime/client.rs` | `handle_client_message` | function | named | 140 | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/runtime/client.rs` | `update_queue_depth` | function | named | 23 | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/runtime/heartbeat.rs` | `HeartbeatConfig` | struct | named | 26 | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/runtime/heartbeat.rs` | `HeartbeatEvent` | enum | named | 138 | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/runtime/heartbeat.rs` | `HeartbeatInspectorContext` | struct | named | 143 | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/runtime/heartbeat.rs` | `disabled` | function | named | 60 | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/runtime/heartbeat.rs` | `is_heartbeat_response` | function | named | 326 | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/runtime/heartbeat.rs` | `new` | function | named | 50 | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/runtime/heartbeat.rs` | `spawn_heartbeat_inspector` | function | named | 161 | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/runtime/mod.rs` | `DEFAULT_STATUS_SOCKET` | reexport | named |  | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/runtime/mod.rs` | `DaemonStatus` | reexport | named |  | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/runtime/mod.rs` | `HeartbeatConfig` | reexport | named |  | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/runtime/mod.rs` | `HeartbeatEvent` | reexport | named |  | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/runtime/mod.rs` | `HeartbeatInspectorContext` | reexport | named |  | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/runtime/mod.rs` | `MAX_PENDING` | reexport | named |  | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/runtime/mod.rs` | `MAX_QUEUE` | reexport | named |  | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/runtime/mod.rs` | `ServerRef` | reexport | named |  | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/runtime/mod.rs` | `StatusState` | reexport | named |  | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/runtime/mod.rs` | `health_check` | function | named | 85 | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/runtime/mod.rs` | `is_heartbeat_response` | reexport | named |  | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/runtime/mod.rs` | `print_status_table` | reexport | named |  | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/runtime/mod.rs` | `query_status` | reexport | named |  | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/runtime/mod.rs` | `run_mux` | function | named | 144 | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/runtime/mod.rs` | `run_mux_internal` | function | named | 171 | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/runtime/mod.rs` | `run_mux_internal_with_status` | function | named | 179 | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/runtime/mod.rs` | `run_proxy` | reexport | named |  | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/runtime/mod.rs` | `run_status_listener` | reexport | named |  | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/runtime/mod.rs` | `spawn_heartbeat_inspector` | reexport | named |  | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/runtime/mod.rs` | `spawn_status_writer` | reexport | named |  | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/runtime/proxy.rs` | `run_proxy` | function | named | 24 | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/runtime/server.rs` | `ServerManagerChannels` | struct | named | 120 | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/runtime/server.rs` | `ServerManagerConfig` | struct | named | 109 | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/runtime/server.rs` | `ServerManagerState` | struct | named | 127 | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/runtime/server.rs` | `handle_server_message` | function | named | 26 | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/runtime/server.rs` | `server_manager` | function | named | 135 | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/runtime/status.rs` | `DEFAULT_STATUS_SOCKET` | decl | named | 67 | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/runtime/status.rs` | `DaemonStatus` | struct | named | 71 | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/runtime/status.rs` | `ServerRef` | struct | named | 89 | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/runtime/status.rs` | `StatusState` | struct | named | 97 | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/runtime/status.rs` | `collect_status` | function | named | 115 | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/runtime/status.rs` | `new` | function | named | 103 | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/runtime/status.rs` | `print_status_table` | function | named | 277 | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/runtime/status.rs` | `query_status` | function | named | 267 | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/runtime/status.rs` | `register_server` | function | named | 110 | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/runtime/status.rs` | `run_status_listener` | function | named | 202 | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/runtime/status.rs` | `spawn_status_writer` | function | named | 43 | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/runtime/status.rs` | `write_status_file` | function | named | 25 | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/runtime/types.rs` | `MAX_PENDING` | decl | named | 9 | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/runtime/types.rs` | `MAX_QUEUE` | decl | named | 6 | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/runtime/types.rs` | `ServerEvent` | enum | named | 12 | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/scan.rs` | `Confidence` | enum | named | 157 | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/scan.rs` | `ConfigSchema` | enum | named | 144 | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/scan.rs` | `ConflictReport` | struct | named | 211 | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/scan.rs` | `ConflictVariant` | struct | named | 217 | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/scan.rs` | `DiscoveredMcp` | struct | named | 547 | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/scan.rs` | `DiscoveredMcpSource` | enum | named | 541 | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/scan.rs` | `HostFile` | struct | named | 165 | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/scan.rs` | `HostFormat` | enum | named | 132 | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/scan.rs` | `HostKind` | enum | named | 83 | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/scan.rs` | `HostService` | struct | named | 182 | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/scan.rs` | `MergeOutcome` | struct | named | 203 | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/scan.rs` | `RewireArgs` | struct | named | 39 | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/scan.rs` | `RewireOutcome` | struct | named | 225 | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/scan.rs` | `ScanArgs` | struct | named | 17 | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/scan.rs` | `ScanResult` | struct | named | 195 | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/scan.rs` | `StatusArgs` | struct | named | 61 | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/scan.rs` | `as_label` | function | named | 99 | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/scan.rs` | `build_manifest` | function | named | 735 | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/scan.rs` | `default_sources` | function | named | 240 | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/scan.rs` | `discover_hosts` | function | named | 365 | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/scan.rs` | `discover_vibecrafted_mcp` | function | named | 569 | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/scan.rs` | `discover_vibecrafted_mcp_with` | function | named | 576 | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/scan.rs` | `display_name` | function | named | 114 | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/scan.rs` | `format_for_host` | function | named | 728 | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/scan.rs` | `generate_snippet` | function | named | 774 | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/scan.rs` | `host_file_from_custom_path` | function | named | 375 | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/scan.rs` | `into_host_service` | function | named | 556 | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/scan.rs` | `merge_services` | function | named | 628 | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/scan.rs` | `resolve_host_from_args` | function | named | 940 | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/scan.rs` | `resolve_status_host` | function | named | 958 | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/scan.rs` | `rewire_host` | function | named | 838 | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/scan.rs` | `run_rewire_cmd` | function | named | 1040 | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/scan.rs` | `run_scan_cmd` | function | named | 976 | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/scan.rs` | `run_status_cmd` | function | named | 1062 | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/scan.rs` | `scan_host_file` | function | named | 419 | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/scan.rs` | `scan_hosts` | function | named | 527 | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/scan.rs` | `serialize_config` | function | named | 922 | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/scan.rs` | `serialize_snippet` | function | named | 931 | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/scan.rs` | `write_with_backup` | function | named | 904 | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/state.rs` | `ClientHandshake` | struct | named | 138 | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/state.rs` | `HANDSHAKE_TIMEOUT` | decl | named | 45 | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/state.rs` | `HealthStatus` | type | named | 36 | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/state.rs` | `HeartbeatMetrics` | struct | named | 127 | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/state.rs` | `MuxState` | struct | named | 98 | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/state.rs` | `MuxStateConfig` | struct | named | 146 | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/state.rs` | `Pending` | struct | named | 82 | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/state.rs` | `ServerStatus` | enum | named | 11 | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/state.rs` | `StatusLevel` | enum | named | 29 | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/state.rs` | `StatusSnapshot` | struct | named | 56 | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/state.rs` | `buffer_message` | function | named | 246 | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/state.rs` | `complete_handshake` | function | named | 228 | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/state.rs` | `error_response` | function | named | 263 | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/state.rs` | `get_handshake_mut` | function | named | 252 | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/state.rs` | `is_handshake_complete` | function | named | 232 | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/state.rs` | `is_handshake_timed_out` | function | named | 238 | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/state.rs` | `mark_handshake_complete` | function | named | 219 | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/state.rs` | `new` | function | named | 160 | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/state.rs` | `next_request_id` | function | named | 213 | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/state.rs` | `publish_status` | function | named | 305 | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/state.rs` | `register_client` | function | named | 190 | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/state.rs` | `reset_state` | function | named | 328 | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/state.rs` | `set_id` | function | named | 257 | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/state.rs` | `snapshot_for_state` | function | named | 274 | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/state.rs` | `unregister_client` | function | named | 206 | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/tray.rs` | `LoadedIcon` | struct | named | 18 | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/tray.rs` | `TrayUi` | struct | named | 65 | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/tray.rs` | `find_tray_icon` | function | named | 235 | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/tray.rs` | `load_icon_from_file` | function | named | 250 | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/tray.rs` | `spawn_tray` | function | named | 24 | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/tray_dashboard.rs` | `run_tray_dashboard` | function | named | 26 | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/tray_dashboard.rs` | `spawn_tray_dashboard` | function | named | 48 | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/wizard/keys.rs` | `handle_key` | function | named | 17 | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/wizard/mod.rs` | `WizardArgs` | struct | named | 55 | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/wizard/mod.rs` | `WizardStrategyArg` | enum | named | 96 | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/wizard/mod.rs` | `run_wizard` | function | named | 116 | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/wizard/persist.rs` | `run_danger_auto_configure` | function | named | 305 | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/wizard/persist.rs` | `run_per_client_generate` | function | named | 230 | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/wizard/persist.rs` | `run_unified_generate` | function | named | 167 | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/wizard/persist.rs` | `start_tray_daemon` | function | named | 406 | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/wizard/services.rs` | `append_default_services` | function | named | 214 | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/wizard/services.rs` | `build_services_from_scans` | function | named | 57 | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/wizard/services.rs` | `enrich_running_state` | function | named | 158 | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/wizard/services.rs` | `probe_service_health` | function | named | 414 | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/wizard/types.rs` | `AppState` | struct | named | 198 | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/wizard/types.rs` | `CustomPathInput` | struct | named | 190 | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/wizard/types.rs` | `HealthStatus` | enum | named | 123 | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/wizard/types.rs` | `PendingAction` | enum | named | 78 | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/wizard/types.rs` | `ServiceEntry` | struct | named | 173 | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/wizard/types.rs` | `ServiceSource` | enum | named | 99 | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/wizard/types.rs` | `SourceEntry` | struct | named | 159 | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/wizard/types.rs` | `SourceStatus` | enum | named | 135 | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/wizard/types.rs` | `Strategy` | enum | named | 41 | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/wizard/types.rs` | `SummaryAction` | enum | named | 55 | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/wizard/types.rs` | `TrayChoice` | enum | named | 63 | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/wizard/types.rs` | `WizardStep` | enum | named | 26 | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/wizard/types.rs` | `short_label` | function | named | 113 | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/wizard/ui.rs` | `draw_ui` | function | named | 19 | *RepoVerified* |
| `vibecrafted-app/mux-agent/tools/install.sh` | `ensure_path_line` | function | named | 53 | *RepoVerified* |
| `vibecrafted-app/mux-agent/tools/install.sh` | `info` | function | named | 21 | *RepoVerified* |
| `vibecrafted-app/mux-agent/tools/install.sh` | `warn` | function | named | 22 | *RepoVerified* |
| `vibecrafted-app/shell-agent/Makefile` | `.PHONY` | special_target | named | 6 | *RepoVerified* |
| `vibecrafted-app/shell-agent/Makefile` | `HELP_C_CYAN` | var | named | 8 | *RepoVerified* |
| `vibecrafted-app/shell-agent/Makefile` | `HELP_C_GREEN` | var | named | 9 | *RepoVerified* |
| `vibecrafted-app/shell-agent/Makefile` | `HELP_C_RESET` | var | named | 11 | *RepoVerified* |
| `vibecrafted-app/shell-agent/Makefile` | `HELP_C_YELLOW` | var | named | 10 | *RepoVerified* |
| `vibecrafted-app/shell-agent/Makefile` | `app` | target | named | 26 | *RepoVerified* |
| `vibecrafted-app/shell-agent/Makefile` | `app-debug` | target | named | 46 | *RepoVerified* |
| `vibecrafted-app/shell-agent/Makefile` | `bindings` | target | named | 13 | *RepoVerified* |
| `vibecrafted-app/shell-agent/Makefile` | `dmg` | target | named | 40 | *RepoVerified* |
| `vibecrafted-app/shell-agent/Makefile` | `dmg-signed` | target | named | 43 | *RepoVerified* |
| `vibecrafted-app/shell-agent/Makefile` | `help` | target | named | 59 | *RepoVerified* |
| `vibecrafted-app/shell-agent/Makefile` | `xcode` | target | named | 22 | *RepoVerified* |
| `vibecrafted-app/shell-agent/app/Vibecrafted/AppDelegate.swift` | `AppDelegate` | class | named | 17 | *RepoVerified* |
| `vibecrafted-app/shell-agent/app/Vibecrafted/AppDelegate.swift` | `EventObserver` | class | named | 3 | *RepoVerified* |
| `vibecrafted-app/shell-agent/app/Vibecrafted/AppDelegate.swift` | `appMenu` | let | named | 93 | *RepoVerified* |
| `vibecrafted-app/shell-agent/app/Vibecrafted/AppDelegate.swift` | `appMenuItem` | let | named | 112 | *RepoVerified* |
| `vibecrafted-app/shell-agent/app/Vibecrafted/AppDelegate.swift` | `applicationDidFinishLaunching` | func | named | 31 | *RepoVerified* |
| `vibecrafted-app/shell-agent/app/Vibecrafted/AppDelegate.swift` | `applicationShouldTerminateAfterLastWindowClosed` | func | named | 52 | *RepoVerified* |
| `vibecrafted-app/shell-agent/app/Vibecrafted/AppDelegate.swift` | `applicationSupportsSecureRestorableState` | func | named | 56 | *RepoVerified* |
| `vibecrafted-app/shell-agent/app/Vibecrafted/AppDelegate.swift` | `buildMainMenu` | func | named | 89 | *RepoVerified* |
| `vibecrafted-app/shell-agent/app/Vibecrafted/AppDelegate.swift` | `buildStatusItem` | func | named | 62 | *RepoVerified* |
| `vibecrafted-app/shell-agent/app/Vibecrafted/AppDelegate.swift` | `eventObserver` | let | named | 20 | *RepoVerified* |
| `vibecrafted-app/shell-agent/app/Vibecrafted/AppDelegate.swift` | `fileMenu` | let | named | 117 | *RepoVerified* |
| `vibecrafted-app/shell-agent/app/Vibecrafted/AppDelegate.swift` | `fileMenuItem` | let | named | 121 | *RepoVerified* |
| `vibecrafted-app/shell-agent/app/Vibecrafted/AppDelegate.swift` | `helpMenu` | let | named | 153 | *RepoVerified* |
| `vibecrafted-app/shell-agent/app/Vibecrafted/AppDelegate.swift` | `helpMenuItem` | let | named | 154 | *RepoVerified* |
| `vibecrafted-app/shell-agent/app/Vibecrafted/AppDelegate.swift` | `hideOthers` | let | named | 100 | *RepoVerified* |
| `vibecrafted-app/shell-agent/app/Vibecrafted/AppDelegate.swift` | `inspectorItem` | let | named | 131 | *RepoVerified* |
| `vibecrafted-app/shell-agent/app/Vibecrafted/AppDelegate.swift` | `item` | let | named | 63 | *RepoVerified* |
| `vibecrafted-app/shell-agent/app/Vibecrafted/AppDelegate.swift` | `mainMenu` | let | named | 90 | *RepoVerified* |
| `vibecrafted-app/shell-agent/app/Vibecrafted/AppDelegate.swift` | `mainWindow` | var | named | 18 | *RepoVerified* |
| `vibecrafted-app/shell-agent/app/Vibecrafted/AppDelegate.swift` | `menu` | let | named | 69 | *RepoVerified* |
| `vibecrafted-app/shell-agent/app/Vibecrafted/AppDelegate.swift` | `onError` | func | named | 11 | *RepoVerified* |
| `vibecrafted-app/shell-agent/app/Vibecrafted/AppDelegate.swift` | `onEvent` | func | named | 4 | *RepoVerified* |
| `vibecrafted-app/shell-agent/app/Vibecrafted/AppDelegate.swift` | `openConsoleFromStatusItem` | func | named | 80 | *RepoVerified* |
| `vibecrafted-app/shell-agent/app/Vibecrafted/AppDelegate.swift` | `showMainWindowIfNeeded` | func | named | 22 | *RepoVerified* |
| `vibecrafted-app/shell-agent/app/Vibecrafted/AppDelegate.swift` | `sidebarItem` | let | named | 127 | *RepoVerified* |
| `vibecrafted-app/shell-agent/app/Vibecrafted/AppDelegate.swift` | `socketPath` | let | named | 35 | *RepoVerified* |
| `vibecrafted-app/shell-agent/app/Vibecrafted/AppDelegate.swift` | `statusItem` | var | named | 19 | *RepoVerified* |
| `vibecrafted-app/shell-agent/app/Vibecrafted/AppDelegate.swift` | `viewMenu` | let | named | 126 | *RepoVerified* |
| `vibecrafted-app/shell-agent/app/Vibecrafted/AppDelegate.swift` | `viewMenuItem` | let | named | 136 | *RepoVerified* |
| `vibecrafted-app/shell-agent/app/Vibecrafted/AppDelegate.swift` | `windowMenu` | let | named | 141 | *RepoVerified* |
| `vibecrafted-app/shell-agent/app/Vibecrafted/AppDelegate.swift` | `windowMenuItem` | let | named | 147 | *RepoVerified* |
| `vibecrafted-app/shell-agent/app/Vibecrafted/Bridge/vibecrafted_shell_ffi.swift` | `CALL_CANCELLED` | let | named | 254 | *RepoVerified* |
| `vibecrafted-app/shell-agent/app/Vibecrafted/Bridge/vibecrafted_shell_ffi.swift` | `CALL_ERROR` | let | named | 252 | *RepoVerified* |
| `vibecrafted-app/shell-agent/app/Vibecrafted/Bridge/vibecrafted_shell_ffi.swift` | `CALL_SUCCESS` | let | named | 251 | *RepoVerified* |
| `vibecrafted-app/shell-agent/app/Vibecrafted/Bridge/vibecrafted_shell_ffi.swift` | `CALL_UNEXPECTED_ERROR` | let | named | 253 | *RepoVerified* |
| `vibecrafted-app/shell-agent/app/Vibecrafted/Bridge/vibecrafted_shell_ffi.swift` | `Data` | extension | named | 51 | *RepoVerified* |
| `vibecrafted-app/shell-agent/app/Vibecrafted/Bridge/vibecrafted_shell_ffi.swift` | `EventCallback` | protocol | named | 1027 | *RepoVerified* |
| `vibecrafted-app/shell-agent/app/Vibecrafted/Bridge/vibecrafted_shell_ffi.swift` | `FfiClientConfig` | struct | named | 523 | *RepoVerified* |
| `vibecrafted-app/shell-agent/app/Vibecrafted/Bridge/vibecrafted_shell_ffi.swift` | `FfiClientKind` | enum | named | 801 | *RepoVerified* |
| `vibecrafted-app/shell-agent/app/Vibecrafted/Bridge/vibecrafted_shell_ffi.swift` | `FfiConverter` | protocol | named | 159 | *RepoVerified* |
| `vibecrafted-app/shell-agent/app/Vibecrafted/Bridge/vibecrafted_shell_ffi.swift` | `FfiConverterBool` | struct | named | 460 | *RepoVerified* |
| `vibecrafted-app/shell-agent/app/Vibecrafted/Bridge/vibecrafted_shell_ffi.swift` | `FfiConverterCallbackInterfaceEventCallback` | struct | named | 1118 | *RepoVerified* |
| `vibecrafted-app/shell-agent/app/Vibecrafted/Bridge/vibecrafted_shell_ffi.swift` | `FfiConverterCallbackInterfaceEventCallback_lift` | func | named | 1163 | *RepoVerified* |
| `vibecrafted-app/shell-agent/app/Vibecrafted/Bridge/vibecrafted_shell_ffi.swift` | `FfiConverterCallbackInterfaceEventCallback_lower` | func | named | 1170 | *RepoVerified* |
| `vibecrafted-app/shell-agent/app/Vibecrafted/Bridge/vibecrafted_shell_ffi.swift` | `FfiConverterPrimitive` | protocol | named | 170 | *RepoVerified* |
| `vibecrafted-app/shell-agent/app/Vibecrafted/Bridge/vibecrafted_shell_ffi.swift` | `FfiConverterRustBuffer` | protocol | named | 190 | *RepoVerified* |
| `vibecrafted-app/shell-agent/app/Vibecrafted/Bridge/vibecrafted_shell_ffi.swift` | `FfiConverterSequenceString` | struct | named | 1177 | *RepoVerified* |
| `vibecrafted-app/shell-agent/app/Vibecrafted/Bridge/vibecrafted_shell_ffi.swift` | `FfiConverterSequenceTypeFfiRoute` | struct | named | 1202 | *RepoVerified* |
| `vibecrafted-app/shell-agent/app/Vibecrafted/Bridge/vibecrafted_shell_ffi.swift` | `FfiConverterSequenceTypeFfiServerStatus` | struct | named | 1227 | *RepoVerified* |
| `vibecrafted-app/shell-agent/app/Vibecrafted/Bridge/vibecrafted_shell_ffi.swift` | `FfiConverterString` | struct | named | 484 | *RepoVerified* |
| `vibecrafted-app/shell-agent/app/Vibecrafted/Bridge/vibecrafted_shell_ffi.swift` | `FfiConverterTypeFfiClientConfig` | struct | named | 544 | *RepoVerified* |
| `vibecrafted-app/shell-agent/app/Vibecrafted/Bridge/vibecrafted_shell_ffi.swift` | `FfiConverterTypeFfiClientConfig_lift` | func | named | 563 | *RepoVerified* |
| `vibecrafted-app/shell-agent/app/Vibecrafted/Bridge/vibecrafted_shell_ffi.swift` | `FfiConverterTypeFfiClientConfig_lower` | func | named | 570 | *RepoVerified* |
| `vibecrafted-app/shell-agent/app/Vibecrafted/Bridge/vibecrafted_shell_ffi.swift` | `FfiConverterTypeFfiClientKind` | struct | named | 821 | *RepoVerified* |
| `vibecrafted-app/shell-agent/app/Vibecrafted/Bridge/vibecrafted_shell_ffi.swift` | `FfiConverterTypeFfiClientKind_lift` | func | named | 875 | *RepoVerified* |
| `vibecrafted-app/shell-agent/app/Vibecrafted/Bridge/vibecrafted_shell_ffi.swift` | `FfiConverterTypeFfiClientKind_lower` | func | named | 882 | *RepoVerified* |
| `vibecrafted-app/shell-agent/app/Vibecrafted/Bridge/vibecrafted_shell_ffi.swift` | `FfiConverterTypeFfiNonMuxEntry` | struct | named | 594 | *RepoVerified* |
| `vibecrafted-app/shell-agent/app/Vibecrafted/Bridge/vibecrafted_shell_ffi.swift` | `FfiConverterTypeFfiNonMuxEntry_lift` | func | named | 611 | *RepoVerified* |
| `vibecrafted-app/shell-agent/app/Vibecrafted/Bridge/vibecrafted_shell_ffi.swift` | `FfiConverterTypeFfiNonMuxEntry_lower` | func | named | 618 | *RepoVerified* |
| `vibecrafted-app/shell-agent/app/Vibecrafted/Bridge/vibecrafted_shell_ffi.swift` | `FfiConverterTypeFfiRoute` | struct | named | 646 | *RepoVerified* |
| `vibecrafted-app/shell-agent/app/Vibecrafted/Bridge/vibecrafted_shell_ffi.swift` | `FfiConverterTypeFfiRoute_lift` | func | named | 667 | *RepoVerified* |
| `vibecrafted-app/shell-agent/app/Vibecrafted/Bridge/vibecrafted_shell_ffi.swift` | `FfiConverterTypeFfiRoute_lower` | func | named | 674 | *RepoVerified* |
| `vibecrafted-app/shell-agent/app/Vibecrafted/Bridge/vibecrafted_shell_ffi.swift` | `FfiConverterTypeFfiServerStatus` | struct | named | 706 | *RepoVerified* |
| `vibecrafted-app/shell-agent/app/Vibecrafted/Bridge/vibecrafted_shell_ffi.swift` | `FfiConverterTypeFfiServerStatus_lift` | func | named | 731 | *RepoVerified* |
| `vibecrafted-app/shell-agent/app/Vibecrafted/Bridge/vibecrafted_shell_ffi.swift` | `FfiConverterTypeFfiServerStatus_lower` | func | named | 738 | *RepoVerified* |
| `vibecrafted-app/shell-agent/app/Vibecrafted/Bridge/vibecrafted_shell_ffi.swift` | `FfiConverterTypeFfiSubscriberState` | struct | named | 906 | *RepoVerified* |
| `vibecrafted-app/shell-agent/app/Vibecrafted/Bridge/vibecrafted_shell_ffi.swift` | `FfiConverterTypeFfiSubscriberState_lift` | func | named | 940 | *RepoVerified* |
| `vibecrafted-app/shell-agent/app/Vibecrafted/Bridge/vibecrafted_shell_ffi.swift` | `FfiConverterTypeFfiSubscriberState_lower` | func | named | 947 | *RepoVerified* |
| `vibecrafted-app/shell-agent/app/Vibecrafted/Bridge/vibecrafted_shell_ffi.swift` | `FfiConverterTypeFfiVerifyResult` | struct | named | 766 | *RepoVerified* |
| `vibecrafted-app/shell-agent/app/Vibecrafted/Bridge/vibecrafted_shell_ffi.swift` | `FfiConverterTypeFfiVerifyResult_lift` | func | named | 787 | *RepoVerified* |
| `vibecrafted-app/shell-agent/app/Vibecrafted/Bridge/vibecrafted_shell_ffi.swift` | `FfiConverterTypeFfiVerifyResult_lower` | func | named | 794 | *RepoVerified* |
| `vibecrafted-app/shell-agent/app/Vibecrafted/Bridge/vibecrafted_shell_ffi.swift` | `FfiConverterTypeMuxError` | struct | named | 976 | *RepoVerified* |
| `vibecrafted-app/shell-agent/app/Vibecrafted/Bridge/vibecrafted_shell_ffi.swift` | `FfiConverterTypeMuxError_lift` | func | named | 1013 | *RepoVerified* |
| `vibecrafted-app/shell-agent/app/Vibecrafted/Bridge/vibecrafted_shell_ffi.swift` | `FfiConverterTypeMuxError_lower` | func | named | 1020 | *RepoVerified* |
| `vibecrafted-app/shell-agent/app/Vibecrafted/Bridge/vibecrafted_shell_ffi.swift` | `FfiConverterUInt32` | struct | named | 428 | *RepoVerified* |
| `vibecrafted-app/shell-agent/app/Vibecrafted/Bridge/vibecrafted_shell_ffi.swift` | `FfiConverterUInt64` | struct | named | 444 | *RepoVerified* |
| `vibecrafted-app/shell-agent/app/Vibecrafted/Bridge/vibecrafted_shell_ffi.swift` | `FfiNonMuxEntry` | struct | named | 575 | *RepoVerified* |
| `vibecrafted-app/shell-agent/app/Vibecrafted/Bridge/vibecrafted_shell_ffi.swift` | `FfiRoute` | struct | named | 623 | *RepoVerified* |
| `vibecrafted-app/shell-agent/app/Vibecrafted/Bridge/vibecrafted_shell_ffi.swift` | `FfiServerStatus` | struct | named | 679 | *RepoVerified* |
| `vibecrafted-app/shell-agent/app/Vibecrafted/Bridge/vibecrafted_shell_ffi.swift` | `FfiSubscriberState` | enum | named | 890 | *RepoVerified* |
| `vibecrafted-app/shell-agent/app/Vibecrafted/Bridge/vibecrafted_shell_ffi.swift` | `FfiVerifyResult` | struct | named | 743 | *RepoVerified* |
| `vibecrafted-app/shell-agent/app/Vibecrafted/Bridge/vibecrafted_shell_ffi.swift` | `ForeignBytes` | extension | named | 38 | *RepoVerified* |
| `vibecrafted-app/shell-agent/app/Vibecrafted/Bridge/vibecrafted_shell_ffi.swift` | `IDX_CALLBACK_FREE` | let | named | 419 | *RepoVerified* |
| `vibecrafted-app/shell-agent/app/Vibecrafted/Bridge/vibecrafted_shell_ffi.swift` | `InitializationResult` | enum | named | 1387 | *RepoVerified* |
| `vibecrafted-app/shell-agent/app/Vibecrafted/Bridge/vibecrafted_shell_ffi.swift` | `MuxError` | enum | named | 953 | *RepoVerified* |
| `vibecrafted-app/shell-agent/app/Vibecrafted/Bridge/vibecrafted_shell_ffi.swift` | `NSLock` | extension | named | 243 | *RepoVerified* |
| `vibecrafted-app/shell-agent/app/Vibecrafted/Bridge/vibecrafted_shell_ffi.swift` | `RustBuffer` | extension | named | 14 | *RepoVerified* |
| `vibecrafted-app/shell-agent/app/Vibecrafted/Bridge/vibecrafted_shell_ffi.swift` | `RustCallStatus` | extension | named | 256 | *RepoVerified* |
| `vibecrafted-app/shell-agent/app/Vibecrafted/Bridge/vibecrafted_shell_ffi.swift` | `UNIFFI_CALLBACK_ERROR` | let | named | 422 | *RepoVerified* |
| `vibecrafted-app/shell-agent/app/Vibecrafted/Bridge/vibecrafted_shell_ffi.swift` | `UNIFFI_CALLBACK_SUCCESS` | let | named | 421 | *RepoVerified* |
| `vibecrafted-app/shell-agent/app/Vibecrafted/Bridge/vibecrafted_shell_ffi.swift` | `UNIFFI_CALLBACK_UNEXPECTED_ERROR` | let | named | 423 | *RepoVerified* |
| `vibecrafted-app/shell-agent/app/Vibecrafted/Bridge/vibecrafted_shell_ffi.swift` | `UNIFFI_HANDLEMAP_DELTA` | let | named | 358 | *RepoVerified* |
| `vibecrafted-app/shell-agent/app/Vibecrafted/Bridge/vibecrafted_shell_ffi.swift` | `UNIFFI_HANDLEMAP_INITIAL` | let | named | 357 | *RepoVerified* |
| `vibecrafted-app/shell-agent/app/Vibecrafted/Bridge/vibecrafted_shell_ffi.swift` | `UNIFFI_RUST_FUTURE_POLL_READY` | let | named | 1248 | *RepoVerified* |
| `vibecrafted-app/shell-agent/app/Vibecrafted/Bridge/vibecrafted_shell_ffi.swift` | `UNIFFI_RUST_FUTURE_POLL_WAKE` | let | named | 1249 | *RepoVerified* |
| `vibecrafted-app/shell-agent/app/Vibecrafted/Bridge/vibecrafted_shell_ffi.swift` | `UniffiCallbackInterfaceEventCallback` | struct | named | 1037 | *RepoVerified* |
| `vibecrafted-app/shell-agent/app/Vibecrafted/Bridge/vibecrafted_shell_ffi.swift` | `UniffiHandleMap` | class | named | 360 | *RepoVerified* |
| `vibecrafted-app/shell-agent/app/Vibecrafted/Bridge/vibecrafted_shell_ffi.swift` | `UniffiInternalError` | enum | named | 217 | *RepoVerified* |
| `vibecrafted-app/shell-agent/app/Vibecrafted/Bridge/vibecrafted_shell_ffi.swift` | `_` | let | named | 93 | *RepoVerified* |
| `vibecrafted-app/shell-agent/app/Vibecrafted/Bridge/vibecrafted_shell_ffi.swift` | `bindings_contract_version` | let | named | 1396 | *RepoVerified* |
| `vibecrafted-app/shell-agent/app/Vibecrafted/Bridge/vibecrafted_shell_ffi.swift` | `buf` | let | named | 504 | *RepoVerified* |
| `vibecrafted-app/shell-agent/app/Vibecrafted/Bridge/vibecrafted_shell_ffi.swift` | `bytes` | let | named | 495 | *RepoVerified* |
| `vibecrafted-app/shell-agent/app/Vibecrafted/Bridge/vibecrafted_shell_ffi.swift` | `callStatus` | var | named | 285 | *RepoVerified* |
| `vibecrafted-app/shell-agent/app/Vibecrafted/Bridge/vibecrafted_shell_ffi.swift` | `client` | var | named | 624 | *RepoVerified* |
| `vibecrafted-app/shell-agent/app/Vibecrafted/Bridge/vibecrafted_shell_ffi.swift` | `clone` | func | named | 389 | *RepoVerified* |
| `vibecrafted-app/shell-agent/app/Vibecrafted/Bridge/vibecrafted_shell_ffi.swift` | `config` | var | named | 525 | *RepoVerified* |
| `vibecrafted-app/shell-agent/app/Vibecrafted/Bridge/vibecrafted_shell_ffi.swift` | `count` | var | named | 408 | *RepoVerified* |
| `vibecrafted-app/shell-agent/app/Vibecrafted/Bridge/vibecrafted_shell_ffi.swift` | `createReader` | func | named | 75 | *RepoVerified* |
| `vibecrafted-app/shell-agent/app/Vibecrafted/Bridge/vibecrafted_shell_ffi.swift` | `createWriter` | func | named | 132 | *RepoVerified* |
| `vibecrafted-app/shell-agent/app/Vibecrafted/Bridge/vibecrafted_shell_ffi.swift` | `currentHandle` | var | named | 364 | *RepoVerified* |
| `vibecrafted-app/shell-agent/app/Vibecrafted/Bridge/vibecrafted_shell_ffi.swift` | `deallocate` | func | named | 33 | *RepoVerified* |
| `vibecrafted-app/shell-agent/app/Vibecrafted/Bridge/vibecrafted_shell_ffi.swift` | `detail` | var | named | 746 | *RepoVerified* |
| `vibecrafted-app/shell-agent/app/Vibecrafted/Bridge/vibecrafted_shell_ffi.swift` | `doInsert` | func | named | 373 | *RepoVerified* |
| `vibecrafted-app/shell-agent/app/Vibecrafted/Bridge/vibecrafted_shell_ffi.swift` | `empty` | func | named | 23 | *RepoVerified* |
| `vibecrafted-app/shell-agent/app/Vibecrafted/Bridge/vibecrafted_shell_ffi.swift` | `errorDescription` | var | named | 228 | *RepoVerified* |
| `vibecrafted-app/shell-agent/app/Vibecrafted/Bridge/vibecrafted_shell_ffi.swift` | `from` | func | named | 27 | *RepoVerified* |
| `vibecrafted-app/shell-agent/app/Vibecrafted/Bridge/vibecrafted_shell_ffi.swift` | `get` | func | named | 380 | *RepoVerified* |
| `vibecrafted-app/shell-agent/app/Vibecrafted/Bridge/vibecrafted_shell_ffi.swift` | `getRecentLogs` | func | named | 1296 | *RepoVerified* |
| `vibecrafted-app/shell-agent/app/Vibecrafted/Bridge/vibecrafted_shell_ffi.swift` | `getRoutes` | func | named | 1310 | *RepoVerified* |
| `vibecrafted-app/shell-agent/app/Vibecrafted/Bridge/vibecrafted_shell_ffi.swift` | `getServerStatus` | func | named | 1324 | *RepoVerified* |
| `vibecrafted-app/shell-agent/app/Vibecrafted/Bridge/vibecrafted_shell_ffi.swift` | `handle` | let | named | 374 | *RepoVerified* |
| `vibecrafted-app/shell-agent/app/Vibecrafted/Bridge/vibecrafted_shell_ffi.swift` | `handleMap` | let | named | 1119 | *RepoVerified* |
| `vibecrafted-app/shell-agent/app/Vibecrafted/Bridge/vibecrafted_shell_ffi.swift` | `hasRemaining` | func | named | 124 | *RepoVerified* |
| `vibecrafted-app/shell-agent/app/Vibecrafted/Bridge/vibecrafted_shell_ffi.swift` | `initRuntime` | func | named | 1338 | *RepoVerified* |
| `vibecrafted-app/shell-agent/app/Vibecrafted/Bridge/vibecrafted_shell_ffi.swift` | `initializationResult` | let | named | 1394 | *RepoVerified* |
| `vibecrafted-app/shell-agent/app/Vibecrafted/Bridge/vibecrafted_shell_ffi.swift` | `insert` | func | named | 366 | *RepoVerified* |
| `vibecrafted-app/shell-agent/app/Vibecrafted/Bridge/vibecrafted_shell_ffi.swift` | `kind` | var | named | 524 | *RepoVerified* |
| `vibecrafted-app/shell-agent/app/Vibecrafted/Bridge/vibecrafted_shell_ffi.swift` | `len` | let | named | 511 | *RepoVerified* |
| `vibecrafted-app/shell-agent/app/Vibecrafted/Bridge/vibecrafted_shell_ffi.swift` | `lift` | func | named | 163 | *RepoVerified* |
| `vibecrafted-app/shell-agent/app/Vibecrafted/Bridge/vibecrafted_shell_ffi.swift` | `lock` | let | named | 362 | *RepoVerified* |
| `vibecrafted-app/shell-agent/app/Vibecrafted/Bridge/vibecrafted_shell_ffi.swift` | `lower` | func | named | 164 | *RepoVerified* |
| `vibecrafted-app/shell-agent/app/Vibecrafted/Bridge/vibecrafted_shell_ffi.swift` | `makeCall` | let | named | 1065 | *RepoVerified* |
| `vibecrafted-app/shell-agent/app/Vibecrafted/Bridge/vibecrafted_shell_ffi.swift` | `makeRustCall` | func | named | 280 | *RepoVerified* |
| `vibecrafted-app/shell-agent/app/Vibecrafted/Bridge/vibecrafted_shell_ffi.swift` | `map` | var | named | 363 | *RepoVerified* |
| `vibecrafted-app/shell-agent/app/Vibecrafted/Bridge/vibecrafted_shell_ffi.swift` | `name` | var | named | 576 | *RepoVerified* |
| `vibecrafted-app/shell-agent/app/Vibecrafted/Bridge/vibecrafted_shell_ffi.swift` | `neverThrow` | let | named | 270 | *RepoVerified* |
| `vibecrafted-app/shell-agent/app/Vibecrafted/Bridge/vibecrafted_shell_ffi.swift` | `ok` | var | named | 745 | *RepoVerified* |
| `vibecrafted-app/shell-agent/app/Vibecrafted/Bridge/vibecrafted_shell_ffi.swift` | `onError` | func | named | 1031 | *RepoVerified* |
| `vibecrafted-app/shell-agent/app/Vibecrafted/Bridge/vibecrafted_shell_ffi.swift` | `onEvent` | func | named | 1029 | *RepoVerified* |
| `vibecrafted-app/shell-agent/app/Vibecrafted/Bridge/vibecrafted_shell_ffi.swift` | `pollResult` | var | named | 1268 | *RepoVerified* |
| `vibecrafted-app/shell-agent/app/Vibecrafted/Bridge/vibecrafted_shell_ffi.swift` | `queueCapacity` | var | named | 683 | *RepoVerified* |
| `vibecrafted-app/shell-agent/app/Vibecrafted/Bridge/vibecrafted_shell_ffi.swift` | `queueDepth` | var | named | 682 | *RepoVerified* |
| `vibecrafted-app/shell-agent/app/Vibecrafted/Bridge/vibecrafted_shell_ffi.swift` | `range` | let | named | 83 | *RepoVerified* |
| `vibecrafted-app/shell-agent/app/Vibecrafted/Bridge/vibecrafted_shell_ffi.swift` | `rbuf` | let | named | 17 | *RepoVerified* |
| `vibecrafted-app/shell-agent/app/Vibecrafted/Bridge/vibecrafted_shell_ffi.swift` | `read` | func | named | 165 | *RepoVerified* |
| `vibecrafted-app/shell-agent/app/Vibecrafted/Bridge/vibecrafted_shell_ffi.swift` | `readBytes` | func | named | 100 | *RepoVerified* |
| `vibecrafted-app/shell-agent/app/Vibecrafted/Bridge/vibecrafted_shell_ffi.swift` | `readDouble` | func | named | 119 | *RepoVerified* |
| `vibecrafted-app/shell-agent/app/Vibecrafted/Bridge/vibecrafted_shell_ffi.swift` | `readFloat` | func | named | 114 | *RepoVerified* |
| `vibecrafted-app/shell-agent/app/Vibecrafted/Bridge/vibecrafted_shell_ffi.swift` | `readInt` | func | named | 82 | *RepoVerified* |
| `vibecrafted-app/shell-agent/app/Vibecrafted/Bridge/vibecrafted_shell_ffi.swift` | `reader` | var | named | 197 | *RepoVerified* |
| `vibecrafted-app/shell-agent/app/Vibecrafted/Bridge/vibecrafted_shell_ffi.swift` | `remove` | func | named | 399 | *RepoVerified* |
| `vibecrafted-app/shell-agent/app/Vibecrafted/Bridge/vibecrafted_shell_ffi.swift` | `restartCount` | var | named | 684 | *RepoVerified* |
| `vibecrafted-app/shell-agent/app/Vibecrafted/Bridge/vibecrafted_shell_ffi.swift` | `restartService` | func | named | 1344 | *RepoVerified* |
| `vibecrafted-app/shell-agent/app/Vibecrafted/Bridge/vibecrafted_shell_ffi.swift` | `returnedVal` | let | named | 286 | *RepoVerified* |
| `vibecrafted-app/shell-agent/app/Vibecrafted/Bridge/vibecrafted_shell_ffi.swift` | `rustCall` | func | named | 269 | *RepoVerified* |
| `vibecrafted-app/shell-agent/app/Vibecrafted/Bridge/vibecrafted_shell_ffi.swift` | `rustCallWithError` | func | named | 274 | *RepoVerified* |
| `vibecrafted-app/shell-agent/app/Vibecrafted/Bridge/vibecrafted_shell_ffi.swift` | `rustFuture` | let | named | 1264 | *RepoVerified* |
| `vibecrafted-app/shell-agent/app/Vibecrafted/Bridge/vibecrafted_shell_ffi.swift` | `scaffolding_contract_version` | let | named | 1398 | *RepoVerified* |
| `vibecrafted-app/shell-agent/app/Vibecrafted/Bridge/vibecrafted_shell_ffi.swift` | `seq` | var | named | 1190 | *RepoVerified* |
| `vibecrafted-app/shell-agent/app/Vibecrafted/Bridge/vibecrafted_shell_ffi.swift` | `service` | var | named | 625 | *RepoVerified* |
| `vibecrafted-app/shell-agent/app/Vibecrafted/Bridge/vibecrafted_shell_ffi.swift` | `state` | var | named | 626 | *RepoVerified* |
| `vibecrafted-app/shell-agent/app/Vibecrafted/Bridge/vibecrafted_shell_ffi.swift` | `status` | var | named | 681 | *RepoVerified* |
| `vibecrafted-app/shell-agent/app/Vibecrafted/Bridge/vibecrafted_shell_ffi.swift` | `subscribeEvents` | func | named | 1358 | *RepoVerified* |
| `vibecrafted-app/shell-agent/app/Vibecrafted/Bridge/vibecrafted_shell_ffi.swift` | `uniffiCallbackInitEventCallback` | func | named | 1110 | *RepoVerified* |
| `vibecrafted-app/shell-agent/app/Vibecrafted/Bridge/vibecrafted_shell_ffi.swift` | `uniffiCheckCallStatus` | func | named | 291 | *RepoVerified* |
| `vibecrafted-app/shell-agent/app/Vibecrafted/Bridge/vibecrafted_shell_ffi.swift` | `uniffiContinuationHandleMap` | let | named | 1251 | *RepoVerified* |
| `vibecrafted-app/shell-agent/app/Vibecrafted/Bridge/vibecrafted_shell_ffi.swift` | `uniffiEnsureVibecraftedShellFfiInitialized` | func | named | 1436 | *RepoVerified* |
| `vibecrafted-app/shell-agent/app/Vibecrafted/Bridge/vibecrafted_shell_ffi.swift` | `uniffiFutureContinuationCallback` | func | named | 1289 | *RepoVerified* |
| `vibecrafted-app/shell-agent/app/Vibecrafted/Bridge/vibecrafted_shell_ffi.swift` | `uniffiRustCallAsync` | func | named | 1253 | *RepoVerified* |
| `vibecrafted-app/shell-agent/app/Vibecrafted/Bridge/vibecrafted_shell_ffi.swift` | `uniffiTraitInterfaceCall` | func | named | 326 | *RepoVerified* |
| `vibecrafted-app/shell-agent/app/Vibecrafted/Bridge/vibecrafted_shell_ffi.swift` | `uniffiTraitInterfaceCallWithError` | func | named | 339 | *RepoVerified* |
| `vibecrafted-app/shell-agent/app/Vibecrafted/Bridge/vibecrafted_shell_ffi.swift` | `value` | let | named | 88 | *RepoVerified* |
| `vibecrafted-app/shell-agent/app/Vibecrafted/Bridge/vibecrafted_shell_ffi.swift` | `variant` | let | named | 825 | *RepoVerified* |
| `vibecrafted-app/shell-agent/app/Vibecrafted/Bridge/vibecrafted_shell_ffi.swift` | `verifyClient` | func | named | 1372 | *RepoVerified* |
| `vibecrafted-app/shell-agent/app/Vibecrafted/Bridge/vibecrafted_shell_ffi.swift` | `vtable` | let | named | 1044 | *RepoVerified* |
| `vibecrafted-app/shell-agent/app/Vibecrafted/Bridge/vibecrafted_shell_ffi.swift` | `withLock` | func | named | 244 | *RepoVerified* |
| `vibecrafted-app/shell-agent/app/Vibecrafted/Bridge/vibecrafted_shell_ffi.swift` | `write` | func | named | 166 | *RepoVerified* |
| `vibecrafted-app/shell-agent/app/Vibecrafted/Bridge/vibecrafted_shell_ffi.swift` | `writeBytes` | func | named | 136 | *RepoVerified* |
| `vibecrafted-app/shell-agent/app/Vibecrafted/Bridge/vibecrafted_shell_ffi.swift` | `writeDouble` | func | named | 153 | *RepoVerified* |
| `vibecrafted-app/shell-agent/app/Vibecrafted/Bridge/vibecrafted_shell_ffi.swift` | `writeFloat` | func | named | 149 | *RepoVerified* |
| `vibecrafted-app/shell-agent/app/Vibecrafted/Bridge/vibecrafted_shell_ffi.swift` | `writeInt` | func | named | 144 | *RepoVerified* |
| `vibecrafted-app/shell-agent/app/Vibecrafted/Bridge/vibecrafted_shell_ffi.swift` | `writeReturn` | let | named | 1076 | *RepoVerified* |
| `vibecrafted-app/shell-agent/app/Vibecrafted/Bridge/vibecrafted_shell_ffi.swift` | `writer` | var | named | 210 | *RepoVerified* |
| `vibecrafted-app/shell-agent/app/Vibecrafted/Views/CanvasViewController.swift` | `CanvasViewController` | class | named | 6 | *RepoVerified* |
| `vibecrafted-app/shell-agent/app/Vibecrafted/Views/CanvasViewController.swift` | `cell` | var | named | 153 | *RepoVerified* |
| `vibecrafted-app/shell-agent/app/Vibecrafted/Views/CanvasViewController.swift` | `clientCol` | let | named | 36 | *RepoVerified* |
| `vibecrafted-app/shell-agent/app/Vibecrafted/Views/CanvasViewController.swift` | `container` | let | named | 22 | *RepoVerified* |
| `vibecrafted-app/shell-agent/app/Vibecrafted/Views/CanvasViewController.swift` | `currentServerName` | var | named | 19 | *RepoVerified* |
| `vibecrafted-app/shell-agent/app/Vibecrafted/Views/CanvasViewController.swift` | `handleIpcEvent` | func | named | 103 | *RepoVerified* |
| `vibecrafted-app/shell-agent/app/Vibecrafted/Views/CanvasViewController.swift` | `handleSelectedServerChanged` | func | named | 107 | *RepoVerified* |
| `vibecrafted-app/shell-agent/app/Vibecrafted/Views/CanvasViewController.swift` | `identifier` | let | named | 152 | *RepoVerified* |
| `vibecrafted-app/shell-agent/app/Vibecrafted/Views/CanvasViewController.swift` | `isMatrix` | let | named | 95 | *RepoVerified* |
| `vibecrafted-app/shell-agent/app/Vibecrafted/Views/CanvasViewController.swift` | `lines` | let | named | 132 | *RepoVerified* |
| `vibecrafted-app/shell-agent/app/Vibecrafted/Views/CanvasViewController.swift` | `loadView` | func | named | 21 | *RepoVerified* |
| `vibecrafted-app/shell-agent/app/Vibecrafted/Views/CanvasViewController.swift` | `logScrollView` | let | named | 16 | *RepoVerified* |
| `vibecrafted-app/shell-agent/app/Vibecrafted/Views/CanvasViewController.swift` | `logTextView` | let | named | 17 | *RepoVerified* |
| `vibecrafted-app/shell-agent/app/Vibecrafted/Views/CanvasViewController.swift` | `matrixScrollView` | let | named | 11 | *RepoVerified* |
| `vibecrafted-app/shell-agent/app/Vibecrafted/Views/CanvasViewController.swift` | `matrixTableView` | let | named | 12 | *RepoVerified* |
| `vibecrafted-app/shell-agent/app/Vibecrafted/Views/CanvasViewController.swift` | `numberOfRows` | func | named | 143 | *RepoVerified* |
| `vibecrafted-app/shell-agent/app/Vibecrafted/Views/CanvasViewController.swift` | `refreshLogs` | func | named | 125 | *RepoVerified* |
| `vibecrafted-app/shell-agent/app/Vibecrafted/Views/CanvasViewController.swift` | `refreshRoutes` | func | named | 114 | *RepoVerified* |
| `vibecrafted-app/shell-agent/app/Vibecrafted/Views/CanvasViewController.swift` | `route` | let | named | 151 | *RepoVerified* |
| `vibecrafted-app/shell-agent/app/Vibecrafted/Views/CanvasViewController.swift` | `routes` | var | named | 13 | *RepoVerified* |
| `vibecrafted-app/shell-agent/app/Vibecrafted/Views/CanvasViewController.swift` | `segmentChanged` | func | named | 94 | *RepoVerified* |
| `vibecrafted-app/shell-agent/app/Vibecrafted/Views/CanvasViewController.swift` | `segmentedControl` | let | named | 7 | *RepoVerified* |
| `vibecrafted-app/shell-agent/app/Vibecrafted/Views/CanvasViewController.swift` | `serverCol` | let | named | 41 | *RepoVerified* |
| `vibecrafted-app/shell-agent/app/Vibecrafted/Views/CanvasViewController.swift` | `stateCol` | let | named | 46 | *RepoVerified* |
| `vibecrafted-app/shell-agent/app/Vibecrafted/Views/CanvasViewController.swift` | `tableView` | func | named | 149 | *RepoVerified* |
| `vibecrafted-app/shell-agent/app/Vibecrafted/Views/CanvasViewController.swift` | `textField` | let | named | 158 | *RepoVerified* |
| `vibecrafted-app/shell-agent/app/Vibecrafted/Views/InspectorViewController.swift` | `InspectorViewController` | class | named | 6 | *RepoVerified* |
| `vibecrafted-app/shell-agent/app/Vibecrafted/Views/InspectorViewController.swift` | `alert` | let | named | 134 | *RepoVerified* |
| `vibecrafted-app/shell-agent/app/Vibecrafted/Views/InspectorViewController.swift` | `buttonStack` | let | named | 65 | *RepoVerified* |
| `vibecrafted-app/shell-agent/app/Vibecrafted/Views/InspectorViewController.swift` | `container` | let | named | 22 | *RepoVerified* |
| `vibecrafted-app/shell-agent/app/Vibecrafted/Views/InspectorViewController.swift` | `currentServerName` | var | named | 19 | *RepoVerified* |
| `vibecrafted-app/shell-agent/app/Vibecrafted/Views/InspectorViewController.swift` | `errorLabel` | let | named | 13 | *RepoVerified* |
| `vibecrafted-app/shell-agent/app/Vibecrafted/Views/InspectorViewController.swift` | `handleSelectedServerChanged` | func | named | 86 | *RepoVerified* |
| `vibecrafted-app/shell-agent/app/Vibecrafted/Views/InspectorViewController.swift` | `loadView` | func | named | 21 | *RepoVerified* |
| `vibecrafted-app/shell-agent/app/Vibecrafted/Views/InspectorViewController.swift` | `nameLabel` | let | named | 8 | *RepoVerified* |
| `vibecrafted-app/shell-agent/app/Vibecrafted/Views/InspectorViewController.swift` | `openConfig` | func | named | 147 | *RepoVerified* |
| `vibecrafted-app/shell-agent/app/Vibecrafted/Views/InspectorViewController.swift` | `openConfigButton` | let | named | 17 | *RepoVerified* |
| `vibecrafted-app/shell-agent/app/Vibecrafted/Views/InspectorViewController.swift` | `pidLabel` | let | named | 9 | *RepoVerified* |
| `vibecrafted-app/shell-agent/app/Vibecrafted/Views/InspectorViewController.swift` | `res` | let | named | 132 | *RepoVerified* |
| `vibecrafted-app/shell-agent/app/Vibecrafted/Views/InspectorViewController.swift` | `restartButton` | let | named | 15 | *RepoVerified* |
| `vibecrafted-app/shell-agent/app/Vibecrafted/Views/InspectorViewController.swift` | `restartServiceAction` | func | named | 115 | *RepoVerified* |
| `vibecrafted-app/shell-agent/app/Vibecrafted/Views/InspectorViewController.swift` | `restartsLabel` | let | named | 12 | *RepoVerified* |
| `vibecrafted-app/shell-agent/app/Vibecrafted/Views/InspectorViewController.swift` | `rssLabel` | let | named | 11 | *RepoVerified* |
| `vibecrafted-app/shell-agent/app/Vibecrafted/Views/InspectorViewController.swift` | `socketLabel` | let | named | 10 | *RepoVerified* |
| `vibecrafted-app/shell-agent/app/Vibecrafted/Views/InspectorViewController.swift` | `spacer` | let | named | 61 | *RepoVerified* |
| `vibecrafted-app/shell-agent/app/Vibecrafted/Views/InspectorViewController.swift` | `stackView` | let | named | 7 | *RepoVerified* |
| `vibecrafted-app/shell-agent/app/Vibecrafted/Views/InspectorViewController.swift` | `verifyButton` | let | named | 16 | *RepoVerified* |
| `vibecrafted-app/shell-agent/app/Vibecrafted/Views/InspectorViewController.swift` | `verifyClientsAction` | func | named | 128 | *RepoVerified* |
| `vibecrafted-app/shell-agent/app/Vibecrafted/Views/MainSplitViewController.swift` | `MainSplitViewController` | class | named | 6 | *RepoVerified* |
| `vibecrafted-app/shell-agent/app/Vibecrafted/Views/MainSplitViewController.swift` | `canvasItem` | let | named | 19 | *RepoVerified* |
| `vibecrafted-app/shell-agent/app/Vibecrafted/Views/MainSplitViewController.swift` | `canvasVC` | let | named | 8 | *RepoVerified* |
| `vibecrafted-app/shell-agent/app/Vibecrafted/Views/MainSplitViewController.swift` | `inspectorItem` | let | named | 22 | *RepoVerified* |
| `vibecrafted-app/shell-agent/app/Vibecrafted/Views/MainSplitViewController.swift` | `inspectorVC` | let | named | 9 | *RepoVerified* |
| `vibecrafted-app/shell-agent/app/Vibecrafted/Views/MainSplitViewController.swift` | `sidebarItem` | let | named | 14 | *RepoVerified* |
| `vibecrafted-app/shell-agent/app/Vibecrafted/Views/MainSplitViewController.swift` | `sidebarVC` | let | named | 7 | *RepoVerified* |
| `vibecrafted-app/shell-agent/app/Vibecrafted/Views/MainSplitViewController.swift` | `viewDidLoad` | func | named | 11 | *RepoVerified* |
| `vibecrafted-app/shell-agent/app/Vibecrafted/Views/MainWindowController.swift` | `MainWindowController` | class | named | 6 | *RepoVerified* |
| `vibecrafted-app/shell-agent/app/Vibecrafted/Views/MainWindowController.swift` | `item` | let | named | 49 | *RepoVerified* |
| `vibecrafted-app/shell-agent/app/Vibecrafted/Views/MainWindowController.swift` | `mainViewController` | let | named | 7 | *RepoVerified* |
| `vibecrafted-app/shell-agent/app/Vibecrafted/Views/MainWindowController.swift` | `toolbar` | let | named | 30 | *RepoVerified* |
| `vibecrafted-app/shell-agent/app/Vibecrafted/Views/MainWindowController.swift` | `toolbarAllowedItemIdentifiers` | func | named | 77 | *RepoVerified* |
| `vibecrafted-app/shell-agent/app/Vibecrafted/Views/MainWindowController.swift` | `toolbarDefaultItemIdentifiers` | func | named | 73 | *RepoVerified* |
| `vibecrafted-app/shell-agent/app/Vibecrafted/Views/MainWindowController.swift` | `toolbarInspectorItem` | let | named | 10 | *RepoVerified* |
| `vibecrafted-app/shell-agent/app/Vibecrafted/Views/MainWindowController.swift` | `toolbarSidebarItem` | let | named | 9 | *RepoVerified* |
| `vibecrafted-app/shell-agent/app/Vibecrafted/Views/MainWindowController.swift` | `window` | let | named | 13 | *RepoVerified* |
| `vibecrafted-app/shell-agent/app/Vibecrafted/Views/SidebarViewController.swift` | `SidebarViewController` | class | named | 6 | *RepoVerified* |
| `vibecrafted-app/shell-agent/app/Vibecrafted/Views/SidebarViewController.swift` | `cell` | var | named | 80 | *RepoVerified* |
| `vibecrafted-app/shell-agent/app/Vibecrafted/Views/SidebarViewController.swift` | `color` | let | named | 113 | *RepoVerified* |
| `vibecrafted-app/shell-agent/app/Vibecrafted/Views/SidebarViewController.swift` | `column` | let | named | 20 | *RepoVerified* |
| `vibecrafted-app/shell-agent/app/Vibecrafted/Views/SidebarViewController.swift` | `container` | let | named | 13 | *RepoVerified* |
| `vibecrafted-app/shell-agent/app/Vibecrafted/Views/SidebarViewController.swift` | `handleIpcEvent` | func | named | 55 | *RepoVerified* |
| `vibecrafted-app/shell-agent/app/Vibecrafted/Views/SidebarViewController.swift` | `identifier` | let | named | 79 | *RepoVerified* |
| `vibecrafted-app/shell-agent/app/Vibecrafted/Views/SidebarViewController.swift` | `imageView` | let | named | 86 | *RepoVerified* |
| `vibecrafted-app/shell-agent/app/Vibecrafted/Views/SidebarViewController.swift` | `loadView` | func | named | 12 | *RepoVerified* |
| `vibecrafted-app/shell-agent/app/Vibecrafted/Views/SidebarViewController.swift` | `newServers` | let | named | 59 | *RepoVerified* |
| `vibecrafted-app/shell-agent/app/Vibecrafted/Views/SidebarViewController.swift` | `numberOfRows` | func | named | 70 | *RepoVerified* |
| `vibecrafted-app/shell-agent/app/Vibecrafted/Views/SidebarViewController.swift` | `row` | let | named | 131 | *RepoVerified* |
| `vibecrafted-app/shell-agent/app/Vibecrafted/Views/SidebarViewController.swift` | `scrollView` | let | named | 7 | *RepoVerified* |
| `vibecrafted-app/shell-agent/app/Vibecrafted/Views/SidebarViewController.swift` | `server` | let | named | 78 | *RepoVerified* |
| `vibecrafted-app/shell-agent/app/Vibecrafted/Views/SidebarViewController.swift` | `serverName` | let | named | 133 | *RepoVerified* |
| `vibecrafted-app/shell-agent/app/Vibecrafted/Views/SidebarViewController.swift` | `servers` | var | named | 10 | *RepoVerified* |
| `vibecrafted-app/shell-agent/app/Vibecrafted/Views/SidebarViewController.swift` | `statusGlyph` | let | named | 112 | *RepoVerified* |
| `vibecrafted-app/shell-agent/app/Vibecrafted/Views/SidebarViewController.swift` | `tableView` | let | named | 8 | *RepoVerified* |
| `vibecrafted-app/shell-agent/app/Vibecrafted/Views/SidebarViewController.swift` | `tableViewSelectionDidChange` | func | named | 130 | *RepoVerified* |
| `vibecrafted-app/shell-agent/app/Vibecrafted/Views/SidebarViewController.swift` | `textField` | let | named | 90 | *RepoVerified* |
| `vibecrafted-app/shell-agent/app/Vibecrafted/main.swift` | `delegate` | let | named | 3 | *RepoVerified* |
| `vibecrafted-app/shell-agent/ffi/src/lib.rs` | `EventCallback` | trait | named | 434 | *RepoVerified* |
| `vibecrafted-app/shell-agent/ffi/src/lib.rs` | `FfiActionPriority` | enum | named | 134 | *RepoVerified* |
| `vibecrafted-app/shell-agent/ffi/src/lib.rs` | `FfiActionQueueItem` | struct | named | 205 | *RepoVerified* |
| `vibecrafted-app/shell-agent/ffi/src/lib.rs` | `FfiActionQueueKind` | enum | named | 126 | *RepoVerified* |
| `vibecrafted-app/shell-agent/ffi/src/lib.rs` | `FfiActiveDispatch` | struct | named | 141 | *RepoVerified* |
| `vibecrafted-app/shell-agent/ffi/src/lib.rs` | `FfiAgentStatsRow` | struct | named | 162 | *RepoVerified* |
| `vibecrafted-app/shell-agent/ffi/src/lib.rs` | `FfiClientConfig` | struct | named | 76 | *RepoVerified* |
| `vibecrafted-app/shell-agent/ffi/src/lib.rs` | `FfiClientKind` | enum | named | 27 | *RepoVerified* |
| `vibecrafted-app/shell-agent/ffi/src/lib.rs` | `FfiDataQuality` | struct | named | 213 | *RepoVerified* |
| `vibecrafted-app/shell-agent/ffi/src/lib.rs` | `FfiFailureEntry` | struct | named | 192 | *RepoVerified* |
| `vibecrafted-app/shell-agent/ffi/src/lib.rs` | `FfiFleetHealthSignal` | struct | named | 185 | *RepoVerified* |
| `vibecrafted-app/shell-agent/ffi/src/lib.rs` | `FfiFleetHealthStatus` | enum | named | 118 | *RepoVerified* |
| `vibecrafted-app/shell-agent/ffi/src/lib.rs` | `FfiMissionControlSnapshot` | struct | named | 224 | *RepoVerified* |
| `vibecrafted-app/shell-agent/ffi/src/lib.rs` | `FfiNonMuxEntry` | struct | named | 89 | *RepoVerified* |
| `vibecrafted-app/shell-agent/ffi/src/lib.rs` | `FfiRoute` | struct | named | 69 | *RepoVerified* |
| `vibecrafted-app/shell-agent/ffi/src/lib.rs` | `FfiServerStatus` | struct | named | 60 | *RepoVerified* |
| `vibecrafted-app/shell-agent/ffi/src/lib.rs` | `FfiSkillStatsRow` | struct | named | 176 | *RepoVerified* |
| `vibecrafted-app/shell-agent/ffi/src/lib.rs` | `FfiSubscriberState` | enum | named | 94 | *RepoVerified* |
| `vibecrafted-app/shell-agent/ffi/src/lib.rs` | `FfiVerifyResult` | struct | named | 82 | *RepoVerified* |
| `vibecrafted-app/shell-agent/ffi/src/lib.rs` | `FfiWaveSegment` | struct | named | 152 | *RepoVerified* |
| `vibecrafted-app/shell-agent/ffi/src/lib.rs` | `FfiWaveState` | enum | named | 110 | *RepoVerified* |
| `vibecrafted-app/shell-agent/ffi/src/lib.rs` | `MuxError` | enum | named | 13 | *RepoVerified* |
| `vibecrafted-app/shell-agent/ffi/src/lib.rs` | `get_recent_logs` | function | named | 574 | *RepoVerified* |
| `vibecrafted-app/shell-agent/ffi/src/lib.rs` | `get_routes` | function | named | 523 | *RepoVerified* |
| `vibecrafted-app/shell-agent/ffi/src/lib.rs` | `get_server_status` | function | named | 504 | *RepoVerified* |
| `vibecrafted-app/shell-agent/ffi/src/lib.rs` | `init_runtime` | function | named | 418 | *RepoVerified* |
| `vibecrafted-app/shell-agent/ffi/src/lib.rs` | `load_mission_control_snapshot` | function | named | 389 | *RepoVerified* |
| `vibecrafted-app/shell-agent/ffi/src/lib.rs` | `load_mission_control_snapshot_at` | function | named | 401 | *RepoVerified* |
| `vibecrafted-app/shell-agent/ffi/src/lib.rs` | `restart_service` | function | named | 567 | *RepoVerified* |
| `vibecrafted-app/shell-agent/ffi/src/lib.rs` | `subscribe_events` | function | named | 440 | *RepoVerified* |
| `vibecrafted-app/shell-agent/ffi/src/lib.rs` | `verify_client` | function | named | 543 | *RepoVerified* |
| `vibecrafted-app/shell-agent/scripts/build-dmg.sh` | `MACOSX_DEPLOYMENT_TARGET` | env | named | 11 | *RepoVerified* |
| `vibecrafted-app/shell-agent/scripts/build-dmg.sh` | `require_signing_identity` | function | named | 13 | *RepoVerified* |
| `vibecrafted-app/shell-agent/scripts/build-rust-binaries.sh` | `MACOSX_DEPLOYMENT_TARGET` | env | named | 8 | *RepoVerified* |
| `vibecrafted-app/shell-agent/scripts/fix-dylib-install-names.sh` | `fix_binary_refs` | function | named | 17 | *RepoVerified* |
| `vibecrafted-app/shell-agent/scripts/fix-dylib-install-names.sh` | `fix_library_id` | function | named | 10 | *RepoVerified* |
| `vibecrafted-app/tray-agent/src/handlers.rs` | `MenuRoute` | enum | named | 14 | *RepoVerified* |
| `vibecrafted-app/tray-agent/src/handlers.rs` | `handle_menu_event` | function | named | 63 | *RepoVerified* |
| `vibecrafted-app/tray-agent/src/handlers.rs` | `notify_spawn_update` | function | named | 193 | *RepoVerified* |
| `vibecrafted-app/tray-agent/src/handlers.rs` | `notify_user` | function | named | 199 | *RepoVerified* |
| `vibecrafted-app/tray-agent/src/handlers.rs` | `resolve_menu_route` | function | named | 29 | *RepoVerified* |
| `vibecrafted-app/tray-agent/src/icons.rs` | `create_fallback_icon` | function | named | 66 | *RepoVerified* |
| `vibecrafted-app/tray-agent/src/icons.rs` | `icon_for` | function | named | 11 | *RepoVerified* |
| `vibecrafted-app/tray-agent/src/icons.rs` | `load_custom_icon` | function | named | 21 | *RepoVerified* |
| `vibecrafted-app/tray-agent/src/ipc_client.rs` | `ClientKind` | reexport | named |  | *RepoVerified* |
| `vibecrafted-app/tray-agent/src/ipc_client.rs` | `IpcEvent` | reexport | named |  | *RepoVerified* |
| `vibecrafted-app/tray-agent/src/ipc_client.rs` | `MuxControlCommand` | reexport | named |  | *RepoVerified* |
| `vibecrafted-app/tray-agent/src/ipc_client.rs` | `MuxControlResponse` | reexport | named |  | *RepoVerified* |
| `vibecrafted-app/tray-agent/src/ipc_client.rs` | `client_label` | function | named | 20 | *RepoVerified* |
| `vibecrafted-app/tray-agent/src/ipc_client.rs` | `default_socket_path` | function | named | 13 | *RepoVerified* |
| `vibecrafted-app/tray-agent/src/ipc_client.rs` | `diagnostics` | function | named | 214 | *RepoVerified* |
| `vibecrafted-app/tray-agent/src/ipc_client.rs` | `from_mux_event` | function | named | 30 | *RepoVerified* |
| `vibecrafted-app/tray-agent/src/ipc_client.rs` | `from_mux_response` | function | named | 82 | *RepoVerified* |
| `vibecrafted-app/tray-agent/src/ipc_client.rs` | `restart_service` | function | named | 182 | *RepoVerified* |
| `vibecrafted-app/tray-agent/src/ipc_client.rs` | `route_snapshot` | function | named | 206 | *RepoVerified* |
| `vibecrafted-app/tray-agent/src/ipc_client.rs` | `send_command` | function | named | 154 | *RepoVerified* |
| `vibecrafted-app/tray-agent/src/ipc_client.rs` | `stop_mux_daemon` | function | named | 178 | *RepoVerified* |
| `vibecrafted-app/tray-agent/src/ipc_client.rs` | `subscribe_loop` | function | named | 100 | *RepoVerified* |
| `vibecrafted-app/tray-agent/src/ipc_client.rs` | `tray_status_from_health` | function | named | 90 | *RepoVerified* |
| `vibecrafted-app/tray-agent/src/ipc_client.rs` | `verify_client` | function | named | 192 | *RepoVerified* |
| `vibecrafted-app/tray-agent/src/lib.rs` | `MenuIds` | reexport | named |  | *RepoVerified* |
| `vibecrafted-app/tray-agent/src/lib.rs` | `TrayMenuEvent` | reexport | named |  | *RepoVerified* |
| `vibecrafted-app/tray-agent/src/lib.rs` | `TrayStatus` | reexport | named |  | *RepoVerified* |
| `vibecrafted-app/tray-agent/src/lib.rs` | `is_shutdown_requested` | function | named | 29 | *RepoVerified* |
| `vibecrafted-app/tray-agent/src/lib.rs` | `menu_event_receiver` | reexport | named |  | *RepoVerified* |
| `vibecrafted-app/tray-agent/src/lib.rs` | `request_shutdown` | function | named | 23 | *RepoVerified* |
| `vibecrafted-app/tray-agent/src/lib.rs` | `run` | function | named | 35 | *RepoVerified* |
| `vibecrafted-app/tray-agent/src/lib.rs` | `run_with_ipc` | function | named | 39 | *RepoVerified* |
| `vibecrafted-app/tray-agent/src/lib.rs` | `send_menu_event` | reexport | named |  | *RepoVerified* |
| `vibecrafted-app/tray-agent/src/lib.rs` | `update_tray_status` | reexport | named |  | *RepoVerified* |
| `vibecrafted-app/tray-agent/src/menu.rs` | `build_menu` | function | named | 30 | *RepoVerified* |
| `vibecrafted-app/tray-agent/src/menu.rs` | `current_service_count` | function | named | 22 | *RepoVerified* |
| `vibecrafted-app/tray-agent/src/menu.rs` | `refresh_service_count` | function | named | 26 | *RepoVerified* |
| `vibecrafted-app/tray-agent/src/menu.rs` | `update_onboarding_item` | function | named | 171 | *RepoVerified* |
| `vibecrafted-app/tray-agent/src/menu.rs` | `update_recent_runs_menu` | function | named | 151 | *RepoVerified* |
| `vibecrafted-app/tray-agent/src/menu.rs` | `update_service_count_label` | function | named | 142 | *RepoVerified* |
| `vibecrafted-app/tray-agent/src/menu.rs` | `update_status_label` | function | named | 134 | *RepoVerified* |
| `vibecrafted-app/tray-agent/src/state.rs` | `MENU_EVENT_CHANNEL` | decl | named | 18 | *RepoVerified* |
| `vibecrafted-app/tray-agent/src/state.rs` | `RECENT_SPAWNS` | decl | named | 19 | *RepoVerified* |
| `vibecrafted-app/tray-agent/src/state.rs` | `STATUS_CHANNEL` | decl | named | 17 | *RepoVerified* |
| `vibecrafted-app/tray-agent/src/state.rs` | `init_channels` | function | named | 78 | *RepoVerified* |
| `vibecrafted-app/tray-agent/src/state.rs` | `menu_event_receiver` | function | named | 31 | *RepoVerified* |
| `vibecrafted-app/tray-agent/src/state.rs` | `recent_spawns` | function | named | 57 | *RepoVerified* |
| `vibecrafted-app/tray-agent/src/state.rs` | `record_spawn_entry` | function | named | 45 | *RepoVerified* |
| `vibecrafted-app/tray-agent/src/state.rs` | `send_menu_event` | function | named | 39 | *RepoVerified* |
| `vibecrafted-app/tray-agent/src/state.rs` | `update_tray_status` | function | named | 21 | *RepoVerified* |
| `vibecrafted-app/tray-agent/src/types.rs` | `MenuIds` | struct | named | 102 | *RepoVerified* |
| `vibecrafted-app/tray-agent/src/types.rs` | `SpawnEntry` | struct | named | 49 | *RepoVerified* |
| `vibecrafted-app/tray-agent/src/types.rs` | `TrayMenuEvent` | enum | named | 87 | *RepoVerified* |
| `vibecrafted-app/tray-agent/src/types.rs` | `TrayStatus` | enum | named | 14 | *RepoVerified* |
| `vibecrafted-app/tray-agent/src/types.rs` | `TrayUpdate` | enum | named | 74 | *RepoVerified* |
| `vibecrafted-app/tray-agent/src/types.rs` | `is_active` | function | named | 64 | *RepoVerified* |
| `vibecrafted-app/tray-agent/src/types.rs` | `label` | function | named | 28 | *RepoVerified* |
| `vibecrafted-app/tray-agent/src/types.rs` | `menu_label` | function | named | 39 | *RepoVerified* |
| `vibecrafted-app/tray-agent/src/types.rs` | `resolve_recent_run` | function | named | 130 | *RepoVerified* |
| `vibecrafted-app/tray-agent/src/types.rs` | `resolve_restart_service` | function | named | 118 | *RepoVerified* |
| `vibecrafted-app/tray-agent/src/types.rs` | `resolve_verify_client` | function | named | 124 | *RepoVerified* |
| `vibecrafted-app/tray-agent/src/types.rs` | `silver_label_for_status` | function | named | 44 | *RepoVerified* |
| `vibecrafted-app/tray-agent/src/types.rs` | `tooltip` | function | named | 24 | *RepoVerified* |
| `vibecrafted-app/tui-agent/src/app.rs` | `App` | struct | named | 213 | *RepoVerified* |
| `vibecrafted-app/tui-agent/src/app.rs` | `AppTab` | enum | named | 15 | *RepoVerified* |
| `vibecrafted-app/tui-agent/src/app.rs` | `COUNT` | decl | named | 62 | *RepoVerified* |
| `vibecrafted-app/tui-agent/src/app.rs` | `DeepAction` | enum | named | 118 | *RepoVerified* |
| `vibecrafted-app/tui-agent/src/app.rs` | `DispatchFocus` | enum | named | 54 | *RepoVerified* |
| `vibecrafted-app/tui-agent/src/app.rs` | `LaunchFocus` | enum | named | 75 | *RepoVerified* |
| `vibecrafted-app/tui-agent/src/app.rs` | `MISSION_PANEL_COUNT` | decl | named | 1156 | *RepoVerified* |
| `vibecrafted-app/tui-agent/src/app.rs` | `QueueScope` | enum | named | 85 | *RepoVerified* |
| `vibecrafted-app/tui-agent/src/app.rs` | `TITLES` | decl | named | 23 | *RepoVerified* |
| `vibecrafted-app/tui-agent/src/app.rs` | `active_run_count` | function | named | 864 | *RepoVerified* |
| `vibecrafted-app/tui-agent/src/app.rs` | `active_tab` | function | named | 473 | *RepoVerified* |
| `vibecrafted-app/tui-agent/src/app.rs` | `adjust_dispatch_selection` | function | named | 576 | *RepoVerified* |
| `vibecrafted-app/tui-agent/src/app.rs` | `agents` | function | named | 1215 | *RepoVerified* |
| `vibecrafted-app/tui-agent/src/app.rs` | `append_status` | function | named | 611 | *RepoVerified* |
| `vibecrafted-app/tui-agent/src/app.rs` | `archive_selected_run` | function | named | 444 | *RepoVerified* |
| `vibecrafted-app/tui-agent/src/app.rs` | `artifact_lines` | function | named | 1094 | *RepoVerified* |
| `vibecrafted-app/tui-agent/src/app.rs` | `clear_search` | function | named | 436 | *RepoVerified* |
| `vibecrafted-app/tui-agent/src/app.rs` | `clipboard_payload` | function | named | 1100 | *RepoVerified* |
| `vibecrafted-app/tui-agent/src/app.rs` | `copy_selected_run_to_clipboard` | function | named | 1114 | *RepoVerified* |
| `vibecrafted-app/tui-agent/src/app.rs` | `cycle_agent` | function | named | 504 | *RepoVerified* |
| `vibecrafted-app/tui-agent/src/app.rs` | `cycle_runtime` | function | named | 508 | *RepoVerified* |
| `vibecrafted-app/tui-agent/src/app.rs` | `deep_action_index_for_primary_mission_queue_item` | function | named | 975 | *RepoVerified* |
| `vibecrafted-app/tui-agent/src/app.rs` | `deep_actions` | function | named | 891 | *RepoVerified* |
| `vibecrafted-app/tui-agent/src/app.rs` | `deep_control_lines` | function | named | 1007 | *RepoVerified* |
| `vibecrafted-app/tui-agent/src/app.rs` | `default_prompt` | function | named | 1200 | *RepoVerified* |
| `vibecrafted-app/tui-agent/src/app.rs` | `detail_lines` | function | named | 703 | *RepoVerified* |
| `vibecrafted-app/tui-agent/src/app.rs` | `dispatch_focus` | function | named | 563 | *RepoVerified* |
| `vibecrafted-app/tui-agent/src/app.rs` | `error_lines` | function | named | 626 | *RepoVerified* |
| `vibecrafted-app/tui-agent/src/app.rs` | `event_lines` | function | named | 773 | *RepoVerified* |
| `vibecrafted-app/tui-agent/src/app.rs` | `finish_prompt_edit` | function | named | 632 | *RepoVerified* |
| `vibecrafted-app/tui-agent/src/app.rs` | `from_index` | function | named | 34 | *RepoVerified* |
| `vibecrafted-app/tui-agent/src/app.rs` | `handle_ipc_event` | function | named | 356 | *RepoVerified* |
| `vibecrafted-app/tui-agent/src/app.rs` | `help_lines` | function | named | 826 | *RepoVerified* |
| `vibecrafted-app/tui-agent/src/app.rs` | `index` | function | named | 43 | *RepoVerified* |
| `vibecrafted-app/tui-agent/src/app.rs` | `label` | function | named | 25 | *RepoVerified* |
| `vibecrafted-app/tui-agent/src/app.rs` | `launch_command` | function | named | 607 | *RepoVerified* |
| `vibecrafted-app/tui-agent/src/app.rs` | `launch_env` | function | named | 1125 | *RepoVerified* |
| `vibecrafted-app/tui-agent/src/app.rs` | `launch_request` | function | named | 587 | *RepoVerified* |
| `vibecrafted-app/tui-agent/src/app.rs` | `mission_panel_count` | function | named | 1158 | *RepoVerified* |
| `vibecrafted-app/tui-agent/src/app.rs` | `move_deep_selection` | function | named | 990 | *RepoVerified* |
| `vibecrafted-app/tui-agent/src/app.rs` | `move_dispatch_selection` | function | named | 567 | *RepoVerified* |
| `vibecrafted-app/tui-agent/src/app.rs` | `move_mission_focus` | function | named | 332 | *RepoVerified* |
| `vibecrafted-app/tui-agent/src/app.rs` | `move_selection` | function | named | 648 | *RepoVerified* |
| `vibecrafted-app/tui-agent/src/app.rs` | `mux_status_lines` | function | named | 366 | *RepoVerified* |
| `vibecrafted-app/tui-agent/src/app.rs` | `new` | function | named | 258 | *RepoVerified* |
| `vibecrafted-app/tui-agent/src/app.rs` | `next` | function | named | 108 | *RepoVerified* |
| `vibecrafted-app/tui-agent/src/app.rs` | `next_tab` | function | named | 477 | *RepoVerified* |
| `vibecrafted-app/tui-agent/src/app.rs` | `open_artifact` | function | named | 1052 | *RepoVerified* |
| `vibecrafted-app/tui-agent/src/app.rs` | `open_polarize_intent` | function | named | 1069 | *RepoVerified* |
| `vibecrafted-app/tui-agent/src/app.rs` | `polarize_status_lines` | function | named | 393 | *RepoVerified* |
| `vibecrafted-app/tui-agent/src/app.rs` | `preselect_controls_from_mission_queue` | function | named | 982 | *RepoVerified* |
| `vibecrafted-app/tui-agent/src/app.rs` | `previous_tab` | function | named | 482 | *RepoVerified* |
| `vibecrafted-app/tui-agent/src/app.rs` | `prompt_edit_lines` | function | named | 1032 | *RepoVerified* |
| `vibecrafted-app/tui-agent/src/app.rs` | `prompt_lines` | function | named | 789 | *RepoVerified* |
| `vibecrafted-app/tui-agent/src/app.rs` | `push_launch_history` | function | named | 641 | *RepoVerified* |
| `vibecrafted-app/tui-agent/src/app.rs` | `refresh` | function | named | 303 | *RepoVerified* |
| `vibecrafted-app/tui-agent/src/app.rs` | `refresh_mission_control` | function | named | 321 | *RepoVerified* |
| `vibecrafted-app/tui-agent/src/app.rs` | `refresh_mux` | function | named | 348 | *RepoVerified* |
| `vibecrafted-app/tui-agent/src/app.rs` | `refresh_polarize` | function | named | 352 | *RepoVerified* |
| `vibecrafted-app/tui-agent/src/app.rs` | `selected_agent` | function | named | 512 | *RepoVerified* |
| `vibecrafted-app/tui-agent/src/app.rs` | `selected_deep_action` | function | named | 971 | *RepoVerified* |
| `vibecrafted-app/tui-agent/src/app.rs` | `selected_run` | function | named | 469 | *RepoVerified* |
| `vibecrafted-app/tui-agent/src/app.rs` | `set_active_tab` | function | named | 491 | *RepoVerified* |
| `vibecrafted-app/tui-agent/src/app.rs` | `set_launch_kind` | function | named | 496 | *RepoVerified* |
| `vibecrafted-app/tui-agent/src/app.rs` | `set_search_query` | function | named | 431 | *RepoVerified* |
| `vibecrafted-app/tui-agent/src/app.rs` | `shift_agent` | function | named | 516 | *RepoVerified* |
| `vibecrafted-app/tui-agent/src/app.rs` | `shift_launch_kind` | function | named | 543 | *RepoVerified* |
| `vibecrafted-app/tui-agent/src/app.rs` | `shift_runtime` | function | named | 525 | *RepoVerified* |
| `vibecrafted-app/tui-agent/src/app.rs` | `show_error` | function | named | 615 | *RepoVerified* |
| `vibecrafted-app/tui-agent/src/app.rs` | `status_summary` | function | named | 676 | *RepoVerified* |
| `vibecrafted-app/tui-agent/src/app.rs` | `sync_selection` | function | named | 664 | *RepoVerified* |
| `vibecrafted-app/tui-agent/src/app.rs` | `tab_labels` | function | named | 871 | *RepoVerified* |
| `vibecrafted-app/tui-agent/src/app.rs` | `title` | function | named | 100 | *RepoVerified* |
| `vibecrafted-app/tui-agent/src/app.rs` | `toggle_filter` | function | named | 421 | *RepoVerified* |
| `vibecrafted-app/tui-agent/src/config.rs` | `AppConfig` | struct | named | 32 | *RepoVerified* |
| `vibecrafted-app/tui-agent/src/config.rs` | `CliOptions` | struct | named | 7 | *RepoVerified* |
| `vibecrafted-app/tui-agent/src/config.rs` | `build_config` | function | named | 125 | *RepoVerified* |
| `vibecrafted-app/tui-agent/src/config.rs` | `default_command_deck` | function | named | 164 | *RepoVerified* |
| `vibecrafted-app/tui-agent/src/config.rs` | `default_launch_root` | function | named | 195 | *RepoVerified* |
| `vibecrafted-app/tui-agent/src/config.rs` | `default_state_root` | function | named | 149 | *RepoVerified* |
| `vibecrafted-app/tui-agent/src/config.rs` | `default_terminal_binary` | function | named | 182 | *RepoVerified* |
| `vibecrafted-app/tui-agent/src/config.rs` | `default_vibecrafted_home` | function | named | 142 | *RepoVerified* |
| `vibecrafted-app/tui-agent/src/config.rs` | `parse_args` | function | named | 42 | *RepoVerified* |
| `vibecrafted-app/tui-agent/src/config.rs` | `path_display` | function | named | 235 | *RepoVerified* |
| `vibecrafted-app/tui-agent/src/launch.rs` | `LaunchCommand` | struct | named | 108 | *RepoVerified* |
| `vibecrafted-app/tui-agent/src/launch.rs` | `LaunchKind` | enum | named | 10 | *RepoVerified* |
| `vibecrafted-app/tui-agent/src/launch.rs` | `LaunchReadinessProbe` | struct | named | 115 | *RepoVerified* |
| `vibecrafted-app/tui-agent/src/launch.rs` | `LaunchRequest` | struct | named | 94 | *RepoVerified* |
| `vibecrafted-app/tui-agent/src/launch.rs` | `LaunchRuntime` | enum | named | 53 | *RepoVerified* |
| `vibecrafted-app/tui-agent/src/launch.rs` | `VerifyHalt` | enum | named | 405 | *RepoVerified* |
| `vibecrafted-app/tui-agent/src/launch.rs` | `build_launch_command` | function | named | 220 | *RepoVerified* |
| `vibecrafted-app/tui-agent/src/launch.rs` | `command_line` | function | named | 123 | *RepoVerified* |
| `vibecrafted-app/tui-agent/src/launch.rs` | `cycle` | function | named | 69 | *RepoVerified* |
| `vibecrafted-app/tui-agent/src/launch.rs` | `human_description` | function | named | 36 | *RepoVerified* |
| `vibecrafted-app/tui-agent/src/launch.rs` | `human_title` | function | named | 27 | *RepoVerified* |
| `vibecrafted-app/tui-agent/src/launch.rs` | `is_session_visible` | function | named | 185 | *RepoVerified* |
| `vibecrafted-app/tui-agent/src/launch.rs` | `label` | function | named | 18 | *RepoVerified* |
| `vibecrafted-app/tui-agent/src/launch.rs` | `pre_launch_verify` | function | named | 410 | *RepoVerified* |
| `vibecrafted-app/tui-agent/src/launch.rs` | `readiness_probe` | function | named | 163 | *RepoVerified* |
| `vibecrafted-app/tui-agent/src/launch.rs` | `spawn` | function | named | 133 | *RepoVerified* |
| `vibecrafted-app/tui-agent/src/launch.rs` | `spawn_detached` | function | named | 143 | *RepoVerified* |
| `vibecrafted-app/tui-agent/src/launch.rs` | `spawn_interactive_with_stderr` | function | named | 153 | *RepoVerified* |
| `vibecrafted-app/tui-agent/src/lib.rs` | `ActionPriority` | reexport | named |  | *RepoVerified* |
| `vibecrafted-app/tui-agent/src/lib.rs` | `ActionQueueItem` | reexport | named |  | *RepoVerified* |
| `vibecrafted-app/tui-agent/src/lib.rs` | `ActionQueueKind` | reexport | named |  | *RepoVerified* |
| `vibecrafted-app/tui-agent/src/lib.rs` | `ActiveDispatch` | reexport | named |  | *RepoVerified* |
| `vibecrafted-app/tui-agent/src/lib.rs` | `AgentStatsRow` | reexport | named |  | *RepoVerified* |
| `vibecrafted-app/tui-agent/src/lib.rs` | `App` | reexport | named |  | *RepoVerified* |
| `vibecrafted-app/tui-agent/src/lib.rs` | `AppConfig` | reexport | named |  | *RepoVerified* |
| `vibecrafted-app/tui-agent/src/lib.rs` | `AppTab` | reexport | named |  | *RepoVerified* |
| `vibecrafted-app/tui-agent/src/lib.rs` | `CliOptions` | reexport | named |  | *RepoVerified* |
| `vibecrafted-app/tui-agent/src/lib.rs` | `DataQuality` | reexport | named |  | *RepoVerified* |
| `vibecrafted-app/tui-agent/src/lib.rs` | `DeepAction` | reexport | named |  | *RepoVerified* |
| `vibecrafted-app/tui-agent/src/lib.rs` | `DispatchFocus` | reexport | named |  | *RepoVerified* |
| `vibecrafted-app/tui-agent/src/lib.rs` | `FailureEntry` | reexport | named |  | *RepoVerified* |
| `vibecrafted-app/tui-agent/src/lib.rs` | `FleetHealthSignal` | reexport | named |  | *RepoVerified* |
| `vibecrafted-app/tui-agent/src/lib.rs` | `FleetHealthStatus` | reexport | named |  | *RepoVerified* |
| `vibecrafted-app/tui-agent/src/lib.rs` | `LaunchCommand` | reexport | named |  | *RepoVerified* |
| `vibecrafted-app/tui-agent/src/lib.rs` | `LaunchFocus` | reexport | named |  | *RepoVerified* |
| `vibecrafted-app/tui-agent/src/lib.rs` | `LaunchKind` | reexport | named |  | *RepoVerified* |
| `vibecrafted-app/tui-agent/src/lib.rs` | `LaunchRunError` | enum | named | 459 | *RepoVerified* |
| `vibecrafted-app/tui-agent/src/lib.rs` | `MissionControlState` | reexport | named |  | *RepoVerified* |
| `vibecrafted-app/tui-agent/src/lib.rs` | `PolarizeBand` | reexport | named |  | *RepoVerified* |
| `vibecrafted-app/tui-agent/src/lib.rs` | `PolarizeIntent` | reexport | named |  | *RepoVerified* |
| `vibecrafted-app/tui-agent/src/lib.rs` | `QueueScope` | reexport | named |  | *RepoVerified* |
| `vibecrafted-app/tui-agent/src/lib.rs` | `READINESS_DEADLINE` | decl | named | 562 | *RepoVerified* |
| `vibecrafted-app/tui-agent/src/lib.rs` | `SkillAgent` | reexport | named |  | *RepoVerified* |
| `vibecrafted-app/tui-agent/src/lib.rs` | `SkillEntry` | reexport | named |  | *RepoVerified* |
| `vibecrafted-app/tui-agent/src/lib.rs` | `SkillPayload` | reexport | named |  | *RepoVerified* |
| `vibecrafted-app/tui-agent/src/lib.rs` | `SkillPayloadKind` | reexport | named |  | *RepoVerified* |
| `vibecrafted-app/tui-agent/src/lib.rs` | `SkillStatsRow` | reexport | named |  | *RepoVerified* |
| `vibecrafted-app/tui-agent/src/lib.rs` | `WaveSegment` | reexport | named |  | *RepoVerified* |
| `vibecrafted-app/tui-agent/src/lib.rs` | `WaveState` | reexport | named |  | *RepoVerified* |
| `vibecrafted-app/tui-agent/src/lib.rs` | `build_config` | reexport | named |  | *RepoVerified* |
| `vibecrafted-app/tui-agent/src/lib.rs` | `default_artifact_root` | reexport | named |  | *RepoVerified* |
| `vibecrafted-app/tui-agent/src/lib.rs` | `detail_lines` | function | named | 476 | *RepoVerified* |
| `vibecrafted-app/tui-agent/src/lib.rs` | `parse_args` | reexport | named |  | *RepoVerified* |
| `vibecrafted-app/tui-agent/src/lib.rs` | `run_cli` | function | named | 38 | *RepoVerified* |
| `vibecrafted-app/tui-agent/src/lib.rs` | `wait_for_interactive_launch` | function | named | 564 | *RepoVerified* |
| `vibecrafted-app/tui-agent/src/mission_control.rs` | `ActionPriority` | enum | named | 209 | *RepoVerified* |
| `vibecrafted-app/tui-agent/src/mission_control.rs` | `ActionQueueItem` | struct | named | 182 | *RepoVerified* |
| `vibecrafted-app/tui-agent/src/mission_control.rs` | `ActionQueueKind` | enum | named | 190 | *RepoVerified* |
| `vibecrafted-app/tui-agent/src/mission_control.rs` | `ActiveDispatch` | struct | named | 75 | *RepoVerified* |
| `vibecrafted-app/tui-agent/src/mission_control.rs` | `AgentStatsRow` | struct | named | 126 | *RepoVerified* |
| `vibecrafted-app/tui-agent/src/mission_control.rs` | `DataQuality` | struct | named | 229 | *RepoVerified* |
| `vibecrafted-app/tui-agent/src/mission_control.rs` | `FailureEntry` | struct | named | 172 | *RepoVerified* |
| `vibecrafted-app/tui-agent/src/mission_control.rs` | `FleetHealthSignal` | struct | named | 146 | *RepoVerified* |
| `vibecrafted-app/tui-agent/src/mission_control.rs` | `FleetHealthStatus` | enum | named | 153 | *RepoVerified* |
| `vibecrafted-app/tui-agent/src/mission_control.rs` | `MissionControlState` | struct | named | 62 | *RepoVerified* |
| `vibecrafted-app/tui-agent/src/mission_control.rs` | `SkillStatsRow` | struct | named | 137 | *RepoVerified* |
| `vibecrafted-app/tui-agent/src/mission_control.rs` | `WaveSegment` | struct | named | 88 | *RepoVerified* |
| `vibecrafted-app/tui-agent/src/mission_control.rs` | `WaveState` | enum | named | 98 | *RepoVerified* |
| `vibecrafted-app/tui-agent/src/mission_control.rs` | `build` | function | named | 271 | *RepoVerified* |
| `vibecrafted-app/tui-agent/src/mission_control.rs` | `build_at` | function | named | 289 | *RepoVerified* |
| `vibecrafted-app/tui-agent/src/mission_control.rs` | `build_at_for_root` | function | named | 304 | *RepoVerified* |
| `vibecrafted-app/tui-agent/src/mission_control.rs` | `build_at_with_intents` | function | named | 293 | *RepoVerified* |
| `vibecrafted-app/tui-agent/src/mission_control.rs` | `build_with_intents` | function | named | 277 | *RepoVerified* |
| `vibecrafted-app/tui-agent/src/mission_control.rs` | `default_artifact_root` | function | named | 2195 | *RepoVerified* |
| `vibecrafted-app/tui-agent/src/mission_control.rs` | `glyph` | function | named | 106 | *RepoVerified* |
| `vibecrafted-app/tui-agent/src/mission_control.rs` | `is_empty` | function | named | 357 | *RepoVerified* |
| `vibecrafted-app/tui-agent/src/mission_control.rs` | `label` | function | named | 115 | *RepoVerified* |
| `vibecrafted-app/tui-agent/src/mission_control.rs` | `marker` | function | named | 161 | *RepoVerified* |
| `vibecrafted-app/tui-agent/src/mission_control.rs` | `rlimit_fsize_bytes` | function | named | 2059 | *RepoVerified* |
| `vibecrafted-app/tui-agent/src/mission_control.rs` | `statvfs_probe` | function | named | 2036 | *RepoVerified* |
| `vibecrafted-app/tui-agent/src/mission_control.rs` | `total_entries` | function | named | 347 | *RepoVerified* |
| `vibecrafted-app/tui-agent/src/mux.rs` | `MuxServerStatus` | enum | named | 28 | *RepoVerified* |
| `vibecrafted-app/tui-agent/src/mux.rs` | `MuxStatusSnapshot` | struct | named | 78 | *RepoVerified* |
| `vibecrafted-app/tui-agent/src/mux.rs` | `MuxSubscriber` | struct | named | 686 | *RepoVerified* |
| `vibecrafted-app/tui-agent/src/mux.rs` | `MuxSummaries` | type | named | 675 | *RepoVerified* |
| `vibecrafted-app/tui-agent/src/mux.rs` | `MuxSummary` | struct | named | 240 | *RepoVerified* |
| `vibecrafted-app/tui-agent/src/mux.rs` | `MuxSummaryState` | enum | named | 258 | *RepoVerified* |
| `vibecrafted-app/tui-agent/src/mux.rs` | `SubscriberState` | enum | named | 678 | *RepoVerified* |
| `vibecrafted-app/tui-agent/src/mux.rs` | `current_summaries` | function | named | 323 | *RepoVerified* |
| `vibecrafted-app/tui-agent/src/mux.rs` | `discover_status_files` | function | named | 178 | *RepoVerified* |
| `vibecrafted-app/tui-agent/src/mux.rs` | `failure_reason` | function | named | 63 | *RepoVerified* |
| `vibecrafted-app/tui-agent/src/mux.rs` | `from_json` | function | named | 101 | *RepoVerified* |
| `vibecrafted-app/tui-agent/src/mux.rs` | `from_path_and_result` | function | named | 267 | *RepoVerified* |
| `vibecrafted-app/tui-agent/src/mux.rs` | `is_healthy` | function | named | 54 | *RepoVerified* |
| `vibecrafted-app/tui-agent/src/mux.rs` | `label` | function | named | 41 | *RepoVerified* |
| `vibecrafted-app/tui-agent/src/mux.rs` | `read` | function | named | 109 | *RepoVerified* |
| `vibecrafted-app/tui-agent/src/mux.rs` | `read_all_known_snapshots` | function | named | 225 | *RepoVerified* |
| `vibecrafted-app/tui-agent/src/mux.rs` | `start` | function | named | 693 | *RepoVerified* |
| `vibecrafted-app/tui-agent/src/mux.rs` | `summary_line` | function | named | 117 | *RepoVerified* |
| `vibecrafted-app/tui-agent/src/polarize.rs` | `PolarizeBand` | enum | named | 9 | *RepoVerified* |
| `vibecrafted-app/tui-agent/src/polarize.rs` | `PolarizeIntent` | struct | named | 46 | *RepoVerified* |
| `vibecrafted-app/tui-agent/src/polarize.rs` | `current_intents` | function | named | 80 | *RepoVerified* |
| `vibecrafted-app/tui-agent/src/polarize.rs` | `current_intents_from_home` | function | named | 86 | *RepoVerified* |
| `vibecrafted-app/tui-agent/src/polarize.rs` | `from_score` | function | named | 17 | *RepoVerified* |
| `vibecrafted-app/tui-agent/src/polarize.rs` | `label` | function | named | 26 | *RepoVerified* |
| `vibecrafted-app/tui-agent/src/polarize.rs` | `prism_preview_lines` | function | named | 131 | *RepoVerified* |
| `vibecrafted-app/tui-agent/src/polarize.rs` | `read_intent` | function | named | 100 | *RepoVerified* |
| `vibecrafted-app/tui-agent/src/polarize.rs` | `recommended_action` | function | named | 35 | *RepoVerified* |
| `vibecrafted-app/tui-agent/src/polarize.rs` | `summary_line` | function | named | 54 | *RepoVerified* |
| `vibecrafted-app/tui-agent/src/skills_catalog.rs` | `CATALOG` | decl | named | 82 | *RepoVerified* |
| `vibecrafted-app/tui-agent/src/skills_catalog.rs` | `SkillAgent` | enum | named | 7 | *RepoVerified* |
| `vibecrafted-app/tui-agent/src/skills_catalog.rs` | `SkillEntry` | struct | named | 62 | *RepoVerified* |
| `vibecrafted-app/tui-agent/src/skills_catalog.rs` | `SkillPayload` | enum | named | 48 | *RepoVerified* |
| `vibecrafted-app/tui-agent/src/skills_catalog.rs` | `SkillPayloadKind` | enum | named | 55 | *RepoVerified* |
| `vibecrafted-app/tui-agent/src/skills_catalog.rs` | `build_skill_launch_command` | function | named | 243 | *RepoVerified* |
| `vibecrafted-app/tui-agent/src/skills_catalog.rs` | `catalog_entry` | function | named | 239 | *RepoVerified* |
| `vibecrafted-app/tui-agent/src/skills_catalog.rs` | `command_token` | function | named | 71 | *RepoVerified* |
| `vibecrafted-app/tui-agent/src/skills_catalog.rs` | `emphasized` | function | named | 77 | *RepoVerified* |
| `vibecrafted-app/tui-agent/src/skills_catalog.rs` | `from_cli_token` | function | named | 24 | *RepoVerified* |
| `vibecrafted-app/tui-agent/src/skills_catalog.rs` | `label` | function | named | 15 | *RepoVerified* |
| `vibecrafted-app/tui-agent/src/skills_catalog.rs` | `resolved_cli_token` | function | named | 33 | *RepoVerified* |
| `vibecrafted-app/tui-agent/src/state.rs` | `ControlPlaneState` | struct | named | 11 | *RepoVerified* |
| `vibecrafted-app/tui-agent/src/state.rs` | `RenderedRun` | struct | named | 146 | *RepoVerified* |
| `vibecrafted-app/tui-agent/src/state.rs` | `RunEvent` | struct | named | 133 | *RepoVerified* |
| `vibecrafted-app/tui-agent/src/state.rs` | `RunKind` | enum | named | 50 | *RepoVerified* |
| `vibecrafted-app/tui-agent/src/state.rs` | `RunSnapshot` | struct | named | 87 | *RepoVerified* |
| `vibecrafted-app/tui-agent/src/state.rs` | `classify_run` | function | named | 176 | *RepoVerified* |
| `vibecrafted-app/tui-agent/src/state.rs` | `display_state` | function | named | 123 | *RepoVerified* |
| `vibecrafted-app/tui-agent/src/state.rs` | `empty` | function | named | 39 | *RepoVerified* |
| `vibecrafted-app/tui-agent/src/state.rs` | `label` | function | named | 61 | *RepoVerified* |
| `vibecrafted-app/tui-agent/src/state.rs` | `load` | function | named | 19 | *RepoVerified* |
| `vibecrafted-app/tui-agent/src/state.rs` | `render_runs` | function | named | 153 | *RepoVerified* |
| `vibecrafted-app/tui-agent/src/state.rs` | `sort_rank` | function | named | 73 | *RepoVerified* |
| `vibecrafted-app/tui-agent/src/ui.rs` | `draw` | function | named | 12 | *RepoVerified* |
| `vibecrafted-app/tui-agent/src/ui.rs` | `draw_client_drift_overlay` | function | named | 1394 | *RepoVerified* |

### Imports

| File | Source | Kind | Resolution | Authority |
|---|---|---|---|---|
| `vibecrafted-app/mux-agent/src/bin/rmcp-mux-proxy.rs` | `anyhow::Result` | static | unknown | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/bin/rmcp-mux-proxy.rs` | `clap::Parser` | static | unknown | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/bin/rmcp-mux-proxy.rs` | `std::path` | static | unknown | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/bin/rmcp-mux-proxy.rs` | `tokio::io` | static | unknown | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/bin/rmcp-mux-proxy.rs` | `tokio::net::UnixStream` | static | unknown | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/bin/rmcp-mux.rs` | `anyhow` | static | unknown | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/bin/rmcp-mux.rs` | `clap` | static | unknown | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/bin/rmcp-mux.rs` | `rmcp_mux::config` | static | unknown | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/bin/rmcp-mux.rs` | `rmcp_mux::runtime` | static | unknown | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/bin/rmcp-mux.rs` | `rmcp_mux::scan` | static | unknown | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/bin/rmcp-mux.rs` | `rmcp_mux::wizard::WizardArgs` | static | unknown | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/bin/rmcp-mux.rs` | `rmcp_mux` | static | unknown | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/bin/rmcp-mux.rs` | `std::path::PathBuf` | static | unknown | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/bin/rmcp-mux.rs` | `tokio_util::sync::CancellationToken` | static | unknown | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/bin/rmcp-mux.rs` | `tracing_subscriber::filter::LevelFilter` | static | unknown | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/config.rs` | `anyhow` | static | unknown | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/config.rs` | `serde` | static | unknown | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/config.rs` | `std::collections::HashMap` | static | unknown | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/config.rs` | `std::fs` | static | unknown | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/config.rs` | `std::fs::File` | static | unknown | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/config.rs` | `std::io` | static | unknown | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/config.rs` | `std::path` | static | unknown | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/config.rs` | `std::time::Duration` | static | unknown | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/danger.rs` | `anyhow` | static | unknown | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/danger.rs` | `crate::config` | static | unknown | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/danger.rs` | `crate::scan` | static | unknown | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/danger.rs` | `serde::Serialize` | static | unknown | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/danger.rs` | `std::collections::HashMap` | static | unknown | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/danger.rs` | `std::fs` | static | unknown | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/danger.rs` | `std::path` | static | unknown | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/danger.rs` | `std::time` | static | unknown | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/ipc/command.rs` | `serde` | static | unknown | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/ipc/context.rs` | `crate::ipc::event::IpcEvent` | static | unknown | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/ipc/context.rs` | `std::sync::Arc` | static | unknown | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/ipc/context.rs` | `tokio::sync::broadcast` | static | unknown | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/ipc/event.rs` | `serde` | static | unknown | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/ipc/event.rs` | `std::path::PathBuf` | static | unknown | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/ipc/handlers.rs` | `crate::ipc::command` | static | unknown | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/ipc/handlers.rs` | `crate::ipc::context::MuxControlContext` | static | unknown | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/ipc/handlers.rs` | `crate::scan::scan_hosts` | static | unknown | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/ipc/handlers.rs` | `std::sync::Arc` | static | unknown | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/ipc/mod.rs` | `command` | static | unknown | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/ipc/mod.rs` | `context::MuxControlContext` | static | unknown | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/ipc/mod.rs` | `event::IpcEvent` | static | unknown | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/ipc/mod.rs` | `mod::command` | static | unknown | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/ipc/mod.rs` | `mod::context` | static | unknown | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/ipc/mod.rs` | `mod::event` | static | unknown | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/ipc/mod.rs` | `mod::handlers` | static | unknown | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/ipc/mod.rs` | `mod::server` | static | unknown | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/ipc/mod.rs` | `server` | static | unknown | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/ipc/server.rs` | `crate::ipc::command` | static | unknown | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/ipc/server.rs` | `crate::ipc::context::MuxControlContext` | static | unknown | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/ipc/server.rs` | `crate::ipc::handlers::handle_command` | static | unknown | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/ipc/server.rs` | `std::path::PathBuf` | static | unknown | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/ipc/server.rs` | `std::sync::Arc` | static | unknown | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/ipc/server.rs` | `tokio::io` | static | unknown | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/ipc/server.rs` | `tokio::net` | static | unknown | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/jsonl_bridge.rs` | `anyhow` | static | unknown | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/jsonl_bridge.rs` | `crate::ipc::event::IpcEvent` | static | unknown | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/jsonl_bridge.rs` | `notify` | static | unknown | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/jsonl_bridge.rs` | `serde` | static | unknown | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/jsonl_bridge.rs` | `serde_json::Value` | static | unknown | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/jsonl_bridge.rs` | `std::collections::hash_map::DefaultHasher` | static | unknown | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/jsonl_bridge.rs` | `std::hash` | static | unknown | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/jsonl_bridge.rs` | `std::path` | static | unknown | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/jsonl_bridge.rs` | `std::time::Duration` | static | unknown | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/jsonl_bridge.rs` | `tokio::sync::broadcast` | static | unknown | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/jsonl_bridge.rs` | `tracing` | static | unknown | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/lib.rs` | `anyhow::Result` | static | unknown | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/lib.rs` | `config` | static | unknown | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/lib.rs` | `mod::config` | static | unknown | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/lib.rs` | `mod::danger` | static | unknown | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/lib.rs` | `mod::ipc` | static | unknown | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/lib.rs` | `mod::jsonl_bridge` | static | unknown | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/lib.rs` | `mod::multi` | static | unknown | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/lib.rs` | `mod::multi_tui` | static | unknown | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/lib.rs` | `mod::mux_gen` | static | unknown | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/lib.rs` | `mod::runtime` | static | unknown | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/lib.rs` | `mod::scan` | static | unknown | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/lib.rs` | `mod::state` | static | unknown | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/lib.rs` | `mod::tray` | static | unknown | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/lib.rs` | `mod::tray_dashboard` | static | unknown | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/lib.rs` | `mod::wizard` | static | unknown | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/lib.rs` | `multi` | static | unknown | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/lib.rs` | `multi_tui::run_multi_tui` | static | unknown | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/lib.rs` | `runtime` | static | unknown | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/lib.rs` | `state` | static | unknown | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/lib.rs` | `std::collections::HashMap` | static | unknown | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/lib.rs` | `std::path` | static | unknown | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/lib.rs` | `std::time::Duration` | static | unknown | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/lib.rs` | `tokio_util::sync::CancellationToken` | static | unknown | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/main.rs` | `anyhow` | static | unknown | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/main.rs` | `clap` | static | unknown | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/main.rs` | `crate::config` | static | unknown | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/main.rs` | `crate::runtime` | static | unknown | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/main.rs` | `crate::scan` | static | unknown | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/main.rs` | `crate::wizard::WizardArgs` | static | unknown | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/main.rs` | `mod::config` | static | unknown | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/main.rs` | `mod::danger` | static | unknown | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/main.rs` | `mod::mux_gen` | static | unknown | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/main.rs` | `mod::runtime` | static | unknown | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/main.rs` | `mod::scan` | static | unknown | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/main.rs` | `mod::state` | static | unknown | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/main.rs` | `mod::tray` | static | unknown | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/main.rs` | `mod::wizard` | static | unknown | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/main.rs` | `std::path::PathBuf` | static | unknown | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/main.rs` | `tracing_subscriber::filter::LevelFilter` | static | unknown | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/multi.rs` | `crate::config::ResolvedParams` | static | unknown | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/multi.rs` | `crate::state` | static | unknown | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/multi.rs` | `serde` | static | unknown | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/multi.rs` | `std::collections::HashMap` | static | unknown | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/multi.rs` | `std::sync::Arc` | static | unknown | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/multi.rs` | `std::time::Instant` | static | unknown | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/multi.rs` | `tokio::sync::Mutex` | static | unknown | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/multi.rs` | `tokio_util::sync::CancellationToken` | static | unknown | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/multi_tui.rs` | `crate::multi` | static | unknown | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/multi_tui.rs` | `crate::state::StatusLevel` | static | unknown | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/multi_tui.rs` | `crossterm::event` | static | unknown | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/multi_tui.rs` | `crossterm::execute` | static | unknown | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/multi_tui.rs` | `crossterm::terminal` | static | unknown | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/multi_tui.rs` | `ratatui::Terminal` | static | unknown | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/multi_tui.rs` | `ratatui::backend::CrosstermBackend` | static | unknown | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/multi_tui.rs` | `ratatui::layout` | static | unknown | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/multi_tui.rs` | `ratatui::style` | static | unknown | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/multi_tui.rs` | `ratatui::text` | static | unknown | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/multi_tui.rs` | `ratatui::widgets` | static | unknown | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/multi_tui.rs` | `std::collections::HashMap` | static | unknown | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/multi_tui.rs` | `std::io` | static | unknown | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/multi_tui.rs` | `std::time::Duration` | static | unknown | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/multi_tui.rs` | `tokio::sync` | static | unknown | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/mux_gen.rs` | `anyhow` | static | unknown | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/mux_gen.rs` | `crate::config` | static | unknown | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/mux_gen.rs` | `crate::scan` | static | unknown | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/mux_gen.rs` | `serde::Serialize` | static | unknown | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/mux_gen.rs` | `std::collections::HashMap` | static | unknown | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/mux_gen.rs` | `std::fs` | static | unknown | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/mux_gen.rs` | `std::path` | static | unknown | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/runtime/client.rs` | `anyhow` | static | unknown | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/runtime/client.rs` | `crate::state` | static | unknown | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/runtime/client.rs` | `futures` | static | unknown | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/runtime/client.rs` | `rmcp::transport::async_rw::JsonRpcMessageCodec` | static | unknown | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/runtime/client.rs` | `serde_json::Value` | static | unknown | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/runtime/client.rs` | `std::sync::Arc` | static | unknown | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/runtime/client.rs` | `std::time::Instant` | static | unknown | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/runtime/client.rs` | `super::types::MAX_PENDING` | static | unknown | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/runtime/client.rs` | `tokio::net::UnixStream` | static | unknown | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/runtime/client.rs` | `tokio::sync` | static | unknown | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/runtime/client.rs` | `tokio_util::codec` | static | unknown | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/runtime/client.rs` | `tokio_util::sync::CancellationToken` | static | unknown | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/runtime/client.rs` | `tracing` | static | unknown | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/runtime/heartbeat.rs` | `crate::state` | static | unknown | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/runtime/heartbeat.rs` | `serde` | static | unknown | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/runtime/heartbeat.rs` | `serde_json` | static | unknown | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/runtime/heartbeat.rs` | `std::sync::Arc` | static | unknown | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/runtime/heartbeat.rs` | `std::time` | static | unknown | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/runtime/heartbeat.rs` | `tokio::sync` | static | unknown | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/runtime/heartbeat.rs` | `tokio_util::sync::CancellationToken` | static | unknown | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/runtime/heartbeat.rs` | `tracing` | static | unknown | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/runtime/mod.rs` | `anyhow` | static | unknown | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/runtime/mod.rs` | `client::handle_client` | static | unknown | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/runtime/mod.rs` | `crate::config::ResolvedParams` | static | unknown | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/runtime/mod.rs` | `crate::state` | static | unknown | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/runtime/mod.rs` | `crate::tray` | static | unknown | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/runtime/mod.rs` | `heartbeat` | static | unknown | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/runtime/mod.rs` | `mod::client` | static | unknown | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/runtime/mod.rs` | `mod::heartbeat` | static | unknown | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/runtime/mod.rs` | `mod::proxy` | static | unknown | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/runtime/mod.rs` | `mod::server` | static | unknown | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/runtime/mod.rs` | `mod::status` | static | unknown | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/runtime/mod.rs` | `mod::types` | static | unknown | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/runtime/mod.rs` | `proxy::run_proxy` | static | unknown | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/runtime/mod.rs` | `serde_json::Value` | static | unknown | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/runtime/mod.rs` | `server` | static | unknown | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/runtime/mod.rs` | `status::spawn_status_writer` | static | unknown | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/runtime/mod.rs` | `status` | static | unknown | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/runtime/mod.rs` | `std::sync::Arc` | static | unknown | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/runtime/mod.rs` | `std::time` | static | unknown | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/runtime/mod.rs` | `tokio::io::AsyncWriteExt` | static | unknown | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/runtime/mod.rs` | `tokio::net` | static | unknown | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/runtime/mod.rs` | `tokio::sync` | static | unknown | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/runtime/mod.rs` | `tokio_util::sync::CancellationToken` | static | unknown | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/runtime/mod.rs` | `tracing` | static | unknown | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/runtime/mod.rs` | `types::MAX_PENDING` | static | unknown | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/runtime/mod.rs` | `types::MAX_QUEUE` | static | unknown | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/runtime/mod.rs` | `types::ServerEvent` | static | unknown | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/runtime/proxy.rs` | `anyhow` | static | unknown | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/runtime/proxy.rs` | `futures` | static | unknown | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/runtime/proxy.rs` | `rmcp::transport::async_rw::JsonRpcMessageCodec` | static | unknown | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/runtime/proxy.rs` | `serde_json::Value` | static | unknown | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/runtime/proxy.rs` | `std::path::PathBuf` | static | unknown | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/runtime/proxy.rs` | `tokio::io` | static | unknown | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/runtime/proxy.rs` | `tokio::net::UnixStream` | static | unknown | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/runtime/proxy.rs` | `tokio_util::codec` | static | unknown | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/runtime/proxy.rs` | `tracing` | static | unknown | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/runtime/server.rs` | `anyhow` | static | unknown | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/runtime/server.rs` | `crate::state` | static | unknown | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/runtime/server.rs` | `futures` | static | unknown | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/runtime/server.rs` | `rmcp::transport::async_rw::JsonRpcMessageCodec` | static | unknown | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/runtime/server.rs` | `serde_json::Value` | static | unknown | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/runtime/server.rs` | `std::collections::HashMap` | static | unknown | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/runtime/server.rs` | `std::path::PathBuf` | static | unknown | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/runtime/server.rs` | `std::process::Stdio` | static | unknown | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/runtime/server.rs` | `std::sync::Arc` | static | unknown | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/runtime/server.rs` | `std::time::Duration` | static | unknown | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/runtime/server.rs` | `super::client::update_queue_depth` | static | unknown | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/runtime/server.rs` | `super::types::ServerEvent` | static | unknown | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/runtime/server.rs` | `tokio::process::Command as TokioCommand` | static | unknown | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/runtime/server.rs` | `tokio::sync` | static | unknown | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/runtime/server.rs` | `tokio::time::sleep` | static | unknown | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/runtime/server.rs` | `tokio_util::codec` | static | unknown | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/runtime/server.rs` | `tokio_util::sync::CancellationToken` | static | unknown | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/runtime/server.rs` | `tracing` | static | unknown | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/runtime/status.rs` | `anyhow` | static | unknown | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/runtime/status.rs` | `crate::multi` | static | unknown | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/runtime/status.rs` | `crate::state` | static | unknown | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/runtime/status.rs` | `serde` | static | unknown | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/runtime/status.rs` | `std::collections::HashMap` | static | unknown | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/runtime/status.rs` | `std::path` | static | unknown | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/runtime/status.rs` | `std::sync::Arc` | static | unknown | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/runtime/status.rs` | `std::time::Instant` | static | unknown | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/runtime/status.rs` | `tokio::fs` | static | unknown | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/runtime/status.rs` | `tokio::io` | static | unknown | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/runtime/status.rs` | `tokio::net` | static | unknown | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/runtime/status.rs` | `tokio::sync` | static | unknown | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/runtime/status.rs` | `tokio_util::sync::CancellationToken` | static | unknown | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/runtime/status.rs` | `tracing` | static | unknown | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/runtime/tests.rs` | `crate::config` | static | unknown | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/runtime/tests.rs` | `crate::state` | static | unknown | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/runtime/tests.rs` | `serde_json::Value` | static | unknown | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/runtime/tests.rs` | `std::collections::HashMap` | static | unknown | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/runtime/tests.rs` | `std::env` | static | unknown | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/runtime/tests.rs` | `std::fs` | static | unknown | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/runtime/tests.rs` | `std::path::PathBuf` | static | unknown | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/runtime/tests.rs` | `std::sync::Arc` | static | unknown | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/runtime/tests.rs` | `std::time` | static | unknown | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/runtime/tests.rs` | `super::client::handle_client_message` | static | unknown | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/runtime/tests.rs` | `super::health_check` | static | unknown | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/runtime/tests.rs` | `super::server::handle_server_message` | static | unknown | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/runtime/tests.rs` | `super::status::spawn_status_writer` | static | unknown | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/runtime/tests.rs` | `tempfile::tempdir` | static | unknown | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/runtime/tests.rs` | `tokio::io` | static | unknown | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/runtime/tests.rs` | `tokio::net::UnixListener` | static | unknown | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/runtime/tests.rs` | `tokio::net::UnixStream` | static | unknown | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/runtime/tests.rs` | `tokio::sync::mpsc` | static | unknown | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/runtime/tests.rs` | `tokio::sync` | static | unknown | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/runtime/types.rs` | `serde_json::Value` | static | unknown | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/scan.rs` | `anyhow` | static | unknown | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/scan.rs` | `clap::Args` | static | unknown | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/scan.rs` | `crate::config` | static | unknown | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/scan.rs` | `serde` | static | unknown | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/scan.rs` | `std::collections` | static | unknown | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/scan.rs` | `std::fs` | static | unknown | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/scan.rs` | `std::path` | static | unknown | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/scan.rs` | `std::process` | static | unknown | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/state.rs` | `serde` | static | unknown | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/state.rs` | `serde_json::Value` | static | unknown | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/state.rs` | `std::collections::HashMap` | static | unknown | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/state.rs` | `std::sync::Arc` | static | unknown | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/state.rs` | `std::time` | static | unknown | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/state.rs` | `tokio::sync` | static | unknown | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/tray.rs` | `anyhow::Result` | static | unknown | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/tray.rs` | `crate::state` | static | unknown | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/tray.rs` | `crossbeam_channel` | static | unknown | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/tray.rs` | `image::ImageFormat` | static | unknown | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/tray.rs` | `std::path::Path` | static | unknown | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/tray.rs` | `std::path::PathBuf` | static | unknown | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/tray.rs` | `std::thread` | static | unknown | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/tray.rs` | `std::time::Duration` | static | unknown | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/tray.rs` | `tokio_util::sync::CancellationToken` | static | unknown | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/tray.rs` | `tray_icon` | static | unknown | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/tray_dashboard.rs` | `anyhow::Result` | static | unknown | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/tray_dashboard.rs` | `crate::runtime` | static | unknown | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/tray_dashboard.rs` | `crate::state::StatusLevel` | static | unknown | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/tray_dashboard.rs` | `crate::tray::LoadedIcon` | static | unknown | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/tray_dashboard.rs` | `std::path::PathBuf` | static | unknown | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/tray_dashboard.rs` | `std::thread` | static | unknown | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/tray_dashboard.rs` | `std::time::Duration` | static | unknown | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/tray_dashboard.rs` | `tokio_util::sync::CancellationToken` | static | unknown | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/tray_dashboard.rs` | `tray_icon` | static | unknown | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/wizard/keys.rs` | `anyhow::Result` | static | unknown | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/wizard/keys.rs` | `crossterm::event` | static | unknown | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/wizard/keys.rs` | `std::path::PathBuf` | static | unknown | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/wizard/keys.rs` | `super::services` | static | unknown | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/wizard/keys.rs` | `super::types` | static | unknown | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/wizard/mod.rs` | `anyhow` | static | unknown | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/wizard/mod.rs` | `clap` | static | unknown | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/wizard/mod.rs` | `crate::config::expand_path` | static | unknown | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/wizard/mod.rs` | `crate::scan` | static | unknown | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/wizard/mod.rs` | `crossterm::event` | static | unknown | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/wizard/mod.rs` | `crossterm::execute` | static | unknown | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/wizard/mod.rs` | `crossterm::terminal` | static | unknown | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/wizard/mod.rs` | `keys::handle_key` | static | unknown | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/wizard/mod.rs` | `mod::keys` | static | unknown | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/wizard/mod.rs` | `mod::persist` | static | unknown | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/wizard/mod.rs` | `mod::services` | static | unknown | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/wizard/mod.rs` | `mod::types` | static | unknown | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/wizard/mod.rs` | `mod::ui` | static | unknown | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/wizard/mod.rs` | `persist` | static | unknown | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/wizard/mod.rs` | `ratatui::Terminal` | static | unknown | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/wizard/mod.rs` | `ratatui::backend::CrosstermBackend` | static | unknown | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/wizard/mod.rs` | `services` | static | unknown | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/wizard/mod.rs` | `std::io` | static | unknown | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/wizard/mod.rs` | `std::path::PathBuf` | static | unknown | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/wizard/mod.rs` | `std::time::Duration` | static | unknown | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/wizard/mod.rs` | `types` | static | unknown | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/wizard/mod.rs` | `ui::draw_ui` | static | unknown | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/wizard/persist.rs` | `anyhow` | static | unknown | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/wizard/persist.rs` | `crate::config::expand_path` | static | unknown | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/wizard/persist.rs` | `crate::danger` | static | unknown | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/wizard/persist.rs` | `crate::mux_gen` | static | unknown | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/wizard/persist.rs` | `crate::scan` | static | unknown | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/wizard/persist.rs` | `std::io` | static | unknown | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/wizard/persist.rs` | `std::process` | static | unknown | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/wizard/persist.rs` | `super::types` | static | unknown | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/wizard/services.rs` | `crate::config` | static | unknown | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/wizard/services.rs` | `crate::scan` | static | unknown | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/wizard/services.rs` | `std::collections::HashMap` | static | unknown | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/wizard/services.rs` | `std::io` | static | unknown | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/wizard/services.rs` | `std::os::unix::net::UnixStream` | static | unknown | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/wizard/services.rs` | `std::process::Command` | static | unknown | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/wizard/services.rs` | `super::types` | static | unknown | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/wizard/types.rs` | `crate::config::ServerConfig` | static | unknown | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/wizard/types.rs` | `crate::scan` | static | unknown | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/wizard/types.rs` | `std::path::PathBuf` | static | unknown | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/wizard/ui.rs` | `crate::scan::HostKind` | static | unknown | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/wizard/ui.rs` | `ratatui::Frame` | static | unknown | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/wizard/ui.rs` | `ratatui::layout` | static | unknown | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/wizard/ui.rs` | `ratatui::style` | static | unknown | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/wizard/ui.rs` | `ratatui::text` | static | unknown | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/wizard/ui.rs` | `ratatui::widgets` | static | unknown | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/wizard/ui.rs` | `super::types` | static | unknown | *RepoVerified* |
| `vibecrafted-app/mux-agent/tests/jsonl_bridge_test.rs` | `rmcp_mux::ipc::IpcEvent` | static | unknown | *RepoVerified* |
| `vibecrafted-app/mux-agent/tests/jsonl_bridge_test.rs` | `std::time::Duration` | static | unknown | *RepoVerified* |
| `vibecrafted-app/mux-agent/tests/jsonl_bridge_test.rs` | `tempfile::tempdir` | static | unknown | *RepoVerified* |
| `vibecrafted-app/mux-agent/tests/jsonl_bridge_test.rs` | `tokio::sync::broadcast` | static | unknown | *RepoVerified* |
| `vibecrafted-app/shell-agent/app/Vibecrafted/AppDelegate.swift` | `AppKit` | static | unknown | *RepoVerified* |
| `vibecrafted-app/shell-agent/app/Vibecrafted/Bridge/vibecrafted_shell_ffi.swift` | `Foundation` | static | unknown | *RepoVerified* |
| `vibecrafted-app/shell-agent/app/Vibecrafted/Bridge/vibecrafted_shell_ffi.swift` | `vibecrafted_shell_ffiFFI` | static | unknown | *RepoVerified* |
| `vibecrafted-app/shell-agent/app/Vibecrafted/Views/CanvasViewController.swift` | `AppKit` | static | unknown | *RepoVerified* |
| `vibecrafted-app/shell-agent/app/Vibecrafted/Views/InspectorViewController.swift` | `AppKit` | static | unknown | *RepoVerified* |
| `vibecrafted-app/shell-agent/app/Vibecrafted/Views/MainSplitViewController.swift` | `AppKit` | static | unknown | *RepoVerified* |
| `vibecrafted-app/shell-agent/app/Vibecrafted/Views/MainWindowController.swift` | `AppKit` | static | unknown | *RepoVerified* |
| `vibecrafted-app/shell-agent/app/Vibecrafted/Views/SidebarViewController.swift` | `AppKit` | static | unknown | *RepoVerified* |
| `vibecrafted-app/shell-agent/app/Vibecrafted/main.swift` | `AppKit` | static | unknown | *RepoVerified* |
| `vibecrafted-app/shell-agent/ffi/src/lib.rs` | `std::path::PathBuf` | static | unknown | *RepoVerified* |
| `vibecrafted-app/shell-agent/ffi/src/lib.rs` | `std::sync::OnceLock` | static | unknown | *RepoVerified* |
| `vibecrafted-app/shell-agent/ffi/src/lib.rs` | `tray_agent::ipc_client` | static | unknown | *RepoVerified* |
| `vibecrafted-app/shell-agent/ffi/src/lib.rs` | `voc::config` | static | unknown | *RepoVerified* |
| `vibecrafted-app/shell-agent/ffi/src/lib.rs` | `voc::mission_control` | static | unknown | *RepoVerified* |
| `vibecrafted-app/shell-agent/ffi/src/lib.rs` | `voc::state::ControlPlaneState` | static | unknown | *RepoVerified* |
| `vibecrafted-app/tray-agent/src/bin/vc-mux-tray.rs` | `clap` | static | unknown | *RepoVerified* |
| `vibecrafted-app/tray-agent/src/bin/vc-mux-tray.rs` | `std::path::PathBuf` | static | unknown | *RepoVerified* |
| `vibecrafted-app/tray-agent/src/bin/vc-mux-tray.rs` | `tracing_subscriber::EnvFilter` | static | unknown | *RepoVerified* |
| `vibecrafted-app/tray-agent/src/handlers.rs` | `arboard::Clipboard` | static | unknown | *RepoVerified* |
| `vibecrafted-app/tray-agent/src/handlers.rs` | `crate::ipc_client` | static | unknown | *RepoVerified* |
| `vibecrafted-app/tray-agent/src/handlers.rs` | `crate::ipc_client` | static | unknown | *RepoVerified* |
| `vibecrafted-app/tray-agent/src/handlers.rs` | `crate::state` | static | unknown | *RepoVerified* |
| `vibecrafted-app/tray-agent/src/handlers.rs` | `crate::types` | static | unknown | *RepoVerified* |
| `vibecrafted-app/tray-agent/src/handlers.rs` | `muda::MenuId` | static | unknown | *RepoVerified* |
| `vibecrafted-app/tray-agent/src/handlers.rs` | `std::path` | static | unknown | *RepoVerified* |
| `vibecrafted-app/tray-agent/src/handlers.rs` | `std::process::Command` | static | unknown | *RepoVerified* |
| `vibecrafted-app/tray-agent/src/handlers.rs` | `tracing` | static | unknown | *RepoVerified* |
| `vibecrafted-app/tray-agent/src/icons.rs` | `anyhow::Result` | static | unknown | *RepoVerified* |
| `vibecrafted-app/tray-agent/src/icons.rs` | `crate::types::TrayStatus` | static | unknown | *RepoVerified* |
| `vibecrafted-app/tray-agent/src/icons.rs` | `image` | static | unknown | *RepoVerified* |
| `vibecrafted-app/tray-agent/src/icons.rs` | `tracing::debug` | static | unknown | *RepoVerified* |
| `vibecrafted-app/tray-agent/src/icons.rs` | `tray_icon::Icon` | static | unknown | *RepoVerified* |
| `vibecrafted-app/tray-agent/src/ipc_client.rs` | `anyhow` | static | unknown | *RepoVerified* |
| `vibecrafted-app/tray-agent/src/ipc_client.rs` | `crate::state` | static | unknown | *RepoVerified* |
| `vibecrafted-app/tray-agent/src/ipc_client.rs` | `crate::types` | static | unknown | *RepoVerified* |
| `vibecrafted-app/tray-agent/src/ipc_client.rs` | `mux_agent::ipc` | static | unknown | *RepoVerified* |
| `vibecrafted-app/tray-agent/src/ipc_client.rs` | `std::path` | static | unknown | *RepoVerified* |
| `vibecrafted-app/tray-agent/src/ipc_client.rs` | `std::time::Duration` | static | unknown | *RepoVerified* |
| `vibecrafted-app/tray-agent/src/ipc_client.rs` | `tokio::io` | static | unknown | *RepoVerified* |
| `vibecrafted-app/tray-agent/src/ipc_client.rs` | `tokio::net::UnixStream` | static | unknown | *RepoVerified* |
| `vibecrafted-app/tray-agent/src/ipc_client.rs` | `tracing::warn` | static | unknown | *RepoVerified* |
| `vibecrafted-app/tray-agent/src/lib.rs` | `anyhow::Result` | static | unknown | *RepoVerified* |
| `vibecrafted-app/tray-agent/src/lib.rs` | `mod::handlers` | static | unknown | *RepoVerified* |
| `vibecrafted-app/tray-agent/src/lib.rs` | `mod::icons` | static | unknown | *RepoVerified* |
| `vibecrafted-app/tray-agent/src/lib.rs` | `mod::ipc_client` | static | unknown | *RepoVerified* |
| `vibecrafted-app/tray-agent/src/lib.rs` | `mod::menu` | static | unknown | *RepoVerified* |
| `vibecrafted-app/tray-agent/src/lib.rs` | `mod::state` | static | unknown | *RepoVerified* |
| `vibecrafted-app/tray-agent/src/lib.rs` | `mod::types` | static | unknown | *RepoVerified* |
| `vibecrafted-app/tray-agent/src/lib.rs` | `state` | static | unknown | *RepoVerified* |
| `vibecrafted-app/tray-agent/src/lib.rs` | `std::path::PathBuf` | static | unknown | *RepoVerified* |
| `vibecrafted-app/tray-agent/src/lib.rs` | `std::sync::OnceLock` | static | unknown | *RepoVerified* |
| `vibecrafted-app/tray-agent/src/lib.rs` | `std::sync::atomic` | static | unknown | *RepoVerified* |
| `vibecrafted-app/tray-agent/src/lib.rs` | `std::thread` | static | unknown | *RepoVerified* |
| `vibecrafted-app/tray-agent/src/lib.rs` | `std::time` | static | unknown | *RepoVerified* |
| `vibecrafted-app/tray-agent/src/lib.rs` | `tao::event_loop` | static | unknown | *RepoVerified* |
| `vibecrafted-app/tray-agent/src/lib.rs` | `tracing` | static | unknown | *RepoVerified* |
| `vibecrafted-app/tray-agent/src/lib.rs` | `tray_icon` | static | unknown | *RepoVerified* |
| `vibecrafted-app/tray-agent/src/lib.rs` | `types` | static | unknown | *RepoVerified* |
| `vibecrafted-app/tray-agent/src/menu.rs` | `anyhow::Result` | static | unknown | *RepoVerified* |
| `vibecrafted-app/tray-agent/src/menu.rs` | `crate::ipc_client` | static | unknown | *RepoVerified* |
| `vibecrafted-app/tray-agent/src/menu.rs` | `crate::types::MenuIds` | static | unknown | *RepoVerified* |
| `vibecrafted-app/tray-agent/src/menu.rs` | `muda::accelerator` | static | unknown | *RepoVerified* |
| `vibecrafted-app/tray-agent/src/menu.rs` | `muda` | static | unknown | *RepoVerified* |
| `vibecrafted-app/tray-agent/src/menu.rs` | `std::cell::RefCell` | static | unknown | *RepoVerified* |
| `vibecrafted-app/tray-agent/src/menu.rs` | `std::env` | static | unknown | *RepoVerified* |
| `vibecrafted-app/tray-agent/src/menu.rs` | `std::sync::atomic` | static | unknown | *RepoVerified* |
| `vibecrafted-app/tray-agent/src/state.rs` | `crate::types` | static | unknown | *RepoVerified* |
| `vibecrafted-app/tray-agent/src/state.rs` | `crossbeam_channel` | static | unknown | *RepoVerified* |
| `vibecrafted-app/tray-agent/src/state.rs` | `std::collections` | static | unknown | *RepoVerified* |
| `vibecrafted-app/tray-agent/src/state.rs` | `std::sync` | static | unknown | *RepoVerified* |
| `vibecrafted-app/tray-agent/src/state.rs` | `tracing::debug` | static | unknown | *RepoVerified* |
| `vibecrafted-app/tray-agent/src/types.rs` | `muda::MenuId` | static | unknown | *RepoVerified* |
| `vibecrafted-app/tray-agent/src/types.rs` | `mux_agent::ipc::ClientKind` | static | unknown | *RepoVerified* |
| `vibecrafted-app/tray-agent/src/types.rs` | `std::path::PathBuf` | static | unknown | *RepoVerified* |
| `vibecrafted-app/tray-agent/tests/ipc_client.rs` | `mux_agent::ipc::command` | static | unknown | *RepoVerified* |
| `vibecrafted-app/tray-agent/tests/ipc_client.rs` | `tray_agent::ipc_client` | static | unknown | *RepoVerified* |
| `vibecrafted-app/tray-agent/tests/spawn_update_render_test.rs` | `mux_agent::ipc` | static | unknown | *RepoVerified* |
| `vibecrafted-app/tray-agent/tests/spawn_update_render_test.rs` | `tray_agent::ipc_client::from_mux_response` | static | unknown | *RepoVerified* |
| `vibecrafted-app/tray-agent/tests/spawn_update_render_test.rs` | `tray_agent::types::TrayUpdate` | static | unknown | *RepoVerified* |
| `vibecrafted-app/tui-agent/src/app.rs` | `crate::config` | static | unknown | *RepoVerified* |
| `vibecrafted-app/tui-agent/src/app.rs` | `crate::launch` | static | unknown | *RepoVerified* |
| `vibecrafted-app/tui-agent/src/app.rs` | `crate::mission_control` | static | unknown | *RepoVerified* |
| `vibecrafted-app/tui-agent/src/app.rs` | `crate::polarize` | static | unknown | *RepoVerified* |
| `vibecrafted-app/tui-agent/src/app.rs` | `crate::skills_catalog` | static | unknown | *RepoVerified* |
| `vibecrafted-app/tui-agent/src/app.rs` | `crate::state` | static | unknown | *RepoVerified* |
| `vibecrafted-app/tui-agent/src/app.rs` | `std::collections::BTreeMap` | static | unknown | *RepoVerified* |
| `vibecrafted-app/tui-agent/src/app.rs` | `std::ffi::OsString` | static | unknown | *RepoVerified* |
| `vibecrafted-app/tui-agent/src/app.rs` | `std::fs` | static | unknown | *RepoVerified* |
| `vibecrafted-app/tui-agent/src/app.rs` | `std::path` | static | unknown | *RepoVerified* |
| `vibecrafted-app/tui-agent/src/bin/vc_admin.rs` | `anyhow::Context` | static | unknown | *RepoVerified* |
| `vibecrafted-app/tui-agent/src/bin/vc_admin.rs` | `clap` | static | unknown | *RepoVerified* |
| `vibecrafted-app/tui-agent/src/bin/vc_admin.rs` | `std::fmt::Write as _` | static | unknown | *RepoVerified* |
| `vibecrafted-app/tui-agent/src/bin/vc_admin.rs` | `std::io` | static | unknown | *RepoVerified* |
| `vibecrafted-app/tui-agent/src/bin/vc_admin.rs` | `std::path::PathBuf` | static | unknown | *RepoVerified* |
| `vibecrafted-app/tui-agent/src/bin/vc_admin.rs` | `std::thread` | static | unknown | *RepoVerified* |
| `vibecrafted-app/tui-agent/src/bin/vc_admin.rs` | `std::time::Duration` | static | unknown | *RepoVerified* |
| `vibecrafted-app/tui-agent/src/bin/vc_admin.rs` | `voc::mission_control::default_artifact_root` | static | unknown | *RepoVerified* |
| `vibecrafted-app/tui-agent/src/bin/vc_admin.rs` | `voc::state::ControlPlaneState` | static | unknown | *RepoVerified* |
| `vibecrafted-app/tui-agent/src/bin/vc_admin.rs` | `voc` | static | unknown | *RepoVerified* |
| `vibecrafted-app/tui-agent/src/config.rs` | `crate::launch::LaunchRuntime` | static | unknown | *RepoVerified* |
| `vibecrafted-app/tui-agent/src/config.rs` | `std::env` | static | unknown | *RepoVerified* |
| `vibecrafted-app/tui-agent/src/config.rs` | `std::path` | static | unknown | *RepoVerified* |
| `vibecrafted-app/tui-agent/src/config.rs` | `std::time::Duration` | static | unknown | *RepoVerified* |
| `vibecrafted-app/tui-agent/src/launch.rs` | `anyhow::Context` | static | unknown | *RepoVerified* |
| `vibecrafted-app/tui-agent/src/launch.rs` | `std::collections::BTreeMap` | static | unknown | *RepoVerified* |
| `vibecrafted-app/tui-agent/src/launch.rs` | `std::env` | static | unknown | *RepoVerified* |
| `vibecrafted-app/tui-agent/src/launch.rs` | `std::ffi::OsString` | static | unknown | *RepoVerified* |
| `vibecrafted-app/tui-agent/src/launch.rs` | `std::path` | static | unknown | *RepoVerified* |
| `vibecrafted-app/tui-agent/src/launch.rs` | `std::process` | static | unknown | *RepoVerified* |
| `vibecrafted-app/tui-agent/src/launch.rs` | `std::str::FromStr` | static | unknown | *RepoVerified* |
| `vibecrafted-app/tui-agent/src/lib.rs` | `anyhow::Context` | static | unknown | *RepoVerified* |
| `vibecrafted-app/tui-agent/src/lib.rs` | `app` | static | unknown | *RepoVerified* |
| `vibecrafted-app/tui-agent/src/lib.rs` | `config` | static | unknown | *RepoVerified* |
| `vibecrafted-app/tui-agent/src/lib.rs` | `crossterm::event` | static | unknown | *RepoVerified* |
| `vibecrafted-app/tui-agent/src/lib.rs` | `crossterm::execute` | static | unknown | *RepoVerified* |
| `vibecrafted-app/tui-agent/src/lib.rs` | `crossterm::terminal` | static | unknown | *RepoVerified* |
| `vibecrafted-app/tui-agent/src/lib.rs` | `launch` | static | unknown | *RepoVerified* |
| `vibecrafted-app/tui-agent/src/lib.rs` | `mission_control` | static | unknown | *RepoVerified* |
| `vibecrafted-app/tui-agent/src/lib.rs` | `mod::app` | static | unknown | *RepoVerified* |
| `vibecrafted-app/tui-agent/src/lib.rs` | `mod::config` | static | unknown | *RepoVerified* |
| `vibecrafted-app/tui-agent/src/lib.rs` | `mod::launch` | static | unknown | *RepoVerified* |
| `vibecrafted-app/tui-agent/src/lib.rs` | `mod::mission_control` | static | unknown | *RepoVerified* |
| `vibecrafted-app/tui-agent/src/lib.rs` | `mod::mux` | static | unknown | *RepoVerified* |
| `vibecrafted-app/tui-agent/src/lib.rs` | `mod::polarize` | static | unknown | *RepoVerified* |
| `vibecrafted-app/tui-agent/src/lib.rs` | `mod::skills_catalog` | static | unknown | *RepoVerified* |
| `vibecrafted-app/tui-agent/src/lib.rs` | `mod::state` | static | unknown | *RepoVerified* |
| `vibecrafted-app/tui-agent/src/lib.rs` | `mod::ui` | static | unknown | *RepoVerified* |
| `vibecrafted-app/tui-agent/src/lib.rs` | `notify` | static | unknown | *RepoVerified* |
| `vibecrafted-app/tui-agent/src/lib.rs` | `polarize` | static | unknown | *RepoVerified* |
| `vibecrafted-app/tui-agent/src/lib.rs` | `ratatui::Terminal` | static | unknown | *RepoVerified* |
| `vibecrafted-app/tui-agent/src/lib.rs` | `ratatui::backend::CrosstermBackend` | static | unknown | *RepoVerified* |
| `vibecrafted-app/tui-agent/src/lib.rs` | `skills_catalog` | static | unknown | *RepoVerified* |
| `vibecrafted-app/tui-agent/src/lib.rs` | `std::io` | static | unknown | *RepoVerified* |
| `vibecrafted-app/tui-agent/src/lib.rs` | `std::path` | static | unknown | *RepoVerified* |
| `vibecrafted-app/tui-agent/src/lib.rs` | `std::process::Output` | static | unknown | *RepoVerified* |
| `vibecrafted-app/tui-agent/src/lib.rs` | `std::sync::mpsc` | static | unknown | *RepoVerified* |
| `vibecrafted-app/tui-agent/src/lib.rs` | `std::thread` | static | unknown | *RepoVerified* |
| `vibecrafted-app/tui-agent/src/lib.rs` | `std::time` | static | unknown | *RepoVerified* |
| `vibecrafted-app/tui-agent/src/mission_control.rs` | `chrono` | static | unknown | *RepoVerified* |
| `vibecrafted-app/tui-agent/src/mission_control.rs` | `crate::polarize` | static | unknown | *RepoVerified* |
| `vibecrafted-app/tui-agent/src/mission_control.rs` | `crate::state` | static | unknown | *RepoVerified* |
| `vibecrafted-app/tui-agent/src/mission_control.rs` | `serde::Deserialize` | static | unknown | *RepoVerified* |
| `vibecrafted-app/tui-agent/src/mission_control.rs` | `std::collections` | static | unknown | *RepoVerified* |
| `vibecrafted-app/tui-agent/src/mission_control.rs` | `std::env` | static | unknown | *RepoVerified* |
| `vibecrafted-app/tui-agent/src/mission_control.rs` | `std::ffi::CString` | static | unknown | *RepoVerified* |
| `vibecrafted-app/tui-agent/src/mission_control.rs` | `std::fs` | static | unknown | *RepoVerified* |
| `vibecrafted-app/tui-agent/src/mission_control.rs` | `std::mem::MaybeUninit` | static | unknown | *RepoVerified* |
| `vibecrafted-app/tui-agent/src/mission_control.rs` | `std::os::unix::ffi::OsStrExt` | static | unknown | *RepoVerified* |
| `vibecrafted-app/tui-agent/src/mission_control.rs` | `std::path::Path` | static | unknown | *RepoVerified* |
| `vibecrafted-app/tui-agent/src/mission_control.rs` | `std::path` | static | unknown | *RepoVerified* |
| `vibecrafted-app/tui-agent/src/mission_control.rs` | `std::process` | static | unknown | *RepoVerified* |
| `vibecrafted-app/tui-agent/src/mission_control.rs` | `std::sync` | static | unknown | *RepoVerified* |
| `vibecrafted-app/tui-agent/src/mission_control.rs` | `std::time` | static | unknown | *RepoVerified* |
| `vibecrafted-app/tui-agent/src/mission_control.rs` | `super::DiskStats` | static | unknown | *RepoVerified* |
| `vibecrafted-app/tui-agent/src/mux.rs` | `anyhow` | static | unknown | *RepoVerified* |
| `vibecrafted-app/tui-agent/src/mux.rs` | `serde::Deserialize` | static | unknown | *RepoVerified* |
| `vibecrafted-app/tui-agent/src/mux.rs` | `std::env` | static | unknown | *RepoVerified* |
| `vibecrafted-app/tui-agent/src/mux.rs` | `std::fs` | static | unknown | *RepoVerified* |
| `vibecrafted-app/tui-agent/src/mux.rs` | `std::path` | static | unknown | *RepoVerified* |
| `vibecrafted-app/tui-agent/src/mux.rs` | `std::sync` | static | unknown | *RepoVerified* |
| `vibecrafted-app/tui-agent/src/polarize.rs` | `anyhow::Context` | static | unknown | *RepoVerified* |
| `vibecrafted-app/tui-agent/src/polarize.rs` | `serde::Deserialize` | static | unknown | *RepoVerified* |
| `vibecrafted-app/tui-agent/src/polarize.rs` | `std::env` | static | unknown | *RepoVerified* |
| `vibecrafted-app/tui-agent/src/polarize.rs` | `std::fs` | static | unknown | *RepoVerified* |
| `vibecrafted-app/tui-agent/src/polarize.rs` | `std::path` | static | unknown | *RepoVerified* |
| `vibecrafted-app/tui-agent/src/polarize.rs` | `std::time::SystemTime` | static | unknown | *RepoVerified* |
| `vibecrafted-app/tui-agent/src/skills_catalog.rs` | `crate::launch::LaunchCommand` | static | unknown | *RepoVerified* |
| `vibecrafted-app/tui-agent/src/skills_catalog.rs` | `std::collections::BTreeMap` | static | unknown | *RepoVerified* |
| `vibecrafted-app/tui-agent/src/skills_catalog.rs` | `std::ffi::OsString` | static | unknown | *RepoVerified* |
| `vibecrafted-app/tui-agent/src/skills_catalog.rs` | `std::path` | static | unknown | *RepoVerified* |
| `vibecrafted-app/tui-agent/src/state.rs` | `chrono` | static | unknown | *RepoVerified* |
| `vibecrafted-app/tui-agent/src/state.rs` | `serde::Deserialize` | static | unknown | *RepoVerified* |
| `vibecrafted-app/tui-agent/src/state.rs` | `serde_json::Value` | static | unknown | *RepoVerified* |
| `vibecrafted-app/tui-agent/src/state.rs` | `std::cmp::Ordering` | static | unknown | *RepoVerified* |
| `vibecrafted-app/tui-agent/src/state.rs` | `std::collections` | static | unknown | *RepoVerified* |
| `vibecrafted-app/tui-agent/src/state.rs` | `std::fs` | static | unknown | *RepoVerified* |
| `vibecrafted-app/tui-agent/src/state.rs` | `std::io` | static | unknown | *RepoVerified* |
| `vibecrafted-app/tui-agent/src/state.rs` | `std::path` | static | unknown | *RepoVerified* |
| `vibecrafted-app/tui-agent/src/ui.rs` | `crate::app` | static | unknown | *RepoVerified* |
| `vibecrafted-app/tui-agent/src/ui.rs` | `crate::mission_control` | static | unknown | *RepoVerified* |
| `vibecrafted-app/tui-agent/src/ui.rs` | `crate::state::RunKind` | static | unknown | *RepoVerified* |
| `vibecrafted-app/tui-agent/src/ui.rs` | `ratatui::prelude` | static | unknown | *RepoVerified* |
| `vibecrafted-app/tui-agent/src/ui.rs` | `ratatui::style` | static | unknown | *RepoVerified* |
| `vibecrafted-app/tui-agent/src/ui.rs` | `ratatui::text` | static | unknown | *RepoVerified* |
| `vibecrafted-app/tui-agent/src/ui.rs` | `ratatui::widgets` | static | unknown | *RepoVerified* |
| `vibecrafted-app/tui-agent/tests/launch_readiness.rs` | `std::collections::BTreeMap` | static | unknown | *RepoVerified* |
| `vibecrafted-app/tui-agent/tests/launch_readiness.rs` | `std::ffi::OsString` | static | unknown | *RepoVerified* |
| `vibecrafted-app/tui-agent/tests/launch_readiness.rs` | `std::fs` | static | unknown | *RepoVerified* |
| `vibecrafted-app/tui-agent/tests/launch_readiness.rs` | `std::os::unix::fs::PermissionsExt` | static | unknown | *RepoVerified* |
| `vibecrafted-app/tui-agent/tests/launch_readiness.rs` | `std::path` | static | unknown | *RepoVerified* |
| `vibecrafted-app/tui-agent/tests/launch_readiness.rs` | `std::time` | static | unknown | *RepoVerified* |
| `vibecrafted-app/tui-agent/tests/launch_readiness.rs` | `tempfile::TempDir` | static | unknown | *RepoVerified* |
| `vibecrafted-app/tui-agent/tests/launch_readiness.rs` | `voc::launch::LaunchCommand` | static | unknown | *RepoVerified* |
| `vibecrafted-app/tui-agent/tests/launch_readiness.rs` | `voc` | static | unknown | *RepoVerified* |
| `vibecrafted-app/tui-agent/tests/mission_control_snapshots.rs` | `ratatui::Terminal` | static | unknown | *RepoVerified* |
| `vibecrafted-app/tui-agent/tests/mission_control_snapshots.rs` | `ratatui::backend::TestBackend` | static | unknown | *RepoVerified* |
| `vibecrafted-app/tui-agent/tests/mission_control_snapshots.rs` | `ratatui::buffer::Buffer` | static | unknown | *RepoVerified* |
| `vibecrafted-app/tui-agent/tests/mission_control_snapshots.rs` | `ratatui::style::Color` | static | unknown | *RepoVerified* |
| `vibecrafted-app/tui-agent/tests/mission_control_snapshots.rs` | `std::fs` | static | unknown | *RepoVerified* |
| `vibecrafted-app/tui-agent/tests/mission_control_snapshots.rs` | `std::path` | static | unknown | *RepoVerified* |
| `vibecrafted-app/tui-agent/tests/mission_control_snapshots.rs` | `std::time::Duration` | static | unknown | *RepoVerified* |
| `vibecrafted-app/tui-agent/tests/mission_control_snapshots.rs` | `tempfile::tempdir` | static | unknown | *RepoVerified* |
| `vibecrafted-app/tui-agent/tests/mission_control_snapshots.rs` | `voc::app` | static | unknown | *RepoVerified* |
| `vibecrafted-app/tui-agent/tests/mission_control_snapshots.rs` | `voc::config::AppConfig` | static | unknown | *RepoVerified* |
| `vibecrafted-app/tui-agent/tests/mission_control_snapshots.rs` | `voc::launch` | static | unknown | *RepoVerified* |
| `vibecrafted-app/tui-agent/tests/mission_control_snapshots.rs` | `voc::mission_control` | static | unknown | *RepoVerified* |
| `vibecrafted-app/tui-agent/tests/mission_control_snapshots.rs` | `voc::state::ControlPlaneState` | static | unknown | *RepoVerified* |
| `vibecrafted-app/tui-agent/tests/skill_launcher.rs` | `std::collections` | static | unknown | *RepoVerified* |
| `vibecrafted-app/tui-agent/tests/skill_launcher.rs` | `std::ffi::OsString` | static | unknown | *RepoVerified* |
| `vibecrafted-app/tui-agent/tests/skill_launcher.rs` | `std::fs` | static | unknown | *RepoVerified* |
| `vibecrafted-app/tui-agent/tests/skill_launcher.rs` | `std::os::unix::fs::symlink` | static | unknown | *RepoVerified* |
| `vibecrafted-app/tui-agent/tests/skill_launcher.rs` | `std::path` | static | unknown | *RepoVerified* |
| `vibecrafted-app/tui-agent/tests/skill_launcher.rs` | `tempfile::tempdir` | static | unknown | *RepoVerified* |
| `vibecrafted-app/tui-agent/tests/skill_launcher.rs` | `voc::polarize` | static | unknown | *RepoVerified* |
| `vibecrafted-app/tui-agent/tests/skill_launcher.rs` | `voc::skills_catalog` | static | unknown | *RepoVerified* |
| `vibecrafted-app/tui-agent/tests/state_contract.rs` | `std::collections::BTreeMap` | static | unknown | *RepoVerified* |
| `vibecrafted-app/tui-agent/tests/state_contract.rs` | `std::env` | static | unknown | *RepoVerified* |
| `vibecrafted-app/tui-agent/tests/state_contract.rs` | `std::fs` | static | unknown | *RepoVerified* |
| `vibecrafted-app/tui-agent/tests/state_contract.rs` | `std::os::unix::fs::symlink` | static | unknown | *RepoVerified* |
| `vibecrafted-app/tui-agent/tests/state_contract.rs` | `std::path` | static | unknown | *RepoVerified* |
| `vibecrafted-app/tui-agent/tests/state_contract.rs` | `std::sync` | static | unknown | *RepoVerified* |
| `vibecrafted-app/tui-agent/tests/state_contract.rs` | `std::time::Duration` | static | unknown | *RepoVerified* |
| `vibecrafted-app/tui-agent/tests/state_contract.rs` | `tempfile::tempdir` | static | unknown | *RepoVerified* |
| `vibecrafted-app/tui-agent/tests/state_contract.rs` | `voc::app` | static | unknown | *RepoVerified* |
| `vibecrafted-app/tui-agent/tests/state_contract.rs` | `voc::config` | static | unknown | *RepoVerified* |
| `vibecrafted-app/tui-agent/tests/state_contract.rs` | `voc::launch` | static | unknown | *RepoVerified* |
| `vibecrafted-app/tui-agent/tests/state_contract.rs` | `voc::skills_catalog::CATALOG` | static | unknown | *RepoVerified* |
| `vibecrafted-app/tui-agent/tests/state_contract.rs` | `voc::state` | static | unknown | *RepoVerified* |

### Consumers

| File | Import Kind | Imports Used | Authority |
|---|---|---|---|
| `vibecrafted-app/mux-agent/src/danger.rs` | `Direct` | safe_copy_file, safe_read_to_string | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/ipc/context.rs` | `Direct` | IpcEvent | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/ipc/handlers.rs` | `Direct` | MuxControlCommand, MuxControlResponse, NonMuxEntry, VerifyResult | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/ipc/mod.rs` | `Direct` | ClientKind, MuxControlCommand, MuxControlResponse, command | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/ipc/server.rs` | `Direct` | MuxControlCommand, MuxControlResponse | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/jsonl_bridge.rs` | `Direct` | IpcEvent | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/lib.rs` | `Reexport` | CliOptions, Config, ResolvedParams, ServerConfig, resolve_params_multi, config | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/main.rs` | `Direct` | expand_path, load_config, resolve_params, config | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/multi.rs` | `Direct` | ResolvedParams | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/multi_tui.rs` | `Direct` | MultiServerStatus, ServerCommand, format_uptime | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/mux_gen.rs` | `Direct` | Config, ServerConfig, expand_path | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/runtime/client.rs` | `Direct` | HANDSHAKE_TIMEOUT, MuxState, Pending, StatusSnapshot, error_response, publish_status, set_id | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/runtime/heartbeat.rs` | `Direct` | HeartbeatMetrics, MuxState, StatusSnapshot, publish_status | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/runtime/mod.rs` | `Direct` | ResolvedParams | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/runtime/server.rs` | `Direct` | MuxState, ServerStatus, StatusSnapshot, publish_status, set_id | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/runtime/status.rs` | `Direct` | MultiServerStatus, format_uptime | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/runtime/tests.rs` | `Direct` | CliOptions, Config, ResolvedParams, ServerConfig, expand_path, load_config, resolve_params | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/scan.rs` | `Direct` | Config, ServerConfig, expand_path, safe_copy_file, safe_read_to_string | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/tray.rs` | `Direct` | ServerStatus, StatusSnapshot | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/tray_dashboard.rs` | `Transitive` |  | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/wizard/mod.rs` | `Direct` | expand_path | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/wizard/persist.rs` | `Direct` | expand_path | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/wizard/services.rs` | `Direct` | ServerConfig, expand_path | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/wizard/types.rs` | `Direct` | ServerConfig | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/wizard/ui.rs` | `Direct` | HostKind | *RepoVerified* |
| `vibecrafted-app/shell-agent/app/Vibecrafted/AppDelegate.swift` | `Direct` |  | *RepoVerified* |
| `vibecrafted-app/shell-agent/app/Vibecrafted/Bridge/vibecrafted_shell_ffi.swift` | `Direct` |  | *RepoVerified* |
| `vibecrafted-app/shell-agent/app/Vibecrafted/Views/CanvasViewController.swift` | `Direct` |  | *RepoVerified* |
| `vibecrafted-app/shell-agent/app/Vibecrafted/Views/InspectorViewController.swift` | `Direct` |  | *RepoVerified* |
| `vibecrafted-app/shell-agent/app/Vibecrafted/Views/MainSplitViewController.swift` | `Direct` |  | *RepoVerified* |
| `vibecrafted-app/shell-agent/app/Vibecrafted/Views/MainWindowController.swift` | `Direct` |  | *RepoVerified* |
| `vibecrafted-app/shell-agent/app/Vibecrafted/Views/SidebarViewController.swift` | `Direct` |  | *RepoVerified* |
| `vibecrafted-app/shell-agent/app/Vibecrafted/main.swift` | `Direct` |  | *RepoVerified* |
| `vibecrafted-app/tray-agent/src/handlers.rs` | `Direct` | ClientKind, MuxControlResponse, ipc_client | *RepoVerified* |
| `vibecrafted-app/tray-agent/src/icons.rs` | `Direct` | TrayStatus | *RepoVerified* |
| `vibecrafted-app/tray-agent/src/ipc_client.rs` | `Direct` | record_spawn_entry, update_tray_status | *RepoVerified* |
| `vibecrafted-app/tray-agent/src/lib.rs` | `Direct` | handlers | *RepoVerified* |
| `vibecrafted-app/tray-agent/src/menu.rs` | `Direct` | ClientKind, client_label | *RepoVerified* |
| `vibecrafted-app/tray-agent/src/state.rs` | `Direct` | SpawnEntry, TrayMenuEvent, TrayStatus | *RepoVerified* |
| `vibecrafted-app/tui-agent/src/app.rs` | `Direct` | AppConfig, path_display | *RepoVerified* |
| `vibecrafted-app/tui-agent/src/config.rs` | `Direct` | LaunchRuntime | *RepoVerified* |
| `vibecrafted-app/tui-agent/src/lib.rs` | `Reexport` | App, AppTab, DeepAction, DispatchFocus, LaunchFocus, QueueScope, app | *RepoVerified* |
| `vibecrafted-app/tui-agent/src/mission_control.rs` | `Direct` | PolarizeBand, PolarizeIntent | *RepoVerified* |
| `vibecrafted-app/tui-agent/src/skills_catalog.rs` | `Direct` | LaunchCommand | *RepoVerified* |
| `vibecrafted-app/tui-agent/src/ui.rs` | `Direct` | App, AppTab, LaunchFocus | *RepoVerified* |

### Entrypoints

| Path | Kinds | Authority |
|---|---|---|
| `plugins/iterm2/vibecrafted_iterm2/vc_launcher.py` | script | *RepoVerified* |
| `runtime/scripts/codex_stream_bridge.py` | script | *RepoVerified* |
| `scripts/build_marketplace_bundle.py` | script | *RepoVerified* |
| `scripts/check_shell.py` | script | *RepoVerified* |
| `scripts/control_plane_state.py` | script | *RepoVerified* |
| `scripts/installer/vetcoders_installer/__init__.py` | script | *RepoVerified* |
| `scripts/installer_gui.py` | script | *RepoVerified* |
| `scripts/version_bump.py` | script | *RepoVerified* |
| `scripts/vetcoders_install.py` | script | *RepoVerified* |
| `tools/scripts/chat/chat-cli.py` | script | *RepoVerified* |
| `tools/scripts/github/repo-transfer.py` | script | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/bin/rmcp-mux-proxy.rs` | main, async_main | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/bin/rmcp-mux.rs` | main | *RepoVerified* |
| `vibecrafted-app/mux-agent/src/main.rs` | main, async_main | *RepoVerified* |
| `vibecrafted-app/shell-agent/ffi/build.rs` | main | *RepoVerified* |
| `vibecrafted-app/shell-agent/uniffi-bindgen/src/main.rs` | main | *RepoVerified* |
| `vibecrafted-app/tray-agent/src/bin/vc-mux-tray.rs` | main | *RepoVerified* |
| `vibecrafted-app/tui-agent/src/bin/vc_admin.rs` | main | *RepoVerified* |
| `vibecrafted-app/tui-agent/src/main.rs` | main | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/cli.py` | script | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/compact_hooks.py` | script | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/control_plane.py` | script | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/cron.py` | script | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/dispatch/cli.py` | script | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/dispatch/doctor.py` | script | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/dispatcher.py` | script | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/loop.py` | script | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/ship.py` | script | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/spawn.py` | script | *RepoVerified* |
| `vibecrafted-mcp/vibecrafted_mcp/server.py` | script | *RepoVerified* |
| `vibecrafted-vm/wizard/vc-onboard.py` | script | *RepoVerified* |

## Runtime Slice

### Idiom Tags

- **.PHONY** (`vibecrafted-app/Makefile::.PHONY`): GNU Make directive marking targets that are not files; targets listed after .PHONY are public entrypoints. (Role: metadata, Source: embedded_default) *LoctreeDerived*
- **.PHONY** (`vibecrafted-app/Makefile::app`): Target 'app' is listed in a .PHONY directive; operator-invoked make target. (Role: public_entrypoint, Source: inferred_from_code) *SemanticGuess*
- **.PHONY** (`vibecrafted-app/Makefile::app-debug`): Target 'app-debug' is listed in a .PHONY directive; operator-invoked make target. (Role: public_entrypoint, Source: inferred_from_code) *SemanticGuess*
- **.PHONY** (`vibecrafted-app/Makefile::bindings`): Target 'bindings' is listed in a .PHONY directive; operator-invoked make target. (Role: public_entrypoint, Source: inferred_from_code) *SemanticGuess*
- **.PHONY** (`vibecrafted-app/Makefile::check`): Target 'check' is listed in a .PHONY directive; operator-invoked make target. (Role: public_entrypoint, Source: inferred_from_code) *SemanticGuess*
- **.PHONY** (`vibecrafted-app/Makefile::clean`): Target 'clean' is listed in a .PHONY directive; operator-invoked make target. (Role: public_entrypoint, Source: inferred_from_code) *SemanticGuess*
- **.PHONY** (`vibecrafted-app/Makefile::dmg`): Target 'dmg' is listed in a .PHONY directive; operator-invoked make target. (Role: public_entrypoint, Source: inferred_from_code) *SemanticGuess*
- **.PHONY** (`vibecrafted-app/Makefile::dmg-signed`): Target 'dmg-signed' is listed in a .PHONY directive; operator-invoked make target. (Role: public_entrypoint, Source: inferred_from_code) *SemanticGuess*
- **.PHONY** (`vibecrafted-app/Makefile::fmt`): Target 'fmt' is listed in a .PHONY directive; operator-invoked make target. (Role: public_entrypoint, Source: inferred_from_code) *SemanticGuess*
- **.PHONY** (`vibecrafted-app/Makefile::fmt-check`): Target 'fmt-check' is listed in a .PHONY directive; operator-invoked make target. (Role: public_entrypoint, Source: inferred_from_code) *SemanticGuess*
- **.PHONY** (`vibecrafted-app/Makefile::gates`): Target 'gates' is listed in a .PHONY directive; operator-invoked make target. (Role: public_entrypoint, Source: inferred_from_code) *SemanticGuess*
- **.PHONY** (`vibecrafted-app/Makefile::help`): Target 'help' is listed in a .PHONY directive; operator-invoked make target. (Role: public_entrypoint, Source: inferred_from_code) *SemanticGuess*
- **.PHONY** (`vibecrafted-app/Makefile::lint`): Target 'lint' is listed in a .PHONY directive; operator-invoked make target. (Role: public_entrypoint, Source: inferred_from_code) *SemanticGuess*
- **.PHONY** (`vibecrafted-app/Makefile::test`): Target 'test' is listed in a .PHONY directive; operator-invoked make target. (Role: public_entrypoint, Source: inferred_from_code) *SemanticGuess*
- **.PHONY** (`vibecrafted-app/Makefile::workspace-check`): Target 'workspace-check' is listed in a .PHONY directive; operator-invoked make target. (Role: public_entrypoint, Source: inferred_from_code) *SemanticGuess*
- **.PHONY** (`vibecrafted-app/Makefile::xcode`): Target 'xcode' is listed in a .PHONY directive; operator-invoked make target. (Role: public_entrypoint, Source: inferred_from_code) *SemanticGuess*
- **.PHONY** (`vibecrafted-app/mux-agent/Makefile::.PHONY`): GNU Make directive marking targets that are not files; targets listed after .PHONY are public entrypoints. (Role: metadata, Source: embedded_default) *LoctreeDerived*
- **.PHONY** (`vibecrafted-app/mux-agent/Makefile::build`): Target 'build' is listed in a .PHONY directive; operator-invoked make target. (Role: public_entrypoint, Source: inferred_from_code) *SemanticGuess*
- **.PHONY** (`vibecrafted-app/mux-agent/Makefile::check`): Target 'check' is listed in a .PHONY directive; operator-invoked make target. (Role: public_entrypoint, Source: inferred_from_code) *SemanticGuess*
- **.PHONY** (`vibecrafted-app/mux-agent/Makefile::clean-runtime`): Target 'clean-runtime' is listed in a .PHONY directive; operator-invoked make target. (Role: public_entrypoint, Source: inferred_from_code) *SemanticGuess*
- **.PHONY** (`vibecrafted-app/mux-agent/Makefile::clippy`): Target 'clippy' is listed in a .PHONY directive; operator-invoked make target. (Role: public_entrypoint, Source: inferred_from_code) *SemanticGuess*
- **.PHONY** (`vibecrafted-app/mux-agent/Makefile::daemon-status`): Target 'daemon-status' is listed in a .PHONY directive; operator-invoked make target. (Role: public_entrypoint, Source: inferred_from_code) *SemanticGuess*
- **.PHONY** (`vibecrafted-app/mux-agent/Makefile::dashboard`): Target 'dashboard' is listed in a .PHONY directive; operator-invoked make target. (Role: public_entrypoint, Source: inferred_from_code) *SemanticGuess*
- **.PHONY** (`vibecrafted-app/mux-agent/Makefile::fmt`): Target 'fmt' is listed in a .PHONY directive; operator-invoked make target. (Role: public_entrypoint, Source: inferred_from_code) *SemanticGuess*
- **.PHONY** (`vibecrafted-app/mux-agent/Makefile::fmt-check`): Target 'fmt-check' is listed in a .PHONY directive; operator-invoked make target. (Role: public_entrypoint, Source: inferred_from_code) *SemanticGuess*
- **.PHONY** (`vibecrafted-app/mux-agent/Makefile::gates`): Target 'gates' is listed in a .PHONY directive; operator-invoked make target. (Role: public_entrypoint, Source: inferred_from_code) *SemanticGuess*
- **.PHONY** (`vibecrafted-app/mux-agent/Makefile::health`): Target 'health' is listed in a .PHONY directive; operator-invoked make target. (Role: public_entrypoint, Source: inferred_from_code) *SemanticGuess*
- **.PHONY** (`vibecrafted-app/mux-agent/Makefile::help`): Target 'help' is listed in a .PHONY directive; operator-invoked make target. (Role: public_entrypoint, Source: inferred_from_code) *SemanticGuess*
- **.PHONY** (`vibecrafted-app/mux-agent/Makefile::proxy`): Target 'proxy' is listed in a .PHONY directive; operator-invoked make target. (Role: public_entrypoint, Source: inferred_from_code) *SemanticGuess*
- **.PHONY** (`vibecrafted-app/mux-agent/Makefile::release`): Target 'release' is listed in a .PHONY directive; operator-invoked make target. (Role: public_entrypoint, Source: inferred_from_code) *SemanticGuess*
- **.PHONY** (`vibecrafted-app/mux-agent/Makefile::run`): Target 'run' is listed in a .PHONY directive; operator-invoked make target. (Role: public_entrypoint, Source: inferred_from_code) *SemanticGuess*
- **.PHONY** (`vibecrafted-app/mux-agent/Makefile::run-tray`): Target 'run-tray' is listed in a .PHONY directive; operator-invoked make target. (Role: public_entrypoint, Source: inferred_from_code) *SemanticGuess*
- **.PHONY** (`vibecrafted-app/mux-agent/Makefile::status-file-init`): Target 'status-file-init' is listed in a .PHONY directive; operator-invoked make target. (Role: public_entrypoint, Source: inferred_from_code) *SemanticGuess*
- **.PHONY** (`vibecrafted-app/mux-agent/Makefile::test`): Target 'test' is listed in a .PHONY directive; operator-invoked make target. (Role: public_entrypoint, Source: inferred_from_code) *SemanticGuess*
- **.PHONY** (`vibecrafted-app/mux-agent/Makefile::test-full`): Target 'test-full' is listed in a .PHONY directive; operator-invoked make target. (Role: public_entrypoint, Source: inferred_from_code) *SemanticGuess*
- **.PHONY** (`vibecrafted-app/mux-agent/Makefile::wizard`): Target 'wizard' is listed in a .PHONY directive; operator-invoked make target. (Role: public_entrypoint, Source: inferred_from_code) *SemanticGuess*
- **.PHONY** (`vibecrafted-app/mux-agent/Makefile::wizard-dry-run`): Target 'wizard-dry-run' is listed in a .PHONY directive; operator-invoked make target. (Role: public_entrypoint, Source: inferred_from_code) *SemanticGuess*
- **new** (`vibecrafted-app/mux-agent/src/ipc/context.rs::new`): Idiomatic Rust constructor convention; called via Type::new(...) across the ecosystem. (Role: library_helper, Source: embedded_default) *LoctreeDerived*
- **ClientKind** (`vibecrafted-app/mux-agent/src/ipc/mod.rs::ClientKind`): Re-exported via `pub use`; reached through downstream importers. (Role: public_entrypoint, Source: inferred_from_code) *SemanticGuess*
- **IpcEvent** (`vibecrafted-app/mux-agent/src/ipc/mod.rs::IpcEvent`): Re-exported via `pub use`; reached through downstream importers. (Role: public_entrypoint, Source: inferred_from_code) *SemanticGuess*
- **MuxControlCommand** (`vibecrafted-app/mux-agent/src/ipc/mod.rs::MuxControlCommand`): Re-exported via `pub use`; reached through downstream importers. (Role: public_entrypoint, Source: inferred_from_code) *SemanticGuess*
- **MuxControlContext** (`vibecrafted-app/mux-agent/src/ipc/mod.rs::MuxControlContext`): Re-exported via `pub use`; reached through downstream importers. (Role: public_entrypoint, Source: inferred_from_code) *SemanticGuess*
- **MuxControlResponse** (`vibecrafted-app/mux-agent/src/ipc/mod.rs::MuxControlResponse`): Re-exported via `pub use`; reached through downstream importers. (Role: public_entrypoint, Source: inferred_from_code) *SemanticGuess*
- **run_server** (`vibecrafted-app/mux-agent/src/ipc/mod.rs::run_server`): Re-exported via `pub use`; reached through downstream importers. (Role: public_entrypoint, Source: inferred_from_code) *SemanticGuess*
- **socket_path** (`vibecrafted-app/mux-agent/src/ipc/mod.rs::socket_path`): Re-exported via `pub use`; reached through downstream importers. (Role: public_entrypoint, Source: inferred_from_code) *SemanticGuess*
- **CliOptions** (`vibecrafted-app/mux-agent/src/lib.rs::CliOptions`): Re-exported via `pub use`; reached through downstream importers. (Role: public_entrypoint, Source: inferred_from_code) *SemanticGuess*
- **Config** (`vibecrafted-app/mux-agent/src/lib.rs::Config`): Re-exported via `pub use`; reached through downstream importers. (Role: public_entrypoint, Source: inferred_from_code) *SemanticGuess*
- **DEFAULT_STATUS_SOCKET** (`vibecrafted-app/mux-agent/src/lib.rs::DEFAULT_STATUS_SOCKET`): Re-exported via `pub use`; reached through downstream importers. (Role: public_entrypoint, Source: inferred_from_code) *SemanticGuess*
- **DaemonStatus** (`vibecrafted-app/mux-agent/src/lib.rs::DaemonStatus`): Re-exported via `pub use`; reached through downstream importers. (Role: public_entrypoint, Source: inferred_from_code) *SemanticGuess*
- **HeartbeatConfig** (`vibecrafted-app/mux-agent/src/lib.rs::HeartbeatConfig`): Re-exported via `pub use`; reached through downstream importers. (Role: public_entrypoint, Source: inferred_from_code) *SemanticGuess*
- **MAX_PENDING** (`vibecrafted-app/mux-agent/src/lib.rs::MAX_PENDING`): Re-exported via `pub use`; reached through downstream importers. (Role: public_entrypoint, Source: inferred_from_code) *SemanticGuess*
- **MAX_QUEUE** (`vibecrafted-app/mux-agent/src/lib.rs::MAX_QUEUE`): Re-exported via `pub use`; reached through downstream importers. (Role: public_entrypoint, Source: inferred_from_code) *SemanticGuess*
- **ManagedServer** (`vibecrafted-app/mux-agent/src/lib.rs::ManagedServer`): Re-exported via `pub use`; reached through downstream importers. (Role: public_entrypoint, Source: inferred_from_code) *SemanticGuess*
- **MultiServerStatus** (`vibecrafted-app/mux-agent/src/lib.rs::MultiServerStatus`): Re-exported via `pub use`; reached through downstream importers. (Role: public_entrypoint, Source: inferred_from_code) *SemanticGuess*
- **MuxState** (`vibecrafted-app/mux-agent/src/lib.rs::MuxState`): Re-exported via `pub use`; reached through downstream importers. (Role: public_entrypoint, Source: inferred_from_code) *SemanticGuess*
- **ResolvedParams** (`vibecrafted-app/mux-agent/src/lib.rs::ResolvedParams`): Re-exported via `pub use`; reached through downstream importers. (Role: public_entrypoint, Source: inferred_from_code) *SemanticGuess*
- **ServerCommand** (`vibecrafted-app/mux-agent/src/lib.rs::ServerCommand`): Re-exported via `pub use`; reached through downstream importers. (Role: public_entrypoint, Source: inferred_from_code) *SemanticGuess*
- **ServerConfig** (`vibecrafted-app/mux-agent/src/lib.rs::ServerConfig`): Re-exported via `pub use`; reached through downstream importers. (Role: public_entrypoint, Source: inferred_from_code) *SemanticGuess*
- **ServerRef** (`vibecrafted-app/mux-agent/src/lib.rs::ServerRef`): Re-exported via `pub use`; reached through downstream importers. (Role: public_entrypoint, Source: inferred_from_code) *SemanticGuess*
- **ServerStatus** (`vibecrafted-app/mux-agent/src/lib.rs::ServerStatus`): Re-exported via `pub use`; reached through downstream importers. (Role: public_entrypoint, Source: inferred_from_code) *SemanticGuess*
- **StatusLevel** (`vibecrafted-app/mux-agent/src/lib.rs::StatusLevel`): Re-exported via `pub use`; reached through downstream importers. (Role: public_entrypoint, Source: inferred_from_code) *SemanticGuess*
- **StatusSnapshot** (`vibecrafted-app/mux-agent/src/lib.rs::StatusSnapshot`): Re-exported via `pub use`; reached through downstream importers. (Role: public_entrypoint, Source: inferred_from_code) *SemanticGuess*
- **StatusState** (`vibecrafted-app/mux-agent/src/lib.rs::StatusState`): Re-exported via `pub use`; reached through downstream importers. (Role: public_entrypoint, Source: inferred_from_code) *SemanticGuess*
- **TuiMuxState** (`vibecrafted-app/mux-agent/src/lib.rs::TuiMuxState`): Re-exported via `pub use`; reached through downstream importers. (Role: public_entrypoint, Source: inferred_from_code) *SemanticGuess*
- **format_uptime** (`vibecrafted-app/mux-agent/src/lib.rs::format_uptime`): Re-exported via `pub use`; reached through downstream importers. (Role: public_entrypoint, Source: inferred_from_code) *SemanticGuess*
- **health_check** (`vibecrafted-app/mux-agent/src/lib.rs::health_check`): Re-exported via `pub use`; reached through downstream importers. (Role: public_entrypoint, Source: inferred_from_code) *SemanticGuess*
- **is_running** (`vibecrafted-app/mux-agent/src/lib.rs::is_running`): Defined inside inherent `impl MuxHandle` block; reached via method-call syntax. (Role: library_helper, Source: inferred_from_code) *SemanticGuess*
- **new** (`vibecrafted-app/mux-agent/src/lib.rs::new`): Idiomatic Rust constructor convention; called via Type::new(...) across the ecosystem. (Role: library_helper, Source: embedded_default) *LoctreeDerived*
- **print_status_table** (`vibecrafted-app/mux-agent/src/lib.rs::print_status_table`): Re-exported via `pub use`; reached through downstream importers. (Role: public_entrypoint, Source: inferred_from_code) *SemanticGuess*
- **query_status** (`vibecrafted-app/mux-agent/src/lib.rs::query_status`): Re-exported via `pub use`; reached through downstream importers. (Role: public_entrypoint, Source: inferred_from_code) *SemanticGuess*
- **resolve_params_multi** (`vibecrafted-app/mux-agent/src/lib.rs::resolve_params_multi`): Re-exported via `pub use`; reached through downstream importers. (Role: public_entrypoint, Source: inferred_from_code) *SemanticGuess*
- **run_multi_tui** (`vibecrafted-app/mux-agent/src/lib.rs::run_multi_tui`): Re-exported via `pub use`; reached through downstream importers. (Role: public_entrypoint, Source: inferred_from_code) *SemanticGuess*
- **run_mux** (`vibecrafted-app/mux-agent/src/lib.rs::run_mux`): Re-exported via `pub use`; reached through downstream importers. (Role: public_entrypoint, Source: inferred_from_code) *SemanticGuess*
- **run_proxy** (`vibecrafted-app/mux-agent/src/lib.rs::run_proxy`): Re-exported via `pub use`; reached through downstream importers. (Role: public_entrypoint, Source: inferred_from_code) *SemanticGuess*
- **run_status_listener** (`vibecrafted-app/mux-agent/src/lib.rs::run_status_listener`): Re-exported via `pub use`; reached through downstream importers. (Role: public_entrypoint, Source: inferred_from_code) *SemanticGuess*
- **service_name** (`vibecrafted-app/mux-agent/src/lib.rs::service_name`): Defined inside inherent `impl MuxConfig` block; reached via method-call syntax. (Role: library_helper, Source: inferred_from_code) *SemanticGuess*
- **shutdown** (`vibecrafted-app/mux-agent/src/lib.rs::shutdown`): Defined inside inherent `impl MuxHandle` block; reached via method-call syntax. (Role: library_helper, Source: inferred_from_code) *SemanticGuess*
- **wait** (`vibecrafted-app/mux-agent/src/lib.rs::wait`): Defined inside inherent `impl MuxHandle` block; reached via method-call syntax. (Role: library_helper, Source: inferred_from_code) *SemanticGuess*
- **with_args** (`vibecrafted-app/mux-agent/src/lib.rs::with_args`): Defined inside inherent `impl MuxConfig` block; reached via method-call syntax. (Role: library_helper, Source: inferred_from_code) *SemanticGuess*
- **with_env** (`vibecrafted-app/mux-agent/src/lib.rs::with_env`): Defined inside inherent `impl MuxConfig` block; reached via method-call syntax. (Role: library_helper, Source: inferred_from_code) *SemanticGuess*
- **with_env_var** (`vibecrafted-app/mux-agent/src/lib.rs::with_env_var`): Defined inside inherent `impl MuxConfig` block; reached via method-call syntax. (Role: library_helper, Source: inferred_from_code) *SemanticGuess*
- **with_heartbeat** (`vibecrafted-app/mux-agent/src/lib.rs::with_heartbeat`): Defined inside inherent `impl MuxConfig` block; reached via method-call syntax. (Role: library_helper, Source: inferred_from_code) *SemanticGuess*
- **with_heartbeat_enabled** (`vibecrafted-app/mux-agent/src/lib.rs::with_heartbeat_enabled`): Defined inside inherent `impl MuxConfig` block; reached via method-call syntax. (Role: library_helper, Source: inferred_from_code) *SemanticGuess*
- **with_heartbeat_max_failures** (`vibecrafted-app/mux-agent/src/lib.rs::with_heartbeat_max_failures`): Defined inside inherent `impl MuxConfig` block; reached via method-call syntax. (Role: library_helper, Source: inferred_from_code) *SemanticGuess*
- **with_lazy_start** (`vibecrafted-app/mux-agent/src/lib.rs::with_lazy_start`): Defined inside inherent `impl MuxConfig` block; reached via method-call syntax. (Role: library_helper, Source: inferred_from_code) *SemanticGuess*
- **with_log_level** (`vibecrafted-app/mux-agent/src/lib.rs::with_log_level`): Defined inside inherent `impl MuxConfig` block; reached via method-call syntax. (Role: library_helper, Source: inferred_from_code) *SemanticGuess*
- **with_max_clients** (`vibecrafted-app/mux-agent/src/lib.rs::with_max_clients`): Defined inside inherent `impl MuxConfig` block; reached via method-call syntax. (Role: library_helper, Source: inferred_from_code) *SemanticGuess*
- **with_max_request_bytes** (`vibecrafted-app/mux-agent/src/lib.rs::with_max_request_bytes`): Defined inside inherent `impl MuxConfig` block; reached via method-call syntax. (Role: library_helper, Source: inferred_from_code) *SemanticGuess*
- **with_max_restarts** (`vibecrafted-app/mux-agent/src/lib.rs::with_max_restarts`): Defined inside inherent `impl MuxConfig` block; reached via method-call syntax. (Role: library_helper, Source: inferred_from_code) *SemanticGuess*
- **with_request_timeout** (`vibecrafted-app/mux-agent/src/lib.rs::with_request_timeout`): Defined inside inherent `impl MuxConfig` block; reached via method-call syntax. (Role: library_helper, Source: inferred_from_code) *SemanticGuess*
- **with_restart_backoff** (`vibecrafted-app/mux-agent/src/lib.rs::with_restart_backoff`): Defined inside inherent `impl MuxConfig` block; reached via method-call syntax. (Role: library_helper, Source: inferred_from_code) *SemanticGuess*
- **with_service_name** (`vibecrafted-app/mux-agent/src/lib.rs::with_service_name`): Defined inside inherent `impl MuxConfig` block; reached via method-call syntax. (Role: library_helper, Source: inferred_from_code) *SemanticGuess*
- **with_status_file** (`vibecrafted-app/mux-agent/src/lib.rs::with_status_file`): Defined inside inherent `impl MuxConfig` block; reached via method-call syntax. (Role: library_helper, Source: inferred_from_code) *SemanticGuess*
- **with_tray** (`vibecrafted-app/mux-agent/src/lib.rs::with_tray`): Defined inside inherent `impl MuxConfig` block; reached via method-call syntax. (Role: library_helper, Source: inferred_from_code) *SemanticGuess*
- **add_server** (`vibecrafted-app/mux-agent/src/multi.rs::add_server`): Defined inside inherent `impl TuiMuxState` block; reached via method-call syntax. (Role: library_helper, Source: inferred_from_code) *SemanticGuess*
- **new** (`vibecrafted-app/mux-agent/src/multi.rs::new`): Idiomatic Rust constructor convention; called via Type::new(...) across the ecosystem. (Role: library_helper, Source: embedded_default) *LoctreeDerived*
- **new** (`vibecrafted-app/mux-agent/src/multi_tui.rs::new`): Idiomatic Rust constructor convention; called via Type::new(...) across the ecosystem. (Role: library_helper, Source: embedded_default) *LoctreeDerived*
- **quit** (`vibecrafted-app/mux-agent/src/multi_tui.rs::quit`): Defined inside inherent `impl MultiTuiApp` block; reached via method-call syntax. (Role: library_helper, Source: inferred_from_code) *SemanticGuess*
- **select_next** (`vibecrafted-app/mux-agent/src/multi_tui.rs::select_next`): Defined inside inherent `impl MultiTuiApp` block; reached via method-call syntax. (Role: library_helper, Source: inferred_from_code) *SemanticGuess*
- **select_previous** (`vibecrafted-app/mux-agent/src/multi_tui.rs::select_previous`): Defined inside inherent `impl MultiTuiApp` block; reached via method-call syntax. (Role: library_helper, Source: inferred_from_code) *SemanticGuess*
- **selected_server** (`vibecrafted-app/mux-agent/src/multi_tui.rs::selected_server`): Defined inside inherent `impl MultiTuiApp` block; reached via method-call syntax. (Role: library_helper, Source: inferred_from_code) *SemanticGuess*
- **should_quit** (`vibecrafted-app/mux-agent/src/multi_tui.rs::should_quit`): Defined inside inherent `impl MultiTuiApp` block; reached via method-call syntax. (Role: library_helper, Source: inferred_from_code) *SemanticGuess*
- **update_statuses** (`vibecrafted-app/mux-agent/src/multi_tui.rs::update_statuses`): Defined inside inherent `impl MultiTuiApp` block; reached via method-call syntax. (Role: library_helper, Source: inferred_from_code) *SemanticGuess*
- **disabled** (`vibecrafted-app/mux-agent/src/runtime/heartbeat.rs::disabled`): Defined inside inherent `impl HeartbeatConfig` block; reached via method-call syntax. (Role: library_helper, Source: inferred_from_code) *SemanticGuess*
- **new** (`vibecrafted-app/mux-agent/src/runtime/heartbeat.rs::new`): Idiomatic Rust constructor convention; called via Type::new(...) across the ecosystem. (Role: library_helper, Source: embedded_default) *LoctreeDerived*
- **DEFAULT_STATUS_SOCKET** (`vibecrafted-app/mux-agent/src/runtime/mod.rs::DEFAULT_STATUS_SOCKET`): Re-exported via `pub use`; reached through downstream importers. (Role: public_entrypoint, Source: inferred_from_code) *SemanticGuess*
- **DaemonStatus** (`vibecrafted-app/mux-agent/src/runtime/mod.rs::DaemonStatus`): Re-exported via `pub use`; reached through downstream importers. (Role: public_entrypoint, Source: inferred_from_code) *SemanticGuess*
- **HeartbeatConfig** (`vibecrafted-app/mux-agent/src/runtime/mod.rs::HeartbeatConfig`): Re-exported via `pub use`; reached through downstream importers. (Role: public_entrypoint, Source: inferred_from_code) *SemanticGuess*
- **HeartbeatEvent** (`vibecrafted-app/mux-agent/src/runtime/mod.rs::HeartbeatEvent`): Re-exported via `pub use`; reached through downstream importers. (Role: public_entrypoint, Source: inferred_from_code) *SemanticGuess*
- **HeartbeatInspectorContext** (`vibecrafted-app/mux-agent/src/runtime/mod.rs::HeartbeatInspectorContext`): Re-exported via `pub use`; reached through downstream importers. (Role: public_entrypoint, Source: inferred_from_code) *SemanticGuess*
- **MAX_PENDING** (`vibecrafted-app/mux-agent/src/runtime/mod.rs::MAX_PENDING`): Re-exported via `pub use`; reached through downstream importers. (Role: public_entrypoint, Source: inferred_from_code) *SemanticGuess*
- **MAX_QUEUE** (`vibecrafted-app/mux-agent/src/runtime/mod.rs::MAX_QUEUE`): Re-exported via `pub use`; reached through downstream importers. (Role: public_entrypoint, Source: inferred_from_code) *SemanticGuess*
- **ServerRef** (`vibecrafted-app/mux-agent/src/runtime/mod.rs::ServerRef`): Re-exported via `pub use`; reached through downstream importers. (Role: public_entrypoint, Source: inferred_from_code) *SemanticGuess*
- **StatusState** (`vibecrafted-app/mux-agent/src/runtime/mod.rs::StatusState`): Re-exported via `pub use`; reached through downstream importers. (Role: public_entrypoint, Source: inferred_from_code) *SemanticGuess*
- **is_heartbeat_response** (`vibecrafted-app/mux-agent/src/runtime/mod.rs::is_heartbeat_response`): Re-exported via `pub use`; reached through downstream importers. (Role: public_entrypoint, Source: inferred_from_code) *SemanticGuess*
- **print_status_table** (`vibecrafted-app/mux-agent/src/runtime/mod.rs::print_status_table`): Re-exported via `pub use`; reached through downstream importers. (Role: public_entrypoint, Source: inferred_from_code) *SemanticGuess*
- **query_status** (`vibecrafted-app/mux-agent/src/runtime/mod.rs::query_status`): Re-exported via `pub use`; reached through downstream importers. (Role: public_entrypoint, Source: inferred_from_code) *SemanticGuess*
- **run_proxy** (`vibecrafted-app/mux-agent/src/runtime/mod.rs::run_proxy`): Re-exported via `pub use`; reached through downstream importers. (Role: public_entrypoint, Source: inferred_from_code) *SemanticGuess*
- **run_status_listener** (`vibecrafted-app/mux-agent/src/runtime/mod.rs::run_status_listener`): Re-exported via `pub use`; reached through downstream importers. (Role: public_entrypoint, Source: inferred_from_code) *SemanticGuess*
- **spawn_heartbeat_inspector** (`vibecrafted-app/mux-agent/src/runtime/mod.rs::spawn_heartbeat_inspector`): Re-exported via `pub use`; reached through downstream importers. (Role: public_entrypoint, Source: inferred_from_code) *SemanticGuess*
- **spawn_status_writer** (`vibecrafted-app/mux-agent/src/runtime/mod.rs::spawn_status_writer`): Re-exported via `pub use`; reached through downstream importers. (Role: public_entrypoint, Source: inferred_from_code) *SemanticGuess*
- **collect_status** (`vibecrafted-app/mux-agent/src/runtime/status.rs::collect_status`): Defined inside inherent `impl StatusState` block; reached via method-call syntax. (Role: library_helper, Source: inferred_from_code) *SemanticGuess*
- **new** (`vibecrafted-app/mux-agent/src/runtime/status.rs::new`): Idiomatic Rust constructor convention; called via Type::new(...) across the ecosystem. (Role: library_helper, Source: embedded_default) *LoctreeDerived*
- **register_server** (`vibecrafted-app/mux-agent/src/runtime/status.rs::register_server`): Defined inside inherent `impl StatusState` block; reached via method-call syntax. (Role: library_helper, Source: inferred_from_code) *SemanticGuess*
- **as_label** (`vibecrafted-app/mux-agent/src/scan.rs::as_label`): Defined inside inherent `impl HostKind` block; reached via method-call syntax. (Role: library_helper, Source: inferred_from_code) *SemanticGuess*
- **display_name** (`vibecrafted-app/mux-agent/src/scan.rs::display_name`): Defined inside inherent `impl HostKind` block; reached via method-call syntax. (Role: library_helper, Source: inferred_from_code) *SemanticGuess*
- **into_host_service** (`vibecrafted-app/mux-agent/src/scan.rs::into_host_service`): Defined inside inherent `impl DiscoveredMcp` block; reached via method-call syntax. (Role: library_helper, Source: inferred_from_code) *SemanticGuess*
- **buffer_message** (`vibecrafted-app/mux-agent/src/state.rs::buffer_message`): Defined inside inherent `impl MuxState` block; reached via method-call syntax. (Role: library_helper, Source: inferred_from_code) *SemanticGuess*
- **complete_handshake** (`vibecrafted-app/mux-agent/src/state.rs::complete_handshake`): Defined inside inherent `impl MuxState` block; reached via method-call syntax. (Role: library_helper, Source: inferred_from_code) *SemanticGuess*
- **get_handshake_mut** (`vibecrafted-app/mux-agent/src/state.rs::get_handshake_mut`): Defined inside inherent `impl MuxState` block; reached via method-call syntax. (Role: library_helper, Source: inferred_from_code) *SemanticGuess*
- **is_handshake_complete** (`vibecrafted-app/mux-agent/src/state.rs::is_handshake_complete`): Defined inside inherent `impl MuxState` block; reached via method-call syntax. (Role: library_helper, Source: inferred_from_code) *SemanticGuess*
- **is_handshake_timed_out** (`vibecrafted-app/mux-agent/src/state.rs::is_handshake_timed_out`): Defined inside inherent `impl MuxState` block; reached via method-call syntax. (Role: library_helper, Source: inferred_from_code) *SemanticGuess*
- **mark_handshake_complete** (`vibecrafted-app/mux-agent/src/state.rs::mark_handshake_complete`): Defined inside inherent `impl MuxState` block; reached via method-call syntax. (Role: library_helper, Source: inferred_from_code) *SemanticGuess*
- **new** (`vibecrafted-app/mux-agent/src/state.rs::new`): Idiomatic Rust constructor convention; called via Type::new(...) across the ecosystem. (Role: library_helper, Source: embedded_default) *LoctreeDerived*
- **next_request_id** (`vibecrafted-app/mux-agent/src/state.rs::next_request_id`): Defined inside inherent `impl MuxState` block; reached via method-call syntax. (Role: library_helper, Source: inferred_from_code) *SemanticGuess*
- **register_client** (`vibecrafted-app/mux-agent/src/state.rs::register_client`): Defined inside inherent `impl MuxState` block; reached via method-call syntax. (Role: library_helper, Source: inferred_from_code) *SemanticGuess*
- **unregister_client** (`vibecrafted-app/mux-agent/src/state.rs::unregister_client`): Defined inside inherent `impl MuxState` block; reached via method-call syntax. (Role: library_helper, Source: inferred_from_code) *SemanticGuess*
- **short_label** (`vibecrafted-app/mux-agent/src/wizard/types.rs::short_label`): Defined inside inherent `impl ServiceSource` block; reached via method-call syntax. (Role: library_helper, Source: inferred_from_code) *SemanticGuess*
- **info** (`vibecrafted-app/mux-agent/tools/install.sh::info`): Conventional info-level logger. (Role: library_helper, Source: embedded_default) *LoctreeDerived*
- **warn** (`vibecrafted-app/mux-agent/tools/install.sh::warn`): Conventional warning logger. (Role: library_helper, Source: embedded_default) *LoctreeDerived*
- **.PHONY** (`vibecrafted-app/shell-agent/Makefile::.PHONY`): GNU Make directive marking targets that are not files; targets listed after .PHONY are public entrypoints. (Role: metadata, Source: embedded_default) *LoctreeDerived*
- **.PHONY** (`vibecrafted-app/shell-agent/Makefile::app`): Target 'app' is listed in a .PHONY directive; operator-invoked make target. (Role: public_entrypoint, Source: inferred_from_code) *SemanticGuess*
- **.PHONY** (`vibecrafted-app/shell-agent/Makefile::app-debug`): Target 'app-debug' is listed in a .PHONY directive; operator-invoked make target. (Role: public_entrypoint, Source: inferred_from_code) *SemanticGuess*
- **.PHONY** (`vibecrafted-app/shell-agent/Makefile::bindings`): Target 'bindings' is listed in a .PHONY directive; operator-invoked make target. (Role: public_entrypoint, Source: inferred_from_code) *SemanticGuess*
- **.PHONY** (`vibecrafted-app/shell-agent/Makefile::dmg`): Target 'dmg' is listed in a .PHONY directive; operator-invoked make target. (Role: public_entrypoint, Source: inferred_from_code) *SemanticGuess*
- **.PHONY** (`vibecrafted-app/shell-agent/Makefile::dmg-signed`): Target 'dmg-signed' is listed in a .PHONY directive; operator-invoked make target. (Role: public_entrypoint, Source: inferred_from_code) *SemanticGuess*
- **.PHONY** (`vibecrafted-app/shell-agent/Makefile::help`): Target 'help' is listed in a .PHONY directive; operator-invoked make target. (Role: public_entrypoint, Source: inferred_from_code) *SemanticGuess*
- **.PHONY** (`vibecrafted-app/shell-agent/Makefile::xcode`): Target 'xcode' is listed in a .PHONY directive; operator-invoked make target. (Role: public_entrypoint, Source: inferred_from_code) *SemanticGuess*
- **ClientKind** (`vibecrafted-app/tray-agent/src/ipc_client.rs::ClientKind`): Re-exported via `pub use`; reached through downstream importers. (Role: public_entrypoint, Source: inferred_from_code) *SemanticGuess*
- **IpcEvent** (`vibecrafted-app/tray-agent/src/ipc_client.rs::IpcEvent`): Re-exported via `pub use`; reached through downstream importers. (Role: public_entrypoint, Source: inferred_from_code) *SemanticGuess*
- **MuxControlCommand** (`vibecrafted-app/tray-agent/src/ipc_client.rs::MuxControlCommand`): Re-exported via `pub use`; reached through downstream importers. (Role: public_entrypoint, Source: inferred_from_code) *SemanticGuess*
- **MuxControlResponse** (`vibecrafted-app/tray-agent/src/ipc_client.rs::MuxControlResponse`): Re-exported via `pub use`; reached through downstream importers. (Role: public_entrypoint, Source: inferred_from_code) *SemanticGuess*
- **MenuIds** (`vibecrafted-app/tray-agent/src/lib.rs::MenuIds`): Re-exported via `pub use`; reached through downstream importers. (Role: public_entrypoint, Source: inferred_from_code) *SemanticGuess*
- **TrayMenuEvent** (`vibecrafted-app/tray-agent/src/lib.rs::TrayMenuEvent`): Re-exported via `pub use`; reached through downstream importers. (Role: public_entrypoint, Source: inferred_from_code) *SemanticGuess*
- **TrayStatus** (`vibecrafted-app/tray-agent/src/lib.rs::TrayStatus`): Re-exported via `pub use`; reached through downstream importers. (Role: public_entrypoint, Source: inferred_from_code) *SemanticGuess*
- **menu_event_receiver** (`vibecrafted-app/tray-agent/src/lib.rs::menu_event_receiver`): Re-exported via `pub use`; reached through downstream importers. (Role: public_entrypoint, Source: inferred_from_code) *SemanticGuess*
- **send_menu_event** (`vibecrafted-app/tray-agent/src/lib.rs::send_menu_event`): Re-exported via `pub use`; reached through downstream importers. (Role: public_entrypoint, Source: inferred_from_code) *SemanticGuess*
- **update_tray_status** (`vibecrafted-app/tray-agent/src/lib.rs::update_tray_status`): Re-exported via `pub use`; reached through downstream importers. (Role: public_entrypoint, Source: inferred_from_code) *SemanticGuess*
- **is_active** (`vibecrafted-app/tray-agent/src/types.rs::is_active`): Defined inside inherent `impl SpawnEntry` block; reached via method-call syntax. (Role: library_helper, Source: inferred_from_code) *SemanticGuess*
- **label** (`vibecrafted-app/tray-agent/src/types.rs::label`): Defined inside inherent `impl TrayStatus` block; reached via method-call syntax. (Role: library_helper, Source: inferred_from_code) *SemanticGuess*
- **menu_label** (`vibecrafted-app/tray-agent/src/types.rs::menu_label`): Defined inside inherent `impl TrayStatus` block; reached via method-call syntax. (Role: library_helper, Source: inferred_from_code) *SemanticGuess*
- **resolve_recent_run** (`vibecrafted-app/tray-agent/src/types.rs::resolve_recent_run`): Defined inside inherent `impl MenuIds` block; reached via method-call syntax. (Role: library_helper, Source: inferred_from_code) *SemanticGuess*
- **resolve_restart_service** (`vibecrafted-app/tray-agent/src/types.rs::resolve_restart_service`): Defined inside inherent `impl MenuIds` block; reached via method-call syntax. (Role: library_helper, Source: inferred_from_code) *SemanticGuess*
- **resolve_verify_client** (`vibecrafted-app/tray-agent/src/types.rs::resolve_verify_client`): Defined inside inherent `impl MenuIds` block; reached via method-call syntax. (Role: library_helper, Source: inferred_from_code) *SemanticGuess*
- **tooltip** (`vibecrafted-app/tray-agent/src/types.rs::tooltip`): Defined inside inherent `impl TrayStatus` block; reached via method-call syntax. (Role: library_helper, Source: inferred_from_code) *SemanticGuess*
- **active_run_count** (`vibecrafted-app/tui-agent/src/app.rs::active_run_count`): Defined inside inherent `impl App` block; reached via method-call syntax. (Role: library_helper, Source: inferred_from_code) *SemanticGuess*
- **active_tab** (`vibecrafted-app/tui-agent/src/app.rs::active_tab`): Defined inside inherent `impl App` block; reached via method-call syntax. (Role: library_helper, Source: inferred_from_code) *SemanticGuess*
- **adjust_dispatch_selection** (`vibecrafted-app/tui-agent/src/app.rs::adjust_dispatch_selection`): Defined inside inherent `impl App` block; reached via method-call syntax. (Role: library_helper, Source: inferred_from_code) *SemanticGuess*
- **append_status** (`vibecrafted-app/tui-agent/src/app.rs::append_status`): Defined inside inherent `impl App` block; reached via method-call syntax. (Role: library_helper, Source: inferred_from_code) *SemanticGuess*
- **archive_selected_run** (`vibecrafted-app/tui-agent/src/app.rs::archive_selected_run`): Defined inside inherent `impl App` block; reached via method-call syntax. (Role: library_helper, Source: inferred_from_code) *SemanticGuess*
- **artifact_lines** (`vibecrafted-app/tui-agent/src/app.rs::artifact_lines`): Defined inside inherent `impl App` block; reached via method-call syntax. (Role: library_helper, Source: inferred_from_code) *SemanticGuess*
- **clear_search** (`vibecrafted-app/tui-agent/src/app.rs::clear_search`): Defined inside inherent `impl App` block; reached via method-call syntax. (Role: library_helper, Source: inferred_from_code) *SemanticGuess*
- **clipboard_payload** (`vibecrafted-app/tui-agent/src/app.rs::clipboard_payload`): Defined inside inherent `impl App` block; reached via method-call syntax. (Role: library_helper, Source: inferred_from_code) *SemanticGuess*
- **copy_selected_run_to_clipboard** (`vibecrafted-app/tui-agent/src/app.rs::copy_selected_run_to_clipboard`): Defined inside inherent `impl App` block; reached via method-call syntax. (Role: library_helper, Source: inferred_from_code) *SemanticGuess*
- **cycle_agent** (`vibecrafted-app/tui-agent/src/app.rs::cycle_agent`): Defined inside inherent `impl App` block; reached via method-call syntax. (Role: library_helper, Source: inferred_from_code) *SemanticGuess*
- **cycle_runtime** (`vibecrafted-app/tui-agent/src/app.rs::cycle_runtime`): Defined inside inherent `impl App` block; reached via method-call syntax. (Role: library_helper, Source: inferred_from_code) *SemanticGuess*
- **deep_action_index_for_primary_mission_queue_item** (`vibecrafted-app/tui-agent/src/app.rs::deep_action_index_for_primary_mission_queue_item`): Defined inside inherent `impl App` block; reached via method-call syntax. (Role: library_helper, Source: inferred_from_code) *SemanticGuess*
- **deep_actions** (`vibecrafted-app/tui-agent/src/app.rs::deep_actions`): Defined inside inherent `impl App` block; reached via method-call syntax. (Role: library_helper, Source: inferred_from_code) *SemanticGuess*
- **deep_control_lines** (`vibecrafted-app/tui-agent/src/app.rs::deep_control_lines`): Defined inside inherent `impl App` block; reached via method-call syntax. (Role: library_helper, Source: inferred_from_code) *SemanticGuess*
- **detail_lines** (`vibecrafted-app/tui-agent/src/app.rs::detail_lines`): Defined inside inherent `impl App` block; reached via method-call syntax. (Role: library_helper, Source: inferred_from_code) *SemanticGuess*
- **dispatch_focus** (`vibecrafted-app/tui-agent/src/app.rs::dispatch_focus`): Defined inside inherent `impl App` block; reached via method-call syntax. (Role: library_helper, Source: inferred_from_code) *SemanticGuess*
- **error_lines** (`vibecrafted-app/tui-agent/src/app.rs::error_lines`): Defined inside inherent `impl App` block; reached via method-call syntax. (Role: library_helper, Source: inferred_from_code) *SemanticGuess*
- **event_lines** (`vibecrafted-app/tui-agent/src/app.rs::event_lines`): Defined inside inherent `impl App` block; reached via method-call syntax. (Role: library_helper, Source: inferred_from_code) *SemanticGuess*
- **finish_prompt_edit** (`vibecrafted-app/tui-agent/src/app.rs::finish_prompt_edit`): Defined inside inherent `impl App` block; reached via method-call syntax. (Role: library_helper, Source: inferred_from_code) *SemanticGuess*
- **from_index** (`vibecrafted-app/tui-agent/src/app.rs::from_index`): Defined inside inherent `impl AppTab` block; reached via method-call syntax. (Role: library_helper, Source: inferred_from_code) *SemanticGuess*
- **handle_ipc_event** (`vibecrafted-app/tui-agent/src/app.rs::handle_ipc_event`): Defined inside inherent `impl App` block; reached via method-call syntax. (Role: library_helper, Source: inferred_from_code) *SemanticGuess*
- **help_lines** (`vibecrafted-app/tui-agent/src/app.rs::help_lines`): Defined inside inherent `impl App` block; reached via method-call syntax. (Role: library_helper, Source: inferred_from_code) *SemanticGuess*
- **index** (`vibecrafted-app/tui-agent/src/app.rs::index`): Defined inside inherent `impl AppTab` block; reached via method-call syntax. (Role: library_helper, Source: inferred_from_code) *SemanticGuess*
- **label** (`vibecrafted-app/tui-agent/src/app.rs::label`): Defined inside inherent `impl AppTab` block; reached via method-call syntax. (Role: library_helper, Source: inferred_from_code) *SemanticGuess*
- **launch_command** (`vibecrafted-app/tui-agent/src/app.rs::launch_command`): Defined inside inherent `impl App` block; reached via method-call syntax. (Role: library_helper, Source: inferred_from_code) *SemanticGuess*
- **launch_env** (`vibecrafted-app/tui-agent/src/app.rs::launch_env`): Defined inside inherent `impl App` block; reached via method-call syntax. (Role: library_helper, Source: inferred_from_code) *SemanticGuess*
- **launch_request** (`vibecrafted-app/tui-agent/src/app.rs::launch_request`): Defined inside inherent `impl App` block; reached via method-call syntax. (Role: library_helper, Source: inferred_from_code) *SemanticGuess*
- **move_deep_selection** (`vibecrafted-app/tui-agent/src/app.rs::move_deep_selection`): Defined inside inherent `impl App` block; reached via method-call syntax. (Role: library_helper, Source: inferred_from_code) *SemanticGuess*
- **move_dispatch_selection** (`vibecrafted-app/tui-agent/src/app.rs::move_dispatch_selection`): Defined inside inherent `impl App` block; reached via method-call syntax. (Role: library_helper, Source: inferred_from_code) *SemanticGuess*
- **move_mission_focus** (`vibecrafted-app/tui-agent/src/app.rs::move_mission_focus`): Defined inside inherent `impl App` block; reached via method-call syntax. (Role: library_helper, Source: inferred_from_code) *SemanticGuess*
- **move_selection** (`vibecrafted-app/tui-agent/src/app.rs::move_selection`): Defined inside inherent `impl App` block; reached via method-call syntax. (Role: library_helper, Source: inferred_from_code) *SemanticGuess*
- **mux_status_lines** (`vibecrafted-app/tui-agent/src/app.rs::mux_status_lines`): Defined inside inherent `impl App` block; reached via method-call syntax. (Role: library_helper, Source: inferred_from_code) *SemanticGuess*
- **new** (`vibecrafted-app/tui-agent/src/app.rs::new`): Idiomatic Rust constructor convention; called via Type::new(...) across the ecosystem. (Role: library_helper, Source: embedded_default) *LoctreeDerived*
- **next** (`vibecrafted-app/tui-agent/src/app.rs::next`): Iterator trait method; reached implicitly through for-loops and iterator adapters. (Role: library_helper, Source: embedded_default) *LoctreeDerived*
- **next_tab** (`vibecrafted-app/tui-agent/src/app.rs::next_tab`): Defined inside inherent `impl App` block; reached via method-call syntax. (Role: library_helper, Source: inferred_from_code) *SemanticGuess*
- **open_artifact** (`vibecrafted-app/tui-agent/src/app.rs::open_artifact`): Defined inside inherent `impl App` block; reached via method-call syntax. (Role: library_helper, Source: inferred_from_code) *SemanticGuess*
- **open_polarize_intent** (`vibecrafted-app/tui-agent/src/app.rs::open_polarize_intent`): Defined inside inherent `impl App` block; reached via method-call syntax. (Role: library_helper, Source: inferred_from_code) *SemanticGuess*
- **polarize_status_lines** (`vibecrafted-app/tui-agent/src/app.rs::polarize_status_lines`): Defined inside inherent `impl App` block; reached via method-call syntax. (Role: library_helper, Source: inferred_from_code) *SemanticGuess*
- **preselect_controls_from_mission_queue** (`vibecrafted-app/tui-agent/src/app.rs::preselect_controls_from_mission_queue`): Defined inside inherent `impl App` block; reached via method-call syntax. (Role: library_helper, Source: inferred_from_code) *SemanticGuess*
- **previous_tab** (`vibecrafted-app/tui-agent/src/app.rs::previous_tab`): Defined inside inherent `impl App` block; reached via method-call syntax. (Role: library_helper, Source: inferred_from_code) *SemanticGuess*
- **prompt_edit_lines** (`vibecrafted-app/tui-agent/src/app.rs::prompt_edit_lines`): Defined inside inherent `impl App` block; reached via method-call syntax. (Role: library_helper, Source: inferred_from_code) *SemanticGuess*
- **prompt_lines** (`vibecrafted-app/tui-agent/src/app.rs::prompt_lines`): Defined inside inherent `impl App` block; reached via method-call syntax. (Role: library_helper, Source: inferred_from_code) *SemanticGuess*
- **push_launch_history** (`vibecrafted-app/tui-agent/src/app.rs::push_launch_history`): Defined inside inherent `impl App` block; reached via method-call syntax. (Role: library_helper, Source: inferred_from_code) *SemanticGuess*
- **refresh** (`vibecrafted-app/tui-agent/src/app.rs::refresh`): Defined inside inherent `impl App` block; reached via method-call syntax. (Role: library_helper, Source: inferred_from_code) *SemanticGuess*
- **refresh_mission_control** (`vibecrafted-app/tui-agent/src/app.rs::refresh_mission_control`): Defined inside inherent `impl App` block; reached via method-call syntax. (Role: library_helper, Source: inferred_from_code) *SemanticGuess*
- **refresh_mux** (`vibecrafted-app/tui-agent/src/app.rs::refresh_mux`): Defined inside inherent `impl App` block; reached via method-call syntax. (Role: library_helper, Source: inferred_from_code) *SemanticGuess*
- **refresh_polarize** (`vibecrafted-app/tui-agent/src/app.rs::refresh_polarize`): Defined inside inherent `impl App` block; reached via method-call syntax. (Role: library_helper, Source: inferred_from_code) *SemanticGuess*
- **selected_agent** (`vibecrafted-app/tui-agent/src/app.rs::selected_agent`): Defined inside inherent `impl App` block; reached via method-call syntax. (Role: library_helper, Source: inferred_from_code) *SemanticGuess*
- **selected_deep_action** (`vibecrafted-app/tui-agent/src/app.rs::selected_deep_action`): Defined inside inherent `impl App` block; reached via method-call syntax. (Role: library_helper, Source: inferred_from_code) *SemanticGuess*
- **selected_run** (`vibecrafted-app/tui-agent/src/app.rs::selected_run`): Defined inside inherent `impl App` block; reached via method-call syntax. (Role: library_helper, Source: inferred_from_code) *SemanticGuess*
- **set_active_tab** (`vibecrafted-app/tui-agent/src/app.rs::set_active_tab`): Defined inside inherent `impl App` block; reached via method-call syntax. (Role: library_helper, Source: inferred_from_code) *SemanticGuess*
- **set_launch_kind** (`vibecrafted-app/tui-agent/src/app.rs::set_launch_kind`): Defined inside inherent `impl App` block; reached via method-call syntax. (Role: library_helper, Source: inferred_from_code) *SemanticGuess*
- **set_search_query** (`vibecrafted-app/tui-agent/src/app.rs::set_search_query`): Defined inside inherent `impl App` block; reached via method-call syntax. (Role: library_helper, Source: inferred_from_code) *SemanticGuess*
- **shift_agent** (`vibecrafted-app/tui-agent/src/app.rs::shift_agent`): Defined inside inherent `impl App` block; reached via method-call syntax. (Role: library_helper, Source: inferred_from_code) *SemanticGuess*
- **shift_launch_kind** (`vibecrafted-app/tui-agent/src/app.rs::shift_launch_kind`): Defined inside inherent `impl App` block; reached via method-call syntax. (Role: library_helper, Source: inferred_from_code) *SemanticGuess*
- **shift_runtime** (`vibecrafted-app/tui-agent/src/app.rs::shift_runtime`): Defined inside inherent `impl App` block; reached via method-call syntax. (Role: library_helper, Source: inferred_from_code) *SemanticGuess*
- **show_error** (`vibecrafted-app/tui-agent/src/app.rs::show_error`): Defined inside inherent `impl App` block; reached via method-call syntax. (Role: library_helper, Source: inferred_from_code) *SemanticGuess*
- **status_summary** (`vibecrafted-app/tui-agent/src/app.rs::status_summary`): Defined inside inherent `impl App` block; reached via method-call syntax. (Role: library_helper, Source: inferred_from_code) *SemanticGuess*
- **sync_selection** (`vibecrafted-app/tui-agent/src/app.rs::sync_selection`): Defined inside inherent `impl App` block; reached via method-call syntax. (Role: library_helper, Source: inferred_from_code) *SemanticGuess*
- **tab_labels** (`vibecrafted-app/tui-agent/src/app.rs::tab_labels`): Defined inside inherent `impl App` block; reached via method-call syntax. (Role: library_helper, Source: inferred_from_code) *SemanticGuess*
- **title** (`vibecrafted-app/tui-agent/src/app.rs::title`): Defined inside inherent `impl QueueScope` block; reached via method-call syntax. (Role: library_helper, Source: inferred_from_code) *SemanticGuess*
- **toggle_filter** (`vibecrafted-app/tui-agent/src/app.rs::toggle_filter`): Defined inside inherent `impl App` block; reached via method-call syntax. (Role: library_helper, Source: inferred_from_code) *SemanticGuess*
- **command_line** (`vibecrafted-app/tui-agent/src/launch.rs::command_line`): Defined inside inherent `impl LaunchCommand` block; reached via method-call syntax. (Role: library_helper, Source: inferred_from_code) *SemanticGuess*
- **cycle** (`vibecrafted-app/tui-agent/src/launch.rs::cycle`): Defined inside inherent `impl LaunchRuntime` block; reached via method-call syntax. (Role: library_helper, Source: inferred_from_code) *SemanticGuess*
- **human_description** (`vibecrafted-app/tui-agent/src/launch.rs::human_description`): Defined inside inherent `impl LaunchKind` block; reached via method-call syntax. (Role: library_helper, Source: inferred_from_code) *SemanticGuess*
- **human_title** (`vibecrafted-app/tui-agent/src/launch.rs::human_title`): Defined inside inherent `impl LaunchKind` block; reached via method-call syntax. (Role: library_helper, Source: inferred_from_code) *SemanticGuess*
- **is_session_visible** (`vibecrafted-app/tui-agent/src/launch.rs::is_session_visible`): Defined inside inherent `impl LaunchReadinessProbe` block; reached via method-call syntax. (Role: library_helper, Source: inferred_from_code) *SemanticGuess*
- **label** (`vibecrafted-app/tui-agent/src/launch.rs::label`): Defined inside inherent `impl LaunchKind` block; reached via method-call syntax. (Role: library_helper, Source: inferred_from_code) *SemanticGuess*
- **readiness_probe** (`vibecrafted-app/tui-agent/src/launch.rs::readiness_probe`): Defined inside inherent `impl LaunchCommand` block; reached via method-call syntax. (Role: library_helper, Source: inferred_from_code) *SemanticGuess*
- **spawn** (`vibecrafted-app/tui-agent/src/launch.rs::spawn`): Defined inside inherent `impl LaunchCommand` block; reached via method-call syntax. (Role: library_helper, Source: inferred_from_code) *SemanticGuess*
- **spawn_detached** (`vibecrafted-app/tui-agent/src/launch.rs::spawn_detached`): Defined inside inherent `impl LaunchCommand` block; reached via method-call syntax. (Role: library_helper, Source: inferred_from_code) *SemanticGuess*
- **spawn_interactive_with_stderr** (`vibecrafted-app/tui-agent/src/launch.rs::spawn_interactive_with_stderr`): Defined inside inherent `impl LaunchCommand` block; reached via method-call syntax. (Role: library_helper, Source: inferred_from_code) *SemanticGuess*
- **ActionPriority** (`vibecrafted-app/tui-agent/src/lib.rs::ActionPriority`): Re-exported via `pub use`; reached through downstream importers. (Role: public_entrypoint, Source: inferred_from_code) *SemanticGuess*
- **ActionQueueItem** (`vibecrafted-app/tui-agent/src/lib.rs::ActionQueueItem`): Re-exported via `pub use`; reached through downstream importers. (Role: public_entrypoint, Source: inferred_from_code) *SemanticGuess*
- **ActionQueueKind** (`vibecrafted-app/tui-agent/src/lib.rs::ActionQueueKind`): Re-exported via `pub use`; reached through downstream importers. (Role: public_entrypoint, Source: inferred_from_code) *SemanticGuess*
- **ActiveDispatch** (`vibecrafted-app/tui-agent/src/lib.rs::ActiveDispatch`): Re-exported via `pub use`; reached through downstream importers. (Role: public_entrypoint, Source: inferred_from_code) *SemanticGuess*
- **AgentStatsRow** (`vibecrafted-app/tui-agent/src/lib.rs::AgentStatsRow`): Re-exported via `pub use`; reached through downstream importers. (Role: public_entrypoint, Source: inferred_from_code) *SemanticGuess*
- **App** (`vibecrafted-app/tui-agent/src/lib.rs::App`): Re-exported via `pub use`; reached through downstream importers. (Role: public_entrypoint, Source: inferred_from_code) *SemanticGuess*
- **AppConfig** (`vibecrafted-app/tui-agent/src/lib.rs::AppConfig`): Re-exported via `pub use`; reached through downstream importers. (Role: public_entrypoint, Source: inferred_from_code) *SemanticGuess*
- **AppTab** (`vibecrafted-app/tui-agent/src/lib.rs::AppTab`): Re-exported via `pub use`; reached through downstream importers. (Role: public_entrypoint, Source: inferred_from_code) *SemanticGuess*
- **CliOptions** (`vibecrafted-app/tui-agent/src/lib.rs::CliOptions`): Re-exported via `pub use`; reached through downstream importers. (Role: public_entrypoint, Source: inferred_from_code) *SemanticGuess*
- **DataQuality** (`vibecrafted-app/tui-agent/src/lib.rs::DataQuality`): Re-exported via `pub use`; reached through downstream importers. (Role: public_entrypoint, Source: inferred_from_code) *SemanticGuess*
- **DeepAction** (`vibecrafted-app/tui-agent/src/lib.rs::DeepAction`): Re-exported via `pub use`; reached through downstream importers. (Role: public_entrypoint, Source: inferred_from_code) *SemanticGuess*
- **DispatchFocus** (`vibecrafted-app/tui-agent/src/lib.rs::DispatchFocus`): Re-exported via `pub use`; reached through downstream importers. (Role: public_entrypoint, Source: inferred_from_code) *SemanticGuess*
- **FailureEntry** (`vibecrafted-app/tui-agent/src/lib.rs::FailureEntry`): Re-exported via `pub use`; reached through downstream importers. (Role: public_entrypoint, Source: inferred_from_code) *SemanticGuess*
- **FleetHealthSignal** (`vibecrafted-app/tui-agent/src/lib.rs::FleetHealthSignal`): Re-exported via `pub use`; reached through downstream importers. (Role: public_entrypoint, Source: inferred_from_code) *SemanticGuess*
- **FleetHealthStatus** (`vibecrafted-app/tui-agent/src/lib.rs::FleetHealthStatus`): Re-exported via `pub use`; reached through downstream importers. (Role: public_entrypoint, Source: inferred_from_code) *SemanticGuess*
- **LaunchCommand** (`vibecrafted-app/tui-agent/src/lib.rs::LaunchCommand`): Re-exported via `pub use`; reached through downstream importers. (Role: public_entrypoint, Source: inferred_from_code) *SemanticGuess*
- **LaunchFocus** (`vibecrafted-app/tui-agent/src/lib.rs::LaunchFocus`): Re-exported via `pub use`; reached through downstream importers. (Role: public_entrypoint, Source: inferred_from_code) *SemanticGuess*
- **LaunchKind** (`vibecrafted-app/tui-agent/src/lib.rs::LaunchKind`): Re-exported via `pub use`; reached through downstream importers. (Role: public_entrypoint, Source: inferred_from_code) *SemanticGuess*
- **MissionControlState** (`vibecrafted-app/tui-agent/src/lib.rs::MissionControlState`): Re-exported via `pub use`; reached through downstream importers. (Role: public_entrypoint, Source: inferred_from_code) *SemanticGuess*
- **PolarizeBand** (`vibecrafted-app/tui-agent/src/lib.rs::PolarizeBand`): Re-exported via `pub use`; reached through downstream importers. (Role: public_entrypoint, Source: inferred_from_code) *SemanticGuess*
- **PolarizeIntent** (`vibecrafted-app/tui-agent/src/lib.rs::PolarizeIntent`): Re-exported via `pub use`; reached through downstream importers. (Role: public_entrypoint, Source: inferred_from_code) *SemanticGuess*
- **QueueScope** (`vibecrafted-app/tui-agent/src/lib.rs::QueueScope`): Re-exported via `pub use`; reached through downstream importers. (Role: public_entrypoint, Source: inferred_from_code) *SemanticGuess*
- **SkillAgent** (`vibecrafted-app/tui-agent/src/lib.rs::SkillAgent`): Re-exported via `pub use`; reached through downstream importers. (Role: public_entrypoint, Source: inferred_from_code) *SemanticGuess*
- **SkillEntry** (`vibecrafted-app/tui-agent/src/lib.rs::SkillEntry`): Re-exported via `pub use`; reached through downstream importers. (Role: public_entrypoint, Source: inferred_from_code) *SemanticGuess*
- **SkillPayload** (`vibecrafted-app/tui-agent/src/lib.rs::SkillPayload`): Re-exported via `pub use`; reached through downstream importers. (Role: public_entrypoint, Source: inferred_from_code) *SemanticGuess*
- **SkillPayloadKind** (`vibecrafted-app/tui-agent/src/lib.rs::SkillPayloadKind`): Re-exported via `pub use`; reached through downstream importers. (Role: public_entrypoint, Source: inferred_from_code) *SemanticGuess*
- **SkillStatsRow** (`vibecrafted-app/tui-agent/src/lib.rs::SkillStatsRow`): Re-exported via `pub use`; reached through downstream importers. (Role: public_entrypoint, Source: inferred_from_code) *SemanticGuess*
- **WaveSegment** (`vibecrafted-app/tui-agent/src/lib.rs::WaveSegment`): Re-exported via `pub use`; reached through downstream importers. (Role: public_entrypoint, Source: inferred_from_code) *SemanticGuess*
- **WaveState** (`vibecrafted-app/tui-agent/src/lib.rs::WaveState`): Re-exported via `pub use`; reached through downstream importers. (Role: public_entrypoint, Source: inferred_from_code) *SemanticGuess*
- **build_config** (`vibecrafted-app/tui-agent/src/lib.rs::build_config`): Re-exported via `pub use`; reached through downstream importers. (Role: public_entrypoint, Source: inferred_from_code) *SemanticGuess*
- **default_artifact_root** (`vibecrafted-app/tui-agent/src/lib.rs::default_artifact_root`): Re-exported via `pub use`; reached through downstream importers. (Role: public_entrypoint, Source: inferred_from_code) *SemanticGuess*
- **detail_lines** (`vibecrafted-app/tui-agent/src/lib.rs::detail_lines`): Defined inside inherent `impl LaunchRunError` block; reached via method-call syntax. (Role: library_helper, Source: inferred_from_code) *SemanticGuess*
- **parse_args** (`vibecrafted-app/tui-agent/src/lib.rs::parse_args`): Re-exported via `pub use`; reached through downstream importers. (Role: public_entrypoint, Source: inferred_from_code) *SemanticGuess*
- **build** (`vibecrafted-app/tui-agent/src/mission_control.rs::build`): Builder pattern terminal method; conventionally consumes Self into the built type. (Role: library_helper, Source: embedded_default) *LoctreeDerived*
- **build_at** (`vibecrafted-app/tui-agent/src/mission_control.rs::build_at`): Defined inside inherent `impl MissionControlState` block; reached via method-call syntax. (Role: library_helper, Source: inferred_from_code) *SemanticGuess*
- **build_at_for_root** (`vibecrafted-app/tui-agent/src/mission_control.rs::build_at_for_root`): Defined inside inherent `impl MissionControlState` block; reached via method-call syntax. (Role: library_helper, Source: inferred_from_code) *SemanticGuess*
- **build_at_with_intents** (`vibecrafted-app/tui-agent/src/mission_control.rs::build_at_with_intents`): Defined inside inherent `impl MissionControlState` block; reached via method-call syntax. (Role: library_helper, Source: inferred_from_code) *SemanticGuess*
- **build_with_intents** (`vibecrafted-app/tui-agent/src/mission_control.rs::build_with_intents`): Defined inside inherent `impl MissionControlState` block; reached via method-call syntax. (Role: library_helper, Source: inferred_from_code) *SemanticGuess*
- **glyph** (`vibecrafted-app/tui-agent/src/mission_control.rs::glyph`): Defined inside inherent `impl WaveState` block; reached via method-call syntax. (Role: library_helper, Source: inferred_from_code) *SemanticGuess*
- **is_empty** (`vibecrafted-app/tui-agent/src/mission_control.rs::is_empty`): Defined inside inherent `impl MissionControlState` block; reached via method-call syntax. (Role: library_helper, Source: inferred_from_code) *SemanticGuess*
- **label** (`vibecrafted-app/tui-agent/src/mission_control.rs::label`): Defined inside inherent `impl WaveState` block; reached via method-call syntax. (Role: library_helper, Source: inferred_from_code) *SemanticGuess*
- **marker** (`vibecrafted-app/tui-agent/src/mission_control.rs::marker`): Defined inside inherent `impl FleetHealthStatus` block; reached via method-call syntax. (Role: library_helper, Source: inferred_from_code) *SemanticGuess*
- **total_entries** (`vibecrafted-app/tui-agent/src/mission_control.rs::total_entries`): Defined inside inherent `impl MissionControlState` block; reached via method-call syntax. (Role: library_helper, Source: inferred_from_code) *SemanticGuess*
- **failure_reason** (`vibecrafted-app/tui-agent/src/mux.rs::failure_reason`): Defined inside inherent `impl MuxServerStatus` block; reached via method-call syntax. (Role: library_helper, Source: inferred_from_code) *SemanticGuess*
- **from_json** (`vibecrafted-app/tui-agent/src/mux.rs::from_json`): Defined inside inherent `impl MuxStatusSnapshot` block; reached via method-call syntax. (Role: library_helper, Source: inferred_from_code) *SemanticGuess*
- **from_path_and_result** (`vibecrafted-app/tui-agent/src/mux.rs::from_path_and_result`): Defined inside inherent `impl MuxSummary` block; reached via method-call syntax. (Role: library_helper, Source: inferred_from_code) *SemanticGuess*
- **is_healthy** (`vibecrafted-app/tui-agent/src/mux.rs::is_healthy`): Defined inside inherent `impl MuxServerStatus` block; reached via method-call syntax. (Role: library_helper, Source: inferred_from_code) *SemanticGuess*
- **label** (`vibecrafted-app/tui-agent/src/mux.rs::label`): Defined inside inherent `impl MuxServerStatus` block; reached via method-call syntax. (Role: library_helper, Source: inferred_from_code) *SemanticGuess*
- **read** (`vibecrafted-app/tui-agent/src/mux.rs::read`): Defined inside inherent `impl MuxStatusSnapshot` block; reached via method-call syntax. (Role: library_helper, Source: inferred_from_code) *SemanticGuess*
- **start** (`vibecrafted-app/tui-agent/src/mux.rs::start`): Defined inside inherent `impl MuxSubscriber` block; reached via method-call syntax. (Role: library_helper, Source: inferred_from_code) *SemanticGuess*
- **summary_line** (`vibecrafted-app/tui-agent/src/mux.rs::summary_line`): Defined inside inherent `impl MuxStatusSnapshot` block; reached via method-call syntax. (Role: library_helper, Source: inferred_from_code) *SemanticGuess*
- **from_score** (`vibecrafted-app/tui-agent/src/polarize.rs::from_score`): Defined inside inherent `impl PolarizeBand` block; reached via method-call syntax. (Role: library_helper, Source: inferred_from_code) *SemanticGuess*
- **label** (`vibecrafted-app/tui-agent/src/polarize.rs::label`): Defined inside inherent `impl PolarizeBand` block; reached via method-call syntax. (Role: library_helper, Source: inferred_from_code) *SemanticGuess*
- **recommended_action** (`vibecrafted-app/tui-agent/src/polarize.rs::recommended_action`): Defined inside inherent `impl PolarizeBand` block; reached via method-call syntax. (Role: library_helper, Source: inferred_from_code) *SemanticGuess*
- **summary_line** (`vibecrafted-app/tui-agent/src/polarize.rs::summary_line`): Defined inside inherent `impl PolarizeIntent` block; reached via method-call syntax. (Role: library_helper, Source: inferred_from_code) *SemanticGuess*
- **command_token** (`vibecrafted-app/tui-agent/src/skills_catalog.rs::command_token`): Defined inside inherent `impl SkillEntry` block; reached via method-call syntax. (Role: library_helper, Source: inferred_from_code) *SemanticGuess*
- **emphasized** (`vibecrafted-app/tui-agent/src/skills_catalog.rs::emphasized`): Defined inside inherent `impl SkillEntry` block; reached via method-call syntax. (Role: library_helper, Source: inferred_from_code) *SemanticGuess*
- **from_cli_token** (`vibecrafted-app/tui-agent/src/skills_catalog.rs::from_cli_token`): Defined inside inherent `impl SkillAgent` block; reached via method-call syntax. (Role: library_helper, Source: inferred_from_code) *SemanticGuess*
- **label** (`vibecrafted-app/tui-agent/src/skills_catalog.rs::label`): Defined inside inherent `impl SkillAgent` block; reached via method-call syntax. (Role: library_helper, Source: inferred_from_code) *SemanticGuess*
- **resolved_cli_token** (`vibecrafted-app/tui-agent/src/skills_catalog.rs::resolved_cli_token`): Defined inside inherent `impl SkillAgent` block; reached via method-call syntax. (Role: library_helper, Source: inferred_from_code) *SemanticGuess*
- **display_state** (`vibecrafted-app/tui-agent/src/state.rs::display_state`): Defined inside inherent `impl RunSnapshot` block; reached via method-call syntax. (Role: library_helper, Source: inferred_from_code) *SemanticGuess*
- **empty** (`vibecrafted-app/tui-agent/src/state.rs::empty`): Defined inside inherent `impl ControlPlaneState` block; reached via method-call syntax. (Role: library_helper, Source: inferred_from_code) *SemanticGuess*
- **label** (`vibecrafted-app/tui-agent/src/state.rs::label`): Defined inside inherent `impl RunKind` block; reached via method-call syntax. (Role: library_helper, Source: inferred_from_code) *SemanticGuess*
- **load** (`vibecrafted-app/tui-agent/src/state.rs::load`): Defined inside inherent `impl ControlPlaneState` block; reached via method-call syntax. (Role: library_helper, Source: inferred_from_code) *SemanticGuess*
- **sort_rank** (`vibecrafted-app/tui-agent/src/state.rs::sort_rank`): Defined inside inherent `impl RunKind` block; reached via method-call syntax. (Role: library_helper, Source: inferred_from_code) *SemanticGuess*

### Dispatch Edges

- `vibecrafted-app/Makefile`:6 -> `cargo` (`unknown`) *LoctreeDerived*
- `vibecrafted-app/Makefile`:50 -> `printf` (`unknown`) *LoctreeDerived*
- `vibecrafted-app/mux-agent/Makefile`:55 -> `cargo` (`unknown`) *LoctreeDerived*
- `vibecrafted-app/mux-agent/Makefile`:106 -> `mkdir` (`unknown`) *LoctreeDerived*
- `vibecrafted-app/mux-agent/Makefile`:22 -> `printf` (`unknown`) *LoctreeDerived*
- `vibecrafted-app/mux-agent/Makefile`:109 -> `rm` (`unknown`) *LoctreeDerived*
- `vibecrafted-app/mux-agent/Makefile`:4 -> `wizard` (`unknown`) *LoctreeDerived*
- `vibecrafted-app/mux-agent/tools/install.sh`:78 -> `warn` (`unknown`) *LoctreeDerived*
- `vibecrafted-app/shell-agent/Makefile`:30 -> `DerivedData` (`unknown`) *LoctreeDerived*
- `vibecrafted-app/shell-agent/Makefile`:44 -> `ID` (`unknown`) *LoctreeDerived*
- `vibecrafted-app/shell-agent/Makefile`:41 -> `build-dmg.sh` (`unknown`) *LoctreeDerived*
- `vibecrafted-app/shell-agent/Makefile`:15 -> `cargo` (`unknown`) *LoctreeDerived*
- `vibecrafted-app/shell-agent/Makefile`:23 -> `cd` (`unknown`) *LoctreeDerived*
- `vibecrafted-app/shell-agent/Makefile`:49 -> `chmod` (`unknown`) *LoctreeDerived*
- `vibecrafted-app/shell-agent/Makefile`:37 -> `codesign` (`unknown`) *LoctreeDerived*
- `vibecrafted-app/shell-agent/Makefile`:30 -> `cp` (`unknown`) *LoctreeDerived*
- `vibecrafted-app/shell-agent/Makefile`:14 -> `echo` (`unknown`) *LoctreeDerived*
- `vibecrafted-app/shell-agent/Makefile`:30 -> `exit` (`unknown`) *LoctreeDerived*
- `vibecrafted-app/shell-agent/Makefile`:16 -> `fix-dylib-install-names.sh` (`unknown`) *LoctreeDerived*
- `vibecrafted-app/shell-agent/Makefile`:30 -> `head` (`unknown`) *LoctreeDerived*
- `vibecrafted-app/shell-agent/Makefile`:19 -> `normalize-bindings.sh` (`unknown`) *LoctreeDerived*
- `vibecrafted-app/shell-agent/Makefile`:60 -> `printf` (`unknown`) *LoctreeDerived*
- `vibecrafted-app/shell-agent/Makefile`:28 -> `rm` (`unknown`) *LoctreeDerived*
- `vibecrafted-app/shell-agent/Makefile`:29 -> `set` (`unknown`) *LoctreeDerived*
- `vibecrafted-app/shell-agent/Makefile`:29 -> `tail` (`unknown`) *LoctreeDerived*
- `vibecrafted-app/shell-agent/Makefile`:29 -> `xcodebuild` (`unknown`) *LoctreeDerived*
- `vibecrafted-app/shell-agent/Makefile`:23 -> `xcodegen` (`unknown`) *LoctreeDerived*

### Reachability

- `vibecrafted-app/Makefile::app`: Reached (phony_make_target) *LoctreeDerived*
- `vibecrafted-app/Makefile::app-debug`: Reached (phony_make_target) *LoctreeDerived*
- `vibecrafted-app/Makefile::bindings`: Reached (phony_make_target) *LoctreeDerived*
- `vibecrafted-app/Makefile::check`: Reached (phony_make_target) *LoctreeDerived*
- `vibecrafted-app/Makefile::clean`: Reached (phony_make_target) *LoctreeDerived*
- `vibecrafted-app/Makefile::dmg`: Reached (phony_make_target) *LoctreeDerived*
- `vibecrafted-app/Makefile::dmg-signed`: Reached (phony_make_target) *LoctreeDerived*
- `vibecrafted-app/Makefile::fmt`: Reached (phony_make_target) *LoctreeDerived*
- `vibecrafted-app/Makefile::fmt-check`: Reached (phony_make_target) *LoctreeDerived*
- `vibecrafted-app/Makefile::gates`: Reached (phony_make_target) *LoctreeDerived*
- `vibecrafted-app/Makefile::help`: Reached (phony_make_target) *LoctreeDerived*
- `vibecrafted-app/Makefile::lint`: Reached (phony_make_target) *LoctreeDerived*
- `vibecrafted-app/Makefile::test`: Reached (phony_make_target) *LoctreeDerived*
- `vibecrafted-app/Makefile::workspace-check`: Reached (phony_make_target) *LoctreeDerived*
- `vibecrafted-app/Makefile::xcode`: Reached (phony_make_target) *LoctreeDerived*
- `vibecrafted-app/mux-agent/Makefile::build`: Reached (phony_make_target) *LoctreeDerived*
- `vibecrafted-app/mux-agent/Makefile::check`: Reached (phony_make_target) *LoctreeDerived*
- `vibecrafted-app/mux-agent/Makefile::clean-runtime`: Reached (phony_make_target) *LoctreeDerived*
- `vibecrafted-app/mux-agent/Makefile::clippy`: Reached (phony_make_target) *LoctreeDerived*
- `vibecrafted-app/mux-agent/Makefile::daemon-status`: Reached (phony_make_target) *LoctreeDerived*
- `vibecrafted-app/mux-agent/Makefile::dashboard`: Reached (phony_make_target) *LoctreeDerived*
- `vibecrafted-app/mux-agent/Makefile::fmt`: Reached (phony_make_target) *LoctreeDerived*
- `vibecrafted-app/mux-agent/Makefile::fmt-check`: Reached (phony_make_target) *LoctreeDerived*
- `vibecrafted-app/mux-agent/Makefile::gates`: Reached (phony_make_target) *LoctreeDerived*
- `vibecrafted-app/mux-agent/Makefile::health`: Reached (phony_make_target) *LoctreeDerived*
- `vibecrafted-app/mux-agent/Makefile::help`: Reached (phony_make_target) *LoctreeDerived*
- `vibecrafted-app/mux-agent/Makefile::proxy`: Reached (phony_make_target) *LoctreeDerived*
- `vibecrafted-app/mux-agent/Makefile::release`: Reached (phony_make_target) *LoctreeDerived*
- `vibecrafted-app/mux-agent/Makefile::run`: Reached (phony_make_target) *LoctreeDerived*
- `vibecrafted-app/mux-agent/Makefile::run-tray`: Reached (phony_make_target) *LoctreeDerived*
- `vibecrafted-app/mux-agent/Makefile::status-file-init`: Reached (phony_make_target) *LoctreeDerived*
- `vibecrafted-app/mux-agent/Makefile::test`: Reached (phony_make_target) *LoctreeDerived*
- `vibecrafted-app/mux-agent/Makefile::test-full`: Reached (phony_make_target) *LoctreeDerived*
- `vibecrafted-app/mux-agent/Makefile::wizard`: Reached (phony_make_target) *LoctreeDerived*
- `vibecrafted-app/mux-agent/Makefile::wizard-dry-run`: Reached (phony_make_target) *LoctreeDerived*
- `vibecrafted-app/mux-agent/src/ipc/context.rs::new`: Reached (idiom_runtime_role:library_helper) *SemanticGuess*
- `vibecrafted-app/mux-agent/src/ipc/mod.rs::ClientKind`: Reached (idiom_runtime_role:public_entrypoint) *SemanticGuess*
- `vibecrafted-app/mux-agent/src/ipc/mod.rs::IpcEvent`: Reached (idiom_runtime_role:public_entrypoint) *SemanticGuess*
- `vibecrafted-app/mux-agent/src/ipc/mod.rs::MuxControlCommand`: Reached (idiom_runtime_role:public_entrypoint) *SemanticGuess*
- `vibecrafted-app/mux-agent/src/ipc/mod.rs::MuxControlContext`: Reached (idiom_runtime_role:public_entrypoint) *SemanticGuess*
- `vibecrafted-app/mux-agent/src/ipc/mod.rs::MuxControlResponse`: Reached (idiom_runtime_role:public_entrypoint) *SemanticGuess*
- `vibecrafted-app/mux-agent/src/ipc/mod.rs::run_server`: Reached (idiom_runtime_role:public_entrypoint) *SemanticGuess*
- `vibecrafted-app/mux-agent/src/ipc/mod.rs::socket_path`: Reached (idiom_runtime_role:public_entrypoint) *SemanticGuess*
- `vibecrafted-app/mux-agent/src/lib.rs::CliOptions`: Reached (idiom_runtime_role:public_entrypoint) *SemanticGuess*
- `vibecrafted-app/mux-agent/src/lib.rs::Config`: Reached (idiom_runtime_role:public_entrypoint) *SemanticGuess*
- `vibecrafted-app/mux-agent/src/lib.rs::DEFAULT_STATUS_SOCKET`: Reached (idiom_runtime_role:public_entrypoint) *SemanticGuess*
- `vibecrafted-app/mux-agent/src/lib.rs::DaemonStatus`: Reached (idiom_runtime_role:public_entrypoint) *SemanticGuess*
- `vibecrafted-app/mux-agent/src/lib.rs::HeartbeatConfig`: Reached (idiom_runtime_role:public_entrypoint) *SemanticGuess*
- `vibecrafted-app/mux-agent/src/lib.rs::MAX_PENDING`: Reached (idiom_runtime_role:public_entrypoint) *SemanticGuess*
- `vibecrafted-app/mux-agent/src/lib.rs::MAX_QUEUE`: Reached (idiom_runtime_role:public_entrypoint) *SemanticGuess*
- `vibecrafted-app/mux-agent/src/lib.rs::ManagedServer`: Reached (idiom_runtime_role:public_entrypoint) *SemanticGuess*
- `vibecrafted-app/mux-agent/src/lib.rs::MultiServerStatus`: Reached (idiom_runtime_role:public_entrypoint) *SemanticGuess*
- `vibecrafted-app/mux-agent/src/lib.rs::MuxState`: Reached (idiom_runtime_role:public_entrypoint) *SemanticGuess*
- `vibecrafted-app/mux-agent/src/lib.rs::ResolvedParams`: Reached (idiom_runtime_role:public_entrypoint) *SemanticGuess*
- `vibecrafted-app/mux-agent/src/lib.rs::ServerCommand`: Reached (idiom_runtime_role:public_entrypoint) *SemanticGuess*
- `vibecrafted-app/mux-agent/src/lib.rs::ServerConfig`: Reached (idiom_runtime_role:public_entrypoint) *SemanticGuess*
- `vibecrafted-app/mux-agent/src/lib.rs::ServerRef`: Reached (idiom_runtime_role:public_entrypoint) *SemanticGuess*
- `vibecrafted-app/mux-agent/src/lib.rs::ServerStatus`: Reached (idiom_runtime_role:public_entrypoint) *SemanticGuess*
- `vibecrafted-app/mux-agent/src/lib.rs::StatusLevel`: Reached (idiom_runtime_role:public_entrypoint) *SemanticGuess*
- `vibecrafted-app/mux-agent/src/lib.rs::StatusSnapshot`: Reached (idiom_runtime_role:public_entrypoint) *SemanticGuess*
- `vibecrafted-app/mux-agent/src/lib.rs::StatusState`: Reached (idiom_runtime_role:public_entrypoint) *SemanticGuess*
- `vibecrafted-app/mux-agent/src/lib.rs::TuiMuxState`: Reached (idiom_runtime_role:public_entrypoint) *SemanticGuess*
- `vibecrafted-app/mux-agent/src/lib.rs::format_uptime`: Reached (idiom_runtime_role:public_entrypoint) *SemanticGuess*
- `vibecrafted-app/mux-agent/src/lib.rs::health_check`: Reached (idiom_runtime_role:public_entrypoint) *SemanticGuess*
- `vibecrafted-app/mux-agent/src/lib.rs::is_running`: Reached (idiom_runtime_role:library_helper) *SemanticGuess*
- `vibecrafted-app/mux-agent/src/lib.rs::new`: Reached (idiom_runtime_role:library_helper) *SemanticGuess*
- `vibecrafted-app/mux-agent/src/lib.rs::print_status_table`: Reached (idiom_runtime_role:public_entrypoint) *SemanticGuess*
- `vibecrafted-app/mux-agent/src/lib.rs::query_status`: Reached (idiom_runtime_role:public_entrypoint) *SemanticGuess*
- `vibecrafted-app/mux-agent/src/lib.rs::resolve_params_multi`: Reached (idiom_runtime_role:public_entrypoint) *SemanticGuess*
- `vibecrafted-app/mux-agent/src/lib.rs::run_multi_tui`: Reached (idiom_runtime_role:public_entrypoint) *SemanticGuess*
- `vibecrafted-app/mux-agent/src/lib.rs::run_mux`: Reached (idiom_runtime_role:public_entrypoint) *SemanticGuess*
- `vibecrafted-app/mux-agent/src/lib.rs::run_proxy`: Reached (idiom_runtime_role:public_entrypoint) *SemanticGuess*
- `vibecrafted-app/mux-agent/src/lib.rs::run_status_listener`: Reached (idiom_runtime_role:public_entrypoint) *SemanticGuess*
- `vibecrafted-app/mux-agent/src/lib.rs::service_name`: Reached (idiom_runtime_role:library_helper) *SemanticGuess*
- `vibecrafted-app/mux-agent/src/lib.rs::shutdown`: Reached (idiom_runtime_role:library_helper) *SemanticGuess*
- `vibecrafted-app/mux-agent/src/lib.rs::wait`: Reached (idiom_runtime_role:library_helper) *SemanticGuess*
- `vibecrafted-app/mux-agent/src/lib.rs::with_args`: Reached (idiom_runtime_role:library_helper) *SemanticGuess*
- `vibecrafted-app/mux-agent/src/lib.rs::with_env`: Reached (idiom_runtime_role:library_helper) *SemanticGuess*
- `vibecrafted-app/mux-agent/src/lib.rs::with_env_var`: Reached (idiom_runtime_role:library_helper) *SemanticGuess*
- `vibecrafted-app/mux-agent/src/lib.rs::with_heartbeat`: Reached (idiom_runtime_role:library_helper) *SemanticGuess*
- `vibecrafted-app/mux-agent/src/lib.rs::with_heartbeat_enabled`: Reached (idiom_runtime_role:library_helper) *SemanticGuess*
- `vibecrafted-app/mux-agent/src/lib.rs::with_heartbeat_max_failures`: Reached (idiom_runtime_role:library_helper) *SemanticGuess*
- `vibecrafted-app/mux-agent/src/lib.rs::with_lazy_start`: Reached (idiom_runtime_role:library_helper) *SemanticGuess*
- `vibecrafted-app/mux-agent/src/lib.rs::with_log_level`: Reached (idiom_runtime_role:library_helper) *SemanticGuess*
- `vibecrafted-app/mux-agent/src/lib.rs::with_max_clients`: Reached (idiom_runtime_role:library_helper) *SemanticGuess*
- `vibecrafted-app/mux-agent/src/lib.rs::with_max_request_bytes`: Reached (idiom_runtime_role:library_helper) *SemanticGuess*
- `vibecrafted-app/mux-agent/src/lib.rs::with_max_restarts`: Reached (idiom_runtime_role:library_helper) *SemanticGuess*
- `vibecrafted-app/mux-agent/src/lib.rs::with_request_timeout`: Reached (idiom_runtime_role:library_helper) *SemanticGuess*
- `vibecrafted-app/mux-agent/src/lib.rs::with_restart_backoff`: Reached (idiom_runtime_role:library_helper) *SemanticGuess*
- `vibecrafted-app/mux-agent/src/lib.rs::with_service_name`: Reached (idiom_runtime_role:library_helper) *SemanticGuess*
- `vibecrafted-app/mux-agent/src/lib.rs::with_status_file`: Reached (idiom_runtime_role:library_helper) *SemanticGuess*
- `vibecrafted-app/mux-agent/src/lib.rs::with_tray`: Reached (idiom_runtime_role:library_helper) *SemanticGuess*
- `vibecrafted-app/mux-agent/src/multi.rs::add_server`: Reached (idiom_runtime_role:library_helper) *SemanticGuess*
- `vibecrafted-app/mux-agent/src/multi.rs::new`: Reached (idiom_runtime_role:library_helper) *SemanticGuess*
- `vibecrafted-app/mux-agent/src/multi_tui.rs::new`: Reached (idiom_runtime_role:library_helper) *SemanticGuess*
- `vibecrafted-app/mux-agent/src/multi_tui.rs::quit`: Reached (idiom_runtime_role:library_helper) *SemanticGuess*
- `vibecrafted-app/mux-agent/src/multi_tui.rs::select_next`: Reached (idiom_runtime_role:library_helper) *SemanticGuess*
- `vibecrafted-app/mux-agent/src/multi_tui.rs::select_previous`: Reached (idiom_runtime_role:library_helper) *SemanticGuess*
- `vibecrafted-app/mux-agent/src/multi_tui.rs::selected_server`: Reached (idiom_runtime_role:library_helper) *SemanticGuess*
- `vibecrafted-app/mux-agent/src/multi_tui.rs::should_quit`: Reached (idiom_runtime_role:library_helper) *SemanticGuess*
- `vibecrafted-app/mux-agent/src/multi_tui.rs::update_statuses`: Reached (idiom_runtime_role:library_helper) *SemanticGuess*
- `vibecrafted-app/mux-agent/src/runtime/heartbeat.rs::disabled`: Reached (idiom_runtime_role:library_helper) *SemanticGuess*
- `vibecrafted-app/mux-agent/src/runtime/heartbeat.rs::new`: Reached (idiom_runtime_role:library_helper) *SemanticGuess*
- `vibecrafted-app/mux-agent/src/runtime/mod.rs::DEFAULT_STATUS_SOCKET`: Reached (idiom_runtime_role:public_entrypoint) *SemanticGuess*
- `vibecrafted-app/mux-agent/src/runtime/mod.rs::DaemonStatus`: Reached (idiom_runtime_role:public_entrypoint) *SemanticGuess*
- `vibecrafted-app/mux-agent/src/runtime/mod.rs::HeartbeatConfig`: Reached (idiom_runtime_role:public_entrypoint) *SemanticGuess*
- `vibecrafted-app/mux-agent/src/runtime/mod.rs::HeartbeatEvent`: Reached (idiom_runtime_role:public_entrypoint) *SemanticGuess*
- `vibecrafted-app/mux-agent/src/runtime/mod.rs::HeartbeatInspectorContext`: Reached (idiom_runtime_role:public_entrypoint) *SemanticGuess*
- `vibecrafted-app/mux-agent/src/runtime/mod.rs::MAX_PENDING`: Reached (idiom_runtime_role:public_entrypoint) *SemanticGuess*
- `vibecrafted-app/mux-agent/src/runtime/mod.rs::MAX_QUEUE`: Reached (idiom_runtime_role:public_entrypoint) *SemanticGuess*
- `vibecrafted-app/mux-agent/src/runtime/mod.rs::ServerRef`: Reached (idiom_runtime_role:public_entrypoint) *SemanticGuess*
- `vibecrafted-app/mux-agent/src/runtime/mod.rs::StatusState`: Reached (idiom_runtime_role:public_entrypoint) *SemanticGuess*
- `vibecrafted-app/mux-agent/src/runtime/mod.rs::is_heartbeat_response`: Reached (idiom_runtime_role:public_entrypoint) *SemanticGuess*
- `vibecrafted-app/mux-agent/src/runtime/mod.rs::print_status_table`: Reached (idiom_runtime_role:public_entrypoint) *SemanticGuess*
- `vibecrafted-app/mux-agent/src/runtime/mod.rs::query_status`: Reached (idiom_runtime_role:public_entrypoint) *SemanticGuess*
- `vibecrafted-app/mux-agent/src/runtime/mod.rs::run_proxy`: Reached (idiom_runtime_role:public_entrypoint) *SemanticGuess*
- `vibecrafted-app/mux-agent/src/runtime/mod.rs::run_status_listener`: Reached (idiom_runtime_role:public_entrypoint) *SemanticGuess*
- `vibecrafted-app/mux-agent/src/runtime/mod.rs::spawn_heartbeat_inspector`: Reached (idiom_runtime_role:public_entrypoint) *SemanticGuess*
- `vibecrafted-app/mux-agent/src/runtime/mod.rs::spawn_status_writer`: Reached (idiom_runtime_role:public_entrypoint) *SemanticGuess*
- `vibecrafted-app/mux-agent/src/runtime/status.rs::collect_status`: Reached (idiom_runtime_role:library_helper) *SemanticGuess*
- `vibecrafted-app/mux-agent/src/runtime/status.rs::new`: Reached (idiom_runtime_role:library_helper) *SemanticGuess*
- `vibecrafted-app/mux-agent/src/runtime/status.rs::register_server`: Reached (idiom_runtime_role:library_helper) *SemanticGuess*
- `vibecrafted-app/mux-agent/src/scan.rs::as_label`: Reached (idiom_runtime_role:library_helper) *SemanticGuess*
- `vibecrafted-app/mux-agent/src/scan.rs::display_name`: Reached (idiom_runtime_role:library_helper) *SemanticGuess*
- `vibecrafted-app/mux-agent/src/scan.rs::into_host_service`: Reached (idiom_runtime_role:library_helper) *SemanticGuess*
- `vibecrafted-app/mux-agent/src/state.rs::buffer_message`: Reached (idiom_runtime_role:library_helper) *SemanticGuess*
- `vibecrafted-app/mux-agent/src/state.rs::complete_handshake`: Reached (idiom_runtime_role:library_helper) *SemanticGuess*
- `vibecrafted-app/mux-agent/src/state.rs::get_handshake_mut`: Reached (idiom_runtime_role:library_helper) *SemanticGuess*
- `vibecrafted-app/mux-agent/src/state.rs::is_handshake_complete`: Reached (idiom_runtime_role:library_helper) *SemanticGuess*
- `vibecrafted-app/mux-agent/src/state.rs::is_handshake_timed_out`: Reached (idiom_runtime_role:library_helper) *SemanticGuess*
- `vibecrafted-app/mux-agent/src/state.rs::mark_handshake_complete`: Reached (idiom_runtime_role:library_helper) *SemanticGuess*
- `vibecrafted-app/mux-agent/src/state.rs::new`: Reached (idiom_runtime_role:library_helper) *SemanticGuess*
- `vibecrafted-app/mux-agent/src/state.rs::next_request_id`: Reached (idiom_runtime_role:library_helper) *SemanticGuess*
- `vibecrafted-app/mux-agent/src/state.rs::register_client`: Reached (idiom_runtime_role:library_helper) *SemanticGuess*
- `vibecrafted-app/mux-agent/src/state.rs::unregister_client`: Reached (idiom_runtime_role:library_helper) *SemanticGuess*
- `vibecrafted-app/mux-agent/src/wizard/types.rs::short_label`: Reached (idiom_runtime_role:library_helper) *SemanticGuess*
- `vibecrafted-app/mux-agent/tools/install.sh::info`: Reached (idiom_runtime_role:library_helper) *SemanticGuess*
- `vibecrafted-app/mux-agent/tools/install.sh::warn`: Reached (dispatch_handler:case_statement:vibecrafted-app/mux-agent/tools/install.sh) *LoctreeDerived*
- `vibecrafted-app/shell-agent/Makefile::app`: Reached (phony_make_target) *LoctreeDerived*
- `vibecrafted-app/shell-agent/Makefile::app-debug`: Reached (phony_make_target) *LoctreeDerived*
- `vibecrafted-app/shell-agent/Makefile::bindings`: Reached (phony_make_target) *LoctreeDerived*
- `vibecrafted-app/shell-agent/Makefile::dmg`: Reached (phony_make_target) *LoctreeDerived*
- `vibecrafted-app/shell-agent/Makefile::dmg-signed`: Reached (phony_make_target) *LoctreeDerived*
- `vibecrafted-app/shell-agent/Makefile::help`: Reached (phony_make_target) *LoctreeDerived*
- `vibecrafted-app/shell-agent/Makefile::xcode`: Reached (phony_make_target) *LoctreeDerived*
- `vibecrafted-app/tray-agent/src/ipc_client.rs::ClientKind`: Reached (idiom_runtime_role:public_entrypoint) *SemanticGuess*
- `vibecrafted-app/tray-agent/src/ipc_client.rs::IpcEvent`: Reached (idiom_runtime_role:public_entrypoint) *SemanticGuess*
- `vibecrafted-app/tray-agent/src/ipc_client.rs::MuxControlCommand`: Reached (idiom_runtime_role:public_entrypoint) *SemanticGuess*
- `vibecrafted-app/tray-agent/src/ipc_client.rs::MuxControlResponse`: Reached (idiom_runtime_role:public_entrypoint) *SemanticGuess*
- `vibecrafted-app/tray-agent/src/lib.rs::MenuIds`: Reached (idiom_runtime_role:public_entrypoint) *SemanticGuess*
- `vibecrafted-app/tray-agent/src/lib.rs::TrayMenuEvent`: Reached (idiom_runtime_role:public_entrypoint) *SemanticGuess*
- `vibecrafted-app/tray-agent/src/lib.rs::TrayStatus`: Reached (idiom_runtime_role:public_entrypoint) *SemanticGuess*
- `vibecrafted-app/tray-agent/src/lib.rs::menu_event_receiver`: Reached (idiom_runtime_role:public_entrypoint) *SemanticGuess*
- `vibecrafted-app/tray-agent/src/lib.rs::send_menu_event`: Reached (idiom_runtime_role:public_entrypoint) *SemanticGuess*
- `vibecrafted-app/tray-agent/src/lib.rs::update_tray_status`: Reached (idiom_runtime_role:public_entrypoint) *SemanticGuess*
- `vibecrafted-app/tray-agent/src/types.rs::is_active`: Reached (idiom_runtime_role:library_helper) *SemanticGuess*
- `vibecrafted-app/tray-agent/src/types.rs::label`: Reached (idiom_runtime_role:library_helper) *SemanticGuess*
- `vibecrafted-app/tray-agent/src/types.rs::menu_label`: Reached (idiom_runtime_role:library_helper) *SemanticGuess*
- `vibecrafted-app/tray-agent/src/types.rs::resolve_recent_run`: Reached (idiom_runtime_role:library_helper) *SemanticGuess*
- `vibecrafted-app/tray-agent/src/types.rs::resolve_restart_service`: Reached (idiom_runtime_role:library_helper) *SemanticGuess*
- `vibecrafted-app/tray-agent/src/types.rs::resolve_verify_client`: Reached (idiom_runtime_role:library_helper) *SemanticGuess*
- `vibecrafted-app/tray-agent/src/types.rs::tooltip`: Reached (idiom_runtime_role:library_helper) *SemanticGuess*
- `vibecrafted-app/tui-agent/src/app.rs::active_run_count`: Reached (idiom_runtime_role:library_helper) *SemanticGuess*
- `vibecrafted-app/tui-agent/src/app.rs::active_tab`: Reached (idiom_runtime_role:library_helper) *SemanticGuess*
- `vibecrafted-app/tui-agent/src/app.rs::adjust_dispatch_selection`: Reached (idiom_runtime_role:library_helper) *SemanticGuess*
- `vibecrafted-app/tui-agent/src/app.rs::append_status`: Reached (idiom_runtime_role:library_helper) *SemanticGuess*
- `vibecrafted-app/tui-agent/src/app.rs::archive_selected_run`: Reached (idiom_runtime_role:library_helper) *SemanticGuess*
- `vibecrafted-app/tui-agent/src/app.rs::artifact_lines`: Reached (idiom_runtime_role:library_helper) *SemanticGuess*
- `vibecrafted-app/tui-agent/src/app.rs::clear_search`: Reached (idiom_runtime_role:library_helper) *SemanticGuess*
- `vibecrafted-app/tui-agent/src/app.rs::clipboard_payload`: Reached (idiom_runtime_role:library_helper) *SemanticGuess*
- `vibecrafted-app/tui-agent/src/app.rs::copy_selected_run_to_clipboard`: Reached (idiom_runtime_role:library_helper) *SemanticGuess*
- `vibecrafted-app/tui-agent/src/app.rs::cycle_agent`: Reached (idiom_runtime_role:library_helper) *SemanticGuess*
- `vibecrafted-app/tui-agent/src/app.rs::cycle_runtime`: Reached (idiom_runtime_role:library_helper) *SemanticGuess*
- `vibecrafted-app/tui-agent/src/app.rs::deep_action_index_for_primary_mission_queue_item`: Reached (idiom_runtime_role:library_helper) *SemanticGuess*
- `vibecrafted-app/tui-agent/src/app.rs::deep_actions`: Reached (idiom_runtime_role:library_helper) *SemanticGuess*
- `vibecrafted-app/tui-agent/src/app.rs::deep_control_lines`: Reached (idiom_runtime_role:library_helper) *SemanticGuess*
- `vibecrafted-app/tui-agent/src/app.rs::detail_lines`: Reached (idiom_runtime_role:library_helper) *SemanticGuess*
- `vibecrafted-app/tui-agent/src/app.rs::dispatch_focus`: Reached (idiom_runtime_role:library_helper) *SemanticGuess*
- `vibecrafted-app/tui-agent/src/app.rs::error_lines`: Reached (idiom_runtime_role:library_helper) *SemanticGuess*
- `vibecrafted-app/tui-agent/src/app.rs::event_lines`: Reached (idiom_runtime_role:library_helper) *SemanticGuess*
- `vibecrafted-app/tui-agent/src/app.rs::finish_prompt_edit`: Reached (idiom_runtime_role:library_helper) *SemanticGuess*
- `vibecrafted-app/tui-agent/src/app.rs::from_index`: Reached (idiom_runtime_role:library_helper) *SemanticGuess*
- `vibecrafted-app/tui-agent/src/app.rs::handle_ipc_event`: Reached (idiom_runtime_role:library_helper) *SemanticGuess*
- `vibecrafted-app/tui-agent/src/app.rs::help_lines`: Reached (idiom_runtime_role:library_helper) *SemanticGuess*
- `vibecrafted-app/tui-agent/src/app.rs::index`: Reached (idiom_runtime_role:library_helper) *SemanticGuess*
- `vibecrafted-app/tui-agent/src/app.rs::label`: Reached (idiom_runtime_role:library_helper) *SemanticGuess*
- `vibecrafted-app/tui-agent/src/app.rs::launch_command`: Reached (idiom_runtime_role:library_helper) *SemanticGuess*
- `vibecrafted-app/tui-agent/src/app.rs::launch_env`: Reached (idiom_runtime_role:library_helper) *SemanticGuess*
- `vibecrafted-app/tui-agent/src/app.rs::launch_request`: Reached (idiom_runtime_role:library_helper) *SemanticGuess*
- `vibecrafted-app/tui-agent/src/app.rs::move_deep_selection`: Reached (idiom_runtime_role:library_helper) *SemanticGuess*
- `vibecrafted-app/tui-agent/src/app.rs::move_dispatch_selection`: Reached (idiom_runtime_role:library_helper) *SemanticGuess*
- `vibecrafted-app/tui-agent/src/app.rs::move_mission_focus`: Reached (idiom_runtime_role:library_helper) *SemanticGuess*
- `vibecrafted-app/tui-agent/src/app.rs::move_selection`: Reached (idiom_runtime_role:library_helper) *SemanticGuess*
- `vibecrafted-app/tui-agent/src/app.rs::mux_status_lines`: Reached (idiom_runtime_role:library_helper) *SemanticGuess*
- `vibecrafted-app/tui-agent/src/app.rs::new`: Reached (idiom_runtime_role:library_helper) *SemanticGuess*
- `vibecrafted-app/tui-agent/src/app.rs::next`: Reached (idiom_runtime_role:library_helper) *SemanticGuess*
- `vibecrafted-app/tui-agent/src/app.rs::next_tab`: Reached (idiom_runtime_role:library_helper) *SemanticGuess*
- `vibecrafted-app/tui-agent/src/app.rs::open_artifact`: Reached (idiom_runtime_role:library_helper) *SemanticGuess*
- `vibecrafted-app/tui-agent/src/app.rs::open_polarize_intent`: Reached (idiom_runtime_role:library_helper) *SemanticGuess*
- `vibecrafted-app/tui-agent/src/app.rs::polarize_status_lines`: Reached (idiom_runtime_role:library_helper) *SemanticGuess*
- `vibecrafted-app/tui-agent/src/app.rs::preselect_controls_from_mission_queue`: Reached (idiom_runtime_role:library_helper) *SemanticGuess*
- `vibecrafted-app/tui-agent/src/app.rs::previous_tab`: Reached (idiom_runtime_role:library_helper) *SemanticGuess*
- `vibecrafted-app/tui-agent/src/app.rs::prompt_edit_lines`: Reached (idiom_runtime_role:library_helper) *SemanticGuess*
- `vibecrafted-app/tui-agent/src/app.rs::prompt_lines`: Reached (idiom_runtime_role:library_helper) *SemanticGuess*
- `vibecrafted-app/tui-agent/src/app.rs::push_launch_history`: Reached (idiom_runtime_role:library_helper) *SemanticGuess*
- `vibecrafted-app/tui-agent/src/app.rs::refresh`: Reached (idiom_runtime_role:library_helper) *SemanticGuess*
- `vibecrafted-app/tui-agent/src/app.rs::refresh_mission_control`: Reached (idiom_runtime_role:library_helper) *SemanticGuess*
- `vibecrafted-app/tui-agent/src/app.rs::refresh_mux`: Reached (idiom_runtime_role:library_helper) *SemanticGuess*
- `vibecrafted-app/tui-agent/src/app.rs::refresh_polarize`: Reached (idiom_runtime_role:library_helper) *SemanticGuess*
- `vibecrafted-app/tui-agent/src/app.rs::selected_agent`: Reached (idiom_runtime_role:library_helper) *SemanticGuess*
- `vibecrafted-app/tui-agent/src/app.rs::selected_deep_action`: Reached (idiom_runtime_role:library_helper) *SemanticGuess*
- `vibecrafted-app/tui-agent/src/app.rs::selected_run`: Reached (idiom_runtime_role:library_helper) *SemanticGuess*
- `vibecrafted-app/tui-agent/src/app.rs::set_active_tab`: Reached (idiom_runtime_role:library_helper) *SemanticGuess*
- `vibecrafted-app/tui-agent/src/app.rs::set_launch_kind`: Reached (idiom_runtime_role:library_helper) *SemanticGuess*
- `vibecrafted-app/tui-agent/src/app.rs::set_search_query`: Reached (idiom_runtime_role:library_helper) *SemanticGuess*
- `vibecrafted-app/tui-agent/src/app.rs::shift_agent`: Reached (idiom_runtime_role:library_helper) *SemanticGuess*
- `vibecrafted-app/tui-agent/src/app.rs::shift_launch_kind`: Reached (idiom_runtime_role:library_helper) *SemanticGuess*
- `vibecrafted-app/tui-agent/src/app.rs::shift_runtime`: Reached (idiom_runtime_role:library_helper) *SemanticGuess*
- `vibecrafted-app/tui-agent/src/app.rs::show_error`: Reached (idiom_runtime_role:library_helper) *SemanticGuess*
- `vibecrafted-app/tui-agent/src/app.rs::status_summary`: Reached (idiom_runtime_role:library_helper) *SemanticGuess*
- `vibecrafted-app/tui-agent/src/app.rs::sync_selection`: Reached (idiom_runtime_role:library_helper) *SemanticGuess*
- `vibecrafted-app/tui-agent/src/app.rs::tab_labels`: Reached (idiom_runtime_role:library_helper) *SemanticGuess*
- `vibecrafted-app/tui-agent/src/app.rs::title`: Reached (idiom_runtime_role:library_helper) *SemanticGuess*
- `vibecrafted-app/tui-agent/src/app.rs::toggle_filter`: Reached (idiom_runtime_role:library_helper) *SemanticGuess*
- `vibecrafted-app/tui-agent/src/launch.rs::command_line`: Reached (idiom_runtime_role:library_helper) *SemanticGuess*
- `vibecrafted-app/tui-agent/src/launch.rs::cycle`: Reached (idiom_runtime_role:library_helper) *SemanticGuess*
- `vibecrafted-app/tui-agent/src/launch.rs::human_description`: Reached (idiom_runtime_role:library_helper) *SemanticGuess*
- `vibecrafted-app/tui-agent/src/launch.rs::human_title`: Reached (idiom_runtime_role:library_helper) *SemanticGuess*
- `vibecrafted-app/tui-agent/src/launch.rs::is_session_visible`: Reached (idiom_runtime_role:library_helper) *SemanticGuess*
- `vibecrafted-app/tui-agent/src/launch.rs::label`: Reached (idiom_runtime_role:library_helper) *SemanticGuess*
- `vibecrafted-app/tui-agent/src/launch.rs::readiness_probe`: Reached (idiom_runtime_role:library_helper) *SemanticGuess*
- `vibecrafted-app/tui-agent/src/launch.rs::spawn`: Reached (idiom_runtime_role:library_helper) *SemanticGuess*
- `vibecrafted-app/tui-agent/src/launch.rs::spawn_detached`: Reached (idiom_runtime_role:library_helper) *SemanticGuess*
- `vibecrafted-app/tui-agent/src/launch.rs::spawn_interactive_with_stderr`: Reached (idiom_runtime_role:library_helper) *SemanticGuess*
- `vibecrafted-app/tui-agent/src/lib.rs::ActionPriority`: Reached (idiom_runtime_role:public_entrypoint) *SemanticGuess*
- `vibecrafted-app/tui-agent/src/lib.rs::ActionQueueItem`: Reached (idiom_runtime_role:public_entrypoint) *SemanticGuess*
- `vibecrafted-app/tui-agent/src/lib.rs::ActionQueueKind`: Reached (idiom_runtime_role:public_entrypoint) *SemanticGuess*
- `vibecrafted-app/tui-agent/src/lib.rs::ActiveDispatch`: Reached (idiom_runtime_role:public_entrypoint) *SemanticGuess*
- `vibecrafted-app/tui-agent/src/lib.rs::AgentStatsRow`: Reached (idiom_runtime_role:public_entrypoint) *SemanticGuess*
- `vibecrafted-app/tui-agent/src/lib.rs::App`: Reached (idiom_runtime_role:public_entrypoint) *SemanticGuess*
- `vibecrafted-app/tui-agent/src/lib.rs::AppConfig`: Reached (idiom_runtime_role:public_entrypoint) *SemanticGuess*
- `vibecrafted-app/tui-agent/src/lib.rs::AppTab`: Reached (idiom_runtime_role:public_entrypoint) *SemanticGuess*
- `vibecrafted-app/tui-agent/src/lib.rs::CliOptions`: Reached (idiom_runtime_role:public_entrypoint) *SemanticGuess*
- `vibecrafted-app/tui-agent/src/lib.rs::DataQuality`: Reached (idiom_runtime_role:public_entrypoint) *SemanticGuess*
- `vibecrafted-app/tui-agent/src/lib.rs::DeepAction`: Reached (idiom_runtime_role:public_entrypoint) *SemanticGuess*
- `vibecrafted-app/tui-agent/src/lib.rs::DispatchFocus`: Reached (idiom_runtime_role:public_entrypoint) *SemanticGuess*
- `vibecrafted-app/tui-agent/src/lib.rs::FailureEntry`: Reached (idiom_runtime_role:public_entrypoint) *SemanticGuess*
- `vibecrafted-app/tui-agent/src/lib.rs::FleetHealthSignal`: Reached (idiom_runtime_role:public_entrypoint) *SemanticGuess*
- `vibecrafted-app/tui-agent/src/lib.rs::FleetHealthStatus`: Reached (idiom_runtime_role:public_entrypoint) *SemanticGuess*
- `vibecrafted-app/tui-agent/src/lib.rs::LaunchCommand`: Reached (idiom_runtime_role:public_entrypoint) *SemanticGuess*
- `vibecrafted-app/tui-agent/src/lib.rs::LaunchFocus`: Reached (idiom_runtime_role:public_entrypoint) *SemanticGuess*
- `vibecrafted-app/tui-agent/src/lib.rs::LaunchKind`: Reached (idiom_runtime_role:public_entrypoint) *SemanticGuess*
- `vibecrafted-app/tui-agent/src/lib.rs::MissionControlState`: Reached (idiom_runtime_role:public_entrypoint) *SemanticGuess*
- `vibecrafted-app/tui-agent/src/lib.rs::PolarizeBand`: Reached (idiom_runtime_role:public_entrypoint) *SemanticGuess*
- `vibecrafted-app/tui-agent/src/lib.rs::PolarizeIntent`: Reached (idiom_runtime_role:public_entrypoint) *SemanticGuess*
- `vibecrafted-app/tui-agent/src/lib.rs::QueueScope`: Reached (idiom_runtime_role:public_entrypoint) *SemanticGuess*
- `vibecrafted-app/tui-agent/src/lib.rs::SkillAgent`: Reached (idiom_runtime_role:public_entrypoint) *SemanticGuess*
- `vibecrafted-app/tui-agent/src/lib.rs::SkillEntry`: Reached (idiom_runtime_role:public_entrypoint) *SemanticGuess*
- `vibecrafted-app/tui-agent/src/lib.rs::SkillPayload`: Reached (idiom_runtime_role:public_entrypoint) *SemanticGuess*
- `vibecrafted-app/tui-agent/src/lib.rs::SkillPayloadKind`: Reached (idiom_runtime_role:public_entrypoint) *SemanticGuess*
- `vibecrafted-app/tui-agent/src/lib.rs::SkillStatsRow`: Reached (idiom_runtime_role:public_entrypoint) *SemanticGuess*
- `vibecrafted-app/tui-agent/src/lib.rs::WaveSegment`: Reached (idiom_runtime_role:public_entrypoint) *SemanticGuess*
- `vibecrafted-app/tui-agent/src/lib.rs::WaveState`: Reached (idiom_runtime_role:public_entrypoint) *SemanticGuess*
- `vibecrafted-app/tui-agent/src/lib.rs::build_config`: Reached (idiom_runtime_role:public_entrypoint) *SemanticGuess*
- `vibecrafted-app/tui-agent/src/lib.rs::default_artifact_root`: Reached (idiom_runtime_role:public_entrypoint) *SemanticGuess*
- `vibecrafted-app/tui-agent/src/lib.rs::detail_lines`: Reached (idiom_runtime_role:library_helper) *SemanticGuess*
- `vibecrafted-app/tui-agent/src/lib.rs::parse_args`: Reached (idiom_runtime_role:public_entrypoint) *SemanticGuess*
- `vibecrafted-app/tui-agent/src/mission_control.rs::build`: Reached (idiom_runtime_role:library_helper) *SemanticGuess*
- `vibecrafted-app/tui-agent/src/mission_control.rs::build_at`: Reached (idiom_runtime_role:library_helper) *SemanticGuess*
- `vibecrafted-app/tui-agent/src/mission_control.rs::build_at_for_root`: Reached (idiom_runtime_role:library_helper) *SemanticGuess*
- `vibecrafted-app/tui-agent/src/mission_control.rs::build_at_with_intents`: Reached (idiom_runtime_role:library_helper) *SemanticGuess*
- `vibecrafted-app/tui-agent/src/mission_control.rs::build_with_intents`: Reached (idiom_runtime_role:library_helper) *SemanticGuess*
- `vibecrafted-app/tui-agent/src/mission_control.rs::glyph`: Reached (idiom_runtime_role:library_helper) *SemanticGuess*
- `vibecrafted-app/tui-agent/src/mission_control.rs::is_empty`: Reached (idiom_runtime_role:library_helper) *SemanticGuess*
- `vibecrafted-app/tui-agent/src/mission_control.rs::label`: Reached (idiom_runtime_role:library_helper) *SemanticGuess*
- `vibecrafted-app/tui-agent/src/mission_control.rs::marker`: Reached (idiom_runtime_role:library_helper) *SemanticGuess*
- `vibecrafted-app/tui-agent/src/mission_control.rs::total_entries`: Reached (idiom_runtime_role:library_helper) *SemanticGuess*
- `vibecrafted-app/tui-agent/src/mux.rs::failure_reason`: Reached (idiom_runtime_role:library_helper) *SemanticGuess*
- `vibecrafted-app/tui-agent/src/mux.rs::from_json`: Reached (idiom_runtime_role:library_helper) *SemanticGuess*
- `vibecrafted-app/tui-agent/src/mux.rs::from_path_and_result`: Reached (idiom_runtime_role:library_helper) *SemanticGuess*
- `vibecrafted-app/tui-agent/src/mux.rs::is_healthy`: Reached (idiom_runtime_role:library_helper) *SemanticGuess*
- `vibecrafted-app/tui-agent/src/mux.rs::label`: Reached (idiom_runtime_role:library_helper) *SemanticGuess*
- `vibecrafted-app/tui-agent/src/mux.rs::read`: Reached (idiom_runtime_role:library_helper) *SemanticGuess*
- `vibecrafted-app/tui-agent/src/mux.rs::start`: Reached (idiom_runtime_role:library_helper) *SemanticGuess*
- `vibecrafted-app/tui-agent/src/mux.rs::summary_line`: Reached (idiom_runtime_role:library_helper) *SemanticGuess*
- `vibecrafted-app/tui-agent/src/polarize.rs::from_score`: Reached (idiom_runtime_role:library_helper) *SemanticGuess*
- `vibecrafted-app/tui-agent/src/polarize.rs::label`: Reached (idiom_runtime_role:library_helper) *SemanticGuess*
- `vibecrafted-app/tui-agent/src/polarize.rs::recommended_action`: Reached (idiom_runtime_role:library_helper) *SemanticGuess*
- `vibecrafted-app/tui-agent/src/polarize.rs::summary_line`: Reached (idiom_runtime_role:library_helper) *SemanticGuess*
- `vibecrafted-app/tui-agent/src/skills_catalog.rs::command_token`: Reached (idiom_runtime_role:library_helper) *SemanticGuess*
- `vibecrafted-app/tui-agent/src/skills_catalog.rs::emphasized`: Reached (idiom_runtime_role:library_helper) *SemanticGuess*
- `vibecrafted-app/tui-agent/src/skills_catalog.rs::from_cli_token`: Reached (idiom_runtime_role:library_helper) *SemanticGuess*
- `vibecrafted-app/tui-agent/src/skills_catalog.rs::label`: Reached (idiom_runtime_role:library_helper) *SemanticGuess*
- `vibecrafted-app/tui-agent/src/skills_catalog.rs::resolved_cli_token`: Reached (idiom_runtime_role:library_helper) *SemanticGuess*
- `vibecrafted-app/tui-agent/src/state.rs::display_state`: Reached (idiom_runtime_role:library_helper) *SemanticGuess*
- `vibecrafted-app/tui-agent/src/state.rs::empty`: Reached (idiom_runtime_role:library_helper) *SemanticGuess*
- `vibecrafted-app/tui-agent/src/state.rs::label`: Reached (idiom_runtime_role:library_helper) *SemanticGuess*
- `vibecrafted-app/tui-agent/src/state.rs::load`: Reached (idiom_runtime_role:library_helper) *SemanticGuess*
- `vibecrafted-app/tui-agent/src/state.rs::sort_rank`: Reached (idiom_runtime_role:library_helper) *SemanticGuess*

### Env Contracts

- `APP_MACOS_DIR` used in 1 files *LoctreeDerived*
- `APP_PATH` used in 2 files *LoctreeDerived*
- `BASH_SOURCE` used in 66 files *LoctreeDerived*
- `BRIDGE_DIR` used in 1 files *LoctreeDerived*
- `BUILD_DIR` used in 1 files *LoctreeDerived*
- `CARGO_BIN` used in 1 files *LoctreeDerived*
- `CARGO_HOME` used in 1 files *LoctreeDerived*
- `CONTENTS_FOLDER_PATH` used in 1 files *LoctreeDerived*
- `DMG_NAME` used in 1 files *LoctreeDerived*
- `DMG_STAGING` used in 1 files *LoctreeDerived*
- `HOME` used in 42 files *LoctreeDerived*
- `HOOKS_DIR` used in 1 files *LoctreeDerived*
- `INSTALL_DIR` used in 1 files *LoctreeDerived*
- `LIB_NAME` used in 1 files *LoctreeDerived*
- `MACOSX_DEPLOYMENT_TARGET` used in 2 files *LoctreeDerived*
- `MUX_NO_LOCK` used in 1 files *LoctreeDerived*
- `MUX_REF` used in 1 files *LoctreeDerived*
- `PATH` used in 15 files *LoctreeDerived*
- `PRE_COMMIT_SRC` used in 1 files *LoctreeDerived*
- `PRE_PUSH_SRC` used in 1 files *LoctreeDerived*
- `REPO_ROOT` used in 20 files *LoctreeDerived*
- `REPO_URL` used in 1 files *LoctreeDerived*
- `ROOT` used in 6 files *LoctreeDerived*
- `RPATH_NAME` used in 1 files *LoctreeDerived*
- `SIGNING_IDENTITY` used in 1 files *LoctreeDerived*
- `TARGET_BUILD_DIR` used in 1 files *LoctreeDerived*
- `VERSION` used in 2 files *LoctreeDerived*

### Framework Hints

- `entrypoint` at `vibecrafted-app/mux-agent/src/bin/rmcp-mux-proxy.rs`: async_main *RepoVerified*
- `entrypoint` at `vibecrafted-app/mux-agent/src/bin/rmcp-mux-proxy.rs`: main *RepoVerified*
- `entrypoint` at `vibecrafted-app/mux-agent/src/bin/rmcp-mux.rs`: main *RepoVerified*
- `rust:inherent_impl_method` at `vibecrafted-app/mux-agent/src/ipc/context.rs`: vibecrafted-app/mux-agent/src/ipc/context.rs::new *LoctreeDerived*
- `rust:pub_use_reexport` at `vibecrafted-app/mux-agent/src/ipc/mod.rs`: vibecrafted-app/mux-agent/src/ipc/mod.rs::ClientKind *LoctreeDerived*
- `rust:pub_use_reexport` at `vibecrafted-app/mux-agent/src/ipc/mod.rs`: vibecrafted-app/mux-agent/src/ipc/mod.rs::IpcEvent *LoctreeDerived*
- `rust:pub_use_reexport` at `vibecrafted-app/mux-agent/src/ipc/mod.rs`: vibecrafted-app/mux-agent/src/ipc/mod.rs::MuxControlCommand *LoctreeDerived*
- `rust:pub_use_reexport` at `vibecrafted-app/mux-agent/src/ipc/mod.rs`: vibecrafted-app/mux-agent/src/ipc/mod.rs::MuxControlContext *LoctreeDerived*
- `rust:pub_use_reexport` at `vibecrafted-app/mux-agent/src/ipc/mod.rs`: vibecrafted-app/mux-agent/src/ipc/mod.rs::MuxControlResponse *LoctreeDerived*
- `rust:pub_use_reexport` at `vibecrafted-app/mux-agent/src/ipc/mod.rs`: vibecrafted-app/mux-agent/src/ipc/mod.rs::run_server *LoctreeDerived*
- `rust:pub_use_reexport` at `vibecrafted-app/mux-agent/src/ipc/mod.rs`: vibecrafted-app/mux-agent/src/ipc/mod.rs::socket_path *LoctreeDerived*
- `rust:pub_use_reexport` at `vibecrafted-app/mux-agent/src/lib.rs`: vibecrafted-app/mux-agent/src/lib.rs::CliOptions *LoctreeDerived*
- `rust:pub_use_reexport` at `vibecrafted-app/mux-agent/src/lib.rs`: vibecrafted-app/mux-agent/src/lib.rs::Config *LoctreeDerived*
- `rust:pub_use_reexport` at `vibecrafted-app/mux-agent/src/lib.rs`: vibecrafted-app/mux-agent/src/lib.rs::DEFAULT_STATUS_SOCKET *LoctreeDerived*
- `rust:pub_use_reexport` at `vibecrafted-app/mux-agent/src/lib.rs`: vibecrafted-app/mux-agent/src/lib.rs::DaemonStatus *LoctreeDerived*
- `rust:pub_use_reexport` at `vibecrafted-app/mux-agent/src/lib.rs`: vibecrafted-app/mux-agent/src/lib.rs::HeartbeatConfig *LoctreeDerived*
- `rust:pub_use_reexport` at `vibecrafted-app/mux-agent/src/lib.rs`: vibecrafted-app/mux-agent/src/lib.rs::MAX_PENDING *LoctreeDerived*
- `rust:pub_use_reexport` at `vibecrafted-app/mux-agent/src/lib.rs`: vibecrafted-app/mux-agent/src/lib.rs::MAX_QUEUE *LoctreeDerived*
- `rust:pub_use_reexport` at `vibecrafted-app/mux-agent/src/lib.rs`: vibecrafted-app/mux-agent/src/lib.rs::ManagedServer *LoctreeDerived*
- `rust:pub_use_reexport` at `vibecrafted-app/mux-agent/src/lib.rs`: vibecrafted-app/mux-agent/src/lib.rs::MultiServerStatus *LoctreeDerived*
- `rust:pub_use_reexport` at `vibecrafted-app/mux-agent/src/lib.rs`: vibecrafted-app/mux-agent/src/lib.rs::MuxState *LoctreeDerived*
- `rust:pub_use_reexport` at `vibecrafted-app/mux-agent/src/lib.rs`: vibecrafted-app/mux-agent/src/lib.rs::ResolvedParams *LoctreeDerived*
- `rust:pub_use_reexport` at `vibecrafted-app/mux-agent/src/lib.rs`: vibecrafted-app/mux-agent/src/lib.rs::ServerCommand *LoctreeDerived*
- `rust:pub_use_reexport` at `vibecrafted-app/mux-agent/src/lib.rs`: vibecrafted-app/mux-agent/src/lib.rs::ServerConfig *LoctreeDerived*
- `rust:pub_use_reexport` at `vibecrafted-app/mux-agent/src/lib.rs`: vibecrafted-app/mux-agent/src/lib.rs::ServerRef *LoctreeDerived*
- `rust:pub_use_reexport` at `vibecrafted-app/mux-agent/src/lib.rs`: vibecrafted-app/mux-agent/src/lib.rs::ServerStatus *LoctreeDerived*
- `rust:pub_use_reexport` at `vibecrafted-app/mux-agent/src/lib.rs`: vibecrafted-app/mux-agent/src/lib.rs::StatusLevel *LoctreeDerived*
- `rust:pub_use_reexport` at `vibecrafted-app/mux-agent/src/lib.rs`: vibecrafted-app/mux-agent/src/lib.rs::StatusSnapshot *LoctreeDerived*
- `rust:pub_use_reexport` at `vibecrafted-app/mux-agent/src/lib.rs`: vibecrafted-app/mux-agent/src/lib.rs::StatusState *LoctreeDerived*
- `rust:pub_use_reexport` at `vibecrafted-app/mux-agent/src/lib.rs`: vibecrafted-app/mux-agent/src/lib.rs::TuiMuxState *LoctreeDerived*
- `rust:pub_use_reexport` at `vibecrafted-app/mux-agent/src/lib.rs`: vibecrafted-app/mux-agent/src/lib.rs::format_uptime *LoctreeDerived*
- `rust:pub_use_reexport` at `vibecrafted-app/mux-agent/src/lib.rs`: vibecrafted-app/mux-agent/src/lib.rs::health_check *LoctreeDerived*
- `rust:inherent_impl_method` at `vibecrafted-app/mux-agent/src/lib.rs`: vibecrafted-app/mux-agent/src/lib.rs::is_running *LoctreeDerived*
- `rust:inherent_impl_method` at `vibecrafted-app/mux-agent/src/lib.rs`: vibecrafted-app/mux-agent/src/lib.rs::new *LoctreeDerived*
- `rust:pub_use_reexport` at `vibecrafted-app/mux-agent/src/lib.rs`: vibecrafted-app/mux-agent/src/lib.rs::print_status_table *LoctreeDerived*
- `rust:pub_use_reexport` at `vibecrafted-app/mux-agent/src/lib.rs`: vibecrafted-app/mux-agent/src/lib.rs::query_status *LoctreeDerived*
- `rust:pub_use_reexport` at `vibecrafted-app/mux-agent/src/lib.rs`: vibecrafted-app/mux-agent/src/lib.rs::resolve_params_multi *LoctreeDerived*
- `rust:pub_use_reexport` at `vibecrafted-app/mux-agent/src/lib.rs`: vibecrafted-app/mux-agent/src/lib.rs::run_multi_tui *LoctreeDerived*
- `rust:pub_use_reexport` at `vibecrafted-app/mux-agent/src/lib.rs`: vibecrafted-app/mux-agent/src/lib.rs::run_mux *LoctreeDerived*
- `rust:pub_use_reexport` at `vibecrafted-app/mux-agent/src/lib.rs`: vibecrafted-app/mux-agent/src/lib.rs::run_proxy *LoctreeDerived*
- `rust:pub_use_reexport` at `vibecrafted-app/mux-agent/src/lib.rs`: vibecrafted-app/mux-agent/src/lib.rs::run_status_listener *LoctreeDerived*
- `rust:inherent_impl_method` at `vibecrafted-app/mux-agent/src/lib.rs`: vibecrafted-app/mux-agent/src/lib.rs::service_name *LoctreeDerived*
- `rust:inherent_impl_method` at `vibecrafted-app/mux-agent/src/lib.rs`: vibecrafted-app/mux-agent/src/lib.rs::shutdown *LoctreeDerived*
- `rust:inherent_impl_method` at `vibecrafted-app/mux-agent/src/lib.rs`: vibecrafted-app/mux-agent/src/lib.rs::wait *LoctreeDerived*
- `rust:inherent_impl_method` at `vibecrafted-app/mux-agent/src/lib.rs`: vibecrafted-app/mux-agent/src/lib.rs::with_args *LoctreeDerived*
- `rust:inherent_impl_method` at `vibecrafted-app/mux-agent/src/lib.rs`: vibecrafted-app/mux-agent/src/lib.rs::with_env *LoctreeDerived*
- `rust:inherent_impl_method` at `vibecrafted-app/mux-agent/src/lib.rs`: vibecrafted-app/mux-agent/src/lib.rs::with_env_var *LoctreeDerived*
- `rust:inherent_impl_method` at `vibecrafted-app/mux-agent/src/lib.rs`: vibecrafted-app/mux-agent/src/lib.rs::with_heartbeat *LoctreeDerived*
- `rust:inherent_impl_method` at `vibecrafted-app/mux-agent/src/lib.rs`: vibecrafted-app/mux-agent/src/lib.rs::with_heartbeat_enabled *LoctreeDerived*
- `rust:inherent_impl_method` at `vibecrafted-app/mux-agent/src/lib.rs`: vibecrafted-app/mux-agent/src/lib.rs::with_heartbeat_max_failures *LoctreeDerived*
- `rust:inherent_impl_method` at `vibecrafted-app/mux-agent/src/lib.rs`: vibecrafted-app/mux-agent/src/lib.rs::with_lazy_start *LoctreeDerived*
- `rust:inherent_impl_method` at `vibecrafted-app/mux-agent/src/lib.rs`: vibecrafted-app/mux-agent/src/lib.rs::with_log_level *LoctreeDerived*
- `rust:inherent_impl_method` at `vibecrafted-app/mux-agent/src/lib.rs`: vibecrafted-app/mux-agent/src/lib.rs::with_max_clients *LoctreeDerived*
- `rust:inherent_impl_method` at `vibecrafted-app/mux-agent/src/lib.rs`: vibecrafted-app/mux-agent/src/lib.rs::with_max_request_bytes *LoctreeDerived*
- `rust:inherent_impl_method` at `vibecrafted-app/mux-agent/src/lib.rs`: vibecrafted-app/mux-agent/src/lib.rs::with_max_restarts *LoctreeDerived*
- `rust:inherent_impl_method` at `vibecrafted-app/mux-agent/src/lib.rs`: vibecrafted-app/mux-agent/src/lib.rs::with_request_timeout *LoctreeDerived*
- `rust:inherent_impl_method` at `vibecrafted-app/mux-agent/src/lib.rs`: vibecrafted-app/mux-agent/src/lib.rs::with_restart_backoff *LoctreeDerived*
- `rust:inherent_impl_method` at `vibecrafted-app/mux-agent/src/lib.rs`: vibecrafted-app/mux-agent/src/lib.rs::with_service_name *LoctreeDerived*
- `rust:inherent_impl_method` at `vibecrafted-app/mux-agent/src/lib.rs`: vibecrafted-app/mux-agent/src/lib.rs::with_status_file *LoctreeDerived*
- `rust:inherent_impl_method` at `vibecrafted-app/mux-agent/src/lib.rs`: vibecrafted-app/mux-agent/src/lib.rs::with_tray *LoctreeDerived*
- `entrypoint` at `vibecrafted-app/mux-agent/src/main.rs`: async_main *RepoVerified*
- `entrypoint` at `vibecrafted-app/mux-agent/src/main.rs`: main *RepoVerified*
- `rust:inherent_impl_method` at `vibecrafted-app/mux-agent/src/multi.rs`: vibecrafted-app/mux-agent/src/multi.rs::add_server *LoctreeDerived*
- `rust:inherent_impl_method` at `vibecrafted-app/mux-agent/src/multi.rs`: vibecrafted-app/mux-agent/src/multi.rs::new *LoctreeDerived*
- `rust:inherent_impl_method` at `vibecrafted-app/mux-agent/src/multi_tui.rs`: vibecrafted-app/mux-agent/src/multi_tui.rs::new *LoctreeDerived*
- `rust:inherent_impl_method` at `vibecrafted-app/mux-agent/src/multi_tui.rs`: vibecrafted-app/mux-agent/src/multi_tui.rs::quit *LoctreeDerived*
- `rust:inherent_impl_method` at `vibecrafted-app/mux-agent/src/multi_tui.rs`: vibecrafted-app/mux-agent/src/multi_tui.rs::select_next *LoctreeDerived*
- `rust:inherent_impl_method` at `vibecrafted-app/mux-agent/src/multi_tui.rs`: vibecrafted-app/mux-agent/src/multi_tui.rs::select_previous *LoctreeDerived*
- `rust:inherent_impl_method` at `vibecrafted-app/mux-agent/src/multi_tui.rs`: vibecrafted-app/mux-agent/src/multi_tui.rs::selected_server *LoctreeDerived*
- `rust:inherent_impl_method` at `vibecrafted-app/mux-agent/src/multi_tui.rs`: vibecrafted-app/mux-agent/src/multi_tui.rs::should_quit *LoctreeDerived*
- `rust:inherent_impl_method` at `vibecrafted-app/mux-agent/src/multi_tui.rs`: vibecrafted-app/mux-agent/src/multi_tui.rs::update_statuses *LoctreeDerived*
- `rust:inherent_impl_method` at `vibecrafted-app/mux-agent/src/runtime/heartbeat.rs`: vibecrafted-app/mux-agent/src/runtime/heartbeat.rs::disabled *LoctreeDerived*
- `rust:inherent_impl_method` at `vibecrafted-app/mux-agent/src/runtime/heartbeat.rs`: vibecrafted-app/mux-agent/src/runtime/heartbeat.rs::new *LoctreeDerived*
- `rust:pub_use_reexport` at `vibecrafted-app/mux-agent/src/runtime/mod.rs`: vibecrafted-app/mux-agent/src/runtime/mod.rs::DEFAULT_STATUS_SOCKET *LoctreeDerived*
- `rust:pub_use_reexport` at `vibecrafted-app/mux-agent/src/runtime/mod.rs`: vibecrafted-app/mux-agent/src/runtime/mod.rs::DaemonStatus *LoctreeDerived*
- `rust:pub_use_reexport` at `vibecrafted-app/mux-agent/src/runtime/mod.rs`: vibecrafted-app/mux-agent/src/runtime/mod.rs::HeartbeatConfig *LoctreeDerived*
- `rust:pub_use_reexport` at `vibecrafted-app/mux-agent/src/runtime/mod.rs`: vibecrafted-app/mux-agent/src/runtime/mod.rs::HeartbeatEvent *LoctreeDerived*
- `rust:pub_use_reexport` at `vibecrafted-app/mux-agent/src/runtime/mod.rs`: vibecrafted-app/mux-agent/src/runtime/mod.rs::HeartbeatInspectorContext *LoctreeDerived*
- `rust:pub_use_reexport` at `vibecrafted-app/mux-agent/src/runtime/mod.rs`: vibecrafted-app/mux-agent/src/runtime/mod.rs::MAX_PENDING *LoctreeDerived*
- `rust:pub_use_reexport` at `vibecrafted-app/mux-agent/src/runtime/mod.rs`: vibecrafted-app/mux-agent/src/runtime/mod.rs::MAX_QUEUE *LoctreeDerived*
- `rust:pub_use_reexport` at `vibecrafted-app/mux-agent/src/runtime/mod.rs`: vibecrafted-app/mux-agent/src/runtime/mod.rs::ServerRef *LoctreeDerived*
- `rust:pub_use_reexport` at `vibecrafted-app/mux-agent/src/runtime/mod.rs`: vibecrafted-app/mux-agent/src/runtime/mod.rs::StatusState *LoctreeDerived*
- `rust:pub_use_reexport` at `vibecrafted-app/mux-agent/src/runtime/mod.rs`: vibecrafted-app/mux-agent/src/runtime/mod.rs::is_heartbeat_response *LoctreeDerived*
- `rust:pub_use_reexport` at `vibecrafted-app/mux-agent/src/runtime/mod.rs`: vibecrafted-app/mux-agent/src/runtime/mod.rs::print_status_table *LoctreeDerived*
- `rust:pub_use_reexport` at `vibecrafted-app/mux-agent/src/runtime/mod.rs`: vibecrafted-app/mux-agent/src/runtime/mod.rs::query_status *LoctreeDerived*
- `rust:pub_use_reexport` at `vibecrafted-app/mux-agent/src/runtime/mod.rs`: vibecrafted-app/mux-agent/src/runtime/mod.rs::run_proxy *LoctreeDerived*
- `rust:pub_use_reexport` at `vibecrafted-app/mux-agent/src/runtime/mod.rs`: vibecrafted-app/mux-agent/src/runtime/mod.rs::run_status_listener *LoctreeDerived*
- `rust:pub_use_reexport` at `vibecrafted-app/mux-agent/src/runtime/mod.rs`: vibecrafted-app/mux-agent/src/runtime/mod.rs::spawn_heartbeat_inspector *LoctreeDerived*
- `rust:pub_use_reexport` at `vibecrafted-app/mux-agent/src/runtime/mod.rs`: vibecrafted-app/mux-agent/src/runtime/mod.rs::spawn_status_writer *LoctreeDerived*
- `rust:inherent_impl_method` at `vibecrafted-app/mux-agent/src/runtime/status.rs`: vibecrafted-app/mux-agent/src/runtime/status.rs::collect_status *LoctreeDerived*
- `rust:inherent_impl_method` at `vibecrafted-app/mux-agent/src/runtime/status.rs`: vibecrafted-app/mux-agent/src/runtime/status.rs::new *LoctreeDerived*
- `rust:inherent_impl_method` at `vibecrafted-app/mux-agent/src/runtime/status.rs`: vibecrafted-app/mux-agent/src/runtime/status.rs::register_server *LoctreeDerived*
- `rust:inherent_impl_method` at `vibecrafted-app/mux-agent/src/scan.rs`: vibecrafted-app/mux-agent/src/scan.rs::as_label *LoctreeDerived*
- `rust:inherent_impl_method` at `vibecrafted-app/mux-agent/src/scan.rs`: vibecrafted-app/mux-agent/src/scan.rs::display_name *LoctreeDerived*
- `rust:inherent_impl_method` at `vibecrafted-app/mux-agent/src/scan.rs`: vibecrafted-app/mux-agent/src/scan.rs::into_host_service *LoctreeDerived*
- `rust:inherent_impl_method` at `vibecrafted-app/mux-agent/src/state.rs`: vibecrafted-app/mux-agent/src/state.rs::buffer_message *LoctreeDerived*
- `rust:inherent_impl_method` at `vibecrafted-app/mux-agent/src/state.rs`: vibecrafted-app/mux-agent/src/state.rs::complete_handshake *LoctreeDerived*
- `rust:inherent_impl_method` at `vibecrafted-app/mux-agent/src/state.rs`: vibecrafted-app/mux-agent/src/state.rs::get_handshake_mut *LoctreeDerived*
- `rust:inherent_impl_method` at `vibecrafted-app/mux-agent/src/state.rs`: vibecrafted-app/mux-agent/src/state.rs::is_handshake_complete *LoctreeDerived*
- `rust:inherent_impl_method` at `vibecrafted-app/mux-agent/src/state.rs`: vibecrafted-app/mux-agent/src/state.rs::is_handshake_timed_out *LoctreeDerived*
- `rust:inherent_impl_method` at `vibecrafted-app/mux-agent/src/state.rs`: vibecrafted-app/mux-agent/src/state.rs::mark_handshake_complete *LoctreeDerived*
- `rust:inherent_impl_method` at `vibecrafted-app/mux-agent/src/state.rs`: vibecrafted-app/mux-agent/src/state.rs::new *LoctreeDerived*
- `rust:inherent_impl_method` at `vibecrafted-app/mux-agent/src/state.rs`: vibecrafted-app/mux-agent/src/state.rs::next_request_id *LoctreeDerived*
- `rust:inherent_impl_method` at `vibecrafted-app/mux-agent/src/state.rs`: vibecrafted-app/mux-agent/src/state.rs::register_client *LoctreeDerived*
- `rust:inherent_impl_method` at `vibecrafted-app/mux-agent/src/state.rs`: vibecrafted-app/mux-agent/src/state.rs::unregister_client *LoctreeDerived*
- `rust:inherent_impl_method` at `vibecrafted-app/mux-agent/src/wizard/types.rs`: vibecrafted-app/mux-agent/src/wizard/types.rs::short_label *LoctreeDerived*
- `entrypoint` at `vibecrafted-app/shell-agent/ffi/build.rs`: main *RepoVerified*
- `entrypoint` at `vibecrafted-app/shell-agent/uniffi-bindgen/src/main.rs`: main *RepoVerified*
- `entrypoint` at `vibecrafted-app/tray-agent/src/bin/vc-mux-tray.rs`: main *RepoVerified*
- `rust:pub_use_reexport` at `vibecrafted-app/tray-agent/src/ipc_client.rs`: vibecrafted-app/tray-agent/src/ipc_client.rs::ClientKind *LoctreeDerived*
- `rust:pub_use_reexport` at `vibecrafted-app/tray-agent/src/ipc_client.rs`: vibecrafted-app/tray-agent/src/ipc_client.rs::IpcEvent *LoctreeDerived*
- `rust:pub_use_reexport` at `vibecrafted-app/tray-agent/src/ipc_client.rs`: vibecrafted-app/tray-agent/src/ipc_client.rs::MuxControlCommand *LoctreeDerived*
- `rust:pub_use_reexport` at `vibecrafted-app/tray-agent/src/ipc_client.rs`: vibecrafted-app/tray-agent/src/ipc_client.rs::MuxControlResponse *LoctreeDerived*
- `rust:pub_use_reexport` at `vibecrafted-app/tray-agent/src/lib.rs`: vibecrafted-app/tray-agent/src/lib.rs::MenuIds *LoctreeDerived*
- `rust:pub_use_reexport` at `vibecrafted-app/tray-agent/src/lib.rs`: vibecrafted-app/tray-agent/src/lib.rs::TrayMenuEvent *LoctreeDerived*
- `rust:pub_use_reexport` at `vibecrafted-app/tray-agent/src/lib.rs`: vibecrafted-app/tray-agent/src/lib.rs::TrayStatus *LoctreeDerived*
- `rust:pub_use_reexport` at `vibecrafted-app/tray-agent/src/lib.rs`: vibecrafted-app/tray-agent/src/lib.rs::menu_event_receiver *LoctreeDerived*
- `rust:pub_use_reexport` at `vibecrafted-app/tray-agent/src/lib.rs`: vibecrafted-app/tray-agent/src/lib.rs::send_menu_event *LoctreeDerived*
- `rust:pub_use_reexport` at `vibecrafted-app/tray-agent/src/lib.rs`: vibecrafted-app/tray-agent/src/lib.rs::update_tray_status *LoctreeDerived*
- `rust:inherent_impl_method` at `vibecrafted-app/tray-agent/src/types.rs`: vibecrafted-app/tray-agent/src/types.rs::is_active *LoctreeDerived*
- `rust:inherent_impl_method` at `vibecrafted-app/tray-agent/src/types.rs`: vibecrafted-app/tray-agent/src/types.rs::label *LoctreeDerived*
- `rust:inherent_impl_method` at `vibecrafted-app/tray-agent/src/types.rs`: vibecrafted-app/tray-agent/src/types.rs::menu_label *LoctreeDerived*
- `rust:inherent_impl_method` at `vibecrafted-app/tray-agent/src/types.rs`: vibecrafted-app/tray-agent/src/types.rs::resolve_recent_run *LoctreeDerived*
- `rust:inherent_impl_method` at `vibecrafted-app/tray-agent/src/types.rs`: vibecrafted-app/tray-agent/src/types.rs::resolve_restart_service *LoctreeDerived*
- `rust:inherent_impl_method` at `vibecrafted-app/tray-agent/src/types.rs`: vibecrafted-app/tray-agent/src/types.rs::resolve_verify_client *LoctreeDerived*
- `rust:inherent_impl_method` at `vibecrafted-app/tray-agent/src/types.rs`: vibecrafted-app/tray-agent/src/types.rs::tooltip *LoctreeDerived*
- `rust:inherent_impl_method` at `vibecrafted-app/tui-agent/src/app.rs`: vibecrafted-app/tui-agent/src/app.rs::active_run_count *LoctreeDerived*
- `rust:inherent_impl_method` at `vibecrafted-app/tui-agent/src/app.rs`: vibecrafted-app/tui-agent/src/app.rs::active_tab *LoctreeDerived*
- `rust:inherent_impl_method` at `vibecrafted-app/tui-agent/src/app.rs`: vibecrafted-app/tui-agent/src/app.rs::adjust_dispatch_selection *LoctreeDerived*
- `rust:inherent_impl_method` at `vibecrafted-app/tui-agent/src/app.rs`: vibecrafted-app/tui-agent/src/app.rs::append_status *LoctreeDerived*
- `rust:inherent_impl_method` at `vibecrafted-app/tui-agent/src/app.rs`: vibecrafted-app/tui-agent/src/app.rs::archive_selected_run *LoctreeDerived*
- `rust:inherent_impl_method` at `vibecrafted-app/tui-agent/src/app.rs`: vibecrafted-app/tui-agent/src/app.rs::artifact_lines *LoctreeDerived*
- `rust:inherent_impl_method` at `vibecrafted-app/tui-agent/src/app.rs`: vibecrafted-app/tui-agent/src/app.rs::clear_search *LoctreeDerived*
- `rust:inherent_impl_method` at `vibecrafted-app/tui-agent/src/app.rs`: vibecrafted-app/tui-agent/src/app.rs::clipboard_payload *LoctreeDerived*
- `rust:inherent_impl_method` at `vibecrafted-app/tui-agent/src/app.rs`: vibecrafted-app/tui-agent/src/app.rs::copy_selected_run_to_clipboard *LoctreeDerived*
- `rust:inherent_impl_method` at `vibecrafted-app/tui-agent/src/app.rs`: vibecrafted-app/tui-agent/src/app.rs::cycle_agent *LoctreeDerived*
- `rust:inherent_impl_method` at `vibecrafted-app/tui-agent/src/app.rs`: vibecrafted-app/tui-agent/src/app.rs::cycle_runtime *LoctreeDerived*
- `rust:inherent_impl_method` at `vibecrafted-app/tui-agent/src/app.rs`: vibecrafted-app/tui-agent/src/app.rs::deep_action_index_for_primary_mission_queue_item *LoctreeDerived*
- `rust:inherent_impl_method` at `vibecrafted-app/tui-agent/src/app.rs`: vibecrafted-app/tui-agent/src/app.rs::deep_actions *LoctreeDerived*
- `rust:inherent_impl_method` at `vibecrafted-app/tui-agent/src/app.rs`: vibecrafted-app/tui-agent/src/app.rs::deep_control_lines *LoctreeDerived*
- `rust:inherent_impl_method` at `vibecrafted-app/tui-agent/src/app.rs`: vibecrafted-app/tui-agent/src/app.rs::detail_lines *LoctreeDerived*
- `rust:inherent_impl_method` at `vibecrafted-app/tui-agent/src/app.rs`: vibecrafted-app/tui-agent/src/app.rs::dispatch_focus *LoctreeDerived*
- `rust:inherent_impl_method` at `vibecrafted-app/tui-agent/src/app.rs`: vibecrafted-app/tui-agent/src/app.rs::error_lines *LoctreeDerived*
- `rust:inherent_impl_method` at `vibecrafted-app/tui-agent/src/app.rs`: vibecrafted-app/tui-agent/src/app.rs::event_lines *LoctreeDerived*
- `rust:inherent_impl_method` at `vibecrafted-app/tui-agent/src/app.rs`: vibecrafted-app/tui-agent/src/app.rs::finish_prompt_edit *LoctreeDerived*
- `rust:inherent_impl_method` at `vibecrafted-app/tui-agent/src/app.rs`: vibecrafted-app/tui-agent/src/app.rs::from_index *LoctreeDerived*
- `rust:inherent_impl_method` at `vibecrafted-app/tui-agent/src/app.rs`: vibecrafted-app/tui-agent/src/app.rs::handle_ipc_event *LoctreeDerived*
- `rust:inherent_impl_method` at `vibecrafted-app/tui-agent/src/app.rs`: vibecrafted-app/tui-agent/src/app.rs::help_lines *LoctreeDerived*
- `rust:inherent_impl_method` at `vibecrafted-app/tui-agent/src/app.rs`: vibecrafted-app/tui-agent/src/app.rs::index *LoctreeDerived*
- `rust:inherent_impl_method` at `vibecrafted-app/tui-agent/src/app.rs`: vibecrafted-app/tui-agent/src/app.rs::label *LoctreeDerived*
- `rust:inherent_impl_method` at `vibecrafted-app/tui-agent/src/app.rs`: vibecrafted-app/tui-agent/src/app.rs::launch_command *LoctreeDerived*
- `rust:inherent_impl_method` at `vibecrafted-app/tui-agent/src/app.rs`: vibecrafted-app/tui-agent/src/app.rs::launch_env *LoctreeDerived*
- `rust:inherent_impl_method` at `vibecrafted-app/tui-agent/src/app.rs`: vibecrafted-app/tui-agent/src/app.rs::launch_request *LoctreeDerived*
- `rust:inherent_impl_method` at `vibecrafted-app/tui-agent/src/app.rs`: vibecrafted-app/tui-agent/src/app.rs::move_deep_selection *LoctreeDerived*
- `rust:inherent_impl_method` at `vibecrafted-app/tui-agent/src/app.rs`: vibecrafted-app/tui-agent/src/app.rs::move_dispatch_selection *LoctreeDerived*
- `rust:inherent_impl_method` at `vibecrafted-app/tui-agent/src/app.rs`: vibecrafted-app/tui-agent/src/app.rs::move_mission_focus *LoctreeDerived*
- `rust:inherent_impl_method` at `vibecrafted-app/tui-agent/src/app.rs`: vibecrafted-app/tui-agent/src/app.rs::move_selection *LoctreeDerived*
- `rust:inherent_impl_method` at `vibecrafted-app/tui-agent/src/app.rs`: vibecrafted-app/tui-agent/src/app.rs::mux_status_lines *LoctreeDerived*
- `rust:inherent_impl_method` at `vibecrafted-app/tui-agent/src/app.rs`: vibecrafted-app/tui-agent/src/app.rs::new *LoctreeDerived*
- `rust:inherent_impl_method` at `vibecrafted-app/tui-agent/src/app.rs`: vibecrafted-app/tui-agent/src/app.rs::next *LoctreeDerived*
- `rust:inherent_impl_method` at `vibecrafted-app/tui-agent/src/app.rs`: vibecrafted-app/tui-agent/src/app.rs::next_tab *LoctreeDerived*
- `rust:inherent_impl_method` at `vibecrafted-app/tui-agent/src/app.rs`: vibecrafted-app/tui-agent/src/app.rs::open_artifact *LoctreeDerived*
- `rust:inherent_impl_method` at `vibecrafted-app/tui-agent/src/app.rs`: vibecrafted-app/tui-agent/src/app.rs::open_polarize_intent *LoctreeDerived*
- `rust:inherent_impl_method` at `vibecrafted-app/tui-agent/src/app.rs`: vibecrafted-app/tui-agent/src/app.rs::polarize_status_lines *LoctreeDerived*
- `rust:inherent_impl_method` at `vibecrafted-app/tui-agent/src/app.rs`: vibecrafted-app/tui-agent/src/app.rs::preselect_controls_from_mission_queue *LoctreeDerived*
- `rust:inherent_impl_method` at `vibecrafted-app/tui-agent/src/app.rs`: vibecrafted-app/tui-agent/src/app.rs::previous_tab *LoctreeDerived*
- `rust:inherent_impl_method` at `vibecrafted-app/tui-agent/src/app.rs`: vibecrafted-app/tui-agent/src/app.rs::prompt_edit_lines *LoctreeDerived*
- `rust:inherent_impl_method` at `vibecrafted-app/tui-agent/src/app.rs`: vibecrafted-app/tui-agent/src/app.rs::prompt_lines *LoctreeDerived*
- `rust:inherent_impl_method` at `vibecrafted-app/tui-agent/src/app.rs`: vibecrafted-app/tui-agent/src/app.rs::push_launch_history *LoctreeDerived*
- `rust:inherent_impl_method` at `vibecrafted-app/tui-agent/src/app.rs`: vibecrafted-app/tui-agent/src/app.rs::refresh *LoctreeDerived*
- `rust:inherent_impl_method` at `vibecrafted-app/tui-agent/src/app.rs`: vibecrafted-app/tui-agent/src/app.rs::refresh_mission_control *LoctreeDerived*
- `rust:inherent_impl_method` at `vibecrafted-app/tui-agent/src/app.rs`: vibecrafted-app/tui-agent/src/app.rs::refresh_mux *LoctreeDerived*
- `rust:inherent_impl_method` at `vibecrafted-app/tui-agent/src/app.rs`: vibecrafted-app/tui-agent/src/app.rs::refresh_polarize *LoctreeDerived*
- `rust:inherent_impl_method` at `vibecrafted-app/tui-agent/src/app.rs`: vibecrafted-app/tui-agent/src/app.rs::selected_agent *LoctreeDerived*
- `rust:inherent_impl_method` at `vibecrafted-app/tui-agent/src/app.rs`: vibecrafted-app/tui-agent/src/app.rs::selected_deep_action *LoctreeDerived*
- `rust:inherent_impl_method` at `vibecrafted-app/tui-agent/src/app.rs`: vibecrafted-app/tui-agent/src/app.rs::selected_run *LoctreeDerived*
- `rust:inherent_impl_method` at `vibecrafted-app/tui-agent/src/app.rs`: vibecrafted-app/tui-agent/src/app.rs::set_active_tab *LoctreeDerived*
- `rust:inherent_impl_method` at `vibecrafted-app/tui-agent/src/app.rs`: vibecrafted-app/tui-agent/src/app.rs::set_launch_kind *LoctreeDerived*
- `rust:inherent_impl_method` at `vibecrafted-app/tui-agent/src/app.rs`: vibecrafted-app/tui-agent/src/app.rs::set_search_query *LoctreeDerived*
- `rust:inherent_impl_method` at `vibecrafted-app/tui-agent/src/app.rs`: vibecrafted-app/tui-agent/src/app.rs::shift_agent *LoctreeDerived*
- `rust:inherent_impl_method` at `vibecrafted-app/tui-agent/src/app.rs`: vibecrafted-app/tui-agent/src/app.rs::shift_launch_kind *LoctreeDerived*
- `rust:inherent_impl_method` at `vibecrafted-app/tui-agent/src/app.rs`: vibecrafted-app/tui-agent/src/app.rs::shift_runtime *LoctreeDerived*
- `rust:inherent_impl_method` at `vibecrafted-app/tui-agent/src/app.rs`: vibecrafted-app/tui-agent/src/app.rs::show_error *LoctreeDerived*
- `rust:inherent_impl_method` at `vibecrafted-app/tui-agent/src/app.rs`: vibecrafted-app/tui-agent/src/app.rs::status_summary *LoctreeDerived*
- `rust:inherent_impl_method` at `vibecrafted-app/tui-agent/src/app.rs`: vibecrafted-app/tui-agent/src/app.rs::sync_selection *LoctreeDerived*
- `rust:inherent_impl_method` at `vibecrafted-app/tui-agent/src/app.rs`: vibecrafted-app/tui-agent/src/app.rs::tab_labels *LoctreeDerived*
- `rust:inherent_impl_method` at `vibecrafted-app/tui-agent/src/app.rs`: vibecrafted-app/tui-agent/src/app.rs::title *LoctreeDerived*
- `rust:inherent_impl_method` at `vibecrafted-app/tui-agent/src/app.rs`: vibecrafted-app/tui-agent/src/app.rs::toggle_filter *LoctreeDerived*
- `entrypoint` at `vibecrafted-app/tui-agent/src/bin/vc_admin.rs`: main *RepoVerified*
- `rust:inherent_impl_method` at `vibecrafted-app/tui-agent/src/launch.rs`: vibecrafted-app/tui-agent/src/launch.rs::command_line *LoctreeDerived*
- `rust:inherent_impl_method` at `vibecrafted-app/tui-agent/src/launch.rs`: vibecrafted-app/tui-agent/src/launch.rs::cycle *LoctreeDerived*
- `rust:inherent_impl_method` at `vibecrafted-app/tui-agent/src/launch.rs`: vibecrafted-app/tui-agent/src/launch.rs::human_description *LoctreeDerived*
- `rust:inherent_impl_method` at `vibecrafted-app/tui-agent/src/launch.rs`: vibecrafted-app/tui-agent/src/launch.rs::human_title *LoctreeDerived*
- `rust:inherent_impl_method` at `vibecrafted-app/tui-agent/src/launch.rs`: vibecrafted-app/tui-agent/src/launch.rs::is_session_visible *LoctreeDerived*
- `rust:inherent_impl_method` at `vibecrafted-app/tui-agent/src/launch.rs`: vibecrafted-app/tui-agent/src/launch.rs::label *LoctreeDerived*
- `rust:inherent_impl_method` at `vibecrafted-app/tui-agent/src/launch.rs`: vibecrafted-app/tui-agent/src/launch.rs::readiness_probe *LoctreeDerived*
- `rust:inherent_impl_method` at `vibecrafted-app/tui-agent/src/launch.rs`: vibecrafted-app/tui-agent/src/launch.rs::spawn *LoctreeDerived*
- `rust:inherent_impl_method` at `vibecrafted-app/tui-agent/src/launch.rs`: vibecrafted-app/tui-agent/src/launch.rs::spawn_detached *LoctreeDerived*
- `rust:inherent_impl_method` at `vibecrafted-app/tui-agent/src/launch.rs`: vibecrafted-app/tui-agent/src/launch.rs::spawn_interactive_with_stderr *LoctreeDerived*
- `rust:pub_use_reexport` at `vibecrafted-app/tui-agent/src/lib.rs`: vibecrafted-app/tui-agent/src/lib.rs::ActionPriority *LoctreeDerived*
- `rust:pub_use_reexport` at `vibecrafted-app/tui-agent/src/lib.rs`: vibecrafted-app/tui-agent/src/lib.rs::ActionQueueItem *LoctreeDerived*
- `rust:pub_use_reexport` at `vibecrafted-app/tui-agent/src/lib.rs`: vibecrafted-app/tui-agent/src/lib.rs::ActionQueueKind *LoctreeDerived*
- `rust:pub_use_reexport` at `vibecrafted-app/tui-agent/src/lib.rs`: vibecrafted-app/tui-agent/src/lib.rs::ActiveDispatch *LoctreeDerived*
- `rust:pub_use_reexport` at `vibecrafted-app/tui-agent/src/lib.rs`: vibecrafted-app/tui-agent/src/lib.rs::AgentStatsRow *LoctreeDerived*
- `rust:pub_use_reexport` at `vibecrafted-app/tui-agent/src/lib.rs`: vibecrafted-app/tui-agent/src/lib.rs::App *LoctreeDerived*
- `rust:pub_use_reexport` at `vibecrafted-app/tui-agent/src/lib.rs`: vibecrafted-app/tui-agent/src/lib.rs::AppConfig *LoctreeDerived*
- `rust:pub_use_reexport` at `vibecrafted-app/tui-agent/src/lib.rs`: vibecrafted-app/tui-agent/src/lib.rs::AppTab *LoctreeDerived*
- `rust:pub_use_reexport` at `vibecrafted-app/tui-agent/src/lib.rs`: vibecrafted-app/tui-agent/src/lib.rs::CliOptions *LoctreeDerived*
- `rust:pub_use_reexport` at `vibecrafted-app/tui-agent/src/lib.rs`: vibecrafted-app/tui-agent/src/lib.rs::DataQuality *LoctreeDerived*
- `rust:pub_use_reexport` at `vibecrafted-app/tui-agent/src/lib.rs`: vibecrafted-app/tui-agent/src/lib.rs::DeepAction *LoctreeDerived*
- `rust:pub_use_reexport` at `vibecrafted-app/tui-agent/src/lib.rs`: vibecrafted-app/tui-agent/src/lib.rs::DispatchFocus *LoctreeDerived*
- `rust:pub_use_reexport` at `vibecrafted-app/tui-agent/src/lib.rs`: vibecrafted-app/tui-agent/src/lib.rs::FailureEntry *LoctreeDerived*
- `rust:pub_use_reexport` at `vibecrafted-app/tui-agent/src/lib.rs`: vibecrafted-app/tui-agent/src/lib.rs::FleetHealthSignal *LoctreeDerived*
- `rust:pub_use_reexport` at `vibecrafted-app/tui-agent/src/lib.rs`: vibecrafted-app/tui-agent/src/lib.rs::FleetHealthStatus *LoctreeDerived*
- `rust:pub_use_reexport` at `vibecrafted-app/tui-agent/src/lib.rs`: vibecrafted-app/tui-agent/src/lib.rs::LaunchCommand *LoctreeDerived*
- `rust:pub_use_reexport` at `vibecrafted-app/tui-agent/src/lib.rs`: vibecrafted-app/tui-agent/src/lib.rs::LaunchFocus *LoctreeDerived*
- `rust:pub_use_reexport` at `vibecrafted-app/tui-agent/src/lib.rs`: vibecrafted-app/tui-agent/src/lib.rs::LaunchKind *LoctreeDerived*
- `rust:pub_use_reexport` at `vibecrafted-app/tui-agent/src/lib.rs`: vibecrafted-app/tui-agent/src/lib.rs::MissionControlState *LoctreeDerived*
- `rust:pub_use_reexport` at `vibecrafted-app/tui-agent/src/lib.rs`: vibecrafted-app/tui-agent/src/lib.rs::PolarizeBand *LoctreeDerived*
- `rust:pub_use_reexport` at `vibecrafted-app/tui-agent/src/lib.rs`: vibecrafted-app/tui-agent/src/lib.rs::PolarizeIntent *LoctreeDerived*
- `rust:pub_use_reexport` at `vibecrafted-app/tui-agent/src/lib.rs`: vibecrafted-app/tui-agent/src/lib.rs::QueueScope *LoctreeDerived*
- `rust:pub_use_reexport` at `vibecrafted-app/tui-agent/src/lib.rs`: vibecrafted-app/tui-agent/src/lib.rs::SkillAgent *LoctreeDerived*
- `rust:pub_use_reexport` at `vibecrafted-app/tui-agent/src/lib.rs`: vibecrafted-app/tui-agent/src/lib.rs::SkillEntry *LoctreeDerived*
- `rust:pub_use_reexport` at `vibecrafted-app/tui-agent/src/lib.rs`: vibecrafted-app/tui-agent/src/lib.rs::SkillPayload *LoctreeDerived*
- `rust:pub_use_reexport` at `vibecrafted-app/tui-agent/src/lib.rs`: vibecrafted-app/tui-agent/src/lib.rs::SkillPayloadKind *LoctreeDerived*
- `rust:pub_use_reexport` at `vibecrafted-app/tui-agent/src/lib.rs`: vibecrafted-app/tui-agent/src/lib.rs::SkillStatsRow *LoctreeDerived*
- `rust:pub_use_reexport` at `vibecrafted-app/tui-agent/src/lib.rs`: vibecrafted-app/tui-agent/src/lib.rs::WaveSegment *LoctreeDerived*
- `rust:pub_use_reexport` at `vibecrafted-app/tui-agent/src/lib.rs`: vibecrafted-app/tui-agent/src/lib.rs::WaveState *LoctreeDerived*
- `rust:pub_use_reexport` at `vibecrafted-app/tui-agent/src/lib.rs`: vibecrafted-app/tui-agent/src/lib.rs::build_config *LoctreeDerived*
- `rust:pub_use_reexport` at `vibecrafted-app/tui-agent/src/lib.rs`: vibecrafted-app/tui-agent/src/lib.rs::default_artifact_root *LoctreeDerived*
- `rust:inherent_impl_method` at `vibecrafted-app/tui-agent/src/lib.rs`: vibecrafted-app/tui-agent/src/lib.rs::detail_lines *LoctreeDerived*
- `rust:pub_use_reexport` at `vibecrafted-app/tui-agent/src/lib.rs`: vibecrafted-app/tui-agent/src/lib.rs::parse_args *LoctreeDerived*
- `entrypoint` at `vibecrafted-app/tui-agent/src/main.rs`: main *RepoVerified*
- `rust:inherent_impl_method` at `vibecrafted-app/tui-agent/src/mission_control.rs`: vibecrafted-app/tui-agent/src/mission_control.rs::build *LoctreeDerived*
- `rust:inherent_impl_method` at `vibecrafted-app/tui-agent/src/mission_control.rs`: vibecrafted-app/tui-agent/src/mission_control.rs::build_at *LoctreeDerived*
- `rust:inherent_impl_method` at `vibecrafted-app/tui-agent/src/mission_control.rs`: vibecrafted-app/tui-agent/src/mission_control.rs::build_at_for_root *LoctreeDerived*
- `rust:inherent_impl_method` at `vibecrafted-app/tui-agent/src/mission_control.rs`: vibecrafted-app/tui-agent/src/mission_control.rs::build_at_with_intents *LoctreeDerived*
- `rust:inherent_impl_method` at `vibecrafted-app/tui-agent/src/mission_control.rs`: vibecrafted-app/tui-agent/src/mission_control.rs::build_with_intents *LoctreeDerived*
- `rust:inherent_impl_method` at `vibecrafted-app/tui-agent/src/mission_control.rs`: vibecrafted-app/tui-agent/src/mission_control.rs::glyph *LoctreeDerived*
- `rust:inherent_impl_method` at `vibecrafted-app/tui-agent/src/mission_control.rs`: vibecrafted-app/tui-agent/src/mission_control.rs::is_empty *LoctreeDerived*
- `rust:inherent_impl_method` at `vibecrafted-app/tui-agent/src/mission_control.rs`: vibecrafted-app/tui-agent/src/mission_control.rs::label *LoctreeDerived*
- `rust:inherent_impl_method` at `vibecrafted-app/tui-agent/src/mission_control.rs`: vibecrafted-app/tui-agent/src/mission_control.rs::marker *LoctreeDerived*
- `rust:inherent_impl_method` at `vibecrafted-app/tui-agent/src/mission_control.rs`: vibecrafted-app/tui-agent/src/mission_control.rs::total_entries *LoctreeDerived*
- `rust:inherent_impl_method` at `vibecrafted-app/tui-agent/src/mux.rs`: vibecrafted-app/tui-agent/src/mux.rs::failure_reason *LoctreeDerived*
- `rust:inherent_impl_method` at `vibecrafted-app/tui-agent/src/mux.rs`: vibecrafted-app/tui-agent/src/mux.rs::from_json *LoctreeDerived*
- `rust:inherent_impl_method` at `vibecrafted-app/tui-agent/src/mux.rs`: vibecrafted-app/tui-agent/src/mux.rs::from_path_and_result *LoctreeDerived*
- `rust:inherent_impl_method` at `vibecrafted-app/tui-agent/src/mux.rs`: vibecrafted-app/tui-agent/src/mux.rs::is_healthy *LoctreeDerived*
- `rust:inherent_impl_method` at `vibecrafted-app/tui-agent/src/mux.rs`: vibecrafted-app/tui-agent/src/mux.rs::label *LoctreeDerived*
- `rust:inherent_impl_method` at `vibecrafted-app/tui-agent/src/mux.rs`: vibecrafted-app/tui-agent/src/mux.rs::read *LoctreeDerived*
- `rust:inherent_impl_method` at `vibecrafted-app/tui-agent/src/mux.rs`: vibecrafted-app/tui-agent/src/mux.rs::start *LoctreeDerived*
- `rust:inherent_impl_method` at `vibecrafted-app/tui-agent/src/mux.rs`: vibecrafted-app/tui-agent/src/mux.rs::summary_line *LoctreeDerived*
- `rust:inherent_impl_method` at `vibecrafted-app/tui-agent/src/polarize.rs`: vibecrafted-app/tui-agent/src/polarize.rs::from_score *LoctreeDerived*
- `rust:inherent_impl_method` at `vibecrafted-app/tui-agent/src/polarize.rs`: vibecrafted-app/tui-agent/src/polarize.rs::label *LoctreeDerived*
- `rust:inherent_impl_method` at `vibecrafted-app/tui-agent/src/polarize.rs`: vibecrafted-app/tui-agent/src/polarize.rs::recommended_action *LoctreeDerived*
- `rust:inherent_impl_method` at `vibecrafted-app/tui-agent/src/polarize.rs`: vibecrafted-app/tui-agent/src/polarize.rs::summary_line *LoctreeDerived*
- `rust:inherent_impl_method` at `vibecrafted-app/tui-agent/src/skills_catalog.rs`: vibecrafted-app/tui-agent/src/skills_catalog.rs::command_token *LoctreeDerived*
- `rust:inherent_impl_method` at `vibecrafted-app/tui-agent/src/skills_catalog.rs`: vibecrafted-app/tui-agent/src/skills_catalog.rs::emphasized *LoctreeDerived*
- `rust:inherent_impl_method` at `vibecrafted-app/tui-agent/src/skills_catalog.rs`: vibecrafted-app/tui-agent/src/skills_catalog.rs::from_cli_token *LoctreeDerived*
- `rust:inherent_impl_method` at `vibecrafted-app/tui-agent/src/skills_catalog.rs`: vibecrafted-app/tui-agent/src/skills_catalog.rs::label *LoctreeDerived*
- `rust:inherent_impl_method` at `vibecrafted-app/tui-agent/src/skills_catalog.rs`: vibecrafted-app/tui-agent/src/skills_catalog.rs::resolved_cli_token *LoctreeDerived*
- `rust:inherent_impl_method` at `vibecrafted-app/tui-agent/src/state.rs`: vibecrafted-app/tui-agent/src/state.rs::display_state *LoctreeDerived*
- `rust:inherent_impl_method` at `vibecrafted-app/tui-agent/src/state.rs`: vibecrafted-app/tui-agent/src/state.rs::empty *LoctreeDerived*
- `rust:inherent_impl_method` at `vibecrafted-app/tui-agent/src/state.rs`: vibecrafted-app/tui-agent/src/state.rs::label *LoctreeDerived*
- `rust:inherent_impl_method` at `vibecrafted-app/tui-agent/src/state.rs`: vibecrafted-app/tui-agent/src/state.rs::load *LoctreeDerived*
- `rust:inherent_impl_method` at `vibecrafted-app/tui-agent/src/state.rs`: vibecrafted-app/tui-agent/src/state.rs::sort_rank *LoctreeDerived*

## Risk Slice

- Cache Scope: `Scoped("916a9cd2b34c")` *RepoVerified*
- Snapshot Health: `scoped`
- Stale Snapshot: false
- Dirty Worktree: true

### Hotspots

| File | Importers | Authority |
|---|---|---|
| `vibecrafted-app/mux-agent/src/config.rs` | 13 | *LoctreeDerived* |
| `vibecrafted-app/mux-agent/src/state.rs` | 12 | *LoctreeDerived* |
| `vibecrafted-app/mux-agent/src/scan.rs` | 10 | *LoctreeDerived* |
| `vibecrafted-app/tray-agent/src/types.rs` | 8 | *LoctreeDerived* |
| `vibecrafted-app/tui-agent/src/app.rs` | 7 | *LoctreeDerived* |
| `vibecrafted-app/tui-agent/src/state.rs` | 7 | *LoctreeDerived* |
| `vibecrafted-app/mux-agent/src/ipc/event.rs` | 6 | *LoctreeDerived* |
| `vibecrafted-app/tui-agent/src/launch.rs` | 6 | *LoctreeDerived* |
| `vibecrafted-app/tui-agent/src/mission_control.rs` | 5 | *LoctreeDerived* |
| `vibecrafted-app/tui-agent/src/polarize.rs` | 5 | *LoctreeDerived* |
| `vibecrafted-app/mux-agent/src/tray.rs` | 4 | *LoctreeDerived* |
| `vibecrafted-app/shell-agent/app/Vibecrafted/Bridge/vibecrafted_shell_ffi.swift` | 4 | *LoctreeDerived* |
| `vibecrafted-app/shell-agent/app/Vibecrafted/Views/SidebarViewController.swift` | 4 | *LoctreeDerived* |
| `vibecrafted-app/tui-agent/src/mux.rs` | 4 | *LoctreeDerived* |
| `vibecrafted-app/tui-agent/src/skills_catalog.rs` | 4 | *LoctreeDerived* |
| `vibecrafted-app/mux-agent/src/danger.rs` | 3 | *LoctreeDerived* |
| `vibecrafted-app/mux-agent/src/ipc/command.rs` | 3 | *LoctreeDerived* |
| `vibecrafted-app/mux-agent/src/ipc/context.rs` | 3 | *LoctreeDerived* |
| `vibecrafted-app/mux-agent/src/multi.rs` | 3 | *LoctreeDerived* |
| `vibecrafted-app/mux-agent/src/mux_gen.rs` | 3 | *LoctreeDerived* |
| `vibecrafted-app/mux-agent/src/runtime/mod.rs` | 3 | *LoctreeDerived* |
| `vibecrafted-app/shell-agent/app/Vibecrafted/Views/CanvasViewController.swift` | 3 | *LoctreeDerived* |
| `vibecrafted-app/shell-agent/app/Vibecrafted/main.swift` | 3 | *LoctreeDerived* |
| `vibecrafted-app/shell-agent/ffi/src/lib.rs` | 3 | *LoctreeDerived* |
| `vibecrafted-app/tray-agent/src/ipc_client.rs` | 3 | *LoctreeDerived* |
| `vibecrafted-app/tray-agent/src/state.rs` | 3 | *LoctreeDerived* |
| `vibecrafted-app/mux-agent/src/ipc/handlers.rs` | 2 | *LoctreeDerived* |
| `vibecrafted-app/mux-agent/src/wizard/mod.rs` | 2 | *LoctreeDerived* |
| `vibecrafted-app/shell-agent/app/Vibecrafted/AppDelegate.swift` | 2 | *LoctreeDerived* |
| `vibecrafted-app/shell-agent/app/Vibecrafted/Views/MainWindowController.swift` | 2 | *LoctreeDerived* |
| `vibecrafted-app/tui-agent/src/config.rs` | 2 | *LoctreeDerived* |
| `vibecrafted-app/mux-agent/src/ipc/mod.rs` | 1 | *LoctreeDerived* |
| `vibecrafted-app/mux-agent/src/ipc/server.rs` | 1 | *LoctreeDerived* |
| `vibecrafted-app/mux-agent/src/jsonl_bridge.rs` | 1 | *LoctreeDerived* |
| `vibecrafted-app/mux-agent/src/multi_tui.rs` | 1 | *LoctreeDerived* |
| `vibecrafted-app/mux-agent/src/runtime/client.rs` | 1 | *LoctreeDerived* |
| `vibecrafted-app/mux-agent/src/runtime/heartbeat.rs` | 1 | *LoctreeDerived* |
| `vibecrafted-app/mux-agent/src/runtime/proxy.rs` | 1 | *LoctreeDerived* |
| `vibecrafted-app/mux-agent/src/runtime/server.rs` | 1 | *LoctreeDerived* |
| `vibecrafted-app/mux-agent/src/runtime/status.rs` | 1 | *LoctreeDerived* |
| `vibecrafted-app/mux-agent/src/runtime/types.rs` | 1 | *LoctreeDerived* |
| `vibecrafted-app/mux-agent/src/tray_dashboard.rs` | 1 | *LoctreeDerived* |
| `vibecrafted-app/mux-agent/src/wizard/keys.rs` | 1 | *LoctreeDerived* |
| `vibecrafted-app/mux-agent/src/wizard/persist.rs` | 1 | *LoctreeDerived* |
| `vibecrafted-app/mux-agent/src/wizard/services.rs` | 1 | *LoctreeDerived* |
| `vibecrafted-app/mux-agent/src/wizard/types.rs` | 1 | *LoctreeDerived* |
| `vibecrafted-app/mux-agent/src/wizard/ui.rs` | 1 | *LoctreeDerived* |
| `vibecrafted-app/shell-agent/app/Vibecrafted/Views/InspectorViewController.swift` | 1 | *LoctreeDerived* |
| `vibecrafted-app/shell-agent/app/Vibecrafted/Views/MainSplitViewController.swift` | 1 | *LoctreeDerived* |
| `vibecrafted-app/tray-agent/src/handlers.rs` | 1 | *LoctreeDerived* |
| `vibecrafted-app/tray-agent/src/icons.rs` | 1 | *LoctreeDerived* |
| `vibecrafted-app/tray-agent/src/lib.rs` | 1 | *LoctreeDerived* |
| `vibecrafted-app/tray-agent/src/menu.rs` | 1 | *LoctreeDerived* |
| `vibecrafted-app/tui-agent/src/ui.rs` | 1 | *LoctreeDerived* |

### High Fan-In

| File | Importers | Authority |
|---|---|---|
| `vibecrafted-app/mux-agent/src/config.rs` | 13 | *LoctreeDerived* |
| `vibecrafted-app/mux-agent/src/state.rs` | 12 | *LoctreeDerived* |
| `vibecrafted-app/mux-agent/src/scan.rs` | 10 | *LoctreeDerived* |

## Action Slice

### Power Path

- `loct slice vibecrafted-app/AGENTS.md`: Slice this file to inspect its direct dependencies and immediate consumers before editing.
- `loct follow`: Pursue unified structural signals (dead exports, import cycles, twins) to ensure health.
- `loct slice vibecrafted-app/Cargo.toml`: Slice this file to inspect its direct dependencies and immediate consumers before editing.
- `loct slice vibecrafted-app/Makefile`: Slice this file to inspect its direct dependencies and immediate consumers before editing.
- `loct body .PHONY`: View the definition body of symbol '.PHONY' to understand its implementation structure.
- `loct find --literal .PHONY`: Execute a literal exact-identifier scan for '.PHONY' to find exact matches across the codebase.
- `loct occurrences .PHONY`: Perform a literal boundary-sensitive occurrences scan for '.PHONY' to locate all references.
- `loct slice vibecrafted-app/README.md`: Slice this file to inspect its direct dependencies and immediate consumers before editing.
- `loct slice vibecrafted-app/docs/plans/PLAN_22_NEXT_OPERATOR_MISSION_CONTROL.md`: Slice this file to inspect its direct dependencies and immediate consumers before editing.
- `loct slice vibecrafted-app/docs/plans/PLAN_23_AGENT_OPERATOR_DASHBOARD.md`: Slice this file to inspect its direct dependencies and immediate consumers before editing.
- `loct slice vibecrafted-app/mux-agent/AI_README.md`: Slice this file to inspect its direct dependencies and immediate consumers before editing.
- `loct slice vibecrafted-app/mux-agent/CHANGELOG.md`: Slice this file to inspect its direct dependencies and immediate consumers before editing.
- `loct slice vibecrafted-app/mux-agent/Cargo.toml`: Slice this file to inspect its direct dependencies and immediate consumers before editing.
- `loct slice vibecrafted-app/mux-agent/Makefile`: Slice this file to inspect its direct dependencies and immediate consumers before editing.
- `loct body SHELL`: View the definition body of symbol 'SHELL' to understand its implementation structure.
- `loct find --literal SHELL`: Execute a literal exact-identifier scan for 'SHELL' to find exact matches across the codebase.
- `loct occurrences SHELL`: Perform a literal boundary-sensitive occurrences scan for 'SHELL' to locate all references.
- `loct slice vibecrafted-app/mux-agent/README.md`: Slice this file to inspect its direct dependencies and immediate consumers before editing.
- `loct slice vibecrafted-app/mux-agent/docs/WIZARD.md`: Slice this file to inspect its direct dependencies and immediate consumers before editing.
- `loct slice vibecrafted-app/mux-agent/docs/dev/guidelines.md`: Slice this file to inspect its direct dependencies and immediate consumers before editing.
- `loct slice vibecrafted-app/mux-agent/docs/integration.md`: Slice this file to inspect its direct dependencies and immediate consumers before editing.
- `loct slice vibecrafted-app/mux-agent/docs/vc-agents-client-discovery-plan.md`: Slice this file to inspect its direct dependencies and immediate consumers before editing.
- `loct slice vibecrafted-app/mux-agent/src/bin/rmcp-mux-proxy.rs`: Slice this file to inspect its direct dependencies and immediate consumers before editing.
- `loct slice vibecrafted-app/mux-agent/src/bin/rmcp-mux.rs`: Slice this file to inspect its direct dependencies and immediate consumers before editing.
- `loct slice vibecrafted-app/mux-agent/src/config.rs`: Slice this file to inspect its direct dependencies and immediate consumers before editing.
- `loct impact vibecrafted-app/mux-agent/src/config.rs`: Assess the transitive blast radius and downstream consumers of this file before modifying.
- `loct body expand_path`: View the definition body of symbol 'expand_path' to understand its implementation structure.
- `loct find --literal expand_path`: Execute a literal exact-identifier scan for 'expand_path' to find exact matches across the codebase.
- `loct occurrences expand_path`: Perform a literal boundary-sensitive occurrences scan for 'expand_path' to locate all references.
- `loct slice vibecrafted-app/mux-agent/src/danger.rs`: Slice this file to inspect its direct dependencies and immediate consumers before editing.
- `loct impact vibecrafted-app/mux-agent/src/danger.rs`: Assess the transitive blast radius and downstream consumers of this file before modifying.
- `loct body plan_danger_rewrite`: View the definition body of symbol 'plan_danger_rewrite' to understand its implementation structure.
- `loct find --literal plan_danger_rewrite`: Execute a literal exact-identifier scan for 'plan_danger_rewrite' to find exact matches across the codebase.
- `loct occurrences plan_danger_rewrite`: Perform a literal boundary-sensitive occurrences scan for 'plan_danger_rewrite' to locate all references.
- `loct slice vibecrafted-app/mux-agent/src/ipc/command.rs`: Slice this file to inspect its direct dependencies and immediate consumers before editing.
- `loct impact vibecrafted-app/mux-agent/src/ipc/command.rs`: Assess the transitive blast radius and downstream consumers of this file before modifying.
- `loct body VerifyResult`: View the definition body of symbol 'VerifyResult' to understand its implementation structure.
- `loct find --literal VerifyResult`: Execute a literal exact-identifier scan for 'VerifyResult' to find exact matches across the codebase.
- `loct occurrences VerifyResult`: Perform a literal boundary-sensitive occurrences scan for 'VerifyResult' to locate all references.
- `loct slice vibecrafted-app/mux-agent/src/ipc/context.rs`: Slice this file to inspect its direct dependencies and immediate consumers before editing.
- `loct impact vibecrafted-app/mux-agent/src/ipc/context.rs`: Assess the transitive blast radius and downstream consumers of this file before modifying.
- `loct body new`: View the definition body of symbol 'new' to understand its implementation structure.
- `loct find --literal new`: Execute a literal exact-identifier scan for 'new' to find exact matches across the codebase.
- `loct occurrences new`: Perform a literal boundary-sensitive occurrences scan for 'new' to locate all references.
- `loct slice vibecrafted-app/mux-agent/src/ipc/event.rs`: Slice this file to inspect its direct dependencies and immediate consumers before editing.
- `loct impact vibecrafted-app/mux-agent/src/ipc/event.rs`: Assess the transitive blast radius and downstream consumers of this file before modifying.
- `loct body IpcEvent`: View the definition body of symbol 'IpcEvent' to understand its implementation structure.
- `loct find --literal IpcEvent`: Execute a literal exact-identifier scan for 'IpcEvent' to find exact matches across the codebase.
- `loct occurrences IpcEvent`: Perform a literal boundary-sensitive occurrences scan for 'IpcEvent' to locate all references.
- `loct slice vibecrafted-app/mux-agent/src/ipc/handlers.rs`: Slice this file to inspect its direct dependencies and immediate consumers before editing.
- `loct impact vibecrafted-app/mux-agent/src/ipc/handlers.rs`: Assess the transitive blast radius and downstream consumers of this file before modifying.
- `loct body handle_command`: View the definition body of symbol 'handle_command' to understand its implementation structure.
- `loct find --literal handle_command`: Execute a literal exact-identifier scan for 'handle_command' to find exact matches across the codebase.
- `loct occurrences handle_command`: Perform a literal boundary-sensitive occurrences scan for 'handle_command' to locate all references.
- `loct slice vibecrafted-app/mux-agent/src/ipc/mod.rs`: Slice this file to inspect its direct dependencies and immediate consumers before editing.
- `loct impact vibecrafted-app/mux-agent/src/ipc/mod.rs`: Assess the transitive blast radius and downstream consumers of this file before modifying.
- `loct body ClientKind`: View the definition body of symbol 'ClientKind' to understand its implementation structure.
- `loct find --literal ClientKind`: Execute a literal exact-identifier scan for 'ClientKind' to find exact matches across the codebase.
- `loct occurrences ClientKind`: Perform a literal boundary-sensitive occurrences scan for 'ClientKind' to locate all references.
- `loct slice vibecrafted-app/mux-agent/src/ipc/server.rs`: Slice this file to inspect its direct dependencies and immediate consumers before editing.
- `loct impact vibecrafted-app/mux-agent/src/ipc/server.rs`: Assess the transitive blast radius and downstream consumers of this file before modifying.
- `loct body socket_path`: View the definition body of symbol 'socket_path' to understand its implementation structure.
- `loct find --literal socket_path`: Execute a literal exact-identifier scan for 'socket_path' to find exact matches across the codebase.
- `loct occurrences socket_path`: Perform a literal boundary-sensitive occurrences scan for 'socket_path' to locate all references.
- `loct slice vibecrafted-app/mux-agent/src/jsonl_bridge.rs`: Slice this file to inspect its direct dependencies and immediate consumers before editing.
- `loct impact vibecrafted-app/mux-agent/src/jsonl_bridge.rs`: Assess the transitive blast radius and downstream consumers of this file before modifying.
- `loct body run_jsonl_bridge`: View the definition body of symbol 'run_jsonl_bridge' to understand its implementation structure.
- `loct find --literal run_jsonl_bridge`: Execute a literal exact-identifier scan for 'run_jsonl_bridge' to find exact matches across the codebase.
- `loct occurrences run_jsonl_bridge`: Perform a literal boundary-sensitive occurrences scan for 'run_jsonl_bridge' to locate all references.
- `loct slice vibecrafted-app/mux-agent/src/lib.rs`: Slice this file to inspect its direct dependencies and immediate consumers before editing.
- `loct body CliOptions`: View the definition body of symbol 'CliOptions' to understand its implementation structure.
- `loct find --literal CliOptions`: Execute a literal exact-identifier scan for 'CliOptions' to find exact matches across the codebase.
- `loct occurrences CliOptions`: Perform a literal boundary-sensitive occurrences scan for 'CliOptions' to locate all references.
- `loct slice vibecrafted-app/mux-agent/src/main.rs`: Slice this file to inspect its direct dependencies and immediate consumers before editing.
- `loct slice vibecrafted-app/mux-agent/src/multi.rs`: Slice this file to inspect its direct dependencies and immediate consumers before editing.
- `loct impact vibecrafted-app/mux-agent/src/multi.rs`: Assess the transitive blast radius and downstream consumers of this file before modifying.
- `loct slice vibecrafted-app/mux-agent/src/multi_tui.rs`: Slice this file to inspect its direct dependencies and immediate consumers before editing.
- `loct impact vibecrafted-app/mux-agent/src/multi_tui.rs`: Assess the transitive blast radius and downstream consumers of this file before modifying.
- `loct slice vibecrafted-app/mux-agent/src/mux_gen.rs`: Slice this file to inspect its direct dependencies and immediate consumers before editing.
- `loct impact vibecrafted-app/mux-agent/src/mux_gen.rs`: Assess the transitive blast radius and downstream consumers of this file before modifying.
- `loct body default_mux_dir`: View the definition body of symbol 'default_mux_dir' to understand its implementation structure.
- `loct find --literal default_mux_dir`: Execute a literal exact-identifier scan for 'default_mux_dir' to find exact matches across the codebase.
- `loct occurrences default_mux_dir`: Perform a literal boundary-sensitive occurrences scan for 'default_mux_dir' to locate all references.
- `loct slice vibecrafted-app/mux-agent/src/runtime/client.rs`: Slice this file to inspect its direct dependencies and immediate consumers before editing.
- `loct impact vibecrafted-app/mux-agent/src/runtime/client.rs`: Assess the transitive blast radius and downstream consumers of this file before modifying.
- `loct body update_queue_depth`: View the definition body of symbol 'update_queue_depth' to understand its implementation structure.
- `loct find --literal update_queue_depth`: Execute a literal exact-identifier scan for 'update_queue_depth' to find exact matches across the codebase.
- `loct occurrences update_queue_depth`: Perform a literal boundary-sensitive occurrences scan for 'update_queue_depth' to locate all references.
- `loct slice vibecrafted-app/mux-agent/src/runtime/heartbeat.rs`: Slice this file to inspect its direct dependencies and immediate consumers before editing.
- `loct impact vibecrafted-app/mux-agent/src/runtime/heartbeat.rs`: Assess the transitive blast radius and downstream consumers of this file before modifying.
- `loct slice vibecrafted-app/mux-agent/src/runtime/mod.rs`: Slice this file to inspect its direct dependencies and immediate consumers before editing.
- `loct impact vibecrafted-app/mux-agent/src/runtime/mod.rs`: Assess the transitive blast radius and downstream consumers of this file before modifying.
- `loct body HeartbeatConfig`: View the definition body of symbol 'HeartbeatConfig' to understand its implementation structure.
- `loct find --literal HeartbeatConfig`: Execute a literal exact-identifier scan for 'HeartbeatConfig' to find exact matches across the codebase.
- `loct occurrences HeartbeatConfig`: Perform a literal boundary-sensitive occurrences scan for 'HeartbeatConfig' to locate all references.
- `loct slice vibecrafted-app/mux-agent/src/runtime/proxy.rs`: Slice this file to inspect its direct dependencies and immediate consumers before editing.
- `loct impact vibecrafted-app/mux-agent/src/runtime/proxy.rs`: Assess the transitive blast radius and downstream consumers of this file before modifying.
- `loct body run_proxy`: View the definition body of symbol 'run_proxy' to understand its implementation structure.
- `loct find --literal run_proxy`: Execute a literal exact-identifier scan for 'run_proxy' to find exact matches across the codebase.
- `loct occurrences run_proxy`: Perform a literal boundary-sensitive occurrences scan for 'run_proxy' to locate all references.
- `loct slice vibecrafted-app/mux-agent/src/runtime/server.rs`: Slice this file to inspect its direct dependencies and immediate consumers before editing.
- `loct impact vibecrafted-app/mux-agent/src/runtime/server.rs`: Assess the transitive blast radius and downstream consumers of this file before modifying.
- `loct body handle_server_message`: View the definition body of symbol 'handle_server_message' to understand its implementation structure.
- `loct find --literal handle_server_message`: Execute a literal exact-identifier scan for 'handle_server_message' to find exact matches across the codebase.
- `loct occurrences handle_server_message`: Perform a literal boundary-sensitive occurrences scan for 'handle_server_message' to locate all references.
- `loct slice vibecrafted-app/mux-agent/src/runtime/status.rs`: Slice this file to inspect its direct dependencies and immediate consumers before editing.
- `loct impact vibecrafted-app/mux-agent/src/runtime/status.rs`: Assess the transitive blast radius and downstream consumers of this file before modifying.
- `loct body write_status_file`: View the definition body of symbol 'write_status_file' to understand its implementation structure.
- `loct find --literal write_status_file`: Execute a literal exact-identifier scan for 'write_status_file' to find exact matches across the codebase.
- `loct occurrences write_status_file`: Perform a literal boundary-sensitive occurrences scan for 'write_status_file' to locate all references.
- `loct slice vibecrafted-app/mux-agent/src/runtime/tests.rs`: Slice this file to inspect its direct dependencies and immediate consumers before editing.
- `loct slice vibecrafted-app/mux-agent/src/runtime/types.rs`: Slice this file to inspect its direct dependencies and immediate consumers before editing.
- `loct impact vibecrafted-app/mux-agent/src/runtime/types.rs`: Assess the transitive blast radius and downstream consumers of this file before modifying.
- `loct body ServerEvent`: View the definition body of symbol 'ServerEvent' to understand its implementation structure.
- `loct find --literal ServerEvent`: Execute a literal exact-identifier scan for 'ServerEvent' to find exact matches across the codebase.
- `loct occurrences ServerEvent`: Perform a literal boundary-sensitive occurrences scan for 'ServerEvent' to locate all references.
- `loct slice vibecrafted-app/mux-agent/src/scan.rs`: Slice this file to inspect its direct dependencies and immediate consumers before editing.
- `loct impact vibecrafted-app/mux-agent/src/scan.rs`: Assess the transitive blast radius and downstream consumers of this file before modifying.
- `loct body as_label`: View the definition body of symbol 'as_label' to understand its implementation structure.
- `loct find --literal as_label`: Execute a literal exact-identifier scan for 'as_label' to find exact matches across the codebase.
- `loct occurrences as_label`: Perform a literal boundary-sensitive occurrences scan for 'as_label' to locate all references.
- `loct slice vibecrafted-app/mux-agent/src/state.rs`: Slice this file to inspect its direct dependencies and immediate consumers before editing.
- `loct impact vibecrafted-app/mux-agent/src/state.rs`: Assess the transitive blast radius and downstream consumers of this file before modifying.
- `loct slice vibecrafted-app/mux-agent/src/tray.rs`: Slice this file to inspect its direct dependencies and immediate consumers before editing.
- `loct impact vibecrafted-app/mux-agent/src/tray.rs`: Assess the transitive blast radius and downstream consumers of this file before modifying.
- `loct body spawn_tray`: View the definition body of symbol 'spawn_tray' to understand its implementation structure.
- `loct find --literal spawn_tray`: Execute a literal exact-identifier scan for 'spawn_tray' to find exact matches across the codebase.
- `loct occurrences spawn_tray`: Perform a literal boundary-sensitive occurrences scan for 'spawn_tray' to locate all references.
- `loct slice vibecrafted-app/mux-agent/src/tray_dashboard.rs`: Slice this file to inspect its direct dependencies and immediate consumers before editing.
- `loct impact vibecrafted-app/mux-agent/src/tray_dashboard.rs`: Assess the transitive blast radius and downstream consumers of this file before modifying.
- `loct body run_tray_dashboard`: View the definition body of symbol 'run_tray_dashboard' to understand its implementation structure.
- `loct find --literal run_tray_dashboard`: Execute a literal exact-identifier scan for 'run_tray_dashboard' to find exact matches across the codebase.
- `loct occurrences run_tray_dashboard`: Perform a literal boundary-sensitive occurrences scan for 'run_tray_dashboard' to locate all references.
- `loct slice vibecrafted-app/mux-agent/src/wizard/keys.rs`: Slice this file to inspect its direct dependencies and immediate consumers before editing.
- `loct impact vibecrafted-app/mux-agent/src/wizard/keys.rs`: Assess the transitive blast radius and downstream consumers of this file before modifying.
- `loct body handle_key`: View the definition body of symbol 'handle_key' to understand its implementation structure.
- `loct find --literal handle_key`: Execute a literal exact-identifier scan for 'handle_key' to find exact matches across the codebase.
- `loct occurrences handle_key`: Perform a literal boundary-sensitive occurrences scan for 'handle_key' to locate all references.
- `loct slice vibecrafted-app/mux-agent/src/wizard/mod.rs`: Slice this file to inspect its direct dependencies and immediate consumers before editing.
- `loct impact vibecrafted-app/mux-agent/src/wizard/mod.rs`: Assess the transitive blast radius and downstream consumers of this file before modifying.
- `loct body run_wizard`: View the definition body of symbol 'run_wizard' to understand its implementation structure.
- `loct find --literal run_wizard`: Execute a literal exact-identifier scan for 'run_wizard' to find exact matches across the codebase.
- `loct occurrences run_wizard`: Perform a literal boundary-sensitive occurrences scan for 'run_wizard' to locate all references.
- `loct slice vibecrafted-app/mux-agent/src/wizard/persist.rs`: Slice this file to inspect its direct dependencies and immediate consumers before editing.
- `loct impact vibecrafted-app/mux-agent/src/wizard/persist.rs`: Assess the transitive blast radius and downstream consumers of this file before modifying.
- `loct body run_unified_generate`: View the definition body of symbol 'run_unified_generate' to understand its implementation structure.
- `loct find --literal run_unified_generate`: Execute a literal exact-identifier scan for 'run_unified_generate' to find exact matches across the codebase.
- `loct occurrences run_unified_generate`: Perform a literal boundary-sensitive occurrences scan for 'run_unified_generate' to locate all references.
- `loct slice vibecrafted-app/mux-agent/src/wizard/services.rs`: Slice this file to inspect its direct dependencies and immediate consumers before editing.
- `loct impact vibecrafted-app/mux-agent/src/wizard/services.rs`: Assess the transitive blast radius and downstream consumers of this file before modifying.
- `loct body build_services_from_scans`: View the definition body of symbol 'build_services_from_scans' to understand its implementation structure.
- `loct find --literal build_services_from_scans`: Execute a literal exact-identifier scan for 'build_services_from_scans' to find exact matches across the codebase.
- `loct occurrences build_services_from_scans`: Perform a literal boundary-sensitive occurrences scan for 'build_services_from_scans' to locate all references.
- `loct slice vibecrafted-app/mux-agent/src/wizard/types.rs`: Slice this file to inspect its direct dependencies and immediate consumers before editing.
- `loct impact vibecrafted-app/mux-agent/src/wizard/types.rs`: Assess the transitive blast radius and downstream consumers of this file before modifying.
- `loct body short_label`: View the definition body of symbol 'short_label' to understand its implementation structure.
- `loct find --literal short_label`: Execute a literal exact-identifier scan for 'short_label' to find exact matches across the codebase.
- `loct occurrences short_label`: Perform a literal boundary-sensitive occurrences scan for 'short_label' to locate all references.
- `loct slice vibecrafted-app/mux-agent/src/wizard/ui.rs`: Slice this file to inspect its direct dependencies and immediate consumers before editing.
- `loct impact vibecrafted-app/mux-agent/src/wizard/ui.rs`: Assess the transitive blast radius and downstream consumers of this file before modifying.
- `loct body draw_ui`: View the definition body of symbol 'draw_ui' to understand its implementation structure.
- `loct find --literal draw_ui`: Execute a literal exact-identifier scan for 'draw_ui' to find exact matches across the codebase.
- `loct occurrences draw_ui`: Perform a literal boundary-sensitive occurrences scan for 'draw_ui' to locate all references.
- `loct slice vibecrafted-app/mux-agent/tests/jsonl_bridge_test.rs`: Slice this file to inspect its direct dependencies and immediate consumers before editing.
- `loct slice vibecrafted-app/mux-agent/tools/githooks/pre-commit`: Slice this file to inspect its direct dependencies and immediate consumers before editing.
- `loct slice vibecrafted-app/mux-agent/tools/githooks/pre-push`: Slice this file to inspect its direct dependencies and immediate consumers before editing.
- `loct slice vibecrafted-app/mux-agent/tools/install-githooks.sh`: Slice this file to inspect its direct dependencies and immediate consumers before editing.
- `loct slice vibecrafted-app/mux-agent/tools/install.sh`: Slice this file to inspect its direct dependencies and immediate consumers before editing.
- `loct body info`: View the definition body of symbol 'info' to understand its implementation structure.
- `loct find --literal info`: Execute a literal exact-identifier scan for 'info' to find exact matches across the codebase.
- `loct occurrences info`: Perform a literal boundary-sensitive occurrences scan for 'info' to locate all references.
- `loct slice vibecrafted-app/mux-agent/tools/setup_hooks.sh`: Slice this file to inspect its direct dependencies and immediate consumers before editing.
- `loct slice vibecrafted-app/shell-agent/Makefile`: Slice this file to inspect its direct dependencies and immediate consumers before editing.
- `loct slice vibecrafted-app/shell-agent/app/Vibecrafted/AppDelegate.swift`: Slice this file to inspect its direct dependencies and immediate consumers before editing.
- `loct impact vibecrafted-app/shell-agent/app/Vibecrafted/AppDelegate.swift`: Assess the transitive blast radius and downstream consumers of this file before modifying.
- `loct body EventObserver`: View the definition body of symbol 'EventObserver' to understand its implementation structure.
- `loct find --literal EventObserver`: Execute a literal exact-identifier scan for 'EventObserver' to find exact matches across the codebase.
- `loct occurrences EventObserver`: Perform a literal boundary-sensitive occurrences scan for 'EventObserver' to locate all references.
- `loct slice vibecrafted-app/shell-agent/app/Vibecrafted/Bridge/vibecrafted_shell_ffi.swift`: Slice this file to inspect its direct dependencies and immediate consumers before editing.
- `loct impact vibecrafted-app/shell-agent/app/Vibecrafted/Bridge/vibecrafted_shell_ffi.swift`: Assess the transitive blast radius and downstream consumers of this file before modifying.
- `loct body RustBuffer`: View the definition body of symbol 'RustBuffer' to understand its implementation structure.
- `loct find --literal RustBuffer`: Execute a literal exact-identifier scan for 'RustBuffer' to find exact matches across the codebase.
- `loct occurrences RustBuffer`: Perform a literal boundary-sensitive occurrences scan for 'RustBuffer' to locate all references.
- `loct slice vibecrafted-app/shell-agent/app/Vibecrafted/Views/CanvasViewController.swift`: Slice this file to inspect its direct dependencies and immediate consumers before editing.
- `loct impact vibecrafted-app/shell-agent/app/Vibecrafted/Views/CanvasViewController.swift`: Assess the transitive blast radius and downstream consumers of this file before modifying.
- `loct body CanvasViewController`: View the definition body of symbol 'CanvasViewController' to understand its implementation structure.
- `loct find --literal CanvasViewController`: Execute a literal exact-identifier scan for 'CanvasViewController' to find exact matches across the codebase.
- `loct occurrences CanvasViewController`: Perform a literal boundary-sensitive occurrences scan for 'CanvasViewController' to locate all references.
- `loct slice vibecrafted-app/shell-agent/app/Vibecrafted/Views/InspectorViewController.swift`: Slice this file to inspect its direct dependencies and immediate consumers before editing.
- `loct impact vibecrafted-app/shell-agent/app/Vibecrafted/Views/InspectorViewController.swift`: Assess the transitive blast radius and downstream consumers of this file before modifying.
- `loct body InspectorViewController`: View the definition body of symbol 'InspectorViewController' to understand its implementation structure.
- `loct find --literal InspectorViewController`: Execute a literal exact-identifier scan for 'InspectorViewController' to find exact matches across the codebase.
- `loct occurrences InspectorViewController`: Perform a literal boundary-sensitive occurrences scan for 'InspectorViewController' to locate all references.
- `loct slice vibecrafted-app/shell-agent/app/Vibecrafted/Views/MainSplitViewController.swift`: Slice this file to inspect its direct dependencies and immediate consumers before editing.
- `loct impact vibecrafted-app/shell-agent/app/Vibecrafted/Views/MainSplitViewController.swift`: Assess the transitive blast radius and downstream consumers of this file before modifying.
- `loct body MainSplitViewController`: View the definition body of symbol 'MainSplitViewController' to understand its implementation structure.
- `loct find --literal MainSplitViewController`: Execute a literal exact-identifier scan for 'MainSplitViewController' to find exact matches across the codebase.
- `loct occurrences MainSplitViewController`: Perform a literal boundary-sensitive occurrences scan for 'MainSplitViewController' to locate all references.
- `loct slice vibecrafted-app/shell-agent/app/Vibecrafted/Views/MainWindowController.swift`: Slice this file to inspect its direct dependencies and immediate consumers before editing.
- `loct impact vibecrafted-app/shell-agent/app/Vibecrafted/Views/MainWindowController.swift`: Assess the transitive blast radius and downstream consumers of this file before modifying.
- `loct body MainWindowController`: View the definition body of symbol 'MainWindowController' to understand its implementation structure.
- `loct find --literal MainWindowController`: Execute a literal exact-identifier scan for 'MainWindowController' to find exact matches across the codebase.
- `loct occurrences MainWindowController`: Perform a literal boundary-sensitive occurrences scan for 'MainWindowController' to locate all references.
- `loct slice vibecrafted-app/shell-agent/app/Vibecrafted/Views/SidebarViewController.swift`: Slice this file to inspect its direct dependencies and immediate consumers before editing.
- `loct impact vibecrafted-app/shell-agent/app/Vibecrafted/Views/SidebarViewController.swift`: Assess the transitive blast radius and downstream consumers of this file before modifying.
- `loct body SidebarViewController`: View the definition body of symbol 'SidebarViewController' to understand its implementation structure.
- `loct find --literal SidebarViewController`: Execute a literal exact-identifier scan for 'SidebarViewController' to find exact matches across the codebase.
- `loct occurrences SidebarViewController`: Perform a literal boundary-sensitive occurrences scan for 'SidebarViewController' to locate all references.
- `loct slice vibecrafted-app/shell-agent/app/Vibecrafted/main.swift`: Slice this file to inspect its direct dependencies and immediate consumers before editing.
- `loct impact vibecrafted-app/shell-agent/app/Vibecrafted/main.swift`: Assess the transitive blast radius and downstream consumers of this file before modifying.
- `loct body delegate`: View the definition body of symbol 'delegate' to understand its implementation structure.
- `loct find --literal delegate`: Execute a literal exact-identifier scan for 'delegate' to find exact matches across the codebase.
- `loct occurrences delegate`: Perform a literal boundary-sensitive occurrences scan for 'delegate' to locate all references.
- `loct slice vibecrafted-app/shell-agent/app/project.yml`: Slice this file to inspect its direct dependencies and immediate consumers before editing.
- `loct slice vibecrafted-app/shell-agent/ffi/Cargo.toml`: Slice this file to inspect its direct dependencies and immediate consumers before editing.
- `loct slice vibecrafted-app/shell-agent/ffi/build.rs`: Slice this file to inspect its direct dependencies and immediate consumers before editing.
- `loct slice vibecrafted-app/shell-agent/ffi/src/lib.rs`: Slice this file to inspect its direct dependencies and immediate consumers before editing.
- `loct impact vibecrafted-app/shell-agent/ffi/src/lib.rs`: Assess the transitive blast radius and downstream consumers of this file before modifying.
- `loct body load_mission_control_snapshot`: View the definition body of symbol 'load_mission_control_snapshot' to understand its implementation structure.
- `loct find --literal load_mission_control_snapshot`: Execute a literal exact-identifier scan for 'load_mission_control_snapshot' to find exact matches across the codebase.
- `loct occurrences load_mission_control_snapshot`: Perform a literal boundary-sensitive occurrences scan for 'load_mission_control_snapshot' to locate all references.
- `loct slice vibecrafted-app/shell-agent/scripts/build-dmg.sh`: Slice this file to inspect its direct dependencies and immediate consumers before editing.
- `loct body MACOSX_DEPLOYMENT_TARGET`: View the definition body of symbol 'MACOSX_DEPLOYMENT_TARGET' to understand its implementation structure.
- `loct find --literal MACOSX_DEPLOYMENT_TARGET`: Execute a literal exact-identifier scan for 'MACOSX_DEPLOYMENT_TARGET' to find exact matches across the codebase.
- `loct occurrences MACOSX_DEPLOYMENT_TARGET`: Perform a literal boundary-sensitive occurrences scan for 'MACOSX_DEPLOYMENT_TARGET' to locate all references.
- `loct slice vibecrafted-app/shell-agent/scripts/build-rust-binaries.sh`: Slice this file to inspect its direct dependencies and immediate consumers before editing.
- `loct slice vibecrafted-app/shell-agent/scripts/build-rust.sh`: Slice this file to inspect its direct dependencies and immediate consumers before editing.
- `loct slice vibecrafted-app/shell-agent/scripts/fix-dylib-install-names.sh`: Slice this file to inspect its direct dependencies and immediate consumers before editing.
- `loct body fix_library_id`: View the definition body of symbol 'fix_library_id' to understand its implementation structure.
- `loct find --literal fix_library_id`: Execute a literal exact-identifier scan for 'fix_library_id' to find exact matches across the codebase.
- `loct occurrences fix_library_id`: Perform a literal boundary-sensitive occurrences scan for 'fix_library_id' to locate all references.
- `loct slice vibecrafted-app/shell-agent/scripts/normalize-bindings.sh`: Slice this file to inspect its direct dependencies and immediate consumers before editing.
- `loct slice vibecrafted-app/shell-agent/uniffi-bindgen/Cargo.toml`: Slice this file to inspect its direct dependencies and immediate consumers before editing.
- `loct slice vibecrafted-app/shell-agent/uniffi-bindgen/src/main.rs`: Slice this file to inspect its direct dependencies and immediate consumers before editing.
- `loct slice vibecrafted-app/tray-agent/Cargo.toml`: Slice this file to inspect its direct dependencies and immediate consumers before editing.
- `loct slice vibecrafted-app/tray-agent/src/bin/vc-mux-tray.rs`: Slice this file to inspect its direct dependencies and immediate consumers before editing.
- `loct slice vibecrafted-app/tray-agent/src/handlers.rs`: Slice this file to inspect its direct dependencies and immediate consumers before editing.
- `loct impact vibecrafted-app/tray-agent/src/handlers.rs`: Assess the transitive blast radius and downstream consumers of this file before modifying.
- `loct body resolve_menu_route`: View the definition body of symbol 'resolve_menu_route' to understand its implementation structure.
- `loct find --literal resolve_menu_route`: Execute a literal exact-identifier scan for 'resolve_menu_route' to find exact matches across the codebase.
- `loct occurrences resolve_menu_route`: Perform a literal boundary-sensitive occurrences scan for 'resolve_menu_route' to locate all references.
- `loct slice vibecrafted-app/tray-agent/src/icons.rs`: Slice this file to inspect its direct dependencies and immediate consumers before editing.
- `loct impact vibecrafted-app/tray-agent/src/icons.rs`: Assess the transitive blast radius and downstream consumers of this file before modifying.
- `loct body icon_for`: View the definition body of symbol 'icon_for' to understand its implementation structure.
- `loct find --literal icon_for`: Execute a literal exact-identifier scan for 'icon_for' to find exact matches across the codebase.
- `loct occurrences icon_for`: Perform a literal boundary-sensitive occurrences scan for 'icon_for' to locate all references.
- `loct slice vibecrafted-app/tray-agent/src/ipc_client.rs`: Slice this file to inspect its direct dependencies and immediate consumers before editing.
- `loct impact vibecrafted-app/tray-agent/src/ipc_client.rs`: Assess the transitive blast radius and downstream consumers of this file before modifying.
- `loct slice vibecrafted-app/tray-agent/src/lib.rs`: Slice this file to inspect its direct dependencies and immediate consumers before editing.
- `loct impact vibecrafted-app/tray-agent/src/lib.rs`: Assess the transitive blast radius and downstream consumers of this file before modifying.
- `loct body menu_event_receiver`: View the definition body of symbol 'menu_event_receiver' to understand its implementation structure.
- `loct find --literal menu_event_receiver`: Execute a literal exact-identifier scan for 'menu_event_receiver' to find exact matches across the codebase.
- `loct occurrences menu_event_receiver`: Perform a literal boundary-sensitive occurrences scan for 'menu_event_receiver' to locate all references.
- `loct slice vibecrafted-app/tray-agent/src/menu.rs`: Slice this file to inspect its direct dependencies and immediate consumers before editing.
- `loct impact vibecrafted-app/tray-agent/src/menu.rs`: Assess the transitive blast radius and downstream consumers of this file before modifying.
- `loct body current_service_count`: View the definition body of symbol 'current_service_count' to understand its implementation structure.
- `loct find --literal current_service_count`: Execute a literal exact-identifier scan for 'current_service_count' to find exact matches across the codebase.
- `loct occurrences current_service_count`: Perform a literal boundary-sensitive occurrences scan for 'current_service_count' to locate all references.
- `loct slice vibecrafted-app/tray-agent/src/state.rs`: Slice this file to inspect its direct dependencies and immediate consumers before editing.
- `loct impact vibecrafted-app/tray-agent/src/state.rs`: Assess the transitive blast radius and downstream consumers of this file before modifying.
- `loct body update_tray_status`: View the definition body of symbol 'update_tray_status' to understand its implementation structure.
- `loct find --literal update_tray_status`: Execute a literal exact-identifier scan for 'update_tray_status' to find exact matches across the codebase.
- `loct occurrences update_tray_status`: Perform a literal boundary-sensitive occurrences scan for 'update_tray_status' to locate all references.
- `loct slice vibecrafted-app/tray-agent/src/types.rs`: Slice this file to inspect its direct dependencies and immediate consumers before editing.
- `loct impact vibecrafted-app/tray-agent/src/types.rs`: Assess the transitive blast radius and downstream consumers of this file before modifying.
- `loct body tooltip`: View the definition body of symbol 'tooltip' to understand its implementation structure.
- `loct find --literal tooltip`: Execute a literal exact-identifier scan for 'tooltip' to find exact matches across the codebase.
- `loct occurrences tooltip`: Perform a literal boundary-sensitive occurrences scan for 'tooltip' to locate all references.
- `loct slice vibecrafted-app/tray-agent/tests/ipc_client.rs`: Slice this file to inspect its direct dependencies and immediate consumers before editing.
- `loct slice vibecrafted-app/tray-agent/tests/spawn_update_render_test.rs`: Slice this file to inspect its direct dependencies and immediate consumers before editing.
- `loct slice vibecrafted-app/tui-agent/Cargo.toml`: Slice this file to inspect its direct dependencies and immediate consumers before editing.
- `loct slice vibecrafted-app/tui-agent/README.md`: Slice this file to inspect its direct dependencies and immediate consumers before editing.
- `loct slice vibecrafted-app/tui-agent/audits/historical/2026-04-19_next-steps-agnostic.md`: Slice this file to inspect its direct dependencies and immediate consumers before editing.
- `loct slice vibecrafted-app/tui-agent/audits/historical/2026-04-19_next-steps-ghostty.md`: Slice this file to inspect its direct dependencies and immediate consumers before editing.
- `loct slice vibecrafted-app/tui-agent/audits/historical/2026-04-29_vc-intents.md`: Slice this file to inspect its direct dependencies and immediate consumers before editing.
- `loct slice vibecrafted-app/tui-agent/audits/historical/2026-04-30_vc-review.md`: Slice this file to inspect its direct dependencies and immediate consumers before editing.
- `loct slice vibecrafted-app/tui-agent/src/app.rs`: Slice this file to inspect its direct dependencies and immediate consumers before editing.
- `loct impact vibecrafted-app/tui-agent/src/app.rs`: Assess the transitive blast radius and downstream consumers of this file before modifying.
- `loct body label`: View the definition body of symbol 'label' to understand its implementation structure.
- `loct find --literal label`: Execute a literal exact-identifier scan for 'label' to find exact matches across the codebase.
- `loct occurrences label`: Perform a literal boundary-sensitive occurrences scan for 'label' to locate all references.
- `loct slice vibecrafted-app/tui-agent/src/bin/vc_admin.rs`: Slice this file to inspect its direct dependencies and immediate consumers before editing.
- `loct slice vibecrafted-app/tui-agent/src/config.rs`: Slice this file to inspect its direct dependencies and immediate consumers before editing.
- `loct impact vibecrafted-app/tui-agent/src/config.rs`: Assess the transitive blast radius and downstream consumers of this file before modifying.
- `loct body parse_args`: View the definition body of symbol 'parse_args' to understand its implementation structure.
- `loct find --literal parse_args`: Execute a literal exact-identifier scan for 'parse_args' to find exact matches across the codebase.
- `loct occurrences parse_args`: Perform a literal boundary-sensitive occurrences scan for 'parse_args' to locate all references.
- `loct slice vibecrafted-app/tui-agent/src/launch.rs`: Slice this file to inspect its direct dependencies and immediate consumers before editing.
- `loct impact vibecrafted-app/tui-agent/src/launch.rs`: Assess the transitive blast radius and downstream consumers of this file before modifying.
- `loct slice vibecrafted-app/tui-agent/src/lib.rs`: Slice this file to inspect its direct dependencies and immediate consumers before editing.
- `loct body App`: View the definition body of symbol 'App' to understand its implementation structure.
- `loct find --literal App`: Execute a literal exact-identifier scan for 'App' to find exact matches across the codebase.
- `loct occurrences App`: Perform a literal boundary-sensitive occurrences scan for 'App' to locate all references.
- `loct slice vibecrafted-app/tui-agent/src/main.rs`: Slice this file to inspect its direct dependencies and immediate consumers before editing.
- `loct slice vibecrafted-app/tui-agent/src/mission_control.rs`: Slice this file to inspect its direct dependencies and immediate consumers before editing.
- `loct impact vibecrafted-app/tui-agent/src/mission_control.rs`: Assess the transitive blast radius and downstream consumers of this file before modifying.
- `loct body glyph`: View the definition body of symbol 'glyph' to understand its implementation structure.
- `loct find --literal glyph`: Execute a literal exact-identifier scan for 'glyph' to find exact matches across the codebase.
- `loct occurrences glyph`: Perform a literal boundary-sensitive occurrences scan for 'glyph' to locate all references.
- `loct slice vibecrafted-app/tui-agent/src/mux.rs`: Slice this file to inspect its direct dependencies and immediate consumers before editing.
- `loct impact vibecrafted-app/tui-agent/src/mux.rs`: Assess the transitive blast radius and downstream consumers of this file before modifying.
- `loct slice vibecrafted-app/tui-agent/src/polarize.rs`: Slice this file to inspect its direct dependencies and immediate consumers before editing.
- `loct impact vibecrafted-app/tui-agent/src/polarize.rs`: Assess the transitive blast radius and downstream consumers of this file before modifying.
- `loct body from_score`: View the definition body of symbol 'from_score' to understand its implementation structure.
- `loct find --literal from_score`: Execute a literal exact-identifier scan for 'from_score' to find exact matches across the codebase.
- `loct occurrences from_score`: Perform a literal boundary-sensitive occurrences scan for 'from_score' to locate all references.
- `loct slice vibecrafted-app/tui-agent/src/skills_catalog.rs`: Slice this file to inspect its direct dependencies and immediate consumers before editing.
- `loct impact vibecrafted-app/tui-agent/src/skills_catalog.rs`: Assess the transitive blast radius and downstream consumers of this file before modifying.
- `loct slice vibecrafted-app/tui-agent/src/state.rs`: Slice this file to inspect its direct dependencies and immediate consumers before editing.
- `loct impact vibecrafted-app/tui-agent/src/state.rs`: Assess the transitive blast radius and downstream consumers of this file before modifying.
- `loct body load`: View the definition body of symbol 'load' to understand its implementation structure.
- `loct find --literal load`: Execute a literal exact-identifier scan for 'load' to find exact matches across the codebase.
- `loct occurrences load`: Perform a literal boundary-sensitive occurrences scan for 'load' to locate all references.
- `loct slice vibecrafted-app/tui-agent/src/ui.rs`: Slice this file to inspect its direct dependencies and immediate consumers before editing.
- `loct impact vibecrafted-app/tui-agent/src/ui.rs`: Assess the transitive blast radius and downstream consumers of this file before modifying.
- `loct body draw`: View the definition body of symbol 'draw' to understand its implementation structure.
- `loct find --literal draw`: Execute a literal exact-identifier scan for 'draw' to find exact matches across the codebase.
- `loct occurrences draw`: Perform a literal boundary-sensitive occurrences scan for 'draw' to locate all references.
- `loct slice vibecrafted-app/tui-agent/tests/launch_readiness.rs`: Slice this file to inspect its direct dependencies and immediate consumers before editing.
- `loct slice vibecrafted-app/tui-agent/tests/mission_control_snapshots.rs`: Slice this file to inspect its direct dependencies and immediate consumers before editing.
- `loct slice vibecrafted-app/tui-agent/tests/skill_launcher.rs`: Slice this file to inspect its direct dependencies and immediate consumers before editing.
- `loct slice vibecrafted-app/tui-agent/tests/state_contract.rs`: Slice this file to inspect its direct dependencies and immediate consumers before editing.

### Next Safe Commands

```bash
loct context --file vibecrafted-app/AGENTS.md
loct context --file vibecrafted-app/Cargo.toml
loct find .PHONY
```

### Verification Gates

```bash
mypy .
```

### Likely Tests

- `tests/agent_dispatch_test.py`
- `vibecrafted-app/mux-agent/tests/jsonl_bridge_test.rs`
- `vibecrafted-app/tray-agent/tests/ipc_client.rs`
- `vibecrafted-app/tray-agent/tests/spawn_update_render_test.rs`
- `vibecrafted-app/tui-agent/tests/launch_readiness.rs`
- `vibecrafted-app/tui-agent/tests/mission_control_snapshots.rs`
- `vibecrafted-app/tui-agent/tests/skill_launcher.rs`
- `vibecrafted-app/tui-agent/tests/state_contract.rs`
- `vibecrafted-core/tests/dispatch/test_cli.py`
- `vibecrafted-core/tests/dispatch/test_supervisor.py`

## Memory Slice

_Empty_

## Authority Slice

- Repo Verified: 11
- Loctree Derived: 438
- AICX Operator: 0
- AICX Agent: 0
- AICX Failure: 0
- Semantic Guess: 543
- Stale Or Unknown: 0

