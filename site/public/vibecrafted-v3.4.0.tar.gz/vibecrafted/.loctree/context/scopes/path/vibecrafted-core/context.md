# Loctree Context Pack

## Project Identity

- **Root**: `/Users/maciejgad/vc-workspace/vetcoders/vibecrafted`
- **Branch**: `feat/runtime-integration`
- **Commit**: `9f76009`
- **Snapshot**: `feat_runtime-integration@9f76009`

## Where You Are

### Files

| Path | Role | Language | LOC | Authority |
|---|---|---|---|---|
| `bin/vc-agents` | `Consumer` | py | 12 | *RepoVerified* |
| `bin/vc-followup` | `Consumer` | py | 12 | *RepoVerified* |
| `bin/vc-implement` | `Consumer` | py | 12 | *RepoVerified* |
| `bin/vc-marbles` | `Consumer` | py | 12 | *RepoVerified* |
| `bin/vc-prune` | `Consumer` | py | 12 | *RepoVerified* |
| `bin/vc-research` | `Consumer` | py | 12 | *RepoVerified* |
| `bin/vc-research-await` | `Consumer` | py | 12 | *RepoVerified* |
| `bin/vc-research-synthesize` | `Consumer` | py | 12 | *RepoVerified* |
| `bin/vc-review` | `Consumer` | py | 12 | *RepoVerified* |
| `bin/vc-sandbox` | `Consumer` | py | 54 | *RepoVerified* |
| `bin/vc-scaffold` | `Consumer` | py | 12 | *RepoVerified* |
| `bin/vibecrafted-resume` | `Consumer` | py | 12 | *RepoVerified* |
| `scripts/control_plane_launch.py` | `Consumer` | py | 12 | *RepoVerified* |
| `scripts/control_plane_state.py` | `Consumer` | py | 31 | *RepoVerified* |
| `scripts/installer_gui.py` | `Consumer` | py | 2709 | *RepoVerified* |
| `scripts/runtime_paths.py` | `Consumer` | py | 12 | *RepoVerified* |
| `scripts/vetcoders_install.py` | `Consumer` | py | 5764 | *RepoVerified* |
| `tests/agent_dispatch_test.py` | `Consumer` | py | 276 | *RepoVerified* |
| `tests/tui/test_keys.py` | `Consumer` | py | 255 | *RepoVerified* |
| `tests/tui/test_research_terminal_safety.py` | `Consumer` | py | 112 | *RepoVerified* |
| `vibecrafted-app/shell-agent/app/Vibecrafted/AppDelegate.swift` | `Consumer` | swift | 161 | *RepoVerified* |
| `vibecrafted-app/shell-agent/app/Vibecrafted/Bridge/vibecrafted_shell_ffi.swift` | `Consumer` | swift | 1447 | *RepoVerified* |
| `vibecrafted-app/shell-agent/app/Vibecrafted/Views/InspectorViewController.swift` | `Consumer` | swift | 150 | *RepoVerified* |
| `vibecrafted-core/README.md` | `Target` | md | 35 | *RepoVerified* |
| `vibecrafted-core/pyproject.toml` | `Target` | toml | 36 | *RepoVerified* |
| `vibecrafted-core/tests/__init__.py` | `Target` | py | 0 | *RepoVerified* |
| `vibecrafted-core/tests/conftest.py` | `Target` | py | 9 | *RepoVerified* |
| `vibecrafted-core/tests/dispatch/fixtures/invalid-no-verify.dispatch.toml` | `Target` | toml | 14 | *RepoVerified* |
| `vibecrafted-core/tests/dispatch/fixtures/invalid/concurrency-without-policy.dispatch.toml` | `Target` | toml | 18 | *RepoVerified* |
| `vibecrafted-core/tests/dispatch/fixtures/invalid/duplicate-id.dispatch.toml` | `Target` | toml | 25 | *RepoVerified* |
| `vibecrafted-core/tests/dispatch/fixtures/invalid/hard-stop-no-verify.dispatch.toml` | `Target` | toml | 15 | *RepoVerified* |
| `vibecrafted-core/tests/dispatch/fixtures/invalid/hard-stop-push.dispatch.toml` | `Target` | toml | 15 | *RepoVerified* |
| `vibecrafted-core/tests/dispatch/fixtures/invalid/hard-stop-release.dispatch.toml` | `Target` | toml | 15 | *RepoVerified* |
| `vibecrafted-core/tests/dispatch/fixtures/invalid/missing-meta-repo.dispatch.toml` | `Target` | toml | 14 | *RepoVerified* |
| `vibecrafted-core/tests/dispatch/fixtures/invalid/missing-prompt-and-brief.dispatch.toml` | `Target` | toml | 14 | *RepoVerified* |
| `vibecrafted-core/tests/dispatch/fixtures/invalid/missing-verify.dispatch.toml` | `Target` | toml | 11 | *RepoVerified* |
| `vibecrafted-core/tests/dispatch/fixtures/invalid/read-without-mutation.dispatch.toml` | `Target` | toml | 13 | *RepoVerified* |
| `vibecrafted-core/tests/dispatch/fixtures/invalid/unknown-matcher.dispatch.toml` | `Target` | toml | 15 | *RepoVerified* |
| `vibecrafted-core/tests/dispatch/fixtures/invalid/unknown-phase.dispatch.toml` | `Target` | toml | 19 | *RepoVerified* |
| `vibecrafted-core/tests/dispatch/fixtures/invalid/unknown-schema.dispatch.toml` | `Target` | toml | 15 | *RepoVerified* |
| `vibecrafted-core/tests/dispatch/fixtures/invalid/unknown-workflow.dispatch.toml` | `Target` | toml | 15 | *RepoVerified* |
| `vibecrafted-core/tests/dispatch/fixtures/invalid/unreadable-brief.dispatch.toml` | `Target` | toml | 15 | *RepoVerified* |
| `vibecrafted-core/tests/dispatch/fixtures/legacy-stage0-read-no-edit.dispatch.toml` | `Target` | toml | 16 | *RepoVerified* |
| `vibecrafted-core/tests/dispatch/fixtures/minimal.dispatch.toml` | `Target` | toml | 34 | *RepoVerified* |
| `vibecrafted-core/tests/dispatch/fixtures/observational-read.dispatch.toml` | `Target` | toml | 21 | *RepoVerified* |
| `vibecrafted-core/tests/dispatch/fixtures/stage0-brief.md` | `Target` | md | 3 | *RepoVerified* |
| `vibecrafted-core/tests/dispatch/fixtures/stage0.dispatch.toml` | `Target` | toml | 124 | *RepoVerified* |
| `vibecrafted-core/tests/dispatch/test_cli.py` | `Target` | py | 100 | *RepoVerified* |
| `vibecrafted-core/tests/dispatch/test_doctor.py` | `Target` | py | 90 | *RepoVerified* |
| `vibecrafted-core/tests/dispatch/test_schema.py` | `Target` | py | 192 | *RepoVerified* |
| `vibecrafted-core/tests/dispatch/test_supervisor.py` | `Target` | py | 538 | *RepoVerified* |
| `vibecrafted-core/tests/dispatch/test_verify.py` | `Target` | py | 249 | *RepoVerified* |
| `vibecrafted-core/tests/test_agent_stream.py` | `Target` | py | 160 | *RepoVerified* |
| `vibecrafted-core/tests/test_agy_junie_pipeline.py` | `Target` | py | 53 | *RepoVerified* |
| `vibecrafted-core/tests/test_aicx_sync.py` | `Target` | py | 536 | *RepoVerified* |
| `vibecrafted-core/tests/test_capabilities.py` | `Target` | py | 217 | *RepoVerified* |
| `vibecrafted-core/tests/test_cli.py` | `Target` | py | 474 | *RepoVerified* |
| `vibecrafted-core/tests/test_compact_hooks.py` | `Target` | py | 190 | *RepoVerified* |
| `vibecrafted-core/tests/test_control_plane.py` | `Target` | py | 684 | *RepoVerified* |
| `vibecrafted-core/tests/test_cron.py` | `Target` | py | 160 | *RepoVerified* |
| `vibecrafted-core/tests/test_dispatch_contract.py` | `Target` | py | 224 | *RepoVerified* |
| `vibecrafted-core/tests/test_doctor.py` | `Target` | py | 48 | *RepoVerified* |
| `vibecrafted-core/tests/test_git.py` | `Target` | py | 39 | *RepoVerified* |
| `vibecrafted-core/tests/test_loop_ship.py` | `Target` | py | 71 | *RepoVerified* |
| `vibecrafted-core/tests/test_memex_client.py` | `Target` | py | 397 | *RepoVerified* |
| `vibecrafted-core/tests/test_package_init.py` | `Target` | py | 34 | *RepoVerified* |
| `vibecrafted-core/tests/test_sandbox_adapter.py` | `Target` | py | 212 | *RepoVerified* |
| `vibecrafted-core/tests/test_supervisor.py` | `Target` | py | 239 | *RepoVerified* |
| `vibecrafted-core/tests/test_supervisor_async.py` | `Target` | py | 478 | *RepoVerified* |
| `vibecrafted-core/tests/test_ui.py` | `Target` | py | 64 | *RepoVerified* |
| `vibecrafted-core/tests/test_workflow.py` | `Target` | py | 731 | *RepoVerified* |
| `vibecrafted-core/tests/test_workflow_registry.py` | `Target` | py | 78 | *RepoVerified* |
| `vibecrafted-core/tests/test_workflow_runtime.py` | `Target` | py | 340 | *RepoVerified* |
| `vibecrafted-core/tests/test_wrappers.py` | `Target` | py | 100 | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/__init__.py` | `Dependency` | py | 111 | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/agent_dispatch.py` | `Dependency` | py | 296 | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/agent_stream.py` | `Dependency` | py | 509 | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/aicx_sync.py` | `Target` | py | 870 | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/artifacts.py` | `Dependency` | py | 134 | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/capabilities.py` | `Dependency` | py | 333 | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/cli.py` | `Consumer` | py | 422 | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/compact_hooks.py` | `Target` | py | 475 | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/control_plane.py` | `Dependency` | py | 1267 | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/cron.py` | `Target` | py | 373 | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/dispatch/__init__.py` | `Dependency` | py | 71 | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/dispatch/cli.py` | `Dependency` | py | 239 | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/dispatch/doctor.py` | `Dependency` | py | 82 | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/dispatch/model.py` | `Dependency` | py | 255 | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/dispatch/schema.py` | `Dependency` | py | 508 | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/dispatch/supervisor.py` | `Dependency` | py | 776 | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/dispatch/verify.py` | `Dependency` | py | 217 | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/dispatch_contract.py` | `Dependency` | py | 496 | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/dispatcher.py` | `Target` | py | 129 | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/doctor.py` | `Dependency` | py | 86 | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/events.py` | `Dependency` | py | 24 | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/git.py` | `Dependency` | py | 192 | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/lifecycle.py` | `Dependency` | py | 175 | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/loop.py` | `Target` | py | 336 | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/memex_client.py` | `Target` | py | 415 | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/runtime_paths.py` | `Dependency` | py | 53 | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/sandbox/README.md` | `Target` | md | 92 | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/sandbox/__init__.py` | `Dependency` | py | 12 | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/sandbox/adapter.py` | `Dependency` | py | 228 | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/sandbox/msbserver_lifecycle.py` | `Dependency` | py | 157 | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/sandbox/policy.py` | `Dependency` | py | 131 | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/ship.py` | `Target` | py | 98 | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/spawn.py` | `Dependency` | py | 1141 | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/supervisor_async.py` | `Dependency` | py | 605 | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/ui.py` | `Target` | py | 149 | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/workflow.py` | `Dependency` | py | 1429 | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/workflow_runtime.py` | `Dependency` | py | 935 | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/workflows/__init__.py` | `Dependency` | py | 21 | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/workflows/model.py` | `Dependency` | py | 36 | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/workflows/registry.py` | `Dependency` | py | 204 | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/wrappers.py` | `Dependency` | py | 440 | *RepoVerified* |
| `vibecrafted-mcp/vibecrafted_mcp/server.py` | `Consumer` | py | 801 | *RepoVerified* |

### Symbols

| File | Name | Kind | Export Type | Line | Authority |
|---|---|---|---|---|---|
| `vibecrafted-core/tests/dispatch/test_doctor.py` | `test_dispatch_doctor_allows_observational_read_with_mutation_policy` | def | named | 56 | *RepoVerified* |
| `vibecrafted-core/tests/dispatch/test_doctor.py` | `test_dispatch_doctor_cli_returns_nonzero_for_errors` | def | named | 73 | *RepoVerified* |
| `vibecrafted-core/tests/dispatch/test_doctor.py` | `test_dispatch_doctor_cli_returns_zero_for_valid_fixture` | def | named | 83 | *RepoVerified* |
| `vibecrafted-core/tests/dispatch/test_doctor.py` | `test_dispatch_doctor_rejects_design_refusal_fixtures` | def | named | 45 | *RepoVerified* |
| `vibecrafted-core/tests/dispatch/test_doctor.py` | `test_dispatch_doctor_rejects_legacy_stage0_review_no_edit_read` | def | named | 63 | *RepoVerified* |
| `vibecrafted-core/tests/dispatch/test_schema.py` | `test_doctor_reports_schema_errors_without_throwing` | def | named | 112 | *RepoVerified* |
| `vibecrafted-core/tests/dispatch/test_schema.py` | `test_matchers_cover_required_set` | def | named | 101 | *RepoVerified* |
| `vibecrafted-core/tests/dispatch/test_schema.py` | `test_minimal_fixture_parses_into_typed_model` | def | named | 27 | *RepoVerified* |
| `vibecrafted-core/tests/dispatch/test_schema.py` | `test_parser_accepts_read_cut_without_mutation_for_doctor_policy` | def | named | 120 | *RepoVerified* |
| `vibecrafted-core/tests/dispatch/test_schema.py` | `test_prompt_rendering_substitutes_common_body_extra_and_empty_baton` | def | named | 53 | *RepoVerified* |
| `vibecrafted-core/tests/dispatch/test_schema.py` | `test_prompt_rendering_substitutes_previous_verdict_baton` | def | named | 67 | *RepoVerified* |
| `vibecrafted-core/tests/dispatch/test_schema.py` | `test_rejects_duplicate_cut_ids_and_missing_verify` | def | named | 148 | *RepoVerified* |
| `vibecrafted-core/tests/dispatch/test_schema.py` | `test_rejects_unsupported_read_mutation_at_parse_time` | def | named | 135 | *RepoVerified* |
| `vibecrafted-core/tests/dispatch/test_schema.py` | `test_stage0_maximum_fixture_is_accepted` | def | named | 38 | *RepoVerified* |
| `vibecrafted-core/tests/dispatch/test_supervisor.py` | `FakeCell` | class | named | 31 | *RepoVerified* |
| `vibecrafted-core/tests/dispatch/test_supervisor.py` | `FakeCells` | class | named | 40 | *RepoVerified* |
| `vibecrafted-core/tests/dispatch/test_supervisor.py` | `build_dispatch` | def | named | 72 | *RepoVerified* |
| `vibecrafted-core/tests/dispatch/test_verify.py` | `make_cut` | def | named | 25 | *RepoVerified* |
| `vibecrafted-core/tests/dispatch/test_verify.py` | `test_all_green_matchers_verify_cut` | def | named | 43 | *RepoVerified* |
| `vibecrafted-core/tests/dispatch/test_verify.py` | `test_bare_verify_list_with_expect_reports_ok` | def | named | 205 | *RepoVerified* |
| `vibecrafted-core/tests/dispatch/test_verify.py` | `test_commands_run_in_repo_cwd` | def | named | 132 | *RepoVerified* |
| `vibecrafted-core/tests/dispatch/test_verify.py` | `test_cut_without_verifiers_stays_unknown` | def | named | 195 | *RepoVerified* |
| `vibecrafted-core/tests/dispatch/test_verify.py` | `test_env_is_sanitized_for_verifier_shells` | def | named | 140 | *RepoVerified* |
| `vibecrafted-core/tests/dispatch/test_verify.py` | `test_evidence_serializes_to_journal_json` | def | named | 163 | *RepoVerified* |
| `vibecrafted-core/tests/dispatch/test_verify.py` | `test_excerpt_keeps_head_and_tail` | def | named | 181 | *RepoVerified* |
| `vibecrafted-core/tests/dispatch/test_verify.py` | `test_exit_code_matcher_on_failing_command` | def | named | 88 | *RepoVerified* |
| `vibecrafted-core/tests/dispatch/test_verify.py` | `test_expect_exit_code_coerces_string_to_int` | def | named | 230 | *RepoVerified* |
| `vibecrafted-core/tests/dispatch/test_verify.py` | `test_expect_rejects_unknown_matcher_kind` | def | named | 237 | *RepoVerified* |
| `vibecrafted-core/tests/dispatch/test_verify.py` | `test_matchers_see_stderr` | def | named | 97 | *RepoVerified* |
| `vibecrafted-core/tests/dispatch/test_verify.py` | `test_one_failure_per_red_matcher_with_evidence` | def | named | 60 | *RepoVerified* |
| `vibecrafted-core/tests/dispatch/test_verify.py` | `test_red_matcher_beats_timeout` | def | named | 120 | *RepoVerified* |
| `vibecrafted-core/tests/dispatch/test_verify.py` | `test_repo_defaults_to_cwd` | def | named | 242 | *RepoVerified* |
| `vibecrafted-core/tests/dispatch/test_verify.py` | `test_sanitize_env_keeps_path_and_drops_noise` | def | named | 151 | *RepoVerified* |
| `vibecrafted-core/tests/dispatch/test_verify.py` | `test_timeout_marks_cut_unknown` | def | named | 106 | *RepoVerified* |
| `vibecrafted-core/tests/dispatch/test_verify.py` | `test_verdict_is_and_of_all_verifiers` | def | named | 74 | *RepoVerified* |
| `vibecrafted-core/tests/dispatch/test_verify.py` | `test_verdict_ok_is_false_on_red_matcher` | def | named | 220 | *RepoVerified* |
| `vibecrafted-core/tests/dispatch/test_verify.py` | `verify` | def | named | 36 | *RepoVerified* |
| `vibecrafted-core/tests/test_agent_stream.py` | `test_agent_stream_parser_extracts_claude_session_usage_cost_and_text` | def | named | 6 | *RepoVerified* |
| `vibecrafted-core/tests/test_agent_stream.py` | `test_agent_stream_parser_extracts_codex_thread_usage_and_text` | def | named | 36 | *RepoVerified* |
| `vibecrafted-core/tests/test_agent_stream.py` | `test_agent_stream_parser_extracts_gemini_session_stats_and_text` | def | named | 63 | *RepoVerified* |
| `vibecrafted-core/tests/test_agent_stream.py` | `test_agent_stream_parser_renders_grok_thought_text_and_session` | def | named | 99 | *RepoVerified* |
| `vibecrafted-core/tests/test_agent_stream.py` | `test_agent_stream_parser_treats_agy_as_claude_family_text_stream` | def | named | 124 | *RepoVerified* |
| `vibecrafted-core/tests/test_agent_stream.py` | `test_resolve_default_model_reads_codex_config` | def | named | 144 | *RepoVerified* |
| `vibecrafted-core/tests/test_agy_junie_pipeline.py` | `test_build_launch_command_passes_new_agent_to_command_deck` | def | named | 19 | *RepoVerified* |
| `vibecrafted-core/tests/test_agy_junie_pipeline.py` | `test_supervisor_defaults_and_sandbox_support_cover_agy_junie_grok` | def | named | 37 | *RepoVerified* |
| `vibecrafted-core/tests/test_agy_junie_pipeline.py` | `test_workflow_launch_spec_accepts_agy_junie_and_grok` | def | named | 10 | *RepoVerified* |
| `vibecrafted-core/tests/test_aicx_sync.py` | `test_aicx_chunk_canonical_authority_falls_back_for_unknown` | def | named | 152 | *RepoVerified* |
| `vibecrafted-core/tests/test_aicx_sync.py` | `test_aicx_chunk_rank_reflects_normalized_authority` | def | named | 157 | *RepoVerified* |
| `vibecrafted-core/tests/test_aicx_sync.py` | `test_apply_plan_dry_run_is_read_only` | def | named | 410 | *RepoVerified* |
| `vibecrafted-core/tests/test_aicx_sync.py` | `test_apply_plan_non_dry_run_no_crash` | def | named | 467 | *RepoVerified* |
| `vibecrafted-core/tests/test_aicx_sync.py` | `test_apply_plan_records_adds_in_both_directions` | def | named | 428 | *RepoVerified* |
| `vibecrafted-core/tests/test_aicx_sync.py` | `test_apply_plan_resolves_authority_conflict` | def | named | 452 | *RepoVerified* |
| `vibecrafted-core/tests/test_aicx_sync.py` | `test_apply_plan_surfaces_ties` | def | named | 440 | *RepoVerified* |
| `vibecrafted-core/tests/test_aicx_sync.py` | `test_authority_canonical_names` | def | named | 84 | *RepoVerified* |
| `vibecrafted-core/tests/test_aicx_sync.py` | `test_authority_from_str_camelcase_alias` | def | named | 97 | *RepoVerified* |
| `vibecrafted-core/tests/test_aicx_sync.py` | `test_authority_from_str_canonical` | def | named | 90 | *RepoVerified* |
| `vibecrafted-core/tests/test_aicx_sync.py` | `test_authority_from_str_unknown_raises` | def | named | 113 | *RepoVerified* |
| `vibecrafted-core/tests/test_aicx_sync.py` | `test_authority_rank_ordering` | def | named | 125 | *RepoVerified* |
| `vibecrafted-core/tests/test_aicx_sync.py` | `test_authority_rank_unknown_returns_zero` | def | named | 144 | *RepoVerified* |
| `vibecrafted-core/tests/test_aicx_sync.py` | `test_cli_dry_run_emits_json` | def | named | 514 | *RepoVerified* |
| `vibecrafted-core/tests/test_aicx_sync.py` | `test_cli_help_returns_zero` | def | named | 501 | *RepoVerified* |
| `vibecrafted-core/tests/test_aicx_sync.py` | `test_cli_log_show_handles_missing_log` | def | named | 529 | *RepoVerified* |
| `vibecrafted-core/tests/test_aicx_sync.py` | `test_cli_unknown_command_returns_two` | def | named | 509 | *RepoVerified* |
| `vibecrafted-core/tests/test_aicx_sync.py` | `test_discover_chunks_accepts_file_url` | def | named | 245 | *RepoVerified* |
| `vibecrafted-core/tests/test_aicx_sync.py` | `test_discover_chunks_conflict_surfaced` | def | named | 201 | *RepoVerified* |
| `vibecrafted-core/tests/test_aicx_sync.py` | `test_discover_chunks_corrupted_reported` | def | named | 211 | *RepoVerified* |
| `vibecrafted-core/tests/test_aicx_sync.py` | `test_discover_chunks_identical_content_skipped` | def | named | 191 | *RepoVerified* |
| `vibecrafted-core/tests/test_aicx_sync.py` | `test_discover_chunks_local_only` | def | named | 165 | *RepoVerified* |
| `vibecrafted-core/tests/test_aicx_sync.py` | `test_discover_chunks_markdown_format` | def | named | 226 | *RepoVerified* |
| `vibecrafted-core/tests/test_aicx_sync.py` | `test_discover_chunks_rejects_remote_url_scheme` | def | named | 237 | *RepoVerified* |
| `vibecrafted-core/tests/test_aicx_sync.py` | `test_discover_chunks_remote_only` | def | named | 180 | *RepoVerified* |
| `vibecrafted-core/tests/test_aicx_sync.py` | `test_normalize_authority_handles_empty_and_unknown` | def | named | 118 | *RepoVerified* |
| `vibecrafted-core/tests/test_aicx_sync.py` | `test_record_decision_appends_log` | def | named | 380 | *RepoVerified* |
| `vibecrafted-core/tests/test_aicx_sync.py` | `test_record_decision_rejects_bad_decision` | def | named | 398 | *RepoVerified* |
| `vibecrafted-core/tests/test_aicx_sync.py` | `test_resolve_conflict_complete_tier_ladder` | def | named | 274 | *RepoVerified* |
| `vibecrafted-core/tests/test_aicx_sync.py` | `test_resolve_conflict_honours_prior_local_decision` | def | named | 305 | *RepoVerified* |
| `vibecrafted-core/tests/test_aicx_sync.py` | `test_resolve_conflict_honours_prior_remote_decision` | def | named | 329 | *RepoVerified* |
| `vibecrafted-core/tests/test_aicx_sync.py` | `test_resolve_conflict_local_higher_wins` | def | named | 266 | *RepoVerified* |
| `vibecrafted-core/tests/test_aicx_sync.py` | `test_resolve_conflict_log_last_write_wins` | def | named | 353 | *RepoVerified* |
| `vibecrafted-core/tests/test_aicx_sync.py` | `test_resolve_conflict_picks_higher_authority` | def | named | 258 | *RepoVerified* |
| `vibecrafted-core/tests/test_aicx_sync.py` | `test_resolve_conflict_same_authority_returns_tie` | def | named | 295 | *RepoVerified* |
| `vibecrafted-core/tests/test_aicx_sync.py` | `test_sync_result_to_jsonable_round_trip` | def | named | 485 | *RepoVerified* |
| `vibecrafted-core/tests/test_capabilities.py` | `test_foundation_capabilities_emits_versioned_schema` | def | named | 200 | *RepoVerified* |
| `vibecrafted-core/tests/test_capabilities.py` | `test_probe_tool_discovers_canonical_binary_without_path` | def | named | 40 | *RepoVerified* |
| `vibecrafted-core/tests/test_capabilities.py` | `test_probe_tool_flags_noncanonical_install` | def | named | 137 | *RepoVerified* |
| `vibecrafted-core/tests/test_capabilities.py` | `test_probe_tool_ok_with_capability_discovery` | def | named | 95 | *RepoVerified* |
| `vibecrafted-core/tests/test_capabilities.py` | `test_probe_tool_reports_ghost_root_even_when_path_is_minimal` | def | named | 166 | *RepoVerified* |
| `vibecrafted-core/tests/test_capabilities.py` | `test_probe_tool_reports_product_broken` | def | named | 72 | *RepoVerified* |
| `vibecrafted-core/tests/test_capabilities.py` | `test_probe_tool_reports_product_missing` | def | named | 20 | *RepoVerified* |
| `vibecrafted-core/tests/test_cli.py` | `test_root_cli_accepts_justdo_alias` | def | named | 33 | *RepoVerified* |
| `vibecrafted-core/tests/test_cli.py` | `test_root_cli_agent_await_accepts_receipt_command` | def | named | 385 | *RepoVerified* |
| `vibecrafted-core/tests/test_cli.py` | `test_root_cli_agent_await_fails_dead_stale_worker` | def | named | 412 | *RepoVerified* |
| `vibecrafted-core/tests/test_cli.py` | `test_root_cli_agent_observe_accepts_receipt_command` | def | named | 149 | *RepoVerified* |
| `vibecrafted-core/tests/test_cli.py` | `test_root_cli_agent_observe_prints_transcript_tail` | def | named | 226 | *RepoVerified* |
| `vibecrafted-core/tests/test_cli.py` | `test_root_cli_agent_observe_recovers_model_when_tail_starts_after_init` | def | named | 304 | *RepoVerified* |
| `vibecrafted-core/tests/test_cli.py` | `test_root_cli_agent_observe_renders_json_transcript_tail` | def | named | 260 | *RepoVerified* |
| `vibecrafted-core/tests/test_cli.py` | `test_root_cli_agent_observe_uses_codex_config_model` | def | named | 343 | *RepoVerified* |
| `vibecrafted-core/tests/test_cli.py` | `test_root_cli_doctor_returns_failure_for_failed_findings` | def | named | 467 | *RepoVerified* |
| `vibecrafted-core/tests/test_cli.py` | `test_root_cli_doctor_routes_to_installer_doctor` | def | named | 453 | *RepoVerified* |
| `vibecrafted-core/tests/test_cli.py` | `test_root_cli_launch_missing_work_prints_friendly_error` | def | named | 51 | *RepoVerified* |
| `vibecrafted-core/tests/test_cli.py` | `test_root_cli_observe_hides_stale_error_after_report_validated` | def | named | 197 | *RepoVerified* |
| `vibecrafted-core/tests/test_cli.py` | `test_root_cli_prints_full_launch_receipt` | def | named | 123 | *RepoVerified* |
| `vibecrafted-core/tests/test_cli.py` | `test_root_cli_prune_without_agent_defaults_to_claude` | def | named | 88 | *RepoVerified* |
| `vibecrafted-core/tests/test_cli.py` | `test_root_cli_prune_without_work_uses_discovery_prompt` | def | named | 70 | *RepoVerified* |
| `vibecrafted-core/tests/test_cli.py` | `test_root_cli_swarm_observe_accepts_research_receipt` | def | named | 174 | *RepoVerified* |
| `vibecrafted-core/tests/test_cli.py` | `test_root_cli_uses_terminal_runtime_when_operator_session_exists` | def | named | 105 | *RepoVerified* |
| `vibecrafted-core/tests/test_cli.py` | `test_root_cli_vc_help_alias_returns_help_success` | def | named | 25 | *RepoVerified* |
| `vibecrafted-core/tests/test_compact_hooks.py` | `test_postcompact_emits_manifest_and_chunks_extract` | def | named | 108 | *RepoVerified* |
| `vibecrafted-core/tests/test_compact_hooks.py` | `test_postcompact_emits_only_delta_after_first_recall` | def | named | 137 | *RepoVerified* |
| `vibecrafted-core/tests/test_compact_hooks.py` | `test_postcompact_missing_extract_is_loud` | def | named | 177 | *RepoVerified* |
| `vibecrafted-core/tests/test_compact_hooks.py` | `test_precompact_extracts_conversation_and_user_only` | def | named | 9 | *RepoVerified* |
| `vibecrafted-core/tests/test_compact_hooks.py` | `test_precompact_resolves_codex_session_from_sessions_dir` | def | named | 41 | *RepoVerified* |
| `vibecrafted-core/tests/test_control_plane.py` | `test_await_run_completes_from_metadata_without_transcript` | def | named | 467 | *RepoVerified* |
| `vibecrafted-core/tests/test_control_plane.py` | `test_await_run_completes_when_dead_worker_missing_report_is_terminal` | def | named | 496 | *RepoVerified* |
| `vibecrafted-core/tests/test_control_plane.py` | `test_await_run_times_out_when_metadata_missing` | def | named | 531 | *RepoVerified* |
| `vibecrafted-core/tests/test_control_plane.py` | `test_block_run_lever_pins_terminal_blocked_state` | def | named | 639 | *RepoVerified* |
| `vibecrafted-core/tests/test_control_plane.py` | `test_lookup_run_uses_synced_snapshot` | def | named | 212 | *RepoVerified* |
| `vibecrafted-core/tests/test_control_plane.py` | `test_sync_state_enforces_identity_on_fresh_creation_events` | def | named | 70 | *RepoVerified* |
| `vibecrafted-core/tests/test_control_plane.py` | `test_sync_state_leaves_fresh_lock_present_run_running` | def | named | 369 | *RepoVerified* |
| `vibecrafted-core/tests/test_control_plane.py` | `test_sync_state_leaves_live_launcher_running` | def | named | 403 | *RepoVerified* |
| `vibecrafted-core/tests/test_control_plane.py` | `test_sync_state_leaves_terminal_dead_launcher_untouched` | def | named | 433 | *RepoVerified* |
| `vibecrafted-core/tests/test_control_plane.py` | `test_sync_state_preserves_runtime_observe_fields` | def | named | 32 | *RepoVerified* |
| `vibecrafted-core/tests/test_control_plane.py` | `test_sync_state_projects_event_stream_lifecycle` | def | named | 545 | *RepoVerified* |
| `vibecrafted-core/tests/test_control_plane.py` | `test_sync_state_publishes_lifecycle_control_availability` | def | named | 136 | *RepoVerified* |
| `vibecrafted-core/tests/test_control_plane.py` | `test_sync_state_reaps_stale_lock_present_run_without_launcher_pid` | def | named | 334 | *RepoVerified* |
| `vibecrafted-core/tests/test_control_plane.py` | `test_sync_state_reconciles_dead_launcher_to_stalled` | def | named | 240 | *RepoVerified* |
| `vibecrafted-core/tests/test_control_plane.py` | `test_sync_state_reconciles_dead_launcher_with_missing_report_to_terminal_failure` | def | named | 290 | *RepoVerified* |
| `vibecrafted-core/tests/test_control_plane.py` | `test_sync_state_surfaces_failure_card_on_contract_failure` | def | named | 599 | *RepoVerified* |
| `vibecrafted-core/tests/test_cron.py` | `test_cron_line_prints_real_vibecrafted_command` | def | named | 135 | *RepoVerified* |
| `vibecrafted-core/tests/test_cron.py` | `test_tick_default_prints_human_summary_not_json` | def | named | 100 | *RepoVerified* |
| `vibecrafted-core/tests/test_cron.py` | `test_tick_refuses_hard_stop_then_command` | def | named | 69 | *RepoVerified* |
| `vibecrafted-core/tests/test_cron.py` | `test_tick_runs_then_command_after_idle_window` | def | named | 29 | *RepoVerified* |
| `vibecrafted-core/tests/test_cron.py` | `write_state` | def | named | 10 | *RepoVerified* |
| `vibecrafted-core/tests/test_doctor.py` | `test_doctor_summary_counts_findings` | def | named | 36 | *RepoVerified* |
| `vibecrafted-core/tests/test_doctor.py` | `test_installer_module_loads_source_file_without_mutating_sys_path` | def | named | 10 | *RepoVerified* |
| `vibecrafted-core/tests/test_doctor.py` | `test_repo_root_from_source_detects_live_checkout` | def | named | 29 | *RepoVerified* |
| `vibecrafted-core/tests/test_git.py` | `test_repo_full_rejects_non_repo_path` | def | named | 37 | *RepoVerified* |
| `vibecrafted-core/tests/test_git.py` | `test_repo_full_reports_git_availability_and_commit` | def | named | 25 | *RepoVerified* |
| `vibecrafted-core/tests/test_loop_ship.py` | `test_loop_start_next_complete_round_trip` | def | named | 8 | *RepoVerified* |
| `vibecrafted-core/tests/test_loop_ship.py` | `test_ship_loop_only_creates_vc_ship_contract` | def | named | 42 | *RepoVerified* |
| `vibecrafted-core/tests/test_memex_client.py` | `test_http_search_rejects_missing_host` | def | named | 343 | *RepoVerified* |
| `vibecrafted-core/tests/test_memex_client.py` | `test_http_search_rejects_unsupported_scheme` | def | named | 330 | *RepoVerified* |
| `vibecrafted-core/tests/test_memex_client.py` | `test_load_config_env_endpoint_without_token_stays_disabled` | def | named | 58 | *RepoVerified* |
| `vibecrafted-core/tests/test_memex_client.py` | `test_load_config_env_only_enables_when_token_present` | def | named | 41 | *RepoVerified* |
| `vibecrafted-core/tests/test_memex_client.py` | `test_load_config_invalid_timeout_falls_back` | def | named | 67 | *RepoVerified* |
| `vibecrafted-core/tests/test_memex_client.py` | `test_load_config_pure_defaults` | def | named | 30 | *RepoVerified* |
| `vibecrafted-core/tests/test_memex_client.py` | `test_load_config_strips_trailing_slash` | def | named | 119 | *RepoVerified* |
| `vibecrafted-core/tests/test_memex_client.py` | `test_load_config_toml_wins_over_env` | def | named | 81 | *RepoVerified* |
| `vibecrafted-core/tests/test_memex_client.py` | `test_load_config_toml_without_token_can_borrow_env` | def | named | 106 | *RepoVerified* |
| `vibecrafted-core/tests/test_memex_client.py` | `test_memex_chunk_authority_label_locked` | def | named | 132 | *RepoVerified* |
| `vibecrafted-core/tests/test_memex_client.py` | `test_payload_helper_unused_json_keeps_module_importable` | def | named | 395 | *RepoVerified* |
| `vibecrafted-core/tests/test_memex_client.py` | `test_public_surface_exports_remain_stable` | def | named | 379 | *RepoVerified* |
| `vibecrafted-core/tests/test_memex_client.py` | `test_search_disabled_config_returns_empty` | def | named | 200 | *RepoVerified* |
| `vibecrafted-core/tests/test_memex_client.py` | `test_search_empty_query_short_circuits` | def | named | 176 | *RepoVerified* |
| `vibecrafted-core/tests/test_memex_client.py` | `test_search_http_client_error_returns_empty` | def | named | 309 | *RepoVerified* |
| `vibecrafted-core/tests/test_memex_client.py` | `test_search_http_os_error_returns_empty` | def | named | 287 | *RepoVerified* |
| `vibecrafted-core/tests/test_memex_client.py` | `test_search_http_success` | def | named | 217 | *RepoVerified* |
| `vibecrafted-core/tests/test_memex_client.py` | `test_search_http_unreachable_returns_empty` | def | named | 263 | *RepoVerified* |
| `vibecrafted-core/tests/test_memex_client.py` | `test_search_limit_is_clamped` | def | named | 355 | *RepoVerified* |
| `vibecrafted-core/tests/test_memex_client.py` | `test_search_mcp_failure_returns_empty` | def | named | 181 | *RepoVerified* |
| `vibecrafted-core/tests/test_memex_client.py` | `test_search_parses_chunks_via_mcp_bridge` | def | named | 139 | *RepoVerified* |
| `vibecrafted-core/tests/test_memex_client.py` | `test_sparse_aicx_threshold_is_five` | def | named | 374 | *RepoVerified* |
| `vibecrafted-core/tests/test_package_init.py` | `test_package_import_does_not_preload_spawn_module` | def | named | 7 | *RepoVerified* |
| `vibecrafted-core/tests/test_package_init.py` | `test_spawn_module_runs_without_runpy_preload_warning` | def | named | 25 | *RepoVerified* |
| `vibecrafted-core/tests/test_sandbox_adapter.py` | `FakeCommand` | class | named | 39 | *RepoVerified* |
| `vibecrafted-core/tests/test_sandbox_adapter.py` | `FakeExecution` | class | named | 29 | *RepoVerified* |
| `vibecrafted-core/tests/test_sandbox_adapter.py` | `FakeLifecycle` | class | named | 17 | *RepoVerified* |
| `vibecrafted-core/tests/test_sandbox_adapter.py` | `FakeSandbox` | class | named | 49 | *RepoVerified* |
| `vibecrafted-core/tests/test_sandbox_adapter.py` | `FakeSession` | class | named | 24 | *RepoVerified* |
| `vibecrafted-core/tests/test_sandbox_adapter.py` | `fake_microsandbox` | def | named | 73 | *RepoVerified* |
| `vibecrafted-core/tests/test_sandbox_adapter.py` | `test_adapter_can_use_local_microsandbox_sdk_path` | def | named | 195 | *RepoVerified* |
| `vibecrafted-core/tests/test_sandbox_adapter.py` | `test_adapter_executes_command_and_emits_spawn_updates` | def | named | 157 | *RepoVerified* |
| `vibecrafted-core/tests/test_sandbox_adapter.py` | `test_adapter_shell_script_exports_env_before_exec` | def | named | 184 | *RepoVerified* |
| `vibecrafted-core/tests/test_sandbox_adapter.py` | `test_lifecycle_ignores_invalid_msbserver_key` | def | named | 149 | *RepoVerified* |
| `vibecrafted-core/tests/test_sandbox_adapter.py` | `test_lifecycle_reads_valid_msbserver_key` | def | named | 141 | *RepoVerified* |
| `vibecrafted-core/tests/test_sandbox_adapter.py` | `test_lifecycle_rejects_non_http_health_url` | def | named | 132 | *RepoVerified* |
| `vibecrafted-core/tests/test_sandbox_adapter.py` | `test_lifecycle_reports_not_running_for_dead_pid` | def | named | 120 | *RepoVerified* |
| `vibecrafted-core/tests/test_sandbox_adapter.py` | `test_policy_default_is_deny_with_readonly_project_mount` | def | named | 83 | *RepoVerified* |
| `vibecrafted-core/tests/test_sandbox_adapter.py` | `test_policy_loads_operator_yaml` | def | named | 92 | *RepoVerified* |
| `vibecrafted-core/tests/test_sandbox_adapter.py` | `test_real_msbserver_absence_is_skip_not_failure` | def | named | 208 | *RepoVerified* |
| `vibecrafted-core/tests/test_supervisor.py` | `test_extract_tokens_prefers_run_closure_footer_across_agents` | def | named | 209 | *RepoVerified* |
| `vibecrafted-core/tests/test_supervisor.py` | `test_finalize_artifacts_python_owns_launcher_artifact_contract` | def | named | 95 | *RepoVerified* |
| `vibecrafted-core/tests/test_supervisor.py` | `test_finish_meta_python_owns_terminal_state` | def | named | 161 | *RepoVerified* |
| `vibecrafted-core/tests/test_supervisor.py` | `test_session_id_extractors_use_shared_pattern` | def | named | 77 | *RepoVerified* |
| `vibecrafted-core/tests/test_supervisor.py` | `test_subscribe_events_reads_appended_events` | def | named | 196 | *RepoVerified* |
| `vibecrafted-core/tests/test_supervisor.py` | `test_supervisor_propagates_exit_code` | def | named | 56 | *RepoVerified* |
| `vibecrafted-core/tests/test_supervisor.py` | `test_supervisor_spawn_lifecycle_extracts_session_id` | def | named | 15 | *RepoVerified* |
| `vibecrafted-core/tests/test_supervisor_async.py` | `test_artifact_validator_reports_missing_report` | def | named | 20 | *RepoVerified* |
| `vibecrafted-core/tests/test_supervisor_async.py` | `test_async_supervisor_emits_lifecycle_and_validates_artifacts` | def | named | 31 | *RepoVerified* |
| `vibecrafted-core/tests/test_supervisor_async.py` | `test_async_supervisor_renders_claude_stream_json_for_visible_terminal` | def | named | 241 | *RepoVerified* |
| `vibecrafted-core/tests/test_supervisor_async.py` | `test_async_supervisor_salvages_grok_report_from_streaming_json` | def | named | 343 | *RepoVerified* |
| `vibecrafted-core/tests/test_supervisor_async.py` | `test_async_supervisor_survives_large_single_json_line_from_mcp` | def | named | 404 | *RepoVerified* |
| `vibecrafted-core/tests/test_supervisor_async.py` | `test_async_supervisor_uses_env_model_for_codex_thread_banner` | def | named | 300 | *RepoVerified* |
| `vibecrafted-core/tests/test_supervisor_async.py` | `test_dispatcher_cli_delivers_prompt_file_on_stdin` | def | named | 118 | *RepoVerified* |
| `vibecrafted-core/tests/test_supervisor_async.py` | `test_dispatcher_cli_fails_missing_report_contract` | def | named | 448 | *RepoVerified* |
| `vibecrafted-core/tests/test_supervisor_async.py` | `test_dispatcher_cli_quiet_suppresses_final_summary` | def | named | 206 | *RepoVerified* |
| `vibecrafted-core/tests/test_supervisor_async.py` | `test_dispatcher_cli_runs_full_lifecycle` | def | named | 74 | *RepoVerified* |
| `vibecrafted-core/tests/test_supervisor_async.py` | `test_dispatcher_cli_tees_visible_worker_output` | def | named | 165 | *RepoVerified* |
| `vibecrafted-core/tests/test_supervisor_async.py` | `test_lifecycle_transition_table_rejects_backwards_transition` | def | named | 15 | *RepoVerified* |
| `vibecrafted-core/tests/test_ui.py` | `test_bounded_collapses_long_lists` | def | named | 51 | *RepoVerified* |
| `vibecrafted-core/tests/test_ui.py` | `test_err_shape_goes_to_stderr_with_fix_and_log` | def | named | 26 | *RepoVerified* |
| `vibecrafted-core/tests/test_ui.py` | `test_glyph_is_the_prefix_no_bracket_tags` | def | named | 17 | *RepoVerified* |
| `vibecrafted-core/tests/test_ui.py` | `test_no_color_strips_ansi` | def | named | 43 | *RepoVerified* |
| `vibecrafted-core/tests/test_ui.py` | `test_spinner_non_tty_prints_single_stage_line` | def | named | 59 | *RepoVerified* |
| `vibecrafted-core/tests/test_workflow.py` | `test_artifact_org_repo_reads_git_config_with_duplicate_options` | def | named | 84 | *RepoVerified* |
| `vibecrafted-core/tests/test_workflow.py` | `test_artifact_slug_skips_boilerplate_research_words` | def | named | 75 | *RepoVerified* |
| `vibecrafted-core/tests/test_workflow.py` | `test_block_run_marks_active_run_blocked` | def | named | 565 | *RepoVerified* |
| `vibecrafted-core/tests/test_workflow.py` | `test_block_run_rejects_terminal_run` | def | named | 597 | *RepoVerified* |
| `vibecrafted-core/tests/test_workflow.py` | `test_build_launch_command_uses_core_stdin_agent_command_not_legacy_deck` | def | named | 664 | *RepoVerified* |
| `vibecrafted-core/tests/test_workflow.py` | `test_claude_terminal_command_streams_visible_json` | def | named | 333 | *RepoVerified* |
| `vibecrafted-core/tests/test_workflow.py` | `test_launch_workflow_artifact_paths_are_terminal_truth` | def | named | 394 | *RepoVerified* |
| `vibecrafted-core/tests/test_workflow.py` | `test_launch_workflow_keeps_dispatcher_launch_even_if_worker_command_is_bad` | def | named | 138 | *RepoVerified* |
| `vibecrafted-core/tests/test_workflow.py` | `test_launch_workflow_returns_pid_and_logs_spawn` | def | named | 101 | *RepoVerified* |
| `vibecrafted-core/tests/test_workflow.py` | `test_marbles_uses_supervised_core_runtime` | def | named | 712 | *RepoVerified* |
| `vibecrafted-core/tests/test_workflow.py` | `test_normalize_launch_spec_maps_justdo_to_implement` | def | named | 65 | *RepoVerified* |
| `vibecrafted-core/tests/test_workflow.py` | `test_normalize_launch_spec_prune_without_input_uses_discovery_prompt` | def | named | 33 | *RepoVerified* |
| `vibecrafted-core/tests/test_workflow.py` | `test_normalize_launch_spec_requires_prompt_or_file` | def | named | 28 | *RepoVerified* |
| `vibecrafted-core/tests/test_workflow.py` | `test_normalize_launch_spec_uses_registry_for_marbles_defaults` | def | named | 52 | *RepoVerified* |
| `vibecrafted-core/tests/test_workflow.py` | `test_research_swarm_uses_core_codex_coordinator` | def | named | 695 | *RepoVerified* |
| `vibecrafted-core/tests/test_workflow.py` | `test_research_terminal_runtime_uses_vc_frame_research_layout` | def | named | 237 | *RepoVerified* |
| `vibecrafted-core/tests/test_workflow.py` | `test_retry_run_relaunches_terminal_run` | def | named | 617 | *RepoVerified* |
| `vibecrafted-core/tests/test_workflow.py` | `test_runtime_prompt_keeps_metadata_runtime_owned` | def | named | 376 | *RepoVerified* |
| `vibecrafted-core/tests/test_workflow.py` | `test_stop_run_records_already_dead_launcher_without_error` | def | named | 501 | *RepoVerified* |
| `vibecrafted-core/tests/test_workflow.py` | `test_stop_run_terminal_record_is_noop` | def | named | 533 | *RepoVerified* |
| `vibecrafted-core/tests/test_workflow.py` | `test_stop_run_terms_live_launcher_process_group` | def | named | 458 | *RepoVerified* |
| `vibecrafted-core/tests/test_workflow.py` | `test_stream_capable_agents_use_native_stream_commands` | def | named | 351 | *RepoVerified* |
| `vibecrafted-core/tests/test_workflow.py` | `test_terminal_runtime_launches_worker_in_vc_frame_tab` | def | named | 163 | *RepoVerified* |
| `vibecrafted-core/tests/test_workflow_registry.py` | `test_prune_default_prompt_can_be_overridden` | def | named | 72 | *RepoVerified* |
| `vibecrafted-core/tests/test_workflow_registry.py` | `test_prune_default_prompt_is_runtime_workflow_asset` | def | named | 58 | *RepoVerified* |
| `vibecrafted-core/tests/test_workflow_registry.py` | `test_registry_classifies_workflow_runtime_kinds` | def | named | 15 | *RepoVerified* |
| `vibecrafted-core/tests/test_workflow_registry.py` | `test_registry_keeps_supported_workflows_explicit` | def | named | 9 | *RepoVerified* |
| `vibecrafted-core/tests/test_workflow_registry.py` | `test_registry_models_input_policy` | def | named | 23 | *RepoVerified* |
| `vibecrafted-core/tests/test_workflow_registry.py` | `test_registry_models_read_write_lifecycle` | def | named | 38 | *RepoVerified* |
| `vibecrafted-core/tests/test_workflow_runtime.py` | `test_marbles_runtime_supervises_loops` | def | named | 306 | *RepoVerified* |
| `vibecrafted-core/tests/test_workflow_runtime.py` | `test_research_runtime_env_agents_override_user_config` | def | named | 123 | *RepoVerified* |
| `vibecrafted-core/tests/test_workflow_runtime.py` | `test_research_runtime_supervises_three_tracks` | def | named | 42 | *RepoVerified* |
| `vibecrafted-core/tests/test_workflow_runtime.py` | `test_research_runtime_tees_child_output` | def | named | 287 | *RepoVerified* |
| `vibecrafted-core/tests/test_workflow_runtime.py` | `test_research_runtime_uses_user_configured_agents` | def | named | 68 | *RepoVerified* |
| `vibecrafted-core/tests/test_workflow_runtime.py` | `test_research_runtime_writes_canonical_named_lane_artifacts` | def | named | 94 | *RepoVerified* |
| `vibecrafted-core/tests/test_workflow_runtime.py` | `test_research_synthesis_closes_when_lane_failed` | def | named | 239 | *RepoVerified* |
| `vibecrafted-core/tests/test_workflow_runtime.py` | `test_research_synthesis_recovers_legacy_lane_meta_without_exit_code` | def | named | 198 | *RepoVerified* |
| `vibecrafted-core/tests/test_workflow_runtime.py` | `test_research_synthesis_waits_for_lane_meta_and_resumes_last_finisher` | def | named | 148 | *RepoVerified* |
| `vibecrafted-core/tests/test_wrappers.py` | `test_resume_main_routes_captured_session_through_zellij_aware_resume_helper` | def | named | 11 | *RepoVerified* |
| `vibecrafted-core/tests/test_wrappers.py` | `test_stop_main_prints_success_for_stopped_run` | def | named | 55 | *RepoVerified* |
| `vibecrafted-core/tests/test_wrappers.py` | `test_stop_main_terminal_noop_is_success` | def | named | 83 | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/__init__.py` | `Any` | reexport | named | 3 | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/__init__.py` | `ArtifactValidation` | reexport | named | 25 | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/__init__.py` | `AsyncRunHandle` | reexport | named | 39 | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/__init__.py` | `AsyncSupervisor` | reexport | named | 39 | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/__init__.py` | `Event` | reexport | named | 5 | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/__init__.py` | `EventKind` | reexport | named | 26 | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/__init__.py` | `RunState` | reexport | named | 26 | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/__init__.py` | `RunStatus` | reexport | named | 5 | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/__init__.py` | `ToolCapability` | reexport | named | 18 | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/__init__.py` | `WorkflowLaunchSpec` | __all__ | named |  | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/__init__.py` | `annotations` | reexport | named | 1 | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/__init__.py` | `append_event` | reexport | named | 17 | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/__init__.py` | `await_launch_truth` | __all__ | named |  | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/__init__.py` | `await_run` | reexport | named | 5 | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/__init__.py` | `build_launch_command` | __all__ | named |  | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/__init__.py` | `control_plane_home` | reexport | named | 5 | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/__init__.py` | `doctor_run` | reexport | named | 23 | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/__init__.py` | `doctor_summary` | reexport | named | 23 | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/__init__.py` | `event_stream_path` | reexport | named | 5 | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/__init__.py` | `foundation_capabilities` | reexport | named | 18 | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/__init__.py` | `is_final_state` | reexport | named | 26 | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/__init__.py` | `is_negative_state` | reexport | named | 26 | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/__init__.py` | `launch_workflow` | __all__ | named |  | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/__init__.py` | `lookup_run` | reexport | named | 5 | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/__init__.py` | `normalize_launch_spec` | __all__ | named |  | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/__init__.py` | `probe_tool` | reexport | named | 18 | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/__init__.py` | `read_event_tail` | reexport | named | 5 | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/__init__.py` | `read_version_file` | reexport | named | 33 | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/__init__.py` | `repo_full` | reexport | named | 24 | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/__init__.py` | `repo_full_summary` | reexport | named | 24 | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/__init__.py` | `resolve_env_path` | reexport | named | 33 | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/__init__.py` | `retry_run` | __all__ | named |  | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/__init__.py` | `run_snapshot_dir` | reexport | named | 5 | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/__init__.py` | `stop_run` | __all__ | named |  | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/__init__.py` | `subscribe_events` | reexport | named | 5 | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/__init__.py` | `sync_state` | reexport | named | 5 | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/__init__.py` | `transition_allowed` | reexport | named | 26 | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/__init__.py` | `validate_artifacts` | reexport | named | 25 | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/__init__.py` | `vibecrafted_home` | reexport | named | 33 | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/__init__.py` | `vibecrafted_launcher` | __all__ | named |  | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/__init__.py` | `xdg_config_home` | reexport | named | 33 | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/agent_dispatch.py` | `ParityError` | class | named | 43 | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/agent_dispatch.py` | `check_parity` | def | named | 206 | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/agent_dispatch.py` | `detect_parent_model` | def | named | 83 | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/agent_dispatch.py` | `extract_session_id` | def | named | 97 | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/agent_dispatch.py` | `normalize_model` | def | named | 118 | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/agent_dispatch.py` | `require_parity` | def | named | 254 | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/agent_dispatch.py` | `sandbox_supported` | def | named | 113 | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/agent_dispatch.py` | `tier_family` | def | named | 201 | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/agent_dispatch.py` | `tier_rank` | def | named | 196 | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/agent_stream.py` | `AgentStreamParser` | class | named | 157 | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/agent_stream.py` | `is_grok_ignorable_transport_error` | def | named | 73 | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/agent_stream.py` | `resolve_default_model` | def | named | 138 | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/agent_stream.py` | `stamp` | def | named | 38 | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/agent_stream.py` | `tool_tag` | def | named | 42 | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/aicx_sync.py` | `AicxChunk` | class | named | 199 | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/aicx_sync.py` | `AicxSyncEngine` | class | named | 482 | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/aicx_sync.py` | `Authority` | class | named | 129 | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/aicx_sync.py` | `ConflictTie` | class | named | 231 | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/aicx_sync.py` | `DEFAULT_CONFLICT_LOG` | __all__ | named |  | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/aicx_sync.py` | `SyncPlan` | class | named | 257 | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/aicx_sync.py` | `SyncResult` | class | named | 294 | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/aicx_sync.py` | `authority_rank` | def | named | 185 | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/aicx_sync.py` | `normalize_authority` | def | named | 160 | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/artifacts.py` | `ArtifactValidation` | class | named | 10 | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/artifacts.py` | `validate_artifacts` | def | named | 85 | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/capabilities.py` | `ProbeResult` | class | named | 55 | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/capabilities.py` | `ToolCapability` | class | named | 65 | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/capabilities.py` | `foundation_capabilities` | def | named | 304 | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/capabilities.py` | `probe_tool` | def | named | 220 | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/cli.py` | `main` | def | named | 353 | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/compact_hooks.py` | `append_journal` | def | named | 223 | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/compact_hooks.py` | `clean_context` | def | named | 337 | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/compact_hooks.py` | `codex_session_path_for` | def | named | 106 | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/compact_hooks.py` | `codex_sessions_dir` | def | named | 34 | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/compact_hooks.py` | `compact_state_path` | def | named | 154 | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/compact_hooks.py` | `dedupe_adjacent` | def | named | 326 | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/compact_hooks.py` | `delta_lines` | def | named | 181 | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/compact_hooks.py` | `emit_postcompact_context` | def | named | 211 | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/compact_hooks.py` | `extract_candidates` | def | named | 290 | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/compact_hooks.py` | `fallback` | def | named | 341 | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/compact_hooks.py` | `hook_agent` | def | named | 28 | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/compact_hooks.py` | `hook_project_dir` | def | named | 50 | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/compact_hooks.py` | `latest_codex_session_path` | def | named | 88 | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/compact_hooks.py` | `load_compact_state` | def | named | 163 | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/compact_hooks.py` | `load_hook_input` | def | named | 20 | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/compact_hooks.py` | `main` | def | named | 464 | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/compact_hooks.py` | `normalize_path` | def | named | 41 | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/compact_hooks.py` | `postcompact` | def | named | 363 | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/compact_hooks.py` | `precompact` | def | named | 273 | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/compact_hooks.py` | `resolve_session_id` | def | named | 121 | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/compact_hooks.py` | `run_aicx_extract` | def | named | 254 | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/compact_hooks.py` | `save_compact_state` | def | named | 172 | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/compact_hooks.py` | `session_id_from_jsonl` | def | named | 84 | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/compact_hooks.py` | `session_meta_from_jsonl` | def | named | 62 | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/compact_hooks.py` | `strip_skill_bodies` | def | named | 309 | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/compact_hooks.py` | `utc_now` | def | named | 16 | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/control_plane.py` | `Event` | class | named | 114 | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/control_plane.py` | `RunStatus` | class | named | 87 | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/control_plane.py` | `await_run` | def | named | 1206 | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/control_plane.py` | `cli` | def | named | 1249 | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/control_plane.py` | `control_plane_home` | def | named | 123 | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/control_plane.py` | `ensure_session_id` | def | named | 216 | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/control_plane.py` | `event_stream_path` | def | named | 131 | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/control_plane.py` | `lookup_run` | def | named | 1200 | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/control_plane.py` | `normalize_run_root` | def | named | 207 | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/control_plane.py` | `operator_session_name` | def | named | 498 | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/control_plane.py` | `read_event_tail` | def | named | 1076 | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/control_plane.py` | `record_stop_transition` | def | named | 966 | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/control_plane.py` | `run_snapshot_dir` | def | named | 127 | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/control_plane.py` | `subscribe_events` | def | named | 1089 | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/control_plane.py` | `sync_state` | def | named | 1133 | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/cron.py` | `append_jsonl` | def | named | 88 | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/cron.py` | `capture_context` | def | named | 170 | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/cron.py` | `cron_line` | def | named | 293 | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/cron.py` | `default_journal` | def | named | 84 | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/cron.py` | `default_state_file` | def | named | 80 | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/cron.py` | `hard_stop_reason` | def | named | 96 | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/cron.py` | `idle_minutes` | def | named | 71 | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/cron.py` | `iso_now` | def | named | 35 | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/cron.py` | `main` | def | named | 361 | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/cron.py` | `parse_frontmatter` | def | named | 39 | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/cron.py` | `parse_time` | def | named | 56 | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/cron.py` | `run_capture` | def | named | 104 | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/cron.py` | `run_capture_candidates` | def | named | 138 | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/cron.py` | `tick` | def | named | 215 | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/cron.py` | `utc_now` | def | named | 31 | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/dispatch/__init__.py` | `Baton` | reexport | named | 3 | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/dispatch/__init__.py` | `CellRun` | reexport | named | 25 | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/dispatch/__init__.py` | `Common` | reexport | named | 3 | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/dispatch/__init__.py` | `Cut` | reexport | named | 3 | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/dispatch/__init__.py` | `CutState` | reexport | named | 3 | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/dispatch/__init__.py` | `DEFAULT_TIMEOUT_S` | reexport | named | 32 | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/dispatch/__init__.py` | `Dispatch` | reexport | named | 3 | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/dispatch/__init__.py` | `DispatchResult` | reexport | named | 25 | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/dispatch/__init__.py` | `DispatchSchemaError` | reexport | named | 18 | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/dispatch/__init__.py` | `DispatchSupervisor` | reexport | named | 25 | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/dispatch/__init__.py` | `MATCHER_FAIL` | reexport | named | 32 | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/dispatch/__init__.py` | `MATCHER_PASS` | reexport | named | 32 | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/dispatch/__init__.py` | `MATCHER_TIMEOUT` | reexport | named | 32 | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/dispatch/__init__.py` | `Matcher` | reexport | named | 3 | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/dispatch/__init__.py` | `Meta` | reexport | named | 3 | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/dispatch/__init__.py` | `Phase` | reexport | named | 3 | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/dispatch/__init__.py` | `Policy` | reexport | named | 3 | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/dispatch/__init__.py` | `Recovery` | reexport | named | 3 | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/dispatch/__init__.py` | `Verdict` | reexport | named | 3 | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/dispatch/__init__.py` | `VerifierEvidence` | reexport | named | 3 | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/dispatch/__init__.py` | `Verify` | reexport | named | 3 | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/dispatch/__init__.py` | `annotations` | reexport | named | 1 | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/dispatch/__init__.py` | `doctor_dispatch` | reexport | named | 18 | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/dispatch/__init__.py` | `load_dispatch` | reexport | named | 18 | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/dispatch/__init__.py` | `parse_dispatch` | reexport | named | 18 | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/dispatch/__init__.py` | `render_cell_prompt` | reexport | named | 18 | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/dispatch/__init__.py` | `run_dispatch` | reexport | named | 25 | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/dispatch/__init__.py` | `run_verifies` | reexport | named | 32 | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/dispatch/__init__.py` | `sanitize_env` | reexport | named | 32 | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/dispatch/__init__.py` | `workflow_cell_launcher` | reexport | named | 25 | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/dispatch/cli.py` | `main` | def | named | 48 | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/dispatch/doctor.py` | `DoctorError` | class | named | 14 | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/dispatch/doctor.py` | `DoctorReport` | class | named | 23 | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/dispatch/doctor.py` | `diagnose_file` | def | named | 41 | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/dispatch/doctor.py` | `diagnose_text` | def | named | 35 | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/dispatch/doctor.py` | `main` | def | named | 54 | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/dispatch/model.py` | `Baton` | class | named | 203 | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/dispatch/model.py` | `Common` | class | named | 44 | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/dispatch/model.py` | `Cut` | class | named | 107 | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/dispatch/model.py` | `CutState` | class | named | 175 | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/dispatch/model.py` | `Dispatch` | class | named | 245 | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/dispatch/model.py` | `Matcher` | class | named | 55 | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/dispatch/model.py` | `Meta` | class | named | 23 | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/dispatch/model.py` | `Phase` | class | named | 49 | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/dispatch/model.py` | `Policy` | class | named | 33 | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/dispatch/model.py` | `Recovery` | class | named | 100 | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/dispatch/model.py` | `Verdict` | class | named | 147 | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/dispatch/model.py` | `VerifierEvidence` | class | named | 125 | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/dispatch/model.py` | `Verify` | class | named | 85 | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/dispatch/model.py` | `matchers_from_expect` | def | named | 73 | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/dispatch/schema.py` | `DispatchDoctorResult` | class | named | 45 | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/dispatch/schema.py` | `DispatchSchemaError` | class | named | 51 | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/dispatch/schema.py` | `doctor_dispatch` | def | named | 62 | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/dispatch/schema.py` | `load_dispatch` | def | named | 57 | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/dispatch/schema.py` | `parse_dispatch` | def | named | 83 | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/dispatch/schema.py` | `render_cell_prompt` | def | named | 134 | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/dispatch/schema.py` | `render_cut_verifies` | def | named | 154 | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/dispatch/supervisor.py` | `AwaitOutcome` | class | named | 62 | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/dispatch/supervisor.py` | `CellRun` | class | named | 40 | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/dispatch/supervisor.py` | `DispatchResult` | class | named | 72 | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/dispatch/supervisor.py` | `DispatchSupervisor` | class | named | 125 | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/dispatch/supervisor.py` | `run_dispatch` | def | named | 761 | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/dispatch/supervisor.py` | `workflow_cell_launcher` | def | named | 92 | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/dispatch/verify.py` | `run_verifies` | def | named | 59 | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/dispatch/verify.py` | `sanitize_env` | def | named | 46 | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/dispatch_contract.py` | `DispatchCommon` | class | named | 47 | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/dispatch_contract.py` | `DispatchContract` | class | named | 95 | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/dispatch_contract.py` | `DispatchContractError` | class | named | 112 | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/dispatch_contract.py` | `DispatchCut` | class | named | 77 | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/dispatch_contract.py` | `DispatchDoctorResult` | class | named | 106 | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/dispatch_contract.py` | `DispatchMatcher` | class | named | 58 | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/dispatch_contract.py` | `DispatchMeta` | class | named | 26 | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/dispatch_contract.py` | `DispatchPhase` | class | named | 52 | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/dispatch_contract.py` | `DispatchPolicy` | class | named | 36 | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/dispatch_contract.py` | `DispatchRecovery` | class | named | 70 | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/dispatch_contract.py` | `DispatchVerify` | class | named | 64 | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/dispatch_contract.py` | `doctor_dispatch_contract` | def | named | 125 | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/dispatch_contract.py` | `load_dispatch_contract` | def | named | 118 | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/dispatch_contract.py` | `parse_dispatch_contract` | def | named | 138 | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/dispatcher.py` | `main` | def | named | 113 | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/doctor.py` | `doctor_run` | def | named | 52 | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/doctor.py` | `doctor_summary` | def | named | 69 | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/events.py` | `append_event` | def | named | 6 | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/git.py` | `repo_full` | def | named | 131 | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/git.py` | `repo_full_summary` | def | named | 173 | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/lifecycle.py` | `EventKind` | class | named | 32 | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/lifecycle.py` | `RunState` | class | named | 6 | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/lifecycle.py` | `coerce_state` | def | named | 156 | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/lifecycle.py` | `is_final_state` | def | named | 162 | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/lifecycle.py` | `is_negative_state` | def | named | 166 | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/lifecycle.py` | `transition_allowed` | def | named | 170 | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/loop.py` | `LoopState` | class | named | 39 | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/loop.py` | `cmd_await_run` | def | named | 220 | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/loop.py` | `cmd_cancel` | def | named | 162 | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/loop.py` | `cmd_complete` | def | named | 173 | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/loop.py` | `cmd_next` | def | named | 191 | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/loop.py` | `cmd_start` | def | named | 109 | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/loop.py` | `cmd_status` | def | named | 155 | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/loop.py` | `command_deck` | def | named | 105 | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/loop.py` | `default_state_file` | def | named | 34 | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/loop.py` | `main` | def | named | 322 | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/loop.py` | `parse_state` | def | named | 63 | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/loop.py` | `quote_yaml` | def | named | 57 | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/loop.py` | `repo_root` | def | named | 21 | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/loop.py` | `resolve_state_file` | def | named | 96 | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/loop.py` | `update_field` | def | named | 90 | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/loop.py` | `utc_now` | def | named | 17 | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/loop.py` | `write_state` | def | named | 81 | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/memex_client.py` | `DEFAULT_CONFIG_PATH` | __all__ | named |  | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/memex_client.py` | `DEFAULT_ENDPOINT` | __all__ | named |  | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/memex_client.py` | `DEFAULT_TIMEOUT_SECONDS` | __all__ | named |  | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/memex_client.py` | `MEMEX_AUTHORITY_LABEL` | __all__ | named |  | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/memex_client.py` | `MemexChunk` | class | named | 92 | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/memex_client.py` | `MemexClientError` | class | named | 132 | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/memex_client.py` | `MemexConfig` | class | named | 109 | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/memex_client.py` | `SPARSE_AICX_THRESHOLD` | __all__ | named |  | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/memex_client.py` | `load_config` | def | named | 166 | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/memex_client.py` | `search` | def | named | 353 | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/runtime_paths.py` | `read_version_file` | def | named | 7 | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/runtime_paths.py` | `resolve_env_path` | def | named | 14 | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/runtime_paths.py` | `vibecrafted_home` | def | named | 29 | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/runtime_paths.py` | `vibecrafted_launcher_bin` | def | named | 52 | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/runtime_paths.py` | `vibecrafted_runtime_bin` | def | named | 46 | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/runtime_paths.py` | `vibecrafted_runtime_home` | def | named | 35 | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/runtime_paths.py` | `vibecrafted_tools_home` | def | named | 39 | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/runtime_paths.py` | `xdg_config_home` | def | named | 21 | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/runtime_paths.py` | `xdg_data_home` | def | named | 25 | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/sandbox/__init__.py` | `ExecResult` | reexport | named | 3 | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/sandbox/__init__.py` | `MsbserverLifecycle` | reexport | named | 4 | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/sandbox/__init__.py` | `SandboxAdapter` | reexport | named | 3 | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/sandbox/__init__.py` | `SandboxPolicy` | reexport | named | 5 | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/sandbox/__init__.py` | `annotations` | reexport | named | 1 | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/sandbox/adapter.py` | `ExecResult` | class | named | 20 | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/sandbox/adapter.py` | `SandboxAdapter` | class | named | 27 | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/sandbox/msbserver_lifecycle.py` | `MsbserverLifecycle` | class | named | 15 | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/sandbox/policy.py` | `SandboxPolicy` | class | named | 12 | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/sandbox/policy.py` | `default_policy_path` | def | named | 69 | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/ship.py` | `build_ship_prompt` | def | named | 18 | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/ship.py` | `deck_command` | def | named | 14 | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/ship.py` | `main` | def | named | 38 | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/spawn.py` | `SpawnHandle` | class | named | 62 | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/spawn.py` | `Supervisor` | class | named | 821 | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/spawn.py` | `finalize_artifacts` | def | named | 679 | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/spawn.py` | `finish_meta` | def | named | 439 | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/spawn.py` | `main` | def | named | 1110 | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/spawn.py` | `write_meta` | def | named | 386 | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/supervisor_async.py` | `AsyncRunHandle` | class | named | 157 | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/supervisor_async.py` | `AsyncSupervisor` | class | named | 187 | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/ui.py` | `Spinner` | class | named | 87 | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/ui.py` | `bounded` | def | named | 80 | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/ui.py` | `err` | def | named | 61 | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/ui.py` | `next_step` | def | named | 71 | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/ui.py` | `ok` | def | named | 51 | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/ui.py` | `stage` | def | named | 46 | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/ui.py` | `warn` | def | named | 56 | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/workflow.py` | `WorkflowLaunchSpec` | class | named | 52 | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/workflow.py` | `vibecrafted_launcher` | def | named | 67 | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/workflow_runtime.py` | `ChildResult` | class | named | 23 | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/workflow_runtime.py` | `ResearchAgentSelection` | class | named | 43 | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/workflow_runtime.py` | `research_agent_selection` | def | named | 265 | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/workflows/__init__.py` | `SUPPORTED_WORKFLOWS` | reexport | named | 4 | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/workflows/__init__.py` | `WORKFLOW_ALIASES` | reexport | named | 4 | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/workflows/__init__.py` | `WorkflowDefinition` | reexport | named | 3 | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/workflows/__init__.py` | `annotations` | reexport | named | 1 | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/workflows/__init__.py` | `workflow_default_prompt` | reexport | named | 4 | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/workflows/__init__.py` | `workflow_definition` | reexport | named | 4 | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/workflows/__init__.py` | `workflow_lifecycle` | reexport | named | 4 | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/workflows/__init__.py` | `workflow_runtime_kind` | reexport | named | 4 | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/workflows/model.py` | `WorkflowDefinition` | class | named | 16 | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/workflows/registry.py` | `workflow_default_prompt` | def | named | 193 | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/workflows/registry.py` | `workflow_definition` | def | named | 154 | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/workflows/registry.py` | `workflow_lifecycle` | def | named | 164 | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/workflows/registry.py` | `workflow_runtime_kind` | def | named | 159 | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/wrappers.py` | `agents_main` | def | named | 163 | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/wrappers.py` | `deck_path` | def | named | 33 | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/wrappers.py` | `followup_main` | def | named | 167 | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/wrappers.py` | `implement_main` | def | named | 171 | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/wrappers.py` | `marbles_main` | def | named | 175 | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/wrappers.py` | `prune_main` | def | named | 179 | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/wrappers.py` | `repo_root` | def | named | 29 | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/wrappers.py` | `research_await_main` | def | named | 270 | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/wrappers.py` | `research_main` | def | named | 221 | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/wrappers.py` | `research_synthesize_main` | def | named | 291 | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/wrappers.py` | `resume_main` | def | named | 324 | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/wrappers.py` | `review_main` | def | named | 183 | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/wrappers.py` | `sandbox_main` | def | named | 397 | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/wrappers.py` | `scaffold_main` | def | named | 187 | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/wrappers.py` | `stop_main` | def | named | 349 | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/wrappers.py` | `supervised_skill_main` | def | named | 106 | *RepoVerified* |

### Imports

| File | Source | Kind | Resolution | Authority |
|---|---|---|---|---|
| `vibecrafted-core/tests/conftest.py` | `__future__` | static | unknown | *RepoVerified* |
| `vibecrafted-core/tests/conftest.py` | `pathlib` | static | stdlib | *RepoVerified* |
| `vibecrafted-core/tests/conftest.py` | `sys` | static | stdlib | *RepoVerified* |
| `vibecrafted-core/tests/dispatch/test_cli.py` | `__future__` | static | unknown | *RepoVerified* |
| `vibecrafted-core/tests/dispatch/test_cli.py` | `pathlib` | static | stdlib | *RepoVerified* |
| `vibecrafted-core/tests/dispatch/test_cli.py` | `vibecrafted_core` | static | local | *RepoVerified* |
| `vibecrafted-core/tests/dispatch/test_cli.py` | `vibecrafted_core.dispatch` | static | local | *RepoVerified* |
| `vibecrafted-core/tests/dispatch/test_cli.py` | `json` | static | stdlib | *RepoVerified* |
| `vibecrafted-core/tests/dispatch/test_cli.py` | `subprocess` | static | stdlib | *RepoVerified* |
| `vibecrafted-core/tests/dispatch/test_doctor.py` | `__future__` | static | unknown | *RepoVerified* |
| `vibecrafted-core/tests/dispatch/test_doctor.py` | `pathlib` | static | stdlib | *RepoVerified* |
| `vibecrafted-core/tests/dispatch/test_doctor.py` | `vibecrafted_core.dispatch.doctor` | static | local | *RepoVerified* |
| `vibecrafted-core/tests/dispatch/test_doctor.py` | `pytest` | static | unknown | *RepoVerified* |
| `vibecrafted-core/tests/dispatch/test_schema.py` | `__future__` | static | unknown | *RepoVerified* |
| `vibecrafted-core/tests/dispatch/test_schema.py` | `pathlib` | static | stdlib | *RepoVerified* |
| `vibecrafted-core/tests/dispatch/test_schema.py` | `vibecrafted_core.dispatch.model` | static | local | *RepoVerified* |
| `vibecrafted-core/tests/dispatch/test_schema.py` | `vibecrafted_core.dispatch.schema` | static | local | *RepoVerified* |
| `vibecrafted-core/tests/dispatch/test_schema.py` | `pytest` | static | unknown | *RepoVerified* |
| `vibecrafted-core/tests/dispatch/test_supervisor.py` | `__future__` | static | unknown | *RepoVerified* |
| `vibecrafted-core/tests/dispatch/test_supervisor.py` | `dataclasses` | static | stdlib | *RepoVerified* |
| `vibecrafted-core/tests/dispatch/test_supervisor.py` | `pathlib` | static | stdlib | *RepoVerified* |
| `vibecrafted-core/tests/dispatch/test_supervisor.py` | `vibecrafted_core` | static | local | *RepoVerified* |
| `vibecrafted-core/tests/dispatch/test_supervisor.py` | `vibecrafted_core.dispatch.model` | static | local | *RepoVerified* |
| `vibecrafted-core/tests/dispatch/test_supervisor.py` | `vibecrafted_core.dispatch.schema` | static | local | *RepoVerified* |
| `vibecrafted-core/tests/dispatch/test_supervisor.py` | `vibecrafted_core.dispatch.supervisor` | static | local | *RepoVerified* |
| `vibecrafted-core/tests/dispatch/test_supervisor.py` | `json` | static | stdlib | *RepoVerified* |
| `vibecrafted-core/tests/dispatch/test_supervisor.py` | `pytest` | static | unknown | *RepoVerified* |
| `vibecrafted-core/tests/dispatch/test_supervisor.py` | `shlex` | static | stdlib | *RepoVerified* |
| `vibecrafted-core/tests/dispatch/test_supervisor.py` | `subprocess` | static | stdlib | *RepoVerified* |
| `vibecrafted-core/tests/dispatch/test_verify.py` | `__future__` | static | unknown | *RepoVerified* |
| `vibecrafted-core/tests/dispatch/test_verify.py` | `pathlib` | static | stdlib | *RepoVerified* |
| `vibecrafted-core/tests/dispatch/test_verify.py` | `vibecrafted_core.dispatch.model` | static | local | *RepoVerified* |
| `vibecrafted-core/tests/dispatch/test_verify.py` | `vibecrafted_core.dispatch.verify` | static | local | *RepoVerified* |
| `vibecrafted-core/tests/dispatch/test_verify.py` | `json` | static | stdlib | *RepoVerified* |
| `vibecrafted-core/tests/dispatch/test_verify.py` | `pytest` | static | unknown | *RepoVerified* |
| `vibecrafted-core/tests/test_agent_stream.py` | `__future__` | static | unknown | *RepoVerified* |
| `vibecrafted-core/tests/test_agent_stream.py` | `vibecrafted_core.agent_stream` | static | local | *RepoVerified* |
| `vibecrafted-core/tests/test_agent_stream.py` | `vibecrafted_core.spawn` | static | local | *RepoVerified* |
| `vibecrafted-core/tests/test_agy_junie_pipeline.py` | `__future__` | static | unknown | *RepoVerified* |
| `vibecrafted-core/tests/test_agy_junie_pipeline.py` | `pathlib` | static | stdlib | *RepoVerified* |
| `vibecrafted-core/tests/test_agy_junie_pipeline.py` | `vibecrafted_core` | static | local | *RepoVerified* |
| `vibecrafted-core/tests/test_agy_junie_pipeline.py` | `vibecrafted_core.agent_dispatch` | static | local | *RepoVerified* |
| `vibecrafted-core/tests/test_agy_junie_pipeline.py` | `vibecrafted_core.spawn` | static | local | *RepoVerified* |
| `vibecrafted-core/tests/test_aicx_sync.py` | `__future__` | static | unknown | *RepoVerified* |
| `vibecrafted-core/tests/test_aicx_sync.py` | `pathlib` | static | stdlib | *RepoVerified* |
| `vibecrafted-core/tests/test_aicx_sync.py` | `typing` | static | stdlib | *RepoVerified* |
| `vibecrafted-core/tests/test_aicx_sync.py` | `vibecrafted_core` | static | local | *RepoVerified* |
| `vibecrafted-core/tests/test_aicx_sync.py` | `json` | static | stdlib | *RepoVerified* |
| `vibecrafted-core/tests/test_aicx_sync.py` | `pytest` | static | unknown | *RepoVerified* |
| `vibecrafted-core/tests/test_capabilities.py` | `__future__` | static | unknown | *RepoVerified* |
| `vibecrafted-core/tests/test_capabilities.py` | `pathlib` | static | stdlib | *RepoVerified* |
| `vibecrafted-core/tests/test_capabilities.py` | `typing` | static | stdlib | *RepoVerified* |
| `vibecrafted-core/tests/test_capabilities.py` | `vibecrafted_core` | static | local | *RepoVerified* |
| `vibecrafted-core/tests/test_capabilities.py` | `pytest` | static | unknown | *RepoVerified* |
| `vibecrafted-core/tests/test_cli.py` | `__future__` | static | unknown | *RepoVerified* |
| `vibecrafted-core/tests/test_cli.py` | `pathlib` | static | stdlib | *RepoVerified* |
| `vibecrafted-core/tests/test_cli.py` | `types` | static | stdlib | *RepoVerified* |
| `vibecrafted-core/tests/test_cli.py` | `vibecrafted_core` | static | local | *RepoVerified* |
| `vibecrafted-core/tests/test_compact_hooks.py` | `__future__` | static | unknown | *RepoVerified* |
| `vibecrafted-core/tests/test_compact_hooks.py` | `pathlib` | static | stdlib | *RepoVerified* |
| `vibecrafted-core/tests/test_compact_hooks.py` | `vibecrafted_core` | static | local | *RepoVerified* |
| `vibecrafted-core/tests/test_compact_hooks.py` | `json` | static | stdlib | *RepoVerified* |
| `vibecrafted-core/tests/test_control_plane.py` | `__future__` | static | unknown | *RepoVerified* |
| `vibecrafted-core/tests/test_control_plane.py` | `pathlib` | static | stdlib | *RepoVerified* |
| `vibecrafted-core/tests/test_control_plane.py` | `vibecrafted_core` | static | local | *RepoVerified* |
| `vibecrafted-core/tests/test_control_plane.py` | `vibecrafted_core` | static | local | *RepoVerified* |
| `vibecrafted-core/tests/test_control_plane.py` | `json` | static | stdlib | *RepoVerified* |
| `vibecrafted-core/tests/test_control_plane.py` | `os` | static | stdlib | *RepoVerified* |
| `vibecrafted-core/tests/test_control_plane.py` | `pytest` | static | unknown | *RepoVerified* |
| `vibecrafted-core/tests/test_control_plane.py` | `uuid` | static | stdlib | *RepoVerified* |
| `vibecrafted-core/tests/test_cron.py` | `__future__` | static | unknown | *RepoVerified* |
| `vibecrafted-core/tests/test_cron.py` | `datetime` | static | stdlib | *RepoVerified* |
| `vibecrafted-core/tests/test_cron.py` | `pathlib` | static | stdlib | *RepoVerified* |
| `vibecrafted-core/tests/test_cron.py` | `vibecrafted_core` | static | local | *RepoVerified* |
| `vibecrafted-core/tests/test_cron.py` | `json` | static | stdlib | *RepoVerified* |
| `vibecrafted-core/tests/test_dispatch_contract.py` | `__future__` | static | unknown | *RepoVerified* |
| `vibecrafted-core/tests/test_dispatch_contract.py` | `pathlib` | static | stdlib | *RepoVerified* |
| `vibecrafted-core/tests/test_dispatch_contract.py` | `vibecrafted_core.dispatch_contract` | static | local | *RepoVerified* |
| `vibecrafted-core/tests/test_dispatch_contract.py` | `pytest` | static | unknown | *RepoVerified* |
| `vibecrafted-core/tests/test_doctor.py` | `__future__` | static | unknown | *RepoVerified* |
| `vibecrafted-core/tests/test_doctor.py` | `pathlib` | static | stdlib | *RepoVerified* |
| `vibecrafted-core/tests/test_doctor.py` | `types` | static | stdlib | *RepoVerified* |
| `vibecrafted-core/tests/test_doctor.py` | `vibecrafted_core` | static | local | *RepoVerified* |
| `vibecrafted-core/tests/test_doctor.py` | `sys` | static | stdlib | *RepoVerified* |
| `vibecrafted-core/tests/test_git.py` | `__future__` | static | unknown | *RepoVerified* |
| `vibecrafted-core/tests/test_git.py` | `pathlib` | static | stdlib | *RepoVerified* |
| `vibecrafted-core/tests/test_git.py` | `vibecrafted_core` | static | local | *RepoVerified* |
| `vibecrafted-core/tests/test_git.py` | `pytest` | static | unknown | *RepoVerified* |
| `vibecrafted-core/tests/test_git.py` | `subprocess` | static | stdlib | *RepoVerified* |
| `vibecrafted-core/tests/test_loop_ship.py` | `__future__` | static | unknown | *RepoVerified* |
| `vibecrafted-core/tests/test_loop_ship.py` | `pathlib` | static | stdlib | *RepoVerified* |
| `vibecrafted-core/tests/test_loop_ship.py` | `vibecrafted_core` | static | local | *RepoVerified* |
| `vibecrafted-core/tests/test_memex_client.py` | `__future__` | static | unknown | *RepoVerified* |
| `vibecrafted-core/tests/test_memex_client.py` | `pathlib` | static | stdlib | *RepoVerified* |
| `vibecrafted-core/tests/test_memex_client.py` | `typing` | static | stdlib | *RepoVerified* |
| `vibecrafted-core/tests/test_memex_client.py` | `vibecrafted_core` | static | local | *RepoVerified* |
| `vibecrafted-core/tests/test_memex_client.py` | `http.client` | static | stdlib | *RepoVerified* |
| `vibecrafted-core/tests/test_memex_client.py` | `json` | static | stdlib | *RepoVerified* |
| `vibecrafted-core/tests/test_memex_client.py` | `logging` | static | stdlib | *RepoVerified* |
| `vibecrafted-core/tests/test_memex_client.py` | `pytest` | static | unknown | *RepoVerified* |
| `vibecrafted-core/tests/test_package_init.py` | `__future__` | static | unknown | *RepoVerified* |
| `vibecrafted-core/tests/test_package_init.py` | `subprocess` | static | stdlib | *RepoVerified* |
| `vibecrafted-core/tests/test_package_init.py` | `sys` | static | stdlib | *RepoVerified* |
| `vibecrafted-core/tests/test_sandbox_adapter.py` | `__future__` | static | unknown | *RepoVerified* |
| `vibecrafted-core/tests/test_sandbox_adapter.py` | `pathlib` | static | stdlib | *RepoVerified* |
| `vibecrafted-core/tests/test_sandbox_adapter.py` | `vibecrafted_core` | static | local | *RepoVerified* |
| `vibecrafted-core/tests/test_sandbox_adapter.py` | `vibecrafted_core.sandbox` | static | local | *RepoVerified* |
| `vibecrafted-core/tests/test_sandbox_adapter.py` | `vibecrafted_core.sandbox` | static | local | *RepoVerified* |
| `vibecrafted-core/tests/test_sandbox_adapter.py` | `vibecrafted_core.sandbox` | static | local | *RepoVerified* |
| `vibecrafted-core/tests/test_sandbox_adapter.py` | `vibecrafted_core.sandbox.msbserver_lifecycle` | static | local | *RepoVerified* |
| `vibecrafted-core/tests/test_sandbox_adapter.py` | `vibecrafted_core.sandbox.policy` | static | local | *RepoVerified* |
| `vibecrafted-core/tests/test_sandbox_adapter.py` | `pytest` | static | unknown | *RepoVerified* |
| `vibecrafted-core/tests/test_sandbox_adapter.py` | `sys` | static | stdlib | *RepoVerified* |
| `vibecrafted-core/tests/test_sandbox_adapter.py` | `types` | static | stdlib | *RepoVerified* |
| `vibecrafted-core/tests/test_supervisor.py` | `__future__` | static | unknown | *RepoVerified* |
| `vibecrafted-core/tests/test_supervisor.py` | `pathlib` | static | stdlib | *RepoVerified* |
| `vibecrafted-core/tests/test_supervisor.py` | `vibecrafted_core` | static | local | *RepoVerified* |
| `vibecrafted-core/tests/test_supervisor.py` | `vibecrafted_core.agent_dispatch` | static | local | *RepoVerified* |
| `vibecrafted-core/tests/test_supervisor.py` | `vibecrafted_core.events` | static | local | *RepoVerified* |
| `vibecrafted-core/tests/test_supervisor.py` | `vibecrafted_core.spawn` | static | local | *RepoVerified* |
| `vibecrafted-core/tests/test_supervisor.py` | `vibecrafted_core.spawn` | static | local | *RepoVerified* |
| `vibecrafted-core/tests/test_supervisor.py` | `json` | static | stdlib | *RepoVerified* |
| `vibecrafted-core/tests/test_supervisor.py` | `pytest` | static | unknown | *RepoVerified* |
| `vibecrafted-core/tests/test_supervisor.py` | `sys` | static | stdlib | *RepoVerified* |
| `vibecrafted-core/tests/test_supervisor_async.py` | `asyncio` | static | stdlib | *RepoVerified* |
| `vibecrafted-core/tests/test_supervisor_async.py` | `__future__` | static | unknown | *RepoVerified* |
| `vibecrafted-core/tests/test_supervisor_async.py` | `pathlib` | static | stdlib | *RepoVerified* |
| `vibecrafted-core/tests/test_supervisor_async.py` | `vibecrafted_core` | static | local | *RepoVerified* |
| `vibecrafted-core/tests/test_supervisor_async.py` | `vibecrafted_core.artifacts` | static | local | *RepoVerified* |
| `vibecrafted-core/tests/test_supervisor_async.py` | `vibecrafted_core.control_plane` | static | local | *RepoVerified* |
| `vibecrafted-core/tests/test_supervisor_async.py` | `vibecrafted_core.lifecycle` | static | local | *RepoVerified* |
| `vibecrafted-core/tests/test_supervisor_async.py` | `vibecrafted_core.supervisor_async` | static | local | *RepoVerified* |
| `vibecrafted-core/tests/test_supervisor_async.py` | `json` | static | stdlib | *RepoVerified* |
| `vibecrafted-core/tests/test_supervisor_async.py` | `sys` | static | stdlib | *RepoVerified* |
| `vibecrafted-core/tests/test_ui.py` | `__future__` | static | unknown | *RepoVerified* |
| `vibecrafted-core/tests/test_ui.py` | `vibecrafted_core` | static | local | *RepoVerified* |
| `vibecrafted-core/tests/test_ui.py` | `io` | static | stdlib | *RepoVerified* |
| `vibecrafted-core/tests/test_ui.py` | `pytest` | static | unknown | *RepoVerified* |
| `vibecrafted-core/tests/test_workflow.py` | `__future__` | static | unknown | *RepoVerified* |
| `vibecrafted-core/tests/test_workflow.py` | `pathlib` | static | stdlib | *RepoVerified* |
| `vibecrafted-core/tests/test_workflow.py` | `typing` | static | stdlib | *RepoVerified* |
| `vibecrafted-core/tests/test_workflow.py` | `vibecrafted_core` | static | local | *RepoVerified* |
| `vibecrafted-core/tests/test_workflow.py` | `json` | static | stdlib | *RepoVerified* |
| `vibecrafted-core/tests/test_workflow.py` | `pytest` | static | unknown | *RepoVerified* |
| `vibecrafted-core/tests/test_workflow.py` | `subprocess` | static | stdlib | *RepoVerified* |
| `vibecrafted-core/tests/test_workflow.py` | `sys` | static | stdlib | *RepoVerified* |
| `vibecrafted-core/tests/test_workflow_registry.py` | `__future__` | static | unknown | *RepoVerified* |
| `vibecrafted-core/tests/test_workflow_registry.py` | `pathlib` | static | stdlib | *RepoVerified* |
| `vibecrafted-core/tests/test_workflow_registry.py` | `vibecrafted_core` | static | local | *RepoVerified* |
| `vibecrafted-core/tests/test_workflow_registry.py` | `vibecrafted_core.workflows` | static | local | *RepoVerified* |
| `vibecrafted-core/tests/test_workflow_runtime.py` | `__future__` | static | unknown | *RepoVerified* |
| `vibecrafted-core/tests/test_workflow_runtime.py` | `pathlib` | static | stdlib | *RepoVerified* |
| `vibecrafted-core/tests/test_workflow_runtime.py` | `vibecrafted_core` | static | local | *RepoVerified* |
| `vibecrafted-core/tests/test_workflow_runtime.py` | `json` | static | stdlib | *RepoVerified* |
| `vibecrafted-core/tests/test_workflow_runtime.py` | `os` | static | stdlib | *RepoVerified* |
| `vibecrafted-core/tests/test_wrappers.py` | `__future__` | static | unknown | *RepoVerified* |
| `vibecrafted-core/tests/test_wrappers.py` | `vibecrafted_core` | static | local | *RepoVerified* |
| `vibecrafted-core/tests/test_wrappers.py` | `vibecrafted_core` | static | local | *RepoVerified* |
| `vibecrafted-core/tests/test_wrappers.py` | `pytest` | static | unknown | *RepoVerified* |
| `vibecrafted-core/tests/test_wrappers.py` | `subprocess` | static | stdlib | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/__init__.py` | `.artifacts` | static | local | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/__init__.py` | `.capabilities` | static | local | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/__init__.py` | `.control_plane` | static | local | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/__init__.py` | `.doctor` | static | local | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/__init__.py` | `.events` | static | local | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/__init__.py` | `.git` | static | local | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/__init__.py` | `.lifecycle` | static | local | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/__init__.py` | `.runtime_paths` | static | local | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/__init__.py` | `.supervisor_async` | static | local | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/__init__.py` | `__future__` | static | unknown | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/__init__.py` | `typing` | static | stdlib | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/agent_dispatch.py` | `__future__` | static | unknown | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/agent_dispatch.py` | `typing` | static | stdlib | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/agent_dispatch.py` | `os` | static | stdlib | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/agent_dispatch.py` | `re` | static | stdlib | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/agent_dispatch.py` | `sys` | static | stdlib | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/agent_stream.py` | `__future__` | static | unknown | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/agent_stream.py` | `pathlib` | static | stdlib | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/agent_stream.py` | `typing` | static | stdlib | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/agent_stream.py` | `json` | static | stdlib | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/agent_stream.py` | `os` | static | stdlib | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/agent_stream.py` | `re` | static | stdlib | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/agent_stream.py` | `time` | static | stdlib | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/agent_stream.py` | `tomllib` | static | unknown | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/aicx_sync.py` | `__future__` | static | unknown | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/aicx_sync.py` | `dataclasses` | static | stdlib | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/aicx_sync.py` | `datetime` | static | stdlib | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/aicx_sync.py` | `enum` | static | unknown | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/aicx_sync.py` | `pathlib` | static | stdlib | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/aicx_sync.py` | `typing` | static | stdlib | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/aicx_sync.py` | `json` | static | stdlib | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/aicx_sync.py` | `sys` | static | stdlib | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/artifacts.py` | `__future__` | static | unknown | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/artifacts.py` | `dataclasses` | static | stdlib | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/artifacts.py` | `pathlib` | static | stdlib | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/artifacts.py` | `typing` | static | stdlib | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/artifacts.py` | `json` | static | stdlib | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/capabilities.py` | `.runtime_paths` | static | local | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/capabilities.py` | `__future__` | static | unknown | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/capabilities.py` | `dataclasses` | static | stdlib | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/capabilities.py` | `datetime` | static | stdlib | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/capabilities.py` | `pathlib` | static | stdlib | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/capabilities.py` | `typing` | static | stdlib | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/capabilities.py` | `re` | static | stdlib | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/capabilities.py` | `shutil` | static | stdlib | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/capabilities.py` | `subprocess` | static | stdlib | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/cli.py` | `argparse` | static | stdlib | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/cli.py` | `datetime` | static | stdlib | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/cli.py` | `.agent_stream` | static | local | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/cli.py` | `.control_plane` | static | local | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/cli.py` | `.dispatch.cli` | static | local | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/cli.py` | `.workflow` | static | local | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/cli.py` | `.wrappers` | static | local | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/cli.py` | `__future__` | static | unknown | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/cli.py` | `pathlib` | static | stdlib | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/cli.py` | `typing` | static | stdlib | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/cli.py` | `json` | static | stdlib | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/cli.py` | `os` | static | stdlib | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/cli.py` | `sys` | static | stdlib | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/cli.py` | `time` | static | stdlib | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/compact_hooks.py` | `argparse` | static | stdlib | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/compact_hooks.py` | `.runtime_paths` | static | local | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/compact_hooks.py` | `__future__` | static | unknown | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/compact_hooks.py` | `datetime` | static | stdlib | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/compact_hooks.py` | `pathlib` | static | stdlib | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/compact_hooks.py` | `typing` | static | stdlib | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/compact_hooks.py` | `json` | static | stdlib | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/compact_hooks.py` | `os` | static | stdlib | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/compact_hooks.py` | `shutil` | static | stdlib | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/compact_hooks.py` | `subprocess` | static | stdlib | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/compact_hooks.py` | `sys` | static | stdlib | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/control_plane.py` | `argparse` | static | stdlib | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/control_plane.py` | `contextlib` | static | stdlib | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/control_plane.py` | `datetime` | static | stdlib | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/control_plane.py` | `errno` | static | stdlib | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/control_plane.py` | `fcntl` | static | unknown | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/control_plane.py` | `.runtime_paths` | static | local | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/control_plane.py` | `__future__` | static | unknown | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/control_plane.py` | `dataclasses` | static | stdlib | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/control_plane.py` | `pathlib` | static | stdlib | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/control_plane.py` | `typing` | static | stdlib | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/control_plane.py` | `json` | static | stdlib | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/control_plane.py` | `os` | static | stdlib | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/control_plane.py` | `time` | static | stdlib | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/control_plane.py` | `uuid` | static | stdlib | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/cron.py` | `argparse` | static | stdlib | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/cron.py` | `.runtime_paths` | static | local | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/cron.py` | `__future__` | static | unknown | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/cron.py` | `datetime` | static | stdlib | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/cron.py` | `pathlib` | static | stdlib | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/cron.py` | `typing` | static | stdlib | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/cron.py` | `json` | static | stdlib | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/cron.py` | `shlex` | static | stdlib | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/cron.py` | `subprocess` | static | stdlib | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/cron.py` | `sys` | static | stdlib | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/dispatch/__init__.py` | `.model` | static | local | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/dispatch/__init__.py` | `.schema` | static | local | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/dispatch/__init__.py` | `.supervisor` | static | local | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/dispatch/__init__.py` | `.verify` | static | local | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/dispatch/__init__.py` | `__future__` | static | unknown | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/dispatch/cli.py` | `argparse` | static | stdlib | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/dispatch/cli.py` | `.doctor` | static | local | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/dispatch/cli.py` | `.model` | static | local | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/dispatch/cli.py` | `.schema` | static | local | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/dispatch/cli.py` | `.supervisor` | static | local | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/dispatch/cli.py` | `__future__` | static | unknown | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/dispatch/cli.py` | `dataclasses` | static | stdlib | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/dispatch/cli.py` | `datetime` | static | stdlib | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/dispatch/cli.py` | `pathlib` | static | stdlib | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/dispatch/cli.py` | `typing` | static | stdlib | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/dispatch/cli.py` | `json` | static | stdlib | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/dispatch/cli.py` | `shutil` | static | stdlib | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/dispatch/cli.py` | `subprocess` | static | stdlib | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/dispatch/cli.py` | `sys` | static | stdlib | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/dispatch/doctor.py` | `argparse` | static | stdlib | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/dispatch/doctor.py` | `.model` | static | local | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/dispatch/doctor.py` | `.schema` | static | local | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/dispatch/doctor.py` | `__future__` | static | unknown | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/dispatch/doctor.py` | `dataclasses` | static | stdlib | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/dispatch/doctor.py` | `pathlib` | static | stdlib | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/dispatch/doctor.py` | `typing` | static | stdlib | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/dispatch/doctor.py` | `json` | static | stdlib | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/dispatch/model.py` | `__future__` | static | unknown | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/dispatch/model.py` | `collections.abc` | static | stdlib | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/dispatch/model.py` | `dataclasses` | static | stdlib | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/dispatch/model.py` | `typing` | static | stdlib | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/dispatch/model.py` | `json` | static | stdlib | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/dispatch/model.py` | `re` | static | stdlib | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/dispatch/schema.py` | `.model` | static | local | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/dispatch/schema.py` | `__future__` | static | unknown | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/dispatch/schema.py` | `dataclasses` | static | stdlib | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/dispatch/schema.py` | `pathlib` | static | stdlib | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/dispatch/schema.py` | `typing` | static | stdlib | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/dispatch/schema.py` | `vibecrafted_core.workflow` | static | local | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/dispatch/schema.py` | `re` | static | stdlib | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/dispatch/schema.py` | `shlex` | static | stdlib | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/dispatch/schema.py` | `tomllib` | static | unknown | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/dispatch/supervisor.py` | `.model` | static | local | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/dispatch/supervisor.py` | `.schema` | static | local | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/dispatch/supervisor.py` | `.verify` | static | local | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/dispatch/supervisor.py` | `__future__` | static | unknown | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/dispatch/supervisor.py` | `dataclasses` | static | stdlib | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/dispatch/supervisor.py` | `datetime` | static | stdlib | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/dispatch/supervisor.py` | `pathlib` | static | stdlib | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/dispatch/supervisor.py` | `typing` | static | stdlib | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/dispatch/supervisor.py` | `vibecrafted_core.workflow` | static | local | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/dispatch/supervisor.py` | `json` | static | stdlib | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/dispatch/supervisor.py` | `os` | static | stdlib | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/dispatch/supervisor.py` | `signal` | static | stdlib | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/dispatch/supervisor.py` | `subprocess` | static | stdlib | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/dispatch/supervisor.py` | `time` | static | stdlib | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/dispatch/verify.py` | `.model` | static | local | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/dispatch/verify.py` | `__future__` | static | unknown | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/dispatch/verify.py` | `collections.abc` | static | stdlib | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/dispatch/verify.py` | `datetime` | static | stdlib | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/dispatch/verify.py` | `os` | static | stdlib | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/dispatch/verify.py` | `subprocess` | static | stdlib | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/dispatch/verify.py` | `time` | static | stdlib | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/dispatch_contract.py` | `.workflow` | static | local | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/dispatch_contract.py` | `__future__` | static | unknown | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/dispatch_contract.py` | `dataclasses` | static | stdlib | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/dispatch_contract.py` | `pathlib` | static | stdlib | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/dispatch_contract.py` | `typing` | static | stdlib | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/dispatch_contract.py` | `re` | static | stdlib | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/dispatch_contract.py` | `shlex` | static | stdlib | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/dispatch_contract.py` | `tomllib` | static | unknown | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/dispatcher.py` | `argparse` | static | stdlib | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/dispatcher.py` | `asyncio` | static | stdlib | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/dispatcher.py` | `.supervisor_async` | static | local | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/dispatcher.py` | `__future__` | static | unknown | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/dispatcher.py` | `typing` | static | stdlib | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/dispatcher.py` | `json` | static | stdlib | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/dispatcher.py` | `os` | static | stdlib | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/dispatcher.py` | `sys` | static | stdlib | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/doctor.py` | `__future__` | static | unknown | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/doctor.py` | `pathlib` | static | stdlib | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/doctor.py` | `typing` | static | stdlib | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/doctor.py` | `importlib.util` | static | stdlib | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/doctor.py` | `sys` | static | stdlib | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/doctor.py` | `vetcoders_install` | static | unknown | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/events.py` | `__future__` | static | unknown | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/events.py` | `typing` | static | stdlib | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/git.py` | `__future__` | static | unknown | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/git.py` | `pathlib` | static | stdlib | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/git.py` | `typing` | static | stdlib | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/git.py` | `subprocess` | static | stdlib | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/lifecycle.py` | `__future__` | static | unknown | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/lifecycle.py` | `enum` | static | unknown | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/loop.py` | `argparse` | static | stdlib | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/loop.py` | `__future__` | static | unknown | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/loop.py` | `dataclasses` | static | stdlib | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/loop.py` | `datetime` | static | stdlib | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/loop.py` | `pathlib` | static | stdlib | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/loop.py` | `typing` | static | stdlib | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/loop.py` | `json` | static | stdlib | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/loop.py` | `os` | static | stdlib | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/loop.py` | `shlex` | static | stdlib | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/loop.py` | `subprocess` | static | stdlib | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/loop.py` | `sys` | static | stdlib | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/memex_client.py` | `__future__` | static | unknown | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/memex_client.py` | `dataclasses` | static | stdlib | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/memex_client.py` | `datetime` | static | stdlib | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/memex_client.py` | `pathlib` | static | stdlib | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/memex_client.py` | `typing` | static | stdlib | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/memex_client.py` | `http.client` | static | stdlib | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/memex_client.py` | `json` | static | stdlib | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/memex_client.py` | `logging` | static | stdlib | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/memex_client.py` | `os` | static | stdlib | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/memex_client.py` | `tomllib` | static | unknown | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/memex_client.py` | `urllib.parse` | static | stdlib | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/runtime_paths.py` | `__future__` | static | unknown | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/runtime_paths.py` | `pathlib` | static | stdlib | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/runtime_paths.py` | `os` | static | stdlib | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/sandbox/__init__.py` | `.adapter` | static | local | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/sandbox/__init__.py` | `.msbserver_lifecycle` | static | local | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/sandbox/__init__.py` | `.policy` | static | local | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/sandbox/__init__.py` | `__future__` | static | unknown | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/sandbox/adapter.py` | `aiohttp` | static | unknown | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/sandbox/adapter.py` | `asyncio` | static | stdlib | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/sandbox/adapter.py` | `.msbserver_lifecycle` | static | local | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/sandbox/adapter.py` | `.policy` | static | local | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/sandbox/adapter.py` | `__future__` | static | unknown | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/sandbox/adapter.py` | `dataclasses` | static | stdlib | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/sandbox/adapter.py` | `microsandbox` | static | unknown | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/sandbox/adapter.py` | `pathlib` | static | stdlib | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/sandbox/adapter.py` | `typing` | static | stdlib | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/sandbox/adapter.py` | `vibecrafted_core.events` | static | local | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/sandbox/adapter.py` | `os` | static | stdlib | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/sandbox/adapter.py` | `shlex` | static | stdlib | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/sandbox/adapter.py` | `sys` | static | stdlib | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/sandbox/msbserver_lifecycle.py` | `__future__` | static | unknown | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/sandbox/msbserver_lifecycle.py` | `pathlib` | static | stdlib | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/sandbox/msbserver_lifecycle.py` | `vibecrafted_core.runtime_paths` | static | local | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/sandbox/msbserver_lifecycle.py` | `http.client` | static | stdlib | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/sandbox/msbserver_lifecycle.py` | `os` | static | stdlib | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/sandbox/msbserver_lifecycle.py` | `re` | static | stdlib | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/sandbox/msbserver_lifecycle.py` | `shutil` | static | stdlib | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/sandbox/msbserver_lifecycle.py` | `signal` | static | stdlib | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/sandbox/msbserver_lifecycle.py` | `subprocess` | static | stdlib | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/sandbox/msbserver_lifecycle.py` | `time` | static | stdlib | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/sandbox/policy.py` | `__future__` | static | unknown | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/sandbox/policy.py` | `dataclasses` | static | stdlib | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/sandbox/policy.py` | `pathlib` | static | stdlib | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/sandbox/policy.py` | `typing` | static | stdlib | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/sandbox/policy.py` | `vibecrafted_core.runtime_paths` | static | local | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/sandbox/policy.py` | `os` | static | stdlib | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/ship.py` | `argparse` | static | stdlib | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/ship.py` | `__future__` | static | unknown | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/ship.py` | `pathlib` | static | stdlib | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/ship.py` | `typing` | static | stdlib | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/ship.py` | `subprocess` | static | stdlib | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/spawn.py` | `argparse` | static | stdlib | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/spawn.py` | `datetime` | static | stdlib | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/spawn.py` | `.agent_dispatch` | static | local | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/spawn.py` | `.control_plane` | static | local | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/spawn.py` | `.events` | static | local | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/spawn.py` | `.sandbox` | static | local | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/spawn.py` | `__future__` | static | unknown | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/spawn.py` | `dataclasses` | static | stdlib | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/spawn.py` | `pathlib` | static | stdlib | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/spawn.py` | `typing` | static | stdlib | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/spawn.py` | `json` | static | stdlib | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/spawn.py` | `os` | static | stdlib | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/spawn.py` | `re` | static | stdlib | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/spawn.py` | `shlex` | static | stdlib | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/spawn.py` | `subprocess` | static | stdlib | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/spawn.py` | `threading` | static | stdlib | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/supervisor_async.py` | `asyncio` | static | stdlib | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/supervisor_async.py` | `.agent_stream` | static | local | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/supervisor_async.py` | `.artifacts` | static | local | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/supervisor_async.py` | `.control_plane` | static | local | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/supervisor_async.py` | `.events` | static | local | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/supervisor_async.py` | `.lifecycle` | static | local | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/supervisor_async.py` | `__future__` | static | unknown | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/supervisor_async.py` | `dataclasses` | static | stdlib | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/supervisor_async.py` | `datetime` | static | stdlib | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/supervisor_async.py` | `pathlib` | static | stdlib | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/supervisor_async.py` | `typing` | static | stdlib | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/supervisor_async.py` | `json` | static | stdlib | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/supervisor_async.py` | `os` | static | stdlib | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/supervisor_async.py` | `signal` | static | stdlib | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/supervisor_async.py` | `sys` | static | stdlib | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/ui.py` | `__future__` | static | unknown | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/ui.py` | `types` | static | stdlib | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/ui.py` | `itertools` | static | stdlib | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/ui.py` | `os` | static | stdlib | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/ui.py` | `sys` | static | stdlib | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/ui.py` | `threading` | static | stdlib | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/workflow.py` | `.artifacts` | static | local | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/workflow.py` | `.control_plane` | static | local | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/workflow.py` | `.events` | static | local | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/workflow.py` | `.spawn` | static | local | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/workflow.py` | `.workflow_runtime` | static | local | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/workflow.py` | `.workflows` | static | local | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/workflow.py` | `__future__` | static | unknown | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/workflow.py` | `dataclasses` | static | stdlib | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/workflow.py` | `pathlib` | static | stdlib | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/workflow.py` | `typing` | static | stdlib | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/workflow.py` | `json` | static | stdlib | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/workflow.py` | `os` | static | stdlib | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/workflow.py` | `re` | static | stdlib | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/workflow.py` | `shlex` | static | stdlib | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/workflow.py` | `shutil` | static | stdlib | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/workflow.py` | `signal` | static | stdlib | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/workflow.py` | `subprocess` | static | stdlib | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/workflow.py` | `sys` | static | stdlib | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/workflow.py` | `time` | static | stdlib | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/workflow_runtime.py` | `argparse` | static | stdlib | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/workflow_runtime.py` | `asyncio` | static | stdlib | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/workflow_runtime.py` | `.spawn` | static | local | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/workflow_runtime.py` | `.supervisor_async` | static | local | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/workflow_runtime.py` | `__future__` | static | unknown | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/workflow_runtime.py` | `dataclasses` | static | stdlib | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/workflow_runtime.py` | `datetime` | static | stdlib | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/workflow_runtime.py` | `pathlib` | static | stdlib | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/workflow_runtime.py` | `typing` | static | stdlib | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/workflow_runtime.py` | `json` | static | stdlib | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/workflow_runtime.py` | `os` | static | stdlib | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/workflow_runtime.py` | `re` | static | stdlib | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/workflow_runtime.py` | `sys` | static | stdlib | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/workflow_runtime.py` | `tomllib` | static | unknown | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/workflows/__init__.py` | `.model` | static | local | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/workflows/__init__.py` | `.registry` | static | local | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/workflows/__init__.py` | `__future__` | static | unknown | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/workflows/model.py` | `__future__` | static | unknown | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/workflows/model.py` | `dataclasses` | static | stdlib | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/workflows/model.py` | `typing` | static | stdlib | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/workflows/registry.py` | `..runtime_paths` | static | local | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/workflows/registry.py` | `.model` | static | local | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/workflows/registry.py` | `__future__` | static | unknown | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/workflows/registry.py` | `pathlib` | static | stdlib | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/workflows/registry.py` | `os` | static | stdlib | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/wrappers.py` | `argparse` | static | stdlib | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/wrappers.py` | `.events` | static | local | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/wrappers.py` | `.spawn` | static | local | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/wrappers.py` | `.workflow` | static | local | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/wrappers.py` | `__future__` | static | unknown | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/wrappers.py` | `pathlib` | static | stdlib | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/wrappers.py` | `typing` | static | stdlib | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/wrappers.py` | `vibecrafted_core.sandbox` | static | local | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/wrappers.py` | `vibecrafted_core.sandbox.policy` | static | local | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/wrappers.py` | `json` | static | stdlib | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/wrappers.py` | `os` | static | stdlib | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/wrappers.py` | `re` | static | stdlib | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/wrappers.py` | `subprocess` | static | stdlib | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/wrappers.py` | `sys` | static | stdlib | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/wrappers.py` | `time` | static | stdlib | *RepoVerified* |

### Consumers

| File | Import Kind | Imports Used | Authority |
|---|---|---|---|
| `bin/vc-agents` | `Direct` | supervised_skill_main | *RepoVerified* |
| `bin/vc-followup` | `Direct` | supervised_skill_main | *RepoVerified* |
| `bin/vc-implement` | `Direct` | supervised_skill_main | *RepoVerified* |
| `bin/vc-marbles` | `Direct` | supervised_skill_main | *RepoVerified* |
| `bin/vc-prune` | `Direct` | supervised_skill_main | *RepoVerified* |
| `bin/vc-research` | `Direct` | research_main | *RepoVerified* |
| `bin/vc-research-await` | `Direct` | research_await_main | *RepoVerified* |
| `bin/vc-research-synthesize` | `Direct` | research_synthesize_main | *RepoVerified* |
| `bin/vc-review` | `Direct` | supervised_skill_main | *RepoVerified* |
| `bin/vc-sandbox` | `Direct` | annotations, MsbserverLifecycle, SandboxPolicy | *RepoVerified* |
| `bin/vc-scaffold` | `Direct` | supervised_skill_main | *RepoVerified* |
| `bin/vibecrafted-resume` | `Direct` | resume_main | *RepoVerified* |
| `scripts/control_plane_launch.py` | `Reexport` |  | *RepoVerified* |
| `scripts/control_plane_state.py` | `Direct` | annotations, control_plane | *RepoVerified* |
| `scripts/installer_gui.py` | `Transitive` | annotations, Any, launch_workflow, normalize_launch_spec, sync_state, read_version_file, vibecrafted_home, xdg_config_home | *RepoVerified* |
| `scripts/runtime_paths.py` | `Reexport` |  | *RepoVerified* |
| `scripts/vetcoders_install.py` | `Transitive` | read_version_file, vibecrafted_launcher_bin, vibecrafted_runtime_home, vibecrafted_runtime_bin, vibecrafted_tools_home, vibecrafted_home, xdg_config_home | *RepoVerified* |
| `tests/agent_dispatch_test.py` | `Direct` | annotations, agent_dispatch | *RepoVerified* |
| `tests/tui/test_keys.py` | `Transitive` | read_version_file, vibecrafted_home | *RepoVerified* |
| `tests/tui/test_research_terminal_safety.py` | `Direct` | _launcher_paths | *RepoVerified* |
| `vibecrafted-app/shell-agent/app/Vibecrafted/AppDelegate.swift` | `Direct` |  | *RepoVerified* |
| `vibecrafted-app/shell-agent/app/Vibecrafted/Bridge/vibecrafted_shell_ffi.swift` | `Direct` |  | *RepoVerified* |
| `vibecrafted-app/shell-agent/app/Vibecrafted/Views/InspectorViewController.swift` | `Direct` |  | *RepoVerified* |
| `vibecrafted-core/tests/dispatch/test_cli.py` | `Direct` | annotations, cli | *RepoVerified* |
| `vibecrafted-core/tests/dispatch/test_doctor.py` | `Direct` | diagnose_file, main | *RepoVerified* |
| `vibecrafted-core/tests/dispatch/test_schema.py` | `Direct` | Baton, CutState, Matcher, STATE_VERIFIED, Verdict, VerifierEvidence | *RepoVerified* |
| `vibecrafted-core/tests/dispatch/test_supervisor.py` | `Direct` | annotations, workflow | *RepoVerified* |
| `vibecrafted-core/tests/dispatch/test_verify.py` | `Direct` | STATE_FAILED, STATE_UNKNOWN, STATE_VERIFIED, Cut, Matcher, Verify | *RepoVerified* |
| `vibecrafted-core/tests/test_agent_stream.py` | `Direct` | AgentStreamParser, resolve_default_model | *RepoVerified* |
| `vibecrafted-core/tests/test_agy_junie_pipeline.py` | `Direct` | annotations, workflow | *RepoVerified* |
| `vibecrafted-core/tests/test_aicx_sync.py` | `Direct` | annotations, Any, aicx_sync | *RepoVerified* |
| `vibecrafted-core/tests/test_capabilities.py` | `Direct` | annotations, capabilities | *RepoVerified* |
| `vibecrafted-core/tests/test_cli.py` | `Direct` | annotations, cli | *RepoVerified* |
| `vibecrafted-core/tests/test_compact_hooks.py` | `Direct` | annotations, compact_hooks | *RepoVerified* |
| `vibecrafted-core/tests/test_control_plane.py` | `Direct` | annotations, control_plane, workflow | *RepoVerified* |
| `vibecrafted-core/tests/test_cron.py` | `Direct` | annotations, cron | *RepoVerified* |
| `vibecrafted-core/tests/test_dispatch_contract.py` | `Direct` | DispatchContractError, MATCHER_TYPES, doctor_dispatch_contract, parse_dispatch_contract | *RepoVerified* |
| `vibecrafted-core/tests/test_doctor.py` | `Direct` | annotations, doctor | *RepoVerified* |
| `vibecrafted-core/tests/test_git.py` | `Direct` | annotations, git | *RepoVerified* |
| `vibecrafted-core/tests/test_loop_ship.py` | `Direct` | annotations, loop, ship | *RepoVerified* |
| `vibecrafted-core/tests/test_memex_client.py` | `Direct` | annotations, Any, memex_client | *RepoVerified* |
| `vibecrafted-core/tests/test_sandbox_adapter.py` | `Direct` | annotations, control_plane | *RepoVerified* |
| `vibecrafted-core/tests/test_supervisor.py` | `Direct` | annotations, control_plane, append_event | *RepoVerified* |
| `vibecrafted-core/tests/test_supervisor_async.py` | `Direct` | annotations, dispatcher, validate_artifacts, read_event_tail, RunState, transition_allowed, AsyncSupervisor | *RepoVerified* |
| `vibecrafted-core/tests/test_ui.py` | `Direct` | annotations, ui | *RepoVerified* |
| `vibecrafted-core/tests/test_workflow.py` | `Direct` | annotations, Any, workflow | *RepoVerified* |
| `vibecrafted-core/tests/test_workflow_registry.py` | `Direct` | annotations, workflow | *RepoVerified* |
| `vibecrafted-core/tests/test_workflow_runtime.py` | `Direct` | annotations, workflow_runtime | *RepoVerified* |
| `vibecrafted-core/tests/test_wrappers.py` | `Direct` | annotations, wrappers, workflow | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/__init__.py` | `Reexport` | ArtifactValidation, validate_artifacts | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/capabilities.py` | `Direct` | vibecrafted_launcher_bin | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/cli.py` | `Direct` | ANSI_PATTERN, AgentStreamParser, resolve_default_model | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/compact_hooks.py` | `Direct` | vibecrafted_home | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/control_plane.py` | `Direct` | vibecrafted_home | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/cron.py` | `Direct` | vibecrafted_home | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/dispatch/__init__.py` | `Reexport` | Baton, Common, Cut, CutState, Dispatch, Matcher, Meta, Phase, Policy, Recovery, Verdict, VerifierEvidence, Verify | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/dispatch/cli.py` | `Direct` | diagnose_file | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/dispatch/doctor.py` | `Direct` | Dispatch | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/dispatch/schema.py` | `Direct` | CRITICAL_FAIL_POLICIES, MATCHER_TYPES, READ_MUTATIONS, SCHEMA_VERSION, TIMEOUT_POLICIES, Baton, Common, Cut, Dispatch, Matcher, Meta, Phase, Policy, Recovery, Verify | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/dispatch/supervisor.py` | `Direct` | STATE_FAILED, STATE_PENDING, STATE_UNKNOWN, STATE_VERIFIED, STATE_WORKER_DONE, Baton, Cut, Dispatch, Verdict | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/dispatch/verify.py` | `Direct` | STATE_FAILED, STATE_UNKNOWN, STATE_VERIFIED, Cut, Verdict, VerifierEvidence, Verify | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/dispatch_contract.py` | `Direct` | SUPPORTED_WORKFLOWS | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/dispatcher.py` | `Direct` | AsyncSupervisor | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/sandbox/__init__.py` | `Reexport` | ExecResult, SandboxAdapter | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/sandbox/adapter.py` | `Direct` | append_event | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/sandbox/msbserver_lifecycle.py` | `Direct` | vibecrafted_home | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/sandbox/policy.py` | `Direct` | vibecrafted_home | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/spawn.py` | `Direct` | extract_session_id, sandbox_supported | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/supervisor_async.py` | `Direct` | AgentStreamParser, is_grok_ignorable_transport_error, resolve_default_model | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/workflow.py` | `Direct` | validate_artifacts | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/workflow_runtime.py` | `Direct` | _stdin_command | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/workflows/__init__.py` | `Reexport` | WorkflowDefinition | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/workflows/registry.py` | `Direct` | vibecrafted_tools_home | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/wrappers.py` | `Direct` | append_event | *RepoVerified* |
| `vibecrafted-mcp/vibecrafted_mcp/server.py` | `Direct` | annotations, Any, capabilities, control_plane, doctor, git, workflow | *RepoVerified* |

### Entrypoints

| Path | Kinds | Authority |
|---|---|---|
| `scripts/control_plane_state.py` | script | *RepoVerified* |
| `scripts/installer_gui.py` | script | *RepoVerified* |
| `scripts/vetcoders_install.py` | script | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/aicx_sync.py` | script | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/cli.py` | script | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/compact_hooks.py` | script | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/control_plane.py` | script | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/cron.py` | script | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/dispatch/cli.py` | script | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/dispatch/doctor.py` | script | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/dispatcher.py` | script | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/loop.py` | script | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/ship.py` | script | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/spawn.py` | script | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/workflow_runtime.py` | script | *RepoVerified* |
| `vibecrafted-mcp/vibecrafted_mcp/server.py` | script | *RepoVerified* |

## Runtime Slice

### Idiom Tags

- **main** (`vibecrafted-core/vibecrafted_core/cli.py::main`): Convention entrypoint called from `if __name__ == '__main__':` blocks and `console_scripts` entry points. (Role: primary_entrypoint, Source: embedded_default) *LoctreeDerived*
- **main** (`vibecrafted-core/vibecrafted_core/compact_hooks.py::main`): Convention entrypoint called from `if __name__ == '__main__':` blocks and `console_scripts` entry points. (Role: primary_entrypoint, Source: embedded_default) *LoctreeDerived*
- **main** (`vibecrafted-core/vibecrafted_core/cron.py::main`): Convention entrypoint called from `if __name__ == '__main__':` blocks and `console_scripts` entry points. (Role: primary_entrypoint, Source: embedded_default) *LoctreeDerived*
- **main** (`vibecrafted-core/vibecrafted_core/dispatch/cli.py::main`): Convention entrypoint called from `if __name__ == '__main__':` blocks and `console_scripts` entry points. (Role: primary_entrypoint, Source: embedded_default) *LoctreeDerived*
- **main** (`vibecrafted-core/vibecrafted_core/dispatch/doctor.py::main`): Convention entrypoint called from `if __name__ == '__main__':` blocks and `console_scripts` entry points. (Role: primary_entrypoint, Source: embedded_default) *LoctreeDerived*
- **main** (`vibecrafted-core/vibecrafted_core/dispatcher.py::main`): Convention entrypoint called from `if __name__ == '__main__':` blocks and `console_scripts` entry points. (Role: primary_entrypoint, Source: embedded_default) *LoctreeDerived*
- **main** (`vibecrafted-core/vibecrafted_core/loop.py::main`): Convention entrypoint called from `if __name__ == '__main__':` blocks and `console_scripts` entry points. (Role: primary_entrypoint, Source: embedded_default) *LoctreeDerived*
- **main** (`vibecrafted-core/vibecrafted_core/ship.py::main`): Convention entrypoint called from `if __name__ == '__main__':` blocks and `console_scripts` entry points. (Role: primary_entrypoint, Source: embedded_default) *LoctreeDerived*
- **main** (`vibecrafted-core/vibecrafted_core/spawn.py::main`): Convention entrypoint called from `if __name__ == '__main__':` blocks and `console_scripts` entry points. (Role: primary_entrypoint, Source: embedded_default) *LoctreeDerived*
- **warning** (`vibecrafted-core/vibecrafted_core/ui.py::warn`): Conventional warning-level logger method (stdlib `logging.warning`). (Role: library_helper, Source: embedded_default) *LoctreeDerived*

### Dispatch Edges

- `vibecrafted-core/tests/test_sandbox_adapter.py`:72 -> `fake_microsandbox` (`vibecrafted-core/tests/test_sandbox_adapter.py`) *LoctreeDerived*
- `vibecrafted-core/tests/test_ui.py`:12 -> `_no_color_by_default` (`vibecrafted-core/tests/test_ui.py`) *LoctreeDerived*

### Reachability

- `vibecrafted-core/tests/test_sandbox_adapter.py::fake_microsandbox`: Reached (dispatch_handler:event_handler:vibecrafted-core/tests/test_sandbox_adapter.py) *LoctreeDerived*
- `vibecrafted-core/vibecrafted_core/cli.py::main`: Reached (idiom_runtime_role:primary_entrypoint) *SemanticGuess*
- `vibecrafted-core/vibecrafted_core/compact_hooks.py::main`: Reached (idiom_runtime_role:primary_entrypoint) *SemanticGuess*
- `vibecrafted-core/vibecrafted_core/cron.py::main`: Reached (idiom_runtime_role:primary_entrypoint) *SemanticGuess*
- `vibecrafted-core/vibecrafted_core/dispatch/cli.py::main`: Reached (idiom_runtime_role:primary_entrypoint) *SemanticGuess*
- `vibecrafted-core/vibecrafted_core/dispatch/doctor.py::main`: Reached (idiom_runtime_role:primary_entrypoint) *SemanticGuess*
- `vibecrafted-core/vibecrafted_core/dispatcher.py::main`: Reached (idiom_runtime_role:primary_entrypoint) *SemanticGuess*
- `vibecrafted-core/vibecrafted_core/loop.py::main`: Reached (idiom_runtime_role:primary_entrypoint) *SemanticGuess*
- `vibecrafted-core/vibecrafted_core/ship.py::main`: Reached (idiom_runtime_role:primary_entrypoint) *SemanticGuess*
- `vibecrafted-core/vibecrafted_core/spawn.py::main`: Reached (idiom_runtime_role:primary_entrypoint) *SemanticGuess*
- `vibecrafted-core/vibecrafted_core/ui.py::warn`: Reached (idiom_runtime_role:library_helper) *SemanticGuess*

### Env Contracts

- `AICX_RECALL_CHUNK_LINES` used in 1 files *LoctreeDerived*
- `AICX_RECALL_DEDUP` used in 1 files *LoctreeDerived*
- `AICX_RECALL_STRIP_SKILLS` used in 1 files *LoctreeDerived*
- `CLAUDE_CODE_SESSION_ID` used in 6 files *LoctreeDerived*
- `CLAUDE_PROJECT_DIR` used in 1 files *LoctreeDerived*
- `CODEX_HOME` used in 1 files *LoctreeDerived*
- `CODEX_PROJECT_DIR` used in 1 files *LoctreeDerived*
- `CODEX_SESSIONS_DIR` used in 1 files *LoctreeDerived*
- `CODEX_SESSION_ID` used in 4 files *LoctreeDerived*
- `MICROSANDBOX_PYTHON_SDK` used in 1 files *LoctreeDerived*
- `MSBSERVER_EXE` used in 1 files *LoctreeDerived*
- `MSB_API_KEY` used in 1 files *LoctreeDerived*
- `MSB_SERVER_URL` used in 1 files *LoctreeDerived*
- `NO_COLOR` used in 2 files *LoctreeDerived*
- `PATH` used in 15 files *LoctreeDerived*
- `TMPDIR` used in 6 files *LoctreeDerived*
- `VIBECRAFTED_ARTIFACT_SLUG` used in 1 files *LoctreeDerived*
- `VIBECRAFTED_ARTIFACT_SUFFIX` used in 1 files *LoctreeDerived*
- `VIBECRAFTED_ARTIFACT_TS` used in 1 files *LoctreeDerived*
- `VIBECRAFTED_CANONICAL_REPORT_DIR` used in 1 files *LoctreeDerived*
- `VIBECRAFTED_CMD` used in 1 files *LoctreeDerived*
- `VIBECRAFTED_COMPACT_AGENT` used in 1 files *LoctreeDerived*
- `VIBECRAFTED_HOME` used in 27 files *LoctreeDerived*
- `VIBECRAFTED_LOOP_STATE_FILE` used in 1 files *LoctreeDerived*
- `VIBECRAFTED_META_PATH` used in 1 files *LoctreeDerived*
- `VIBECRAFTED_OPERATOR_SESSION_ID` used in 1 files *LoctreeDerived*
- `VIBECRAFTED_PROMPT_PATH` used in 2 files *LoctreeDerived*
- `VIBECRAFTED_REPORT_PATH` used in 3 files *LoctreeDerived*
- `VIBECRAFTED_RESEARCH_AGENTS` used in 2 files *LoctreeDerived*
- `VIBECRAFTED_RESEARCH_SYNTHESIS_TIMEOUT` used in 1 files *LoctreeDerived*
- `VIBECRAFTED_ROOT` used in 19 files *LoctreeDerived*
- `VIBECRAFTED_RUN_ID` used in 7 files *LoctreeDerived*
- `VIBECRAFTED_TEE_OUTPUT` used in 2 files *LoctreeDerived*
- `VIBECRAFTED_TOOLS_HOME` used in 13 files *LoctreeDerived*
- `VIBECRAFTED_WORKFLOWS_DIR` used in 1 files *LoctreeDerived*
- `XDG_CONFIG_HOME` used in 10 files *LoctreeDerived*

### Framework Hints

- `pytest_fixture` at `vibecrafted-core/tests/test_sandbox_adapter.py`: fake_microsandbox *RepoVerified*
- `pytest_fixture` at `vibecrafted-core/tests/test_ui.py`: _no_color_by_default *RepoVerified*
- `entrypoint` at `vibecrafted-core/vibecrafted_core/aicx_sync.py`: script *RepoVerified*
- `entrypoint` at `vibecrafted-core/vibecrafted_core/cli.py`: script *RepoVerified*
- `entrypoint` at `vibecrafted-core/vibecrafted_core/compact_hooks.py`: script *RepoVerified*
- `entrypoint` at `vibecrafted-core/vibecrafted_core/control_plane.py`: script *RepoVerified*
- `entrypoint` at `vibecrafted-core/vibecrafted_core/cron.py`: script *RepoVerified*
- `entrypoint` at `vibecrafted-core/vibecrafted_core/dispatch/cli.py`: script *RepoVerified*
- `entrypoint` at `vibecrafted-core/vibecrafted_core/dispatch/doctor.py`: script *RepoVerified*
- `entrypoint` at `vibecrafted-core/vibecrafted_core/dispatcher.py`: script *RepoVerified*
- `entrypoint` at `vibecrafted-core/vibecrafted_core/loop.py`: script *RepoVerified*
- `entrypoint` at `vibecrafted-core/vibecrafted_core/ship.py`: script *RepoVerified*
- `entrypoint` at `vibecrafted-core/vibecrafted_core/spawn.py`: script *RepoVerified*
- `entrypoint` at `vibecrafted-core/vibecrafted_core/workflow_runtime.py`: script *RepoVerified*

## Risk Slice

- Cache Scope: `Scoped("f1835573938e")` *RepoVerified*
- Snapshot Health: `scoped`
- Stale Snapshot: false
- Dirty Worktree: true

### Hotspots

| File | Importers | Authority |
|---|---|---|
| `vibecrafted-core/vibecrafted_core/__init__.py` | 24 | *LoctreeDerived* |
| `vibecrafted-core/vibecrafted_core/wrappers.py` | 13 | *LoctreeDerived* |
| `vibecrafted-core/vibecrafted_core/dispatch/model.py` | 10 | *LoctreeDerived* |
| `vibecrafted-core/vibecrafted_core/runtime_paths.py` | 9 | *LoctreeDerived* |
| `vibecrafted-core/vibecrafted_core/spawn.py` | 8 | *LoctreeDerived* |
| `vibecrafted-core/vibecrafted_core/control_plane.py` | 7 | *LoctreeDerived* |
| `vibecrafted-core/vibecrafted_core/events.py` | 7 | *LoctreeDerived* |
| `vibecrafted-core/vibecrafted_core/dispatch/schema.py` | 6 | *LoctreeDerived* |
| `vibecrafted-core/vibecrafted_core/workflow.py` | 6 | *LoctreeDerived* |
| `vibecrafted-core/vibecrafted_core/sandbox/policy.py` | 5 | *LoctreeDerived* |
| `vibecrafted-core/vibecrafted_core/artifacts.py` | 4 | *LoctreeDerived* |
| `vibecrafted-core/vibecrafted_core/dispatch/doctor.py` | 4 | *LoctreeDerived* |
| `vibecrafted-core/vibecrafted_core/sandbox/__init__.py` | 4 | *LoctreeDerived* |
| `vibecrafted-core/vibecrafted_core/supervisor_async.py` | 4 | *LoctreeDerived* |
| `vibecrafted-core/vibecrafted_core/agent_dispatch.py` | 3 | *LoctreeDerived* |
| `vibecrafted-core/vibecrafted_core/agent_stream.py` | 3 | *LoctreeDerived* |
| `vibecrafted-core/vibecrafted_core/dispatch/cli.py` | 3 | *LoctreeDerived* |
| `vibecrafted-core/vibecrafted_core/dispatch/supervisor.py` | 3 | *LoctreeDerived* |
| `vibecrafted-core/vibecrafted_core/dispatch/verify.py` | 3 | *LoctreeDerived* |
| `vibecrafted-core/vibecrafted_core/lifecycle.py` | 3 | *LoctreeDerived* |
| `vibecrafted-core/vibecrafted_core/sandbox/msbserver_lifecycle.py` | 3 | *LoctreeDerived* |
| `vibecrafted-core/vibecrafted_core/ui.py` | 3 | *LoctreeDerived* |
| `vibecrafted-core/vibecrafted_core/cli.py` | 2 | *LoctreeDerived* |
| `vibecrafted-core/vibecrafted_core/compact_hooks.py` | 2 | *LoctreeDerived* |
| `vibecrafted-core/vibecrafted_core/cron.py` | 2 | *LoctreeDerived* |
| `vibecrafted-core/vibecrafted_core/dispatcher.py` | 2 | *LoctreeDerived* |
| `vibecrafted-core/vibecrafted_core/loop.py` | 2 | *LoctreeDerived* |
| `vibecrafted-core/vibecrafted_core/ship.py` | 2 | *LoctreeDerived* |
| `vibecrafted-core/vibecrafted_core/workflows/__init__.py` | 2 | *LoctreeDerived* |
| `vibecrafted-core/vibecrafted_core/workflows/model.py` | 2 | *LoctreeDerived* |
| `vibecrafted-core/vibecrafted_core/capabilities.py` | 1 | *LoctreeDerived* |
| `vibecrafted-core/vibecrafted_core/dispatch/__init__.py` | 1 | *LoctreeDerived* |
| `vibecrafted-core/vibecrafted_core/dispatch_contract.py` | 1 | *LoctreeDerived* |
| `vibecrafted-core/vibecrafted_core/doctor.py` | 1 | *LoctreeDerived* |
| `vibecrafted-core/vibecrafted_core/git.py` | 1 | *LoctreeDerived* |
| `vibecrafted-core/vibecrafted_core/sandbox/adapter.py` | 1 | *LoctreeDerived* |
| `vibecrafted-core/vibecrafted_core/workflow_runtime.py` | 1 | *LoctreeDerived* |
| `vibecrafted-core/vibecrafted_core/workflows/registry.py` | 1 | *LoctreeDerived* |

### High Fan-In

| File | Importers | Authority |
|---|---|---|
| `vibecrafted-core/vibecrafted_core/__init__.py` | 24 | *LoctreeDerived* |
| `vibecrafted-core/vibecrafted_core/wrappers.py` | 13 | *LoctreeDerived* |
| `vibecrafted-core/vibecrafted_core/dispatch/model.py` | 10 | *LoctreeDerived* |

## Action Slice

### Power Path

- `loct slice vibecrafted-core/README.md`: Slice this file to inspect its direct dependencies and immediate consumers before editing.
- `loct follow`: Pursue unified structural signals (dead exports, import cycles, twins) to ensure health.
- `loct slice vibecrafted-core/pyproject.toml`: Slice this file to inspect its direct dependencies and immediate consumers before editing.
- `loct slice vibecrafted-core/tests/__init__.py`: Slice this file to inspect its direct dependencies and immediate consumers before editing.
- `loct slice vibecrafted-core/tests/conftest.py`: Slice this file to inspect its direct dependencies and immediate consumers before editing.
- `loct slice vibecrafted-core/tests/dispatch/fixtures/invalid-no-verify.dispatch.toml`: Slice this file to inspect its direct dependencies and immediate consumers before editing.
- `loct slice vibecrafted-core/tests/dispatch/fixtures/invalid/concurrency-without-policy.dispatch.toml`: Slice this file to inspect its direct dependencies and immediate consumers before editing.
- `loct slice vibecrafted-core/tests/dispatch/fixtures/invalid/duplicate-id.dispatch.toml`: Slice this file to inspect its direct dependencies and immediate consumers before editing.
- `loct slice vibecrafted-core/tests/dispatch/fixtures/invalid/hard-stop-no-verify.dispatch.toml`: Slice this file to inspect its direct dependencies and immediate consumers before editing.
- `loct slice vibecrafted-core/tests/dispatch/fixtures/invalid/hard-stop-push.dispatch.toml`: Slice this file to inspect its direct dependencies and immediate consumers before editing.
- `loct slice vibecrafted-core/tests/dispatch/fixtures/invalid/hard-stop-release.dispatch.toml`: Slice this file to inspect its direct dependencies and immediate consumers before editing.
- `loct slice vibecrafted-core/tests/dispatch/fixtures/invalid/missing-meta-repo.dispatch.toml`: Slice this file to inspect its direct dependencies and immediate consumers before editing.
- `loct slice vibecrafted-core/tests/dispatch/fixtures/invalid/missing-prompt-and-brief.dispatch.toml`: Slice this file to inspect its direct dependencies and immediate consumers before editing.
- `loct slice vibecrafted-core/tests/dispatch/fixtures/invalid/missing-verify.dispatch.toml`: Slice this file to inspect its direct dependencies and immediate consumers before editing.
- `loct slice vibecrafted-core/tests/dispatch/fixtures/invalid/read-without-mutation.dispatch.toml`: Slice this file to inspect its direct dependencies and immediate consumers before editing.
- `loct slice vibecrafted-core/tests/dispatch/fixtures/invalid/unknown-matcher.dispatch.toml`: Slice this file to inspect its direct dependencies and immediate consumers before editing.
- `loct slice vibecrafted-core/tests/dispatch/fixtures/invalid/unknown-phase.dispatch.toml`: Slice this file to inspect its direct dependencies and immediate consumers before editing.
- `loct slice vibecrafted-core/tests/dispatch/fixtures/invalid/unknown-schema.dispatch.toml`: Slice this file to inspect its direct dependencies and immediate consumers before editing.
- `loct slice vibecrafted-core/tests/dispatch/fixtures/invalid/unknown-workflow.dispatch.toml`: Slice this file to inspect its direct dependencies and immediate consumers before editing.
- `loct slice vibecrafted-core/tests/dispatch/fixtures/invalid/unreadable-brief.dispatch.toml`: Slice this file to inspect its direct dependencies and immediate consumers before editing.
- `loct slice vibecrafted-core/tests/dispatch/fixtures/legacy-stage0-read-no-edit.dispatch.toml`: Slice this file to inspect its direct dependencies and immediate consumers before editing.
- `loct slice vibecrafted-core/tests/dispatch/fixtures/minimal.dispatch.toml`: Slice this file to inspect its direct dependencies and immediate consumers before editing.
- `loct slice vibecrafted-core/tests/dispatch/fixtures/observational-read.dispatch.toml`: Slice this file to inspect its direct dependencies and immediate consumers before editing.
- `loct slice vibecrafted-core/tests/dispatch/fixtures/stage0-brief.md`: Slice this file to inspect its direct dependencies and immediate consumers before editing.
- `loct slice vibecrafted-core/tests/dispatch/fixtures/stage0.dispatch.toml`: Slice this file to inspect its direct dependencies and immediate consumers before editing.
- `loct slice vibecrafted-core/tests/dispatch/test_cli.py`: Slice this file to inspect its direct dependencies and immediate consumers before editing.
- `loct slice vibecrafted-core/tests/dispatch/test_doctor.py`: Slice this file to inspect its direct dependencies and immediate consumers before editing.
- `loct body test_dispatch_doctor_rejects_design_refusal_fixtures`: View the definition body of symbol 'test_dispatch_doctor_rejects_design_refusal_fixtures' to understand its implementation structure.
- `loct find --literal test_dispatch_doctor_rejects_design_refusal_fixtures`: Execute a literal exact-identifier scan for 'test_dispatch_doctor_rejects_design_refusal_fixtures' to find exact matches across the codebase.
- `loct occurrences test_dispatch_doctor_rejects_design_refusal_fixtures`: Perform a literal boundary-sensitive occurrences scan for 'test_dispatch_doctor_rejects_design_refusal_fixtures' to locate all references.
- `loct slice vibecrafted-core/tests/dispatch/test_schema.py`: Slice this file to inspect its direct dependencies and immediate consumers before editing.
- `loct body test_minimal_fixture_parses_into_typed_model`: View the definition body of symbol 'test_minimal_fixture_parses_into_typed_model' to understand its implementation structure.
- `loct find --literal test_minimal_fixture_parses_into_typed_model`: Execute a literal exact-identifier scan for 'test_minimal_fixture_parses_into_typed_model' to find exact matches across the codebase.
- `loct occurrences test_minimal_fixture_parses_into_typed_model`: Perform a literal boundary-sensitive occurrences scan for 'test_minimal_fixture_parses_into_typed_model' to locate all references.
- `loct slice vibecrafted-core/tests/dispatch/test_supervisor.py`: Slice this file to inspect its direct dependencies and immediate consumers before editing.
- `loct body FakeCell`: View the definition body of symbol 'FakeCell' to understand its implementation structure.
- `loct find --literal FakeCell`: Execute a literal exact-identifier scan for 'FakeCell' to find exact matches across the codebase.
- `loct occurrences FakeCell`: Perform a literal boundary-sensitive occurrences scan for 'FakeCell' to locate all references.
- `loct slice vibecrafted-core/tests/dispatch/test_verify.py`: Slice this file to inspect its direct dependencies and immediate consumers before editing.
- `loct body make_cut`: View the definition body of symbol 'make_cut' to understand its implementation structure.
- `loct find --literal make_cut`: Execute a literal exact-identifier scan for 'make_cut' to find exact matches across the codebase.
- `loct occurrences make_cut`: Perform a literal boundary-sensitive occurrences scan for 'make_cut' to locate all references.
- `loct slice vibecrafted-core/tests/test_agent_stream.py`: Slice this file to inspect its direct dependencies and immediate consumers before editing.
- `loct body test_agent_stream_parser_extracts_claude_session_usage_cost_and_text`: View the definition body of symbol 'test_agent_stream_parser_extracts_claude_session_usage_cost_and_text' to understand its implementation structure.
- `loct find --literal test_agent_stream_parser_extracts_claude_session_usage_cost_and_text`: Execute a literal exact-identifier scan for 'test_agent_stream_parser_extracts_claude_session_usage_cost_and_text' to find exact matches across the codebase.
- `loct occurrences test_agent_stream_parser_extracts_claude_session_usage_cost_and_text`: Perform a literal boundary-sensitive occurrences scan for 'test_agent_stream_parser_extracts_claude_session_usage_cost_and_text' to locate all references.
- `loct slice vibecrafted-core/tests/test_agy_junie_pipeline.py`: Slice this file to inspect its direct dependencies and immediate consumers before editing.
- `loct body test_workflow_launch_spec_accepts_agy_junie_and_grok`: View the definition body of symbol 'test_workflow_launch_spec_accepts_agy_junie_and_grok' to understand its implementation structure.
- `loct find --literal test_workflow_launch_spec_accepts_agy_junie_and_grok`: Execute a literal exact-identifier scan for 'test_workflow_launch_spec_accepts_agy_junie_and_grok' to find exact matches across the codebase.
- `loct occurrences test_workflow_launch_spec_accepts_agy_junie_and_grok`: Perform a literal boundary-sensitive occurrences scan for 'test_workflow_launch_spec_accepts_agy_junie_and_grok' to locate all references.
- `loct slice vibecrafted-core/tests/test_aicx_sync.py`: Slice this file to inspect its direct dependencies and immediate consumers before editing.
- `loct body test_authority_canonical_names`: View the definition body of symbol 'test_authority_canonical_names' to understand its implementation structure.
- `loct find --literal test_authority_canonical_names`: Execute a literal exact-identifier scan for 'test_authority_canonical_names' to find exact matches across the codebase.
- `loct occurrences test_authority_canonical_names`: Perform a literal boundary-sensitive occurrences scan for 'test_authority_canonical_names' to locate all references.
- `loct slice vibecrafted-core/tests/test_capabilities.py`: Slice this file to inspect its direct dependencies and immediate consumers before editing.
- `loct body test_probe_tool_reports_product_missing`: View the definition body of symbol 'test_probe_tool_reports_product_missing' to understand its implementation structure.
- `loct find --literal test_probe_tool_reports_product_missing`: Execute a literal exact-identifier scan for 'test_probe_tool_reports_product_missing' to find exact matches across the codebase.
- `loct occurrences test_probe_tool_reports_product_missing`: Perform a literal boundary-sensitive occurrences scan for 'test_probe_tool_reports_product_missing' to locate all references.
- `loct slice vibecrafted-core/tests/test_cli.py`: Slice this file to inspect its direct dependencies and immediate consumers before editing.
- `loct body test_root_cli_vc_help_alias_returns_help_success`: View the definition body of symbol 'test_root_cli_vc_help_alias_returns_help_success' to understand its implementation structure.
- `loct find --literal test_root_cli_vc_help_alias_returns_help_success`: Execute a literal exact-identifier scan for 'test_root_cli_vc_help_alias_returns_help_success' to find exact matches across the codebase.
- `loct occurrences test_root_cli_vc_help_alias_returns_help_success`: Perform a literal boundary-sensitive occurrences scan for 'test_root_cli_vc_help_alias_returns_help_success' to locate all references.
- `loct slice vibecrafted-core/tests/test_compact_hooks.py`: Slice this file to inspect its direct dependencies and immediate consumers before editing.
- `loct body test_precompact_extracts_conversation_and_user_only`: View the definition body of symbol 'test_precompact_extracts_conversation_and_user_only' to understand its implementation structure.
- `loct find --literal test_precompact_extracts_conversation_and_user_only`: Execute a literal exact-identifier scan for 'test_precompact_extracts_conversation_and_user_only' to find exact matches across the codebase.
- `loct occurrences test_precompact_extracts_conversation_and_user_only`: Perform a literal boundary-sensitive occurrences scan for 'test_precompact_extracts_conversation_and_user_only' to locate all references.
- `loct slice vibecrafted-core/tests/test_control_plane.py`: Slice this file to inspect its direct dependencies and immediate consumers before editing.
- `loct body test_sync_state_preserves_runtime_observe_fields`: View the definition body of symbol 'test_sync_state_preserves_runtime_observe_fields' to understand its implementation structure.
- `loct find --literal test_sync_state_preserves_runtime_observe_fields`: Execute a literal exact-identifier scan for 'test_sync_state_preserves_runtime_observe_fields' to find exact matches across the codebase.
- `loct occurrences test_sync_state_preserves_runtime_observe_fields`: Perform a literal boundary-sensitive occurrences scan for 'test_sync_state_preserves_runtime_observe_fields' to locate all references.
- `loct slice vibecrafted-core/tests/test_cron.py`: Slice this file to inspect its direct dependencies and immediate consumers before editing.
- `loct body write_state`: View the definition body of symbol 'write_state' to understand its implementation structure.
- `loct find --literal write_state`: Execute a literal exact-identifier scan for 'write_state' to find exact matches across the codebase.
- `loct occurrences write_state`: Perform a literal boundary-sensitive occurrences scan for 'write_state' to locate all references.
- `loct slice vibecrafted-core/tests/test_dispatch_contract.py`: Slice this file to inspect its direct dependencies and immediate consumers before editing.
- `loct slice vibecrafted-core/tests/test_doctor.py`: Slice this file to inspect its direct dependencies and immediate consumers before editing.
- `loct body test_installer_module_loads_source_file_without_mutating_sys_path`: View the definition body of symbol 'test_installer_module_loads_source_file_without_mutating_sys_path' to understand its implementation structure.
- `loct find --literal test_installer_module_loads_source_file_without_mutating_sys_path`: Execute a literal exact-identifier scan for 'test_installer_module_loads_source_file_without_mutating_sys_path' to find exact matches across the codebase.
- `loct occurrences test_installer_module_loads_source_file_without_mutating_sys_path`: Perform a literal boundary-sensitive occurrences scan for 'test_installer_module_loads_source_file_without_mutating_sys_path' to locate all references.
- `loct slice vibecrafted-core/tests/test_git.py`: Slice this file to inspect its direct dependencies and immediate consumers before editing.
- `loct body test_repo_full_reports_git_availability_and_commit`: View the definition body of symbol 'test_repo_full_reports_git_availability_and_commit' to understand its implementation structure.
- `loct find --literal test_repo_full_reports_git_availability_and_commit`: Execute a literal exact-identifier scan for 'test_repo_full_reports_git_availability_and_commit' to find exact matches across the codebase.
- `loct occurrences test_repo_full_reports_git_availability_and_commit`: Perform a literal boundary-sensitive occurrences scan for 'test_repo_full_reports_git_availability_and_commit' to locate all references.
- `loct slice vibecrafted-core/tests/test_loop_ship.py`: Slice this file to inspect its direct dependencies and immediate consumers before editing.
- `loct body test_loop_start_next_complete_round_trip`: View the definition body of symbol 'test_loop_start_next_complete_round_trip' to understand its implementation structure.
- `loct find --literal test_loop_start_next_complete_round_trip`: Execute a literal exact-identifier scan for 'test_loop_start_next_complete_round_trip' to find exact matches across the codebase.
- `loct occurrences test_loop_start_next_complete_round_trip`: Perform a literal boundary-sensitive occurrences scan for 'test_loop_start_next_complete_round_trip' to locate all references.
- `loct slice vibecrafted-core/tests/test_memex_client.py`: Slice this file to inspect its direct dependencies and immediate consumers before editing.
- `loct body test_load_config_pure_defaults`: View the definition body of symbol 'test_load_config_pure_defaults' to understand its implementation structure.
- `loct find --literal test_load_config_pure_defaults`: Execute a literal exact-identifier scan for 'test_load_config_pure_defaults' to find exact matches across the codebase.
- `loct occurrences test_load_config_pure_defaults`: Perform a literal boundary-sensitive occurrences scan for 'test_load_config_pure_defaults' to locate all references.
- `loct slice vibecrafted-core/tests/test_package_init.py`: Slice this file to inspect its direct dependencies and immediate consumers before editing.
- `loct body test_package_import_does_not_preload_spawn_module`: View the definition body of symbol 'test_package_import_does_not_preload_spawn_module' to understand its implementation structure.
- `loct find --literal test_package_import_does_not_preload_spawn_module`: Execute a literal exact-identifier scan for 'test_package_import_does_not_preload_spawn_module' to find exact matches across the codebase.
- `loct occurrences test_package_import_does_not_preload_spawn_module`: Perform a literal boundary-sensitive occurrences scan for 'test_package_import_does_not_preload_spawn_module' to locate all references.
- `loct slice vibecrafted-core/tests/test_sandbox_adapter.py`: Slice this file to inspect its direct dependencies and immediate consumers before editing.
- `loct body FakeLifecycle`: View the definition body of symbol 'FakeLifecycle' to understand its implementation structure.
- `loct find --literal FakeLifecycle`: Execute a literal exact-identifier scan for 'FakeLifecycle' to find exact matches across the codebase.
- `loct occurrences FakeLifecycle`: Perform a literal boundary-sensitive occurrences scan for 'FakeLifecycle' to locate all references.
- `loct slice vibecrafted-core/tests/test_supervisor.py`: Slice this file to inspect its direct dependencies and immediate consumers before editing.
- `loct body test_supervisor_spawn_lifecycle_extracts_session_id`: View the definition body of symbol 'test_supervisor_spawn_lifecycle_extracts_session_id' to understand its implementation structure.
- `loct find --literal test_supervisor_spawn_lifecycle_extracts_session_id`: Execute a literal exact-identifier scan for 'test_supervisor_spawn_lifecycle_extracts_session_id' to find exact matches across the codebase.
- `loct occurrences test_supervisor_spawn_lifecycle_extracts_session_id`: Perform a literal boundary-sensitive occurrences scan for 'test_supervisor_spawn_lifecycle_extracts_session_id' to locate all references.
- `loct slice vibecrafted-core/tests/test_supervisor_async.py`: Slice this file to inspect its direct dependencies and immediate consumers before editing.
- `loct body test_lifecycle_transition_table_rejects_backwards_transition`: View the definition body of symbol 'test_lifecycle_transition_table_rejects_backwards_transition' to understand its implementation structure.
- `loct find --literal test_lifecycle_transition_table_rejects_backwards_transition`: Execute a literal exact-identifier scan for 'test_lifecycle_transition_table_rejects_backwards_transition' to find exact matches across the codebase.
- `loct occurrences test_lifecycle_transition_table_rejects_backwards_transition`: Perform a literal boundary-sensitive occurrences scan for 'test_lifecycle_transition_table_rejects_backwards_transition' to locate all references.
- `loct slice vibecrafted-core/tests/test_ui.py`: Slice this file to inspect its direct dependencies and immediate consumers before editing.
- `loct body test_glyph_is_the_prefix_no_bracket_tags`: View the definition body of symbol 'test_glyph_is_the_prefix_no_bracket_tags' to understand its implementation structure.
- `loct find --literal test_glyph_is_the_prefix_no_bracket_tags`: Execute a literal exact-identifier scan for 'test_glyph_is_the_prefix_no_bracket_tags' to find exact matches across the codebase.
- `loct occurrences test_glyph_is_the_prefix_no_bracket_tags`: Perform a literal boundary-sensitive occurrences scan for 'test_glyph_is_the_prefix_no_bracket_tags' to locate all references.
- `loct slice vibecrafted-core/tests/test_workflow.py`: Slice this file to inspect its direct dependencies and immediate consumers before editing.
- `loct body test_normalize_launch_spec_requires_prompt_or_file`: View the definition body of symbol 'test_normalize_launch_spec_requires_prompt_or_file' to understand its implementation structure.
- `loct find --literal test_normalize_launch_spec_requires_prompt_or_file`: Execute a literal exact-identifier scan for 'test_normalize_launch_spec_requires_prompt_or_file' to find exact matches across the codebase.
- `loct occurrences test_normalize_launch_spec_requires_prompt_or_file`: Perform a literal boundary-sensitive occurrences scan for 'test_normalize_launch_spec_requires_prompt_or_file' to locate all references.
- `loct slice vibecrafted-core/tests/test_workflow_registry.py`: Slice this file to inspect its direct dependencies and immediate consumers before editing.
- `loct body test_registry_keeps_supported_workflows_explicit`: View the definition body of symbol 'test_registry_keeps_supported_workflows_explicit' to understand its implementation structure.
- `loct find --literal test_registry_keeps_supported_workflows_explicit`: Execute a literal exact-identifier scan for 'test_registry_keeps_supported_workflows_explicit' to find exact matches across the codebase.
- `loct occurrences test_registry_keeps_supported_workflows_explicit`: Perform a literal boundary-sensitive occurrences scan for 'test_registry_keeps_supported_workflows_explicit' to locate all references.
- `loct slice vibecrafted-core/tests/test_workflow_runtime.py`: Slice this file to inspect its direct dependencies and immediate consumers before editing.
- `loct body test_research_runtime_supervises_three_tracks`: View the definition body of symbol 'test_research_runtime_supervises_three_tracks' to understand its implementation structure.
- `loct find --literal test_research_runtime_supervises_three_tracks`: Execute a literal exact-identifier scan for 'test_research_runtime_supervises_three_tracks' to find exact matches across the codebase.
- `loct occurrences test_research_runtime_supervises_three_tracks`: Perform a literal boundary-sensitive occurrences scan for 'test_research_runtime_supervises_three_tracks' to locate all references.
- `loct slice vibecrafted-core/tests/test_wrappers.py`: Slice this file to inspect its direct dependencies and immediate consumers before editing.
- `loct body test_resume_main_routes_captured_session_through_zellij_aware_resume_helper`: View the definition body of symbol 'test_resume_main_routes_captured_session_through_zellij_aware_resume_helper' to understand its implementation structure.
- `loct find --literal test_resume_main_routes_captured_session_through_zellij_aware_resume_helper`: Execute a literal exact-identifier scan for 'test_resume_main_routes_captured_session_through_zellij_aware_resume_helper' to find exact matches across the codebase.
- `loct occurrences test_resume_main_routes_captured_session_through_zellij_aware_resume_helper`: Perform a literal boundary-sensitive occurrences scan for 'test_resume_main_routes_captured_session_through_zellij_aware_resume_helper' to locate all references.
- `loct slice vibecrafted-core/vibecrafted_core/__init__.py`: Slice this file to inspect its direct dependencies and immediate consumers before editing.
- `loct impact vibecrafted-core/vibecrafted_core/__init__.py`: Assess the transitive blast radius and downstream consumers of this file before modifying.
- `loct body annotations`: View the definition body of symbol 'annotations' to understand its implementation structure.
- `loct find --literal annotations`: Execute a literal exact-identifier scan for 'annotations' to find exact matches across the codebase.
- `loct occurrences annotations`: Perform a literal boundary-sensitive occurrences scan for 'annotations' to locate all references.
- `loct slice vibecrafted-core/vibecrafted_core/agent_dispatch.py`: Slice this file to inspect its direct dependencies and immediate consumers before editing.
- `loct impact vibecrafted-core/vibecrafted_core/agent_dispatch.py`: Assess the transitive blast radius and downstream consumers of this file before modifying.
- `loct body ParityError`: View the definition body of symbol 'ParityError' to understand its implementation structure.
- `loct find --literal ParityError`: Execute a literal exact-identifier scan for 'ParityError' to find exact matches across the codebase.
- `loct occurrences ParityError`: Perform a literal boundary-sensitive occurrences scan for 'ParityError' to locate all references.
- `loct slice vibecrafted-core/vibecrafted_core/agent_stream.py`: Slice this file to inspect its direct dependencies and immediate consumers before editing.
- `loct impact vibecrafted-core/vibecrafted_core/agent_stream.py`: Assess the transitive blast radius and downstream consumers of this file before modifying.
- `loct body stamp`: View the definition body of symbol 'stamp' to understand its implementation structure.
- `loct find --literal stamp`: Execute a literal exact-identifier scan for 'stamp' to find exact matches across the codebase.
- `loct occurrences stamp`: Perform a literal boundary-sensitive occurrences scan for 'stamp' to locate all references.
- `loct slice vibecrafted-core/vibecrafted_core/aicx_sync.py`: Slice this file to inspect its direct dependencies and immediate consumers before editing.
- `loct body Authority`: View the definition body of symbol 'Authority' to understand its implementation structure.
- `loct find --literal Authority`: Execute a literal exact-identifier scan for 'Authority' to find exact matches across the codebase.
- `loct occurrences Authority`: Perform a literal boundary-sensitive occurrences scan for 'Authority' to locate all references.
- `loct slice vibecrafted-core/vibecrafted_core/artifacts.py`: Slice this file to inspect its direct dependencies and immediate consumers before editing.
- `loct impact vibecrafted-core/vibecrafted_core/artifacts.py`: Assess the transitive blast radius and downstream consumers of this file before modifying.
- `loct body ArtifactValidation`: View the definition body of symbol 'ArtifactValidation' to understand its implementation structure.
- `loct find --literal ArtifactValidation`: Execute a literal exact-identifier scan for 'ArtifactValidation' to find exact matches across the codebase.
- `loct occurrences ArtifactValidation`: Perform a literal boundary-sensitive occurrences scan for 'ArtifactValidation' to locate all references.
- `loct slice vibecrafted-core/vibecrafted_core/capabilities.py`: Slice this file to inspect its direct dependencies and immediate consumers before editing.
- `loct impact vibecrafted-core/vibecrafted_core/capabilities.py`: Assess the transitive blast radius and downstream consumers of this file before modifying.
- `loct body ProbeResult`: View the definition body of symbol 'ProbeResult' to understand its implementation structure.
- `loct find --literal ProbeResult`: Execute a literal exact-identifier scan for 'ProbeResult' to find exact matches across the codebase.
- `loct occurrences ProbeResult`: Perform a literal boundary-sensitive occurrences scan for 'ProbeResult' to locate all references.
- `loct slice vibecrafted-core/vibecrafted_core/cli.py`: Slice this file to inspect its direct dependencies and immediate consumers before editing.
- `loct impact vibecrafted-core/vibecrafted_core/cli.py`: Assess the transitive blast radius and downstream consumers of this file before modifying.
- `loct body main`: View the definition body of symbol 'main' to understand its implementation structure.
- `loct find --literal main`: Execute a literal exact-identifier scan for 'main' to find exact matches across the codebase.
- `loct occurrences main`: Perform a literal boundary-sensitive occurrences scan for 'main' to locate all references.
- `loct slice vibecrafted-core/vibecrafted_core/compact_hooks.py`: Slice this file to inspect its direct dependencies and immediate consumers before editing.
- `loct impact vibecrafted-core/vibecrafted_core/compact_hooks.py`: Assess the transitive blast radius and downstream consumers of this file before modifying.
- `loct body utc_now`: View the definition body of symbol 'utc_now' to understand its implementation structure.
- `loct find --literal utc_now`: Execute a literal exact-identifier scan for 'utc_now' to find exact matches across the codebase.
- `loct occurrences utc_now`: Perform a literal boundary-sensitive occurrences scan for 'utc_now' to locate all references.
- `loct slice vibecrafted-core/vibecrafted_core/control_plane.py`: Slice this file to inspect its direct dependencies and immediate consumers before editing.
- `loct impact vibecrafted-core/vibecrafted_core/control_plane.py`: Assess the transitive blast radius and downstream consumers of this file before modifying.
- `loct body RunStatus`: View the definition body of symbol 'RunStatus' to understand its implementation structure.
- `loct find --literal RunStatus`: Execute a literal exact-identifier scan for 'RunStatus' to find exact matches across the codebase.
- `loct occurrences RunStatus`: Perform a literal boundary-sensitive occurrences scan for 'RunStatus' to locate all references.
- `loct slice vibecrafted-core/vibecrafted_core/cron.py`: Slice this file to inspect its direct dependencies and immediate consumers before editing.
- `loct impact vibecrafted-core/vibecrafted_core/cron.py`: Assess the transitive blast radius and downstream consumers of this file before modifying.
- `loct slice vibecrafted-core/vibecrafted_core/dispatch/__init__.py`: Slice this file to inspect its direct dependencies and immediate consumers before editing.
- `loct impact vibecrafted-core/vibecrafted_core/dispatch/__init__.py`: Assess the transitive blast radius and downstream consumers of this file before modifying.
- `loct slice vibecrafted-core/vibecrafted_core/dispatch/cli.py`: Slice this file to inspect its direct dependencies and immediate consumers before editing.
- `loct impact vibecrafted-core/vibecrafted_core/dispatch/cli.py`: Assess the transitive blast radius and downstream consumers of this file before modifying.
- `loct slice vibecrafted-core/vibecrafted_core/dispatch/doctor.py`: Slice this file to inspect its direct dependencies and immediate consumers before editing.
- `loct impact vibecrafted-core/vibecrafted_core/dispatch/doctor.py`: Assess the transitive blast radius and downstream consumers of this file before modifying.
- `loct body DoctorError`: View the definition body of symbol 'DoctorError' to understand its implementation structure.
- `loct find --literal DoctorError`: Execute a literal exact-identifier scan for 'DoctorError' to find exact matches across the codebase.
- `loct occurrences DoctorError`: Perform a literal boundary-sensitive occurrences scan for 'DoctorError' to locate all references.
- `loct slice vibecrafted-core/vibecrafted_core/dispatch/model.py`: Slice this file to inspect its direct dependencies and immediate consumers before editing.
- `loct impact vibecrafted-core/vibecrafted_core/dispatch/model.py`: Assess the transitive blast radius and downstream consumers of this file before modifying.
- `loct body Meta`: View the definition body of symbol 'Meta' to understand its implementation structure.
- `loct find --literal Meta`: Execute a literal exact-identifier scan for 'Meta' to find exact matches across the codebase.
- `loct occurrences Meta`: Perform a literal boundary-sensitive occurrences scan for 'Meta' to locate all references.
- `loct slice vibecrafted-core/vibecrafted_core/dispatch/schema.py`: Slice this file to inspect its direct dependencies and immediate consumers before editing.
- `loct impact vibecrafted-core/vibecrafted_core/dispatch/schema.py`: Assess the transitive blast radius and downstream consumers of this file before modifying.
- `loct body DispatchDoctorResult`: View the definition body of symbol 'DispatchDoctorResult' to understand its implementation structure.
- `loct find --literal DispatchDoctorResult`: Execute a literal exact-identifier scan for 'DispatchDoctorResult' to find exact matches across the codebase.
- `loct occurrences DispatchDoctorResult`: Perform a literal boundary-sensitive occurrences scan for 'DispatchDoctorResult' to locate all references.
- `loct slice vibecrafted-core/vibecrafted_core/dispatch/supervisor.py`: Slice this file to inspect its direct dependencies and immediate consumers before editing.
- `loct impact vibecrafted-core/vibecrafted_core/dispatch/supervisor.py`: Assess the transitive blast radius and downstream consumers of this file before modifying.
- `loct body CellRun`: View the definition body of symbol 'CellRun' to understand its implementation structure.
- `loct find --literal CellRun`: Execute a literal exact-identifier scan for 'CellRun' to find exact matches across the codebase.
- `loct occurrences CellRun`: Perform a literal boundary-sensitive occurrences scan for 'CellRun' to locate all references.
- `loct slice vibecrafted-core/vibecrafted_core/dispatch/verify.py`: Slice this file to inspect its direct dependencies and immediate consumers before editing.
- `loct impact vibecrafted-core/vibecrafted_core/dispatch/verify.py`: Assess the transitive blast radius and downstream consumers of this file before modifying.
- `loct body sanitize_env`: View the definition body of symbol 'sanitize_env' to understand its implementation structure.
- `loct find --literal sanitize_env`: Execute a literal exact-identifier scan for 'sanitize_env' to find exact matches across the codebase.
- `loct occurrences sanitize_env`: Perform a literal boundary-sensitive occurrences scan for 'sanitize_env' to locate all references.
- `loct slice vibecrafted-core/vibecrafted_core/dispatch_contract.py`: Slice this file to inspect its direct dependencies and immediate consumers before editing.
- `loct impact vibecrafted-core/vibecrafted_core/dispatch_contract.py`: Assess the transitive blast radius and downstream consumers of this file before modifying.
- `loct body DispatchMeta`: View the definition body of symbol 'DispatchMeta' to understand its implementation structure.
- `loct find --literal DispatchMeta`: Execute a literal exact-identifier scan for 'DispatchMeta' to find exact matches across the codebase.
- `loct occurrences DispatchMeta`: Perform a literal boundary-sensitive occurrences scan for 'DispatchMeta' to locate all references.
- `loct slice vibecrafted-core/vibecrafted_core/dispatcher.py`: Slice this file to inspect its direct dependencies and immediate consumers before editing.
- `loct impact vibecrafted-core/vibecrafted_core/dispatcher.py`: Assess the transitive blast radius and downstream consumers of this file before modifying.
- `loct slice vibecrafted-core/vibecrafted_core/doctor.py`: Slice this file to inspect its direct dependencies and immediate consumers before editing.
- `loct impact vibecrafted-core/vibecrafted_core/doctor.py`: Assess the transitive blast radius and downstream consumers of this file before modifying.
- `loct body doctor_run`: View the definition body of symbol 'doctor_run' to understand its implementation structure.
- `loct find --literal doctor_run`: Execute a literal exact-identifier scan for 'doctor_run' to find exact matches across the codebase.
- `loct occurrences doctor_run`: Perform a literal boundary-sensitive occurrences scan for 'doctor_run' to locate all references.
- `loct slice vibecrafted-core/vibecrafted_core/events.py`: Slice this file to inspect its direct dependencies and immediate consumers before editing.
- `loct impact vibecrafted-core/vibecrafted_core/events.py`: Assess the transitive blast radius and downstream consumers of this file before modifying.
- `loct body append_event`: View the definition body of symbol 'append_event' to understand its implementation structure.
- `loct find --literal append_event`: Execute a literal exact-identifier scan for 'append_event' to find exact matches across the codebase.
- `loct occurrences append_event`: Perform a literal boundary-sensitive occurrences scan for 'append_event' to locate all references.
- `loct slice vibecrafted-core/vibecrafted_core/git.py`: Slice this file to inspect its direct dependencies and immediate consumers before editing.
- `loct impact vibecrafted-core/vibecrafted_core/git.py`: Assess the transitive blast radius and downstream consumers of this file before modifying.
- `loct body repo_full`: View the definition body of symbol 'repo_full' to understand its implementation structure.
- `loct find --literal repo_full`: Execute a literal exact-identifier scan for 'repo_full' to find exact matches across the codebase.
- `loct occurrences repo_full`: Perform a literal boundary-sensitive occurrences scan for 'repo_full' to locate all references.
- `loct slice vibecrafted-core/vibecrafted_core/lifecycle.py`: Slice this file to inspect its direct dependencies and immediate consumers before editing.
- `loct impact vibecrafted-core/vibecrafted_core/lifecycle.py`: Assess the transitive blast radius and downstream consumers of this file before modifying.
- `loct body RunState`: View the definition body of symbol 'RunState' to understand its implementation structure.
- `loct find --literal RunState`: Execute a literal exact-identifier scan for 'RunState' to find exact matches across the codebase.
- `loct occurrences RunState`: Perform a literal boundary-sensitive occurrences scan for 'RunState' to locate all references.
- `loct slice vibecrafted-core/vibecrafted_core/loop.py`: Slice this file to inspect its direct dependencies and immediate consumers before editing.
- `loct impact vibecrafted-core/vibecrafted_core/loop.py`: Assess the transitive blast radius and downstream consumers of this file before modifying.
- `loct slice vibecrafted-core/vibecrafted_core/memex_client.py`: Slice this file to inspect its direct dependencies and immediate consumers before editing.
- `loct body MemexChunk`: View the definition body of symbol 'MemexChunk' to understand its implementation structure.
- `loct find --literal MemexChunk`: Execute a literal exact-identifier scan for 'MemexChunk' to find exact matches across the codebase.
- `loct occurrences MemexChunk`: Perform a literal boundary-sensitive occurrences scan for 'MemexChunk' to locate all references.
- `loct slice vibecrafted-core/vibecrafted_core/runtime_paths.py`: Slice this file to inspect its direct dependencies and immediate consumers before editing.
- `loct impact vibecrafted-core/vibecrafted_core/runtime_paths.py`: Assess the transitive blast radius and downstream consumers of this file before modifying.
- `loct body read_version_file`: View the definition body of symbol 'read_version_file' to understand its implementation structure.
- `loct find --literal read_version_file`: Execute a literal exact-identifier scan for 'read_version_file' to find exact matches across the codebase.
- `loct occurrences read_version_file`: Perform a literal boundary-sensitive occurrences scan for 'read_version_file' to locate all references.
- `loct slice vibecrafted-core/vibecrafted_core/sandbox/README.md`: Slice this file to inspect its direct dependencies and immediate consumers before editing.
- `loct slice vibecrafted-core/vibecrafted_core/sandbox/__init__.py`: Slice this file to inspect its direct dependencies and immediate consumers before editing.
- `loct impact vibecrafted-core/vibecrafted_core/sandbox/__init__.py`: Assess the transitive blast radius and downstream consumers of this file before modifying.
- `loct slice vibecrafted-core/vibecrafted_core/sandbox/adapter.py`: Slice this file to inspect its direct dependencies and immediate consumers before editing.
- `loct impact vibecrafted-core/vibecrafted_core/sandbox/adapter.py`: Assess the transitive blast radius and downstream consumers of this file before modifying.
- `loct body ExecResult`: View the definition body of symbol 'ExecResult' to understand its implementation structure.
- `loct find --literal ExecResult`: Execute a literal exact-identifier scan for 'ExecResult' to find exact matches across the codebase.
- `loct occurrences ExecResult`: Perform a literal boundary-sensitive occurrences scan for 'ExecResult' to locate all references.
- `loct slice vibecrafted-core/vibecrafted_core/sandbox/msbserver_lifecycle.py`: Slice this file to inspect its direct dependencies and immediate consumers before editing.
- `loct impact vibecrafted-core/vibecrafted_core/sandbox/msbserver_lifecycle.py`: Assess the transitive blast radius and downstream consumers of this file before modifying.
- `loct body MsbserverLifecycle`: View the definition body of symbol 'MsbserverLifecycle' to understand its implementation structure.
- `loct find --literal MsbserverLifecycle`: Execute a literal exact-identifier scan for 'MsbserverLifecycle' to find exact matches across the codebase.
- `loct occurrences MsbserverLifecycle`: Perform a literal boundary-sensitive occurrences scan for 'MsbserverLifecycle' to locate all references.
- `loct slice vibecrafted-core/vibecrafted_core/sandbox/policy.py`: Slice this file to inspect its direct dependencies and immediate consumers before editing.
- `loct impact vibecrafted-core/vibecrafted_core/sandbox/policy.py`: Assess the transitive blast radius and downstream consumers of this file before modifying.
- `loct body SandboxPolicy`: View the definition body of symbol 'SandboxPolicy' to understand its implementation structure.
- `loct find --literal SandboxPolicy`: Execute a literal exact-identifier scan for 'SandboxPolicy' to find exact matches across the codebase.
- `loct occurrences SandboxPolicy`: Perform a literal boundary-sensitive occurrences scan for 'SandboxPolicy' to locate all references.
- `loct slice vibecrafted-core/vibecrafted_core/ship.py`: Slice this file to inspect its direct dependencies and immediate consumers before editing.
- `loct impact vibecrafted-core/vibecrafted_core/ship.py`: Assess the transitive blast radius and downstream consumers of this file before modifying.
- `loct body deck_command`: View the definition body of symbol 'deck_command' to understand its implementation structure.
- `loct find --literal deck_command`: Execute a literal exact-identifier scan for 'deck_command' to find exact matches across the codebase.
- `loct occurrences deck_command`: Perform a literal boundary-sensitive occurrences scan for 'deck_command' to locate all references.
- `loct slice vibecrafted-core/vibecrafted_core/spawn.py`: Slice this file to inspect its direct dependencies and immediate consumers before editing.
- `loct impact vibecrafted-core/vibecrafted_core/spawn.py`: Assess the transitive blast radius and downstream consumers of this file before modifying.
- `loct body SpawnHandle`: View the definition body of symbol 'SpawnHandle' to understand its implementation structure.
- `loct find --literal SpawnHandle`: Execute a literal exact-identifier scan for 'SpawnHandle' to find exact matches across the codebase.
- `loct occurrences SpawnHandle`: Perform a literal boundary-sensitive occurrences scan for 'SpawnHandle' to locate all references.
- `loct slice vibecrafted-core/vibecrafted_core/supervisor_async.py`: Slice this file to inspect its direct dependencies and immediate consumers before editing.
- `loct impact vibecrafted-core/vibecrafted_core/supervisor_async.py`: Assess the transitive blast radius and downstream consumers of this file before modifying.
- `loct body AsyncRunHandle`: View the definition body of symbol 'AsyncRunHandle' to understand its implementation structure.
- `loct find --literal AsyncRunHandle`: Execute a literal exact-identifier scan for 'AsyncRunHandle' to find exact matches across the codebase.
- `loct occurrences AsyncRunHandle`: Perform a literal boundary-sensitive occurrences scan for 'AsyncRunHandle' to locate all references.
- `loct slice vibecrafted-core/vibecrafted_core/ui.py`: Slice this file to inspect its direct dependencies and immediate consumers before editing.
- `loct impact vibecrafted-core/vibecrafted_core/ui.py`: Assess the transitive blast radius and downstream consumers of this file before modifying.
- `loct body stage`: View the definition body of symbol 'stage' to understand its implementation structure.
- `loct find --literal stage`: Execute a literal exact-identifier scan for 'stage' to find exact matches across the codebase.
- `loct occurrences stage`: Perform a literal boundary-sensitive occurrences scan for 'stage' to locate all references.
- `loct slice vibecrafted-core/vibecrafted_core/workflow.py`: Slice this file to inspect its direct dependencies and immediate consumers before editing.
- `loct impact vibecrafted-core/vibecrafted_core/workflow.py`: Assess the transitive blast radius and downstream consumers of this file before modifying.
- `loct body WorkflowLaunchSpec`: View the definition body of symbol 'WorkflowLaunchSpec' to understand its implementation structure.
- `loct find --literal WorkflowLaunchSpec`: Execute a literal exact-identifier scan for 'WorkflowLaunchSpec' to find exact matches across the codebase.
- `loct occurrences WorkflowLaunchSpec`: Perform a literal boundary-sensitive occurrences scan for 'WorkflowLaunchSpec' to locate all references.
- `loct slice vibecrafted-core/vibecrafted_core/workflow_runtime.py`: Slice this file to inspect its direct dependencies and immediate consumers before editing.
- `loct impact vibecrafted-core/vibecrafted_core/workflow_runtime.py`: Assess the transitive blast radius and downstream consumers of this file before modifying.
- `loct body ChildResult`: View the definition body of symbol 'ChildResult' to understand its implementation structure.
- `loct find --literal ChildResult`: Execute a literal exact-identifier scan for 'ChildResult' to find exact matches across the codebase.
- `loct occurrences ChildResult`: Perform a literal boundary-sensitive occurrences scan for 'ChildResult' to locate all references.
- `loct slice vibecrafted-core/vibecrafted_core/workflows/__init__.py`: Slice this file to inspect its direct dependencies and immediate consumers before editing.
- `loct impact vibecrafted-core/vibecrafted_core/workflows/__init__.py`: Assess the transitive blast radius and downstream consumers of this file before modifying.
- `loct slice vibecrafted-core/vibecrafted_core/workflows/model.py`: Slice this file to inspect its direct dependencies and immediate consumers before editing.
- `loct impact vibecrafted-core/vibecrafted_core/workflows/model.py`: Assess the transitive blast radius and downstream consumers of this file before modifying.
- `loct body WorkflowDefinition`: View the definition body of symbol 'WorkflowDefinition' to understand its implementation structure.
- `loct find --literal WorkflowDefinition`: Execute a literal exact-identifier scan for 'WorkflowDefinition' to find exact matches across the codebase.
- `loct occurrences WorkflowDefinition`: Perform a literal boundary-sensitive occurrences scan for 'WorkflowDefinition' to locate all references.
- `loct slice vibecrafted-core/vibecrafted_core/workflows/registry.py`: Slice this file to inspect its direct dependencies and immediate consumers before editing.
- `loct impact vibecrafted-core/vibecrafted_core/workflows/registry.py`: Assess the transitive blast radius and downstream consumers of this file before modifying.
- `loct body workflow_definition`: View the definition body of symbol 'workflow_definition' to understand its implementation structure.
- `loct find --literal workflow_definition`: Execute a literal exact-identifier scan for 'workflow_definition' to find exact matches across the codebase.
- `loct occurrences workflow_definition`: Perform a literal boundary-sensitive occurrences scan for 'workflow_definition' to locate all references.
- `loct slice vibecrafted-core/vibecrafted_core/wrappers.py`: Slice this file to inspect its direct dependencies and immediate consumers before editing.
- `loct impact vibecrafted-core/vibecrafted_core/wrappers.py`: Assess the transitive blast radius and downstream consumers of this file before modifying.
- `loct body repo_root`: View the definition body of symbol 'repo_root' to understand its implementation structure.
- `loct find --literal repo_root`: Execute a literal exact-identifier scan for 'repo_root' to find exact matches across the codebase.
- `loct occurrences repo_root`: Perform a literal boundary-sensitive occurrences scan for 'repo_root' to locate all references.

### Next Safe Commands

```bash
loct context --file vibecrafted-core/README.md
loct context --file vibecrafted-core/pyproject.toml
loct context --file vibecrafted-core/tests/__init__.py
```

### Verification Gates

```bash
mypy .
```

### Likely Tests

- `plugins/iterm2/tests/test_iterm2_osc.py`
- `plugins/iterm2/tests/test_iterm2_plugin.py`
- `plugins/iterm2/tests/test_iterm2_profiles.py`
- `tests/agent_dispatch_test.py`
- `tests/tui/test_agy_junie_pipeline.py`
- `tests/tui/test_artifact_truth.py`
- `tests/tui/test_atuin_fallback.py`
- `tests/tui/test_await_observe_contract.py`
- `tests/tui/test_codex_stream_bridge.py`
- `tests/tui/test_keys.py`

## Memory Slice

_Empty_

## Authority Slice

- Repo Verified: 15
- Loctree Derived: 104
- AICX Operator: 0
- AICX Agent: 0
- AICX Failure: 0
- Semantic Guess: 10
- Stale Or Unknown: 0

