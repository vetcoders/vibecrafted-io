# Loctree Context Pack

## Project Identity

- **Root**: `/Users/maciejgad/vc-workspace/vetcoders/vibecrafted`
- **Branch**: `feat/runtime-integration`
- **Commit**: `9f76009`
- **Snapshot**: `feat_runtime-integration@9f76009`

## Where You Are

### Files

| Path | Role | Language | LOC | Authority |
|---|---|---|---|---|
| `vibecrafted-app/shell-agent/app/Vibecrafted/Bridge/vibecrafted_shell_ffi.swift` | `Consumer` | swift | 1447 | *RepoVerified* |
| `vibecrafted-server/Cargo.toml` | `Target` | toml | 6 | *RepoVerified* |
| `vibecrafted-server/README.md` | `Target` | md | 73 | *RepoVerified* |
| `vibecrafted-server/control-core/Cargo.toml` | `Target` | toml | 22 | *RepoVerified* |
| `vibecrafted-server/control-core/examples/dump.rs` | `Target` | rs | 53 | *RepoVerified* |
| `vibecrafted-server/control-core/src/events.rs` | `Target` | rs | 117 | *RepoVerified* |
| `vibecrafted-server/control-core/src/lib.rs` | `Consumer` | rs | 55 | *RepoVerified* |
| `vibecrafted-server/control-core/src/model.rs` | `Dependency` | rs | 482 | *RepoVerified* |
| `vibecrafted-server/control-core/src/read.rs` | `Consumer` | rs | 475 | *RepoVerified* |
| `vibecrafted-server/control-core/src/scaffold.rs` | `Dependency` | rs | 591 | *RepoVerified* |
| `vibecrafted-server/control-core/tests/scaffold_artifacts.rs` | `Target` | rs | 77 | *RepoVerified* |
| `vibecrafted-server/control-core/tests/schema_fidelity.rs` | `Target` | rs | 258 | *RepoVerified* |
| `vibecrafted-server/web/Cargo.toml` | `Target` | toml | 97 | *RepoVerified* |
| `vibecrafted-server/web/src/app.rs` | `Target` | rs | 322 | *RepoVerified* |
| `vibecrafted-server/web/src/control/mod.rs` | `Target` | rs | 85 | *RepoVerified* |
| `vibecrafted-server/web/src/lib.rs` | `Consumer` | rs | 15 | *RepoVerified* |
| `vibecrafted-server/web/src/main.rs` | `Target` | rs | 114 | *RepoVerified* |
| `vibecrafted-server/web/src/scaffold/mod.rs` | `Dependency` | rs | 519 | *RepoVerified* |
| `vibecrafted-server/web/src/theme.rs` | `Dependency` | rs | 102 | *RepoVerified* |
| `vibecrafted-server/web/styles/fonts.css` | `Target` | css | 131 | *RepoVerified* |
| `vibecrafted-server/web/styles/main.css` | `Target` | css | 1675 | *RepoVerified* |
| `vibecrafted-server/web/styles/tokens.css` | `Target` | css | 299 | *RepoVerified* |

### Symbols

| File | Name | Kind | Export Type | Line | Authority |
|---|---|---|---|---|---|
| `vibecrafted-server/control-core/src/events.rs` | `EventBatch` | struct | named | 30 | *RepoVerified* |
| `vibecrafted-server/control-core/src/events.rs` | `EventStream` | struct | named | 24 | *RepoVerified* |
| `vibecrafted-server/control-core/src/events.rs` | `new` | function | named | 42 | *RepoVerified* |
| `vibecrafted-server/control-core/src/events.rs` | `path` | function | named | 48 | *RepoVerified* |
| `vibecrafted-server/control-core/src/events.rs` | `read_all` | function | named | 102 | *RepoVerified* |
| `vibecrafted-server/control-core/src/events.rs` | `read_since` | function | named | 58 | *RepoVerified* |
| `vibecrafted-server/control-core/src/events.rs` | `tail` | function | named | 108 | *RepoVerified* |
| `vibecrafted-server/control-core/src/lib.rs` | `ACTIVE_STATES` | reexport | named |  | *RepoVerified* |
| `vibecrafted-server/control-core/src/lib.rs` | `AgentMeta` | reexport | named |  | *RepoVerified* |
| `vibecrafted-server/control-core/src/lib.rs` | `ControlPlane` | reexport | named |  | *RepoVerified* |
| `vibecrafted-server/control-core/src/lib.rs` | `EVENT_TAIL_LIMIT` | reexport | named |  | *RepoVerified* |
| `vibecrafted-server/control-core/src/lib.rs` | `Event` | reexport | named |  | *RepoVerified* |
| `vibecrafted-server/control-core/src/lib.rs` | `EventBatch` | reexport | named |  | *RepoVerified* |
| `vibecrafted-server/control-core/src/lib.rs` | `EventStream` | reexport | named |  | *RepoVerified* |
| `vibecrafted-server/control-core/src/lib.rs` | `FINAL_STATES` | reexport | named |  | *RepoVerified* |
| `vibecrafted-server/control-core/src/lib.rs` | `Health` | reexport | named |  | *RepoVerified* |
| `vibecrafted-server/control-core/src/lib.rs` | `RECENT_RUN_LIMIT` | reexport | named |  | *RepoVerified* |
| `vibecrafted-server/control-core/src/lib.rs` | `RUN_STALL_SECONDS` | reexport | named |  | *RepoVerified* |
| `vibecrafted-server/control-core/src/lib.rs` | `RunStatus` | reexport | named |  | *RepoVerified* |
| `vibecrafted-server/control-core/src/lib.rs` | `SKILL_CODE_MAP` | reexport | named |  | *RepoVerified* |
| `vibecrafted-server/control-core/src/lib.rs` | `ScaffoldArtifact` | reexport | named |  | *RepoVerified* |
| `vibecrafted-server/control-core/src/lib.rs` | `ScaffoldArtifactKind` | reexport | named |  | *RepoVerified* |
| `vibecrafted-server/control-core/src/lib.rs` | `ScaffoldArtifactPatch` | reexport | named |  | *RepoVerified* |
| `vibecrafted-server/control-core/src/lib.rs` | `ScaffoldArtifactStore` | reexport | named |  | *RepoVerified* |
| `vibecrafted-server/control-core/src/lib.rs` | `ScaffoldChange` | reexport | named |  | *RepoVerified* |
| `vibecrafted-server/control-core/src/lib.rs` | `ScaffoldCheckpoint` | reexport | named |  | *RepoVerified* |
| `vibecrafted-server/control-core/src/lib.rs` | `ScaffoldCheckpointPatch` | reexport | named |  | *RepoVerified* |
| `vibecrafted-server/control-core/src/lib.rs` | `ScaffoldWorkspace` | reexport | named |  | *RepoVerified* |
| `vibecrafted-server/control-core/src/lib.rs` | `StateClass` | reexport | named |  | *RepoVerified* |
| `vibecrafted-server/control-core/src/lib.rs` | `StateView` | reexport | named |  | *RepoVerified* |
| `vibecrafted-server/control-core/src/lib.rs` | `classify_state` | reexport | named |  | *RepoVerified* |
| `vibecrafted-server/control-core/src/lib.rs` | `coerce_int_value` | reexport | named |  | *RepoVerified* |
| `vibecrafted-server/control-core/src/lib.rs` | `is_active_state` | reexport | named |  | *RepoVerified* |
| `vibecrafted-server/control-core/src/lib.rs` | `is_final_state` | reexport | named |  | *RepoVerified* |
| `vibecrafted-server/control-core/src/lib.rs` | `merge_status` | reexport | named |  | *RepoVerified* |
| `vibecrafted-server/control-core/src/lib.rs` | `operator_session_name` | reexport | named |  | *RepoVerified* |
| `vibecrafted-server/control-core/src/lib.rs` | `parse_iso` | reexport | named |  | *RepoVerified* |
| `vibecrafted-server/control-core/src/lib.rs` | `skill_from_code` | reexport | named |  | *RepoVerified* |
| `vibecrafted-server/control-core/src/lib.rs` | `state_health` | reexport | named |  | *RepoVerified* |
| `vibecrafted-server/control-core/src/lib.rs` | `vibecrafted_home` | reexport | named |  | *RepoVerified* |
| `vibecrafted-server/control-core/src/model.rs` | `ACTIVE_STATES` | decl | named | 35 | *RepoVerified* |
| `vibecrafted-server/control-core/src/model.rs` | `AgentMeta` | struct | named | 334 | *RepoVerified* |
| `vibecrafted-server/control-core/src/model.rs` | `EVENT_TAIL_LIMIT` | decl | named | 28 | *RepoVerified* |
| `vibecrafted-server/control-core/src/model.rs` | `Event` | struct | named | 316 | *RepoVerified* |
| `vibecrafted-server/control-core/src/model.rs` | `FINAL_STATES` | decl | named | 46 | *RepoVerified* |
| `vibecrafted-server/control-core/src/model.rs` | `Health` | enum | named | 123 | *RepoVerified* |
| `vibecrafted-server/control-core/src/model.rs` | `RECENT_RUN_LIMIT` | decl | named | 32 | *RepoVerified* |
| `vibecrafted-server/control-core/src/model.rs` | `RUN_STALL_SECONDS` | decl | named | 24 | *RepoVerified* |
| `vibecrafted-server/control-core/src/model.rs` | `RunStatus` | struct | named | 262 | *RepoVerified* |
| `vibecrafted-server/control-core/src/model.rs` | `SKILL_CODE_MAP` | decl | named | 59 | *RepoVerified* |
| `vibecrafted-server/control-core/src/model.rs` | `StateClass` | enum | named | 98 | *RepoVerified* |
| `vibecrafted-server/control-core/src/model.rs` | `as_str` | function | named | 137 | *RepoVerified* |
| `vibecrafted-server/control-core/src/model.rs` | `classify_state` | function | named | 109 | *RepoVerified* |
| `vibecrafted-server/control-core/src/model.rs` | `coerce_int_value` | function | named | 165 | *RepoVerified* |
| `vibecrafted-server/control-core/src/model.rs` | `is_active_state` | function | named | 82 | *RepoVerified* |
| `vibecrafted-server/control-core/src/model.rs` | `is_final_state` | function | named | 88 | *RepoVerified* |
| `vibecrafted-server/control-core/src/model.rs` | `is_terminal` | function | named | 298 | *RepoVerified* |
| `vibecrafted-server/control-core/src/model.rs` | `merge_status` | function | named | 439 | *RepoVerified* |
| `vibecrafted-server/control-core/src/model.rs` | `normalize` | function | named | 384 | *RepoVerified* |
| `vibecrafted-server/control-core/src/model.rs` | `operator_session_name` | function | named | 241 | *RepoVerified* |
| `vibecrafted-server/control-core/src/model.rs` | `parse_iso` | function | named | 152 | *RepoVerified* |
| `vibecrafted-server/control-core/src/model.rs` | `skill_from_code` | function | named | 206 | *RepoVerified* |
| `vibecrafted-server/control-core/src/model.rs` | `state_class` | function | named | 304 | *RepoVerified* |
| `vibecrafted-server/control-core/src/model.rs` | `state_health` | function | named | 186 | *RepoVerified* |
| `vibecrafted-server/control-core/src/read.rs` | `ControlPlane` | struct | named | 58 | *RepoVerified* |
| `vibecrafted-server/control-core/src/read.rs` | `StateView` | struct | named | 65 | *RepoVerified* |
| `vibecrafted-server/control-core/src/read.rs` | `compute_view` | function | named | 184 | *RepoVerified* |
| `vibecrafted-server/control-core/src/read.rs` | `control_plane_home` | function | named | 92 | *RepoVerified* |
| `vibecrafted-server/control-core/src/read.rs` | `event_stream_path` | function | named | 104 | *RepoVerified* |
| `vibecrafted-server/control-core/src/read.rs` | `events` | function | named | 110 | *RepoVerified* |
| `vibecrafted-server/control-core/src/read.rs` | `from_env` | function | named | 86 | *RepoVerified* |
| `vibecrafted-server/control-core/src/read.rs` | `load_snapshots` | function | named | 118 | *RepoVerified* |
| `vibecrafted-server/control-core/src/read.rs` | `lookup_run` | function | named | 148 | *RepoVerified* |
| `vibecrafted-server/control-core/src/read.rs` | `new` | function | named | 80 | *RepoVerified* |
| `vibecrafted-server/control-core/src/read.rs` | `read_event_tail` | function | named | 166 | *RepoVerified* |
| `vibecrafted-server/control-core/src/read.rs` | `read_state_view` | function | named | 174 | *RepoVerified* |
| `vibecrafted-server/control-core/src/read.rs` | `run_snapshot_dir` | function | named | 98 | *RepoVerified* |
| `vibecrafted-server/control-core/src/read.rs` | `vibecrafted_home` | function | named | 45 | *RepoVerified* |
| `vibecrafted-server/control-core/src/scaffold.rs` | `ScaffoldArtifact` | struct | named | 50 | *RepoVerified* |
| `vibecrafted-server/control-core/src/scaffold.rs` | `ScaffoldArtifactKind` | enum | named | 20 | *RepoVerified* |
| `vibecrafted-server/control-core/src/scaffold.rs` | `ScaffoldArtifactPatch` | struct | named | 76 | *RepoVerified* |
| `vibecrafted-server/control-core/src/scaffold.rs` | `ScaffoldArtifactStore` | struct | named | 109 | *RepoVerified* |
| `vibecrafted-server/control-core/src/scaffold.rs` | `ScaffoldChange` | struct | named | 91 | *RepoVerified* |
| `vibecrafted-server/control-core/src/scaffold.rs` | `ScaffoldCheckpoint` | struct | named | 41 | *RepoVerified* |
| `vibecrafted-server/control-core/src/scaffold.rs` | `ScaffoldCheckpointPatch` | struct | named | 83 | *RepoVerified* |
| `vibecrafted-server/control-core/src/scaffold.rs` | `ScaffoldWorkspace` | struct | named | 64 | *RepoVerified* |
| `vibecrafted-server/control-core/src/scaffold.rs` | `as_str` | function | named | 29 | *RepoVerified* |
| `vibecrafted-server/control-core/src/scaffold.rs` | `changes` | function | named | 279 | *RepoVerified* |
| `vibecrafted-server/control-core/src/scaffold.rs` | `checkpoint` | function | named | 238 | *RepoVerified* |
| `vibecrafted-server/control-core/src/scaffold.rs` | `latest_workspace` | function | named | 136 | *RepoVerified* |
| `vibecrafted-server/control-core/src/scaffold.rs` | `new` | function | named | 115 | *RepoVerified* |
| `vibecrafted-server/control-core/src/scaffold.rs` | `operator_dir` | function | named | 120 | *RepoVerified* |
| `vibecrafted-server/control-core/src/scaffold.rs` | `workspace` | function | named | 150 | *RepoVerified* |
| `vibecrafted-server/control-core/src/scaffold.rs` | `write_artifact` | function | named | 200 | *RepoVerified* |
| `vibecrafted-server/web/src/app.rs` | `App` | function | named | 176 | *RepoVerified* |
| `vibecrafted-server/web/src/app.rs` | `ConsolePage` | function | named | 192 | *RepoVerified* |
| `vibecrafted-server/web/src/app.rs` | `shell` | function | named | 148 | *RepoVerified* |
| `vibecrafted-server/web/src/control/mod.rs` | `control_routes` | function | named | 31 | *RepoVerified* |
| `vibecrafted-server/web/src/lib.rs` | `hydrate` | function | named | 10 | *RepoVerified* |
| `vibecrafted-server/web/src/scaffold/mod.rs` | `CheckpointForm` | struct | named | 55 | *RepoVerified* |
| `vibecrafted-server/web/src/scaffold/mod.rs` | `SaveArtifactForm` | struct | named | 46 | *RepoVerified* |
| `vibecrafted-server/web/src/scaffold/mod.rs` | `ScaffoldEditorPage` | function | named | 5 | *RepoVerified* |
| `vibecrafted-server/web/src/scaffold/mod.rs` | `ScaffoldQuery` | struct | named | 39 | *RepoVerified* |
| `vibecrafted-server/web/src/scaffold/mod.rs` | `scaffold_routes` | function | named | 66 | *RepoVerified* |
| `vibecrafted-server/web/src/theme.rs` | `Theme` | enum | named | 6 | *RepoVerified* |
| `vibecrafted-server/web/src/theme.rs` | `ThemeBridge` | function | named | 64 | *RepoVerified* |
| `vibecrafted-server/web/src/theme.rs` | `ThemeContext` | struct | named | 37 | *RepoVerified* |
| `vibecrafted-server/web/src/theme.rs` | `code` | function | named | 13 | *RepoVerified* |
| `vibecrafted-server/web/src/theme.rs` | `from_code` | function | named | 20 | *RepoVerified* |
| `vibecrafted-server/web/src/theme.rs` | `new` | function | named | 42 | *RepoVerified* |
| `vibecrafted-server/web/src/theme.rs` | `provide_theme_context` | function | named | 55 | *RepoVerified* |
| `vibecrafted-server/web/src/theme.rs` | `toggle` | function | named | 28 | *RepoVerified* |
| `vibecrafted-server/web/src/theme.rs` | `use_theme` | function | named | 59 | *RepoVerified* |

### Imports

| File | Source | Kind | Resolution | Authority |
|---|---|---|---|---|
| `vibecrafted-server/control-core/examples/dump.rs` | `chrono::Utc` | static | unknown | *RepoVerified* |
| `vibecrafted-server/control-core/examples/dump.rs` | `control_core::ControlPlane` | static | unknown | *RepoVerified* |
| `vibecrafted-server/control-core/src/events.rs` | `crate::model::Event` | static | unknown | *RepoVerified* |
| `vibecrafted-server/control-core/src/events.rs` | `std::fs::File` | static | unknown | *RepoVerified* |
| `vibecrafted-server/control-core/src/events.rs` | `std::io` | static | unknown | *RepoVerified* |
| `vibecrafted-server/control-core/src/events.rs` | `std::path::PathBuf` | static | unknown | *RepoVerified* |
| `vibecrafted-server/control-core/src/lib.rs` | `events` | static | unknown | *RepoVerified* |
| `vibecrafted-server/control-core/src/lib.rs` | `mod::events` | static | unknown | *RepoVerified* |
| `vibecrafted-server/control-core/src/lib.rs` | `mod::model` | static | unknown | *RepoVerified* |
| `vibecrafted-server/control-core/src/lib.rs` | `mod::read` | static | unknown | *RepoVerified* |
| `vibecrafted-server/control-core/src/lib.rs` | `mod::scaffold` | static | unknown | *RepoVerified* |
| `vibecrafted-server/control-core/src/lib.rs` | `model` | static | unknown | *RepoVerified* |
| `vibecrafted-server/control-core/src/lib.rs` | `read` | static | unknown | *RepoVerified* |
| `vibecrafted-server/control-core/src/lib.rs` | `scaffold` | static | unknown | *RepoVerified* |
| `vibecrafted-server/control-core/src/model.rs` | `chrono` | static | unknown | *RepoVerified* |
| `vibecrafted-server/control-core/src/model.rs` | `serde` | static | unknown | *RepoVerified* |
| `vibecrafted-server/control-core/src/model.rs` | `std::collections::BTreeMap` | static | unknown | *RepoVerified* |
| `vibecrafted-server/control-core/src/model.rs` | `std::path::Path` | static | unknown | *RepoVerified* |
| `vibecrafted-server/control-core/src/read.rs` | `chrono` | static | unknown | *RepoVerified* |
| `vibecrafted-server/control-core/src/read.rs` | `crate::events::EventStream` | static | unknown | *RepoVerified* |
| `vibecrafted-server/control-core/src/read.rs` | `crate::model` | static | unknown | *RepoVerified* |
| `vibecrafted-server/control-core/src/read.rs` | `std::fs` | static | unknown | *RepoVerified* |
| `vibecrafted-server/control-core/src/read.rs` | `std::path` | static | unknown | *RepoVerified* |
| `vibecrafted-server/control-core/src/scaffold.rs` | `chrono::Utc` | static | unknown | *RepoVerified* |
| `vibecrafted-server/control-core/src/scaffold.rs` | `serde` | static | unknown | *RepoVerified* |
| `vibecrafted-server/control-core/src/scaffold.rs` | `std::collections::BTreeMap` | static | unknown | *RepoVerified* |
| `vibecrafted-server/control-core/src/scaffold.rs` | `std::fs` | static | unknown | *RepoVerified* |
| `vibecrafted-server/control-core/src/scaffold.rs` | `std::io` | static | unknown | *RepoVerified* |
| `vibecrafted-server/control-core/src/scaffold.rs` | `std::path` | static | unknown | *RepoVerified* |
| `vibecrafted-server/control-core/tests/scaffold_artifacts.rs` | `control_core` | static | unknown | *RepoVerified* |
| `vibecrafted-server/control-core/tests/scaffold_artifacts.rs` | `std::fs` | static | unknown | *RepoVerified* |
| `vibecrafted-server/control-core/tests/scaffold_artifacts.rs` | `std::path::PathBuf` | static | unknown | *RepoVerified* |
| `vibecrafted-server/control-core/tests/schema_fidelity.rs` | `chrono::Duration` | static | unknown | *RepoVerified* |
| `vibecrafted-server/control-core/tests/schema_fidelity.rs` | `control_core::model` | static | unknown | *RepoVerified* |
| `vibecrafted-server/control-core/tests/schema_fidelity.rs` | `control_core` | static | unknown | *RepoVerified* |
| `vibecrafted-server/control-core/tests/schema_fidelity.rs` | `std::collections::BTreeSet` | static | unknown | *RepoVerified* |
| `vibecrafted-server/web/src/app.rs` | `crate::scaffold::ScaffoldEditorPage` | static | unknown | *RepoVerified* |
| `vibecrafted-server/web/src/app.rs` | `crate::theme` | static | unknown | *RepoVerified* |
| `vibecrafted-server/web/src/app.rs` | `leptos::prelude` | static | unknown | *RepoVerified* |
| `vibecrafted-server/web/src/app.rs` | `leptos_meta` | static | unknown | *RepoVerified* |
| `vibecrafted-server/web/src/app.rs` | `leptos_router::components` | static | unknown | *RepoVerified* |
| `vibecrafted-server/web/src/app.rs` | `leptos_router::path` | static | unknown | *RepoVerified* |
| `vibecrafted-server/web/src/control/mod.rs` | `axum::Json` | static | unknown | *RepoVerified* |
| `vibecrafted-server/web/src/control/mod.rs` | `axum::Router` | static | unknown | *RepoVerified* |
| `vibecrafted-server/web/src/control/mod.rs` | `axum::extract::Path` | static | unknown | *RepoVerified* |
| `vibecrafted-server/web/src/control/mod.rs` | `axum::http::StatusCode` | static | unknown | *RepoVerified* |
| `vibecrafted-server/web/src/control/mod.rs` | `axum::response::IntoResponse` | static | unknown | *RepoVerified* |
| `vibecrafted-server/web/src/control/mod.rs` | `axum::routing::get` | static | unknown | *RepoVerified* |
| `vibecrafted-server/web/src/control/mod.rs` | `chrono::Utc` | static | unknown | *RepoVerified* |
| `vibecrafted-server/web/src/control/mod.rs` | `control_core` | static | unknown | *RepoVerified* |
| `vibecrafted-server/web/src/control/mod.rs` | `serde_json::json` | static | unknown | *RepoVerified* |
| `vibecrafted-server/web/src/lib.rs` | `mod::app` | static | unknown | *RepoVerified* |
| `vibecrafted-server/web/src/lib.rs` | `mod::control` | static | unknown | *RepoVerified* |
| `vibecrafted-server/web/src/lib.rs` | `mod::scaffold` | static | unknown | *RepoVerified* |
| `vibecrafted-server/web/src/lib.rs` | `mod::theme` | static | unknown | *RepoVerified* |
| `vibecrafted-server/web/src/scaffold/mod.rs` | `axum::extract` | static | unknown | *RepoVerified* |
| `vibecrafted-server/web/src/scaffold/mod.rs` | `axum::http` | static | unknown | *RepoVerified* |
| `vibecrafted-server/web/src/scaffold/mod.rs` | `axum::response` | static | unknown | *RepoVerified* |
| `vibecrafted-server/web/src/scaffold/mod.rs` | `axum::routing` | static | unknown | *RepoVerified* |
| `vibecrafted-server/web/src/scaffold/mod.rs` | `axum` | static | unknown | *RepoVerified* |
| `vibecrafted-server/web/src/scaffold/mod.rs` | `control_core` | static | unknown | *RepoVerified* |
| `vibecrafted-server/web/src/scaffold/mod.rs` | `leptos::prelude` | static | unknown | *RepoVerified* |
| `vibecrafted-server/web/src/scaffold/mod.rs` | `leptos_meta` | static | unknown | *RepoVerified* |
| `vibecrafted-server/web/src/scaffold/mod.rs` | `serde::Deserialize` | static | unknown | *RepoVerified* |
| `vibecrafted-server/web/src/theme.rs` | `leptos::prelude` | static | unknown | *RepoVerified* |

### Consumers

| File | Import Kind | Imports Used | Authority |
|---|---|---|---|
| `vibecrafted-app/shell-agent/app/Vibecrafted/Bridge/vibecrafted_shell_ffi.swift` | `Direct` |  | *RepoVerified* |
| `vibecrafted-server/control-core/src/events.rs` | `Direct` | Event | *RepoVerified* |
| `vibecrafted-server/control-core/src/lib.rs` | `Reexport` | EventBatch, EventStream, events | *RepoVerified* |
| `vibecrafted-server/control-core/src/read.rs` | `Direct` | EventStream | *RepoVerified* |
| `vibecrafted-server/web/src/app.rs` | `Direct` | ScaffoldEditorPage | *RepoVerified* |
| `vibecrafted-server/web/src/lib.rs` | `Direct` | app | *RepoVerified* |

### Entrypoints

| Path | Kinds | Authority |
|---|---|---|
| `vibecrafted-server/control-core/examples/dump.rs` | main | *RepoVerified* |
| `vibecrafted-server/web/src/main.rs` | main, async_main | *RepoVerified* |

## Runtime Slice

### Idiom Tags

- **new** (`vibecrafted-server/control-core/src/events.rs::new`): Idiomatic Rust constructor convention; called via Type::new(...) across the ecosystem. (Role: library_helper, Source: embedded_default) *LoctreeDerived*
- **path** (`vibecrafted-server/control-core/src/events.rs::path`): Defined inside inherent `impl EventStream` block; reached via method-call syntax. (Role: library_helper, Source: inferred_from_code) *SemanticGuess*
- **read_all** (`vibecrafted-server/control-core/src/events.rs::read_all`): Defined inside inherent `impl EventStream` block; reached via method-call syntax. (Role: library_helper, Source: inferred_from_code) *SemanticGuess*
- **read_since** (`vibecrafted-server/control-core/src/events.rs::read_since`): Defined inside inherent `impl EventStream` block; reached via method-call syntax. (Role: library_helper, Source: inferred_from_code) *SemanticGuess*
- **tail** (`vibecrafted-server/control-core/src/events.rs::tail`): Defined inside inherent `impl EventStream` block; reached via method-call syntax. (Role: library_helper, Source: inferred_from_code) *SemanticGuess*
- **ACTIVE_STATES** (`vibecrafted-server/control-core/src/lib.rs::ACTIVE_STATES`): Re-exported via `pub use`; reached through downstream importers. (Role: public_entrypoint, Source: inferred_from_code) *SemanticGuess*
- **AgentMeta** (`vibecrafted-server/control-core/src/lib.rs::AgentMeta`): Re-exported via `pub use`; reached through downstream importers. (Role: public_entrypoint, Source: inferred_from_code) *SemanticGuess*
- **ControlPlane** (`vibecrafted-server/control-core/src/lib.rs::ControlPlane`): Re-exported via `pub use`; reached through downstream importers. (Role: public_entrypoint, Source: inferred_from_code) *SemanticGuess*
- **EVENT_TAIL_LIMIT** (`vibecrafted-server/control-core/src/lib.rs::EVENT_TAIL_LIMIT`): Re-exported via `pub use`; reached through downstream importers. (Role: public_entrypoint, Source: inferred_from_code) *SemanticGuess*
- **Event** (`vibecrafted-server/control-core/src/lib.rs::Event`): Re-exported via `pub use`; reached through downstream importers. (Role: public_entrypoint, Source: inferred_from_code) *SemanticGuess*
- **EventBatch** (`vibecrafted-server/control-core/src/lib.rs::EventBatch`): Re-exported via `pub use`; reached through downstream importers. (Role: public_entrypoint, Source: inferred_from_code) *SemanticGuess*
- **EventStream** (`vibecrafted-server/control-core/src/lib.rs::EventStream`): Re-exported via `pub use`; reached through downstream importers. (Role: public_entrypoint, Source: inferred_from_code) *SemanticGuess*
- **FINAL_STATES** (`vibecrafted-server/control-core/src/lib.rs::FINAL_STATES`): Re-exported via `pub use`; reached through downstream importers. (Role: public_entrypoint, Source: inferred_from_code) *SemanticGuess*
- **Health** (`vibecrafted-server/control-core/src/lib.rs::Health`): Re-exported via `pub use`; reached through downstream importers. (Role: public_entrypoint, Source: inferred_from_code) *SemanticGuess*
- **RECENT_RUN_LIMIT** (`vibecrafted-server/control-core/src/lib.rs::RECENT_RUN_LIMIT`): Re-exported via `pub use`; reached through downstream importers. (Role: public_entrypoint, Source: inferred_from_code) *SemanticGuess*
- **RUN_STALL_SECONDS** (`vibecrafted-server/control-core/src/lib.rs::RUN_STALL_SECONDS`): Re-exported via `pub use`; reached through downstream importers. (Role: public_entrypoint, Source: inferred_from_code) *SemanticGuess*
- **RunStatus** (`vibecrafted-server/control-core/src/lib.rs::RunStatus`): Re-exported via `pub use`; reached through downstream importers. (Role: public_entrypoint, Source: inferred_from_code) *SemanticGuess*
- **SKILL_CODE_MAP** (`vibecrafted-server/control-core/src/lib.rs::SKILL_CODE_MAP`): Re-exported via `pub use`; reached through downstream importers. (Role: public_entrypoint, Source: inferred_from_code) *SemanticGuess*
- **ScaffoldArtifact** (`vibecrafted-server/control-core/src/lib.rs::ScaffoldArtifact`): Re-exported via `pub use`; reached through downstream importers. (Role: public_entrypoint, Source: inferred_from_code) *SemanticGuess*
- **ScaffoldArtifactKind** (`vibecrafted-server/control-core/src/lib.rs::ScaffoldArtifactKind`): Re-exported via `pub use`; reached through downstream importers. (Role: public_entrypoint, Source: inferred_from_code) *SemanticGuess*
- **ScaffoldArtifactPatch** (`vibecrafted-server/control-core/src/lib.rs::ScaffoldArtifactPatch`): Re-exported via `pub use`; reached through downstream importers. (Role: public_entrypoint, Source: inferred_from_code) *SemanticGuess*
- **ScaffoldArtifactStore** (`vibecrafted-server/control-core/src/lib.rs::ScaffoldArtifactStore`): Re-exported via `pub use`; reached through downstream importers. (Role: public_entrypoint, Source: inferred_from_code) *SemanticGuess*
- **ScaffoldChange** (`vibecrafted-server/control-core/src/lib.rs::ScaffoldChange`): Re-exported via `pub use`; reached through downstream importers. (Role: public_entrypoint, Source: inferred_from_code) *SemanticGuess*
- **ScaffoldCheckpoint** (`vibecrafted-server/control-core/src/lib.rs::ScaffoldCheckpoint`): Re-exported via `pub use`; reached through downstream importers. (Role: public_entrypoint, Source: inferred_from_code) *SemanticGuess*
- **ScaffoldCheckpointPatch** (`vibecrafted-server/control-core/src/lib.rs::ScaffoldCheckpointPatch`): Re-exported via `pub use`; reached through downstream importers. (Role: public_entrypoint, Source: inferred_from_code) *SemanticGuess*
- **ScaffoldWorkspace** (`vibecrafted-server/control-core/src/lib.rs::ScaffoldWorkspace`): Re-exported via `pub use`; reached through downstream importers. (Role: public_entrypoint, Source: inferred_from_code) *SemanticGuess*
- **StateClass** (`vibecrafted-server/control-core/src/lib.rs::StateClass`): Re-exported via `pub use`; reached through downstream importers. (Role: public_entrypoint, Source: inferred_from_code) *SemanticGuess*
- **StateView** (`vibecrafted-server/control-core/src/lib.rs::StateView`): Re-exported via `pub use`; reached through downstream importers. (Role: public_entrypoint, Source: inferred_from_code) *SemanticGuess*
- **classify_state** (`vibecrafted-server/control-core/src/lib.rs::classify_state`): Re-exported via `pub use`; reached through downstream importers. (Role: public_entrypoint, Source: inferred_from_code) *SemanticGuess*
- **coerce_int_value** (`vibecrafted-server/control-core/src/lib.rs::coerce_int_value`): Re-exported via `pub use`; reached through downstream importers. (Role: public_entrypoint, Source: inferred_from_code) *SemanticGuess*
- **is_active_state** (`vibecrafted-server/control-core/src/lib.rs::is_active_state`): Re-exported via `pub use`; reached through downstream importers. (Role: public_entrypoint, Source: inferred_from_code) *SemanticGuess*
- **is_final_state** (`vibecrafted-server/control-core/src/lib.rs::is_final_state`): Re-exported via `pub use`; reached through downstream importers. (Role: public_entrypoint, Source: inferred_from_code) *SemanticGuess*
- **merge_status** (`vibecrafted-server/control-core/src/lib.rs::merge_status`): Re-exported via `pub use`; reached through downstream importers. (Role: public_entrypoint, Source: inferred_from_code) *SemanticGuess*
- **operator_session_name** (`vibecrafted-server/control-core/src/lib.rs::operator_session_name`): Re-exported via `pub use`; reached through downstream importers. (Role: public_entrypoint, Source: inferred_from_code) *SemanticGuess*
- **parse_iso** (`vibecrafted-server/control-core/src/lib.rs::parse_iso`): Re-exported via `pub use`; reached through downstream importers. (Role: public_entrypoint, Source: inferred_from_code) *SemanticGuess*
- **skill_from_code** (`vibecrafted-server/control-core/src/lib.rs::skill_from_code`): Re-exported via `pub use`; reached through downstream importers. (Role: public_entrypoint, Source: inferred_from_code) *SemanticGuess*
- **state_health** (`vibecrafted-server/control-core/src/lib.rs::state_health`): Re-exported via `pub use`; reached through downstream importers. (Role: public_entrypoint, Source: inferred_from_code) *SemanticGuess*
- **vibecrafted_home** (`vibecrafted-server/control-core/src/lib.rs::vibecrafted_home`): Re-exported via `pub use`; reached through downstream importers. (Role: public_entrypoint, Source: inferred_from_code) *SemanticGuess*
- **as_str** (`vibecrafted-server/control-core/src/model.rs::as_str`): Defined inside inherent `impl Health` block; reached via method-call syntax. (Role: library_helper, Source: inferred_from_code) *SemanticGuess*
- **is_terminal** (`vibecrafted-server/control-core/src/model.rs::is_terminal`): Defined inside inherent `impl RunStatus` block; reached via method-call syntax. (Role: library_helper, Source: inferred_from_code) *SemanticGuess*
- **normalize** (`vibecrafted-server/control-core/src/model.rs::normalize`): Defined inside inherent `impl AgentMeta` block; reached via method-call syntax. (Role: library_helper, Source: inferred_from_code) *SemanticGuess*
- **state_class** (`vibecrafted-server/control-core/src/model.rs::state_class`): Defined inside inherent `impl RunStatus` block; reached via method-call syntax. (Role: library_helper, Source: inferred_from_code) *SemanticGuess*
- **compute_view** (`vibecrafted-server/control-core/src/read.rs::compute_view`): Defined inside inherent `impl ControlPlane` block; reached via method-call syntax. (Role: library_helper, Source: inferred_from_code) *SemanticGuess*
- **control_plane_home** (`vibecrafted-server/control-core/src/read.rs::control_plane_home`): Defined inside inherent `impl ControlPlane` block; reached via method-call syntax. (Role: library_helper, Source: inferred_from_code) *SemanticGuess*
- **event_stream_path** (`vibecrafted-server/control-core/src/read.rs::event_stream_path`): Defined inside inherent `impl ControlPlane` block; reached via method-call syntax. (Role: library_helper, Source: inferred_from_code) *SemanticGuess*
- **events** (`vibecrafted-server/control-core/src/read.rs::events`): Defined inside inherent `impl ControlPlane` block; reached via method-call syntax. (Role: library_helper, Source: inferred_from_code) *SemanticGuess*
- **from_env** (`vibecrafted-server/control-core/src/read.rs::from_env`): Defined inside inherent `impl ControlPlane` block; reached via method-call syntax. (Role: library_helper, Source: inferred_from_code) *SemanticGuess*
- **load_snapshots** (`vibecrafted-server/control-core/src/read.rs::load_snapshots`): Defined inside inherent `impl ControlPlane` block; reached via method-call syntax. (Role: library_helper, Source: inferred_from_code) *SemanticGuess*
- **lookup_run** (`vibecrafted-server/control-core/src/read.rs::lookup_run`): Defined inside inherent `impl ControlPlane` block; reached via method-call syntax. (Role: library_helper, Source: inferred_from_code) *SemanticGuess*
- **new** (`vibecrafted-server/control-core/src/read.rs::new`): Idiomatic Rust constructor convention; called via Type::new(...) across the ecosystem. (Role: library_helper, Source: embedded_default) *LoctreeDerived*
- **read_event_tail** (`vibecrafted-server/control-core/src/read.rs::read_event_tail`): Defined inside inherent `impl ControlPlane` block; reached via method-call syntax. (Role: library_helper, Source: inferred_from_code) *SemanticGuess*
- **read_state_view** (`vibecrafted-server/control-core/src/read.rs::read_state_view`): Defined inside inherent `impl ControlPlane` block; reached via method-call syntax. (Role: library_helper, Source: inferred_from_code) *SemanticGuess*
- **run_snapshot_dir** (`vibecrafted-server/control-core/src/read.rs::run_snapshot_dir`): Defined inside inherent `impl ControlPlane` block; reached via method-call syntax. (Role: library_helper, Source: inferred_from_code) *SemanticGuess*
- **as_str** (`vibecrafted-server/control-core/src/scaffold.rs::as_str`): Defined inside inherent `impl ScaffoldArtifactKind` block; reached via method-call syntax. (Role: library_helper, Source: inferred_from_code) *SemanticGuess*
- **changes** (`vibecrafted-server/control-core/src/scaffold.rs::changes`): Defined inside inherent `impl ScaffoldArtifactStore` block; reached via method-call syntax. (Role: library_helper, Source: inferred_from_code) *SemanticGuess*
- **checkpoint** (`vibecrafted-server/control-core/src/scaffold.rs::checkpoint`): Defined inside inherent `impl ScaffoldArtifactStore` block; reached via method-call syntax. (Role: library_helper, Source: inferred_from_code) *SemanticGuess*
- **latest_workspace** (`vibecrafted-server/control-core/src/scaffold.rs::latest_workspace`): Defined inside inherent `impl ScaffoldArtifactStore` block; reached via method-call syntax. (Role: library_helper, Source: inferred_from_code) *SemanticGuess*
- **new** (`vibecrafted-server/control-core/src/scaffold.rs::new`): Idiomatic Rust constructor convention; called via Type::new(...) across the ecosystem. (Role: library_helper, Source: embedded_default) *LoctreeDerived*
- **operator_dir** (`vibecrafted-server/control-core/src/scaffold.rs::operator_dir`): Defined inside inherent `impl ScaffoldArtifactStore` block; reached via method-call syntax. (Role: library_helper, Source: inferred_from_code) *SemanticGuess*
- **workspace** (`vibecrafted-server/control-core/src/scaffold.rs::workspace`): Defined inside inherent `impl ScaffoldArtifactStore` block; reached via method-call syntax. (Role: library_helper, Source: inferred_from_code) *SemanticGuess*
- **write_artifact** (`vibecrafted-server/control-core/src/scaffold.rs::write_artifact`): Defined inside inherent `impl ScaffoldArtifactStore` block; reached via method-call syntax. (Role: library_helper, Source: inferred_from_code) *SemanticGuess*
- **shell** (`vibecrafted-server/web/src/app.rs::shell`): Gated by `#[cfg(feature = "ssr")]`; reached when feature is enabled. (Role: library_helper, Source: inferred_from_code) *SemanticGuess*
- **hydrate** (`vibecrafted-server/web/src/lib.rs::hydrate`): Gated by `#[cfg(feature = "hydrate")]`; reached when feature is enabled. (Role: library_helper, Source: inferred_from_code) *SemanticGuess*
- **code** (`vibecrafted-server/web/src/theme.rs::code`): Defined inside inherent `impl Theme` block; reached via method-call syntax. (Role: library_helper, Source: inferred_from_code) *SemanticGuess*
- **from_code** (`vibecrafted-server/web/src/theme.rs::from_code`): Defined inside inherent `impl Theme` block; reached via method-call syntax. (Role: library_helper, Source: inferred_from_code) *SemanticGuess*
- **new** (`vibecrafted-server/web/src/theme.rs::new`): Idiomatic Rust constructor convention; called via Type::new(...) across the ecosystem. (Role: library_helper, Source: embedded_default) *LoctreeDerived*
- **toggle** (`vibecrafted-server/web/src/theme.rs::toggle`): Defined inside inherent `impl Theme` block; reached via method-call syntax. (Role: library_helper, Source: inferred_from_code) *SemanticGuess*

### Reachability

- `vibecrafted-server/control-core/src/events.rs::new`: Reached (idiom_runtime_role:library_helper) *SemanticGuess*
- `vibecrafted-server/control-core/src/events.rs::path`: Reached (idiom_runtime_role:library_helper) *SemanticGuess*
- `vibecrafted-server/control-core/src/events.rs::read_all`: Reached (idiom_runtime_role:library_helper) *SemanticGuess*
- `vibecrafted-server/control-core/src/events.rs::read_since`: Reached (idiom_runtime_role:library_helper) *SemanticGuess*
- `vibecrafted-server/control-core/src/events.rs::tail`: Reached (idiom_runtime_role:library_helper) *SemanticGuess*
- `vibecrafted-server/control-core/src/lib.rs::ACTIVE_STATES`: Reached (idiom_runtime_role:public_entrypoint) *SemanticGuess*
- `vibecrafted-server/control-core/src/lib.rs::AgentMeta`: Reached (idiom_runtime_role:public_entrypoint) *SemanticGuess*
- `vibecrafted-server/control-core/src/lib.rs::ControlPlane`: Reached (idiom_runtime_role:public_entrypoint) *SemanticGuess*
- `vibecrafted-server/control-core/src/lib.rs::EVENT_TAIL_LIMIT`: Reached (idiom_runtime_role:public_entrypoint) *SemanticGuess*
- `vibecrafted-server/control-core/src/lib.rs::Event`: Reached (idiom_runtime_role:public_entrypoint) *SemanticGuess*
- `vibecrafted-server/control-core/src/lib.rs::EventBatch`: Reached (idiom_runtime_role:public_entrypoint) *SemanticGuess*
- `vibecrafted-server/control-core/src/lib.rs::EventStream`: Reached (idiom_runtime_role:public_entrypoint) *SemanticGuess*
- `vibecrafted-server/control-core/src/lib.rs::FINAL_STATES`: Reached (idiom_runtime_role:public_entrypoint) *SemanticGuess*
- `vibecrafted-server/control-core/src/lib.rs::Health`: Reached (idiom_runtime_role:public_entrypoint) *SemanticGuess*
- `vibecrafted-server/control-core/src/lib.rs::RECENT_RUN_LIMIT`: Reached (idiom_runtime_role:public_entrypoint) *SemanticGuess*
- `vibecrafted-server/control-core/src/lib.rs::RUN_STALL_SECONDS`: Reached (idiom_runtime_role:public_entrypoint) *SemanticGuess*
- `vibecrafted-server/control-core/src/lib.rs::RunStatus`: Reached (idiom_runtime_role:public_entrypoint) *SemanticGuess*
- `vibecrafted-server/control-core/src/lib.rs::SKILL_CODE_MAP`: Reached (idiom_runtime_role:public_entrypoint) *SemanticGuess*
- `vibecrafted-server/control-core/src/lib.rs::ScaffoldArtifact`: Reached (idiom_runtime_role:public_entrypoint) *SemanticGuess*
- `vibecrafted-server/control-core/src/lib.rs::ScaffoldArtifactKind`: Reached (idiom_runtime_role:public_entrypoint) *SemanticGuess*
- `vibecrafted-server/control-core/src/lib.rs::ScaffoldArtifactPatch`: Reached (idiom_runtime_role:public_entrypoint) *SemanticGuess*
- `vibecrafted-server/control-core/src/lib.rs::ScaffoldArtifactStore`: Reached (idiom_runtime_role:public_entrypoint) *SemanticGuess*
- `vibecrafted-server/control-core/src/lib.rs::ScaffoldChange`: Reached (idiom_runtime_role:public_entrypoint) *SemanticGuess*
- `vibecrafted-server/control-core/src/lib.rs::ScaffoldCheckpoint`: Reached (idiom_runtime_role:public_entrypoint) *SemanticGuess*
- `vibecrafted-server/control-core/src/lib.rs::ScaffoldCheckpointPatch`: Reached (idiom_runtime_role:public_entrypoint) *SemanticGuess*
- `vibecrafted-server/control-core/src/lib.rs::ScaffoldWorkspace`: Reached (idiom_runtime_role:public_entrypoint) *SemanticGuess*
- `vibecrafted-server/control-core/src/lib.rs::StateClass`: Reached (idiom_runtime_role:public_entrypoint) *SemanticGuess*
- `vibecrafted-server/control-core/src/lib.rs::StateView`: Reached (idiom_runtime_role:public_entrypoint) *SemanticGuess*
- `vibecrafted-server/control-core/src/lib.rs::classify_state`: Reached (idiom_runtime_role:public_entrypoint) *SemanticGuess*
- `vibecrafted-server/control-core/src/lib.rs::coerce_int_value`: Reached (idiom_runtime_role:public_entrypoint) *SemanticGuess*
- `vibecrafted-server/control-core/src/lib.rs::is_active_state`: Reached (idiom_runtime_role:public_entrypoint) *SemanticGuess*
- `vibecrafted-server/control-core/src/lib.rs::is_final_state`: Reached (idiom_runtime_role:public_entrypoint) *SemanticGuess*
- `vibecrafted-server/control-core/src/lib.rs::merge_status`: Reached (idiom_runtime_role:public_entrypoint) *SemanticGuess*
- `vibecrafted-server/control-core/src/lib.rs::operator_session_name`: Reached (idiom_runtime_role:public_entrypoint) *SemanticGuess*
- `vibecrafted-server/control-core/src/lib.rs::parse_iso`: Reached (idiom_runtime_role:public_entrypoint) *SemanticGuess*
- `vibecrafted-server/control-core/src/lib.rs::skill_from_code`: Reached (idiom_runtime_role:public_entrypoint) *SemanticGuess*
- `vibecrafted-server/control-core/src/lib.rs::state_health`: Reached (idiom_runtime_role:public_entrypoint) *SemanticGuess*
- `vibecrafted-server/control-core/src/lib.rs::vibecrafted_home`: Reached (idiom_runtime_role:public_entrypoint) *SemanticGuess*
- `vibecrafted-server/control-core/src/model.rs::as_str`: Reached (idiom_runtime_role:library_helper) *SemanticGuess*
- `vibecrafted-server/control-core/src/model.rs::is_terminal`: Reached (idiom_runtime_role:library_helper) *SemanticGuess*
- `vibecrafted-server/control-core/src/model.rs::normalize`: Reached (idiom_runtime_role:library_helper) *SemanticGuess*
- `vibecrafted-server/control-core/src/model.rs::state_class`: Reached (idiom_runtime_role:library_helper) *SemanticGuess*
- `vibecrafted-server/control-core/src/read.rs::compute_view`: Reached (idiom_runtime_role:library_helper) *SemanticGuess*
- `vibecrafted-server/control-core/src/read.rs::control_plane_home`: Reached (idiom_runtime_role:library_helper) *SemanticGuess*
- `vibecrafted-server/control-core/src/read.rs::event_stream_path`: Reached (idiom_runtime_role:library_helper) *SemanticGuess*
- `vibecrafted-server/control-core/src/read.rs::events`: Reached (idiom_runtime_role:library_helper) *SemanticGuess*
- `vibecrafted-server/control-core/src/read.rs::from_env`: Reached (idiom_runtime_role:library_helper) *SemanticGuess*
- `vibecrafted-server/control-core/src/read.rs::load_snapshots`: Reached (idiom_runtime_role:library_helper) *SemanticGuess*
- `vibecrafted-server/control-core/src/read.rs::lookup_run`: Reached (idiom_runtime_role:library_helper) *SemanticGuess*
- `vibecrafted-server/control-core/src/read.rs::new`: Reached (idiom_runtime_role:library_helper) *SemanticGuess*
- `vibecrafted-server/control-core/src/read.rs::read_event_tail`: Reached (idiom_runtime_role:library_helper) *SemanticGuess*
- `vibecrafted-server/control-core/src/read.rs::read_state_view`: Reached (idiom_runtime_role:library_helper) *SemanticGuess*
- `vibecrafted-server/control-core/src/read.rs::run_snapshot_dir`: Reached (idiom_runtime_role:library_helper) *SemanticGuess*
- `vibecrafted-server/control-core/src/scaffold.rs::as_str`: Reached (idiom_runtime_role:library_helper) *SemanticGuess*
- `vibecrafted-server/control-core/src/scaffold.rs::changes`: Reached (idiom_runtime_role:library_helper) *SemanticGuess*
- `vibecrafted-server/control-core/src/scaffold.rs::checkpoint`: Reached (idiom_runtime_role:library_helper) *SemanticGuess*
- `vibecrafted-server/control-core/src/scaffold.rs::latest_workspace`: Reached (idiom_runtime_role:library_helper) *SemanticGuess*
- `vibecrafted-server/control-core/src/scaffold.rs::new`: Reached (idiom_runtime_role:library_helper) *SemanticGuess*
- `vibecrafted-server/control-core/src/scaffold.rs::operator_dir`: Reached (idiom_runtime_role:library_helper) *SemanticGuess*
- `vibecrafted-server/control-core/src/scaffold.rs::workspace`: Reached (idiom_runtime_role:library_helper) *SemanticGuess*
- `vibecrafted-server/control-core/src/scaffold.rs::write_artifact`: Reached (idiom_runtime_role:library_helper) *SemanticGuess*
- `vibecrafted-server/web/src/app.rs::shell`: Reached (idiom_runtime_role:library_helper) *SemanticGuess*
- `vibecrafted-server/web/src/lib.rs::hydrate`: Reached (idiom_runtime_role:library_helper) *SemanticGuess*
- `vibecrafted-server/web/src/theme.rs::code`: Reached (idiom_runtime_role:library_helper) *SemanticGuess*
- `vibecrafted-server/web/src/theme.rs::from_code`: Reached (idiom_runtime_role:library_helper) *SemanticGuess*
- `vibecrafted-server/web/src/theme.rs::new`: Reached (idiom_runtime_role:library_helper) *SemanticGuess*
- `vibecrafted-server/web/src/theme.rs::toggle`: Reached (idiom_runtime_role:library_helper) *SemanticGuess*

### Framework Hints

- `entrypoint` at `vibecrafted-server/control-core/examples/dump.rs`: main *RepoVerified*
- `rust:inherent_impl_method` at `vibecrafted-server/control-core/src/events.rs`: vibecrafted-server/control-core/src/events.rs::new *LoctreeDerived*
- `rust:inherent_impl_method` at `vibecrafted-server/control-core/src/events.rs`: vibecrafted-server/control-core/src/events.rs::path *LoctreeDerived*
- `rust:inherent_impl_method` at `vibecrafted-server/control-core/src/events.rs`: vibecrafted-server/control-core/src/events.rs::read_all *LoctreeDerived*
- `rust:inherent_impl_method` at `vibecrafted-server/control-core/src/events.rs`: vibecrafted-server/control-core/src/events.rs::read_since *LoctreeDerived*
- `rust:inherent_impl_method` at `vibecrafted-server/control-core/src/events.rs`: vibecrafted-server/control-core/src/events.rs::tail *LoctreeDerived*
- `rust:pub_use_reexport` at `vibecrafted-server/control-core/src/lib.rs`: vibecrafted-server/control-core/src/lib.rs::ACTIVE_STATES *LoctreeDerived*
- `rust:pub_use_reexport` at `vibecrafted-server/control-core/src/lib.rs`: vibecrafted-server/control-core/src/lib.rs::AgentMeta *LoctreeDerived*
- `rust:pub_use_reexport` at `vibecrafted-server/control-core/src/lib.rs`: vibecrafted-server/control-core/src/lib.rs::ControlPlane *LoctreeDerived*
- `rust:pub_use_reexport` at `vibecrafted-server/control-core/src/lib.rs`: vibecrafted-server/control-core/src/lib.rs::EVENT_TAIL_LIMIT *LoctreeDerived*
- `rust:pub_use_reexport` at `vibecrafted-server/control-core/src/lib.rs`: vibecrafted-server/control-core/src/lib.rs::Event *LoctreeDerived*
- `rust:pub_use_reexport` at `vibecrafted-server/control-core/src/lib.rs`: vibecrafted-server/control-core/src/lib.rs::EventBatch *LoctreeDerived*
- `rust:pub_use_reexport` at `vibecrafted-server/control-core/src/lib.rs`: vibecrafted-server/control-core/src/lib.rs::EventStream *LoctreeDerived*
- `rust:pub_use_reexport` at `vibecrafted-server/control-core/src/lib.rs`: vibecrafted-server/control-core/src/lib.rs::FINAL_STATES *LoctreeDerived*
- `rust:pub_use_reexport` at `vibecrafted-server/control-core/src/lib.rs`: vibecrafted-server/control-core/src/lib.rs::Health *LoctreeDerived*
- `rust:pub_use_reexport` at `vibecrafted-server/control-core/src/lib.rs`: vibecrafted-server/control-core/src/lib.rs::RECENT_RUN_LIMIT *LoctreeDerived*
- `rust:pub_use_reexport` at `vibecrafted-server/control-core/src/lib.rs`: vibecrafted-server/control-core/src/lib.rs::RUN_STALL_SECONDS *LoctreeDerived*
- `rust:pub_use_reexport` at `vibecrafted-server/control-core/src/lib.rs`: vibecrafted-server/control-core/src/lib.rs::RunStatus *LoctreeDerived*
- `rust:pub_use_reexport` at `vibecrafted-server/control-core/src/lib.rs`: vibecrafted-server/control-core/src/lib.rs::SKILL_CODE_MAP *LoctreeDerived*
- `rust:pub_use_reexport` at `vibecrafted-server/control-core/src/lib.rs`: vibecrafted-server/control-core/src/lib.rs::ScaffoldArtifact *LoctreeDerived*
- `rust:pub_use_reexport` at `vibecrafted-server/control-core/src/lib.rs`: vibecrafted-server/control-core/src/lib.rs::ScaffoldArtifactKind *LoctreeDerived*
- `rust:pub_use_reexport` at `vibecrafted-server/control-core/src/lib.rs`: vibecrafted-server/control-core/src/lib.rs::ScaffoldArtifactPatch *LoctreeDerived*
- `rust:pub_use_reexport` at `vibecrafted-server/control-core/src/lib.rs`: vibecrafted-server/control-core/src/lib.rs::ScaffoldArtifactStore *LoctreeDerived*
- `rust:pub_use_reexport` at `vibecrafted-server/control-core/src/lib.rs`: vibecrafted-server/control-core/src/lib.rs::ScaffoldChange *LoctreeDerived*
- `rust:pub_use_reexport` at `vibecrafted-server/control-core/src/lib.rs`: vibecrafted-server/control-core/src/lib.rs::ScaffoldCheckpoint *LoctreeDerived*
- `rust:pub_use_reexport` at `vibecrafted-server/control-core/src/lib.rs`: vibecrafted-server/control-core/src/lib.rs::ScaffoldCheckpointPatch *LoctreeDerived*
- `rust:pub_use_reexport` at `vibecrafted-server/control-core/src/lib.rs`: vibecrafted-server/control-core/src/lib.rs::ScaffoldWorkspace *LoctreeDerived*
- `rust:pub_use_reexport` at `vibecrafted-server/control-core/src/lib.rs`: vibecrafted-server/control-core/src/lib.rs::StateClass *LoctreeDerived*
- `rust:pub_use_reexport` at `vibecrafted-server/control-core/src/lib.rs`: vibecrafted-server/control-core/src/lib.rs::StateView *LoctreeDerived*
- `rust:pub_use_reexport` at `vibecrafted-server/control-core/src/lib.rs`: vibecrafted-server/control-core/src/lib.rs::classify_state *LoctreeDerived*
- `rust:pub_use_reexport` at `vibecrafted-server/control-core/src/lib.rs`: vibecrafted-server/control-core/src/lib.rs::coerce_int_value *LoctreeDerived*
- `rust:pub_use_reexport` at `vibecrafted-server/control-core/src/lib.rs`: vibecrafted-server/control-core/src/lib.rs::is_active_state *LoctreeDerived*
- `rust:pub_use_reexport` at `vibecrafted-server/control-core/src/lib.rs`: vibecrafted-server/control-core/src/lib.rs::is_final_state *LoctreeDerived*
- `rust:pub_use_reexport` at `vibecrafted-server/control-core/src/lib.rs`: vibecrafted-server/control-core/src/lib.rs::merge_status *LoctreeDerived*
- `rust:pub_use_reexport` at `vibecrafted-server/control-core/src/lib.rs`: vibecrafted-server/control-core/src/lib.rs::operator_session_name *LoctreeDerived*
- `rust:pub_use_reexport` at `vibecrafted-server/control-core/src/lib.rs`: vibecrafted-server/control-core/src/lib.rs::parse_iso *LoctreeDerived*
- `rust:pub_use_reexport` at `vibecrafted-server/control-core/src/lib.rs`: vibecrafted-server/control-core/src/lib.rs::skill_from_code *LoctreeDerived*
- `rust:pub_use_reexport` at `vibecrafted-server/control-core/src/lib.rs`: vibecrafted-server/control-core/src/lib.rs::state_health *LoctreeDerived*
- `rust:pub_use_reexport` at `vibecrafted-server/control-core/src/lib.rs`: vibecrafted-server/control-core/src/lib.rs::vibecrafted_home *LoctreeDerived*
- `rust:inherent_impl_method` at `vibecrafted-server/control-core/src/model.rs`: vibecrafted-server/control-core/src/model.rs::as_str *LoctreeDerived*
- `rust:inherent_impl_method` at `vibecrafted-server/control-core/src/model.rs`: vibecrafted-server/control-core/src/model.rs::is_terminal *LoctreeDerived*
- `rust:inherent_impl_method` at `vibecrafted-server/control-core/src/model.rs`: vibecrafted-server/control-core/src/model.rs::normalize *LoctreeDerived*
- `rust:inherent_impl_method` at `vibecrafted-server/control-core/src/model.rs`: vibecrafted-server/control-core/src/model.rs::state_class *LoctreeDerived*
- `rust:inherent_impl_method` at `vibecrafted-server/control-core/src/read.rs`: vibecrafted-server/control-core/src/read.rs::compute_view *LoctreeDerived*
- `rust:inherent_impl_method` at `vibecrafted-server/control-core/src/read.rs`: vibecrafted-server/control-core/src/read.rs::control_plane_home *LoctreeDerived*
- `rust:inherent_impl_method` at `vibecrafted-server/control-core/src/read.rs`: vibecrafted-server/control-core/src/read.rs::event_stream_path *LoctreeDerived*
- `rust:inherent_impl_method` at `vibecrafted-server/control-core/src/read.rs`: vibecrafted-server/control-core/src/read.rs::events *LoctreeDerived*
- `rust:inherent_impl_method` at `vibecrafted-server/control-core/src/read.rs`: vibecrafted-server/control-core/src/read.rs::from_env *LoctreeDerived*
- `rust:inherent_impl_method` at `vibecrafted-server/control-core/src/read.rs`: vibecrafted-server/control-core/src/read.rs::load_snapshots *LoctreeDerived*
- `rust:inherent_impl_method` at `vibecrafted-server/control-core/src/read.rs`: vibecrafted-server/control-core/src/read.rs::lookup_run *LoctreeDerived*
- `rust:inherent_impl_method` at `vibecrafted-server/control-core/src/read.rs`: vibecrafted-server/control-core/src/read.rs::new *LoctreeDerived*
- `rust:inherent_impl_method` at `vibecrafted-server/control-core/src/read.rs`: vibecrafted-server/control-core/src/read.rs::read_event_tail *LoctreeDerived*
- `rust:inherent_impl_method` at `vibecrafted-server/control-core/src/read.rs`: vibecrafted-server/control-core/src/read.rs::read_state_view *LoctreeDerived*
- `rust:inherent_impl_method` at `vibecrafted-server/control-core/src/read.rs`: vibecrafted-server/control-core/src/read.rs::run_snapshot_dir *LoctreeDerived*
- `rust:inherent_impl_method` at `vibecrafted-server/control-core/src/scaffold.rs`: vibecrafted-server/control-core/src/scaffold.rs::as_str *LoctreeDerived*
- `rust:inherent_impl_method` at `vibecrafted-server/control-core/src/scaffold.rs`: vibecrafted-server/control-core/src/scaffold.rs::changes *LoctreeDerived*
- `rust:inherent_impl_method` at `vibecrafted-server/control-core/src/scaffold.rs`: vibecrafted-server/control-core/src/scaffold.rs::checkpoint *LoctreeDerived*
- `rust:inherent_impl_method` at `vibecrafted-server/control-core/src/scaffold.rs`: vibecrafted-server/control-core/src/scaffold.rs::latest_workspace *LoctreeDerived*
- `rust:inherent_impl_method` at `vibecrafted-server/control-core/src/scaffold.rs`: vibecrafted-server/control-core/src/scaffold.rs::new *LoctreeDerived*
- `rust:inherent_impl_method` at `vibecrafted-server/control-core/src/scaffold.rs`: vibecrafted-server/control-core/src/scaffold.rs::operator_dir *LoctreeDerived*
- `rust:inherent_impl_method` at `vibecrafted-server/control-core/src/scaffold.rs`: vibecrafted-server/control-core/src/scaffold.rs::workspace *LoctreeDerived*
- `rust:inherent_impl_method` at `vibecrafted-server/control-core/src/scaffold.rs`: vibecrafted-server/control-core/src/scaffold.rs::write_artifact *LoctreeDerived*
- `rust:cfg_feature` at `vibecrafted-server/web/src/app.rs`: vibecrafted-server/web/src/app.rs::shell *LoctreeDerived*
- `rust:cfg_feature` at `vibecrafted-server/web/src/lib.rs`: vibecrafted-server/web/src/lib.rs::hydrate *LoctreeDerived*
- `entrypoint` at `vibecrafted-server/web/src/main.rs`: async_main *RepoVerified*
- `entrypoint` at `vibecrafted-server/web/src/main.rs`: main *RepoVerified*
- `rust:inherent_impl_method` at `vibecrafted-server/web/src/theme.rs`: vibecrafted-server/web/src/theme.rs::code *LoctreeDerived*
- `rust:inherent_impl_method` at `vibecrafted-server/web/src/theme.rs`: vibecrafted-server/web/src/theme.rs::from_code *LoctreeDerived*
- `rust:inherent_impl_method` at `vibecrafted-server/web/src/theme.rs`: vibecrafted-server/web/src/theme.rs::new *LoctreeDerived*
- `rust:inherent_impl_method` at `vibecrafted-server/web/src/theme.rs`: vibecrafted-server/web/src/theme.rs::toggle *LoctreeDerived*

## Risk Slice

- Cache Scope: `Scoped("de81ef8c7fa0")` *RepoVerified*
- Snapshot Health: `scoped`
- Stale Snapshot: false
- Dirty Worktree: true

### Hotspots

| File | Importers | Authority |
|---|---|---|
| `vibecrafted-server/control-core/src/model.rs` | 3 | *LoctreeDerived* |
| `vibecrafted-server/web/src/theme.rs` | 3 | *LoctreeDerived* |
| `vibecrafted-server/control-core/src/events.rs` | 2 | *LoctreeDerived* |
| `vibecrafted-server/web/src/scaffold/mod.rs` | 2 | *LoctreeDerived* |
| `vibecrafted-server/control-core/src/read.rs` | 1 | *LoctreeDerived* |
| `vibecrafted-server/control-core/src/scaffold.rs` | 1 | *LoctreeDerived* |
| `vibecrafted-server/web/src/app.rs` | 1 | *LoctreeDerived* |
| `vibecrafted-server/web/src/control/mod.rs` | 1 | *LoctreeDerived* |

## Action Slice

### Power Path

- `loct slice vibecrafted-server/Cargo.toml`: Slice this file to inspect its direct dependencies and immediate consumers before editing.
- `loct follow`: Pursue unified structural signals (dead exports, import cycles, twins) to ensure health.
- `loct slice vibecrafted-server/README.md`: Slice this file to inspect its direct dependencies and immediate consumers before editing.
- `loct slice vibecrafted-server/control-core/Cargo.toml`: Slice this file to inspect its direct dependencies and immediate consumers before editing.
- `loct slice vibecrafted-server/control-core/examples/dump.rs`: Slice this file to inspect its direct dependencies and immediate consumers before editing.
- `loct slice vibecrafted-server/control-core/src/events.rs`: Slice this file to inspect its direct dependencies and immediate consumers before editing.
- `loct impact vibecrafted-server/control-core/src/events.rs`: Assess the transitive blast radius and downstream consumers of this file before modifying.
- `loct body new`: View the definition body of symbol 'new' to understand its implementation structure.
- `loct find --literal new`: Execute a literal exact-identifier scan for 'new' to find exact matches across the codebase.
- `loct occurrences new`: Perform a literal boundary-sensitive occurrences scan for 'new' to locate all references.
- `loct slice vibecrafted-server/control-core/src/lib.rs`: Slice this file to inspect its direct dependencies and immediate consumers before editing.
- `loct body EventBatch`: View the definition body of symbol 'EventBatch' to understand its implementation structure.
- `loct find --literal EventBatch`: Execute a literal exact-identifier scan for 'EventBatch' to find exact matches across the codebase.
- `loct occurrences EventBatch`: Perform a literal boundary-sensitive occurrences scan for 'EventBatch' to locate all references.
- `loct slice vibecrafted-server/control-core/src/model.rs`: Slice this file to inspect its direct dependencies and immediate consumers before editing.
- `loct impact vibecrafted-server/control-core/src/model.rs`: Assess the transitive blast radius and downstream consumers of this file before modifying.
- `loct body is_active_state`: View the definition body of symbol 'is_active_state' to understand its implementation structure.
- `loct find --literal is_active_state`: Execute a literal exact-identifier scan for 'is_active_state' to find exact matches across the codebase.
- `loct occurrences is_active_state`: Perform a literal boundary-sensitive occurrences scan for 'is_active_state' to locate all references.
- `loct slice vibecrafted-server/control-core/src/read.rs`: Slice this file to inspect its direct dependencies and immediate consumers before editing.
- `loct impact vibecrafted-server/control-core/src/read.rs`: Assess the transitive blast radius and downstream consumers of this file before modifying.
- `loct body vibecrafted_home`: View the definition body of symbol 'vibecrafted_home' to understand its implementation structure.
- `loct find --literal vibecrafted_home`: Execute a literal exact-identifier scan for 'vibecrafted_home' to find exact matches across the codebase.
- `loct occurrences vibecrafted_home`: Perform a literal boundary-sensitive occurrences scan for 'vibecrafted_home' to locate all references.
- `loct slice vibecrafted-server/control-core/src/scaffold.rs`: Slice this file to inspect its direct dependencies and immediate consumers before editing.
- `loct impact vibecrafted-server/control-core/src/scaffold.rs`: Assess the transitive blast radius and downstream consumers of this file before modifying.
- `loct body as_str`: View the definition body of symbol 'as_str' to understand its implementation structure.
- `loct find --literal as_str`: Execute a literal exact-identifier scan for 'as_str' to find exact matches across the codebase.
- `loct occurrences as_str`: Perform a literal boundary-sensitive occurrences scan for 'as_str' to locate all references.
- `loct slice vibecrafted-server/control-core/tests/scaffold_artifacts.rs`: Slice this file to inspect its direct dependencies and immediate consumers before editing.
- `loct slice vibecrafted-server/control-core/tests/schema_fidelity.rs`: Slice this file to inspect its direct dependencies and immediate consumers before editing.
- `loct slice vibecrafted-server/web/Cargo.toml`: Slice this file to inspect its direct dependencies and immediate consumers before editing.
- `loct slice vibecrafted-server/web/src/app.rs`: Slice this file to inspect its direct dependencies and immediate consumers before editing.
- `loct impact vibecrafted-server/web/src/app.rs`: Assess the transitive blast radius and downstream consumers of this file before modifying.
- `loct body shell`: View the definition body of symbol 'shell' to understand its implementation structure.
- `loct find --literal shell`: Execute a literal exact-identifier scan for 'shell' to find exact matches across the codebase.
- `loct occurrences shell`: Perform a literal boundary-sensitive occurrences scan for 'shell' to locate all references.
- `loct slice vibecrafted-server/web/src/control/mod.rs`: Slice this file to inspect its direct dependencies and immediate consumers before editing.
- `loct impact vibecrafted-server/web/src/control/mod.rs`: Assess the transitive blast radius and downstream consumers of this file before modifying.
- `loct body control_routes`: View the definition body of symbol 'control_routes' to understand its implementation structure.
- `loct find --literal control_routes`: Execute a literal exact-identifier scan for 'control_routes' to find exact matches across the codebase.
- `loct occurrences control_routes`: Perform a literal boundary-sensitive occurrences scan for 'control_routes' to locate all references.
- `loct slice vibecrafted-server/web/src/lib.rs`: Slice this file to inspect its direct dependencies and immediate consumers before editing.
- `loct body hydrate`: View the definition body of symbol 'hydrate' to understand its implementation structure.
- `loct find --literal hydrate`: Execute a literal exact-identifier scan for 'hydrate' to find exact matches across the codebase.
- `loct occurrences hydrate`: Perform a literal boundary-sensitive occurrences scan for 'hydrate' to locate all references.
- `loct slice vibecrafted-server/web/src/main.rs`: Slice this file to inspect its direct dependencies and immediate consumers before editing.
- `loct slice vibecrafted-server/web/src/scaffold/mod.rs`: Slice this file to inspect its direct dependencies and immediate consumers before editing.
- `loct impact vibecrafted-server/web/src/scaffold/mod.rs`: Assess the transitive blast radius and downstream consumers of this file before modifying.
- `loct body ScaffoldEditorPage`: View the definition body of symbol 'ScaffoldEditorPage' to understand its implementation structure.
- `loct find --literal ScaffoldEditorPage`: Execute a literal exact-identifier scan for 'ScaffoldEditorPage' to find exact matches across the codebase.
- `loct occurrences ScaffoldEditorPage`: Perform a literal boundary-sensitive occurrences scan for 'ScaffoldEditorPage' to locate all references.
- `loct slice vibecrafted-server/web/src/theme.rs`: Slice this file to inspect its direct dependencies and immediate consumers before editing.
- `loct impact vibecrafted-server/web/src/theme.rs`: Assess the transitive blast radius and downstream consumers of this file before modifying.
- `loct body code`: View the definition body of symbol 'code' to understand its implementation structure.
- `loct find --literal code`: Execute a literal exact-identifier scan for 'code' to find exact matches across the codebase.
- `loct occurrences code`: Perform a literal boundary-sensitive occurrences scan for 'code' to locate all references.
- `loct slice vibecrafted-server/web/styles/fonts.css`: Slice this file to inspect its direct dependencies and immediate consumers before editing.
- `loct slice vibecrafted-server/web/styles/main.css`: Slice this file to inspect its direct dependencies and immediate consumers before editing.
- `loct slice vibecrafted-server/web/styles/tokens.css`: Slice this file to inspect its direct dependencies and immediate consumers before editing.

### Next Safe Commands

```bash
loct context --file vibecrafted-server/Cargo.toml
loct context --file vibecrafted-server/README.md
loct context --file vibecrafted-server/control-core/Cargo.toml
```

### Verification Gates

```bash
mypy .
```

### Likely Tests

- `tests/agent_dispatch_test.py`
- `tests/tui/test_keys.py`
- `vibecrafted-app/tui-agent/tests/mission_control_snapshots.rs`
- `vibecrafted-app/tui-agent/tests/state_contract.rs`
- `vibecrafted-core/tests/dispatch/test_cli.py`
- `vibecrafted-core/tests/dispatch/test_supervisor.py`
- `vibecrafted-core/tests/test_agy_junie_pipeline.py`
- `vibecrafted-core/tests/test_aicx_sync.py`
- `vibecrafted-core/tests/test_capabilities.py`
- `vibecrafted-core/tests/test_cli.py`

## Memory Slice

_Empty_

## Authority Slice

- Repo Verified: 4
- Loctree Derived: 93
- AICX Operator: 0
- AICX Agent: 0
- AICX Failure: 0
- Semantic Guess: 130
- Stale Or Unknown: 0

