# Loctree Context Pack

## Project Identity

- **Root**: `/Users/maciejgad/vc-workspace/vetcoders/vibecrafted`
- **Branch**: `feat/runtime-integration`
- **Commit**: `9f76009`
- **Snapshot**: `feat_runtime-integration@9f76009`

## Where You Are

### Files

| Path | Role | Language | LOC | Authority |
|---|---|---|---|---|
| `vibecrafted-app/shell-agent/app/Vibecrafted/AppDelegate.swift` | `Consumer` | swift | 161 | *RepoVerified* |
| `vibecrafted-app/shell-agent/app/Vibecrafted/Bridge/vibecrafted_shell_ffi.swift` | `Consumer` | swift | 1447 | *RepoVerified* |
| `vibecrafted-app/shell-agent/app/Vibecrafted/Views/InspectorViewController.swift` | `Consumer` | swift | 150 | *RepoVerified* |
| `vibecrafted-vm/README.md` | `Target` | md | 172 | *RepoVerified* |
| `vibecrafted-vm/RUNBOOK.md` | `Target` | md | 338 | *RepoVerified* |
| `vibecrafted-vm/compose.yaml` | `Target` | yaml | 61 | *RepoVerified* |
| `vibecrafted-vm/entry.sh` | `Target` | shell | 128 | *RepoVerified* |
| `vibecrafted-vm/vendor-src.sh` | `Target` | shell | 42 | *RepoVerified* |
| `vibecrafted-vm/wizard/strings.json` | `Target` | json | 240 | *RepoVerified* |
| `vibecrafted-vm/wizard/vc-onboard.py` | `Target` | py | 583 | *RepoVerified* |

### Symbols

| File | Name | Kind | Export Type | Line | Authority |
|---|---|---|---|---|---|
| `vibecrafted-vm/entry.sh` | `log` | function | named | 27 | *RepoVerified* |
| `vibecrafted-vm/entry.sh` | `ok` | function | named | 28 | *RepoVerified* |
| `vibecrafted-vm/entry.sh` | `warn` | function | named | 29 | *RepoVerified* |
| `vibecrafted-vm/wizard/vc-onboard.py` | `WizardState` | class | named | 66 | *RepoVerified* |
| `vibecrafted-vm/wizard/vc-onboard.py` | `build_and_run` | def | named | 497 | *RepoVerified* |
| `vibecrafted-vm/wizard/vc-onboard.py` | `check_docker` | def | named | 374 | *RepoVerified* |
| `vibecrafted-vm/wizard/vc-onboard.py` | `main` | def | named | 542 | *RepoVerified* |
| `vibecrafted-vm/wizard/vc-onboard.py` | `ping_host` | def | named | 361 | *RepoVerified* |
| `vibecrafted-vm/wizard/vc-onboard.py` | `render_compose_file` | def | named | 430 | *RepoVerified* |
| `vibecrafted-vm/wizard/vc-onboard.py` | `render_env_file` | def | named | 379 | *RepoVerified* |
| `vibecrafted-vm/wizard/vc-onboard.py` | `step_connection` | def | named | 141 | *RepoVerified* |
| `vibecrafted-vm/wizard/vc-onboard.py` | `step_host` | def | named | 124 | *RepoVerified* |
| `vibecrafted-vm/wizard/vc-onboard.py` | `step_language` | def | named | 115 | *RepoVerified* |
| `vibecrafted-vm/wizard/vc-onboard.py` | `step_mounts` | def | named | 220 | *RepoVerified* |
| `vibecrafted-vm/wizard/vc-onboard.py` | `step_profile` | def | named | 203 | *RepoVerified* |
| `vibecrafted-vm/wizard/vc-onboard.py` | `step_review` | def | named | 310 | *RepoVerified* |
| `vibecrafted-vm/wizard/vc-onboard.py` | `step_tailscale` | def | named | 261 | *RepoVerified* |
| `vibecrafted-vm/wizard/vc-onboard.py` | `step_welcome` | def | named | 84 | *RepoVerified* |
| `vibecrafted-vm/wizard/vc-onboard.py` | `t` | def | named | 52 | *RepoVerified* |

### Imports

| File | Source | Kind | Resolution | Authority |
|---|---|---|---|---|
| `vibecrafted-vm/wizard/vc-onboard.py` | `__future__` | static | unknown | *RepoVerified* |
| `vibecrafted-vm/wizard/vc-onboard.py` | `dataclasses` | static | stdlib | *RepoVerified* |
| `vibecrafted-vm/wizard/vc-onboard.py` | `pathlib` | static | stdlib | *RepoVerified* |
| `vibecrafted-vm/wizard/vc-onboard.py` | `rich.console` | static | unknown | *RepoVerified* |
| `vibecrafted-vm/wizard/vc-onboard.py` | `rich.panel` | static | unknown | *RepoVerified* |
| `vibecrafted-vm/wizard/vc-onboard.py` | `rich.table` | static | unknown | *RepoVerified* |
| `vibecrafted-vm/wizard/vc-onboard.py` | `typing` | static | stdlib | *RepoVerified* |
| `vibecrafted-vm/wizard/vc-onboard.py` | `json` | static | stdlib | *RepoVerified* |
| `vibecrafted-vm/wizard/vc-onboard.py` | `os` | static | stdlib | *RepoVerified* |
| `vibecrafted-vm/wizard/vc-onboard.py` | `questionary` | static | unknown | *RepoVerified* |
| `vibecrafted-vm/wizard/vc-onboard.py` | `shutil` | static | stdlib | *RepoVerified* |
| `vibecrafted-vm/wizard/vc-onboard.py` | `subprocess` | static | stdlib | *RepoVerified* |
| `vibecrafted-vm/wizard/vc-onboard.py` | `sys` | static | stdlib | *RepoVerified* |

### Consumers

| File | Import Kind | Imports Used | Authority |
|---|---|---|---|
| `vibecrafted-app/shell-agent/app/Vibecrafted/AppDelegate.swift` | `Direct` |  | *RepoVerified* |
| `vibecrafted-app/shell-agent/app/Vibecrafted/Bridge/vibecrafted_shell_ffi.swift` | `Direct` |  | *RepoVerified* |
| `vibecrafted-app/shell-agent/app/Vibecrafted/Views/InspectorViewController.swift` | `Direct` |  | *RepoVerified* |

### Entrypoints

| Path | Kinds | Authority |
|---|---|---|
| `vibecrafted-vm/wizard/vc-onboard.py` | script | *RepoVerified* |

## Runtime Slice

### Idiom Tags

- **log** (`vibecrafted-vm/entry.sh::log`): Generic log dispatcher. (Role: library_helper, Source: embedded_default) *LoctreeDerived*
- **warn** (`vibecrafted-vm/entry.sh::warn`): Conventional warning logger. (Role: library_helper, Source: embedded_default) *LoctreeDerived*
- **main** (`vibecrafted-vm/wizard/vc-onboard.py::main`): Convention entrypoint called from `if __name__ == '__main__':` blocks and `console_scripts` entry points. (Role: primary_entrypoint, Source: embedded_default) *LoctreeDerived*

### Reachability

- `vibecrafted-vm/entry.sh::log`: Reached (dispatch_handler:case_statement:scripts/install-hammerspoon.sh) *LoctreeDerived*
- `vibecrafted-vm/entry.sh::ok`: Reached (dispatch_handler:case_statement:tests/hammerspoon_smoke.sh) *LoctreeDerived*
- `vibecrafted-vm/entry.sh::warn`: Reached (dispatch_handler:case_statement:vibecrafted-app/mux-agent/tools/install.sh) *LoctreeDerived*
- `vibecrafted-vm/wizard/vc-onboard.py::main`: Reached (idiom_runtime_role:primary_entrypoint) *SemanticGuess*

### Env Contracts

- `BASH_SOURCE` used in 66 files *LoctreeDerived*
- `BLUE` used in 1 files *LoctreeDerived*
- `DEST` used in 1 files *LoctreeDerived*
- `GREEN` used in 1 files *LoctreeDerived*
- `HOSTNAME_DEFAULT` used in 1 files *LoctreeDerived*
- `LOCTREE_GPG_KEY_ID` used in 2 files *LoctreeDerived*
- `NC` used in 1 files *LoctreeDerived*
- `RUNTIME_DIR` used in 1 files *LoctreeDerived*
- `SCRIPT_DIR` used in 27 files *LoctreeDerived*
- `TAILSCALED_PID` used in 1 files *LoctreeDerived*
- `TAILSCALE_AUTHKEY` used in 1 files *LoctreeDerived*
- `TAILSCALE_EXIT_NODE` used in 1 files *LoctreeDerived*
- `TAILSCALE_HOSTNAME` used in 1 files *LoctreeDerived*
- `TAILSCALE_TAGS` used in 1 files *LoctreeDerived*
- `TS_HOSTNAME` used in 2 files *LoctreeDerived*
- `TS_IP` used in 1 files *LoctreeDerived*
- `TS_TAGS` used in 1 files *LoctreeDerived*
- `TS_UP_ARGS` used in 1 files *LoctreeDerived*
- `USER` used in 2 files *LoctreeDerived*
- `VC_RUNTIME_DIR` used in 1 files *LoctreeDerived*
- `YELLOW` used in 1 files *LoctreeDerived*

### Framework Hints

- `entrypoint` at `vibecrafted-vm/wizard/vc-onboard.py`: script *RepoVerified*

## Risk Slice

- Cache Scope: `Scoped("3d79743b1e71")` *RepoVerified*
- Snapshot Health: `scoped`
- Stale Snapshot: false
- Dirty Worktree: true

### Hotspots

| File | Importers | Authority |
|---|---|---|
| `vibecrafted-vm/wizard/vc-onboard.py` | 3 | *LoctreeDerived* |
| `vibecrafted-vm/entry.sh` | 1 | *LoctreeDerived* |

## Action Slice

### Power Path

- `loct slice vibecrafted-vm/README.md`: Slice this file to inspect its direct dependencies and immediate consumers before editing.
- `loct follow`: Pursue unified structural signals (dead exports, import cycles, twins) to ensure health.
- `loct slice vibecrafted-vm/RUNBOOK.md`: Slice this file to inspect its direct dependencies and immediate consumers before editing.
- `loct slice vibecrafted-vm/compose.yaml`: Slice this file to inspect its direct dependencies and immediate consumers before editing.
- `loct slice vibecrafted-vm/entry.sh`: Slice this file to inspect its direct dependencies and immediate consumers before editing.
- `loct impact vibecrafted-vm/entry.sh`: Assess the transitive blast radius and downstream consumers of this file before modifying.
- `loct body log`: View the definition body of symbol 'log' to understand its implementation structure.
- `loct find --literal log`: Execute a literal exact-identifier scan for 'log' to find exact matches across the codebase.
- `loct occurrences log`: Perform a literal boundary-sensitive occurrences scan for 'log' to locate all references.
- `loct slice vibecrafted-vm/vendor-src.sh`: Slice this file to inspect its direct dependencies and immediate consumers before editing.
- `loct slice vibecrafted-vm/wizard/strings.json`: Slice this file to inspect its direct dependencies and immediate consumers before editing.
- `loct slice vibecrafted-vm/wizard/vc-onboard.py`: Slice this file to inspect its direct dependencies and immediate consumers before editing.
- `loct impact vibecrafted-vm/wizard/vc-onboard.py`: Assess the transitive blast radius and downstream consumers of this file before modifying.
- `loct body t`: View the definition body of symbol 't' to understand its implementation structure.
- `loct find --literal t`: Execute a literal exact-identifier scan for 't' to find exact matches across the codebase.
- `loct occurrences t`: Perform a literal boundary-sensitive occurrences scan for 't' to locate all references.

### Next Safe Commands

```bash
loct context --file vibecrafted-vm/README.md
loct context --file vibecrafted-vm/RUNBOOK.md
loct context --file vibecrafted-vm/compose.yaml
```

### Verification Gates

```bash
mypy .
```

### Likely Tests

- `tests/agent_dispatch_test.py`
- `vibecrafted-core/tests/dispatch/test_cli.py`
- `vibecrafted-core/tests/dispatch/test_doctor.py`
- `vibecrafted-core/tests/dispatch/test_supervisor.py`
- `vibecrafted-core/tests/test_agy_junie_pipeline.py`
- `vibecrafted-core/tests/test_aicx_sync.py`
- `vibecrafted-core/tests/test_capabilities.py`
- `vibecrafted-core/tests/test_cli.py`
- `vibecrafted-core/tests/test_compact_hooks.py`
- `vibecrafted-core/tests/test_control_plane.py`

## Memory Slice

_Empty_

## Authority Slice

- Repo Verified: 2
- Loctree Derived: 43
- AICX Operator: 0
- AICX Agent: 0
- AICX Failure: 0
- Semantic Guess: 1
- Stale Or Unknown: 0

