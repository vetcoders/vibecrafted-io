# Loctree Context · vibecrafted @ feat/runtime-integration · 2026-06-07T23:43:37.083083Z

_617 files · 398 import edges · snapshot fresh · dirty worktree_

## TL;DR — read this first

**What this is.** `vibecrafted` repository — current focus: _Runtime Integration_.

**Where you stand.** Branch `feat/runtime-integration`, dirty worktree, snapshot fresh.
Last 5 commits: `216f180 [claude/interactive] fix(skills): add Code-Derived Application Map to vc-justdo + vc-scaffold gates` · `60b0bde [claude/interactive] fix(install): wire shell rc on every machine for one truth after install-all` · `be044ea [claude/interactive] fix(test): stage marbles_spawn.sh under runtime/scripts in fixtures`
Active intent (AICX): "{"completed_at":1780688474,"duration_ms":33780,"last_agent_message":"Przeczytane w całości: 5 scope contextów, 814 linii.\n\nNajważniejszy obraz:\n\n- `vibecrafted-app`: największy blast radius. Szczególnie `mux-agent/src/config.rs`, `scan.rs`, `state.rs`; realne testy Rust do odpalenia przy zmianach.\n- `vibecrafted-core`: runtime serce. `__init__.py`, `events.py`, `runtime_paths.py`, `spawn.py`, `control_plane.py`, `workflow.py` są główne punkty ryzyka." — codex on 2026-06-05.
**Scope.** `path:vibecrafted-app` -> path:vibecrafted-app (107 files, fingerprint: 916a9cd2b34c).

**Top 3 things to know before editing.**
1. Hub `vibecrafted-app/mux-agent/src/config.rs` has 13 importers — touching it = wide blast radius (of 54 ranked hubs). (LoctreeDerived)
2. 3 high-fan-in file(s) exceed threshold — review impact before edits. (LoctreeDerived)
3. Active memory says `{"completed_at":1780688474,"duration_ms":33780,"last_agent_message":"Przeczytane w całości: 5 scope contextów, 814 linii.\n\nNajważniejszy obraz:\n\n- `vibecrafted-app`: największy blast radius. Szczególnie `mux-agent/src/config.rs`, `scan.rs`, `state.rs`; realne testy Rust do odpalenia przy zmianach.\n- `vibecrafted-core`: runtime serce. `__init__.py`, `events.py`, `runtime_paths.py`, `spawn.py`, `control_plane.py`, `workflow.py` są główne punkty ryzyka.` — codex on 2026-06-05. (AicxOperator)

**Snapshot facts.** 54 hubs · 303 idiom tag(s) · 27 dispatch edge(s) · 27 env contract(s) · 50 memory entries · 1369 authority claim(s).

**What's stale.** None.

## Where You Are

### Hubs — touch = blast radius

| File | Importers | Authority |
|---|---:|---|
| `vibecrafted-app/mux-agent/src/config.rs` | 13 | LoctreeDerived |
| `vibecrafted-app/mux-agent/src/scan.rs` | 10 | LoctreeDerived |
| `vibecrafted-app/mux-agent/src/state.rs` | 10 | LoctreeDerived |
| `vibecrafted-app/tray-agent/src/types.rs` | 7 | LoctreeDerived |
| `vibecrafted-app/tui-agent/src/app.rs` | 7 | LoctreeDerived |
| `vibecrafted-app/mux-agent/src/ipc/event.rs` | 6 | LoctreeDerived |
| `vibecrafted-app/tui-agent/src/state.rs` | 6 | LoctreeDerived |
| `vibecrafted-app/mux-agent/src/multi.rs` | 5 | LoctreeDerived |
| `vibecrafted-app/tui-agent/src/launch.rs` | 5 | LoctreeDerived |
| `vibecrafted-app/mux-agent/src/tray.rs` | 4 | LoctreeDerived |
| `vibecrafted-app/shell-agent/app/Vibecrafted/Bridge/vibecrafted_shell_ffi.swift` | 4 | LoctreeDerived |
| `vibecrafted-app/shell-agent/app/Vibecrafted/Views/SidebarViewController.swift` | 4 | LoctreeDerived |
| `vibecrafted-app/tray-agent/src/ipc_client.rs` | 4 | LoctreeDerived |
| `vibecrafted-app/tui-agent/src/mission_control.rs` | 4 | LoctreeDerived |
| `vibecrafted-app/tui-agent/src/polarize.rs` | 4 | LoctreeDerived |
| `vibecrafted-app/mux-agent/src/danger.rs` | 3 | LoctreeDerived |
| `vibecrafted-app/mux-agent/src/ipc/command.rs` | 3 | LoctreeDerived |
| `vibecrafted-app/mux-agent/src/mux_gen.rs` | 3 | LoctreeDerived |
| `vibecrafted-app/mux-agent/src/runtime/mod.rs` | 3 | LoctreeDerived |
| `vibecrafted-app/shell-agent/app/Vibecrafted/Views/CanvasViewController.swift` | 3 | LoctreeDerived |
| `vibecrafted-app/shell-agent/app/Vibecrafted/main.swift` | 3 | LoctreeDerived |
| `vibecrafted-app/shell-agent/ffi/src/lib.rs` | 3 | LoctreeDerived |
| `vibecrafted-app/tray-agent/src/state.rs` | 3 | LoctreeDerived |
| `vibecrafted-app/tui-agent/src/mux.rs` | 3 | LoctreeDerived |
| `vibecrafted-app/tui-agent/src/skills_catalog.rs` | 3 | LoctreeDerived |
| `vibecrafted-app/mux-agent/src/ipc/handlers.rs` | 2 | LoctreeDerived |
| `vibecrafted-app/mux-agent/src/ipc/server.rs` | 2 | LoctreeDerived |
| `vibecrafted-app/mux-agent/src/wizard/mod.rs` | 2 | LoctreeDerived |
| `vibecrafted-app/shell-agent/app/Vibecrafted/AppDelegate.swift` | 2 | LoctreeDerived |
| `vibecrafted-app/shell-agent/app/Vibecrafted/Views/MainWindowController.swift` | 2 | LoctreeDerived |
| `vibecrafted-app/tray-agent/src/icons.rs` | 2 | LoctreeDerived |
| `vibecrafted-app/tray-agent/src/menu.rs` | 2 | LoctreeDerived |
| `vibecrafted-app/tui-agent/src/config.rs` | 2 | LoctreeDerived |
| `vibecrafted-app/mux-agent/src/common.rs` | 1 | LoctreeDerived |
| `vibecrafted-app/mux-agent/src/ipc/mod.rs` | 1 | LoctreeDerived |
| `vibecrafted-app/mux-agent/src/jsonl_bridge.rs` | 1 | LoctreeDerived |
| `vibecrafted-app/mux-agent/src/multi_tui.rs` | 1 | LoctreeDerived |
| `vibecrafted-app/mux-agent/src/runtime/client.rs` | 1 | LoctreeDerived |
| `vibecrafted-app/mux-agent/src/runtime/heartbeat.rs` | 1 | LoctreeDerived |
| `vibecrafted-app/mux-agent/src/runtime/proxy.rs` | 1 | LoctreeDerived |
| `vibecrafted-app/mux-agent/src/runtime/server.rs` | 1 | LoctreeDerived |
| `vibecrafted-app/mux-agent/src/runtime/status.rs` | 1 | LoctreeDerived |
| `vibecrafted-app/mux-agent/src/runtime/types.rs` | 1 | LoctreeDerived |
| `vibecrafted-app/mux-agent/src/tray_dashboard.rs` | 1 | LoctreeDerived |
| `vibecrafted-app/mux-agent/src/wizard/keys.rs` | 1 | LoctreeDerived |
| `vibecrafted-app/mux-agent/src/wizard/persist.rs` | 1 | LoctreeDerived |
| `vibecrafted-app/mux-agent/src/wizard/services.rs` | 1 | LoctreeDerived |
+ 7 more, run `loct context --full` for full data

### Cycles

- not_measured (run `loct cycles` for current measurement) (LoctreeDerived)

### Recently active surface (last 24h)

- `.github/workflows/portable.yml` (RepoVerified)
- `.gitignore` (RepoVerified)
- `.junie/plans/decompose-vetcoders-shell-runtime.md` (RepoVerified)
- `.loctignore` (RepoVerified)
- `CHANGELOG.md` (RepoVerified)
- `Makefile` (RepoVerified)
- `agents/scripts/install-shell.sh` (RepoVerified)
- `agents/scripts/lib/meta.sh` (RepoVerified)
- `agents/scripts/skills_sync.sh` (RepoVerified)
- `agents/shell/lib/atuin.sh` (RepoVerified)

### Risk metrics

- dead_exports: not_measured (use-graph counts `pub use` re-exports as live — known limitation; run `loct dead` for current count) (RepoVerified)
- twins: not_measured (run `loct twins` for a context-classified pass) (RepoVerified)
- cache_scope: `Scoped("916a9cd2b34c")` (RepoVerified)
- high_fan_in: 3 files over threshold 10 (LoctreeDerived)

## What's Live

### Idiom tag clusters (top 10 by hit count)

- `idiom:rust-inherent-impl` (154 hits) — method-call reachability via inherent impls (SemanticGuess)
- `idiom:rust-reexport` (92 hits) — public re-export surface (SemanticGuess)
- `idiom:make-target` (45 hits) — .PHONY Make workflow targets (LoctreeDerived)
- `idiom:shell-helper` (2 hits) — info/warn shell helpers (LoctreeDerived)

### Dispatch edges (top 5 by reach)

- `vibecrafted-app/Makefile`:6 → `cargo` (`recipe_shell_call`) (LoctreeDerived)
- `vibecrafted-app/Makefile`:50 → `printf` (`recipe_shell_call`) (LoctreeDerived)
- `vibecrafted-app/mux-agent/Makefile`:55 → `cargo` (`recipe_shell_call`) (LoctreeDerived)
- `vibecrafted-app/mux-agent/Makefile`:106 → `mkdir` (`recipe_shell_call`) (LoctreeDerived)
- `vibecrafted-app/mux-agent/Makefile`:22 → `printf` (`recipe_shell_call`) (LoctreeDerived)

### Env contracts (vars used in scope)

- `APP_MACOS_DIR` — used in 1 file(s) (LoctreeDerived)
- `APP_PATH` — used in 2 file(s) (LoctreeDerived)
- `BASH_SOURCE` — used in 60 file(s) (LoctreeDerived)
- `BRIDGE_DIR` — used in 1 file(s) (LoctreeDerived)
- `BUILD_DIR` — used in 1 file(s) (LoctreeDerived)
- `CARGO_BIN` — used in 1 file(s) (LoctreeDerived)
- `CARGO_HOME` — used in 1 file(s) (LoctreeDerived)
- `CONTENTS_FOLDER_PATH` — used in 1 file(s) (LoctreeDerived)
- `DMG_NAME` — used in 1 file(s) (LoctreeDerived)
- `DMG_STAGING` — used in 1 file(s) (LoctreeDerived)

### Reachability (top 5 widely-reached symbols)

- `vibecrafted-app/Makefile::app` — reason: `phony_make_target` (LoctreeDerived)
- `vibecrafted-app/Makefile::app-debug` — reason: `phony_make_target` (LoctreeDerived)
- `vibecrafted-app/Makefile::bindings` — reason: `phony_make_target` (LoctreeDerived)
- `vibecrafted-app/Makefile::check` — reason: `phony_make_target` (LoctreeDerived)
- `vibecrafted-app/Makefile::clean` — reason: `phony_make_target` (LoctreeDerived)

## Memory

### Recent decisions / intents / outcomes (last 168h, top by relevance)

1. `outcome` · codex · 2026-06-05 · _{"completed_at":1780688474,"duration_ms":33780,"last_agent_message":"Przeczytane w całości: 5 scope contextów, 814 linii.\n\nNajważniejszy obraz:\n\n- `vibecrafted-app`: największy blast radius. Szczególnie `mux-agent/src/config.rs`, `scan.rs`, `state.rs`; realne testy Rust do odpalenia przy zmianach.\n- `vibecrafted-core`: runtime serce. `__init__.py`, `events.py`, `runtime_paths.py`, `spawn.py`, `control_plane.py`, `workflow.py` są główne punkty ryzyka._ (AicxAgent) — chunk: `chunk:48e118ea`
2. `outcome` · codex · 2026-06-05 · _{"completed_at":1780697273,"duration_ms":25193,"last_agent_message":"Tak, teraz mam już te MCP-y działające po stronie Codexa.\n\nKonkretnie: po zmianie configu i odświeżeniu tool discovery `loctree-mcp` wystawił namespace `mcp__loctree_mcp`, a realny smoke-test przeszedł:\n\n```text\nslice scripts/vetcoders_install.py\ncore_loc: 5482\ndependencies: scripts/installer_brand.py, scripts/runtime_paths.py\nconsumer: scripts/build_marketplace_bundle._ (AicxAgent) — chunk: `chunk:a5e67bf9`
3. `outcome` · codex · 2026-06-05 · _{"completed_at":1780688474,"duration_ms":33780,"last_agent_message":"Przeczytane w całości: 5 scope contextów, 814 linii.\n\nNajważniejszy obraz:\n\n- `vibecrafted-app`: największy blast radius. Szczególnie `mux-agent/src/config.rs`, `scan.rs`, `state.rs`; realne testy Rust do odpalenia przy zmianach.\n- `vibecrafted-core`: runtime serce. `__init__.py`, `events.py`, `runtime_paths.py`, `spawn.py`, `control_plane.py`, `workflow.py` są główne punkty ryzyka._ (AicxAgent) — chunk: `chunk:48e118ea`
4. `outcome` · codex · 2026-06-05 · _{"completed_at":1780697273,"duration_ms":25193,"last_agent_message":"Tak, teraz mam już te MCP-y działające po stronie Codexa.\n\nKonkretnie: po zmianie configu i odświeżeniu tool discovery `loctree-mcp` wystawił namespace `mcp__loctree_mcp`, a realny smoke-test przeszedł:\n\n```text\nslice scripts/vetcoders_install.py\ncore_loc: 5482\ndependencies: scripts/installer_brand.py, scripts/runtime_paths.py\nconsumer: scripts/build_marketplace_bundle._ (AicxAgent) — chunk: `chunk:a5e67bf9`
5. `outcome` · codex · 2026-06-05 · _{"completed_at":1780688474,"duration_ms":33780,"last_agent_message":"Przeczytane w całości: 5 scope contextów, 814 linii.\n\nNajważniejszy obraz:\n\n- `vibecrafted-app`: największy blast radius. Szczególnie `mux-agent/src/config.rs`, `scan.rs`, `state.rs`; realne testy Rust do odpalenia przy zmianach.\n- `vibecrafted-core`: runtime serce. `__init__.py`, `events.py`, `runtime_paths.py`, `spawn.py`, `control_plane.py`, `workflow.py` są główne punkty ryzyka._ (AicxAgent) — chunk: `chunk:48e118ea`
6. `outcome` · codex · 2026-06-05 · _{"call_id":"call_yw5VKW9ST4pM1a4TjNaMcj0R","changes":{"/Users/maciejgad/vc-workspace/vetcoders/vibecrafted/plans/2026-06-05-workflow-runtime-extraction.md":{"content":"---\nstatus: draft\nowner: codex\ndate: 2026-06-05\nvector: stabilize\n---\n\n# Workflow Runtime Extraction\n\n## Current State\n\nWorkflow runtime truth is split across:\n\n- `skills/<workflow>/SKILL.md`, `FLOW.md`, references, templates, and agent YAML.\n- `skills/vc-agents/shell/lib/*._ (AicxAgent) — chunk: `chunk:70c2d1cc`
7. `outcome` · codex · 2026-06-05 · _{"call_id":"call_Zgu0iBG7LARhjX81VPejY5ZT","changes":{"/Users/maciejgad/vc-workspace/vetcoders/vibecrafted/tests/tui/test_runtime_regressions.py":{"content":"from __future__ import annotations\n\nimport os\nimport subprocess\nfrom pathlib import Path\n\nfrom scripts import vetcoders_install\n\nREPO_ROOT = Path(__file__).resolve().parents[2]\nSHELL_SH = REPO_ROOT / \"skills\" / \"vc-agents\" / \"shell\" / \"vetcoders._ (AicxAgent) — chunk: `chunk:3ec05ea4`
8. `outcome` · codex · 2026-06-05 · _{"completed_at":1780697273,"duration_ms":25193,"last_agent_message":"Tak, teraz mam już te MCP-y działające po stronie Codexa.\n\nKonkretnie: po zmianie configu i odświeżeniu tool discovery `loctree-mcp` wystawił namespace `mcp__loctree_mcp`, a realny smoke-test przeszedł:\n\n```text\nslice scripts/vetcoders_install.py\ncore_loc: 5482\ndependencies: scripts/installer_brand.py, scripts/runtime_paths.py\nconsumer: scripts/build_marketplace_bundle._ (AicxAgent) — chunk: `chunk:a5e67bf9`
9. `outcome` · codex · 2026-06-05 · _{"completed_at":1780688474,"duration_ms":33780,"last_agent_message":"Przeczytane w całości: 5 scope contextów, 814 linii.\n\nNajważniejszy obraz:\n\n- `vibecrafted-app`: największy blast radius. Szczególnie `mux-agent/src/config.rs`, `scan.rs`, `state.rs`; realne testy Rust do odpalenia przy zmianach.\n- `vibecrafted-core`: runtime serce. `__init__.py`, `events.py`, `runtime_paths.py`, `spawn.py`, `control_plane.py`, `workflow.py` są główne punkty ryzyka._ (AicxAgent) — chunk: `chunk:48e118ea`
10. `outcome` · codex · 2026-06-05 · _{"call_id":"call_yw5VKW9ST4pM1a4TjNaMcj0R","changes":{"/Users/maciejgad/vc-workspace/vetcoders/vibecrafted/plans/2026-06-05-workflow-runtime-extraction.md":{"content":"---\nstatus: draft\nowner: codex\ndate: 2026-06-05\nvector: stabilize\n---\n\n# Workflow Runtime Extraction\n\n## Current State\n\nWorkflow runtime truth is split across:\n\n- `skills/<workflow>/SKILL.md`, `FLOW.md`, references, templates, and agent YAML.\n- `skills/vc-agents/shell/lib/*._ (AicxAgent) — chunk: `chunk:70c2d1cc`
11. `outcome` · codex · 2026-06-05 · _{"completed_at":1780697273,"duration_ms":25193,"last_agent_message":"Tak, teraz mam już te MCP-y działające po stronie Codexa.\n\nKonkretnie: po zmianie configu i odświeżeniu tool discovery `loctree-mcp` wystawił namespace `mcp__loctree_mcp`, a realny smoke-test przeszedł:\n\n```text\nslice scripts/vetcoders_install.py\ncore_loc: 5482\ndependencies: scripts/installer_brand.py, scripts/runtime_paths.py\nconsumer: scripts/build_marketplace_bundle._ (AicxAgent) — chunk: `chunk:a5e67bf9`
12. `outcome` · codex · 2026-06-05 · _{"completed_at":1780688474,"duration_ms":33780,"last_agent_message":"Przeczytane w całości: 5 scope contextów, 814 linii.\n\nNajważniejszy obraz:\n\n- `vibecrafted-app`: największy blast radius. Szczególnie `mux-agent/src/config.rs`, `scan.rs`, `state.rs`; realne testy Rust do odpalenia przy zmianach.\n- `vibecrafted-core`: runtime serce. `__init__.py`, `events.py`, `runtime_paths.py`, `spawn.py`, `control_plane.py`, `workflow.py` są główne punkty ryzyka._ (AicxAgent) — chunk: `chunk:48e118ea`
13. `outcome` · codex · 2026-06-05 · _{"call_id":"call_PVlRZAQz8VMdMVPB9KKyBcY3","changes":{"/Users/maciejgad/vc-workspace/vetcoders/vibecrafted/agents/scripts/lib/meta.sh":{"move_path":null,"type":"update","unified_diff":"@@ -449,3 +449,6 @@\n \"status\",\n+ \"date\",\n \"session_id\",\n+ \"artifact_stem\",\n+ \"artifact_kind\",\n \"repo_path\",\n@@ -470,2 +473,66 @@\n \n+def slug_component(value: object, fallback: str) -> str:\n+ raw = str(value or fallback)\n+ raw = re.sub(r\"[^A-Za-z0-9._-]+\", \"-\", raw)._ (AicxAgent) — chunk: `chunk:2fc271d5`
14. `outcome` · codex · 2026-06-05 · _{"call_id":"call_yw5VKW9ST4pM1a4TjNaMcj0R","changes":{"/Users/maciejgad/vc-workspace/vetcoders/vibecrafted/plans/2026-06-05-workflow-runtime-extraction.md":{"content":"---\nstatus: draft\nowner: codex\ndate: 2026-06-05\nvector: stabilize\n---\n\n# Workflow Runtime Extraction\n\n## Current State\n\nWorkflow runtime truth is split across:\n\n- `skills/<workflow>/SKILL.md`, `FLOW.md`, references, templates, and agent YAML.\n- `skills/vc-agents/shell/lib/*._ (AicxAgent) — chunk: `chunk:70c2d1cc`
15. `outcome` · codex · 2026-06-05 · _{"call_id":"call_Zgu0iBG7LARhjX81VPejY5ZT","changes":{"/Users/maciejgad/vc-workspace/vetcoders/vibecrafted/tests/tui/test_runtime_regressions.py":{"content":"from __future__ import annotations\n\nimport os\nimport subprocess\nfrom pathlib import Path\n\nfrom scripts import vetcoders_install\n\nREPO_ROOT = Path(__file__).resolve().parents[2]\nSHELL_SH = REPO_ROOT / \"skills\" / \"vc-agents\" / \"shell\" / \"vetcoders._ (AicxAgent) — chunk: `chunk:3ec05ea4`

### Source chunk pointers

_24 unique chunk(s) reachable via `aicx open <chunk:ref>` (resolved against the operator's local aicx store; absolute paths intentionally redacted to keep this context-pack commitable)._

## Action

### Next safe commands (grounded, ≤3)

```bash
loct slice vibecrafted-app/AGENTS.md
loct impact vibecrafted-app/AGENTS.md
loct context --file vibecrafted-app/AGENTS.md
```

### Verification gates (run before any commit)

- `make test` (SemanticGuess)
- `make check` (SemanticGuess)
- `mypy .` (SemanticGuess)
- `python -m pytest` (SemanticGuess)
- `cargo test --test jsonl_bridge_test` (SemanticGuess)
- `cargo test --test ipc_client` (SemanticGuess)
- `cargo test --test spawn_update_render_test` (SemanticGuess)
- `cargo test --test launch_readiness` (SemanticGuess)

### Likely tests for current scope

- `vibecrafted-app/mux-agent/tests/jsonl_bridge_test.rs` (LoctreeDerived)
- `vibecrafted-app/tray-agent/tests/ipc_client.rs` (LoctreeDerived)
- `vibecrafted-app/tray-agent/tests/spawn_update_render_test.rs` (LoctreeDerived)
- `vibecrafted-app/tui-agent/tests/launch_readiness.rs` (LoctreeDerived)
- `vibecrafted-app/tui-agent/tests/skill_launcher.rs` (LoctreeDerived)
- `vibecrafted-app/tui-agent/tests/state_contract.rs` (LoctreeDerived)

## Authority Index

_1369 total claims tagged with provenance._

- **RepoVerified** (11) — AST + git state derivation
- **LoctreeDerived** (763) — snapshot edges + idiom catalogs
- **AicxOperator** (0) — operator decisions / intents from AICX
- **AicxAgent** (50) — agent outcomes (verify before propagating)
- **AicxFailure** (0) — anti-recommendations (avoid repeating)
- **SemanticGuess** (545) — heuristic only, low trust
- **StaleOrUnknown** (0) — explicit "we don't know"


---

*`loct context` rendered in 13871ms · sections: where=79L · live=38L · memory=24L · `--full` for full ContextPack data · `--file <X>` to narrow scope*
