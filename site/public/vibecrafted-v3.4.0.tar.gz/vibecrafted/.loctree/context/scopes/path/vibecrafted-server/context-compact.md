# Loctree Context · vibecrafted @ feat/runtime-integration · 2026-06-15T14:30:54.36806Z

_710 files · 468 import edges · snapshot fresh · dirty worktree_

## TL;DR — read this first

**What this is.** `vibecrafted` repository — current focus: _Runtime Integration_.

**Where you stand.** Branch `feat/runtime-integration`, dirty worktree, snapshot fresh.
Last 5 commits: `9f76009 [codex/implement] fix(runtime): centralize launcher ulimit hardening` · `3e9ea7a [claude/vc-implement] fix(spawn): read run-closure footer tokens for all agents` · `dadcbd4 [claude/vc-implement] fix(agent-stream): render gemini token line for spawn extractor`
**Scope.** `path:vibecrafted-server` -> path:vibecrafted-server (21 files, fingerprint: de81ef8c7fa0).

**Top 3 things to know before editing.**
1. Hub `vibecrafted-server/control-core/src/model.rs` has 3 importers — touching it = wide blast radius (of 30 ranked hubs). (LoctreeDerived)
2. Worktree is dirty — auto-scope mirrors uncommitted edits, not committed state. (RepoVerified)
3. _no significant recent activity or runtime contract detected._ (StaleOrUnknown)

**Snapshot facts.** 30 hubs · 67 idiom tag(s) · 0 dispatch edge(s) · 0 env contract(s) · 0 memory entries · 227 authority claim(s).

**What's stale.** None.

## Where You Are

### Hubs — touch = blast radius

| File | Importers | Authority |
|---|---:|---|
| `vibecrafted-server/control-core/src/model.rs` | 3 | LoctreeDerived |
| `vibecrafted-server/web/src/theme.rs` | 3 | LoctreeDerived |
| `vibecrafted-server/control-core/src/events.rs` | 2 | LoctreeDerived |
| `vibecrafted-server/web/src/scaffold/mod.rs` | 2 | LoctreeDerived |
| `vibecrafted-server/control-core/src/read.rs` | 1 | LoctreeDerived |
| `vibecrafted-server/control-core/src/scaffold.rs` | 1 | LoctreeDerived |
| `vibecrafted-server/web/src/app.rs` | 1 | LoctreeDerived |
| `vibecrafted-server/web/src/control/mod.rs` | 1 | LoctreeDerived |

### Cycles

- not_measured (run `loct cycles` for current measurement) (LoctreeDerived)

### Recently active surface (last 24h)

- `.gitignore` (RepoVerified)
- `Makefile` (RepoVerified)
- `config/zellij/layouts/operator.kdl` (RepoVerified)
- `runtime/scripts/common.sh` (RepoVerified)
- `runtime/scripts/lib/launcher.sh` (RepoVerified)
- `runtime/scripts/lib/ulimits.sh` (RepoVerified)
- `runtime/scripts/lib/zellij.sh` (RepoVerified)
- `runtime/shell/lib/dashboard.sh` (RepoVerified)
- `runtime/shell/lib/ulimits.sh` (RepoVerified)
- `runtime/shell/lib/zellij.sh` (RepoVerified)

### Risk metrics

- dead_exports: not_measured (use-graph counts `pub use` re-exports as live — known limitation; run `loct dead` for current count) (RepoVerified)
- twins: not_measured (run `loct twins` for a context-classified pass) (RepoVerified)
- cache_scope: `Scoped("de81ef8c7fa0")` (RepoVerified)
- high_fan_in: 0 over threshold 10 (LoctreeDerived)

## What's Live

### Idiom tag clusters (top 10 by hit count)

- `idiom:rust-reexport` (33 hits) — public re-export surface (SemanticGuess)
- `idiom:rust-inherent-impl` (28 hits) — method-call reachability via inherent impls (SemanticGuess)

### Dispatch edges (top 5 by reach)

- _no dispatch edges in scope_ (LoctreeDerived)

### Env contracts (vars used in scope)

- _no env vars surfaced in scope_ (LoctreeDerived)

### Reachability (top 5 widely-reached symbols)

- `vibecrafted-server/control-core/src/events.rs::new` — reason: `idiom_runtime_role:library_helper` (SemanticGuess)
- `vibecrafted-server/control-core/src/events.rs::path` — reason: `idiom_runtime_role:library_helper` (SemanticGuess)
- `vibecrafted-server/control-core/src/events.rs::read_all` — reason: `idiom_runtime_role:library_helper` (SemanticGuess)
- `vibecrafted-server/control-core/src/events.rs::read_since` — reason: `idiom_runtime_role:library_helper` (SemanticGuess)
- `vibecrafted-server/control-core/src/events.rs::tail` — reason: `idiom_runtime_role:library_helper` (SemanticGuess)

## Memory

_AICX overlay disabled by `--no-aicx`; memory overlay intentionally omitted._ (RepoVerified)

## Action

### Power Path (suggested next steps)

- `loct slice vibecrafted-server/Cargo.toml`: Slice this file to inspect its direct dependencies and immediate consumers before editing.
- `loct follow`: Pursue unified structural signals (dead exports, import cycles, twins) to ensure health.
- `loct slice vibecrafted-server/README.md`: Slice this file to inspect its direct dependencies and immediate consumers before editing.
- `loct slice vibecrafted-server/control-core/Cargo.toml`: Slice this file to inspect its direct dependencies and immediate consumers before editing.
- `loct slice vibecrafted-server/control-core/examples/dump.rs`: Slice this file to inspect its direct dependencies and immediate consumers before editing.
- `loct slice vibecrafted-server/control-core/src/events.rs`: Slice this file to inspect its direct dependencies and immediate consumers before editing.
- `loct impact vibecrafted-server/control-core/src/events.rs`: Assess the transitive blast radius and downstream consumers of this file before modifying.
- `loct body new`: View the definition body of symbol 'new' to understand its implementation structure.
- `loct find --literal new`: Execute a literal exact-identifier scan for 'new' to find exact matches across the codebase.
- `loct occurrences new`: Perform a literal boundary-sensitive occurrences scan for 'new' to locate all references.
- `loct slice vibecrafted-server/control-core/src/lib.rs`: Slice this file to inspect its direct dependencies and immediate consumers before editing.
- `loct body EventBatch`: View the definition body of symbol 'EventBatch' to understand its implementation structure.
- `loct find --literal EventBatch`: Execute a literal exact-identifier scan for 'EventBatch' to find exact matches across the codebase.
- `loct occurrences EventBatch`: Perform a literal boundary-sensitive occurrences scan for 'EventBatch' to locate all references.
- `loct slice vibecrafted-server/control-core/src/model.rs`: Slice this file to inspect its direct dependencies and immediate consumers before editing.
- `loct impact vibecrafted-server/control-core/src/model.rs`: Assess the transitive blast radius and downstream consumers of this file before modifying.
- `loct body is_active_state`: View the definition body of symbol 'is_active_state' to understand its implementation structure.
- `loct find --literal is_active_state`: Execute a literal exact-identifier scan for 'is_active_state' to find exact matches across the codebase.
- `loct occurrences is_active_state`: Perform a literal boundary-sensitive occurrences scan for 'is_active_state' to locate all references.
- `loct slice vibecrafted-server/control-core/src/read.rs`: Slice this file to inspect its direct dependencies and immediate consumers before editing.
- `loct impact vibecrafted-server/control-core/src/read.rs`: Assess the transitive blast radius and downstream consumers of this file before modifying.
- `loct body vibecrafted_home`: View the definition body of symbol 'vibecrafted_home' to understand its implementation structure.
- `loct find --literal vibecrafted_home`: Execute a literal exact-identifier scan for 'vibecrafted_home' to find exact matches across the codebase.
- `loct occurrences vibecrafted_home`: Perform a literal boundary-sensitive occurrences scan for 'vibecrafted_home' to locate all references.
- `loct slice vibecrafted-server/control-core/src/scaffold.rs`: Slice this file to inspect its direct dependencies and immediate consumers before editing.
- `loct impact vibecrafted-server/control-core/src/scaffold.rs`: Assess the transitive blast radius and downstream consumers of this file before modifying.
- `loct body as_str`: View the definition body of symbol 'as_str' to understand its implementation structure.
- `loct find --literal as_str`: Execute a literal exact-identifier scan for 'as_str' to find exact matches across the codebase.
- `loct occurrences as_str`: Perform a literal boundary-sensitive occurrences scan for 'as_str' to locate all references.
- `loct slice vibecrafted-server/control-core/tests/scaffold_artifacts.rs`: Slice this file to inspect its direct dependencies and immediate consumers before editing.
- `loct slice vibecrafted-server/control-core/tests/schema_fidelity.rs`: Slice this file to inspect its direct dependencies and immediate consumers before editing.
- `loct slice vibecrafted-server/web/Cargo.toml`: Slice this file to inspect its direct dependencies and immediate consumers before editing.
- `loct slice vibecrafted-server/web/src/app.rs`: Slice this file to inspect its direct dependencies and immediate consumers before editing.
- `loct impact vibecrafted-server/web/src/app.rs`: Assess the transitive blast radius and downstream consumers of this file before modifying.
- `loct body shell`: View the definition body of symbol 'shell' to understand its implementation structure.
- `loct find --literal shell`: Execute a literal exact-identifier scan for 'shell' to find exact matches across the codebase.
- `loct occurrences shell`: Perform a literal boundary-sensitive occurrences scan for 'shell' to locate all references.
- `loct slice vibecrafted-server/web/src/control/mod.rs`: Slice this file to inspect its direct dependencies and immediate consumers before editing.
- `loct impact vibecrafted-server/web/src/control/mod.rs`: Assess the transitive blast radius and downstream consumers of this file before modifying.
- `loct body control_routes`: View the definition body of symbol 'control_routes' to understand its implementation structure.
- `loct find --literal control_routes`: Execute a literal exact-identifier scan for 'control_routes' to find exact matches across the codebase.
- `loct occurrences control_routes`: Perform a literal boundary-sensitive occurrences scan for 'control_routes' to locate all references.
- `loct slice vibecrafted-server/web/src/lib.rs`: Slice this file to inspect its direct dependencies and immediate consumers before editing.
- `loct body hydrate`: View the definition body of symbol 'hydrate' to understand its implementation structure.
- `loct find --literal hydrate`: Execute a literal exact-identifier scan for 'hydrate' to find exact matches across the codebase.
- `loct occurrences hydrate`: Perform a literal boundary-sensitive occurrences scan for 'hydrate' to locate all references.
- `loct slice vibecrafted-server/web/src/main.rs`: Slice this file to inspect its direct dependencies and immediate consumers before editing.
- `loct slice vibecrafted-server/web/src/scaffold/mod.rs`: Slice this file to inspect its direct dependencies and immediate consumers before editing.
- `loct impact vibecrafted-server/web/src/scaffold/mod.rs`: Assess the transitive blast radius and downstream consumers of this file before modifying.
- `loct body ScaffoldEditorPage`: View the definition body of symbol 'ScaffoldEditorPage' to understand its implementation structure.
- `loct find --literal ScaffoldEditorPage`: Execute a literal exact-identifier scan for 'ScaffoldEditorPage' to find exact matches across the codebase.
- `loct occurrences ScaffoldEditorPage`: Perform a literal boundary-sensitive occurrences scan for 'ScaffoldEditorPage' to locate all references.
- `loct slice vibecrafted-server/web/src/theme.rs`: Slice this file to inspect its direct dependencies and immediate consumers before editing.
- `loct impact vibecrafted-server/web/src/theme.rs`: Assess the transitive blast radius and downstream consumers of this file before modifying.
- `loct body code`: View the definition body of symbol 'code' to understand its implementation structure.
- `loct find --literal code`: Execute a literal exact-identifier scan for 'code' to find exact matches across the codebase.
- `loct occurrences code`: Perform a literal boundary-sensitive occurrences scan for 'code' to locate all references.
- `loct slice vibecrafted-server/web/styles/fonts.css`: Slice this file to inspect its direct dependencies and immediate consumers before editing.
- `loct slice vibecrafted-server/web/styles/main.css`: Slice this file to inspect its direct dependencies and immediate consumers before editing.
- `loct slice vibecrafted-server/web/styles/tokens.css`: Slice this file to inspect its direct dependencies and immediate consumers before editing.

### Next safe commands (grounded, ≤3)

```bash
loct context --file vibecrafted-server/Cargo.toml
loct context --file vibecrafted-server/README.md
loct context --file vibecrafted-server/control-core/Cargo.toml
```

### Verification gates (run before any commit)

- `mypy .` (SemanticGuess)

### Likely tests for current scope

- `tests/agent_dispatch_test.py` (LoctreeDerived)
- `tests/tui/test_keys.py` (LoctreeDerived)
- `vibecrafted-app/tui-agent/tests/mission_control_snapshots.rs` (LoctreeDerived)
- `vibecrafted-app/tui-agent/tests/state_contract.rs` (LoctreeDerived)
- `vibecrafted-core/tests/dispatch/test_cli.py` (LoctreeDerived)
- `vibecrafted-core/tests/dispatch/test_supervisor.py` (LoctreeDerived)
- `vibecrafted-core/tests/test_agy_junie_pipeline.py` (LoctreeDerived)
- `vibecrafted-core/tests/test_aicx_sync.py` (LoctreeDerived)
- `vibecrafted-core/tests/test_capabilities.py` (LoctreeDerived)
- `vibecrafted-core/tests/test_cli.py` (LoctreeDerived)

## Authority Index

_227 total claims tagged with provenance._

- **RepoVerified** (4) — AST + git state derivation
- **LoctreeDerived** (93) — snapshot edges + idiom catalogs
- **AicxOperator** (0) — operator decisions / intents from AICX
- **AicxAgent** (0) — agent outcomes (verify before propagating)
- **AicxFailure** (0) — anti-recommendations (avoid repeating)
- **SemanticGuess** (130) — heuristic only, low trust
- **StaleOrUnknown** (0) — explicit "we don't know"


---

*`loct context` rendered in 7419ms · sections: where=39L · live=23L · memory=4L · `--full` for full ContextPack data · `--file <X>` to narrow scope*
