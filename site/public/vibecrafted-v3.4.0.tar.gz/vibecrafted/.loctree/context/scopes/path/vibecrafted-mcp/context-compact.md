# Loctree Context · vibecrafted @ feat/runtime-integration · 2026-06-15T14:31:11.237645Z

_710 files · 468 import edges · snapshot fresh · dirty worktree_

## TL;DR — read this first

**What this is.** `vibecrafted` repository — current focus: _Runtime Integration_.

**Where you stand.** Branch `feat/runtime-integration`, dirty worktree, snapshot fresh.
Last 5 commits: `9f76009 [codex/implement] fix(runtime): centralize launcher ulimit hardening` · `3e9ea7a [claude/vc-implement] fix(spawn): read run-closure footer tokens for all agents` · `dadcbd4 [claude/vc-implement] fix(agent-stream): render gemini token line for spawn extractor`
**Scope.** `path:vibecrafted-mcp` -> path:vibecrafted-mcp (8 files, fingerprint: 1adb52e31c44).

**Top 3 things to know before editing.**
1. Hub `vibecrafted-mcp/vibecrafted_mcp/server.py` has 3 importers — touching it = wide blast radius (of 30 ranked hubs). (LoctreeDerived)
2. Worktree is dirty — auto-scope mirrors uncommitted edits, not committed state. (RepoVerified)
3. Env var `VIBECRAFTED_HOME` is read by 27 file(s) in scope — verify before refactoring config flow. (LoctreeDerived)

**Snapshot facts.** 30 hubs · 2 idiom tag(s) · 0 dispatch edge(s) · 1 env contract(s) · 0 memory entries · 23 authority claim(s).

**What's stale.** None.

## Where You Are

### Hubs — touch = blast radius

| File | Importers | Authority |
|---|---:|---|
| `vibecrafted-mcp/vibecrafted_mcp/server.py` | 3 | LoctreeDerived |
| `vibecrafted-mcp/vibecrafted_mcp/__init__.py` | 1 | LoctreeDerived |

### Cycles

- not_measured (run `loct cycles` for current measurement) (LoctreeDerived)

### Recently active surface (last 24h)

- `.gitignore` (RepoVerified)
- `Makefile` (RepoVerified)
- `config/zellij/layouts/operator.kdl` (RepoVerified)
- `runtime/scripts/common.sh` (RepoVerified)
- `runtime/scripts/lib/launcher.sh` (RepoVerified)
- `runtime/scripts/lib/ulimits.sh` (RepoVerified)
- `runtime/scripts/lib/zellij.sh` (RepoVerified)
- `runtime/shell/lib/dashboard.sh` (RepoVerified)
- `runtime/shell/lib/ulimits.sh` (RepoVerified)
- `runtime/shell/lib/zellij.sh` (RepoVerified)

### Risk metrics

- dead_exports: not_measured (use-graph counts `pub use` re-exports as live — known limitation; run `loct dead` for current count) (RepoVerified)
- twins: not_measured (run `loct twins` for a context-classified pass) (RepoVerified)
- cache_scope: `Scoped("1adb52e31c44")` (RepoVerified)
- high_fan_in: 0 over threshold 10 (LoctreeDerived)

## What's Live

### Idiom tag clusters (top 10 by hit count)

- `idiom:shell-helper` (2 hits) — main shell helpers (LoctreeDerived)

### Dispatch edges (top 5 by reach)

- _no dispatch edges in scope_ (LoctreeDerived)

### Env contracts (vars used in scope)

- `VIBECRAFTED_HOME` — used in 27 file(s) (LoctreeDerived)

### Reachability (top 5 widely-reached symbols)

- `vibecrafted-mcp/vibecrafted_mcp/__init__.py::main` — reason: `idiom_runtime_role:primary_entrypoint` (SemanticGuess)
- `vibecrafted-mcp/vibecrafted_mcp/server.py::main` — reason: `idiom_runtime_role:primary_entrypoint` (SemanticGuess)

## Memory

_AICX overlay disabled by `--no-aicx`; memory overlay intentionally omitted._ (RepoVerified)

## Action

### Power Path (suggested next steps)

- `loct slice vibecrafted-mcp/README.md`: Slice this file to inspect its direct dependencies and immediate consumers before editing.
- `loct follow`: Pursue unified structural signals (dead exports, import cycles, twins) to ensure health.
- `loct slice vibecrafted-mcp/pyproject.toml`: Slice this file to inspect its direct dependencies and immediate consumers before editing.
- `loct slice vibecrafted-mcp/tests/__init__.py`: Slice this file to inspect its direct dependencies and immediate consumers before editing.
- `loct slice vibecrafted-mcp/tests/conftest.py`: Slice this file to inspect its direct dependencies and immediate consumers before editing.
- `loct slice vibecrafted-mcp/tests/test_server.py`: Slice this file to inspect its direct dependencies and immediate consumers before editing.
- `loct body test_live_failure_score_clean_repo_is_low`: View the definition body of symbol 'test_live_failure_score_clean_repo_is_low' to understand its implementation structure.
- `loct find --literal test_live_failure_score_clean_repo_is_low`: Execute a literal exact-identifier scan for 'test_live_failure_score_clean_repo_is_low' to find exact matches across the codebase.
- `loct occurrences test_live_failure_score_clean_repo_is_low`: Perform a literal boundary-sensitive occurrences scan for 'test_live_failure_score_clean_repo_is_low' to locate all references.
- `loct slice vibecrafted-mcp/vibecrafted_mcp/__init__.py`: Slice this file to inspect its direct dependencies and immediate consumers before editing.
- `loct impact vibecrafted-mcp/vibecrafted_mcp/__init__.py`: Assess the transitive blast radius and downstream consumers of this file before modifying.
- `loct body annotations`: View the definition body of symbol 'annotations' to understand its implementation structure.
- `loct find --literal annotations`: Execute a literal exact-identifier scan for 'annotations' to find exact matches across the codebase.
- `loct occurrences annotations`: Perform a literal boundary-sensitive occurrences scan for 'annotations' to locate all references.
- `loct slice vibecrafted-mcp/vibecrafted_mcp/server.py`: Slice this file to inspect its direct dependencies and immediate consumers before editing.
- `loct impact vibecrafted-mcp/vibecrafted_mcp/server.py`: Assess the transitive blast radius and downstream consumers of this file before modifying.
- `loct body build_server`: View the definition body of symbol 'build_server' to understand its implementation structure.
- `loct find --literal build_server`: Execute a literal exact-identifier scan for 'build_server' to find exact matches across the codebase.
- `loct occurrences build_server`: Perform a literal boundary-sensitive occurrences scan for 'build_server' to locate all references.
- `loct slice vibecrafted-mcp/vibecrafted_mcp/synthesis.py`: Slice this file to inspect its direct dependencies and immediate consumers before editing.
- `loct body live_failure_score`: View the definition body of symbol 'live_failure_score' to understand its implementation structure.
- `loct find --literal live_failure_score`: Execute a literal exact-identifier scan for 'live_failure_score' to find exact matches across the codebase.
- `loct occurrences live_failure_score`: Perform a literal boundary-sensitive occurrences scan for 'live_failure_score' to locate all references.

### Next safe commands (grounded, ≤3)

```bash
loct context --file vibecrafted-mcp/README.md
loct context --file vibecrafted-mcp/pyproject.toml
loct context --file vibecrafted-mcp/tests/__init__.py
```

### Verification gates (run before any commit)

- `mypy .` (SemanticGuess)

### Likely tests for current scope

- `plugins/iterm2/tests/test_iterm2_osc.py` (LoctreeDerived)
- `plugins/iterm2/tests/test_iterm2_plugin.py` (LoctreeDerived)
- `plugins/iterm2/tests/test_iterm2_profiles.py` (LoctreeDerived)
- `tests/agent_dispatch_test.py` (LoctreeDerived)
- `tests/tui/test_agy_junie_pipeline.py` (LoctreeDerived)
- `tests/tui/test_artifact_truth.py` (LoctreeDerived)
- `tests/tui/test_atuin_fallback.py` (LoctreeDerived)
- `tests/tui/test_await_observe_contract.py` (LoctreeDerived)
- `vibecrafted-core/tests/dispatch/test_cli.py` (LoctreeDerived)
- `vibecrafted-core/tests/dispatch/test_doctor.py` (LoctreeDerived)

## Authority Index

_23 total claims tagged with provenance._

- **RepoVerified** (2) — AST + git state derivation
- **LoctreeDerived** (19) — snapshot edges + idiom catalogs
- **AicxOperator** (0) — operator decisions / intents from AICX
- **AicxAgent** (0) — agent outcomes (verify before propagating)
- **AicxFailure** (0) — anti-recommendations (avoid repeating)
- **SemanticGuess** (2) — heuristic only, low trust
- **StaleOrUnknown** (0) — explicit "we don't know"


---

*`loct context` rendered in 7336ms · sections: where=33L · live=19L · memory=4L · `--full` for full ContextPack data · `--file <X>` to narrow scope*
