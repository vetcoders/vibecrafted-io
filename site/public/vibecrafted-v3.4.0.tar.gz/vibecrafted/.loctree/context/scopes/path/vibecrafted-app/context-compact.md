# Loctree Context · vibecrafted @ feat/runtime-integration · 2026-06-15T14:30:39.907435Z

_710 files · 468 import edges · snapshot fresh · dirty worktree_

## TL;DR — read this first

**What this is.** `vibecrafted` repository — current focus: _Runtime Integration_.

**Where you stand.** Branch `feat/runtime-integration`, dirty worktree, snapshot fresh.
Last 5 commits: `9f76009 [codex/implement] fix(runtime): centralize launcher ulimit hardening` · `3e9ea7a [claude/vc-implement] fix(spawn): read run-closure footer tokens for all agents` · `dadcbd4 [claude/vc-implement] fix(agent-stream): render gemini token line for spawn extractor`
**Scope.** `path:vibecrafted-app` -> path:vibecrafted-app (108 files, fingerprint: 916a9cd2b34c).

**Top 3 things to know before editing.**
1. Hub `vibecrafted-app/mux-agent/src/config.rs` has 13 importers — touching it = wide blast radius (of 54 ranked hubs). (LoctreeDerived)
2. 3 high-fan-in file(s) exceed threshold — review impact before edits. (LoctreeDerived)
3. Env var `APP_MACOS_DIR` is read by 1 file(s) in scope — verify before refactoring config flow. (LoctreeDerived)

**Snapshot facts.** 54 hubs · 302 idiom tag(s) · 27 dispatch edge(s) · 27 env contract(s) · 0 memory entries · 992 authority claim(s).

**What's stale.** None.

## Where You Are

### Hubs — touch = blast radius

| File | Importers | Authority |
|---|---:|---|
| `vibecrafted-app/mux-agent/src/config.rs` | 13 | LoctreeDerived |
| `vibecrafted-app/mux-agent/src/state.rs` | 12 | LoctreeDerived |
| `vibecrafted-app/mux-agent/src/scan.rs` | 10 | LoctreeDerived |
| `vibecrafted-app/tray-agent/src/types.rs` | 8 | LoctreeDerived |
| `vibecrafted-app/tui-agent/src/app.rs` | 7 | LoctreeDerived |
| `vibecrafted-app/tui-agent/src/state.rs` | 7 | LoctreeDerived |
| `vibecrafted-app/mux-agent/src/ipc/event.rs` | 6 | LoctreeDerived |
| `vibecrafted-app/tui-agent/src/launch.rs` | 6 | LoctreeDerived |
| `vibecrafted-app/tui-agent/src/mission_control.rs` | 5 | LoctreeDerived |
| `vibecrafted-app/tui-agent/src/polarize.rs` | 5 | LoctreeDerived |
| `vibecrafted-app/mux-agent/src/tray.rs` | 4 | LoctreeDerived |
| `vibecrafted-app/shell-agent/app/Vibecrafted/Bridge/vibecrafted_shell_ffi.swift` | 4 | LoctreeDerived |
| `vibecrafted-app/shell-agent/app/Vibecrafted/Views/SidebarViewController.swift` | 4 | LoctreeDerived |
| `vibecrafted-app/tui-agent/src/mux.rs` | 4 | LoctreeDerived |
| `vibecrafted-app/tui-agent/src/skills_catalog.rs` | 4 | LoctreeDerived |
| `vibecrafted-app/mux-agent/src/danger.rs` | 3 | LoctreeDerived |
| `vibecrafted-app/mux-agent/src/ipc/command.rs` | 3 | LoctreeDerived |
| `vibecrafted-app/mux-agent/src/ipc/context.rs` | 3 | LoctreeDerived |
| `vibecrafted-app/mux-agent/src/multi.rs` | 3 | LoctreeDerived |
| `vibecrafted-app/mux-agent/src/mux_gen.rs` | 3 | LoctreeDerived |
| `vibecrafted-app/mux-agent/src/runtime/mod.rs` | 3 | LoctreeDerived |
| `vibecrafted-app/shell-agent/app/Vibecrafted/Views/CanvasViewController.swift` | 3 | LoctreeDerived |
| `vibecrafted-app/shell-agent/app/Vibecrafted/main.swift` | 3 | LoctreeDerived |
| `vibecrafted-app/shell-agent/ffi/src/lib.rs` | 3 | LoctreeDerived |
| `vibecrafted-app/tray-agent/src/ipc_client.rs` | 3 | LoctreeDerived |
| `vibecrafted-app/tray-agent/src/state.rs` | 3 | LoctreeDerived |
| `vibecrafted-app/mux-agent/src/ipc/handlers.rs` | 2 | LoctreeDerived |
| `vibecrafted-app/mux-agent/src/wizard/mod.rs` | 2 | LoctreeDerived |
| `vibecrafted-app/shell-agent/app/Vibecrafted/AppDelegate.swift` | 2 | LoctreeDerived |
| `vibecrafted-app/shell-agent/app/Vibecrafted/Views/MainWindowController.swift` | 2 | LoctreeDerived |
| `vibecrafted-app/tui-agent/src/config.rs` | 2 | LoctreeDerived |
| `vibecrafted-app/mux-agent/src/ipc/mod.rs` | 1 | LoctreeDerived |
| `vibecrafted-app/mux-agent/src/ipc/server.rs` | 1 | LoctreeDerived |
| `vibecrafted-app/mux-agent/src/jsonl_bridge.rs` | 1 | LoctreeDerived |
| `vibecrafted-app/mux-agent/src/multi_tui.rs` | 1 | LoctreeDerived |
| `vibecrafted-app/mux-agent/src/runtime/client.rs` | 1 | LoctreeDerived |
| `vibecrafted-app/mux-agent/src/runtime/heartbeat.rs` | 1 | LoctreeDerived |
| `vibecrafted-app/mux-agent/src/runtime/proxy.rs` | 1 | LoctreeDerived |
| `vibecrafted-app/mux-agent/src/runtime/server.rs` | 1 | LoctreeDerived |
| `vibecrafted-app/mux-agent/src/runtime/status.rs` | 1 | LoctreeDerived |
| `vibecrafted-app/mux-agent/src/runtime/types.rs` | 1 | LoctreeDerived |
| `vibecrafted-app/mux-agent/src/tray_dashboard.rs` | 1 | LoctreeDerived |
| `vibecrafted-app/mux-agent/src/wizard/keys.rs` | 1 | LoctreeDerived |
| `vibecrafted-app/mux-agent/src/wizard/persist.rs` | 1 | LoctreeDerived |
| `vibecrafted-app/mux-agent/src/wizard/services.rs` | 1 | LoctreeDerived |
| `vibecrafted-app/mux-agent/src/wizard/types.rs` | 1 | LoctreeDerived |
| `vibecrafted-app/mux-agent/src/wizard/ui.rs` | 1 | LoctreeDerived |
+ 7 more, run `loct context --full` for full data

### Cycles

- not_measured (run `loct cycles` for current measurement) (LoctreeDerived)

### Recently active surface (last 24h)

- `.gitignore` (RepoVerified)
- `Makefile` (RepoVerified)
- `config/zellij/layouts/operator.kdl` (RepoVerified)
- `runtime/scripts/common.sh` (RepoVerified)
- `runtime/scripts/lib/launcher.sh` (RepoVerified)
- `runtime/scripts/lib/ulimits.sh` (RepoVerified)
- `runtime/scripts/lib/zellij.sh` (RepoVerified)
- `runtime/shell/lib/dashboard.sh` (RepoVerified)
- `runtime/shell/lib/ulimits.sh` (RepoVerified)
- `runtime/shell/lib/zellij.sh` (RepoVerified)

### Risk metrics

- dead_exports: not_measured (use-graph counts `pub use` re-exports as live — known limitation; run `loct dead` for current count) (RepoVerified)
- twins: not_measured (run `loct twins` for a context-classified pass) (RepoVerified)
- cache_scope: `Scoped("916a9cd2b34c")` (RepoVerified)
- high_fan_in: 3 files over threshold 10 (LoctreeDerived)

## What's Live

### Idiom tag clusters (top 10 by hit count)

- `idiom:rust-inherent-impl` (152 hits) — method-call reachability via inherent impls (SemanticGuess)
- `idiom:rust-reexport` (93 hits) — public re-export surface (SemanticGuess)
- `idiom:make-target` (45 hits) — .PHONY Make workflow targets (LoctreeDerived)
- `idiom:shell-helper` (2 hits) — info/warn shell helpers (LoctreeDerived)

### Dispatch edges (top 5 by reach)

- `vibecrafted-app/Makefile`:6 → `cargo` (`recipe_shell_call`) (LoctreeDerived)
- `vibecrafted-app/Makefile`:50 → `printf` (`recipe_shell_call`) (LoctreeDerived)
- `vibecrafted-app/mux-agent/Makefile`:55 → `cargo` (`recipe_shell_call`) (LoctreeDerived)
- `vibecrafted-app/mux-agent/Makefile`:106 → `mkdir` (`recipe_shell_call`) (LoctreeDerived)
- `vibecrafted-app/mux-agent/Makefile`:22 → `printf` (`recipe_shell_call`) (LoctreeDerived)

### Env contracts (vars used in scope)

- `APP_MACOS_DIR` — used in 1 file(s) (LoctreeDerived)
- `APP_PATH` — used in 2 file(s) (LoctreeDerived)
- `BASH_SOURCE` — used in 66 file(s) (LoctreeDerived)
- `BRIDGE_DIR` — used in 1 file(s) (LoctreeDerived)
- `BUILD_DIR` — used in 1 file(s) (LoctreeDerived)
- `CARGO_BIN` — used in 1 file(s) (LoctreeDerived)
- `CARGO_HOME` — used in 1 file(s) (LoctreeDerived)
- `CONTENTS_FOLDER_PATH` — used in 1 file(s) (LoctreeDerived)
- `DMG_NAME` — used in 1 file(s) (LoctreeDerived)
- `DMG_STAGING` — used in 1 file(s) (LoctreeDerived)

### Reachability (top 5 widely-reached symbols)

- `vibecrafted-app/Makefile::app` — reason: `phony_make_target` (LoctreeDerived)
- `vibecrafted-app/Makefile::app-debug` — reason: `phony_make_target` (LoctreeDerived)
- `vibecrafted-app/Makefile::bindings` — reason: `phony_make_target` (LoctreeDerived)
- `vibecrafted-app/Makefile::check` — reason: `phony_make_target` (LoctreeDerived)
- `vibecrafted-app/Makefile::clean` — reason: `phony_make_target` (LoctreeDerived)

## Memory

_AICX overlay disabled by `--no-aicx`; memory overlay intentionally omitted._ (RepoVerified)

## Action

### Power Path (suggested next steps)

- `loct slice vibecrafted-app/AGENTS.md`: Slice this file to inspect its direct dependencies and immediate consumers before editing.
- `loct follow`: Pursue unified structural signals (dead exports, import cycles, twins) to ensure health.
- `loct slice vibecrafted-app/Cargo.toml`: Slice this file to inspect its direct dependencies and immediate consumers before editing.
- `loct slice vibecrafted-app/Makefile`: Slice this file to inspect its direct dependencies and immediate consumers before editing.
- `loct body .PHONY`: View the definition body of symbol '.PHONY' to understand its implementation structure.
- `loct find --literal .PHONY`: Execute a literal exact-identifier scan for '.PHONY' to find exact matches across the codebase.
- `loct occurrences .PHONY`: Perform a literal boundary-sensitive occurrences scan for '.PHONY' to locate all references.
- `loct slice vibecrafted-app/README.md`: Slice this file to inspect its direct dependencies and immediate consumers before editing.
- `loct slice vibecrafted-app/docs/plans/PLAN_22_NEXT_OPERATOR_MISSION_CONTROL.md`: Slice this file to inspect its direct dependencies and immediate consumers before editing.
- `loct slice vibecrafted-app/docs/plans/PLAN_23_AGENT_OPERATOR_DASHBOARD.md`: Slice this file to inspect its direct dependencies and immediate consumers before editing.
- `loct slice vibecrafted-app/mux-agent/AI_README.md`: Slice this file to inspect its direct dependencies and immediate consumers before editing.
- `loct slice vibecrafted-app/mux-agent/CHANGELOG.md`: Slice this file to inspect its direct dependencies and immediate consumers before editing.
- `loct slice vibecrafted-app/mux-agent/Cargo.toml`: Slice this file to inspect its direct dependencies and immediate consumers before editing.
- `loct slice vibecrafted-app/mux-agent/Makefile`: Slice this file to inspect its direct dependencies and immediate consumers before editing.
- `loct body SHELL`: View the definition body of symbol 'SHELL' to understand its implementation structure.
- `loct find --literal SHELL`: Execute a literal exact-identifier scan for 'SHELL' to find exact matches across the codebase.
- `loct occurrences SHELL`: Perform a literal boundary-sensitive occurrences scan for 'SHELL' to locate all references.
- `loct slice vibecrafted-app/mux-agent/README.md`: Slice this file to inspect its direct dependencies and immediate consumers before editing.
- `loct slice vibecrafted-app/mux-agent/docs/WIZARD.md`: Slice this file to inspect its direct dependencies and immediate consumers before editing.
- `loct slice vibecrafted-app/mux-agent/docs/dev/guidelines.md`: Slice this file to inspect its direct dependencies and immediate consumers before editing.
- `loct slice vibecrafted-app/mux-agent/docs/integration.md`: Slice this file to inspect its direct dependencies and immediate consumers before editing.
- `loct slice vibecrafted-app/mux-agent/docs/vc-agents-client-discovery-plan.md`: Slice this file to inspect its direct dependencies and immediate consumers before editing.
- `loct slice vibecrafted-app/mux-agent/src/bin/rmcp-mux-proxy.rs`: Slice this file to inspect its direct dependencies and immediate consumers before editing.
- `loct slice vibecrafted-app/mux-agent/src/bin/rmcp-mux.rs`: Slice this file to inspect its direct dependencies and immediate consumers before editing.
- `loct slice vibecrafted-app/mux-agent/src/config.rs`: Slice this file to inspect its direct dependencies and immediate consumers before editing.
- `loct impact vibecrafted-app/mux-agent/src/config.rs`: Assess the transitive blast radius and downstream consumers of this file before modifying.
- `loct body expand_path`: View the definition body of symbol 'expand_path' to understand its implementation structure.
- `loct find --literal expand_path`: Execute a literal exact-identifier scan for 'expand_path' to find exact matches across the codebase.
- `loct occurrences expand_path`: Perform a literal boundary-sensitive occurrences scan for 'expand_path' to locate all references.
- `loct slice vibecrafted-app/mux-agent/src/danger.rs`: Slice this file to inspect its direct dependencies and immediate consumers before editing.
- `loct impact vibecrafted-app/mux-agent/src/danger.rs`: Assess the transitive blast radius and downstream consumers of this file before modifying.
- `loct body plan_danger_rewrite`: View the definition body of symbol 'plan_danger_rewrite' to understand its implementation structure.
- `loct find --literal plan_danger_rewrite`: Execute a literal exact-identifier scan for 'plan_danger_rewrite' to find exact matches across the codebase.
- `loct occurrences plan_danger_rewrite`: Perform a literal boundary-sensitive occurrences scan for 'plan_danger_rewrite' to locate all references.
- `loct slice vibecrafted-app/mux-agent/src/ipc/command.rs`: Slice this file to inspect its direct dependencies and immediate consumers before editing.
- `loct impact vibecrafted-app/mux-agent/src/ipc/command.rs`: Assess the transitive blast radius and downstream consumers of this file before modifying.
- `loct body VerifyResult`: View the definition body of symbol 'VerifyResult' to understand its implementation structure.
- `loct find --literal VerifyResult`: Execute a literal exact-identifier scan for 'VerifyResult' to find exact matches across the codebase.
- `loct occurrences VerifyResult`: Perform a literal boundary-sensitive occurrences scan for 'VerifyResult' to locate all references.
- `loct slice vibecrafted-app/mux-agent/src/ipc/context.rs`: Slice this file to inspect its direct dependencies and immediate consumers before editing.
- `loct impact vibecrafted-app/mux-agent/src/ipc/context.rs`: Assess the transitive blast radius and downstream consumers of this file before modifying.
- `loct body new`: View the definition body of symbol 'new' to understand its implementation structure.
- `loct find --literal new`: Execute a literal exact-identifier scan for 'new' to find exact matches across the codebase.
- `loct occurrences new`: Perform a literal boundary-sensitive occurrences scan for 'new' to locate all references.
- `loct slice vibecrafted-app/mux-agent/src/ipc/event.rs`: Slice this file to inspect its direct dependencies and immediate consumers before editing.
- `loct impact vibecrafted-app/mux-agent/src/ipc/event.rs`: Assess the transitive blast radius and downstream consumers of this file before modifying.
- `loct body IpcEvent`: View the definition body of symbol 'IpcEvent' to understand its implementation structure.
- `loct find --literal IpcEvent`: Execute a literal exact-identifier scan for 'IpcEvent' to find exact matches across the codebase.
- `loct occurrences IpcEvent`: Perform a literal boundary-sensitive occurrences scan for 'IpcEvent' to locate all references.
- `loct slice vibecrafted-app/mux-agent/src/ipc/handlers.rs`: Slice this file to inspect its direct dependencies and immediate consumers before editing.
- `loct impact vibecrafted-app/mux-agent/src/ipc/handlers.rs`: Assess the transitive blast radius and downstream consumers of this file before modifying.
- `loct body handle_command`: View the definition body of symbol 'handle_command' to understand its implementation structure.
- `loct find --literal handle_command`: Execute a literal exact-identifier scan for 'handle_command' to find exact matches across the codebase.
- `loct occurrences handle_command`: Perform a literal boundary-sensitive occurrences scan for 'handle_command' to locate all references.
- `loct slice vibecrafted-app/mux-agent/src/ipc/mod.rs`: Slice this file to inspect its direct dependencies and immediate consumers before editing.
- `loct impact vibecrafted-app/mux-agent/src/ipc/mod.rs`: Assess the transitive blast radius and downstream consumers of this file before modifying.
- `loct body ClientKind`: View the definition body of symbol 'ClientKind' to understand its implementation structure.
- `loct find --literal ClientKind`: Execute a literal exact-identifier scan for 'ClientKind' to find exact matches across the codebase.
- `loct occurrences ClientKind`: Perform a literal boundary-sensitive occurrences scan for 'ClientKind' to locate all references.
- `loct slice vibecrafted-app/mux-agent/src/ipc/server.rs`: Slice this file to inspect its direct dependencies and immediate consumers before editing.
- `loct impact vibecrafted-app/mux-agent/src/ipc/server.rs`: Assess the transitive blast radius and downstream consumers of this file before modifying.
- `loct body socket_path`: View the definition body of symbol 'socket_path' to understand its implementation structure.
- `loct find --literal socket_path`: Execute a literal exact-identifier scan for 'socket_path' to find exact matches across the codebase.
- `loct occurrences socket_path`: Perform a literal boundary-sensitive occurrences scan for 'socket_path' to locate all references.
- `loct slice vibecrafted-app/mux-agent/src/jsonl_bridge.rs`: Slice this file to inspect its direct dependencies and immediate consumers before editing.
- `loct impact vibecrafted-app/mux-agent/src/jsonl_bridge.rs`: Assess the transitive blast radius and downstream consumers of this file before modifying.
- `loct body run_jsonl_bridge`: View the definition body of symbol 'run_jsonl_bridge' to understand its implementation structure.
- `loct find --literal run_jsonl_bridge`: Execute a literal exact-identifier scan for 'run_jsonl_bridge' to find exact matches across the codebase.
- `loct occurrences run_jsonl_bridge`: Perform a literal boundary-sensitive occurrences scan for 'run_jsonl_bridge' to locate all references.
- `loct slice vibecrafted-app/mux-agent/src/lib.rs`: Slice this file to inspect its direct dependencies and immediate consumers before editing.
- `loct body CliOptions`: View the definition body of symbol 'CliOptions' to understand its implementation structure.
- `loct find --literal CliOptions`: Execute a literal exact-identifier scan for 'CliOptions' to find exact matches across the codebase.
- `loct occurrences CliOptions`: Perform a literal boundary-sensitive occurrences scan for 'CliOptions' to locate all references.
- `loct slice vibecrafted-app/mux-agent/src/main.rs`: Slice this file to inspect its direct dependencies and immediate consumers before editing.
- `loct slice vibecrafted-app/mux-agent/src/multi.rs`: Slice this file to inspect its direct dependencies and immediate consumers before editing.
- `loct impact vibecrafted-app/mux-agent/src/multi.rs`: Assess the transitive blast radius and downstream consumers of this file before modifying.
- `loct slice vibecrafted-app/mux-agent/src/multi_tui.rs`: Slice this file to inspect its direct dependencies and immediate consumers before editing.
- `loct impact vibecrafted-app/mux-agent/src/multi_tui.rs`: Assess the transitive blast radius and downstream consumers of this file before modifying.
- `loct slice vibecrafted-app/mux-agent/src/mux_gen.rs`: Slice this file to inspect its direct dependencies and immediate consumers before editing.
- `loct impact vibecrafted-app/mux-agent/src/mux_gen.rs`: Assess the transitive blast radius and downstream consumers of this file before modifying.
- `loct body default_mux_dir`: View the definition body of symbol 'default_mux_dir' to understand its implementation structure.
- `loct find --literal default_mux_dir`: Execute a literal exact-identifier scan for 'default_mux_dir' to find exact matches across the codebase.
- `loct occurrences default_mux_dir`: Perform a literal boundary-sensitive occurrences scan for 'default_mux_dir' to locate all references.
- `loct slice vibecrafted-app/mux-agent/src/runtime/client.rs`: Slice this file to inspect its direct dependencies and immediate consumers before editing.
- `loct impact vibecrafted-app/mux-agent/src/runtime/client.rs`: Assess the transitive blast radius and downstream consumers of this file before modifying.
- `loct body update_queue_depth`: View the definition body of symbol 'update_queue_depth' to understand its implementation structure.
- `loct find --literal update_queue_depth`: Execute a literal exact-identifier scan for 'update_queue_depth' to find exact matches across the codebase.
- `loct occurrences update_queue_depth`: Perform a literal boundary-sensitive occurrences scan for 'update_queue_depth' to locate all references.
- `loct slice vibecrafted-app/mux-agent/src/runtime/heartbeat.rs`: Slice this file to inspect its direct dependencies and immediate consumers before editing.
- `loct impact vibecrafted-app/mux-agent/src/runtime/heartbeat.rs`: Assess the transitive blast radius and downstream consumers of this file before modifying.
- `loct slice vibecrafted-app/mux-agent/src/runtime/mod.rs`: Slice this file to inspect its direct dependencies and immediate consumers before editing.
- `loct impact vibecrafted-app/mux-agent/src/runtime/mod.rs`: Assess the transitive blast radius and downstream consumers of this file before modifying.
- `loct body HeartbeatConfig`: View the definition body of symbol 'HeartbeatConfig' to understand its implementation structure.
- `loct find --literal HeartbeatConfig`: Execute a literal exact-identifier scan for 'HeartbeatConfig' to find exact matches across the codebase.
- `loct occurrences HeartbeatConfig`: Perform a literal boundary-sensitive occurrences scan for 'HeartbeatConfig' to locate all references.
+ section truncated, run `loct context --full` for full data
## Authority Index

_992 total claims tagged with provenance._

- **RepoVerified** (11) — AST + git state derivation
- **LoctreeDerived** (438) — snapshot edges + idiom catalogs
- **AicxOperator** (0) — operator decisions / intents from AICX
- **AicxAgent** (0) — agent outcomes (verify before propagating)
- **AicxFailure** (0) — anti-recommendations (avoid repeating)
- **SemanticGuess** (543) — heuristic only, low trust
- **StaleOrUnknown** (0) — explicit "we don't know"


---

*`loct context` rendered in 10064ms · sections: where=79L · live=38L · memory=4L · `--full` for full ContextPack data · `--file <X>` to narrow scope*
