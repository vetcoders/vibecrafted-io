# Loctree Context · vibecrafted @ feat/runtime-integration · 2026-06-15T14:31:03.886361Z

_710 files · 468 import edges · snapshot fresh · dirty worktree_

## TL;DR — read this first

**What this is.** `vibecrafted` repository — current focus: _Runtime Integration_.

**Where you stand.** Branch `feat/runtime-integration`, dirty worktree, snapshot fresh.
Last 5 commits: `9f76009 [codex/implement] fix(runtime): centralize launcher ulimit hardening` · `3e9ea7a [claude/vc-implement] fix(spawn): read run-closure footer tokens for all agents` · `dadcbd4 [claude/vc-implement] fix(agent-stream): render gemini token line for spawn extractor`
**Scope.** `path:vibecrafted-core` -> path:vibecrafted-core (92 files, fingerprint: f1835573938e).

**Top 3 things to know before editing.**
1. Hub `vibecrafted-core/vibecrafted_core/__init__.py` has 24 importers — touching it = wide blast radius (of 38 ranked hubs). (LoctreeDerived)
2. 3 high-fan-in file(s) exceed threshold — review impact before edits. (LoctreeDerived)
3. Env var `AICX_RECALL_CHUNK_LINES` is read by 1 file(s) in scope — verify before refactoring config flow. (LoctreeDerived)

**Snapshot facts.** 38 hubs · 10 idiom tag(s) · 2 dispatch edge(s) · 36 env contract(s) · 0 memory entries · 129 authority claim(s).

**What's stale.** None.

## Where You Are

### Hubs — touch = blast radius

| File | Importers | Authority |
|---|---:|---|
| `vibecrafted-core/vibecrafted_core/__init__.py` | 24 | LoctreeDerived |
| `vibecrafted-core/vibecrafted_core/wrappers.py` | 13 | LoctreeDerived |
| `vibecrafted-core/vibecrafted_core/dispatch/model.py` | 10 | LoctreeDerived |
| `vibecrafted-core/vibecrafted_core/runtime_paths.py` | 9 | LoctreeDerived |
| `vibecrafted-core/vibecrafted_core/spawn.py` | 8 | LoctreeDerived |
| `vibecrafted-core/vibecrafted_core/control_plane.py` | 7 | LoctreeDerived |
| `vibecrafted-core/vibecrafted_core/events.py` | 7 | LoctreeDerived |
| `vibecrafted-core/vibecrafted_core/dispatch/schema.py` | 6 | LoctreeDerived |
| `vibecrafted-core/vibecrafted_core/workflow.py` | 6 | LoctreeDerived |
| `vibecrafted-core/vibecrafted_core/sandbox/policy.py` | 5 | LoctreeDerived |
| `vibecrafted-core/vibecrafted_core/artifacts.py` | 4 | LoctreeDerived |
| `vibecrafted-core/vibecrafted_core/dispatch/doctor.py` | 4 | LoctreeDerived |
| `vibecrafted-core/vibecrafted_core/sandbox/__init__.py` | 4 | LoctreeDerived |
| `vibecrafted-core/vibecrafted_core/supervisor_async.py` | 4 | LoctreeDerived |
| `vibecrafted-core/vibecrafted_core/agent_dispatch.py` | 3 | LoctreeDerived |
| `vibecrafted-core/vibecrafted_core/agent_stream.py` | 3 | LoctreeDerived |
| `vibecrafted-core/vibecrafted_core/dispatch/cli.py` | 3 | LoctreeDerived |
| `vibecrafted-core/vibecrafted_core/dispatch/supervisor.py` | 3 | LoctreeDerived |
| `vibecrafted-core/vibecrafted_core/dispatch/verify.py` | 3 | LoctreeDerived |
| `vibecrafted-core/vibecrafted_core/lifecycle.py` | 3 | LoctreeDerived |
| `vibecrafted-core/vibecrafted_core/sandbox/msbserver_lifecycle.py` | 3 | LoctreeDerived |
| `vibecrafted-core/vibecrafted_core/ui.py` | 3 | LoctreeDerived |
| `vibecrafted-core/vibecrafted_core/cli.py` | 2 | LoctreeDerived |
| `vibecrafted-core/vibecrafted_core/compact_hooks.py` | 2 | LoctreeDerived |
| `vibecrafted-core/vibecrafted_core/cron.py` | 2 | LoctreeDerived |
| `vibecrafted-core/vibecrafted_core/dispatcher.py` | 2 | LoctreeDerived |
| `vibecrafted-core/vibecrafted_core/loop.py` | 2 | LoctreeDerived |
| `vibecrafted-core/vibecrafted_core/ship.py` | 2 | LoctreeDerived |
| `vibecrafted-core/vibecrafted_core/workflows/__init__.py` | 2 | LoctreeDerived |
| `vibecrafted-core/vibecrafted_core/workflows/model.py` | 2 | LoctreeDerived |
| `vibecrafted-core/vibecrafted_core/capabilities.py` | 1 | LoctreeDerived |
| `vibecrafted-core/vibecrafted_core/dispatch/__init__.py` | 1 | LoctreeDerived |
| `vibecrafted-core/vibecrafted_core/dispatch_contract.py` | 1 | LoctreeDerived |
| `vibecrafted-core/vibecrafted_core/doctor.py` | 1 | LoctreeDerived |
| `vibecrafted-core/vibecrafted_core/git.py` | 1 | LoctreeDerived |
| `vibecrafted-core/vibecrafted_core/sandbox/adapter.py` | 1 | LoctreeDerived |
| `vibecrafted-core/vibecrafted_core/workflow_runtime.py` | 1 | LoctreeDerived |
| `vibecrafted-core/vibecrafted_core/workflows/registry.py` | 1 | LoctreeDerived |

### Cycles

- not_measured (run `loct cycles` for current measurement) (LoctreeDerived)

### Recently active surface (last 24h)

- `.gitignore` (RepoVerified)
- `Makefile` (RepoVerified)
- `config/zellij/layouts/operator.kdl` (RepoVerified)
- `runtime/scripts/common.sh` (RepoVerified)
- `runtime/scripts/lib/launcher.sh` (RepoVerified)
- `runtime/scripts/lib/ulimits.sh` (RepoVerified)
- `runtime/scripts/lib/zellij.sh` (RepoVerified)
- `runtime/shell/lib/dashboard.sh` (RepoVerified)
- `runtime/shell/lib/ulimits.sh` (RepoVerified)
- `runtime/shell/lib/zellij.sh` (RepoVerified)

### Risk metrics

- dead_exports: not_measured (use-graph counts `pub use` re-exports as live — known limitation; run `loct dead` for current count) (RepoVerified)
- twins: not_measured (run `loct twins` for a context-classified pass) (RepoVerified)
- cache_scope: `Scoped("f1835573938e")` (RepoVerified)
- high_fan_in: 3 files over threshold 10 (LoctreeDerived)

## What's Live

### Idiom tag clusters (top 10 by hit count)

- `idiom:shell-helper` (9 hits) — main shell helpers (LoctreeDerived)

### Dispatch edges (top 5 by reach)

- `vibecrafted-core/tests/test_sandbox_adapter.py`:72 → `fake_microsandbox` (`event_handler`) (LoctreeDerived)
- `vibecrafted-core/tests/test_ui.py`:12 → `_no_color_by_default` (`event_handler`) (LoctreeDerived)

### Env contracts (vars used in scope)

- `AICX_RECALL_CHUNK_LINES` — used in 1 file(s) (LoctreeDerived)
- `AICX_RECALL_DEDUP` — used in 1 file(s) (LoctreeDerived)
- `AICX_RECALL_STRIP_SKILLS` — used in 1 file(s) (LoctreeDerived)
- `CLAUDE_CODE_SESSION_ID` — used in 6 file(s) (LoctreeDerived)
- `CLAUDE_PROJECT_DIR` — used in 1 file(s) (LoctreeDerived)
- `CODEX_HOME` — used in 1 file(s) (LoctreeDerived)
- `CODEX_PROJECT_DIR` — used in 1 file(s) (LoctreeDerived)
- `CODEX_SESSIONS_DIR` — used in 1 file(s) (LoctreeDerived)
- `CODEX_SESSION_ID` — used in 4 file(s) (LoctreeDerived)
- `MICROSANDBOX_PYTHON_SDK` — used in 1 file(s) (LoctreeDerived)

### Reachability (top 5 widely-reached symbols)

- `vibecrafted-core/tests/test_sandbox_adapter.py::fake_microsandbox` — reason: `dispatch_handler:event_handler:vibecrafted-core/tests/test_sandbox_adapter.py` (LoctreeDerived)
- `vibecrafted-core/vibecrafted_core/cli.py::main` — reason: `idiom_runtime_role:primary_entrypoint` (SemanticGuess)
- `vibecrafted-core/vibecrafted_core/compact_hooks.py::main` — reason: `idiom_runtime_role:primary_entrypoint` (SemanticGuess)
- `vibecrafted-core/vibecrafted_core/cron.py::main` — reason: `idiom_runtime_role:primary_entrypoint` (SemanticGuess)
- `vibecrafted-core/vibecrafted_core/dispatch/cli.py::main` — reason: `idiom_runtime_role:primary_entrypoint` (SemanticGuess)

## Memory

_AICX overlay disabled by `--no-aicx`; memory overlay intentionally omitted._ (RepoVerified)

## Action

### Power Path (suggested next steps)

- `loct slice vibecrafted-core/README.md`: Slice this file to inspect its direct dependencies and immediate consumers before editing.
- `loct follow`: Pursue unified structural signals (dead exports, import cycles, twins) to ensure health.
- `loct slice vibecrafted-core/pyproject.toml`: Slice this file to inspect its direct dependencies and immediate consumers before editing.
- `loct slice vibecrafted-core/tests/__init__.py`: Slice this file to inspect its direct dependencies and immediate consumers before editing.
- `loct slice vibecrafted-core/tests/conftest.py`: Slice this file to inspect its direct dependencies and immediate consumers before editing.
- `loct slice vibecrafted-core/tests/dispatch/fixtures/invalid-no-verify.dispatch.toml`: Slice this file to inspect its direct dependencies and immediate consumers before editing.
- `loct slice vibecrafted-core/tests/dispatch/fixtures/invalid/concurrency-without-policy.dispatch.toml`: Slice this file to inspect its direct dependencies and immediate consumers before editing.
- `loct slice vibecrafted-core/tests/dispatch/fixtures/invalid/duplicate-id.dispatch.toml`: Slice this file to inspect its direct dependencies and immediate consumers before editing.
- `loct slice vibecrafted-core/tests/dispatch/fixtures/invalid/hard-stop-no-verify.dispatch.toml`: Slice this file to inspect its direct dependencies and immediate consumers before editing.
- `loct slice vibecrafted-core/tests/dispatch/fixtures/invalid/hard-stop-push.dispatch.toml`: Slice this file to inspect its direct dependencies and immediate consumers before editing.
- `loct slice vibecrafted-core/tests/dispatch/fixtures/invalid/hard-stop-release.dispatch.toml`: Slice this file to inspect its direct dependencies and immediate consumers before editing.
- `loct slice vibecrafted-core/tests/dispatch/fixtures/invalid/missing-meta-repo.dispatch.toml`: Slice this file to inspect its direct dependencies and immediate consumers before editing.
- `loct slice vibecrafted-core/tests/dispatch/fixtures/invalid/missing-prompt-and-brief.dispatch.toml`: Slice this file to inspect its direct dependencies and immediate consumers before editing.
- `loct slice vibecrafted-core/tests/dispatch/fixtures/invalid/missing-verify.dispatch.toml`: Slice this file to inspect its direct dependencies and immediate consumers before editing.
- `loct slice vibecrafted-core/tests/dispatch/fixtures/invalid/read-without-mutation.dispatch.toml`: Slice this file to inspect its direct dependencies and immediate consumers before editing.
- `loct slice vibecrafted-core/tests/dispatch/fixtures/invalid/unknown-matcher.dispatch.toml`: Slice this file to inspect its direct dependencies and immediate consumers before editing.
- `loct slice vibecrafted-core/tests/dispatch/fixtures/invalid/unknown-phase.dispatch.toml`: Slice this file to inspect its direct dependencies and immediate consumers before editing.
- `loct slice vibecrafted-core/tests/dispatch/fixtures/invalid/unknown-schema.dispatch.toml`: Slice this file to inspect its direct dependencies and immediate consumers before editing.
- `loct slice vibecrafted-core/tests/dispatch/fixtures/invalid/unknown-workflow.dispatch.toml`: Slice this file to inspect its direct dependencies and immediate consumers before editing.
- `loct slice vibecrafted-core/tests/dispatch/fixtures/invalid/unreadable-brief.dispatch.toml`: Slice this file to inspect its direct dependencies and immediate consumers before editing.
- `loct slice vibecrafted-core/tests/dispatch/fixtures/legacy-stage0-read-no-edit.dispatch.toml`: Slice this file to inspect its direct dependencies and immediate consumers before editing.
- `loct slice vibecrafted-core/tests/dispatch/fixtures/minimal.dispatch.toml`: Slice this file to inspect its direct dependencies and immediate consumers before editing.
- `loct slice vibecrafted-core/tests/dispatch/fixtures/observational-read.dispatch.toml`: Slice this file to inspect its direct dependencies and immediate consumers before editing.
- `loct slice vibecrafted-core/tests/dispatch/fixtures/stage0-brief.md`: Slice this file to inspect its direct dependencies and immediate consumers before editing.
- `loct slice vibecrafted-core/tests/dispatch/fixtures/stage0.dispatch.toml`: Slice this file to inspect its direct dependencies and immediate consumers before editing.
- `loct slice vibecrafted-core/tests/dispatch/test_cli.py`: Slice this file to inspect its direct dependencies and immediate consumers before editing.
- `loct slice vibecrafted-core/tests/dispatch/test_doctor.py`: Slice this file to inspect its direct dependencies and immediate consumers before editing.
- `loct body test_dispatch_doctor_rejects_design_refusal_fixtures`: View the definition body of symbol 'test_dispatch_doctor_rejects_design_refusal_fixtures' to understand its implementation structure.
- `loct find --literal test_dispatch_doctor_rejects_design_refusal_fixtures`: Execute a literal exact-identifier scan for 'test_dispatch_doctor_rejects_design_refusal_fixtures' to find exact matches across the codebase.
- `loct occurrences test_dispatch_doctor_rejects_design_refusal_fixtures`: Perform a literal boundary-sensitive occurrences scan for 'test_dispatch_doctor_rejects_design_refusal_fixtures' to locate all references.
- `loct slice vibecrafted-core/tests/dispatch/test_schema.py`: Slice this file to inspect its direct dependencies and immediate consumers before editing.
- `loct body test_minimal_fixture_parses_into_typed_model`: View the definition body of symbol 'test_minimal_fixture_parses_into_typed_model' to understand its implementation structure.
- `loct find --literal test_minimal_fixture_parses_into_typed_model`: Execute a literal exact-identifier scan for 'test_minimal_fixture_parses_into_typed_model' to find exact matches across the codebase.
- `loct occurrences test_minimal_fixture_parses_into_typed_model`: Perform a literal boundary-sensitive occurrences scan for 'test_minimal_fixture_parses_into_typed_model' to locate all references.
- `loct slice vibecrafted-core/tests/dispatch/test_supervisor.py`: Slice this file to inspect its direct dependencies and immediate consumers before editing.
- `loct body FakeCell`: View the definition body of symbol 'FakeCell' to understand its implementation structure.
- `loct find --literal FakeCell`: Execute a literal exact-identifier scan for 'FakeCell' to find exact matches across the codebase.
- `loct occurrences FakeCell`: Perform a literal boundary-sensitive occurrences scan for 'FakeCell' to locate all references.
- `loct slice vibecrafted-core/tests/dispatch/test_verify.py`: Slice this file to inspect its direct dependencies and immediate consumers before editing.
- `loct body make_cut`: View the definition body of symbol 'make_cut' to understand its implementation structure.
- `loct find --literal make_cut`: Execute a literal exact-identifier scan for 'make_cut' to find exact matches across the codebase.
- `loct occurrences make_cut`: Perform a literal boundary-sensitive occurrences scan for 'make_cut' to locate all references.
- `loct slice vibecrafted-core/tests/test_agent_stream.py`: Slice this file to inspect its direct dependencies and immediate consumers before editing.
- `loct body test_agent_stream_parser_extracts_claude_session_usage_cost_and_text`: View the definition body of symbol 'test_agent_stream_parser_extracts_claude_session_usage_cost_and_text' to understand its implementation structure.
- `loct find --literal test_agent_stream_parser_extracts_claude_session_usage_cost_and_text`: Execute a literal exact-identifier scan for 'test_agent_stream_parser_extracts_claude_session_usage_cost_and_text' to find exact matches across the codebase.
- `loct occurrences test_agent_stream_parser_extracts_claude_session_usage_cost_and_text`: Perform a literal boundary-sensitive occurrences scan for 'test_agent_stream_parser_extracts_claude_session_usage_cost_and_text' to locate all references.
- `loct slice vibecrafted-core/tests/test_agy_junie_pipeline.py`: Slice this file to inspect its direct dependencies and immediate consumers before editing.
- `loct body test_workflow_launch_spec_accepts_agy_junie_and_grok`: View the definition body of symbol 'test_workflow_launch_spec_accepts_agy_junie_and_grok' to understand its implementation structure.
- `loct find --literal test_workflow_launch_spec_accepts_agy_junie_and_grok`: Execute a literal exact-identifier scan for 'test_workflow_launch_spec_accepts_agy_junie_and_grok' to find exact matches across the codebase.
- `loct occurrences test_workflow_launch_spec_accepts_agy_junie_and_grok`: Perform a literal boundary-sensitive occurrences scan for 'test_workflow_launch_spec_accepts_agy_junie_and_grok' to locate all references.
- `loct slice vibecrafted-core/tests/test_aicx_sync.py`: Slice this file to inspect its direct dependencies and immediate consumers before editing.
- `loct body test_authority_canonical_names`: View the definition body of symbol 'test_authority_canonical_names' to understand its implementation structure.
- `loct find --literal test_authority_canonical_names`: Execute a literal exact-identifier scan for 'test_authority_canonical_names' to find exact matches across the codebase.
- `loct occurrences test_authority_canonical_names`: Perform a literal boundary-sensitive occurrences scan for 'test_authority_canonical_names' to locate all references.
- `loct slice vibecrafted-core/tests/test_capabilities.py`: Slice this file to inspect its direct dependencies and immediate consumers before editing.
- `loct body test_probe_tool_reports_product_missing`: View the definition body of symbol 'test_probe_tool_reports_product_missing' to understand its implementation structure.
- `loct find --literal test_probe_tool_reports_product_missing`: Execute a literal exact-identifier scan for 'test_probe_tool_reports_product_missing' to find exact matches across the codebase.
- `loct occurrences test_probe_tool_reports_product_missing`: Perform a literal boundary-sensitive occurrences scan for 'test_probe_tool_reports_product_missing' to locate all references.
- `loct slice vibecrafted-core/tests/test_cli.py`: Slice this file to inspect its direct dependencies and immediate consumers before editing.
- `loct body test_root_cli_vc_help_alias_returns_help_success`: View the definition body of symbol 'test_root_cli_vc_help_alias_returns_help_success' to understand its implementation structure.
- `loct find --literal test_root_cli_vc_help_alias_returns_help_success`: Execute a literal exact-identifier scan for 'test_root_cli_vc_help_alias_returns_help_success' to find exact matches across the codebase.
- `loct occurrences test_root_cli_vc_help_alias_returns_help_success`: Perform a literal boundary-sensitive occurrences scan for 'test_root_cli_vc_help_alias_returns_help_success' to locate all references.
- `loct slice vibecrafted-core/tests/test_compact_hooks.py`: Slice this file to inspect its direct dependencies and immediate consumers before editing.
- `loct body test_precompact_extracts_conversation_and_user_only`: View the definition body of symbol 'test_precompact_extracts_conversation_and_user_only' to understand its implementation structure.
- `loct find --literal test_precompact_extracts_conversation_and_user_only`: Execute a literal exact-identifier scan for 'test_precompact_extracts_conversation_and_user_only' to find exact matches across the codebase.
- `loct occurrences test_precompact_extracts_conversation_and_user_only`: Perform a literal boundary-sensitive occurrences scan for 'test_precompact_extracts_conversation_and_user_only' to locate all references.
- `loct slice vibecrafted-core/tests/test_control_plane.py`: Slice this file to inspect its direct dependencies and immediate consumers before editing.
- `loct body test_sync_state_preserves_runtime_observe_fields`: View the definition body of symbol 'test_sync_state_preserves_runtime_observe_fields' to understand its implementation structure.
- `loct find --literal test_sync_state_preserves_runtime_observe_fields`: Execute a literal exact-identifier scan for 'test_sync_state_preserves_runtime_observe_fields' to find exact matches across the codebase.
- `loct occurrences test_sync_state_preserves_runtime_observe_fields`: Perform a literal boundary-sensitive occurrences scan for 'test_sync_state_preserves_runtime_observe_fields' to locate all references.
- `loct slice vibecrafted-core/tests/test_cron.py`: Slice this file to inspect its direct dependencies and immediate consumers before editing.
- `loct body write_state`: View the definition body of symbol 'write_state' to understand its implementation structure.
- `loct find --literal write_state`: Execute a literal exact-identifier scan for 'write_state' to find exact matches across the codebase.
- `loct occurrences write_state`: Perform a literal boundary-sensitive occurrences scan for 'write_state' to locate all references.
- `loct slice vibecrafted-core/tests/test_dispatch_contract.py`: Slice this file to inspect its direct dependencies and immediate consumers before editing.
- `loct slice vibecrafted-core/tests/test_doctor.py`: Slice this file to inspect its direct dependencies and immediate consumers before editing.
- `loct body test_installer_module_loads_source_file_without_mutating_sys_path`: View the definition body of symbol 'test_installer_module_loads_source_file_without_mutating_sys_path' to understand its implementation structure.
- `loct find --literal test_installer_module_loads_source_file_without_mutating_sys_path`: Execute a literal exact-identifier scan for 'test_installer_module_loads_source_file_without_mutating_sys_path' to find exact matches across the codebase.
- `loct occurrences test_installer_module_loads_source_file_without_mutating_sys_path`: Perform a literal boundary-sensitive occurrences scan for 'test_installer_module_loads_source_file_without_mutating_sys_path' to locate all references.
- `loct slice vibecrafted-core/tests/test_git.py`: Slice this file to inspect its direct dependencies and immediate consumers before editing.
- `loct body test_repo_full_reports_git_availability_and_commit`: View the definition body of symbol 'test_repo_full_reports_git_availability_and_commit' to understand its implementation structure.
- `loct find --literal test_repo_full_reports_git_availability_and_commit`: Execute a literal exact-identifier scan for 'test_repo_full_reports_git_availability_and_commit' to find exact matches across the codebase.
- `loct occurrences test_repo_full_reports_git_availability_and_commit`: Perform a literal boundary-sensitive occurrences scan for 'test_repo_full_reports_git_availability_and_commit' to locate all references.
- `loct slice vibecrafted-core/tests/test_loop_ship.py`: Slice this file to inspect its direct dependencies and immediate consumers before editing.
- `loct body test_loop_start_next_complete_round_trip`: View the definition body of symbol 'test_loop_start_next_complete_round_trip' to understand its implementation structure.
- `loct find --literal test_loop_start_next_complete_round_trip`: Execute a literal exact-identifier scan for 'test_loop_start_next_complete_round_trip' to find exact matches across the codebase.
- `loct occurrences test_loop_start_next_complete_round_trip`: Perform a literal boundary-sensitive occurrences scan for 'test_loop_start_next_complete_round_trip' to locate all references.
- `loct slice vibecrafted-core/tests/test_memex_client.py`: Slice this file to inspect its direct dependencies and immediate consumers before editing.
- `loct body test_load_config_pure_defaults`: View the definition body of symbol 'test_load_config_pure_defaults' to understand its implementation structure.
- `loct find --literal test_load_config_pure_defaults`: Execute a literal exact-identifier scan for 'test_load_config_pure_defaults' to find exact matches across the codebase.
- `loct occurrences test_load_config_pure_defaults`: Perform a literal boundary-sensitive occurrences scan for 'test_load_config_pure_defaults' to locate all references.
- `loct slice vibecrafted-core/tests/test_package_init.py`: Slice this file to inspect its direct dependencies and immediate consumers before editing.
- `loct body test_package_import_does_not_preload_spawn_module`: View the definition body of symbol 'test_package_import_does_not_preload_spawn_module' to understand its implementation structure.
- `loct find --literal test_package_import_does_not_preload_spawn_module`: Execute a literal exact-identifier scan for 'test_package_import_does_not_preload_spawn_module' to find exact matches across the codebase.
- `loct occurrences test_package_import_does_not_preload_spawn_module`: Perform a literal boundary-sensitive occurrences scan for 'test_package_import_does_not_preload_spawn_module' to locate all references.
+ section truncated, run `loct context --full` for full data
## Authority Index

_129 total claims tagged with provenance._

- **RepoVerified** (15) — AST + git state derivation
- **LoctreeDerived** (104) — snapshot edges + idiom catalogs
- **AicxOperator** (0) — operator decisions / intents from AICX
- **AicxAgent** (0) — agent outcomes (verify before propagating)
- **AicxFailure** (0) — anti-recommendations (avoid repeating)
- **SemanticGuess** (10) — heuristic only, low trust
- **StaleOrUnknown** (0) — explicit "we don't know"


---

*`loct context` rendered in 9504ms · sections: where=69L · live=32L · memory=4L · `--full` for full ContextPack data · `--file <X>` to narrow scope*
