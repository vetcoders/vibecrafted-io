# Loctree Context · vibecrafted @ feat/runtime-integration · 2026-06-07T23:43:55.442033Z

_617 files · 398 import edges · snapshot fresh · dirty worktree_

## TL;DR — read this first

**What this is.** `vibecrafted` repository — current focus: _Runtime Integration_.

**Where you stand.** Branch `feat/runtime-integration`, dirty worktree, snapshot fresh.
Last 5 commits: `216f180 [claude/interactive] fix(skills): add Code-Derived Application Map to vc-justdo + vc-scaffold gates` · `60b0bde [claude/interactive] fix(install): wire shell rc on every machine for one truth after install-all` · `be044ea [claude/interactive] fix(test): stage marbles_spawn.sh under runtime/scripts in fixtures`
Active intent (AICX): "{"call_id":"call_PVlRZAQz8VMdMVPB9KKyBcY3","changes":{"/Users/maciejgad/vc-workspace/vetcoders/vibecrafted/agents/scripts/lib/meta.sh":{"move_path":null,"type":"update","unified_diff":"@@ -449,3 +449,6 @@\n \"status\",\n+ \"date\",\n \"session_id\",\n+ \"artifact_stem\",\n+ \"artifact_kind\",\n \"repo_path\",\n@@ -470,2 +473,66 @@\n \n+def slug_component(value: object, fallback: str) -> str:\n+ raw = str(value or fallback)\n+ raw = re.sub(r\"[^A-Za-z0-9._-]+\", \"-\", raw)." — codex on 2026-06-05.
**Scope.** `path:vibecrafted-server` -> path:vibecrafted-server (19 files, fingerprint: de81ef8c7fa0).

**Top 3 things to know before editing.**
1. Hub `vibecrafted-server/control-core/src/model.rs` has 3 importers — touching it = wide blast radius (of 30 ranked hubs). (LoctreeDerived)
2. Worktree is dirty — auto-scope mirrors uncommitted edits, not committed state. (RepoVerified)
3. Active memory says `{"call_id":"call_PVlRZAQz8VMdMVPB9KKyBcY3","changes":{"/Users/maciejgad/vc-workspace/vetcoders/vibecrafted/agents/scripts/lib/meta.sh":{"move_path":null,"type":"update","unified_diff":"@@ -449,3 +449,6 @@\n \"status\",\n+ \"date\",\n \"session_id\",\n+ \"artifact_stem\",\n+ \"artifact_kind\",\n \"repo_path\",\n@@ -470,2 +473,66 @@\n \n+def slug_component(value: object, fallback: str) -> str:\n+ raw = str(value or fallback)\n+ raw = re.sub(r\"[^A-Za-z0-9._-]+\", \"-\", raw).` — codex on 2026-06-05. (AicxOperator)

**Snapshot facts.** 30 hubs · 67 idiom tag(s) · 0 dispatch edge(s) · 0 env contract(s) · 50 memory entries · 327 authority claim(s).

**What's stale.** None.

## Where You Are

### Hubs — touch = blast radius

| File | Importers | Authority |
|---|---:|---|
| `vibecrafted-server/control-core/src/model.rs` | 3 | LoctreeDerived |
| `vibecrafted-server/web/src/theme.rs` | 3 | LoctreeDerived |
| `vibecrafted-server/control-core/src/events.rs` | 2 | LoctreeDerived |
| `vibecrafted-server/web/src/scaffold/mod.rs` | 2 | LoctreeDerived |
| `vibecrafted-server/control-core/src/read.rs` | 1 | LoctreeDerived |
| `vibecrafted-server/control-core/src/scaffold.rs` | 1 | LoctreeDerived |
| `vibecrafted-server/web/src/app.rs` | 1 | LoctreeDerived |

### Cycles

- not_measured (run `loct cycles` for current measurement) (LoctreeDerived)

### Recently active surface (last 24h)

- `.github/workflows/portable.yml` (RepoVerified)
- `.gitignore` (RepoVerified)
- `.junie/plans/decompose-vetcoders-shell-runtime.md` (RepoVerified)
- `.loctignore` (RepoVerified)
- `CHANGELOG.md` (RepoVerified)
- `Makefile` (RepoVerified)
- `agents/scripts/install-shell.sh` (RepoVerified)
- `agents/scripts/lib/meta.sh` (RepoVerified)
- `agents/scripts/skills_sync.sh` (RepoVerified)
- `agents/shell/lib/atuin.sh` (RepoVerified)

### Risk metrics

- dead_exports: not_measured (use-graph counts `pub use` re-exports as live — known limitation; run `loct dead` for current count) (RepoVerified)
- twins: not_measured (run `loct twins` for a context-classified pass) (RepoVerified)
- cache_scope: `Scoped("de81ef8c7fa0")` (RepoVerified)
- high_fan_in: 0 over threshold 10 (LoctreeDerived)

## What's Live

### Idiom tag clusters (top 10 by hit count)

- `idiom:rust-reexport` (33 hits) — public re-export surface (SemanticGuess)
- `idiom:rust-inherent-impl` (28 hits) — method-call reachability via inherent impls (SemanticGuess)

### Dispatch edges (top 5 by reach)

- _no dispatch edges in scope_ (LoctreeDerived)

### Env contracts (vars used in scope)

- _no env vars surfaced in scope_ (LoctreeDerived)

### Reachability (top 5 widely-reached symbols)

- `vibecrafted-server/control-core/src/events.rs::new` — reason: `idiom_runtime_role:library_helper` (SemanticGuess)
- `vibecrafted-server/control-core/src/events.rs::path` — reason: `idiom_runtime_role:library_helper` (SemanticGuess)
- `vibecrafted-server/control-core/src/events.rs::read_all` — reason: `idiom_runtime_role:library_helper` (SemanticGuess)
- `vibecrafted-server/control-core/src/events.rs::read_since` — reason: `idiom_runtime_role:library_helper` (SemanticGuess)
- `vibecrafted-server/control-core/src/events.rs::tail` — reason: `idiom_runtime_role:library_helper` (SemanticGuess)

## Memory

### Recent decisions / intents / outcomes (last 168h, top by relevance)

1. `outcome` · codex · 2026-06-05 · _{"call_id":"call_PVlRZAQz8VMdMVPB9KKyBcY3","changes":{"/Users/maciejgad/vc-workspace/vetcoders/vibecrafted/agents/scripts/lib/meta.sh":{"move_path":null,"type":"update","unified_diff":"@@ -449,3 +449,6 @@\n \"status\",\n+ \"date\",\n \"session_id\",\n+ \"artifact_stem\",\n+ \"artifact_kind\",\n \"repo_path\",\n@@ -470,2 +473,66 @@\n \n+def slug_component(value: object, fallback: str) -> str:\n+ raw = str(value or fallback)\n+ raw = re.sub(r\"[^A-Za-z0-9._-]+\", \"-\", raw)._ (AicxAgent) — chunk: `chunk:2fc271d5`
2. `outcome` · codex · 2026-06-05 · _{"call_id":"call_3npU2PMx5FmmJnvU3K92GfGi","changes":{"/Users/maciejgad/vc-workspace/vetcoders/vibecrafted/agents/scripts/lib/meta.sh":{"move_path":null,"type":"update","unified_diff":"@@ -574,3 +574,6 @@\n \"status\": payload.get(\"status\", \"unknown\"),\n+ \"date\": payload.get(\"date\", \"unknown\"),\n \"session_id\": payload.get(\"session_id\") or \"unknown\",\n+ \"artifact_stem\": payload.get(\"artifact_stem\", \"unknown\"),\n+ \"artifact_kind\": payload._ (AicxAgent) — chunk: `chunk:7d8ffacb`
3. `outcome` · codex · 2026-06-05 · _{"call_id":"call_y31zrXXdMjazsEXVZr1mTVqk","changes":{"/Users/maciejgad/vc-workspace/vetcoders/vibecrafted/docs/runtime/CONTRACT.md":{"move_path":null,"type":"update","unified_diff":"@@ -150,3 +150,3 @@\n \n-Final Markdown artifact filenames SHOULD use:\n+Final Markdown artifact filenames MUST use:\n `%Y-%m-%d_<org>_<repo>_<full_session_id>-<kind>.md`\n"}},"status":"completed","stderr":"","stdout":"Success. Updated the following files:\nM docs/runtime/CONTRACT._ (AicxAgent) — chunk: `chunk:c15b5f45`
4. `outcome` · codex · 2026-06-05 · _{"completed_at":1780688474,"duration_ms":33780,"last_agent_message":"Przeczytane w całości: 5 scope contextów, 814 linii.\n\nNajważniejszy obraz:\n\n- `vibecrafted-app`: największy blast radius. Szczególnie `mux-agent/src/config.rs`, `scan.rs`, `state.rs`; realne testy Rust do odpalenia przy zmianach.\n- `vibecrafted-core`: runtime serce. `__init__.py`, `events.py`, `runtime_paths.py`, `spawn.py`, `control_plane.py`, `workflow.py` są główne punkty ryzyka._ (AicxAgent) — chunk: `chunk:48e118ea`
5. `outcome` · codex · 2026-06-05 · _{"call_id":"call_Jxj2YRqlNuRSMKBeGRMgzrr9","changes":{"/Users/maciejgad/vc-workspace/vetcoders/vibecrafted/skills/vc-operator/DISPATCH.md":{"move_path":null,"type":"update","unified_diff":"@@ -224,3 +224,3 @@\n `Authored-By: claude <agents@vetcoders.io>`, `session_id: <uuid>`,\n- `timestamp: YYYY_MMDD_HHMM_TZ`, and `runtime: <runtime>`.\n+ `time: YYYY-MM-DDTHH:MM:SS±HH:MM`, and `runtime: <runtime>`._ (AicxAgent) — chunk: `chunk:ee1abbee`
6. `outcome` · codex · 2026-06-05 · _{"call_id":"call_yw5VKW9ST4pM1a4TjNaMcj0R","changes":{"/Users/maciejgad/vc-workspace/vetcoders/vibecrafted/plans/2026-06-05-workflow-runtime-extraction.md":{"content":"---\nstatus: draft\nowner: codex\ndate: 2026-06-05\nvector: stabilize\n---\n\n# Workflow Runtime Extraction\n\n## Current State\n\nWorkflow runtime truth is split across:\n\n- `skills/<workflow>/SKILL.md`, `FLOW.md`, references, templates, and agent YAML.\n- `skills/vc-agents/shell/lib/*._ (AicxAgent) — chunk: `chunk:70c2d1cc`
7. `outcome` · codex · 2026-06-05 · _{"completed_at":1780688474,"duration_ms":33780,"last_agent_message":"Przeczytane w całości: 5 scope contextów, 814 linii.\n\nNajważniejszy obraz:\n\n- `vibecrafted-app`: największy blast radius. Szczególnie `mux-agent/src/config.rs`, `scan.rs`, `state.rs`; realne testy Rust do odpalenia przy zmianach.\n- `vibecrafted-core`: runtime serce. `__init__.py`, `events.py`, `runtime_paths.py`, `spawn.py`, `control_plane.py`, `workflow.py` są główne punkty ryzyka._ (AicxAgent) — chunk: `chunk:48e118ea`
8. `outcome` · codex · 2026-06-05 · _{"call_id":"call_PVlRZAQz8VMdMVPB9KKyBcY3","changes":{"/Users/maciejgad/vc-workspace/vetcoders/vibecrafted/agents/scripts/lib/meta.sh":{"move_path":null,"type":"update","unified_diff":"@@ -449,3 +449,6 @@\n \"status\",\n+ \"date\",\n \"session_id\",\n+ \"artifact_stem\",\n+ \"artifact_kind\",\n \"repo_path\",\n@@ -470,2 +473,66 @@\n \n+def slug_component(value: object, fallback: str) -> str:\n+ raw = str(value or fallback)\n+ raw = re.sub(r\"[^A-Za-z0-9._-]+\", \"-\", raw)._ (AicxAgent) — chunk: `chunk:2fc271d5`
9. `outcome` · codex · 2026-06-05 · _{"call_id":"call_REbyqsjtwdT3GhYZxO7hcpA8","changes":{"/Users/maciejgad/vc-workspace/vetcoders/vibecrafted/agents/scripts/lib/meta.sh":{"move_path":null,"type":"update","unified_diff":"@@ -530,3 +530,3 @@\n def move_artifact(source: pathlib.Path, target: pathlib.Path) -> pathlib.Path:\n- if not str(source) or not source.exists() or same_file(source, target):\n+ if not str(source) or not source.is_file() or same_file(source, target):\n return source\n"}},"status":"completed" …_ (AicxAgent) — chunk: `chunk:593db89b`
10. `outcome` · codex · 2026-06-05 · _{"call_id":"call_HkYTtEKA6pVP9CAAXFuJvHdk","changes":{"/Users/maciejgad/vc-workspace/vetcoders/vibecrafted/skills/vc-operator/DISPATCH_TEMPLATE.md":{"move_path":null,"type":"update","unified_diff":"@@ -179,3 +179,3 @@\n `Authored-By: {{AUTHORED_BY}}`, `session_id: <uuid>`,\n- `timestamp: YYYY_MMDD_HHMM_TZ`, and `runtime: <runtime>`.\n+ `time: YYYY-MM-DDTHH:MM:SS±HH:MM`, and `runtime: <runtime>`.\n - Do not use `Co-Authored-By:`, vendor noreply addresses …_ (AicxAgent) — chunk: `chunk:ee1abbee`
11. `outcome` · codex · 2026-06-05 · _{"call_id":"call_Zgu0iBG7LARhjX81VPejY5ZT","changes":{"/Users/maciejgad/vc-workspace/vetcoders/vibecrafted/tests/tui/test_runtime_regressions.py":{"content":"from __future__ import annotations\n\nimport os\nimport subprocess\nfrom pathlib import Path\n\nfrom scripts import vetcoders_install\n\nREPO_ROOT = Path(__file__).resolve().parents[2]\nSHELL_SH = REPO_ROOT / \"skills\" / \"vc-agents\" / \"shell\" / \"vetcoders._ (AicxAgent) — chunk: `chunk:3ec05ea4`
12. `outcome` · codex · 2026-06-05 · _{"completed_at":1780686710,"duration_ms":581217,"last_agent_message":"### Summary\n\nDowiozłem i wypchnąłem na `origin/feat/runtime-integration` commit:\n\n`1794aa2 [codex/interactive] fix(runtime): Canonicalize agent time and artifact store`\n\nCo teraz stoi jako kanon:\n\n- commit footer: `Authored-By`, `session_id`, `time: 2026-06-05T13:09:03-06:00`, `runtime`\n- `timestamp:` jest legacy i hook go odrzuca\n- hook pokazuje agentowi jak odkryć `session_id`\n- …_ (AicxAgent) — chunk: `chunk:37031c1e`
13. `outcome` · codex · 2026-06-05 · _{"call_id":"call_bblBJaGbGyWr844kizcowVhV","changes":{"/Users/maciejgad/vc-workspace/vetcoders/vibecrafted/templates/hooks/config/template.husky.env":{"move_path":null,"type":"update","unified_diff":"@@ -112,3 +112,3 @@\n # Require the full agent/runtime footer used by Vibecrafted local commits:\n-# Authored-By, session_id, timestamp, and runtime.\n+# Authored-By, session_id, time, and runtime.\n HUSKY_COMMIT_MSG_REQUIRE_AGENT_RUNTIME=1\n"}},"status":"completed","stderr":"" …_ (AicxAgent) — chunk: `chunk:c0c007e3`
14. `outcome` · codex · 2026-06-05 · _{"call_id":"call_yXexjmv8hLwkj6hI3AjCmK6m","changes":{"/Users/maciejgad/vc-workspace/vetcoders/vibecrafted/docs/runtime/CONTRACT.md":{"move_path":null,"type":"update","unified_diff":"@@ -231,3 +231,3 @@\n ```bash\n-PLAN=\"$VIBECRAFTED_ROOT/.vibecrafted/artifacts/<org>/<repo>/<YYYY_MMDD>/plans/<plan>.md\"\n+PLAN=\"$VIBECRAFTED_HOME/artifacts/<org>/<repo>/<YYYY_MMDD>/plans/<plan>.md\"\n bash $VIBECRAFTED_ROOT/agents/scripts/codex_spawn._ (AicxAgent) — chunk: `chunk:c15b5f45`
15. `outcome` · codex · 2026-06-05 · _{"call_id":"call_PVlRZAQz8VMdMVPB9KKyBcY3","changes":{"/Users/maciejgad/vc-workspace/vetcoders/vibecrafted/agents/scripts/lib/meta.sh":{"move_path":null,"type":"update","unified_diff":"@@ -449,3 +449,6 @@\n \"status\",\n+ \"date\",\n \"session_id\",\n+ \"artifact_stem\",\n+ \"artifact_kind\",\n \"repo_path\",\n@@ -470,2 +473,66 @@\n \n+def slug_component(value: object, fallback: str) -> str:\n+ raw = str(value or fallback)\n+ raw = re.sub(r\"[^A-Za-z0-9._-]+\", \"-\", raw)._ (AicxAgent) — chunk: `chunk:2fc271d5`

### Source chunk pointers

_23 unique chunk(s) reachable via `aicx open <chunk:ref>` (resolved against the operator's local aicx store; absolute paths intentionally redacted to keep this context-pack commitable)._

## Action

### Next safe commands (grounded, ≤3)

```bash
loct slice vibecrafted-server/Cargo.toml
loct impact vibecrafted-server/Cargo.toml
loct context --file vibecrafted-server/Cargo.toml
```

### Verification gates (run before any commit)

- `make test` (SemanticGuess)
- `make check` (SemanticGuess)
- `mypy .` (SemanticGuess)
- `python -m pytest` (SemanticGuess)
- `cargo test --test scaffold_artifacts` (SemanticGuess)
- `cargo test --test schema_fidelity` (SemanticGuess)

### Likely tests for current scope

- `vibecrafted-server/control-core/tests/scaffold_artifacts.rs` (LoctreeDerived)
- `vibecrafted-server/control-core/tests/schema_fidelity.rs` (LoctreeDerived)

## Authority Index

_327 total claims tagged with provenance._

- **RepoVerified** (4) — AST + git state derivation
- **LoctreeDerived** (143) — snapshot edges + idiom catalogs
- **AicxOperator** (0) — operator decisions / intents from AICX
- **AicxAgent** (48) — agent outcomes (verify before propagating)
- **AicxFailure** (2) — anti-recommendations (avoid repeating)
- **SemanticGuess** (130) — heuristic only, low trust
- **StaleOrUnknown** (0) — explicit "we don't know"


---

*`loct context` rendered in 9230ms · sections: where=38L · live=23L · memory=24L · `--full` for full ContextPack data · `--file <X>` to narrow scope*
