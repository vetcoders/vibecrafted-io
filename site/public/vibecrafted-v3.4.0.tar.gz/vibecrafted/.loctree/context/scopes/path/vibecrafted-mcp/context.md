# Loctree Context Pack

## Project Identity

- **Root**: `/Users/maciejgad/vc-workspace/vetcoders/vibecrafted`
- **Branch**: `feat/runtime-integration`
- **Commit**: `9f76009`
- **Snapshot**: `feat_runtime-integration@9f76009`

## Where You Are

### Files

| Path | Role | Language | LOC | Authority |
|---|---|---|---|---|
| `vibecrafted-app/shell-agent/app/Vibecrafted/AppDelegate.swift` | `Consumer` | swift | 161 | *RepoVerified* |
| `vibecrafted-app/shell-agent/app/Vibecrafted/Views/InspectorViewController.swift` | `Consumer` | swift | 150 | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/__init__.py` | `Dependency` | py | 111 | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/artifacts.py` | `Dependency` | py | 134 | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/capabilities.py` | `Dependency` | py | 333 | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/control_plane.py` | `Dependency` | py | 1267 | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/doctor.py` | `Dependency` | py | 86 | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/events.py` | `Dependency` | py | 24 | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/git.py` | `Dependency` | py | 192 | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/lifecycle.py` | `Dependency` | py | 175 | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/runtime_paths.py` | `Dependency` | py | 53 | *RepoVerified* |
| `vibecrafted-core/vibecrafted_core/supervisor_async.py` | `Dependency` | py | 605 | *RepoVerified* |
| `vibecrafted-mcp/README.md` | `Target` | md | 104 | *RepoVerified* |
| `vibecrafted-mcp/pyproject.toml` | `Target` | toml | 23 | *RepoVerified* |
| `vibecrafted-mcp/tests/__init__.py` | `Target` | py | 0 | *RepoVerified* |
| `vibecrafted-mcp/tests/conftest.py` | `Target` | py | 12 | *RepoVerified* |
| `vibecrafted-mcp/tests/test_server.py` | `Target` | py | 771 | *RepoVerified* |
| `vibecrafted-mcp/vibecrafted_mcp/__init__.py` | `Dependency` | py | 7 | *RepoVerified* |
| `vibecrafted-mcp/vibecrafted_mcp/server.py` | `Dependency` | py | 801 | *RepoVerified* |
| `vibecrafted-mcp/vibecrafted_mcp/synthesis.py` | `Target` | py | 99 | *RepoVerified* |

### Symbols

| File | Name | Kind | Export Type | Line | Authority |
|---|---|---|---|---|---|
| `vibecrafted-mcp/tests/test_server.py` | `test_board_runs_resource_returns_snapshot` | def | named | 486 | *RepoVerified* |
| `vibecrafted-mcp/tests/test_server.py` | `test_build_server_registers_tools_and_resources` | def | named | 201 | *RepoVerified* |
| `vibecrafted-mcp/tests/test_server.py` | `test_doctor_payload_reraises_runtime_doctor_errors` | def | named | 174 | *RepoVerified* |
| `vibecrafted-mcp/tests/test_server.py` | `test_doctor_payload_unavailable_when_installer_missing` | def | named | 161 | *RepoVerified* |
| `vibecrafted-mcp/tests/test_server.py` | `test_filter_events_by_run_respects_limit` | def | named | 121 | *RepoVerified* |
| `vibecrafted-mcp/tests/test_server.py` | `test_live_failure_score_clean_repo_is_low` | def | named | 27 | *RepoVerified* |
| `vibecrafted-mcp/tests/test_server.py` | `test_live_failure_score_dirty_tree_with_failures_is_high` | def | named | 41 | *RepoVerified* |
| `vibecrafted-mcp/tests/test_server.py` | `test_live_failure_score_is_bounded` | def | named | 58 | *RepoVerified* |
| `vibecrafted-mcp/tests/test_server.py` | `test_override_vibecrafted_home_clears_when_unset` | def | named | 112 | *RepoVerified* |
| `vibecrafted-mcp/tests/test_server.py` | `test_override_vibecrafted_home_restores_previous` | def | named | 103 | *RepoVerified* |
| `vibecrafted-mcp/tests/test_server.py` | `test_read_run_event_tail_filters_stream` | def | named | 139 | *RepoVerified* |
| `vibecrafted-mcp/tests/test_server.py` | `test_read_run_event_tail_returns_empty_when_missing` | def | named | 132 | *RepoVerified* |
| `vibecrafted-mcp/tests/test_server.py` | `test_run_resource_templates_resolve_bounded_artifacts` | def | named | 646 | *RepoVerified* |
| `vibecrafted-mcp/tests/test_server.py` | `test_unmade_decisions_flags_behind_upstream` | def | named | 81 | *RepoVerified* |
| `vibecrafted-mcp/tests/test_server.py` | `test_unmade_decisions_flags_staged_changes` | def | named | 70 | *RepoVerified* |
| `vibecrafted-mcp/tests/test_server.py` | `test_unverified_claims_lists_required_senses` | def | named | 92 | *RepoVerified* |
| `vibecrafted-mcp/tests/test_server.py` | `test_vc_init_slim_stays_within_budget` | def | named | 448 | *RepoVerified* |
| `vibecrafted-mcp/tests/test_server.py` | `test_vc_launch_delegates_to_core_workflow` | def | named | 308 | *RepoVerified* |
| `vibecrafted-mcp/tests/test_server.py` | `test_vc_loct_capabilities_routes_to_core` | def | named | 281 | *RepoVerified* |
| `vibecrafted-mcp/tests/test_server.py` | `test_vc_repo_full_returns_ground_truth` | def | named | 419 | *RepoVerified* |
| `vibecrafted-mcp/tests/test_server.py` | `test_vc_run_launch_alias_delegates_to_core_workflow` | def | named | 363 | *RepoVerified* |
| `vibecrafted-mcp/tests/test_server.py` | `test_vc_run_observe_returns_bounded_cursor_deltas` | def | named | 566 | *RepoVerified* |
| `vibecrafted-mcp/tests/test_server.py` | `test_vc_run_status_and_await_use_control_plane_meta` | def | named | 506 | *RepoVerified* |
| `vibecrafted-mcp/tests/test_server.py` | `test_vc_run_stop_and_retry_route_to_workflow` | def | named | 678 | *RepoVerified* |
| `vibecrafted-mcp/vibecrafted_mcp/__init__.py` | `__version__` | __all__ | named |  | *RepoVerified* |
| `vibecrafted-mcp/vibecrafted_mcp/__init__.py` | `annotations` | reexport | named | 1 | *RepoVerified* |
| `vibecrafted-mcp/vibecrafted_mcp/__init__.py` | `build_server` | reexport | named | 3 | *RepoVerified* |
| `vibecrafted-mcp/vibecrafted_mcp/__init__.py` | `main` | reexport | named | 3 | *RepoVerified* |
| `vibecrafted-mcp/vibecrafted_mcp/server.py` | `build_server` | def | named | 380 | *RepoVerified* |
| `vibecrafted-mcp/vibecrafted_mcp/server.py` | `main` | def | named | 766 | *RepoVerified* |
| `vibecrafted-mcp/vibecrafted_mcp/synthesis.py` | `live_failure_score` | def | named | 18 | *RepoVerified* |
| `vibecrafted-mcp/vibecrafted_mcp/synthesis.py` | `unmade_decisions` | def | named | 69 | *RepoVerified* |
| `vibecrafted-mcp/vibecrafted_mcp/synthesis.py` | `unverified_claims` | def | named | 89 | *RepoVerified* |

### Imports

| File | Source | Kind | Resolution | Authority |
|---|---|---|---|---|
| `vibecrafted-mcp/tests/conftest.py` | `__future__` | static | unknown | *RepoVerified* |
| `vibecrafted-mcp/tests/conftest.py` | `pathlib` | static | stdlib | *RepoVerified* |
| `vibecrafted-mcp/tests/conftest.py` | `sys` | static | stdlib | *RepoVerified* |
| `vibecrafted-mcp/tests/test_server.py` | `asyncio` | static | stdlib | *RepoVerified* |
| `vibecrafted-mcp/tests/test_server.py` | `datetime` | static | stdlib | *RepoVerified* |
| `vibecrafted-mcp/tests/test_server.py` | `__future__` | static | unknown | *RepoVerified* |
| `vibecrafted-mcp/tests/test_server.py` | `fastmcp` | static | unknown | *RepoVerified* |
| `vibecrafted-mcp/tests/test_server.py` | `pathlib` | static | stdlib | *RepoVerified* |
| `vibecrafted-mcp/tests/test_server.py` | `typing` | static | stdlib | *RepoVerified* |
| `vibecrafted-mcp/tests/test_server.py` | `vibecrafted_mcp` | static | local | *RepoVerified* |
| `vibecrafted-mcp/tests/test_server.py` | `json` | static | stdlib | *RepoVerified* |
| `vibecrafted-mcp/tests/test_server.py` | `os` | static | stdlib | *RepoVerified* |
| `vibecrafted-mcp/tests/test_server.py` | `pytest` | static | unknown | *RepoVerified* |
| `vibecrafted-mcp/tests/test_server.py` | `subprocess` | static | stdlib | *RepoVerified* |
| `vibecrafted-mcp/vibecrafted_mcp/__init__.py` | `.server` | static | local | *RepoVerified* |
| `vibecrafted-mcp/vibecrafted_mcp/__init__.py` | `__future__` | static | unknown | *RepoVerified* |
| `vibecrafted-mcp/vibecrafted_mcp/server.py` | `argparse` | static | stdlib | *RepoVerified* |
| `vibecrafted-mcp/vibecrafted_mcp/server.py` | `__future__` | static | unknown | *RepoVerified* |
| `vibecrafted-mcp/vibecrafted_mcp/server.py` | `contextlib` | static | stdlib | *RepoVerified* |
| `vibecrafted-mcp/vibecrafted_mcp/server.py` | `fastmcp` | static | unknown | *RepoVerified* |
| `vibecrafted-mcp/vibecrafted_mcp/server.py` | `pathlib` | static | stdlib | *RepoVerified* |
| `vibecrafted-mcp/vibecrafted_mcp/server.py` | `typing` | static | stdlib | *RepoVerified* |
| `vibecrafted-mcp/vibecrafted_mcp/server.py` | `vibecrafted_core` | static | local | *RepoVerified* |
| `vibecrafted-mcp/vibecrafted_mcp/server.py` | `json` | static | stdlib | *RepoVerified* |
| `vibecrafted-mcp/vibecrafted_mcp/server.py` | `os` | static | stdlib | *RepoVerified* |
| `vibecrafted-mcp/vibecrafted_mcp/server.py` | `time` | static | stdlib | *RepoVerified* |
| `vibecrafted-mcp/vibecrafted_mcp/synthesis.py` | `__future__` | static | unknown | *RepoVerified* |
| `vibecrafted-mcp/vibecrafted_mcp/synthesis.py` | `typing` | static | stdlib | *RepoVerified* |

### Consumers

| File | Import Kind | Imports Used | Authority |
|---|---|---|---|
| `vibecrafted-app/shell-agent/app/Vibecrafted/AppDelegate.swift` | `Direct` |  | *RepoVerified* |
| `vibecrafted-app/shell-agent/app/Vibecrafted/Views/InspectorViewController.swift` | `Direct` |  | *RepoVerified* |
| `vibecrafted-mcp/tests/test_server.py` | `Direct` | annotations, server, synthesis | *RepoVerified* |
| `vibecrafted-mcp/vibecrafted_mcp/__init__.py` | `Reexport` | build_server, main | *RepoVerified* |

### Entrypoints

| Path | Kinds | Authority |
|---|---|---|
| `vibecrafted-core/vibecrafted_core/control_plane.py` | script | *RepoVerified* |
| `vibecrafted-mcp/vibecrafted_mcp/server.py` | script | *RepoVerified* |

## Runtime Slice

### Idiom Tags

- **main** (`vibecrafted-mcp/vibecrafted_mcp/__init__.py::main`): Convention entrypoint called from `if __name__ == '__main__':` blocks and `console_scripts` entry points. (Role: primary_entrypoint, Source: embedded_default) *LoctreeDerived*
- **main** (`vibecrafted-mcp/vibecrafted_mcp/server.py::main`): Convention entrypoint called from `if __name__ == '__main__':` blocks and `console_scripts` entry points. (Role: primary_entrypoint, Source: embedded_default) *LoctreeDerived*

### Reachability

- `vibecrafted-mcp/vibecrafted_mcp/__init__.py::main`: Reached (idiom_runtime_role:primary_entrypoint) *SemanticGuess*
- `vibecrafted-mcp/vibecrafted_mcp/server.py::main`: Reached (idiom_runtime_role:primary_entrypoint) *SemanticGuess*

### Env Contracts

- `VIBECRAFTED_HOME` used in 27 files *LoctreeDerived*

### Framework Hints

- `entrypoint` at `vibecrafted-mcp/vibecrafted_mcp/server.py`: script *RepoVerified*

## Risk Slice

- Cache Scope: `Scoped("1adb52e31c44")` *RepoVerified*
- Snapshot Health: `scoped`
- Stale Snapshot: false
- Dirty Worktree: true

### Hotspots

| File | Importers | Authority |
|---|---|---|
| `vibecrafted-mcp/vibecrafted_mcp/server.py` | 3 | *LoctreeDerived* |
| `vibecrafted-mcp/vibecrafted_mcp/__init__.py` | 1 | *LoctreeDerived* |

## Action Slice

### Power Path

- `loct slice vibecrafted-mcp/README.md`: Slice this file to inspect its direct dependencies and immediate consumers before editing.
- `loct follow`: Pursue unified structural signals (dead exports, import cycles, twins) to ensure health.
- `loct slice vibecrafted-mcp/pyproject.toml`: Slice this file to inspect its direct dependencies and immediate consumers before editing.
- `loct slice vibecrafted-mcp/tests/__init__.py`: Slice this file to inspect its direct dependencies and immediate consumers before editing.
- `loct slice vibecrafted-mcp/tests/conftest.py`: Slice this file to inspect its direct dependencies and immediate consumers before editing.
- `loct slice vibecrafted-mcp/tests/test_server.py`: Slice this file to inspect its direct dependencies and immediate consumers before editing.
- `loct body test_live_failure_score_clean_repo_is_low`: View the definition body of symbol 'test_live_failure_score_clean_repo_is_low' to understand its implementation structure.
- `loct find --literal test_live_failure_score_clean_repo_is_low`: Execute a literal exact-identifier scan for 'test_live_failure_score_clean_repo_is_low' to find exact matches across the codebase.
- `loct occurrences test_live_failure_score_clean_repo_is_low`: Perform a literal boundary-sensitive occurrences scan for 'test_live_failure_score_clean_repo_is_low' to locate all references.
- `loct slice vibecrafted-mcp/vibecrafted_mcp/__init__.py`: Slice this file to inspect its direct dependencies and immediate consumers before editing.
- `loct impact vibecrafted-mcp/vibecrafted_mcp/__init__.py`: Assess the transitive blast radius and downstream consumers of this file before modifying.
- `loct body annotations`: View the definition body of symbol 'annotations' to understand its implementation structure.
- `loct find --literal annotations`: Execute a literal exact-identifier scan for 'annotations' to find exact matches across the codebase.
- `loct occurrences annotations`: Perform a literal boundary-sensitive occurrences scan for 'annotations' to locate all references.
- `loct slice vibecrafted-mcp/vibecrafted_mcp/server.py`: Slice this file to inspect its direct dependencies and immediate consumers before editing.
- `loct impact vibecrafted-mcp/vibecrafted_mcp/server.py`: Assess the transitive blast radius and downstream consumers of this file before modifying.
- `loct body build_server`: View the definition body of symbol 'build_server' to understand its implementation structure.
- `loct find --literal build_server`: Execute a literal exact-identifier scan for 'build_server' to find exact matches across the codebase.
- `loct occurrences build_server`: Perform a literal boundary-sensitive occurrences scan for 'build_server' to locate all references.
- `loct slice vibecrafted-mcp/vibecrafted_mcp/synthesis.py`: Slice this file to inspect its direct dependencies and immediate consumers before editing.
- `loct body live_failure_score`: View the definition body of symbol 'live_failure_score' to understand its implementation structure.
- `loct find --literal live_failure_score`: Execute a literal exact-identifier scan for 'live_failure_score' to find exact matches across the codebase.
- `loct occurrences live_failure_score`: Perform a literal boundary-sensitive occurrences scan for 'live_failure_score' to locate all references.

### Next Safe Commands

```bash
loct context --file vibecrafted-mcp/README.md
loct context --file vibecrafted-mcp/pyproject.toml
loct context --file vibecrafted-mcp/tests/__init__.py
```

### Verification Gates

```bash
mypy .
```

### Likely Tests

- `plugins/iterm2/tests/test_iterm2_osc.py`
- `plugins/iterm2/tests/test_iterm2_plugin.py`
- `plugins/iterm2/tests/test_iterm2_profiles.py`
- `tests/agent_dispatch_test.py`
- `tests/tui/test_agy_junie_pipeline.py`
- `tests/tui/test_artifact_truth.py`
- `tests/tui/test_atuin_fallback.py`
- `tests/tui/test_await_observe_contract.py`
- `vibecrafted-core/tests/dispatch/test_cli.py`
- `vibecrafted-core/tests/dispatch/test_doctor.py`

## Memory Slice

_Empty_

## Authority Slice

- Repo Verified: 2
- Loctree Derived: 19
- AICX Operator: 0
- AICX Agent: 0
- AICX Failure: 0
- Semantic Guess: 2
- Stale Or Unknown: 0

