# Loctree Context · vibecrafted @ feat/runtime-integration · 2026-06-07T23:44:05.533081Z

_617 files · 398 import edges · snapshot fresh · dirty worktree_

## TL;DR — read this first

**What this is.** `vibecrafted` repository — current focus: _Runtime Integration_.

**Where you stand.** Branch `feat/runtime-integration`, dirty worktree, snapshot fresh.
Last 5 commits: `216f180 [claude/interactive] fix(skills): add Code-Derived Application Map to vc-justdo + vc-scaffold gates` · `60b0bde [claude/interactive] fix(install): wire shell rc on every machine for one truth after install-all` · `be044ea [claude/interactive] fix(test): stage marbles_spawn.sh under runtime/scripts in fixtures`
Active intent (AICX): "{"completed_at":1780688474,"duration_ms":33780,"last_agent_message":"Przeczytane w całości: 5 scope contextów, 814 linii.\n\nNajważniejszy obraz:\n\n- `vibecrafted-app`: największy blast radius. Szczególnie `mux-agent/src/config.rs`, `scan.rs`, `state.rs`; realne testy Rust do odpalenia przy zmianach.\n- `vibecrafted-core`: runtime serce. `__init__.py`, `events.py`, `runtime_paths.py`, `spawn.py`, `control_plane.py`, `workflow.py` są główne punkty ryzyka." — codex on 2026-06-05.
**Scope.** `path:vibecrafted-core` -> path:vibecrafted-core (51 files, fingerprint: f1835573938e).

**Top 3 things to know before editing.**
1. Hub `vibecrafted-core/vibecrafted_core/__init__.py` has 18 importers — touching it = wide blast radius (of 30 ranked hubs). (LoctreeDerived)
2. 2 high-fan-in file(s) exceed threshold — review impact before edits. (LoctreeDerived)
3. Active memory says `{"completed_at":1780688474,"duration_ms":33780,"last_agent_message":"Przeczytane w całości: 5 scope contextów, 814 linii.\n\nNajważniejszy obraz:\n\n- `vibecrafted-app`: największy blast radius. Szczególnie `mux-agent/src/config.rs`, `scan.rs`, `state.rs`; realne testy Rust do odpalenia przy zmianach.\n- `vibecrafted-core`: runtime serce. `__init__.py`, `events.py`, `runtime_paths.py`, `spawn.py`, `control_plane.py`, `workflow.py` są główne punkty ryzyka.` — codex on 2026-06-05. (AicxOperator)

**Snapshot facts.** 30 hubs · 3 idiom tag(s) · 2 dispatch edge(s) · 11 env contract(s) · 50 memory entries · 285 authority claim(s).

**What's stale.** None.

## Where You Are

### Hubs — touch = blast radius

| File | Importers | Authority |
|---|---:|---|
| `vibecrafted-core/vibecrafted_core/__init__.py` | 18 | LoctreeDerived |
| `vibecrafted-core/vibecrafted_core/wrappers.py` | 11 | LoctreeDerived |
| `vibecrafted-core/vibecrafted_core/events.py` | 7 | LoctreeDerived |
| `vibecrafted-core/vibecrafted_core/runtime_paths.py` | 7 | LoctreeDerived |
| `vibecrafted-core/vibecrafted_core/sandbox/policy.py` | 5 | LoctreeDerived |
| `vibecrafted-core/vibecrafted_core/spawn.py` | 5 | LoctreeDerived |
| `vibecrafted-core/vibecrafted_core/control_plane.py` | 4 | LoctreeDerived |
| `vibecrafted-core/vibecrafted_core/sandbox/__init__.py` | 4 | LoctreeDerived |
| `vibecrafted-core/vibecrafted_core/supervisor_async.py` | 4 | LoctreeDerived |
| `vibecrafted-core/vibecrafted_core/agent_dispatch.py` | 3 | LoctreeDerived |
| `vibecrafted-core/vibecrafted_core/artifacts.py` | 3 | LoctreeDerived |
| `vibecrafted-core/vibecrafted_core/lifecycle.py` | 3 | LoctreeDerived |
| `vibecrafted-core/vibecrafted_core/sandbox/msbserver_lifecycle.py` | 3 | LoctreeDerived |
| `vibecrafted-core/vibecrafted_core/workflow.py` | 3 | LoctreeDerived |
| `vibecrafted-core/vibecrafted_core/cli.py` | 2 | LoctreeDerived |
| `vibecrafted-core/vibecrafted_core/dispatcher.py` | 2 | LoctreeDerived |
| `vibecrafted-core/vibecrafted_core/iterm2_plugin/vc_launcher.py` | 2 | LoctreeDerived |
| `vibecrafted-core/vibecrafted_core/iterm2_plugin/vc_status_bar.py` | 2 | LoctreeDerived |
| `vibecrafted-core/vibecrafted_core/iterm2_plugin/vc_triggers.py` | 2 | LoctreeDerived |
| `vibecrafted-core/vibecrafted_core/capabilities.py` | 1 | LoctreeDerived |
| `vibecrafted-core/vibecrafted_core/doctor.py` | 1 | LoctreeDerived |
| `vibecrafted-core/vibecrafted_core/git.py` | 1 | LoctreeDerived |
| `vibecrafted-core/vibecrafted_core/iterm2_plugin/__init__.py` | 1 | LoctreeDerived |
| `vibecrafted-core/vibecrafted_core/sandbox/adapter.py` | 1 | LoctreeDerived |

### Cycles

- not_measured (run `loct cycles` for current measurement) (LoctreeDerived)

### Recently active surface (last 24h)

- `.github/workflows/portable.yml` (RepoVerified)
- `.gitignore` (RepoVerified)
- `.junie/plans/decompose-vetcoders-shell-runtime.md` (RepoVerified)
- `.loctignore` (RepoVerified)
- `CHANGELOG.md` (RepoVerified)
- `Makefile` (RepoVerified)
- `agents/scripts/install-shell.sh` (RepoVerified)
- `agents/scripts/lib/meta.sh` (RepoVerified)
- `agents/scripts/skills_sync.sh` (RepoVerified)
- `agents/shell/lib/atuin.sh` (RepoVerified)

### Risk metrics

- dead_exports: not_measured (use-graph counts `pub use` re-exports as live — known limitation; run `loct dead` for current count) (RepoVerified)
- twins: not_measured (run `loct twins` for a context-classified pass) (RepoVerified)
- cache_scope: `Scoped("f1835573938e")` (RepoVerified)
- high_fan_in: 2 files over threshold 10 (LoctreeDerived)

## What's Live

### Idiom tag clusters (top 10 by hit count)

- `idiom:shell-helper` (3 hits) — main shell helpers (LoctreeDerived)

### Dispatch edges (top 5 by reach)

- `vibecrafted-core/tests/test_iterm2_plugin.py`:27 → `fake_iterm2` (`event_handler`) (LoctreeDerived)
- `vibecrafted-core/tests/test_sandbox_adapter.py`:72 → `fake_microsandbox` (`event_handler`) (LoctreeDerived)

### Env contracts (vars used in scope)

- `MICROSANDBOX_PYTHON_SDK` — used in 1 file(s) (LoctreeDerived)
- `MSBSERVER_EXE` — used in 1 file(s) (LoctreeDerived)
- `MSB_API_KEY` — used in 1 file(s) (LoctreeDerived)
- `MSB_SERVER_URL` — used in 1 file(s) (LoctreeDerived)
- `PATH` — used in 14 file(s) (LoctreeDerived)
- `VIBECRAFTED_DEV` — used in 1 file(s) (LoctreeDerived)
- `VIBECRAFTED_HOME` — used in 24 file(s) (LoctreeDerived)
- `VIBECRAFTED_META_PATH` — used in 1 file(s) (LoctreeDerived)
- `VIBECRAFTED_PLUGIN_LOGLEVEL` — used in 1 file(s) (LoctreeDerived)
- `VIBECRAFTED_REPORT_PATH` — used in 2 file(s) (LoctreeDerived)

### Reachability (top 5 widely-reached symbols)

- `vibecrafted-core/tests/test_iterm2_plugin.py::fake_iterm2` — reason: `dispatch_handler:event_handler:vibecrafted-core/tests/test_iterm2_plugin.py` (LoctreeDerived)
- `vibecrafted-core/tests/test_sandbox_adapter.py::fake_microsandbox` — reason: `dispatch_handler:event_handler:vibecrafted-core/tests/test_sandbox_adapter.py` (LoctreeDerived)
- `vibecrafted-core/vibecrafted_core/cli.py::main` — reason: `idiom_runtime_role:primary_entrypoint` (SemanticGuess)
- `vibecrafted-core/vibecrafted_core/dispatcher.py::main` — reason: `idiom_runtime_role:primary_entrypoint` (SemanticGuess)
- `vibecrafted-core/vibecrafted_core/iterm2_plugin/vc_launcher.py::main` — reason: `idiom_runtime_role:primary_entrypoint` (SemanticGuess)

## Memory

### Recent decisions / intents / outcomes (last 168h, top by relevance)

1. `outcome` · codex · 2026-06-05 · _{"completed_at":1780688474,"duration_ms":33780,"last_agent_message":"Przeczytane w całości: 5 scope contextów, 814 linii.\n\nNajważniejszy obraz:\n\n- `vibecrafted-app`: największy blast radius. Szczególnie `mux-agent/src/config.rs`, `scan.rs`, `state.rs`; realne testy Rust do odpalenia przy zmianach.\n- `vibecrafted-core`: runtime serce. `__init__.py`, `events.py`, `runtime_paths.py`, `spawn.py`, `control_plane.py`, `workflow.py` są główne punkty ryzyka._ (AicxAgent) — chunk: `chunk:48e118ea`
2. `outcome` · codex · 2026-06-05 · _{"completed_at":1780697273,"duration_ms":25193,"last_agent_message":"Tak, teraz mam już te MCP-y działające po stronie Codexa.\n\nKonkretnie: po zmianie configu i odświeżeniu tool discovery `loctree-mcp` wystawił namespace `mcp__loctree_mcp`, a realny smoke-test przeszedł:\n\n```text\nslice scripts/vetcoders_install.py\ncore_loc: 5482\ndependencies: scripts/installer_brand.py, scripts/runtime_paths.py\nconsumer: scripts/build_marketplace_bundle._ (AicxAgent) — chunk: `chunk:a5e67bf9`
3. `outcome` · codex · 2026-06-05 · _{"completed_at":1780688474,"duration_ms":33780,"last_agent_message":"Przeczytane w całości: 5 scope contextów, 814 linii.\n\nNajważniejszy obraz:\n\n- `vibecrafted-app`: największy blast radius. Szczególnie `mux-agent/src/config.rs`, `scan.rs`, `state.rs`; realne testy Rust do odpalenia przy zmianach.\n- `vibecrafted-core`: runtime serce. `__init__.py`, `events.py`, `runtime_paths.py`, `spawn.py`, `control_plane.py`, `workflow.py` są główne punkty ryzyka._ (AicxAgent) — chunk: `chunk:48e118ea`
4. `outcome` · codex · 2026-06-05 · _{"call_id":"call_y31zrXXdMjazsEXVZr1mTVqk","changes":{"/Users/maciejgad/vc-workspace/vetcoders/vibecrafted/docs/runtime/CONTRACT.md":{"move_path":null,"type":"update","unified_diff":"@@ -150,3 +150,3 @@\n \n-Final Markdown artifact filenames SHOULD use:\n+Final Markdown artifact filenames MUST use:\n `%Y-%m-%d_<org>_<repo>_<full_session_id>-<kind>.md`\n"}},"status":"completed","stderr":"","stdout":"Success. Updated the following files:\nM docs/runtime/CONTRACT._ (AicxAgent) — chunk: `chunk:c15b5f45`
5. `outcome` · codex · 2026-06-05 · _{"call_id":"call_Zgu0iBG7LARhjX81VPejY5ZT","changes":{"/Users/maciejgad/vc-workspace/vetcoders/vibecrafted/tests/tui/test_runtime_regressions.py":{"content":"from __future__ import annotations\n\nimport os\nimport subprocess\nfrom pathlib import Path\n\nfrom scripts import vetcoders_install\n\nREPO_ROOT = Path(__file__).resolve().parents[2]\nSHELL_SH = REPO_ROOT / \"skills\" / \"vc-agents\" / \"shell\" / \"vetcoders._ (AicxAgent) — chunk: `chunk:3ec05ea4`
6. `outcome` · codex · 2026-06-05 · _{"completed_at":1780688474,"duration_ms":33780,"last_agent_message":"Przeczytane w całości: 5 scope contextów, 814 linii.\n\nNajważniejszy obraz:\n\n- `vibecrafted-app`: największy blast radius. Szczególnie `mux-agent/src/config.rs`, `scan.rs`, `state.rs`; realne testy Rust do odpalenia przy zmianach.\n- `vibecrafted-core`: runtime serce. `__init__.py`, `events.py`, `runtime_paths.py`, `spawn.py`, `control_plane.py`, `workflow.py` są główne punkty ryzyka._ (AicxAgent) — chunk: `chunk:48e118ea`
7. `outcome` · codex · 2026-06-05 · _{"call_id":"call_yXexjmv8hLwkj6hI3AjCmK6m","changes":{"/Users/maciejgad/vc-workspace/vetcoders/vibecrafted/docs/runtime/CONTRACT.md":{"move_path":null,"type":"update","unified_diff":"@@ -231,3 +231,3 @@\n ```bash\n-PLAN=\"$VIBECRAFTED_ROOT/.vibecrafted/artifacts/<org>/<repo>/<YYYY_MMDD>/plans/<plan>.md\"\n+PLAN=\"$VIBECRAFTED_HOME/artifacts/<org>/<repo>/<YYYY_MMDD>/plans/<plan>.md\"\n bash $VIBECRAFTED_ROOT/agents/scripts/codex_spawn._ (AicxAgent) — chunk: `chunk:c15b5f45`
8. `outcome` · codex · 2026-06-05 · _{"call_id":"call_stIqPQOKPrj9SODbjJ0yHQYn","changes":{"/Users/maciejgad/vc-workspace/vetcoders/vibecrafted/tests/tui/test_commit_message_hook.py":{"move_path":null,"type":"update","unified_diff":"@@ -79,2 +79,22 @@\n \n+def test_commit_msg_hook_rejects_legacy_timestamp_trailer(tmp_path: Path) -> None:\n+ result = run_hook(\n+ tmp_path,\n+ \"\"\"\n+ [codex/interactive] chore: Polish Makefile help output formatting\n+\n+ Refactors the help target to use structured printf …_ (AicxAgent) — chunk: `chunk:62387b96`
9. `outcome` · codex · 2026-06-05 · _{"completed_at":1780697273,"duration_ms":25193,"last_agent_message":"Tak, teraz mam już te MCP-y działające po stronie Codexa.\n\nKonkretnie: po zmianie configu i odświeżeniu tool discovery `loctree-mcp` wystawił namespace `mcp__loctree_mcp`, a realny smoke-test przeszedł:\n\n```text\nslice scripts/vetcoders_install.py\ncore_loc: 5482\ndependencies: scripts/installer_brand.py, scripts/runtime_paths.py\nconsumer: scripts/build_marketplace_bundle._ (AicxAgent) — chunk: `chunk:a5e67bf9`
10. `outcome` · codex · 2026-06-05 · _{"completed_at":1780688474,"duration_ms":33780,"last_agent_message":"Przeczytane w całości: 5 scope contextów, 814 linii.\n\nNajważniejszy obraz:\n\n- `vibecrafted-app`: największy blast radius. Szczególnie `mux-agent/src/config.rs`, `scan.rs`, `state.rs`; realne testy Rust do odpalenia przy zmianach.\n- `vibecrafted-core`: runtime serce. `__init__.py`, `events.py`, `runtime_paths.py`, `spawn.py`, `control_plane.py`, `workflow.py` są główne punkty ryzyka._ (AicxAgent) — chunk: `chunk:48e118ea`
11. `outcome` · codex · 2026-06-05 · _{"call_id":"call_stIqPQOKPrj9SODbjJ0yHQYn","changes":{"/Users/maciejgad/vc-workspace/vetcoders/vibecrafted/tests/tui/test_commit_message_hook.py":{"move_path":null,"type":"update","unified_diff":"@@ -79,2 +79,22 @@\n \n+def test_commit_msg_hook_rejects_legacy_timestamp_trailer(tmp_path: Path) -> None:\n+ result = run_hook(\n+ tmp_path,\n+ \"\"\"\n+ [codex/interactive] chore: Polish Makefile help output formatting\n+\n+ Refactors the help target to use structured printf …_ (AicxAgent) — chunk: `chunk:62387b96`
12. `outcome` · codex · 2026-06-05 · _{"call_id":"call_Zgu0iBG7LARhjX81VPejY5ZT","changes":{"/Users/maciejgad/vc-workspace/vetcoders/vibecrafted/tests/tui/test_runtime_regressions.py":{"content":"from __future__ import annotations\n\nimport os\nimport subprocess\nfrom pathlib import Path\n\nfrom scripts import vetcoders_install\n\nREPO_ROOT = Path(__file__).resolve().parents[2]\nSHELL_SH = REPO_ROOT / \"skills\" / \"vc-agents\" / \"shell\" / \"vetcoders._ (AicxAgent) — chunk: `chunk:3ec05ea4`
13. `outcome` · codex · 2026-06-05 · _{"completed_at":1780697273,"duration_ms":25193,"last_agent_message":"Tak, teraz mam już te MCP-y działające po stronie Codexa.\n\nKonkretnie: po zmianie configu i odświeżeniu tool discovery `loctree-mcp` wystawił namespace `mcp__loctree_mcp`, a realny smoke-test przeszedł:\n\n```text\nslice scripts/vetcoders_install.py\ncore_loc: 5482\ndependencies: scripts/installer_brand.py, scripts/runtime_paths.py\nconsumer: scripts/build_marketplace_bundle._ (AicxAgent) — chunk: `chunk:a5e67bf9`
14. `outcome` · codex · 2026-06-05 · _{"completed_at":1780688474,"duration_ms":33780,"last_agent_message":"Przeczytane w całości: 5 scope contextów, 814 linii.\n\nNajważniejszy obraz:\n\n- `vibecrafted-app`: największy blast radius. Szczególnie `mux-agent/src/config.rs`, `scan.rs`, `state.rs`; realne testy Rust do odpalenia przy zmianach.\n- `vibecrafted-core`: runtime serce. `__init__.py`, `events.py`, `runtime_paths.py`, `spawn.py`, `control_plane.py`, `workflow.py` są główne punkty ryzyka._ (AicxAgent) — chunk: `chunk:48e118ea`
15. `outcome` · codex · 2026-06-05 · _{"call_id":"call_bblBJaGbGyWr844kizcowVhV","changes":{"/Users/maciejgad/vc-workspace/vetcoders/vibecrafted/templates/hooks/config/template.husky.env":{"move_path":null,"type":"update","unified_diff":"@@ -112,3 +112,3 @@\n # Require the full agent/runtime footer used by Vibecrafted local commits:\n-# Authored-By, session_id, timestamp, and runtime.\n+# Authored-By, session_id, time, and runtime.\n HUSKY_COMMIT_MSG_REQUIRE_AGENT_RUNTIME=1\n"}},"status":"completed","stderr":"" …_ (AicxAgent) — chunk: `chunk:c0c007e3`

### Source chunk pointers

_23 unique chunk(s) reachable via `aicx open <chunk:ref>` (resolved against the operator's local aicx store; absolute paths intentionally redacted to keep this context-pack commitable)._

## Action

### Next safe commands (grounded, ≤3)

```bash
loct slice vibecrafted-core/README.md
loct impact vibecrafted-core/README.md
loct context --file vibecrafted-core/README.md
```

### Verification gates (run before any commit)

- `make test` (SemanticGuess)
- `make check` (SemanticGuess)
- `mypy .` (SemanticGuess)
- `python -m pytest` (SemanticGuess)

### Likely tests for current scope

- `tests/agent_dispatch_test.py` (LoctreeDerived)
- `tests/tui/test_keys.py` (LoctreeDerived)
- `vibecrafted-core/tests/__init__.py` (LoctreeDerived)
- `vibecrafted-core/tests/conftest.py` (LoctreeDerived)
- `vibecrafted-core/tests/test_agy_junie_pipeline.py` (LoctreeDerived)
- `vibecrafted-core/tests/test_aicx_sync.py` (LoctreeDerived)
- `vibecrafted-core/tests/test_capabilities.py` (LoctreeDerived)
- `vibecrafted-core/tests/test_control_plane.py` (LoctreeDerived)
- `vibecrafted-core/tests/test_doctor.py` (LoctreeDerived)
- `vibecrafted-core/tests/test_git.py` (LoctreeDerived)

## Authority Index

_285 total claims tagged with provenance._

- **RepoVerified** (12) — AST + git state derivation
- **LoctreeDerived** (220) — snapshot edges + idiom catalogs
- **AicxOperator** (0) — operator decisions / intents from AICX
- **AicxAgent** (49) — agent outcomes (verify before propagating)
- **AicxFailure** (1) — anti-recommendations (avoid repeating)
- **SemanticGuess** (3) — heuristic only, low trust
- **StaleOrUnknown** (0) — explicit "we don't know"


---

*`loct context` rendered in 10074ms · sections: where=55L · live=32L · memory=24L · `--full` for full ContextPack data · `--file <X>` to narrow scope*
