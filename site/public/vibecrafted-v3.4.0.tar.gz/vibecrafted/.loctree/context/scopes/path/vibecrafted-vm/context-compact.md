# Loctree Context · vibecrafted @ feat/runtime-integration · 2026-06-15T14:30:46.934734Z

_710 files · 468 import edges · snapshot fresh · dirty worktree_

## TL;DR — read this first

**What this is.** `vibecrafted` repository — current focus: _Runtime Integration_.

**Where you stand.** Branch `feat/runtime-integration`, dirty worktree, snapshot fresh.
Last 5 commits: `9f76009 [codex/implement] fix(runtime): centralize launcher ulimit hardening` · `3e9ea7a [claude/vc-implement] fix(spawn): read run-closure footer tokens for all agents` · `dadcbd4 [claude/vc-implement] fix(agent-stream): render gemini token line for spawn extractor`
**Scope.** `path:vibecrafted-vm` -> path:vibecrafted-vm (7 files, fingerprint: 3d79743b1e71).

**Top 3 things to know before editing.**
1. Hub `vibecrafted-vm/wizard/vc-onboard.py` has 3 importers — touching it = wide blast radius (of 30 ranked hubs). (LoctreeDerived)
2. Worktree is dirty — auto-scope mirrors uncommitted edits, not committed state. (RepoVerified)
3. Env var `BASH_SOURCE` is read by 66 file(s) in scope — verify before refactoring config flow. (LoctreeDerived)

**Snapshot facts.** 30 hubs · 3 idiom tag(s) · 0 dispatch edge(s) · 21 env contract(s) · 0 memory entries · 46 authority claim(s).

**What's stale.** None.

## Where You Are

### Hubs — touch = blast radius

| File | Importers | Authority |
|---|---:|---|
| `vibecrafted-vm/wizard/vc-onboard.py` | 3 | LoctreeDerived |
| `vibecrafted-vm/entry.sh` | 1 | LoctreeDerived |

### Cycles

- not_measured (run `loct cycles` for current measurement) (LoctreeDerived)

### Recently active surface (last 24h)

- `.gitignore` (RepoVerified)
- `Makefile` (RepoVerified)
- `config/zellij/layouts/operator.kdl` (RepoVerified)
- `runtime/scripts/common.sh` (RepoVerified)
- `runtime/scripts/lib/launcher.sh` (RepoVerified)
- `runtime/scripts/lib/ulimits.sh` (RepoVerified)
- `runtime/scripts/lib/zellij.sh` (RepoVerified)
- `runtime/shell/lib/dashboard.sh` (RepoVerified)
- `runtime/shell/lib/ulimits.sh` (RepoVerified)
- `runtime/shell/lib/zellij.sh` (RepoVerified)

### Risk metrics

- dead_exports: not_measured (use-graph counts `pub use` re-exports as live — known limitation; run `loct dead` for current count) (RepoVerified)
- twins: not_measured (run `loct twins` for a context-classified pass) (RepoVerified)
- cache_scope: `Scoped("3d79743b1e71")` (RepoVerified)
- high_fan_in: 0 over threshold 10 (LoctreeDerived)

## What's Live

### Idiom tag clusters (top 10 by hit count)

- `idiom:shell-helper` (3 hits) — log/warn/main shell helpers (LoctreeDerived)

### Dispatch edges (top 5 by reach)

- _no dispatch edges in scope_ (LoctreeDerived)

### Env contracts (vars used in scope)

- `BASH_SOURCE` — used in 66 file(s) (LoctreeDerived)
- `BLUE` — used in 1 file(s) (LoctreeDerived)
- `DEST` — used in 1 file(s) (LoctreeDerived)
- `GREEN` — used in 1 file(s) (LoctreeDerived)
- `HOSTNAME_DEFAULT` — used in 1 file(s) (LoctreeDerived)
- `LOCTREE_GPG_KEY_ID` — used in 2 file(s) (LoctreeDerived)
- `NC` — used in 1 file(s) (LoctreeDerived)
- `RUNTIME_DIR` — used in 1 file(s) (LoctreeDerived)
- `SCRIPT_DIR` — used in 27 file(s) (LoctreeDerived)
- `TAILSCALED_PID` — used in 1 file(s) (LoctreeDerived)

### Reachability (top 5 widely-reached symbols)

- `vibecrafted-vm/entry.sh::log` — reason: `dispatch_handler:case_statement:scripts/install-hammerspoon.sh` (LoctreeDerived)
- `vibecrafted-vm/entry.sh::ok` — reason: `dispatch_handler:case_statement:tests/hammerspoon_smoke.sh` (LoctreeDerived)
- `vibecrafted-vm/entry.sh::warn` — reason: `dispatch_handler:case_statement:vibecrafted-app/mux-agent/tools/install.sh` (LoctreeDerived)
- `vibecrafted-vm/wizard/vc-onboard.py::main` — reason: `idiom_runtime_role:primary_entrypoint` (SemanticGuess)

## Memory

_AICX overlay disabled by `--no-aicx`; memory overlay intentionally omitted._ (RepoVerified)

## Action

### Power Path (suggested next steps)

- `loct slice vibecrafted-vm/README.md`: Slice this file to inspect its direct dependencies and immediate consumers before editing.
- `loct follow`: Pursue unified structural signals (dead exports, import cycles, twins) to ensure health.
- `loct slice vibecrafted-vm/RUNBOOK.md`: Slice this file to inspect its direct dependencies and immediate consumers before editing.
- `loct slice vibecrafted-vm/compose.yaml`: Slice this file to inspect its direct dependencies and immediate consumers before editing.
- `loct slice vibecrafted-vm/entry.sh`: Slice this file to inspect its direct dependencies and immediate consumers before editing.
- `loct impact vibecrafted-vm/entry.sh`: Assess the transitive blast radius and downstream consumers of this file before modifying.
- `loct body log`: View the definition body of symbol 'log' to understand its implementation structure.
- `loct find --literal log`: Execute a literal exact-identifier scan for 'log' to find exact matches across the codebase.
- `loct occurrences log`: Perform a literal boundary-sensitive occurrences scan for 'log' to locate all references.
- `loct slice vibecrafted-vm/vendor-src.sh`: Slice this file to inspect its direct dependencies and immediate consumers before editing.
- `loct slice vibecrafted-vm/wizard/strings.json`: Slice this file to inspect its direct dependencies and immediate consumers before editing.
- `loct slice vibecrafted-vm/wizard/vc-onboard.py`: Slice this file to inspect its direct dependencies and immediate consumers before editing.
- `loct impact vibecrafted-vm/wizard/vc-onboard.py`: Assess the transitive blast radius and downstream consumers of this file before modifying.
- `loct body t`: View the definition body of symbol 't' to understand its implementation structure.
- `loct find --literal t`: Execute a literal exact-identifier scan for 't' to find exact matches across the codebase.
- `loct occurrences t`: Perform a literal boundary-sensitive occurrences scan for 't' to locate all references.

### Next safe commands (grounded, ≤3)

```bash
loct context --file vibecrafted-vm/README.md
loct context --file vibecrafted-vm/RUNBOOK.md
loct context --file vibecrafted-vm/compose.yaml
```

### Verification gates (run before any commit)

- `mypy .` (SemanticGuess)

### Likely tests for current scope

- `tests/agent_dispatch_test.py` (LoctreeDerived)
- `vibecrafted-core/tests/dispatch/test_cli.py` (LoctreeDerived)
- `vibecrafted-core/tests/dispatch/test_doctor.py` (LoctreeDerived)
- `vibecrafted-core/tests/dispatch/test_supervisor.py` (LoctreeDerived)
- `vibecrafted-core/tests/test_agy_junie_pipeline.py` (LoctreeDerived)
- `vibecrafted-core/tests/test_aicx_sync.py` (LoctreeDerived)
- `vibecrafted-core/tests/test_capabilities.py` (LoctreeDerived)
- `vibecrafted-core/tests/test_cli.py` (LoctreeDerived)
- `vibecrafted-core/tests/test_compact_hooks.py` (LoctreeDerived)
- `vibecrafted-core/tests/test_control_plane.py` (LoctreeDerived)

## Authority Index

_46 total claims tagged with provenance._

- **RepoVerified** (2) — AST + git state derivation
- **LoctreeDerived** (43) — snapshot edges + idiom catalogs
- **AicxOperator** (0) — operator decisions / intents from AICX
- **AicxAgent** (0) — agent outcomes (verify before propagating)
- **AicxFailure** (0) — anti-recommendations (avoid repeating)
- **SemanticGuess** (1) — heuristic only, low trust
- **StaleOrUnknown** (0) — explicit "we don't know"


---

*`loct context` rendered in 7012ms · sections: where=33L · live=30L · memory=4L · `--full` for full ContextPack data · `--file <X>` to narrow scope*
