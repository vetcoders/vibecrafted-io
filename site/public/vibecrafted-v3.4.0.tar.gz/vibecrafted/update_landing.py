import os

def update_file(filepath, replacements):
    with open(filepath, 'r', encoding='utf-8') as f:
        content = f.read()
    
    for old, new in replacements:
        if old in content:
            content = content.replace(old, new)
        else:
            print(f"Warning: Could not find '{old[:50]}...' in {filepath}")
            
    with open(filepath, 'w', encoding='utf-8') as f:
        f.write(content)
    print(f"Updated {filepath}")

en_replacements = [
    (
"""                    <p class="manifesto-quote">
                        Created by itself through the <span
                            class="manifesto-quote__accent">𝚅𝚒𝚋𝚎𝚌𝚛𝚊𝚏𝚝𝚜𝚖𝚊𝚗𝚜𝚑𝚒𝚙</span>.
                    </p>""",
"""                    <p class="manifesto-quote">
                        A framework that wrote its own code through <span
                            class="manifesto-quote__accent">𝚅𝚒𝚋𝚎𝚌𝚛𝚊𝚏𝚝𝚜𝚖𝚊𝚗𝚜𝚑𝚒𝚙</span>.
                    </p>"""
    ),
    (
"""                <div class="science-prose fade-up">
                    <h2>It is not magic.<br>It is Computer Science.</h2>
                    <p>The vocabulary is vivid because it was discovered in real founder workflows. Underneath it sits a
                        rigorous operating model for context, variance reduction, and release truth.</p>
                </div>

                <div class="evidence-grid fade-up">
                    <div class="evidence-item">
                        <span class="evidence-num">01</span>
                        <h3>AST-Augmented Context</h3>
                        <p>LLMs fail when they code blind. By externalizing architectural memory into AST-augmented
                            mappings, ݆𝚅𝚒𝚋𝚎𝚌𝚛𝚊𝚏𝚝𝚎𝚍. keeps frontier models oriented precisely inside your
                            repository.</p>
                    </div>
                    <div class="evidence-item">
                        <span class="evidence-num">02</span>
                        <h3>Stochastic Convergence</h3>
                        <p>Code generation is stochastic. The Marbles loop uses priority-weighted denoising loops to
                            relentlessly reduce variance, forcing the system into a shippable state.</p>
                    </div>
                    <div class="evidence-item">
                        <span class="evidence-num">03</span>
                        <h3>𝚅𝚒𝚋𝚎𝚌𝚛𝚊𝚏𝚝𝚜𝚖𝚊𝚗𝚜𝚑𝚒𝚙 (SHACE)</h3>
                        <p>Structured Human-AI Collaborative Engineering. We wrap deterministic human checkpoints around
                            stochastic generation. The result is a system you control and understand.</p>
                    </div>
                </div>""",
"""                <div class="science-prose fade-up">
                    <h2>This is not magic.<br>It's rigorous engineering.</h2>
                    <p>The vocabulary is vivid because it was forged under midnight pressure. Beneath the vibe sits a
                        rigorous operating model for context, variance reduction, and release truth.</p>
                </div>

                <div class="evidence-grid fade-up">
                    <div class="evidence-item">
                        <span class="evidence-num">01</span>
                        <h3>AST-Augmented Context</h3>
                        <p>LLMs hallucinate when they code blind. By externalizing architectural memory into AST-augmented
                            mappings, ݆𝚅𝚒𝚋𝚎𝚌𝚛𝚊𝚏𝚝𝚎𝚍. keeps frontier models oriented precisely inside your
                            codebase.</p>
                    </div>
                    <div class="evidence-item">
                        <span class="evidence-num">02</span>
                        <h3>Stochastic Convergence</h3>
                        <p>Code generation is stochastic. The Marbles loop uses priority-weighted denoising loops to
                            relentlessly reduce variance, forcing the system into a shippable state.</p>
                    </div>
                    <div class="evidence-item">
                        <span class="evidence-num">03</span>
                        <h3>𝚅𝚒𝚋𝚎𝚌𝚛𝚊𝚏𝚝𝚜𝚖𝚊𝚗𝚜𝚑𝚒𝚙</h3>
                        <p>Structured Human-AI Collaborative Engineering. We wrap deterministic human checkpoints around
                            stochastic generation. The result is a system you control, trust, and understand.</p>
                    </div>
                </div>"""
    ),
    (
"""        <section class="runtime-view">
            <div class="container fade-up">
                <div class="section-label">Runtime Foundations</div>
                <h2 class="section-title">The substrate underneath the framework.</h2>
                <p class="section-sub">The substrate that keeps frontier agents anchored to repo truth.</p>""",
"""        <section class="runtime-view">
            <div class="container fade-up">
                <div class="section-label">Runtime Foundations</div>
                <h2 class="section-title">The substrate beneath the framework.</h2>
                <p class="section-sub">The tooling that keeps frontier agents anchored to repo truth, instead of their own hallucinations.</p>"""
    ),
    (
"""        <section class="pipeline-section" id="pipeline">
            <div class="container fade-up">
                <div class="section-label">The Method</div>
                <h2 class="section-title">Craft &rarr; Converge &rarr; Ship</h2>
                <p class="section-sub">A founder-grade operating model for shaping, denoising, and releasing software
                    with AI agents.</p>""",
"""        <section class="pipeline-section" id="pipeline">
            <div class="container fade-up">
                <div class="section-label">The Method</div>
                <h2 class="section-title">Craft &rarr; Converge &rarr; Ship</h2>
                <p class="section-sub">A founder-grade operating model for shaping, denoising, and finally releasing software
                    with AI agents.</p>"""
    ),
    (
"""        <section id="skills">
            <div class="container fade-up">
                <div class="section-label">Skill Suite</div>
                <h2 class="section-title">16 Specialized Workflows</h2>
                <p class="section-sub">Hard-coded procedures born from pain. Powered by frontier models and Rust-based
                    structural intelligence.</p>""",
"""        <section id="skills">
            <div class="container fade-up">
                <div class="section-label">The Skill Suite</div>
                <h2 class="section-title">16 Specialized Workflows</h2>
                <p class="section-sub">Hard-coded procedures forged in the trenches. Powered by frontier models and Rust-based
                    structural intelligence.</p>"""
    ),
    (
"""                    <div class="manifesto-block">
                        <blockquote>AI agents have solved the hardest part of software creation: making the thing work.
                            They
                            have not yet solved the second hardest part: making the thing reachable.</blockquote>
                        <p class="manifesto-lead">The gap is rarely code quality. It is the space between a working
                            system
                            and a product that people can discover, install, trust, and buy.</p>
                        <p class="manifesto-diagnostic-label">The Plague Diagnostic:</p>""",
"""                    <div class="manifesto-block">
                        <blockquote>AI agents have solved the hardest part of software creation: making the thing work.
                            They
                            have not yet solved the second hardest part: making the thing reachable.</blockquote>
                        <p class="manifesto-lead">The gap is rarely code quality. It is the brutal space between a working
                            system
                            and a product that strangers can discover, install, trust, and buy.</p>
                        <p class="manifesto-diagnostic-label">The Founder's Diagnostic:</p>"""
    ),
    (
"""        <section id="get">
            <div class="container fade-up">
                <div class="section-label">Get ݆𝚅𝚒𝚋𝚎𝚌𝚛𝚊𝚏𝚝𝚎𝚍.</div>
                <h2 class="section-title">Install the framework. Start the loop.</h2>
                <p class="section-sub">Bootstrap the control plane, verify the surface, and enter the first
                    founder-grade workflow with the new command deck.</p>""",
"""        <section id="get">
            <div class="container fade-up">
                <div class="section-label">Get ݆𝚅𝚒𝚋𝚎𝚌𝚛𝚊𝚏𝚝𝚎𝚍.</div>
                <h2 class="section-title">Install the framework. Start the loop.</h2>
                <p class="section-sub">Bootstrap the control plane, verify your local surface, and enter the first
                    founder-grade workflow with the new command deck.</p>"""
    )
]

pl_replacements = [
    (
"""                    <p class="manifesto-quote">
                        Framework, który stworzył sam siebie.
                    </p>""",
"""                    <p class="manifesto-quote">
                        Framework, który napisał swój własny kod przez <span class="manifesto-quote__accent">𝚅𝚒𝚋𝚎𝚌𝚛𝚊𝚏𝚝𝚜𝚖𝚊𝚗𝚜𝚑𝚒𝚙</span>.
                    </p>"""
    ),
    (
"""                <div class="science-prose fade-up">
                    <h2>To nie magia.<br>To Computer Science.</h2>
                    <p>To słownictwo jest wyraziste, bo wyrosło z prawdziwych workflow founderów. Pod spodem stoi
                        konkretny model pracy z kontekstem, wariancją i sprawdzaniem, czy coś jest naprawdę gotowe.</p>
                </div>

                <div class="evidence-grid fade-up">
                    <div class="evidence-item">
                        <span class="evidence-num">01</span>
                        <h3>AST-Augmented Context</h3>
                        <p>LLM-y zawodzą, kiedy kodują na ślepo. Dzięki wyprowadzeniu pamięci architektonicznej do map
                            AST-augmented ݆𝚅𝚒𝚋𝚎𝚌𝚛𝚊𝚏𝚝𝚎𝚍.
                            utrzymuje modele frontier precyzyjnie osadzone w rzeczywistej strukturze repozytorium.</p>
                    </div>
                    <div class="evidence-item">
                        <span class="evidence-num">02</span>
                        <h3>Konwergencja stochastyczna</h3>
                        <p>Generowanie kodu jest stochastyczne. Pętla Marbles używa priority-weighted denoising loops,
                            żeby bezlitośnie redukować
                            wariancję i doprowadzić system do stanu gotowego do wdrożenia.</p>
                    </div>
                    <div class="evidence-item">
                        <span class="evidence-num">03</span>
                        <h3>𝚅𝚒𝚋𝚎𝚌𝚛𝚊𝚏𝚝𝚜𝚖𝚊𝚗𝚜𝚑𝚒𝚙 (SHACE)</h3>
                        <p>Structured Human-AI Collaborative Engineering. Otaczamy stochastyczne generowanie
                            deterministycznymi checkpointami
                            człowieka. Efekt to system, który rozumiesz i kontrolujesz.</p>
                    </div>
                </div>""",
"""                <div class="science-prose fade-up">
                    <h2>To nie magia.<br>To rygorystyczna inżynieria.</h2>
                    <p>To słownictwo jest wyraziste, bo zostało wykute pod presją czasu. Pod spodem stoi
                        konkretny model pracy z kontekstem, redukcją wariancji i ostateczną prawdą przed wydaniem.</p>
                </div>

                <div class="evidence-grid fade-up">
                    <div class="evidence-item">
                        <span class="evidence-num">01</span>
                        <h3>AST-Augmented Context</h3>
                        <p>LLM-y halucynują, kiedy kodują na ślepo. Dzięki wyprowadzeniu pamięci architektonicznej do map
                            AST-augmented ݆𝚅𝚒𝚋𝚎𝚌𝚛𝚊𝚏𝚝𝚎𝚍.
                            utrzymuje modele frontier precyzyjnie osadzone w Twoim kodzie źródłowym.</p>
                    </div>
                    <div class="evidence-item">
                        <span class="evidence-num">02</span>
                        <h3>Konwergencja stochastyczna</h3>
                        <p>Generowanie kodu jest stochastyczne. Pętla Marbles używa priority-weighted denoising loops,
                            żeby bezlitośnie redukować
                            wariancję i doprowadzić system do stanu gotowego do wdrożenia.</p>
                    </div>
                    <div class="evidence-item">
                        <span class="evidence-num">03</span>
                        <h3>𝚅𝚒𝚋𝚎𝚌𝚛𝚊𝚏𝚝𝚜𝚖𝚊𝚗𝚜𝚑𝚒𝚙</h3>
                        <p>Structured Human-AI Collaborative Engineering. Otaczamy stochastyczne generowanie
                            deterministycznymi checkpointami
                            człowieka. Efekt to system, któremu ufasz i który kontrolujesz.</p>
                    </div>
                </div>"""
    ),
    (
"""        <section class="runtime-view">
            <div class="container fade-up">
                <div class="section-label">Zależności runtime’u</div>
                <h2 class="section-title">Warstwa, na której opiera się framework.</h2>
                <p class="section-sub">Warstwa, która zakotwicza agentów frontier w rzeczywistej strukturze
                    repozytorium.</p>""",
"""        <section class="runtime-view">
            <div class="container fade-up">
                <div class="section-label">Zależności runtime’u</div>
                <h2 class="section-title">Narzędzia pod maską frameworka.</h2>
                <p class="section-sub">Warstwa, która zakotwicza agentów frontier w prawdzie repozytorium, zamiast w ich własnych halucynacjach.</p>"""
    ),
    (
"""        <section class="pipeline-section" id="pipeline">
            <div class="container fade-up">
                <div class="section-label">Metoda</div>
                <h2 class="section-title">Twórz &rarr; Domykaj &rarr; Wdrażaj</h2>
                <p class="section-sub">Model operacyjny klasy founderskiej do kształtowania, odszumiania i wdrażania
                    oprogramowania
                    z agentami AI.</p>""",
"""        <section class="pipeline-section" id="pipeline">
            <div class="container fade-up">
                <div class="section-label">Metoda</div>
                <h2 class="section-title">Twórz &rarr; Domykaj &rarr; Wdrażaj</h2>
                <p class="section-sub">Model operacyjny klasy founderskiej do kształtowania, odszumiania i wreszcie wdrażania oprogramowania z agentami AI.</p>"""
    ),
    (
"""        <section id="skills">
            <div class="container fade-up">
                <div class="section-label">Pakiet skilli</div>
                <h2 class="section-title">16 wyspecjalizowanych workflow</h2>
                <p class="section-sub">Procedury wykuwane pod presją. Napędzane przez modele frontier i strukturalne
                    rozumienie repozytorium.</p>""",
"""        <section id="skills">
            <div class="container fade-up">
                <div class="section-label">Pakiet skilli</div>
                <h2 class="section-title">16 workflow dla founderów</h2>
                <p class="section-sub">Twarde procedury wykuwane w okopach. Napędzane przez modele frontier i opartą na Rust inteligencję strukturalną.</p>"""
    ),
    (
"""                    <div class="manifesto-block">
                        <blockquote>Agenci AI rozwiązali najtrudniejszą część tworzenia oprogramowania: sprawienie, że
                            rzecz działa. Nie rozwiązali jeszcze drugiej najtrudniejszej: sprawienia, że da się do niej
                            dotrzeć.</blockquote>
                        <p class="manifesto-lead">Luka rzadko dotyczy jakości kodu. To przestrzeń między działającym
                            systemem
                            a produktem, który ludzie mogą odkryć, zainstalować, zrozumieć, zaufać mu i kupić.</p>
                        <p class="manifesto-diagnostic-label">Diagnoza Plague:</p>""",
"""                    <div class="manifesto-block">
                        <blockquote>Agenci AI rozwiązali najtrudniejszą część tworzenia oprogramowania: sprawienie, że
                            rzecz działa. Nie rozwiązali jeszcze drugiej najtrudniejszej: sprawienia, że da się do niej
                            dotrzeć.</blockquote>
                        <p class="manifesto-lead">Luka rzadko dotyczy jakości kodu. To brutalna przestrzeń między działającym
                            systemem
                            a produktem, który obcy mogą odkryć, zainstalować, zrozumieć, zaufać mu i kupić.</p>
                        <p class="manifesto-diagnostic-label">Diagnoza Foundera:</p>"""
    ),
    (
"""        <section id="get">
            <div class="container fade-up">
                <div class="section-label">Instalacja ݆𝚅𝚒𝚋𝚎𝚌𝚛𝚊𝚏𝚝𝚎𝚍.</div>
                <h2 class="section-title">Zainstaluj framework. Uruchom pętlę.</h2>
                <p class="section-sub">Zainstaluj framework, sprawdź, czy wszystko działa, i uruchom pierwszy workflow.
                </p>""",
"""        <section id="get">
            <div class="container fade-up">
                <div class="section-label">Instalacja ݆𝚅𝚒𝚋𝚎𝚌𝚛𝚊𝚏𝚝𝚎𝚍.</div>
                <h2 class="section-title">Zainstaluj framework. Uruchom pętlę.</h2>
                <p class="section-sub">Podnieś środowisko kontrolne, zweryfikuj swoją powierzchnię lokalną i wejdź w pierwszy founder-grade workflow.
                </p>"""
    )
]

update_file('docs/index.html', en_replacements)
update_file('docs/pl/index.html', pl_replacements)

