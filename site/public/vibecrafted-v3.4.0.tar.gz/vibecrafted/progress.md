Original prompt: Uwolnić framework playground z embedu, zrobić board-first standalone experience z manualnym phase rail, większą planszą, monotype HUD-em i kierunkiem pod 1.3.0 game-like flow.

- 2026-03-30: Removed the experimental framework playground from docs/index.html and replaced it with a teaser card linking to presence/framework.html.
- Reason: the embedded surface was destabilizing the landing page and the interaction model needs more than a quick afternoon patch.
- Next: continue the board-first redesign on the standalone page only.
- 2026-03-30: Added reciprocal homepage/demo navigation. `docs/index.html` now exposes `Demo` in the top navbar and `docs/presence/framework.html` now links back with `GO BACK TO HOMEPAGE`.
- 2026-03-30: Spawned external `vc-agents` tracks for standalone extraction and cleanup:
  - Codex: standalone shell extraction and `framework.css`
  - Gemini: manual-flow hardening in `framework.js`
  - Claude: boundary audit for shared vs standalone surface ownership
- 2026-03-31: Began polish pass on `docs/presence/framework.*` for the standalone playground.
- Focus: remove inner right-rail scroll, move phase hint higher in the operator stack, split `Scaffold` from `Workflow`, and align the phase rail with real 𝚅𝚒𝚋𝚎𝚌𝚛𝚊𝚏𝚝𝚎𝚍. skills instead of side effects.
- Direction correction from operator review: use `scaffold -> init -> research -> workflow` at the front of the rail; `overflow` and `P0` remain simulation outcomes, not phase buttons.
- 2026-03-31: Fixed live marbles automation in the standalone playground. `RUN MARBLES` now launches the full `--count` sequence from the operator rail, the prompt reflects `vc-marbles --count N`, and the hidden click-on-board trigger was removed.
- 2026-03-31: Reflowed the standalone grid so the phase pressline spans both columns. The board stage and right operator rail now start from the same visual row instead of drifting on separate vertical anchors.
- 2026-03-31: Verified with Playwright on `http://127.0.0.1:4173/docs/presence/framework.html`: clicking `Marbles` then `RUN MARBLES` produced `Marbles: 32` for `--count 4` and continued increasing `Converge` without further board interaction.

- 2026-03-31: Fixed live marbles automation in framework playground. `RUN MARBLES` now relies on explicit operator controls instead of hidden board clicks, and the prompt exposes `vc-marbles --count N` while the timer counts down in the live loop.
- 2026-03-31: Reflowed the standalone layout so the phase pressline spans both columns; board and operator rail now start from the same visual row instead of drifting on separate vertical anchors.
