# Structural Map

Project: `/Users/polyversai/Libraxis/vc-runtime/vibecrafted`
Snapshot: `release/v2.0.1@f4ec430`

This card contains dependency and symbol topology for the selected scope.

```json
{
  "consumers": [],
  "entrypoints": [],
  "files": [],
  "imports": [],
  "symbols": []
}
```

## What this card does not cover

This Structural Map does not include runtime behavior, env contracts, or verification gates. Read `02-runtime-map.md` and `04-verification-gates.md` before changing behavior.
