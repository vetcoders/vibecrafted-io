#!/usr/bin/env python3
"""Produce the receipts consumed by the fail-closed unified product verifier."""

from __future__ import annotations

import argparse
import hashlib
import ipaddress
import json
import os
import plistlib
import re
import stat
import subprocess
import tarfile
from pathlib import Path
from typing import Any
from urllib.parse import urlsplit

from vibecrafted_core import product_contract as contract
from vibecrafted_core import runtime_pack_contract

# Fixed main-app terminal and its helpers are executable payload.
_DECLARED_CODE = {
    "Contents/MacOS/vc-terminal",
    "Contents/Helpers/vc-frame",
    "Contents/Resources/runtime/bin/vc-start",
}


def _write(path: Path, payload: dict[str, Any], *, canonical: bool = False) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    separators = (",", ":") if canonical else None
    path.write_text(
        json.dumps(payload, ensure_ascii=False, sort_keys=True, separators=separators)
        + "\n",
        encoding="utf-8",
    )


def validate_update_feed_url(raw: str) -> str:
    """Package a locator admitted by ProductUpdatePolicy's HTTPS contract.

    Packaging additionally refuses local origins and ambiguous URL spellings;
    it never normalizes the approved input or changes release trust metadata.
    """
    invalid = "update feed must be an explicit well-formed public HTTPS URL"
    if (
        not raw
        or not raw.isascii()
        or any(char.isspace() or ord(char) < 32 or ord(char) == 127 for char in raw)
        or "\\" in raw
        or re.search(r"%(?![0-9a-fA-F]{2})", raw)
        or "#" in raw
    ):
        raise SystemExit(invalid)
    try:
        url = urlsplit(raw)
        host = (url.hostname or "").lower().rstrip(".")
        port = url.port
    except ValueError:
        raise SystemExit(invalid) from None
    if (
        url.scheme.lower() != "https"
        or not host
        or url.username is not None
        or url.password is not None
        or (port is not None and not 1 <= port <= 65535)
        or url.netloc.endswith(":")
    ):
        raise SystemExit(invalid)
    try:
        address = ipaddress.ip_address(host)
    except ValueError:
        labels = host.split(".")
        if (
            len(labels) < 2
            or len(host) > 253
            or host.endswith((".local", ".localhost", ".internal", ".home", ".lan"))
            or all(label.isdigit() for label in labels)
            or any(
                not re.fullmatch(r"[a-z0-9](?:[a-z0-9-]{0,61}[a-z0-9])?", label)
                for label in labels
            )
        ):
            raise SystemExit(invalid)
    else:
        if not address.is_global:
            raise SystemExit(invalid)
    return raw


def configure_update_channel(args: argparse.Namespace) -> None:
    feed = None if args.unprovisioned else validate_update_feed_url(args.feed_url)
    receipt: dict[str, Any] = {
        "status": "unprovisioned" if feed is None else "configured",
        "feed_url": feed,
    }
    if args.app is not None:
        plist_path = args.app / "Contents/Info.plist"
        if plist_path.is_symlink() or not plist_path.is_file():
            raise SystemExit("update channel requires a regular Info.plist")
        with plist_path.open("rb") as handle:
            plist = plistlib.load(handle)
        if args.verify_only:
            if (feed is None and "VCUpdateFeedURL" in plist) or (
                feed is not None and plist.get("VCUpdateFeedURL") != feed
            ):
                raise SystemExit(
                    "packaged VCUpdateFeedURL does not match explicit input"
                )
        else:
            if (args.app / "Contents/_CodeSignature").exists():
                raise SystemExit("refusing update channel mutation of a signed App")
            if feed is None:
                plist.pop("VCUpdateFeedURL", None)
            else:
                plist["VCUpdateFeedURL"] = feed
            with plist_path.open("wb") as handle:
                plistlib.dump(plist, handle, sort_keys=True)
        receipt["info_plist_sha256"] = contract._sha256(plist_path)
    elif args.verify_only:
        raise SystemExit("--verify-only requires --app")
    print(json.dumps(receipt, sort_keys=True))


def configure_host_permissions(args: argparse.Namespace) -> None:
    """Assemble privacy metadata before signing, or inspect the sealed result.

    Used by the release builder and the safe temporary-bundle packaging probe.
    It never signs code, launches the host, or calls a privacy API.
    """
    app = args.app
    runtime = args.runtime_root
    source = (
        Path(__file__).resolve().parents[1]
        / "vibecrafted-app/shell-agent/app/Vibecrafted"
    )
    entitlements = plistlib.loads((source / "Vibecrafted.entitlements").read_bytes())
    if (
        not isinstance(entitlements, dict)
        or entitlements.keys() != contract.HOST_ENTITLEMENTS.keys()
        or entitlements.get("com.apple.security.device.audio-input") is not True
    ):
        raise SystemExit(
            "host signing input differs from the release entitlement policy"
        )
    if runtime is not None:
        if args.verify_signatures and not args.verify_only:
            raise SystemExit("--verify-signatures requires --verify-only")
        if args.verify_only:
            if args.verify_signatures:
                contract._verify_host_permission_signatures(
                    runtime, targets=(runtime / "libexec/vc-terminal",)
                )
        else:
            if args.entitlements_output is None:
                raise SystemExit("host assembly requires --entitlements-output")
            args.entitlements_output.parent.mkdir(parents=True, exist_ok=True)
            args.entitlements_output.write_bytes(plistlib.dumps(entitlements))
        print(
            json.dumps(
                {
                    "entitlements": entitlements,
                    "hardened_runtime": True,
                    "signing_targets": ["libexec/vc-terminal"],
                    "signatures_verified": bool(
                        args.verify_only and args.verify_signatures
                    ),
                    "live_consent_verified": False,
                },
                sort_keys=True,
            )
        )
        return
    plist_path = app / "Contents/Info.plist"
    if plist_path.is_symlink() or not plist_path.is_file():
        raise SystemExit("host permissions require a regular Info.plist")
    plist = plistlib.loads(plist_path.read_bytes())
    if (
        not isinstance(plist, dict)
        or plist.get("CFBundleIdentifier") != contract.PRODUCT_BUNDLE_ID
    ):
        raise SystemExit("host permissions require the canonical app identity")
    if args.verify_only:
        contract._validate_host_usage_descriptions(plist)
        if args.verify_signatures:
            contract._verify_host_permission_signatures(app)
    else:
        if args.verify_signatures:
            raise SystemExit("--verify-signatures requires --verify-only")
        if (app / "Contents/_CodeSignature").exists():
            raise SystemExit("refusing host permission mutation of a signed App")
        if args.entitlements_output is None:
            raise SystemExit("host assembly requires --entitlements-output")
        canonical = plistlib.loads((source / "Info.plist").read_bytes())
        contract._validate_host_usage_descriptions(canonical)
        for key in contract.HOST_USAGE_DESCRIPTION_KEYS:
            plist[key] = canonical[key]
        args.entitlements_output.parent.mkdir(parents=True, exist_ok=True)
        args.entitlements_output.write_bytes(plistlib.dumps(entitlements))
        plist_path.write_bytes(plistlib.dumps(plist))
    print(
        json.dumps(
            {
                "usage_descriptions": {
                    key: plist[key] for key in contract.HOST_USAGE_DESCRIPTION_KEYS
                },
                "entitlements": contract.HOST_ENTITLEMENTS,
                "hardened_runtime": True,
                "signing_targets": ["Vibecrafted.app", "Contents/MacOS/vc-terminal"],
                "signatures_verified": bool(
                    args.verify_only and args.verify_signatures
                ),
                "live_consent_verified": False,
            },
            sort_keys=True,
        )
    )


def _entry(root: Path, relative: str, *, kind: str | None = None) -> dict[str, Any]:
    path = root / relative
    if kind is None:
        if relative in _DECLARED_CODE:
            kind = "executable"
        elif path.suffix == ".dylib":
            kind = "dylib"
        elif (
            (relative.startswith("Contents/MacOS/") or "/Contents/MacOS/" in relative)
            and os.access(path, os.X_OK)
            or (
                (
                    "/python/bin/" in relative
                    or relative.startswith(
                        (
                            "Contents/Resources/runtime/bin/",
                            "Contents/Resources/runtime/libexec/",
                        )
                    )
                )
                and os.access(path, os.X_OK)
                and "Mach-O"
                in subprocess.run(
                    ["/usr/bin/file", "-b", str(path)],
                    check=True,
                    capture_output=True,
                    text=True,
                ).stdout
            )
        ):
            kind = "executable"
        elif path.suffix in {".json", ".plist", ".toml", ".kdl", ".yaml", ".yml"}:
            kind = "config"
        else:
            kind = "resource"
    dylibs: list[str] = []
    if kind in {"executable", "dylib"}:
        observed = contract._observed_macho(path, relative=relative, kind=kind)
        if observed is None:
            raise SystemExit(f"declared code is not Mach-O: {relative}")
        dylibs = list(observed.dependencies)
    return {
        "path": relative,
        "sha256": contract._sha256(path),
        "mode": f"{stat.S_IMODE(path.stat().st_mode):04o}",
        "kind": kind,
        "size": path.stat().st_size,
        "dylibs": dylibs,
    }


def _module(
    app: Path,
    *,
    name: str,
    source: Path,
    product_relative: str,
    git_sha: str,
    version: str,
) -> dict[str, Any]:
    entrypoint = "terminal" if name == "vc-terminal" else "frame"
    module_relative = f"bin/{name}"
    source_entry = _entry(source.parent, source.name, kind="executable")
    source_entry["path"] = module_relative
    manifest = {
        "schema": contract.MODULE_SCHEMA,
        "module": name,
        "version": version,
        "git_sha": git_sha,
        "dirty": False,
        "architecture": "arm64",
        "minimum_macos": "14.0",
        "files": [source_entry],
        "entrypoints": {entrypoint: module_relative},
    }
    manifest_relative = (
        f"Contents/Resources/module-receipts/{name}/module-manifest.json"
    )
    _write(app / manifest_relative, manifest)
    manifest_hash = contract._sha256(app / manifest_relative)
    product_entry = _entry(app, product_relative, kind="executable")
    assembly = {
        "schema": contract.ASSEMBLY_SCHEMA,
        "module": name,
        "module_manifest_sha256": manifest_hash,
        "files": [
            {
                "module_path": module_relative,
                "product_path": product_relative,
                "unsigned_sha256": source_entry["sha256"],
                "product_sha256": product_entry["sha256"],
                "transformation": "codesign",
            }
        ],
    }
    assembly_relative = (
        f"Contents/Resources/module-receipts/{name}/assembly-receipt.json"
    )
    _write(app / assembly_relative, assembly)
    return {
        "module": name,
        "manifest_path": manifest_relative,
        "manifest_sha256": manifest_hash,
        "assembly_receipt_path": assembly_relative,
        "assembly_receipt_sha256": contract._sha256(app / assembly_relative),
        "git_sha": git_sha,
    }


def produce_app(args: argparse.Namespace) -> None:
    app = args.app.resolve()
    plist_path = app / "Contents/Info.plist"
    with plist_path.open("rb") as handle:
        plist = plistlib.load(handle)
    plist["CFBundleIdentifier"] = contract.PRODUCT_BUNDLE_ID
    plist["CFBundleExecutable"] = contract.PRODUCT_EXECUTABLE
    plist["CFBundleIconFile"] = contract.PRODUCT_ICON_FILE
    plist["CFBundleShortVersionString"] = args.version
    plist["CFBundleVersion"] = args.build
    with plist_path.open("wb") as handle:
        plistlib.dump(plist, handle, sort_keys=True)

    modules = [
        _module(
            app,
            name="vc-terminal",
            source=args.terminal_source.resolve(),
            product_relative="Contents/MacOS/vc-terminal",
            git_sha=args.terminal_sha,
            version=args.version,
        ),
        _module(
            app,
            name="vc-frame",
            source=args.frame_source.resolve(),
            product_relative="Contents/Helpers/vc-frame",
            git_sha=args.frame_sha,
            version=args.version,
        ),
    ]
    manifest_relative = Path("Contents/Resources/product-manifest.json")
    outer_relative = "Contents/MacOS/Vibecrafted"
    excluded = {
        manifest_relative.as_posix(),
        outer_relative,
    }
    files: list[dict[str, Any]] = []
    for path in sorted(app.rglob("*")):
        relative = path.relative_to(app)
        relative_text = relative.as_posix()
        # Not "anything called _CodeSignature": that blanket rule would also
        # exempt an undeclared nested bundle from ever being inventoried, and
        # the verifier would then be arguing with a manifest that never named
        # it. Ask the contract for the exact paths the signer owns.
        if (
            not path.is_file()
            or path.is_symlink()
            or relative_text in excluded
            or contract.is_signature_inventory_artifact(relative_text)
        ):
            continue
        files.append(_entry(app, relative_text))
    outer = app / outer_relative
    observed = contract._observed_macho(
        outer, relative=outer_relative, kind="executable"
    )
    if observed is None:
        raise SystemExit("outer executable is not Mach-O")
    product = {
        "schema": contract.PRODUCT_SCHEMA,
        "product": contract.PRODUCT_NAME,
        "bundle_id": contract.PRODUCT_BUNDLE_ID,
        "bundle_executable": contract.PRODUCT_EXECUTABLE,
        "version": args.version,
        "build": args.build,
        "git_sha": args.vibecrafted_sha,
        "dirty": False,
        "architecture": "arm64",
        "minimum_macos": "14.0",
        "modules": modules,
        "outer_bundle_code": {
            "identity": contract.OUTER_BUNDLE_CODE_IDENTITY,
            "path": outer_relative,
            "mode": f"{stat.S_IMODE(outer.stat().st_mode):04o}",
            "kind": "executable",
            "architecture": "arm64",
            "minimum_macos": "14.0",
            "dylibs": list(observed.dependencies),
            "code_identity": contract.MACHO_CODE_IDENTITY,
            "code_sha256": contract._macho_code_sha256(outer),
            "info_plist_sha256": contract._sha256(plist_path),
            "codesign_identifier": contract.PRODUCT_BUNDLE_ID,
        },
        "files": files,
        "entrypoints": {
            "app": outer_relative,
            "terminal": "Contents/MacOS/vc-terminal",
            "frame": "Contents/Helpers/vc-frame",
        },
        "launch_contract": contract._canonical_launch_contract(),
    }
    _write(app / manifest_relative, product)


def produce_release(args: argparse.Namespace) -> None:
    root = args.output.parent.resolve()
    app = args.app.resolve()
    dmg = args.dmg.resolve()
    product_path = app / "Contents/Resources/product-manifest.json"
    product = json.loads(product_path.read_text(encoding="utf-8"))
    modules = {item["module"]: item for item in product["modules"]}
    executable = app / product["outer_bundle_code"]["path"]
    signer = contract._codesign_release_evidence(app)
    policy = contract._release_policy()
    runtime_pack = args.runtime_pack.resolve()
    embedded_runtime_pack = app / "Contents/Resources/runtime-pack" / runtime_pack.name
    if (
        runtime_pack.stat().st_size != embedded_runtime_pack.stat().st_size
        or contract._sha256(runtime_pack) != contract._sha256(embedded_runtime_pack)
    ):
        raise SystemExit(
            "standalone Runtime Pack bytes differ from the App-embedded carrier"
        )
    with tarfile.open(runtime_pack, "r:gz") as archive:
        member = archive.getmember(
            f"VibecraftedRuntime/{runtime_pack_contract.PROVENANCE_NAME}"
        )
        extracted = archive.extractfile(member)
        if extracted is None:
            raise SystemExit("Runtime Pack provenance cannot be read")
        provenance_raw = extracted.read()
    provenance = json.loads(provenance_raw.decode("utf-8"))
    expected_revisions = {
        "vibecrafted": product["git_sha"],
        "vc-terminal": modules["vc-terminal"]["git_sha"],
        "vc-frame": modules["vc-frame"]["git_sha"],
    }
    if provenance.get("source_revisions") != expected_revisions:
        raise SystemExit("Runtime Pack provenance disagrees with the product sources")
    payload = {
        "schema": contract.RELEASE_OUTPUT_SCHEMA,
        "signature_policy": {
            "algorithm": policy["algorithm"],
            "key_id": "vibecrafted-signing-v1",
            "spki_sha256": policy["public_key_spki_sha256"],
        },
        "product": {
            "version": product["version"],
            "build": product["build"],
            "architecture": product["architecture"],
            "minimum_macos": product["minimum_macos"],
            "manifest": {
                "path": "Contents/Resources/product-manifest.json",
                "sha256": contract._sha256(product_path),
            },
        },
        "outer_executable": {
            "path": product["outer_bundle_code"]["path"],
            "sha256": contract._sha256(executable),
            "code_identity": contract.MACHO_CODE_IDENTITY,
            "code_sha256": contract._macho_code_sha256(executable),
            "cdhash": signer["cdhash"],
            "signer_policy": {
                "team_id": policy["team_id"],
                "designated_requirement": policy["designated_requirement"],
                "hardened_runtime": policy["hardened_runtime"],
                "entitlements": policy["entitlements"],
            },
        },
        "code_resources": {
            "path": "Contents/_CodeSignature/CodeResources",
            "sha256": contract._sha256(app / "Contents/_CodeSignature/CodeResources"),
        },
        "dmg": {
            "path": dmg.name,
            "sha256": contract._sha256(dmg),
            "size": dmg.stat().st_size,
        },
        "runtime_pack": {
            "path": runtime_pack.name,
            "embedded_path": (f"Contents/Resources/runtime-pack/{runtime_pack.name}"),
            "sha256": contract._sha256(runtime_pack),
            "size": runtime_pack.stat().st_size,
            "provenance": {
                "path": runtime_pack_contract.PROVENANCE_NAME,
                "sha256": hashlib.sha256(provenance_raw).hexdigest(),
                "version": provenance["version"],
                "platform": provenance["platform"],
                "architecture": provenance["architecture"],
                "source_revisions": provenance["source_revisions"],
            },
        },
        "modules": {
            name: {
                "manifest": {
                    "path": binding["manifest_path"],
                    "sha256": binding["manifest_sha256"],
                },
                "assembly_receipt": {
                    "path": binding["assembly_receipt_path"],
                    "sha256": binding["assembly_receipt_sha256"],
                },
                "git_sha": binding["git_sha"],
            }
            for name, binding in modules.items()
        },
        "source_revisions": {
            "vibecrafted": product["git_sha"],
            "vc-terminal": modules["vc-terminal"]["git_sha"],
            "vc-frame": modules["vc-frame"]["git_sha"],
        },
        "notarization": {
            "app": {"ticket": True, "gatekeeper": True},
            "dmg": {"codesign": True, "ticket": True, "gatekeeper": True},
        },
    }
    if dmg.parent != root or not contract.is_canonical_release_dmg_name(
        dmg.name,
        version=product["version"],
        source_revision=product["git_sha"],
    ):
        raise SystemExit(
            "release DMG must be a canonical sibling bound to version, date, and source"
        )
    _write(args.output, payload, canonical=True)


def main() -> int:
    parser = argparse.ArgumentParser()
    commands = parser.add_subparsers(dest="command", required=True)
    app = commands.add_parser("app")
    app.add_argument("--app", type=Path, required=True)
    app.add_argument("--terminal-source", type=Path, required=True)
    app.add_argument("--frame-source", type=Path, required=True)
    app.add_argument("--version", required=True)
    app.add_argument("--build", required=True)
    app.add_argument("--vibecrafted-sha", required=True)
    app.add_argument("--terminal-sha", required=True)
    app.add_argument("--frame-sha", required=True)
    release = commands.add_parser("release")
    release.add_argument("--app", type=Path, required=True)
    release.add_argument("--dmg", type=Path, required=True)
    release.add_argument("--runtime-pack", type=Path, required=True)
    release.add_argument("--output", type=Path, required=True)
    channel = commands.add_parser("update-channel")
    choice = channel.add_mutually_exclusive_group(required=True)
    choice.add_argument("--feed-url")
    choice.add_argument("--unprovisioned", action="store_true")
    channel.add_argument("--app", type=Path)
    channel.add_argument("--verify-only", action="store_true")
    permissions = commands.add_parser("host-permissions")
    permission_root = permissions.add_mutually_exclusive_group(required=True)
    permission_root.add_argument("--app", type=Path)
    permission_root.add_argument("--runtime-root", type=Path)
    permissions.add_argument("--entitlements-output", type=Path)
    permissions.add_argument("--verify-only", action="store_true")
    permissions.add_argument("--verify-signatures", action="store_true")
    args = parser.parse_args()
    if args.command == "app":
        produce_app(args)
    elif args.command == "release":
        produce_release(args)
    elif args.command == "host-permissions":
        configure_host_permissions(args)
    else:
        configure_update_channel(args)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
