#!/usr/bin/env bash
set -euo pipefail

log() { printf '\n==> %s\n' "$*"; }
die() {
  # Dual-stream FATAL so `zsh -ic` / redirected make logs cannot swallow the
  # reason (HAK-72). Also append to the release log when BUILD_DIR exists.
  local msg="FATAL: $*"
  printf '%s\n' "$msg" >&2
  printf '%s\n' "$msg"
  if [[ -n "${BUILD_DIR:-}" ]]; then
    mkdir -p "$BUILD_DIR" 2>/dev/null || true
    printf '%s\n' "$msg" >> "$BUILD_DIR/release.log" 2>/dev/null || true
  fi
  exit 1
}
require() { command -v "$1" >/dev/null 2>&1 || die "$1 is required"; }

RELEASE_TOOLCHAIN_CONTRACT="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)/lib/release-toolchain-contract.sh"
# resolved from this script's canonical directory
. "$RELEASE_TOOLCHAIN_CONTRACT"

MODE="release"
SNAPSHOT_DONORS=0
UNPROVISIONED_UPDATE_CHANNEL=0
for argument in "$@"; do
  case "$argument" in
    --app-only) MODE="app" ;;
    --runtime-pack-only) MODE="runtime-pack" ;;
    --no-notarize) MODE="dmg" ;;
    --notarize-only) MODE="notarize" ;;
    --snapshot-donors) SNAPSHOT_DONORS=1 ;;
    --unprovisioned-update-channel) UNPROVISIONED_UPDATE_CHANNEL=1 ;;
    --help|-h)
      echo "usage: $0 [--app-only|--runtime-pack-only|--no-notarize|--notarize-only] [--snapshot-donors] [--unprovisioned-update-channel]" >&2
      echo "App builds use the approved GitHub Releases feed; VIBECRAFTED_UPDATE_FEED_URL can explicitly override it. Unprovisioned is for developer app/dmg only." >&2
      exit 0
      ;;
    *)
      echo "usage: $0 [--app-only|--runtime-pack-only|--no-notarize|--notarize-only] [--snapshot-donors] [--unprovisioned-update-channel]" >&2
      exit 2
      ;;
  esac
done

prefer_rustup_cargo() {
  # Homebrew `rust` (helix-db/pake) often shadows rustup on login PATH and
  # then `cargo leptos` dies with a content-free wasm32 E0463. Prefer rustup.
  if [[ -d "${HOME}/.cargo/bin" ]]; then
    PATH="${HOME}/.cargo/bin:${PATH}"
    export PATH
  fi
  if command -v rustup >/dev/null 2>&1; then
    local rustup_cargo
    rustup_cargo="$(rustup which cargo 2>/dev/null || true)"
    if [[ -n "$rustup_cargo" && -x "$rustup_cargo" ]]; then
      PATH="$(dirname "$rustup_cargo"):${PATH}"
      export PATH
    fi
  fi
}
# A --remap-path-prefix whose prefix still contains `..` never matches the path
# the compiler actually sees, because the match is textual. The donor roots used
# to be plain concatenations ("$REPO_ROOT/../vc-terminal"), so both donor remaps
# silently missed every file: measured on the shipped 4.1.0 payload
# (Vibecrafted_4.1.0-20260817-237d2814.dmg, roadmap 4.2.0 cut W0-a), the strings
# `/usr/src/vc-frame` and `/usr/src/vc-terminal` are ABSENT from every binary
# while `/Volumes/<...>/vc-frame` and `/Volumes/<...>/vc-terminal` are present in
# Contents/Helpers/vc-frame, Contents/MacOS/Vibecrafted, Contents/MacOS/voc and
# the bundled alacritty. Resolve the donor roots; never concatenate them.
canonical_dir() {
  local target="$1"
  (cd "$target" >/dev/null 2>&1 && pwd) || die "missing donor directory: $target"
}

REPO_ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"

# A regular shared build lease covers the complete chain, including gaps and
# child commands. A marker/env boolean cannot stand in for an inherited FD.
if ! "$REPO_ROOT/scripts/project-python" - "$REPO_ROOT/build/.vc-build-lease" \
  "${VIBECRAFTED_BUILD_LEASE_FD:-}" <<'PY'
import fcntl, os, stat, sys
try:
    fd = int(sys.argv[2])
    current = os.lstat(sys.argv[1])
    held = os.fstat(fd)
    if not stat.S_ISREG(current.st_mode) or held.st_nlink != 1 or held.st_uid != os.getuid() or (held.st_dev, held.st_ino) != (current.st_dev, current.st_ino):
        raise ValueError('not the build lease')
    fcntl.flock(fd, fcntl.LOCK_SH | fcntl.LOCK_NB)
except (ValueError, OSError):
    raise SystemExit(1)
PY
then
  lease_roots=()
  [[ -z "${CARGO_TARGET_DIR:-}" ]] || lease_roots+=(--lease-root "$CARGO_TARGET_DIR")
  for donor in "${VIBECRAFTED_TERMINAL_REPO:-$REPO_ROOT/../vc-terminal}" \
    "${VIBECRAFTED_FRAME_REPO:-$REPO_ROOT/../vc-frame}"; do
    [[ ! -d "$donor" ]] || lease_roots+=(--lease-root "$donor/target")
  done
  exec "$REPO_ROOT/scripts/vc-build-lease" --root "$REPO_ROOT/build" \
    "${lease_roots[@]}" -- /bin/bash "$REPO_ROOT/scripts/build-vibecrafted-release.sh" "$@"
fi

# The build -> install handoff record is owned by this library, and it is loaded
# HERE rather than beside the other libraries further down: the claim it makes
# has to happen before the first thing that can fail, and the donor roots, the
# release date and the Xcode preflight all die above that point.
# shellcheck source=/dev/null
. "$REPO_ROOT/scripts/lib/runtime-pack-selection.sh"
# shellcheck source=/dev/null
. "$REPO_ROOT/scripts/lib/release-single-flight.sh"

ROOT_SHA="$(git -C "$REPO_ROOT" rev-parse HEAD)"

# Exclusive ownership of the shared selection, snapshot and App/output paths
# BEFORE any of those mutate. --help/-h and unknown argv have already exited
# above, so usage never takes the lock or creates build/. --notarize-only
# shares APP, DIST and BUILD_DIR with a full release, so it takes the same
# lock and still leaves the selection record untouched.
release_single_flight_acquire "$REPO_ROOT" \
  || die "another release already owns this checkout's shared build state"

cleanup() {
  # Host-wide resources first. The keychain session mutates state that outlives
  # this process and affects every application on the machine; the donor
  # snapshots are directories under this repo's own build/ and a stale one is
  # merely untidy. Reaping first meant a hung `git worktree remove` — an index
  # lock on a busy donor is enough — would strand the keychain instead.
  #
  # In practice keychain_session_begin also arms its own EXIT handler which
  # chains ahead of this one, so the keychain is usually already released by the
  # time we arrive. That path does not exist when no signing certificate was
  # present, which is exactly when this ordering is the only ordering.
  #
  # Both release descriptors stay held through reap: unlocking first would
  # let a successor recreate donor-snapshots/vibecrafted or take a shared
  # output dir, after which this EXIT handler would destroy the successor's
  # frozen source. Closing our own descriptors is last, and never unlinks
  # the lock inodes. This function returns; INT/TERM/HUP then exit so no
  # release work continues after unlock.
  if declare -F keychain_session_end >/dev/null 2>&1; then
    keychain_session_end "$SIGNING_KEYCHAIN_LABEL" || true
  fi
  if declare -F donor_snapshot_reap >/dev/null 2>&1; then
    donor_snapshot_reap || true
  fi
  release_single_flight_release
}
# INT/TERM/HUP must exit after cleanup. A bare shared trap returns into the
# interrupted command and would keep mutating after the lock was released.
# keychain_session_begin reads these handlers back and chains in front.
trap cleanup EXIT
trap 'cleanup; exit 130' INT
trap 'cleanup; exit 143' TERM
trap 'cleanup; exit 129' HUP

# Output may be redirected off this checkout. Take that lock before the
# selection claim so two roots cannot mark pending and then contend for one
# dist. A dist that stays under REPO_ROOT is already covered.
DIST_DIR="${VIBECRAFTED_RELEASE_DIR:-$REPO_ROOT/dist}"
case "$DIST_DIR" in
  /*) ;;
  *) DIST_DIR="$PWD/$DIST_DIR" ;;
esac
release_single_flight_acquire_output "$REPO_ROOT" "$DIST_DIR" \
  || die "another release already owns this output directory"

# Claim the attempt before the first thing that can fail.
#
# An unusable argument has already exited above, so `--help`-shaped misuse never
# touches the record. --notarize-only re-runs notarization for an App that
# already exists and produces no new carrier, so it must leave the record
# exactly as it found it. Every other mode reaches produce_runtime_pack, and
# from here on ANYTHING may die: a missing donor directory, a malformed
# VIBECRAFTED_RELEASE_DATE, a beta Xcode, cargo, codesign, the packager. A build
# that dies must not leave the previous success standing as the implicit answer
# to `make install` -- not even when the failed retry runs at the very same
# source SHA, which no name derived from HEAD could tell apart.
RUNTIME_PACK_SELECTION_ATTEMPT=""
if [[ "$MODE" != "notarize" ]]; then
  RUNTIME_PACK_SELECTION_ATTEMPT="$(runtime_pack_selection_attempt_id)"
  runtime_pack_selection_begin "$REPO_ROOT" "$RUNTIME_PACK_SELECTION_ATTEMPT" \
    "$ROOT_SHA" \
    || die "could not mark the Runtime Pack build attempt as pending"
  DONOR_SNAPSHOT_OWNER="$RUNTIME_PACK_SELECTION_ATTEMPT"
  export DONOR_SNAPSHOT_OWNER
fi

# Bind the approved GitHub default or exact caller override once (Founder
# approval 2026-10-01). The same arguments configure the unsigned
# App and verify it after signing; notarize-only gets verification, never writes.
# Runtime-Pack-only produces no App and therefore has no feed requirement.
UPDATE_CHANNEL_ARGS=()
validate_update_channel() {
  if (( UNPROVISIONED_UPDATE_CHANNEL )); then
    [[ "$MODE" == "app" || "$MODE" == "dmg" ]] \
      || die "unprovisioned Update channel is allowed only for developer app/dmg builds"
    [[ ! ${VIBECRAFTED_UPDATE_FEED_URL+x} ]] \
      || die "choose an explicit feed or unprovisioned Update channel, not both"
    UPDATE_CHANNEL_ARGS=(--unprovisioned)
  elif [[ "$MODE" == "runtime-pack" ]]; then
    return
  else
    UPDATE_CHANNEL_ARGS=(--feed-url "${VIBECRAFTED_UPDATE_FEED_URL-https://github.com/vetcoders/vibecrafted/releases/latest/download/release-output.json}")
  fi
  PYTHONPATH="$REPO_ROOT/vibecrafted-core" "$REPO_ROOT/scripts/project-python" \
    "$REPO_ROOT/scripts/unified_product_manifest.py" update-channel \
    "${UPDATE_CHANNEL_ARGS[@]}" \
    || die "invalid explicit Update channel"
}
configure_update_channel() {
  PYTHONPATH="$SOURCE_ROOT/vibecrafted-core" "$SOURCE_ROOT/scripts/project-python" \
    "$SOURCE_ROOT/scripts/unified_product_manifest.py" update-channel \
    "${UPDATE_CHANNEL_ARGS[@]}" --app "$APP" \
    || die "could not configure unsigned App Update channel"
}
verify_update_channel() {
  mkdir -p "$BUILD_DIR"
  PYTHONPATH="$REPO_ROOT/vibecrafted-core" "$REPO_ROOT/scripts/project-python" \
    "$REPO_ROOT/scripts/unified_product_manifest.py" update-channel \
    "${UPDATE_CHANNEL_ARGS[@]}" --app "$APP" --verify-only \
    > "$BUILD_DIR/update-channel-receipt.json" \
    || die "packaged App Update channel differs from explicit input"
}
validate_update_channel

# The donor is where the source lives; the repo is what we compile. They differ
# only under --snapshot-donors, where the repo becomes a detached worktree at the
# donor HEAD so a dirty Living Tree donor can still produce an honest receipt.
#
# Main product input is always a detached snapshot at the ROOT_SHA captured
# above. REPO_ROOT stays the Living Tree so DIST_DIR, BUILD_DIR caches and
# runtime-pack selection keep living on a path the reaper will not delete.
TERMINAL_DONOR="$(canonical_dir "${VIBECRAFTED_TERMINAL_REPO:-$REPO_ROOT/../vc-terminal}")"
FRAME_DONOR="$(canonical_dir "${VIBECRAFTED_FRAME_REPO:-$REPO_ROOT/../vc-frame}")"
DONOR_SNAPSHOT_ROOT="$REPO_ROOT/build/unified-release/donor-snapshots"
SOURCE_ROOT="$DONOR_SNAPSHOT_ROOT/vibecrafted"
if (( SNAPSHOT_DONORS )); then
  TERMINAL_REPO="$DONOR_SNAPSHOT_ROOT/vc-terminal"
  FRAME_REPO="$DONOR_SNAPSHOT_ROOT/vc-frame"
else
  TERMINAL_REPO="$TERMINAL_DONOR"
  FRAME_REPO="$FRAME_DONOR"
fi
ICON_SOURCE="${VIBECRAFTED_ICON_SOURCE:-$SOURCE_ROOT/docs/presence/logo-master.png}"
ICON_REFERENCE="${VIBECRAFTED_ICON_REFERENCE:-}"
# DIST_DIR was resolved and locked immediately after the checkout lock.
BUILD_DIR="$REPO_ROOT/build/unified-release"
APP="$DIST_DIR/Vibecrafted.app"
VERSION="$(git -C "$REPO_ROOT" show "$ROOT_SHA:VERSION" | tr -d '[:space:]')"
[[ -n "$VERSION" ]] || die "VERSION is missing at bound revision $ROOT_SHA"
RELEASE_DATE="${VIBECRAFTED_RELEASE_DATE:-$(date -u +%Y%m%d)}"
RUNTIME_VERSION="${VERSION}+g${ROOT_SHA:0:8}"
[[ "$RELEASE_DATE" =~ ^[0-9]{8}$ ]] || {
  printf 'FATAL: VIBECRAFTED_RELEASE_DATE must be YYYYMMDD\n' >&2
  exit 1
}
DMG_NAME="Vibecrafted_${VERSION}-${RELEASE_DATE}-${ROOT_SHA:0:8}.dmg"
DMG="$DIST_DIR/$DMG_NAME"
DMG_CHECKSUM="$DMG.sha256"
LEGACY_DMG="$DIST_DIR/Vibecrafted.dmg"
RUNTIME_PACK_PLATFORM="darwin-arm64"
RUNTIME_PACK_ARCHITECTURE="$(uname -m | sed 's/^arm64$/arm64/; s/^aarch64$/arm64/; s/^x86_64$/x64/')"
[[ "$(uname -s)" == "Darwin" && "$RUNTIME_PACK_ARCHITECTURE" == "arm64" ]] \
  || die "Vibecrafted.app release currently supports only darwin-arm64 (this host: $(uname -s) $(uname -m)); a Linux Runtime Pack comes from \`make runtime-pack\` on Linux"
# The toolchain pin is a preflight like any other, so it runs after the claim
# above: a host without it must leave the record pending, not the previous
# success standing. It follows the platform gate so a Linux host hears that
# first.
# Pin the complete build, including donor subprocesses and proc-macro hosts.
# Notarize-only consumes already-built, already-signed bytes and must not depend
# on Cargo or WASM targets that cannot change those bytes.
if [[ "$MODE" != "notarize" ]]; then
  export RUSTUP_TOOLCHAIN="$VIBECRAFTED_RELEASE_RUSTUP_TOOLCHAIN"
  prefer_rustup_cargo
  require rustup
  rustup which --toolchain "$RUSTUP_TOOLCHAIN" rustc >/dev/null \
    || die "install the release toolchain: rustup toolchain install $RUSTUP_TOOLCHAIN --profile minimal"
  for release_target in $VIBECRAFTED_RELEASE_RUST_TARGETS; do
    rustup target list --installed --toolchain "$RUSTUP_TOOLCHAIN" 2>/dev/null \
      | grep -Fxq "$release_target" \
      || die "rustup target $release_target is missing from $RUSTUP_TOOLCHAIN; run: rustup target add --toolchain $RUSTUP_TOOLCHAIN $release_target"
  done
fi
RUNTIME_PACK_NAME="Vibecrafted_RuntimePack_${VERSION}-${RELEASE_DATE}-${ROOT_SHA:0:8}-${RUNTIME_PACK_PLATFORM}.tar.gz"
RUNTIME_PACK="$DIST_DIR/$RUNTIME_PACK_NAME"
RUNTIME_PACK_CHECKSUM="$RUNTIME_PACK.sha256"
RUNTIME_PACK_SIGNATURE="$RUNTIME_PACK.sig"
RUNTIME_PACK_RESOURCE_DIR="$APP/Contents/Resources/runtime-pack"
EMBEDDED_RUNTIME_PACK="$RUNTIME_PACK_RESOURCE_DIR/$RUNTIME_PACK_NAME"
EMBEDDED_RUNTIME_PACK_CHECKSUM="$EMBEDDED_RUNTIME_PACK.sha256"
EMBEDDED_RUNTIME_PACK_SIGNATURE="$EMBEDDED_RUNTIME_PACK.sig"
RUNTIME_PAYLOAD="$BUILD_DIR/runtime-pack-payload/VibecraftedRuntime"
KEYS="${KEYS:-$HOME/.keys}"
TERMINAL_FONT_DIR="$SOURCE_ROOT/assets/fonts/source-code-pro"
SIGNING_IDENTITY_FILE="$KEYS/signing-identity.txt"
CERT_P12="$KEYS/Certificates.p12"
CERT_PASSWORD_FILE="$KEYS/cert_password.txt"
SIGNING_KEY="$KEYS/vibecrafted-signing.key"
NOTARY_ENV="$KEYS/.notary.env"
BUILD_NUMBER="${BUILD_NUMBER:-$(date -u +%Y%m%d%H%M%S)}"
SIGNING_IDENTITY=""
TEMP_KEYCHAIN_PATH=""
SIGNING_KEYCHAIN_LABEL="vibecrafted-signing-$$"
CODESIGN_KEYCHAIN_ARGS=()
# The host toolchain is part of the release contract. Apple `strip` shipped in
# Xcode 27 beta writes a mis-aligned LINKEDIT string pool into chained-fixups
# dylibs (every dylib once MACOSX_DEPLOYMENT_TARGET >= 12); dyld on macOS 27
# refuses them and rustc reports the dependency-free proc-macros
# (`rustversion`, `paste`) as `error[E0463]: can't find crate`. MEASURED
# 2026-08-28 on a build host with xcode-select pointing at ~/Downloads/Xcode-beta.app;
# the same tree under /Applications/Xcode.app (26.6) builds clean. A beta
# Xcode is therefore refused unless the operator opts in explicitly.
#
# shellcheck source=lib/xcode-channel.sh
. "$REPO_ROOT/scripts/lib/xcode-channel.sh"
vibecrafted_xcode_require_stable || exit 1
echo "==> Xcode developer dir: $DEVELOPER_DIR ($(xcrun --find strip 2>/dev/null || echo 'strip: unresolved'))"
export MACOSX_DEPLOYMENT_TARGET=14.0
# Apple ld64 1230.1 and 27037.1 both assert in makeSymbolStringInPlace while
# linking the generated Vibecrafted Server entry object. The exact captured
# linker input succeeds under ld-classic 956.6; on a CLT 27 host, which ships no
# ld-classic, the contract selects the measured Xcode clang/ld pair instead.
# Scope the linker to Cargo's native Apple target: WASM keeps rust-lld, while
# Swift, signing and notarization keep using the selected Xcode toolchain.
if [[ "$MODE" != "notarize" ]]; then
  DARWIN_RUST_LINKER="$REPO_ROOT/scripts/lib/rust-linker-darwin-classic.sh"
  [[ -x "$DARWIN_RUST_LINKER" ]] || die "missing executable Darwin Rust linker wrapper: $DARWIN_RUST_LINKER"
  vibecrafted_release_verify_darwin_linker \
    || die "the pinned Darwin Rust linker contract is not satisfied"
  export VIBECRAFTED_RELEASE_TOOLCHAIN_CONTRACT="$RELEASE_TOOLCHAIN_CONTRACT"
  export CARGO_TARGET_AARCH64_APPLE_DARWIN_LINKER="${CARGO_TARGET_AARCH64_APPLE_DARWIN_LINKER:-$DARWIN_RUST_LINKER}"
  echo "==> Rust Darwin linker: $CARGO_TARGET_AARCH64_APPLE_DARWIN_LINKER ($VIBECRAFTED_RELEASE_DARWIN_LINKER_MODE: $VIBECRAFTED_RELEASE_DARWIN_RUST_CLANG -> $VIBECRAFTED_RELEASE_DARWIN_RUST_LD)"
fi
# Keep host proc-macro dylibs loadable under the Xcode beta linker/strip pair.
# Strip only packaged Mach-O payloads through the existing signing pipeline.
export CARGO_PROFILE_RELEASE_STRIP=false
# Release payloads must not remember the operator account, Cargo registry, or
# living checkout locations through compiler metadata.
#
# ORDER IS LOAD-BEARING. rustc applies the LAST matching --remap-path-prefix.
# MEASURED 2026-08-18:
#   rustc --remap-path-prefix=$T=/usr/src/OUTER \
#         --remap-path-prefix=$T/inner=/usr/src/INNER  $T/inner/main.rs
# reports /usr/src/INNER/main.rs, and swapping the two arguments reports
# /usr/src/OUTER/inner/main.rs. So the list runs BROADEST FIRST:
#   * $HOME must precede the checkout and the donors. It used to be last, which
#     is correct only by accident on this host — every repository happens to
#     live on /Volumes. On any operator whose checkout sits under $HOME, the
#     trailing $HOME entry would win and every specific root would be dead.
#   * the donor snapshots and the main SOURCE_ROOT live under
#     $REPO_ROOT/build/..., so they must follow $REPO_ROOT or they would be
#     rewritten as /usr/src/vibecrafted/build/...
#
# The snapshot pair is emitted only when it exists. Without --snapshot-donors
# TERMINAL_REPO IS TERMINAL_DONOR, and the duplicate pair merely pinned its own
# redundancy into the contract test.
PATH_REMAPS=(
  "$HOME=/usr/src/operator-home"
  "$REPO_ROOT=/usr/src/vibecrafted"
  "$SOURCE_ROOT=/usr/src/vibecrafted"
  "$TERMINAL_DONOR=/usr/src/vc-terminal"
  "$FRAME_DONOR=/usr/src/vc-frame"
)
if (( SNAPSHOT_DONORS )); then
  PATH_REMAPS+=(
    "$TERMINAL_REPO=/usr/src/vc-terminal"
    "$FRAME_REPO=/usr/src/vc-frame"
  )
fi
RUSTFLAGS=""
FILE_PREFIX_MAP=""
SWIFT_PREFIX_MAP=""
for mapping in "${PATH_REMAPS[@]}"; do
  RUSTFLAGS+="${RUSTFLAGS:+ }--remap-path-prefix=$mapping"
  FILE_PREFIX_MAP+="${FILE_PREFIX_MAP:+ }-ffile-prefix-map=$mapping"
  SWIFT_PREFIX_MAP+="${SWIFT_PREFIX_MAP:+ }-debug-prefix-map $mapping"
done
export RUSTFLAGS
# cc-rs compiles the C half of crates such as `ring`, and rustc's remap never
# sees those translation units. MEASURED on the shipped 4.1.0 DMG:
# Contents/MacOS/Vibecrafted carried 21 occurrences of
# $HOME/.cargo/registry/src/.../ring-0.17.14/crypto/... clang's
# -ffile-prefix-map is the same instrument on the C side.
export CFLAGS="${CFLAGS:+$CFLAGS }$FILE_PREFIX_MAP"
export CXXFLAGS="${CXXFLAGS:+$CXXFLAGS }$FILE_PREFIX_MAP"
# The Swift host is built by xcodebuild, which reads none of the above. Same
# payload, 51 occurrences of the checkout root from Swift source locations and
# DerivedData intermediates. Passed to xcodebuild as build settings below.
export SWIFT_PREFIX_MAP

# The ephemeral signing keychain is owned by scripts/lib/keychain-session.sh,
# which arms its own EXIT/INT/TERM/HUP traps and chains onto whatever this
# script already had. See that file's header for the 2026-08-15 incident this
# replaces: the block that used to live here restored the DEFAULT keychain and
# deleted the temp keychain, but never put the search LIST back — it trusted
# `delete-keychain` to unlist, which only holds while the keychain file still
# exists. It also took the login session's default keychain, which is a
# host-wide side effect for the entire duration of the release.
# shellcheck source=/dev/null
. "$REPO_ROOT/scripts/lib/keychain-session.sh"
# shellcheck source=/dev/null
. "$REPO_ROOT/scripts/lib/donor-snapshot.sh"
# shellcheck source=/dev/null
. "$REPO_ROOT/scripts/lib/payload-hygiene.sh"
# shellcheck source=/dev/null
. "$REPO_ROOT/scripts/lib/macho-signing.sh"

git_sha() { git -C "$1" rev-parse HEAD; }

# require_clean_repo <repo> <label> [allowed-path-prefix...]
#
# The allowance exists for exactly one case and is empty everywhere else: under
# --snapshot-donors this script regenerates vc-frame's bundled plugin assets
# INSIDE the snapshot, so that tree legitimately differs from its HEAD. That is
# derived output of the very commit the receipt binds — `plugins-parity
# double-rebuild` is what asserts it is a function of the source and nothing
# else — and the snapshot is a detached worktree this script created and will
# reap. Every other difference still refuses, including an unexpected file
# under the allowed directory's sibling.
#
# Dirt is not identity. A clean checkout whose HEAD moved after launch is
# still the wrong generation. After the main snapshot exists, identity is
# `require_bound_revision` against ROOT_SHA on SOURCE_ROOT, never a second
# dirt check of the living REPO_ROOT.
require_clean_repo() {
  local repo="$1" label="$2"
  shift 2
  local status line path prefix allowed
  local -a offending=()
  status="$(git -C "$repo" status --porcelain --untracked-files=normal)"
  while IFS= read -r line; do
    [[ -n "$line" ]] || continue
    path="${line:3}"
    allowed=0
    for prefix in ${1+"$@"}; do
      if [[ "$path" == "$prefix"* ]]; then
        allowed=1
        break
      fi
    done
    (( allowed )) || offending+=("$line")
  done <<< "$status"
  (( ${#offending[@]} == 0 )) \
    || die "$label is dirty; release receipts refuse moving source: ${offending[*]}"
}

require_bound_revision() {
  local repo="$1" label="$2" expected="$3"
  local actual
  actual="$(git_sha "$repo")"
  [[ "$actual" == "$expected" ]] \
    || die "$label HEAD $actual is not the bound release revision $expected"
}

# Fail closed on a dirty Living Tree before signing or cargo. After this
# check the parent may keep moving; product bytes come from SOURCE_ROOT.
if [[ "$MODE" != "notarize" ]]; then
  require_clean_repo "$REPO_ROOT" vibecrafted
fi
# cleanup + signal traps are armed immediately after the release lock so a
# die() above still reaps nothing it did not create and still closes our
# descriptor. keychain_session_begin chains onto those handlers.

read_trimmed_file() {
  sed -e 's/[[:space:]]*$//' -e '/^$/d' "$1" | head -n1
}

prepare_signing_identity() {
  SIGNING_IDENTITY="$(read_trimmed_file "$SIGNING_IDENTITY_FILE")"
  [[ -n "$SIGNING_IDENTITY" ]] || die "signing identity is empty"
  if [[ -f "$CERT_P12" && -f "$CERT_PASSWORD_FILE" ]]; then
    local cert_password temp_password
    cert_password="$(read_trimmed_file "$CERT_PASSWORD_FILE")"
    [[ -n "$cert_password" ]] || die "certificate password is empty"

    # The ephemeral keychain lives in its own per-process state directory and
    # is always addressed explicitly. It is never registered in the user's
    # global search list: doing so changes keychain lookup for Codescribe and
    # every other application on the host while a release is running.
    #
    # It deliberately does NOT make this the login session's default keychain.
    # Nothing below needs that: every call names the keychain explicitly. The
    # old `security default-keychain -d user -s "$TEMP_KEYCHAIN_PATH"` is what
    # made Codescribe (and everything else on the host) prompt for a uuidgen
    # password for the whole length of the release.
    #
    # A hosted runner is the one place where registering it is right: nothing
    # else runs there, and codesign resolves the Developer ID chain through the
    # search list, not through --keychain alone (run 32597029908: identity
    # present, "The specified item could not be found in the keychain").
    KEYCHAIN_SESSION_REGISTER_SEARCH_LIST="${VIBECRAFTED_KEYCHAIN_SEARCH_LIST:-0}" \
      keychain_session_begin "$SIGNING_KEYCHAIN_LABEL"
    TEMP_KEYCHAIN_PATH="$KEYCHAIN_SESSION_PATH"
    temp_password="$(cat "$(keychain_session_password_file)")"

    security import "$CERT_P12" -k "$TEMP_KEYCHAIN_PATH" -P "$cert_password" \
      -T /usr/bin/codesign >/dev/null
    security set-key-partition-list -S apple-tool:,apple:,codesign: -s \
      -k "$temp_password" "$TEMP_KEYCHAIN_PATH" >/dev/null
    security find-identity -v -p codesigning "$TEMP_KEYCHAIN_PATH" \
      | grep -Fq "$SIGNING_IDENTITY" \
      || die "Developer ID identity is absent from temporary keychain"
    CODESIGN_KEYCHAIN_ARGS=(--keychain "$TEMP_KEYCHAIN_PATH")
    return
  fi
  security find-identity -v -p codesigning | grep -Fq "$SIGNING_IDENTITY" \
    || die "Developer ID identity is not available in the keychain"
}

for command in cargo codesign file git install_name_tool make otool strip uv; do
  require "$command"
done
if [[ "$MODE" != "runtime-pack" ]]; then
  for command in hdiutil xcodebuild xcodegen xcrun; do
    require "$command"
  done
fi
[[ -f "$SIGNING_IDENTITY_FILE" ]] || die "missing $SIGNING_IDENTITY_FILE"
# Darwin terminal bundles carry the canonical OFL family from the captured
# source commit. SOURCE_ROOT is materialized later: preflight its Git blobs,
# rather than reading a missing snapshot or mutable Living Tree font files.
if [[ "$MODE" != "runtime-pack" || "$RUNTIME_PACK_PLATFORM" == darwin-* ]]; then
  for font in 'SourceCodePro[wght].ttf' 'SourceCodePro-Italic[wght].ttf'; do
    git -C "$REPO_ROOT" cat-file -e "$ROOT_SHA:assets/fonts/source-code-pro/$font" \
      || die "missing Source Code Pro input at $ROOT_SHA: $font"
    git -C "$REPO_ROOT" show "$ROOT_SHA:assets/fonts/source-code-pro/$font" \
      | LC_ALL=C file -b - | grep -Eq '(OpenType|TrueType) [Ff]ont' \
      || die "Source Code Pro input is not an OpenType/TrueType font: $font"
  done
  git -C "$REPO_ROOT" show "$ROOT_SHA:assets/fonts/source-code-pro/OFL.txt" \
    | grep -Fq 'SIL OPEN FONT LICENSE Version 1.1' \
    || die "missing Source Code Pro OFL license at $ROOT_SHA"
fi
prepare_signing_identity

# Empty unless the frame repo is a snapshot we are entitled to regenerate into.
FRAME_DERIVED=()
if (( SNAPSHOT_DONORS )); then
  FRAME_DERIVED=("zellij-utils/assets/plugins/")
fi

# normalize_embedded_python_paths <runtime-root> <seed-dir>
#
# Replace every textual mention of the ephemeral CPython seed directory with a
# stable placeholder. Binary files are reported and skipped: shortening a string
# inside a Mach-O would corrupt it, and the payload gate is the backstop that
# refuses the build if one ever appears.
normalize_embedded_python_paths() {
  local runtime="$1" seed="$2"
  python3 - "$runtime" "$seed" <<'PY'
import pathlib
import sys

runtime = pathlib.Path(sys.argv[1])
seed = sys.argv[2].rstrip("/").encode()
placeholder = b"/usr/src/python-seed"

rewritten = 0
binary = []
for path in runtime.rglob("*"):
    if path.is_symlink() or not path.is_file():
        continue
    data = path.read_bytes()
    if seed not in data:
        continue
    try:
        text = data.decode("utf-8")
    except UnicodeDecodeError:
        binary.append(str(path.relative_to(runtime)))
        continue
    path.write_text(text.replace(seed.decode(), placeholder.decode()), encoding="utf-8")
    rewritten += 1

print(f"normalized the embedded interpreter seed path in {rewritten} text file(s)")

# CPython 3.13+ also ships _sysconfig_vars__*.json. python-build-standalone
# freezes its CI runner's home directory into it (the userbase value). The
# runtime recomputes userbase at startup, so the frozen value is informational
# only, but it is an account-home absolute path the product contract refuses.
import json
import re

account_home = re.compile(r"^/(?:Users|home)/[^/]+(?=/|$)")
build_placeholder = "/usr/src/python-build-standalone"
for path in runtime.rglob("_sysconfig_vars__*.json"):
    if path.is_symlink() or not path.is_file():
        continue
    values = json.loads(path.read_text(encoding="utf-8"))
    changed = [
        key
        for key, value in values.items()
        if isinstance(value, str) and account_home.match(value)
    ]
    if not changed:
        continue
    for key in changed:
        values[key] = account_home.sub(build_placeholder, values[key], count=1)
    path.write_text(json.dumps(values, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    print(f"normalized the build account home in {path.relative_to(runtime)}: {', '.join(sorted(changed))}")
if binary:
    print(f"binary files still naming the seed: {binary}", file=sys.stderr)
    raise SystemExit(1)
PY
}

# prune_embedded_python_unreachable <python-home> <interpreter> <libpython>
#
# python-build-standalone ships native code the product never loads, and the
# product contract refuses a declared dylib no declared executable reaches
# (VCPC027). MEASURED 2026-09-14 on the c71487bf candidate with CPython 3.14.7:
# - the Tcl/Tk stack (libtcl9, libtcl9tk9, thread, itcl) exists for tkinter and
#   IDLE, which no Vibecrafted surface imports; only dlopen from _tkinter or a
#   Tcl `load` would reach those dylibs;
# - the interpreter links libpython statically, so the shared libpython is an
#   embedding artifact nothing loads. It stays when the interpreter links it.
prune_embedded_python_unreachable() {
  local python="$1" libpython="$3"
  local path restore_nullglob
  # `shopt -p` exits 1 for an option that is off; under `set -e` that silently
  # ended release #8 right after the interpreter download.
  restore_nullglob="$(shopt -p nullglob || true)"
  shopt -s nullglob
  for path in \
    "$python"/lib/tcl[0-9]* "$python"/lib/tk[0-9]* \
    "$python"/lib/libtcl*.dylib "$python"/lib/libtk*.dylib \
    "$python"/lib/thread[0-9]* "$python"/lib/itcl[0-9]* \
    "$python"/lib/python3.*/tkinter "$python"/lib/python3.*/idlelib \
    "$python"/lib/python3.*/turtledemo \
    "$python"/lib/python3.*/lib-dynload/_tkinter.* \
    "$python"/bin/idle3*; do
    rm -rf "$path"
  done
  eval "$restore_nullglob"
  [[ -f "$python/lib/$libpython" ]] || return 0
  # The native vc-server-supervisor embeds this library even when the ordinary
  # interpreter links Python statically. It belongs to the signed closure.
}

run_bundled_verifier() {
  local verifier="$APP/Contents/Resources/runtime/bin/python3"
  [[ -x "$verifier" ]] || die "bundled product verifier is missing: $verifier"
  PYTHONNOUSERSITE=1 PYTHONDONTWRITEBYTECODE=1 \
    "$verifier" -m vibecrafted_core.product_contract "$@"
}

notary_profile_from_env_file() {
  # Read ONLY the profile name. Never source .notary.env — that file may hold
  # Apple-ID passwords and must not enter process argv or the shell environment.
  local file="${1:-}"
  [[ -f "$file" ]] || return 0
  sed -n 's/^NOTARY_PROFILE=//p' "$file" | head -n1 | tr -d '\r"'
}

notary_profile_from_keychain() {
  local candidate="${NOTARY_FALLBACK_PROFILE:-vibecrafted-notary}"
  # A conventional name is only admitted after Apple authenticates it. This
  # keeps headless retries smooth after the one-time secure credential prompt
  # without reviving the old bug where an invented profile masked valid
  # Apple-ID or API-key credentials.
  if xcrun notarytool history --keychain-profile "$candidate" >/dev/null 2>&1; then
    printf '%s\n' "$candidate"
  fi
}

notary_submit() {
  local artifact="$1"
  local profile="${NOTARY_PROFILE:-}"
  if [[ -z "$profile" ]]; then
    profile="$(notary_profile_from_env_file "$NOTARY_ENV")"
  fi
  if [[ -z "$profile" ]]; then
    profile="$(notary_profile_from_keychain)"
  fi
  # An explicit Founder profile (env or .notary.env name-only), or a fallback
  # profile independently authenticated above, beats API keys.
  if [[ -n "$profile" ]]; then
    export NOTARY_PROFILE="$profile"
    xcrun notarytool submit "$artifact" --keychain-profile "$profile" \
      --wait --timeout 30m
    return
  fi
  if [[ -n "${NOTARY_API_KEY_PATH:-}" || -n "${NOTARY_API_KEY_ID:-}" || -n "${NOTARY_API_ISSUER:-}" ]]; then
    : "${NOTARY_API_KEY_PATH:?NOTARY_API_KEY_PATH missing}"
    : "${NOTARY_API_KEY_ID:?NOTARY_API_KEY_ID missing}"
    : "${NOTARY_API_ISSUER:?NOTARY_API_ISSUER missing}"
    [[ -f "$NOTARY_API_KEY_PATH" ]] \
      || die "Notary API private key is missing: $NOTARY_API_KEY_PATH"
    xcrun notarytool submit "$artifact" --key "$NOTARY_API_KEY_PATH" \
      --key-id "$NOTARY_API_KEY_ID" --issuer "$NOTARY_API_ISSUER" \
      --wait --timeout 30m
    return
  fi
  [[ -f "$NOTARY_ENV" ]] \
    || die "NOTARY_PROFILE is unset; store credentials in Keychain first"
  if [[ ! -t 0 || ! -t 1 ]]; then
    die "raw Apple-ID notarization credentials are not accepted headlessly; create a Keychain profile and set NOTARY_PROFILE"
  fi
  local apple_id team_id fallback_profile
  apple_id="$(sed -n 's/^NOTARY_APPLE_ID=//p' "$NOTARY_ENV" | head -n1)"
  team_id="$(sed -n 's/^NOTARY_TEAM_ID=//p' "$NOTARY_ENV" | head -n1)"
  [[ "$apple_id" =~ ^[^[:space:]@]+@[^[:space:]@]+$ ]] \
    || die "NOTARY_APPLE_ID in $NOTARY_ENV is invalid"
  [[ "$team_id" =~ ^[[:alnum:]]{10}$ ]] \
    || die "NOTARY_TEAM_ID in $NOTARY_ENV is invalid"
  fallback_profile="${NOTARY_FALLBACK_PROFILE:-vibecrafted-notary}"
  log "Storing Apple-ID notarization credentials through the secure Keychain prompt"
  xcrun notarytool store-credentials "$fallback_profile" \
    --apple-id "$apple_id" --team-id "$team_id"
  xcrun notarytool submit "$artifact" --keychain-profile "$fallback_profile" \
    --wait --timeout 30m
}

# Debug stabs are the producer no compiler flag reaches. rustc's
# --remap-path-prefix rewrites SOURCE paths (SO stabs read /usr/src/...), but
# the linker still records every OBJECT file it consumed as an N_OSO stab —
# .../target/release/deps/alacritty-*.o and DerivedData/Intermediates.noindex/...
# — verbatim. MEASURED 2026-08-19 on a fresh af98ebfe build: alacritty carried
# 249 such stabs and Contents/MacOS/Vibecrafted 40, all naming the build root.
# Rust 1.95 applies profile `strip = true` while compiling host proc-macros,
# which makes crates such as include_dir and vte_generate_state_changes
# disappear before their dependants are compiled, so vc-frame is built
# unstripped and normalized here instead. The one shared boundary is
# strip_macho_debug_tree in scripts/lib/macho-signing.sh: the same step the
# Runtime Pack payload passes through in materialize_runtime_payload, so no
# binary is ever named twice and none is forgotten. It runs before any
# signature.
#
# Contents/Frameworks is the one root whose LIBRARIES this build linked:
# xcodegen's "Build Rust FFI" phase runs `cargo build -p vibecrafted-shell-ffi`
# (its profile strip aborts in rust-objcopy, as a warning) and Xcode embeds
# the dylib as it came. MEASURED 2026-09-09 on the aa12980d candidate: the
# Runtime Pack passed (6739 files) and the App gate refused
# libvibecrafted_shell_ffi.dylib for 17 N_OSO stabs — 11 naming the Cargo
# target directory, 6 the rustup sysroot — and nothing else. That root is
# therefore stripped with --shared-libraries, which also proves exports, load
# commands and a real dyld load afterwards. The Runtime Pack's vendor dylibs
# under Contents/Resources/runtime are not named here and stay as delivered.
strip_debug_stabs() {
  strip_macho_debug_tree "$APP/Contents/MacOS" "$APP/Contents/Helpers" \
    || die "Vibecrafted.app debug-record strip failed"
  strip_macho_debug_tree --shared-libraries "$APP/Contents/Frameworks" \
    || die "Vibecrafted.app framework debug-record strip failed"
}

sign_nested_app_bundles() {
  sign_macho_app_bundles "$APP/Contents"
}

# Helpers/vc-app-update is a shebang script, not Mach-O, so sign_macho_tree
# skips it. Outer codesign then refuses: "code object is not signed at all
# In subcomponent: .../Contents/Helpers/vc-app-update".
sign_helper_scripts() {
  local helper
  [[ -x "$APP/Contents/Helpers/vc-app-update" ]] \
    || die "missing app-update helper: Contents/Helpers/vc-app-update"
  while IFS= read -r -d '' helper; do
    [[ -x "$helper" ]] || continue
    if is_macho_file "$helper"; then
      continue
    fi
    codesign --force --options runtime --timestamp --sign "$SIGNING_IDENTITY" \
      "${CODESIGN_KEYCHAIN_ARGS[@]}" "$helper" \
      || die "could not sign helper ${helper#"$APP"/}"
  done < <(find "$APP/Contents/Helpers" -maxdepth 1 -type f -print0)
}

remove_ambient_swift_rpath() {
  local executable="$APP/Contents/MacOS/Vibecrafted"
  local rpaths
  rpaths="$(otool -l "$executable" | awk '
    $1 == "cmd" && $2 == "LC_RPATH" { in_rpath = 1; next }
    in_rpath && $1 == "path" { print $2; in_rpath = 0 }
  ')"
  if grep -Fxq '/usr/lib/swift' <<<"$rpaths"; then
    install_name_tool -delete_rpath /usr/lib/swift "$executable"
  fi
  rpaths="$(otool -l "$executable" | awk '
    $1 == "cmd" && $2 == "LC_RPATH" { in_rpath = 1; next }
    in_rpath && $1 == "path" { print $2; in_rpath = 0 }
  ')"
  if grep -Eq '^/' <<<"$rpaths"; then
    die "Swift host contains an ambient absolute LC_RPATH"
  fi
}

# Snapshots are materialised here, not at parse time: --notarize-only reuses an
# already assembled app and must not touch the donors or main source at all.
#
# Main snapshot lifetime: created here at the ROOT_SHA captured at launch,
# recorded in DONOR_SNAPSHOTS, reaped by cleanup → donor_snapshot_reap on
# EXIT/INT/TERM/HUP. DIST_DIR, BUILD_DIR cargo/DerivedData, the App and
# build/runtime-pack-selection.json stay on the living REPO_ROOT so a reap
# cannot delete a reusable cache or unpublish a finished carrier.
materialize_donor_snapshots() {
  require git
  log "Snapshotting main source at $ROOT_SHA; the Living Tree may keep moving"
  # No command substitution here: it would run the snapshot in a subshell and
  # the reaper would lose the record. See scripts/lib/donor-snapshot.sh.
  donor_snapshot_create "$REPO_ROOT" "$SOURCE_ROOT" "$ROOT_SHA"
  [[ "$DONOR_SNAPSHOT_HEAD" == "$ROOT_SHA" ]] \
    || die "main snapshot HEAD $DONOR_SNAPSHOT_HEAD is not the bound release revision $ROOT_SHA"
  log "vibecrafted snapshot at $DONOR_SNAPSHOT_HEAD"
  if (( SNAPSHOT_DONORS )); then
    log "Snapshotting donors at the selected commits; their dirty working trees stay untouched"
    local terminal_head frame_head
    donor_snapshot_create "$TERMINAL_DONOR" "$TERMINAL_REPO" "${VIBECRAFTED_TERMINAL_REVISION:-}"
    terminal_head="$DONOR_SNAPSHOT_HEAD"
    donor_snapshot_create "$FRAME_DONOR" "$FRAME_REPO" "${VIBECRAFTED_FRAME_REVISION:-}"
    frame_head="$DONOR_SNAPSHOT_HEAD"
    log "vc-terminal snapshot at $terminal_head"
    log "vc-frame snapshot at $frame_head"
  fi
  # Source snapshots are disposable; donor Cargo/WASM outputs remain under the
  # physical donors' leased target roots, never below the snapshots we reap.
  # Main cargo/DerivedData stay in the living BUILD_DIR so correct caches reuse.
  [[ -z "${VIBECRAFTED_RELEASE_FAIL_AFTER_SNAPSHOT:-}" ]] \
    || die "VIBECRAFTED_RELEASE_FAIL_AFTER_SNAPSHOT is set; failing on purpose so the reaper is exercised"
}

produce_runtime_pack() {
  local -a packager_codesign_args=(--codesign-identity "$SIGNING_IDENTITY")
  if [[ -n "$TEMP_KEYCHAIN_PATH" ]]; then
    packager_codesign_args+=(--codesign-keychain "$TEMP_KEYCHAIN_PATH")
  fi
  # Read the donor identities ONCE, here, and hand the very same values to the
  # packager and to the build-selection record. Re-reading a sibling HEAD after
  # the pack is sealed would let a donor that moved mid-build describe bytes it
  # did not produce.
  local terminal_revision frame_revision
  terminal_revision="$(git_sha "$TERMINAL_REPO")"
  frame_revision="$(git_sha "$FRAME_REPO")"
  log "Producing the canonical standalone Runtime Pack"
  rm -f "$RUNTIME_PACK" "$RUNTIME_PACK_CHECKSUM" "$RUNTIME_PACK_SIGNATURE"
  "$SOURCE_ROOT/scripts/package-runtime-pack.sh" \
    --payload-root "$RUNTIME_PAYLOAD" --output "$RUNTIME_PACK" \
    --source-revision "$ROOT_SHA" \
    --terminal-revision "$terminal_revision" \
    --frame-revision "$frame_revision" \
    --version "$RUNTIME_VERSION" \
    --platform "$RUNTIME_PACK_PLATFORM" \
    --architecture "$RUNTIME_PACK_ARCHITECTURE" \
    "${packager_codesign_args[@]}"
  verify_runtime_pack_macho_signatures "$RUNTIME_PACK" \
    || die "standalone Runtime Pack contains an invalid or unsigned Mach-O"
  /usr/bin/openssl dgst -sha256 -sign "$SIGNING_KEY" \
    -out "$RUNTIME_PACK_SIGNATURE" "$RUNTIME_PACK"
  # Completion boundary for the standalone carrier: packaged, its Mach-O payload
  # verified, its detached signature written. Only now may `make install` treat
  # this exact path as the artifact the Founder just built. The packager prints
  # the path much earlier, before signing, which is too early to publish.
  runtime_pack_selection_publish "$REPO_ROOT" "$RUNTIME_PACK_SELECTION_ATTEMPT" \
    "$RUNTIME_PACK" "$RUNTIME_VERSION" "$RUNTIME_PACK_PLATFORM" \
    "$RUNTIME_PACK_ARCHITECTURE" "$ROOT_SHA" "$terminal_revision" \
    "$frame_revision" \
    || die "could not record the standalone Runtime Pack build selection"
}

embed_runtime_pack() {
  log "Embedding the exact standalone Runtime Pack bytes in Vibecrafted.app"
  rm -rf "$RUNTIME_PACK_RESOURCE_DIR"
  mkdir -p "$RUNTIME_PACK_RESOURCE_DIR"
  bash "$SOURCE_ROOT/scripts/package-installer-kit.sh" \
    --directory "$RUNTIME_PACK_RESOURCE_DIR"
  printf '%s\n' "$RUNTIME_VERSION" > "$RUNTIME_PACK_RESOURCE_DIR/VERSION"
  install -m 0644 "$RUNTIME_PACK" "$EMBEDDED_RUNTIME_PACK"
  install -m 0644 "$RUNTIME_PACK_CHECKSUM" "$EMBEDDED_RUNTIME_PACK_CHECKSUM"
  install -m 0644 "$RUNTIME_PACK_SIGNATURE" "$EMBEDDED_RUNTIME_PACK_SIGNATURE"
  cmp "$RUNTIME_PACK" "$EMBEDDED_RUNTIME_PACK"
  cmp "$RUNTIME_PACK_CHECKSUM" "$EMBEDDED_RUNTIME_PACK_CHECKSUM"
  cmp "$RUNTIME_PACK_SIGNATURE" "$EMBEDDED_RUNTIME_PACK_SIGNATURE"
  verify_runtime_pack_macho_signatures "$EMBEDDED_RUNTIME_PACK" \
    || die "embedded Runtime Pack contains an invalid or unsigned Mach-O"
}

# embed_terminal_font_resources <vc-terminal.app>
#
# Give the process that actually draws the glyphs its own copy of the OFL
# Source Code Pro family, declared the way Apple documents for a consuming app:
# ATSApplicationFontsPath names a Resources-relative directory and CoreText
# registers it privately for that bundle's process.
#
# Measured on macOS 27 with an isolated probe (see
# tests/tui/test_terminal_font_ownership.py):
#   * a family absent from the host resolves inside the declaring bundle and
#     stays invisible to every other process, so a user without Source Code Pro
#     installed still gets it;
#   * a family already registered from /System/Library/Fonts or /Library/Fonts
#     keeps winning inside the declaring process, so for those stores the
#     bundled copy is a fallback and not a takeover. The probe deliberately
#     does not read ~/Library/Fonts, so precedence over the owner's private
#     collection is not claimed here — only the system stores were measured.
# That is the whole reason this replaced the parent app's CTFontManager
# `.session` registration, which reached the entire login session; there the
# shadowing of a user-installed SpotMono.ttc WAS observed directly.
embed_terminal_font_resources() {
  local terminal_app="$1"
  local resources="$terminal_app/Contents/Resources"
  local plist="$terminal_app/Contents/Info.plist"
  [[ -f "$plist" ]] || die "vc-terminal bundle has no Info.plist: $terminal_app"
  mkdir -p "$resources/fonts"
  for font in 'SourceCodePro[wght].ttf' 'SourceCodePro-Italic[wght].ttf' 'OFL.txt'; do
    install -m 0644 "$TERMINAL_FONT_DIR/$font" "$resources/fonts/$font"
  done
  /usr/libexec/PlistBuddy -c "Set :ATSApplicationFontsPath fonts" "$plist" 2>/dev/null \
    || /usr/libexec/PlistBuddy -c "Add :ATSApplicationFontsPath string fonts" "$plist"
  [[ "$(/usr/libexec/PlistBuddy -c 'Print :ATSApplicationFontsPath' "$plist")" == "fonts" ]] \
    || die "vc-terminal bundle does not declare its private font directory"
  for font in 'SourceCodePro[wght].ttf' 'SourceCodePro-Italic[wght].ttf' 'OFL.txt'; do
    [[ -s "$resources/fonts/$font" ]] || die "vc-terminal bundle is missing $font"
  done
}

materialize_runtime_payload() {
  local runtime="$1"
  local terminal_source="$2"
  local frame_source="$3"
  local start_source="$4"
  local voc_source="$5"
  local server_source="$6"
  local server_site="$7"
  local scaffold_doctor_source="$8"
  local control_observe_source="$9"
  local admin_source="${10}"
  local procs_source="${11}"
  local canonical_deck python_seed seed_python python_home _attempt

  log "Materializing the App-independent Runtime Pack payload"
  [[ "$runtime" == "$BUILD_DIR/runtime-pack-payload/VibecraftedRuntime" ]] \
    || die "refusing to clear unowned Runtime Pack payload: $runtime"
  # Host metadata can recreate .DS_Store during removal. Unlike EXIT cleanup,
  # this reset must succeed before any bytes are materialized into the payload.
  for _attempt in 1 2 3; do
    if rm -rf -- "$runtime" 2>/dev/null; then
      break
    fi
    [[ "$_attempt" != 3 ]] \
      || die "could not clear owned Runtime Pack payload after 3 attempts: $runtime"
    sleep 0.05
  done
  mkdir -p "$runtime/bin" "$runtime/libexec" "$runtime/scripts" \
    "$runtime/vibecrafted-core" "$runtime/vibecrafted-mcp" \
    "$runtime/config" "$runtime/server/site"
  printf '%s\n' "$RUNTIME_VERSION" > "$runtime/VERSION"
  canonical_deck="$SOURCE_ROOT/vibecrafted-core/vibecrafted_core/deck/vibecrafted"
  install -m 0755 "$canonical_deck" "$runtime/scripts/vibecrafted"
  install -m 0755 "$canonical_deck" "$runtime/bin/vibecrafted"
  install -m 0755 "$SOURCE_ROOT/scripts/vetcoders_install.py" \
    "$runtime/scripts/vetcoders_install.py"
  # Pack carries the foundations INSTALLER, never the foundations (Vetcoders decision, 2026-10-07).
  install -m 0755 "$SOURCE_ROOT/scripts/install-foundations.sh" \
    "$runtime/scripts/install-foundations.sh"
  install -m 0755 "$SOURCE_ROOT/scripts/vibecrafted_housekeeping.py" \
    "$runtime/scripts/vibecrafted_housekeeping.py"
  mkdir -p "$runtime/scripts/lib"
  install -m 0644 "$SOURCE_ROOT/scripts/lib/runtime-roots.sh" \
    "$runtime/scripts/lib/runtime-roots.sh"
  install -m 0644 "$SOURCE_ROOT/scripts/distribution_manifest.py" \
    "$runtime/scripts/distribution_manifest.py"
  install -m 0644 "$SOURCE_ROOT/scripts/installer_brand.py" \
    "$runtime/scripts/installer_brand.py"
  install -m 0755 "$SOURCE_ROOT/scripts/vc-frame-product-entry.sh" \
    "$runtime/scripts/vc-frame-product-entry.sh"
  install -m 0755 "$SOURCE_ROOT/scripts/vc-terminal-product-entry.sh" \
    "$runtime/scripts/vc-terminal-product-entry.sh"
  "$SOURCE_ROOT/scripts/project-python" "$SOURCE_ROOT/scripts/distribution_manifest.py" \
    carrier --source "$SOURCE_ROOT" --output "$runtime/source-provenance.json" \
    --owner-repo vetcoders/vibecrafted --source-revision "$ROOT_SHA"
  /bin/cp -R "$SOURCE_ROOT/bin/." "$runtime/bin/"
  /bin/cp -R "$SOURCE_ROOT/vibecrafted-core/vibecrafted_core" \
    "$runtime/vibecrafted-core/"
  # MCP is a Vibecrafted-owned public command. Keep it in the signed
  # generation so its installed launcher never depends on a mutable uv tool
  # environment or the checkout that happened to assemble the carrier.
  /bin/cp -R "$SOURCE_ROOT/vibecrafted-mcp/vibecrafted_mcp" \
    "$runtime/vibecrafted-mcp/"
  # The MCP package's source VERSION is the release version.  Once copied
  # into a Runtime Pack it must identify the exact signed generation, just as
  # vibecrafted-core does below; both --version and MCP initialize serverInfo
  # resolve this one package-owned file.
  printf '%s\n' "$RUNTIME_VERSION" \
    > "$runtime/vibecrafted-mcp/vibecrafted_mcp/VERSION"
  printf '%s\n' "$RUNTIME_VERSION" \
    > "$runtime/vibecrafted-core/vibecrafted_core/VERSION"
  /bin/cp -R "$SOURCE_ROOT/config/." "$runtime/config/"
  /bin/cp -R "$server_site/." "$runtime/server/site/"
  install -m 0755 "$start_source" "$runtime/bin/vc-start"
  install -m 0755 "$voc_source" "$runtime/bin/voc"
  # vc-o is the A2 public alias for Voc. Keep it as a real copy so the closed
  # Runtime Pack never depends on symlink behavior at install time.
  install -m 0755 "$voc_source" "$runtime/bin/vc-o"
  install -m 0755 "$admin_source" "$runtime/bin/vc-admin"
  install -m 0755 "$procs_source" "$runtime/bin/vc-procs"
  install -m 0755 "$server_source" "$runtime/bin/vc-server"
  install -m 0755 "$server_source" "$runtime/bin/vibecrafted-server-web"
  install -m 0755 "$scaffold_doctor_source" "$runtime/bin/scaffold-doctor"
  install -m 0755 "$control_observe_source" "$runtime/bin/control-observe"
  install -m 0755 "$terminal_source" "$runtime/libexec/vc-terminal"
  # Generations are internal payloads, never separate macOS app/Dock identities.
  # The macOS public entry requires the fixed Applications host; Linux keeps
  # the flat native host. A standalone pack must disclose this GUI requirement.
  install -m 0755 "$runtime/scripts/vc-terminal-product-entry.sh" \
    "$runtime/bin/vc-terminal"
  install -m 0755 "$frame_source" "$runtime/libexec/vc-frame"
  install -m 0755 "$runtime/scripts/vc-frame-product-entry.sh" \
    "$runtime/bin/vc-frame"
  # The foundation manifest is a closed inventory of the complete executable
  # surface. Generate it only after every required runtime executable exists.
  # Loctree, AICX, PRView and ScreenScribe are not in it: each ships through
  # its own channel (npm / GitHub releases / PyPI) and agents resolve the host
  # copies; the contract refuses a payload that carries them.
  PYTHONPATH="$runtime/vibecrafted-core" "$SOURCE_ROOT/scripts/project-python" \
    -m vibecrafted_core.runtime_pack_contract write-foundations \
    --root "$runtime" >/dev/null

  find "$runtime/vibecrafted-core" \
    -type d -name __pycache__ -prune -exec rm -rf {} +
  find "$runtime/vibecrafted-core" \
    -type f \( -name '*.pyc' -o -name '*.pyo' \) -delete

  log "Embedding a private Python runtime; no shell profile or host Python is used"
  python_seed="$(mktemp -d "$BUILD_DIR/python-seed.XXXXXX")"
  mkdir -p "$python_seed"
  # Published python-build-standalone install_only archive, pin+checksum in
  # scripts/lib/portable-python-artifact.json. Retry transient curl; never compile.
  # shellcheck source=/dev/null
  . "$SOURCE_ROOT/scripts/lib/portable-python.sh"
  portable_python_load_pin ""
  seed_python="$(install_portable_python "$python_seed")"
  python_home="$(cd "$(dirname "$seed_python")/.." && pwd)"
  mkdir -p "$runtime/python" "$runtime/python-site"
  /bin/cp -RL "$python_home/." "$runtime/python/"
  prune_embedded_python_unreachable "$runtime/python" \
    "$PORTABLE_PYTHON_BIN" "$PORTABLE_PYTHON_DYLIB"
  uv pip install --python "$seed_python" --target "$runtime/python-site" \
    'jsonschema>=4.23,<5' 'PyYAML>=6.0,<7' 'fastmcp>=2.0,<3'
  if [[ -f "$runtime/python/lib/${PORTABLE_PYTHON_DYLIB}" ]]; then
    install_name_tool -id "@rpath/${PORTABLE_PYTHON_DYLIB}" \
      "$runtime/python/lib/${PORTABLE_PYTHON_DYLIB}"
  fi
  rm -rf "$runtime/python-site/bin"
  normalize_embedded_python_paths "$runtime" "$python_seed"

  find "$runtime" -type f -name '*.pyc' -delete
  find "$runtime" -depth -type d -name __pycache__ -empty -delete
  find "$runtime" -type f -name '.DS_Store' -delete
  # This value is literal source or output for a later shell, awk, or Xcode evaluator; expanding its
  # dollar expressions in the producing shell would change the emitted contract.
  # shellcheck disable=SC2016
  printf '%s\n' \
    '#!/bin/bash' \
    'set -euo pipefail' \
    'runtime_root="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"' \
    'export PYTHONNOUSERSITE=1' \
    'export PYTHONDONTWRITEBYTECODE=1' \
    'export PYTHONPATH="$runtime_root/vibecrafted-core:$runtime_root/vibecrafted-mcp:$runtime_root/python-site"' \
    "exec \"\$runtime_root/python/bin/${PORTABLE_PYTHON_BIN}\" \"\$@\"" \
    > "$runtime/bin/python3"
  chmod 0755 "$runtime/bin/python3"
  "$SOURCE_ROOT/scripts/project-python" \
    "$SOURCE_ROOT/scripts/render-python-entrypoint-launchers.py" \
    --pyproject "$SOURCE_ROOT/vibecrafted-core/pyproject.toml" \
    --bin-dir "$runtime/bin" --native-library "$PORTABLE_PYTHON_DYLIB"
  "$SOURCE_ROOT/scripts/project-python" \
    "$SOURCE_ROOT/scripts/render-python-entrypoint-launchers.py" \
    --pyproject "$SOURCE_ROOT/vibecrafted-mcp/pyproject.toml" \
    --bin-dir "$runtime/bin" --native-library "$PORTABLE_PYTHON_DYLIB"

  # Every executable this payload carries — the ones compiled above and the
  # donors' — goes through one debug-record boundary before the gate reads the bytes and
  # before the packager signs them. MEASURED 2026-09-08 on the f131b81b
  # candidate: two named files here left six others carrying the rustup
  # sysroot and the Cargo target directory in linker stabs.
  log "Stripping linker debug records from the Runtime Pack executables"
  strip_macho_debug_tree "$runtime/bin" "$runtime/libexec" "$runtime/python" \
    || die "Runtime Pack payload debug-record strip failed"
  if find "$runtime" -type l -print -quit | grep -q .; then
    die "Runtime Pack payload contains symlinks"
  fi
  assert_payload_is_anonymous "$runtime" "Runtime Pack payload"
}

build_native_voc() {
  NATIVE_VOC_BUILD_ROOT="$BUILD_DIR/cargo/vibecrafted-app"
  log "Building the native hermetic vc-start and VOC operator binaries"
  (cd "$SOURCE_ROOT/vibecrafted-app" \
    && CARGO_TARGET_DIR="$NATIVE_VOC_BUILD_ROOT" \
      cargo build --locked -p voc --bin vc-start --bin voc --bin vc-admin --bin vc-procs --release)
  NATIVE_VC_START_SOURCE="$NATIVE_VOC_BUILD_ROOT/release/vc-start"
  [[ -x "$NATIVE_VC_START_SOURCE" ]] || die "vc-start release binary is missing"
  chmod 0755 "$NATIVE_VC_START_SOURCE"
  NATIVE_VOC_SOURCE="$NATIVE_VOC_BUILD_ROOT/release/voc"
  [[ -x "$NATIVE_VOC_SOURCE" ]] || die "VOC release binary is missing"
  chmod 0755 "$NATIVE_VOC_SOURCE"
  NATIVE_VC_ADMIN_SOURCE="$NATIVE_VOC_BUILD_ROOT/release/vc-admin"
  [[ -x "$NATIVE_VC_ADMIN_SOURCE" ]] || die "vc-admin release binary is missing"
  chmod 0755 "$NATIVE_VC_ADMIN_SOURCE"
  NATIVE_VC_PROCS_SOURCE="$NATIVE_VOC_BUILD_ROOT/release/vc-procs"
  [[ -x "$NATIVE_VC_PROCS_SOURCE" ]] || die "vc-procs release binary is missing"
  chmod 0755 "$NATIVE_VC_PROCS_SOURCE"
}

build_product() {
  materialize_donor_snapshots
  require_clean_repo "$SOURCE_ROOT" vibecrafted
  require_bound_revision "$SOURCE_ROOT" vibecrafted "$ROOT_SHA"
  require_clean_repo "$TERMINAL_REPO" vc-terminal
  require_clean_repo "$FRAME_REPO" vc-frame

  log "Building vc-terminal through its release binary target"
  CARGO_TARGET_DIR="$TERMINAL_DONOR/target" \
    CARGO_BUILD_BUILD_DIR="$TERMINAL_DONOR/target" \
    make -C "$TERMINAL_REPO" \
    DEPLOYMENT_TARGET='MACOSX_DEPLOYMENT_TARGET=14.0' release-bins
  local terminal_source="$TERMINAL_DONOR/target/release/alacritty"
  [[ -x "$terminal_source" ]] || die "vc-terminal release binary is missing"
  chmod 0755 "$terminal_source"

  # vc-frame's `release-binary` target builds --no-plugins and the binary
  # embeds zellij-utils/assets/plugins/*.wasm through include_bytes!. Those
  # blobs are GIT-TRACKED build output: they carry whatever paths the machine
  # that last ran `make plugins-assets` happened to have. MEASURED 2026-08-18:
  # 276 occurrences of $HOME/.cargo/registry across the 14 tracked blobs, of
  # which 411 reached Contents/Helpers/vc-frame in the shipped 4.1.0 DMG. No
  # compiler flag rewrites bytes that were compiled somewhere else, so the
  # release has to compile them again under its own remaps. Closed loop,
  # measured on default-plugins/link: 16 -> 0 occurrences of $HOME.
  #
  # Only ever against a SNAPSHOT. This rebuild rewrites assets/plugins/ and its
  # SHA256SUMS; doing that to the operator's living donor would trample work
  # another agent may be mid-edit on. The snapshot is a detached worktree this
  # script created and will reap, so it is ours to dirty.
  if (( SNAPSHOT_DONORS )); then
    log "Rebuilding vc-frame's bundled WASM plugins under the release remaps"
    CARGO_TARGET_DIR="$FRAME_DONOR/target" \
      CARGO_BUILD_BUILD_DIR="$FRAME_DONOR/target" \
      CARGO_PROFILE_RELEASE_STRIP=false make -C "$FRAME_REPO" plugins-assets
  else
    log "NOTE: --snapshot-donors is off, so the tracked WASM plugin blobs ship"
    log "      as they are. If they name this host the payload gate refuses"
    log "      the build; rerun with --snapshot-donors."
  fi

  log "Building vc-frame through its provenance-stable donor target"
  # zellij-utils/build.rs bakes CARGO_MANIFEST_DIR into the binary for
  # install-freshness (dev builds compare themselves with their checkout). A
  # release build's checkout is a donor snapshot that is reaped minutes later,
  # so the baked path would be both useless and a host-path leak (measured
  # 2026-08-19: 1 hit in Contents/Helpers/vc-frame). Pin it to the same root
  # the source remap advertises; the freshness probe then reports NoCheckout.
  # `plugins-assets` deliberately rewrites tracked derived blobs in the
  # detached snapshot.  That does not make the source revision dirty: the
  # regenerated bytes are checked by plugins-parity and the release receipt is
  # bound to the immutable snapshot HEAD.  Resolve that identity before Cargo
  # asks zellij-utils/build.rs to inspect the derived-output mutation.
  local frame_release_sha
  frame_release_sha="$(git_sha "$FRAME_REPO")"
  CARGO_TARGET_DIR="$FRAME_DONOR/target" \
    CARGO_BUILD_BUILD_DIR="$FRAME_DONOR/target" \
    CARGO_PROFILE_RELEASE_STRIP=false \
    VC_FRAME_GIT_SHA="$frame_release_sha" \
    VC_FRAME_GIT_DIRTY=0 \
    VC_FRAME_SOURCE_MANIFEST_DIR=/usr/src/vc-frame/zellij-utils \
    make -C "$FRAME_REPO" release-binary
  local frame_source="$FRAME_DONOR/target/release/vc-frame"
  [[ -x "$frame_source" ]] || die "vc-frame release binary is missing"
  chmod 0755 "$frame_source"

  build_native_voc
  local start_source="$NATIVE_VC_START_SOURCE"
  local voc_source="$NATIVE_VOC_SOURCE"
  local admin_source="$NATIVE_VC_ADMIN_SOURCE"
  local procs_source="$NATIVE_VC_PROCS_SOURCE"

  log "Building the bundled Vibecrafted Server and hydrated site"
  local server_build_root="$BUILD_DIR/cargo"
  # Rust 1.96 mangles crate symbols the legacy way, which spells the whole
  # Leptos view type into drop glue: MEASURED 2026-09-25, 111k-character
  # core::ptr::drop_in_place<...View<(Doctype, Html<...>)>> symbols, past the
  # name limit Apple ld enforces (makeSymbolStringInPlace, ld-27036.1 on the
  # xcode pair). v0 is what the server's own pin (1.97.0) emits by default.
  RUSTFLAGS="${RUSTFLAGS:+$RUSTFLAGS }-C symbol-mangling-version=v0" \
    make -C "$SOURCE_ROOT" CARGO_BUILD_ROOT="$server_build_root" build-server-release
  local server_source="$server_build_root/vibecrafted-server/release/vibecrafted-server-web"
  local server_site="$server_build_root/vibecrafted-server/site"
  [[ -x "$server_source" ]] || die "Vibecrafted Server release binary is missing"
  [[ -d "$server_site/pkg" ]] || die "Vibecrafted Server hydrated site is missing"

  log "Building the scaffold-doctor gate and control-observe binaries from control-core"
  (cd "$SOURCE_ROOT/vibecrafted-server" \
    && CARGO_TARGET_DIR="$server_build_root/vibecrafted-server" \
      cargo build --release --locked -p control-core \
        --bin scaffold-doctor --bin control-observe)
  local scaffold_doctor_source="$server_build_root/vibecrafted-server/release/scaffold-doctor"
  local control_observe_source="$server_build_root/vibecrafted-server/release/control-observe"
  [[ -x "$scaffold_doctor_source" ]] || die "scaffold-doctor release binary is missing"
  [[ -x "$control_observe_source" ]] || die "control-observe release binary is missing"
  chmod 0755 "$scaffold_doctor_source" "$control_observe_source"

  materialize_runtime_payload "$RUNTIME_PAYLOAD" \
    "$terminal_source" "$frame_source" "$start_source" "$voc_source" \
    "$server_source" "$server_site" "$scaffold_doctor_source" \
    "$control_observe_source" "$admin_source" "$procs_source"
  produce_runtime_pack
  [[ "$MODE" == "runtime-pack" ]] && return

  log "Building the single Swift host app"
  local generated_project="vibecrafted-app/shell-agent/app/Vibecrafted.xcodeproj"
  if git -C "$SOURCE_ROOT" ls-files --error-unmatch "$generated_project" >/dev/null 2>&1; then
    die "generated Xcode project must not be tracked; project.yml is the source of truth"
  fi
  make -C "$SOURCE_ROOT/vibecrafted-app/shell-agent" bindings xcode
  rm -rf "$BUILD_DIR/DerivedData" "$APP"
  mkdir -p "$BUILD_DIR" "$DIST_DIR"
  # `$(inherited)` is xcodebuild's own build-setting syntax, not a shell
  # command substitution: it must reach xcodebuild verbatim, so the single
  # quotes are the point. The prefix maps beside it ARE expanded, which is why
  # each setting is spliced from a quoted and an unquoted half.
  # This value is literal source or output for a later shell, awk, or Xcode evaluator; expanding its
  # dollar expressions in the producing shell would change the emitted contract.
  # shellcheck disable=SC2016
  xcodebuild \
    -project "$SOURCE_ROOT/vibecrafted-app/shell-agent/app/Vibecrafted.xcodeproj" \
    -scheme Vibecrafted -configuration Release \
    -derivedDataPath "$BUILD_DIR/DerivedData" \
    OTHER_SWIFT_FLAGS='$(inherited) '"$SWIFT_PREFIX_MAP" \
    OTHER_CFLAGS='$(inherited) '"$FILE_PREFIX_MAP" \
    CODE_SIGNING_ALLOWED=NO CODE_SIGNING_REQUIRED=NO build
  local built_app
  built_app="$(find "$BUILD_DIR/DerivedData" -type d -name Vibecrafted.app -print -quit)"
  [[ -n "$built_app" ]] || die "xcodebuild did not produce Vibecrafted.app"
  /usr/bin/ditto "$built_app" "$APP"
  configure_update_channel
  local resources="$APP/Contents/Resources"
  mkdir -p "$resources"
  log "Binding the canonical vc-terminal icon to Vibecrafted.app"
  "$SOURCE_ROOT/scripts/build-vibecrafted-icon.sh" \
    "$ICON_SOURCE" "$resources/Vibecrafted.icns" "$ICON_REFERENCE"
  if find "$resources" -maxdepth 1 -type f -name '*.icns' \
      ! -name 'Vibecrafted.icns' -print -quit | grep -q .; then
    die "assembled app contains a non-canonical application icon"
  fi
  /usr/libexec/PlistBuddy -c "Set :CFBundleIconFile Vibecrafted.icns" \
    "$APP/Contents/Info.plist" 2>/dev/null \
    || /usr/libexec/PlistBuddy -c "Add :CFBundleIconFile string Vibecrafted.icns" \
      "$APP/Contents/Info.plist"
  /usr/libexec/PlistBuddy -c "Set :CFBundleDisplayName Vibecrafted" \
    "$APP/Contents/Info.plist" 2>/dev/null \
    || /usr/libexec/PlistBuddy -c "Add :CFBundleDisplayName string Vibecrafted" \
      "$APP/Contents/Info.plist"
  # Vetcoders decision 2026-10-06: full Dock identity; an explicit false keeps
  # a regression back to the tray-only accessory loud at build time.
  [[ "$(/usr/libexec/PlistBuddy -c 'Print :LSUIElement' \
    "$APP/Contents/Info.plist")" == "false" ]] \
    || die "Vibecrafted.app must carry full Dock identity (LSUIElement=false)"
  [[ -s "$resources/TrayIcon.png" ]] \
    || die "Vibecrafted.app is missing its dedicated tray pictogram"
  remove_ambient_swift_rpath

  log "Embedding the already-materialized Runtime Pack payload"
  local runtime="$resources/runtime"
  mkdir -p "$APP/Contents/Helpers" "$resources/terminal"
  /usr/bin/ditto "$RUNTIME_PAYLOAD" "$runtime"
  # Both native executables live under one physical signed app identity.
  install -m 0755 "$terminal_source" "$APP/Contents/MacOS/vc-terminal"
  embed_terminal_font_resources "$APP"
  install -m 0755 "$frame_source" "$APP/Contents/Helpers/vc-frame"
  install -m 0755 "$SOURCE_ROOT/scripts/vc-app-update.sh" "$APP/Contents/Helpers/vc-app-update"

  install -m 0644 "$SOURCE_ROOT/config/vc-terminal/vibecrafted.toml" \
    "$resources/terminal/vibecrafted.toml"

  if find "$APP" -type l -print -quit | grep -q .; then
    die "assembled app contains symlinks"
  fi

  # Before a signature is spent, and before notarization makes these bytes
  # permanent, ask the finished bundle who built it. This gate exists because
  # every compiler-side answer is partial: measured on the shipped 4.1.0 DMG,
  # eight files named the operator across five producers rustc cannot all
  # reach. See scripts/payload_hygiene.py.
  log "Stripping linker debug stabs from the binaries this build produced"
  strip_debug_stabs

  log "Asserting the assembled app does not name the build host"
  assert_payload_is_anonymous "$APP" "Vibecrafted.app"

  log "Signing nested code and binding exact source receipts"
  # The actual assembly boundary owns privacy metadata and signing inputs.
  # Xcode signing is disabled above; CODE_SIGN_ENTITLEMENTS alone is insufficient.
  local host_entitlements="$BUILD_DIR/host-entitlements.plist"
  PYTHONPATH="$SOURCE_ROOT/vibecrafted-core" "$SOURCE_ROOT/scripts/project-python" \
    "$SOURCE_ROOT/scripts/unified_product_manifest.py" host-permissions \
    --app "$APP" --entitlements-output "$host_entitlements" \
    > "$BUILD_DIR/host-permissions-plan.json"
  sign_macho_tree "$APP/Contents" "$APP/Contents/MacOS/Vibecrafted" \
    "$APP/Contents/MacOS/vc-terminal" "$host_entitlements" \
    "$runtime/libexec/vc-terminal"
  sign_nested_app_bundles
  sign_helper_scripts
  embed_runtime_pack
  require_clean_repo "$SOURCE_ROOT" vibecrafted
  require_bound_revision "$SOURCE_ROOT" vibecrafted "$ROOT_SHA"
  require_clean_repo "$TERMINAL_REPO" vc-terminal
  require_clean_repo "$FRAME_REPO" vc-frame ${FRAME_DERIVED+"${FRAME_DERIVED[@]}"}
  PYTHONPATH="$SOURCE_ROOT/vibecrafted-core" "$SOURCE_ROOT/scripts/project-python" \
    "$SOURCE_ROOT/scripts/unified_product_manifest.py" app \
    --app "$APP" --terminal-source "$terminal_source" --frame-source "$frame_source" \
    --version "$VERSION" --build "$BUILD_NUMBER" \
    --vibecrafted-sha "$ROOT_SHA" \
    --terminal-sha "$(git_sha "$TERMINAL_REPO")" \
    --frame-sha "$(git_sha "$FRAME_REPO")"
  codesign --force --options runtime --timestamp --sign "$SIGNING_IDENTITY" \
    "${CODESIGN_KEYCHAIN_ARGS[@]}" --entitlements "$host_entitlements" "$APP"
  log "Probing the signed bundled Python without mutating the app seal"
  "$runtime/bin/python3" -c 'import jsonschema, yaml, vibecrafted_core.product_contract'
  if find "$APP/Contents" \( -type d -name __pycache__ -o -type f -name '*.py[co]' \) \
      -print -quit | grep -q .; then
    die "bundled Python mutated the signed application payload"
  fi
  codesign --verify --deep --strict --verbose=2 "$APP"
  PYTHONPATH="$SOURCE_ROOT/vibecrafted-core" "$SOURCE_ROOT/scripts/project-python" \
    "$SOURCE_ROOT/scripts/unified_product_manifest.py" host-permissions \
    --app "$APP" --verify-only --verify-signatures \
    > "$BUILD_DIR/host-permissions-receipt.json"
  verify_update_channel
  run_bundled_verifier app "$APP" --require-clean
}

create_dmg() {
  local staging="$BUILD_DIR/dmg-staging"
  rm -rf "$staging" "$DMG"
  rm -f "$DMG_CHECKSUM" "$LEGACY_DMG"
  mkdir -p "$staging"
  /usr/bin/ditto "$APP" "$staging/Vibecrafted.app"
  ln -s /Applications "$staging/Applications"
  hdiutil create -volname Vibecrafted -srcfolder "$staging" -ov -format UDZO "$DMG"
  codesign --force --timestamp --sign "$SIGNING_IDENTITY" \
    "${CODESIGN_KEYCHAIN_ARGS[@]}" "$DMG"
}

notarize_product() {
  local app_zip="$BUILD_DIR/Vibecrafted.app.zip"
  # Also covers --notarize-only: do not spend a ticket on an older assembly
  # that lacks host declarations or loses terminal entitlements on re-sign.
  # The source snapshot is reaped after a build; notarize-only reads the
  # current checkout's verifier just like verify_update_channel above.
  PYTHONPATH="$REPO_ROOT/vibecrafted-core" "$REPO_ROOT/scripts/project-python" \
    "$REPO_ROOT/scripts/unified_product_manifest.py" host-permissions \
    --app "$APP" --verify-only --verify-signatures \
    > "$BUILD_DIR/host-permissions-receipt.json"
  verify_runtime_pack_macho_signatures "$EMBEDDED_RUNTIME_PACK" \
    || die "refusing notarization: embedded Runtime Pack Mach-O preflight failed"
  rm -f "$app_zip"
  /usr/bin/ditto -c -k --keepParent "$APP" "$app_zip"
  notary_submit "$app_zip"
  xcrun stapler staple "$APP"
  xcrun stapler validate "$APP"
  spctl --assess --type execute --verbose=2 "$APP"
  create_dmg
  notary_submit "$DMG"
  xcrun stapler staple "$DMG"
  xcrun stapler validate "$DMG"
  spctl --assess --type open --context context:primary-signature --verbose=2 "$DMG"
}

emit_release_tuple() {
  PYTHONPATH="$REPO_ROOT/vibecrafted-core" "$REPO_ROOT/scripts/project-python" \
    "$REPO_ROOT/scripts/unified_product_manifest.py" release \
    --app "$APP" --dmg "$DMG" --runtime-pack "$RUNTIME_PACK" \
    --output "$DIST_DIR/release-output.json"
  /usr/bin/openssl dgst -sha256 -sign "$SIGNING_KEY" \
    -out "$DIST_DIR/release-output.json.sig" "$DIST_DIR/release-output.json"
  run_bundled_verifier release-output \
    "$DIST_DIR/release-output.json" "$DIST_DIR/release-output.json.sig"
  (
    cd "$DIST_DIR"
    /usr/bin/shasum -a 256 "$DMG_NAME" > "$(basename "$DMG_CHECKSUM")"
  )
}

verify_runtime_pack_projection() {
  log "Verifying App carries the exact standalone Runtime Pack bytes"
  [[ -s "$RUNTIME_PACK" ]] || die "standalone Runtime Pack is missing: $RUNTIME_PACK"
  [[ -s "$RUNTIME_PACK_CHECKSUM" ]] \
    || die "standalone Runtime Pack checksum is missing: $RUNTIME_PACK_CHECKSUM"
  [[ -s "$RUNTIME_PACK_SIGNATURE" ]] \
    || die "standalone Runtime Pack signature is missing: $RUNTIME_PACK_SIGNATURE"
  cmp "$EMBEDDED_RUNTIME_PACK" "$RUNTIME_PACK"
  cmp "$EMBEDDED_RUNTIME_PACK_CHECKSUM" "$RUNTIME_PACK_CHECKSUM"
  cmp "$EMBEDDED_RUNTIME_PACK_SIGNATURE" "$RUNTIME_PACK_SIGNATURE"
}

if [[ "$MODE" == "notarize" ]]; then
  [[ -d "$APP" ]] || die "missing $APP; run make dmg-signed first"
  verify_update_channel
  verify_runtime_pack_projection
  notarize_product
  emit_release_tuple
  exit 0
fi

build_product
[[ "$MODE" == "runtime-pack" ]] && exit 0
verify_runtime_pack_projection
[[ "$MODE" == "app" ]] && exit 0
if [[ "$MODE" == "dmg" ]]; then
  create_dmg
  exit 0
fi
notarize_product
emit_release_tuple
log "Release complete: $DMG"
