#!/bin/bash
# vc-terminal-product-entry.sh — generation-local choke point for the host
# terminal (Alacritty branded as vc-terminal).
#
# The Mach-O/ELF lives at ../libexec/vc-terminal. This wrapper always pins
# --config-file to the product vc-terminal.toml so a raw
#   $VIBECRAFTED_RUNTIME_HOME/releases/<ver>/bin/vc-terminal
# never falls through to the operator's private ~/.config/alacritty/.
# Alacritty does not expand ${HOME} in [terminal].shell.program; the private
# config is not a product surface.
#
# macOS terminal bytes execute inside the fixed /Applications/Vibecrafted.app
# main bundle. Generations remain internal; Linux uses the flat native host.
#
# 𝚅𝚒𝚋𝚎𝚌𝚛𝚊𝚏𝚝𝚎𝚍. with AI Agents by Vetcoders (c)2024-2026 LibraxisAI
set -euo pipefail

# A visible terminal enables TTY color without forcing ordinary shell pipelines.
# Explicit provider/pane launches force their own level in env_allowlist.py.
unset NO_COLOR NODE_DISABLE_COLORS ANSI_COLORS_DISABLED FORCE_COLOR CLICOLOR_FORCE
case "${TERM:-dumb}" in dumb) export TERM=xterm-256color ;; esac
export CLICOLOR=1

# Root discovery cannot call PATH tools. Sanitization has not run yet, and a
# hostile or empty inherited PATH is a supported startup case.
_vc_terminal_entry="${BASH_SOURCE[0]}"
_vc_terminal_scripts="${_vc_terminal_entry%/*}"
if [[ -z "$_vc_terminal_scripts" ]]; then
  _vc_terminal_scripts="/"
elif [[ "$_vc_terminal_scripts" == "$_vc_terminal_entry" ]]; then
  _vc_terminal_scripts="."
fi
root="$(cd "${_vc_terminal_scripts}/.." && pwd -P)"
unset _vc_terminal_entry _vc_terminal_scripts
native_host="$root/libexec/vc-terminal"
config="$HOME/.config/vibecrafted/vc-terminal/vc-terminal.toml"

# This terminal starts a fresh interactive shell. Old Runtime Pack bins from
# its parent must not become ambient commands there. Mirror the runtime shell's
# anchored ownership grammar: only direct children of this runtime home's
# releases directory are owned; user lookalikes stay untouched.
_vc_terminal_runtime_home() {
  # The physical wrapper selects the generation. A parent can carry a stale
  # runtime-root from an earlier launch, which must not choose this boundary.
  local selected="$root" generation
  if [[ -n "${VIBECRAFTED_RUNTIME_HOME:-}" ]]; then
    printf '%s\n' "${VIBECRAFTED_RUNTIME_HOME%/}"
  elif [[ "$selected" == */releases/* ]]; then
    generation="${selected##*/releases/}"
    if [[ -n "$generation" && "$generation" != */* ]]; then
      printf '%s\n' "${selected%/releases/*}"
      return
    fi
    printf '%s\n' "${XDG_DATA_HOME:-$HOME/.local/share}/vibecrafted"
  elif [[ -n "${XDG_DATA_HOME:-}" ]]; then
    printf '%s\n' "${XDG_DATA_HOME%/}/vibecrafted"
  else
    printf '%s\n' "$HOME/.local/share/vibecrafted"
  fi
}

_vc_terminal_is_owned_generation_bin() {
  local entry="${1:-}" runtime_home generation leaf
  runtime_home="$(_vc_terminal_runtime_home)"
  entry="${entry%/}"
  [[ -n "$runtime_home" && "$entry" == "$runtime_home/releases/"*/bin ]] || return 1
  generation="${entry#"$runtime_home/releases/"}"
  leaf="${generation%/bin}"
  [[ -n "$leaf" && "$leaf" != */* ]]
}

_vc_terminal_sanitize_inherited_path() {
  local inherited="${PATH-}" remaining entry joined index
  local -a retained=()
  # A sentinel preserves an empty final component. Empty PATH entries name the
  # caller's working directory, so they are retained rather than normalized.
  remaining="${inherited}:"
  while [[ -n "$remaining" ]]; do
    entry="${remaining%%:*}"
    remaining="${remaining#*:}"
    _vc_terminal_is_owned_generation_bin "$entry" || retained+=("$entry")
  done
  # Explicit join keeps empty, spaced, and repeated components in order.
  joined=""
  index=0
  while ((index < ${#retained[@]})); do
    if ((index)); then
      joined="${joined}:"
    fi
    joined="${joined}${retained[index]}"
    index=$((index + 1))
  done
  PATH="$joined"
  export PATH
}

_vc_terminal_is_bundle_host() {
  local candidate="${1:-}" bundle=/Applications/Vibecrafted.app
  [[ "$candidate" == "$bundle/Contents/MacOS/vc-terminal" ]] || return 1
  [[ -f "$candidate" && -x "$candidate" && ! -L "$candidate" ]] || return 1
  [[ ! -L "$bundle" && ! -L "$bundle/Contents" && ! -L "$bundle/Contents/MacOS" ]] || return 1
  [[ -f "$bundle/Contents/Info.plist" && ! -L "$bundle/Contents/Info.plist" ]] || return 1
  [[ "$(/usr/libexec/PlistBuddy -c 'Print :CFBundleIdentifier' "$bundle/Contents/Info.plist" 2>/dev/null)" == "io.vetcoders.vibecrafted" ]] || return 1
  [[ "$(/usr/libexec/PlistBuddy -c 'Print :CFBundleExecutable' "$bundle/Contents/Info.plist" 2>/dev/null)" == "Vibecrafted" ]] || return 1
}

_vc_terminal_select_host() {
  local fallback="$1" candidate=/Applications/Vibecrafted.app/Contents/MacOS/vc-terminal
  [[ "$(/usr/bin/uname -s)" == "Darwin" ]] || { printf '%s\n' "$fallback"; return 0; }
  if _vc_terminal_is_bundle_host "$candidate"; then
    printf '%s\n' "$candidate"
    return 0
  fi
  printf 'vc-terminal: fixed signed host missing at /Applications/Vibecrafted.app; install the reviewed notarized app before opening a terminal.\n' >&2
  return 78
}

_vc_terminal_sanitize_inherited_path
if [[ "$native_host" != /* || ! -x "$native_host" || -L "$native_host" || -L "$root/libexec" ]]; then
  printf 'vc-terminal: native host missing: %s\n' "$native_host" >&2
  exit 127
fi
host="$(_vc_terminal_select_host "$native_host")"
unset -f _vc_terminal_runtime_home _vc_terminal_is_owned_generation_bin \
  _vc_terminal_sanitize_inherited_path _vc_terminal_is_bundle_host \
  _vc_terminal_select_host

export VIBECRAFTED_RUNTIME_ROOT="$root"
export VIBECRAFTED_ROOT="$root"
export VIBECRAFTED_RUNTIME_BIN="$root/bin"
export VIBECRAFTED_TERMINAL_HOST="$host"
export XDG_CONFIG_HOME="$HOME/.config"
export VIBECRAFTED_PYTHON="$root/bin/python3"
export VIBECRAFTED_VC_FRAME_BIN="$root/libexec/vc-frame"
export VC_FRAME_CONFIG_DIR="$HOME/.config/vibecrafted/vc-frame"
unset VC_FRAME_CONFIG_FILE PYTHONPATH PYTHONHOME native_host
# The runtime python pin: this terminal's python and python3 are the
# interpreter pinned above, reached through the generation's door. The shell
# profile only inherits it and puts the door back after zsh startup.
if [[ -x "$root/config/runtime-pin/bin/python3" ]]; then
  PATH="$root/config/runtime-pin/bin${PATH:+:$PATH}"
  export PATH
fi

# This wrapper creates a new native terminal, so it must not pass through an
# attachment identity from the non-interactive caller.  The child may start a
# fresh VC Frame client, but inherited pane/session values would make its
# front-door believe it already owns the caller's attached surface.  Clear both
# current VC Frame and legacy Zellij twins only in this exec path; the parent
# shell environment is unaffected.
unset VC_FRAME VC_FRAME_PANE_ID VC_FRAME_SESSION_NAME
unset ZELLIJ ZELLIJ_PANE_ID ZELLIJ_SESSION_NAME

if [[ "$host" != /* || ! -x "$host" || -L "$host" ]]; then
  printf 'vc-terminal: native host missing: %s\n' "$host" >&2
  exit 127
fi
# Identity probe: --version answers from the host binary without opening a
# window or reading any config, so it must not require the installed product
# config. The Runtime Pack inventory calls bin/vc-terminal --version on build
# hosts that have no ~/.config/vibecrafted at all.
if [[ $# -eq 1 ]]; then
  case "$1" in
    --version | -V | --help | -h)
      exec "$host" "$1"
      ;;
    --doctor)
      exec "$root/bin/python3" -B "$root/scripts/vetcoders_install.py" runtime-repair --json
      ;;
  esac
fi
if [[ ! -f "$config" || -L "$config" || -L "$HOME/.config" \
  || -L "$HOME/.config/vibecrafted" || -L "$HOME/.config/vibecrafted/vc-terminal" ]]; then
  printf 'vc-terminal: product config missing: %s\n' "$config" >&2
  printf 'Vibecrafted does not read ~/.config/alacritty. Launch via the app or PATH vc-terminal after runtime-install.\n' >&2
  exit 2
fi

# Alacritty's -e/--command consumes all remaining argv, including hyphens.
# Consume values of terminal options so a title such as "-e" is not a boundary.
value_pending=false
option_pending=false
explicit_command=false
shell_options=(--config-file "$config")
for argument in "$@"; do
  if $value_pending; then
    if $option_pending; then
      shell_options+=(--option "$argument")
    fi
    value_pending=false
    option_pending=false
    continue
  fi
  # clap accepts short flag clusters: -veCOMMAND has the same boundary as -e.
  if [[ "$argument" =~ ^-[qv]*e ]]; then
    explicit_command=true
    break
  fi
  if [[ "$argument" =~ ^-[qv]*[tTo]$ ]]; then
    value_pending=true
    [[ "$argument" == *o ]] && option_pending=true
    continue
  fi
  case "$argument" in
    -e* | --command | --command=* | --)
      explicit_command=true
      break
      ;;
    --config-file | --config-file=*)
      printf 'vc-terminal: --config-file is product-owned: %s\n' "$config" >&2
      exit 2
      ;;
    --socket | --socket=*)
      if [[ "$host" == */Contents/MacOS/vc-terminal ]]; then
        printf 'vc-terminal: the host IPC socket is product-owned\n' >&2
        exit 2
      fi
      value_pending=true
      ;;
    --option)
      value_pending=true
      option_pending=true
      ;;
    --option=*) shell_options+=(--option "${argument#*=}") ;;
    -o?*) shell_options+=(--option "${argument#-o}") ;;
    --embed | --working-directory | --title | -T | -t | --class | -s)
      value_pending=true
      ;;
  esac
done
host_tail=(${1+"$@"})
if ! $explicit_command; then
  if ! startup_error="$("$root/bin/python3" -B "$root/scripts/vetcoders_install.py" terminal-shell-check \
    "${shell_options[@]}" 2>&1)"; then
    export VIBECRAFTED_TERMINAL_STARTUP_ERROR="${startup_error:-terminal shell preflight failed}"
    primary="$HOME/.config/vibecrafted/vc-terminal/launch-primary-shell.zsh"
    [[ -f "$primary" ]] || primary="$root/config/alacritty/launch-primary-shell.zsh"
    if [[ -f "$primary" ]]; then
      # Override for this invocation only. Never persist diagnostic argv.
      host_tail=(${1+"$@"} -e /bin/bash "$primary")
    else
      # Even a damaged generation must leave a readable terminal with a shell.
      host_tail=(${1+"$@"} -e /bin/zsh -fc
        'print -u2 -- "Vibecrafted: product shell missing. Open Vibecrafted.app → Repair Runtime; run vc-terminal --doctor. Startup log unavailable: product shell missing."; exec /bin/zsh -dfi')
    fi
  fi
fi

# One fixed macOS host per user: every further window is a native
# `msg create-window` request to the admitted host, never a second GUI
# process. The helper serializes first start under a private flock, proves the
# host by kernel identity and socket peer, and writes the launch receipt the
# App consumes. Delivery is not window readiness and never agent start; a
# refusal is final here, without a duplicate-host fallback. Linux keeps the
# flat host: no portable proof of host identity is claimed there.
admission_helper="$root/vibecrafted-core/vibecrafted_core/terminal_host.py"
launch_receipt="${VIBECRAFTED_TERMINAL_LAUNCH_RECEIPT:-}"
unset VIBECRAFTED_TERMINAL_LAUNCH_RECEIPT
if [[ "$host" == */Contents/MacOS/vc-terminal && "$(/usr/bin/uname -s)" == "Darwin" ]]; then
  if [[ -f "$admission_helper" && ! -L "$admission_helper" && -x "$root/bin/python3" ]]; then
    admission_args=(admit --wrapper-pid "$$" --host "$host" --config "$config")
    [[ -z "$launch_receipt" ]] || admission_args+=(--receipt "$launch_receipt")
    # exec keeps the wrapper as the helper's direct parent: its PID is the
    # identity the fresh host inherits through the exec below.
    admission="$(exec "$root/bin/python3" -I -B "$admission_helper" "${admission_args[@]}" -- ${host_tail[@]+"${host_tail[@]}"})" \
      || exit $?
    case "$admission" in
      reused) exit 0 ;;
      fresh) exec "$host" --config-file "$config" ${host_tail[@]+"${host_tail[@]}"} ;;
    esac
    printf 'vc-terminal: unrecognized host admission: %s\n' "$admission" >&2
    exit 70
  fi
  # Without its admission helper a generation cannot prove the single host;
  # starting an unadmitted GUI would be the duplicate this boundary forbids.
  printf 'vc-terminal: host admission helper missing: %s; run vc-terminal --doctor.\n' \
    "$admission_helper" >&2
  exit 78
fi
exec "$host" --config-file "$config" ${host_tail[@]+"${host_tail[@]}"}
