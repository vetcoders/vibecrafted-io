# Changelog

All notable changes to this project will be documented in this file.

## [0.4.1] - 2026-05-06

### Added

- **5-step interactive wizard** replacing the legacy 4-step flow:
  DiscoverySources → ServerReview → StrategyChoice → SummaryConfirm → ResultAndTray.
- **Three explicit strategies** for using mux:
  - **Unified** — one ~/.config/mux/{config.toml, mcp.json, mcp.toml}.
  - **Per-client** — separate mux config per originating client kind in
    that client's native format (claude.json, codex.toml, junie.json, ...).
  - **[DANGER] Auto-rewire** — backup-first preview-first rewrite of
    existing client configs to route through `rmcp-mux-proxy`, with
    rollback commands.
- **Custom-path input** on STEP 1 (`i` to enter) for client config files
  outside the default discovery list.
- **Tray daemon prompt** on STEP 5: spawn `rmcp-mux --tray --config
<generated>` detached from the wizard session.
- New helpers:
  - `mux_gen::build_per_client_outputs` + `write_per_client_outputs` +
    `per_client_instructions` for the Per-client strategy.
  - `wizard::services::build_services_from_scans` /
    `enrich_running_state` / `load_services_from_custom_path` as the
    public discovery surface.
  - `config` checked file-read/copy helpers that reject parent
    traversal at the filesystem boundary.
- New canonical doc surfaces: `AGENTS.md` (per-repo,
  agent-agnostic doctrine) and a fully rewritten `docs/WIZARD.md`.

### Changed

- **Discovery is now driven by client config files**, not by ps-scan.
  The legacy `MCP_PATTERNS` whitelist is demoted to enrichment-only —
  it stamps PIDs on matching entries and surfaces ps-only orphans, but
  never drives the discovery list.
- **Source-of-truth model** flipped: client configs (Claude / Codex /
  Junie / Gemini / ...) are authoritative; running processes are
  side-effects.
- **Wizard title** rebranded from `rmcp_mux wizard` to `rmcp-mux
wizard`. Daemon-status banner and multi-server dashboard header
  rebranded in lockstep.
- **Socket path canonicalised** to v0.4.0
  `~/.rmcp-servers/rmcp-mux/sockets/` everywhere (was a mix of
  `~/mcp-sockets/` and the canonical path).
- **AI_README** bumped to 0.4.0 / 2026-05-05; project structure
  reflects modular `runtime/` + `wizard/` and the new helper modules.

### Fixed

- Self-skip dedup bug in the ps-scan: `args.contains("rmcp-mux") ||
args.contains("rmcp-mux")` was a copy/paste; the second clause now
  correctly matches the legacy `rmcp_mux` binary name.
- Per-client strategy output collisions for same-kind sources (Junie
  ×3, Cursor ×2, VSCode ×2): same-kind scans now merge before writing
  one file per kind.
- Per-client and danger strategies now honour STEP 2 server selection
  (previously rescanned the source verbatim).
- Wizard's per-client summary filenames now follow STEP 2 selected
  services instead of selected source rows.
- Socket allocation ownership returned to `mux_gen` (services.rs no
  longer injects a default socket path that mux_gen would override).
- Removed dead `#[allow(dead_code)]` carry-overs from the C2/C3
  rebuild after consumers landed in the 5-step flow.
- Documentation drift: rmcp_mux references in doc comments, status
  banners, and proxy `--socket` help text replaced with rmcp-mux.

### Security

- Audited dependency tree for the `tray` feature: 0 vulnerabilities, 1
  unsoundness (glib 0.18.5 RUSTSEC-2024-0429, not on rmcp-mux's call
  graph) and 8 unmaintained advisories (GTK3 stack via tray-icon).
  Tracked in `AGENTS.md` under "Tray feature
  dependency risks". CI mitigation: `--no-default-features`.
- `config::checked_read_to_string` and `checked_copy` helpers reject
  parent-traversal paths and canonicalise filesystem boundaries; used
  by `scan::scan_host_file` and `danger` plan execution.

### Coverage notes

- `cargo test --all-targets --all-features` baseline went from 83 → 87
  passing (+4 new wizard::services tests, plus persist.rs scenarios).
  `mux_transport_roundtrip_with_loctree_mcp` (ignored) passes against
  local `loctree-mcp v0.9.4`.

## [0.4.0] - 2025-12-26

### Breaking Changes

- **Default paths changed** from `~/.rmcp_servers/rmcp_mux/` to `~/.rmcp-servers/rmcp-mux/`.
- **Proxy command** changed from `rmcp_mux_proxy` to `rmcp-mux-proxy`.

### Added

- **Daemon Status Socket** - Query running daemon status via Unix socket.
- **Heartbeat System** - Configurable health checks for MCP servers.
  - `heartbeat_enabled` - Enable/disable per-server heartbeat
  - `heartbeat_interval_ms` - Check interval (default: 30s)
  - `heartbeat_timeout_ms` - Timeout before marking unhealthy
- **Tray Dashboard** - Multi-server status view in system tray.
- **Standalone Build** - Inlined common types, no workspace dependencies.

### Changed

- Default socket directory: `~/.rmcp-servers/rmcp-mux/sockets`.
- Default service name: `rmcp-mux` (hyphenated).
- Detection now matches both `rmcp-mux` and legacy `rmcp_mux` patterns.
- Updated to Rust Edition 2024 (stable).

### Fixed

- Consistent naming across paths, commands, and documentation.

## [0.3.4] - 2025-12-20

### Fixed

- Minor bug fixes and stability improvements.

## [0.3.0] - 2025-12-04

### Added

- **Library-first architecture** – rmcp-mux is now an embeddable Rust library, not just a CLI tool.
- `MuxConfig` builder for programmatic configuration:
  ```rust
  let config = MuxConfig::new("/tmp/mcp.sock", "npx")
      .with_args(vec!["@mcp/server-memory".into()])
      .with_max_clients(10);
  ```
- `run_mux_server(config)` – blocking entry point for single mux server.
- `spawn_mux_server(config)` – non-blocking spawn returning `MuxHandle` for lifecycle control.
- `MuxHandle` with `shutdown()`, `wait()`, `is_running()` methods.
- `run_mux_with_shutdown(params, token)` – external `CancellationToken` support for custom shutdown logic.
- `check_health(socket_path)` – simple health check function.
- `CliOptions` trait for generic CLI parameter handling.
- `docs/integration.md` – comprehensive library integration guide.
- Feature flags: `cli` (wizard, scan, binaries) and `tray` (system tray icon).

### Changed

- **Rebranded: `rmcp_mux` → `rmcp-mux`.** Crate name hyphenated on crates.io per convention; module path `rmcp_mux`. Binary `rmcp_mux_proxy` → `rmcp_mux_proxy`. All internal imports `use rmcp_mux::` → `use rmcp_mux::`. User-facing `RMCP_MUX_*` environment variables preserved for backward compatibility.
- **Moved to Loctree org:** `https://github.com/vetcoders/rmcp-mux` → `https://github.com/Loctree/rmcp-mux`.

### Added

- Package metadata: `description`, `repository`, `homepage`, `documentation`, `readme`, `keywords`, `categories`, `license = "MIT OR Apache-2.0"`, and `authors = ["Vetcoders <hello@vetcoders.io>"]` in `Cargo.toml` for proper crates.io listing and discovery.

## 0.2.0 - 2025-11-24

### Added

- Optional tray icon (`--tray`) showing live server status, client and pending counts, and restart reasons. ([5eefde4](https://github.com/LibraxisAI/rmcp_mux/commit/5eefde4))
- Config file support (JSON/YAML/TOML) with auto-detection and CLI overrides. ([5eefde4](https://github.com/LibraxisAI/rmcp_mux/commit/5eefde4))
- `rmcp-mux-proxy` helper binary plus launchd template and installer tweaks for easier setup. ([04e5402](https://github.com/LibraxisAI/rmcp_mux/commit/04e5402))
- GitHub Actions CI workflow for formatting, linting, testing, and coverage, including an async proxy forwarding test. ([ad2b9aa](https://github.com/LibraxisAI/rmcp_mux/commit/ad2b9aa))
- Mux hooks, Semgrep rules, and expanded README documentation. ([e80083c](https://github.com/LibraxisAI/rmcp_mux/commit/e80083c))
- `health` subcommand to resolve config and assert socket reachability, plus unit tests for healthy/missing sockets.

### Changed

- Refactored mux state management and tray functionality into dedicated `state` and `tray` modules, with tray dependencies gated behind an optional `tray` feature; CI updated to run with `--no-default-features`. ([0d60764](https://github.com/LibraxisAI/rmcp_mux/commit/0d60764), [ad2b9aa](https://github.com/LibraxisAI/rmcp_mux/commit/ad2b9aa))

## 0.1.5

- Added JSON status snapshots (`--status-file` / `status_file`) including PID, queue depth, request limits, restart/backoff settings.
- Hardened runtime: lazy child start, request size guard, request timeouts, capped restart backoff, max restarts.
- Config/Wizard/Scan updated to surface new fields; defaults documented in README.
- Status writer task for tray/automation; MuxState now tracks queue depth and child PID.
- Tests cover initialize cache, resets, status snapshots, and proxy; CI runs fmt/clippy/tests/tarpaulin with `--no-default-features` (tray off in CI).
