import AppKit
import CoreText
import Darwin
import os.log
import SwiftUI

// The durable lifecycle trail (installLog, lifecycleLog, signal handlers)
// lives in LifecycleLog.swift — supervision evidence extracted from this
// delegate; the Runtime Pack installer owns initialization of the log file.

/// The owner's `vibecrafted.runtime-install-result.v1` launch contract.
///
/// One shape, two producers, both of them the installer: `runtime-install`
/// prints it after publishing a generation, and the read-only `runtime-resolve`
/// prints it back for the generation already installed. The App decodes this
/// and launches what it says. It derives none of these paths for itself — that
/// duplication is precisely what made the App a second opinion on what counts
/// as an installable runtime.
private struct CanonicalRuntimeInstall: Decodable {
  let root: URL
  let launcher: URL
  let terminal: URL
  let terminalHost: URL
  let frame: URL
  let start: URL
  let primaryShell: URL
  let terminalConfig: URL
  let frameConfig: URL
  let runtimeHome: URL
  let configHome: URL
  let craftedHome: URL

  enum CodingKeys: String, CodingKey {
    case root
    case launcher
    case terminal
    case terminalHost = "terminal_host"
    case frame
    case start
    case primaryShell = "primary_shell"
    case terminalConfig = "terminal_config"
    case frameConfig = "frame_config"
    case runtimeHome = "runtime_home"
    case configHome = "config_home"
    case craftedHome = "crafted_home"
  }

  init(from decoder: Decoder) throws {
    let container = try decoder.container(keyedBy: CodingKeys.self)

    func fileURL(_ key: CodingKeys) throws -> URL {
      let path = try container.decode(String.self, forKey: key)
      guard path.hasPrefix("/") else {
        throw DecodingError.dataCorruptedError(
          forKey: key, in: container,
          debugDescription: "runtime installer returned a non-absolute filesystem path")
      }
      return URL(fileURLWithPath: path)
    }

    root = try fileURL(.root)
    launcher = try fileURL(.launcher)
    terminal = try fileURL(.terminal)
    terminalHost = try fileURL(.terminalHost)
    frame = try fileURL(.frame)
    start = try fileURL(.start)
    primaryShell = try fileURL(.primaryShell)
    terminalConfig = try fileURL(.terminalConfig)
    frameConfig = try fileURL(.frameConfig)
    runtimeHome = try fileURL(.runtimeHome)
    configHome = try fileURL(.configHome)
    craftedHome = try fileURL(.craftedHome)
  }
}

final class EventObserver: @unchecked Sendable, EventCallback {
  func onEvent(eventJson: String) {
    DispatchQueue.main.async {
      NotificationCenter.default.post(
        name: NSNotification.Name("IpcEvent"), object: nil, userInfo: ["eventJson": eventJson])
    }
  }

  func onError(err: String) {
    print("IPC Stream Error: \(err)")
  }
}

/// Accumulates a bounded amount of one subprocess stream.
///
/// Foundation delivers pipe readability on its own queue, so this is the same
/// shape as `EventObserver` above: an `@unchecked Sendable` box whose mutation
/// is serialised by a lock. Draining continuously is what stops a child from
/// blocking forever on a full pipe buffer; the ceiling is what stops a chatty
/// failure from becoming unbounded memory behind the tray.
extension RuntimeIdentityProbe {
  /// The real filesystem. `exists` is deliberately positive presence, so an
  /// existing file this App cannot read stays an installation rather than
  /// becoming "nothing is installed".
  static var live: RuntimeIdentityProbe {
    RuntimeIdentityProbe(
      exists: { FileManager.default.fileExists(atPath: $0.path) },
      read: { try? Data(contentsOf: $0) },
      realPath: { $0.resolvingSymlinksInPath() },
      isExecutable: { FileManager.default.isExecutableFile(atPath: $0.path) })
  }
}

/// The App only ever resolves one thing: the owner's launch contract.
private typealias RuntimeContract = RuntimeResolution<CanonicalRuntimeInstall>

/// How long the quit path waits for the lifecycle launcher to describe active
/// work before treating its silence as an answer.
private let activityTruthTimeout: TimeInterval = 15

@MainActor
class AppDelegate: NSObject, NSApplicationDelegate, NSMenuItemValidation, CommandDeckActionHandling {
  var mainWindow: MainWindowController?
  private let model = AppModel()
  private lazy var webSession = WebConsoleSession()
  /// Tool and reference tabs. Owns windows and their web sessions only; the
  /// runtime, supervisor and terminal stay here.
  private lazy var tabs = NativeTabCoordinator(
    anchorWindow: { [unowned self] in
      self.showMainWindowIfNeeded()
      return self.mainWindow?.window
    },
    openExternally: { [unowned self] url in self.openExternalURL(url) })
  private var tray: StatusItemController?
  private var repairInFlight = false
  /// The App has one installer owner too: callers join this one launch rather
  /// than racing separate carrier publications against the installer's lease.
  private var runtimeInstallProcess: Process?
  private var runtimeInstallWaiters: [(Result<CanonicalRuntimeInstall, Error>) -> Void] = []
  private var confirmedStopRoot: URL?
  private var terminalWorkingDirectory = FileManager.default.homeDirectoryForCurrentUser
  private var signedCarrierRevisions: (source: String, terminal: String, frame: String)?
  private var statusRefreshTimer: Timer?
  private var terminalApplication: NSRunningApplication?
  private var terminalLaunchInFlight = false
  private var serverStatusProcess: Process?
  private var serverActionProcess: Process?
  private var serverActionInFlight: ServerLifecycleAction?
  /// The one tray action allowed to be preflighting its runtime identity. This
  /// is not the same as an action being in flight: between the click and the
  /// spawn the App is asking the owner what is installed, and a second click in
  /// that window would put two verbs on the same service.
  private var runtimeActionPreflight: String?
  private var serverUtilityProcess: Process?
  /// The last caretaker envelope bytes the status poll brought back. The menu,
  /// the diagnostics alert and the action in-flight state all render from this
  /// one reading — never from a second, privately-fused source.
  private var lastCaretakerData: Data?
  private var trayWorkProcess: Process?
  private var lastTrayWork: TrayWorkObservation?
  private var canonicalInstall: CanonicalRuntimeInstall?
  private var canonicalRuntimeEnvironment: [String: String]?
  private lazy var userShellPath = NativeUserShellPath { [unowned self] process, timeout, completion in
    try self.runBounded(process, timeout: timeout, label: "user-shell-path", completion: completion)
  }
  private var workspaceLaunchFailureReported = false
  private var eyeReconcileProcess: Process?
  private var runtimeResolveProcess: Process?
  /// Callers that asked while a resolve was already in flight. They join the
  /// one invocation instead of racing a second resolver against it.
  private var runtimeResolveWaiters: [(RuntimeContract) -> Void] = []
  /// Bumped whenever runtime truth changes — adopted, lost or refused. Results
  /// and actions carrying an older epoch are dropped, so a late answer for a
  /// previous generation can never repopulate live controls.
  private var runtimeResolveEpoch: UInt64 = 0
  private var cachedResolution: RuntimeResolutionCache<CanonicalRuntimeInstall>?
  private var runtimeResolveFailures = 0
  /// Why there is no usable runtime, rendered where the generation would be.
  private var runtimeResolutionFailure: String?
  /// A non-fatal note about the shared service, rendered under the runtime line.
  private var runtimeAdvisory: String?
  /// The owner's last word on configuration, for the diagnostics surface.
  private var lastConfigRepair: ConfigRepairEnvelope?
  /// Last hash-bound upgrade conflict, so Diagnostics can show it without the dialog.
  private var lastPreferenceConflict: PreferenceConflictEnvelope?
  private var configRepairProcess: Process?
  private var terminalLaunch: TerminalLauncher.Launch?
  private var terminalRegistration: TerminalRegistrationObservation?
  private var terminalRegistrationTimer: Timer?
  private var productUpdate: ProductUpdateCoordinator?
  private var productUpdatePanel: NSWindow?
  /// The native server status window. Lazily built, never released when closed,
  /// and re-rendered from `updateDeckPresentation` so an open window tracks the
  /// same caretaker reading as the tray instead of freezing a modal snapshot.
  private var serverStatusWindow: NSWindow?
  private var serverStatusHosting: NSHostingView<ServerStatusView>?
  private var productUpdateStartupAdoption: ProductUpdateHandoffAdoption = .none
  /// Cancel keeps the verified installation, without asking again this launch.
  private var startupCarrierChoiceOffered = false
  /// Long-lived `vc-frame web` started from the App when `[tools.vc-frame]`
  /// names a loopback origin. Tabs never own this process; closing a tab does
  /// not stop it, and workers are not in this process group.
  private var frameWebProcess: Process?
  let eventObserver = EventObserver()

  func showMainWindowIfNeeded() {
    if mainWindow == nil {
      mainWindow = MainWindowController(model: model, session: webSession, actions: self,
        openExternally: { [unowned self] url in self.openExternalURL(url) })
      mainWindow?.frameWebURL = { [weak self] in
        guard let self, let destination = ToolDestination.named("vc-frame"),
          case .available(let url, .service) = self.tabs.resolve(destination)
        else { return nil }
        return url
      }
    }
    mainWindow?.showWindow(nil)
    mainWindow?.window?.makeKeyAndOrderFront(nil)
    NSApp.activate(ignoringOtherApps: true)
  }

  func applicationDidFinishLaunching(_ notification: Notification) {
    if ProcessInfo.processInfo.arguments.contains("--uninstall") {
      do {
        try uninstallCanonicalRuntime()
        exit(EXIT_SUCCESS)
      } catch {
        fputs("Vibecrafted uninstall failed: \(error)\n", stderr)
        exit(EXIT_FAILURE)
      }
    }
    if ProcessInfo.processInfo.arguments.contains("--bootstrap-only") {
      do {
        let install = try installCanonicalRuntime()
        print(install.root.path)
        exit(EXIT_SUCCESS)
      } catch {
        fputs("Vibecrafted bootstrap failed: \(error)\n", stderr)
        exit(EXIT_FAILURE)
      }
    }

    if !claimUserAppInstanceOrHandoff() {
      return
    }

    installLifecycleSignalHandlers()
    let launchArgs = ProcessInfo.processInfo.arguments.dropFirst().joined(separator: " ")
    let launchedByLS = ProcessInfo.processInfo.environment["__CFBundleIdentifier"] != nil
    lifecycleLog(
      "launch ppid=\(getppid()) launchedByLS=\(launchedByLS) args=[\(launchArgs)]")

    // Vibecrafted is a full Dock application with its own icon and menu bar,
    // alongside the tray item (decyzja Macieja 2026-10-06; reverses 1cd41e51,
    // which hid the app as a tray-only accessory and left the window without
    // app identity). LSUIElement in Info.plist is false for the same reason.
    NSApp.setActivationPolicy(.regular)
    configureCommandDeck()
    buildMainMenu()
    buildStatusItem()
    startNativeNotifications()

    let socketPath = "/tmp/vibecrafted-mux.sock"
    do {
      try initRuntime(socketPath: socketPath)
      Task {
        do {
          try await subscribeEvents(callback: eventObserver)
        } catch {
          print("Failed to subscribe: \(error)")
        }
      }
    } catch {
      print("Failed to init runtime: \(error)")
    }

    showMainWindowIfNeeded()
    productUpdateStartupAdoption = adoptPendingProductUpdateIfNeeded()
    switch productUpdateStartupAdoption {
    case .waiting, .publishing, .restoring:
      break
    case .none, .retained:
      connectCommandDeck()
    }
  }

  func applicationShouldHandleReopen(_ sender: NSApplication, hasVisibleWindows: Bool) -> Bool {
    lifecycleLog("window.restore reason=application-reopen hadVisibleWindows=\(hasVisibleWindows)")
    showMainWindowIfNeeded()
    return true
  }

  func applicationDidHide(_ notification: Notification) {
    lifecycleLog("window.hide reason=application-hide session=retained")
  }

  func applicationDidUnhide(_ notification: Notification) {
    lifecycleLog("window.restore reason=application-unhide session=retained")
  }

  func applicationShouldTerminateAfterLastWindowClosed(_ sender: NSApplication) -> Bool {
    false
  }

  func applicationShouldTerminate(_ sender: NSApplication) -> NSApplication.TerminateReply {
    // Quit closes UI only; the service, terminals and agent lanes keep running.
    // An admitted helper must have a durable handoff before this process dies.
    if productUpdate?.hasAdmittedHelperHandoff == true {
      do {
        try productUpdate?.persistAdmittedHandoff()
      } catch {
        showNativeMessage(
          "Update handoff was not saved",
          "The window stays open so the update helper is not abandoned. \(error.localizedDescription)")
        return .terminateCancel
      }
    }
    return .terminateNow
  }

  func applicationSupportsSecureRestorableState(_ app: NSApplication) -> Bool {
    // AppKit NSApplicationDelegate declares this (NSApplication.h). Returning
    // true opts into secure NSCoding if any restorable state is encoded.
    // It is not a save/restore policy switch. That policy is owned by
    // window.isRestorable = false, restorationClass = nil on Command Deck
    // windows, and Info.plist NSQuitAlwaysKeepsWindows = false. Active AppKit
    // headers have no applicationShouldSave/RestoreApplicationState callback.
    true
  }

  func application(_ application: NSApplication, open urls: [URL]) {
    NotificationManager.shared.handleOpenURLs(urls)
  }

  func applicationWillTerminate(_ notification: Notification) {
    if productUpdate?.hasAdmittedHelperHandoff == true {
      productUpdate?.noteUIShutdownPreservingHandoff()
    } else {
      cancelRuntimePackInstaller()
      productUpdate?.interrupt()
    }
    // The workspace terminal is now started through the generation wrapper, so
    // it is a child of this process rather than an independent application.
    // That changes nothing about its lifetime: quitting the App is a view
    // closing. Nothing here stops the terminal, the shared service, frame
    // sessions, PTYs or workers, and nothing here should.
    let terminalState: String
    if let application = terminalApplication, !application.isTerminated {
      terminalState = "vc-terminal pid=\(application.processIdentifier) still running"
    } else if let launch = terminalLaunch, launch.isRunning {
      terminalState = "vc-terminal pid=\(launch.receipt.processIdentifier) still running"
    } else if terminalApplication != nil || terminalLaunch != nil {
      terminalState = "vc-terminal already exited"
    } else {
      terminalState = "no vc-terminal"
    }
    lifecycleLog("applicationWillTerminate; \(terminalState)")
    statusRefreshTimer?.invalidate()
    tray?.uninstall()
    terminalRegistrationTimer?.invalidate()
    NotificationManager.shared.clearHeartbeat(craftedHome: craftedHomeURL())
  }

  private func startNativeNotifications() {
    NotificationManager.shared.presentWindow = { [weak self] in
      self?.showMainWindowIfNeeded()
    }
    NotificationManager.shared.presentRun = { [weak self] runID, report, preferReport in
      guard !runID.isEmpty,
        runID.unicodeScalars.allSatisfy({ CharacterSet.alphanumerics.contains($0) || "-_".unicodeScalars.contains($0) }) else { return }
      self?.openRoute("/run/\(runID)")
      if preferReport, let report {
        do { try self?.nativeBridge.perform(.revealPath(try .init(path: report))) }
        catch { self?.showNativeMessage("Cannot reveal report", error.localizedDescription) }
      }
    }
    NotificationManager.shared.start(craftedHome: craftedHomeURL())
  }

  private func craftedHomeURL() -> URL {
    let host = ProcessInfo.processInfo.environment
    let home = host["HOME"] ?? FileManager.default.homeDirectoryForCurrentUser.path
    return URL(
      fileURLWithPath: host["VIBECRAFTED_HOME"] ?? "\(home)/.vibecrafted", isDirectory: true)
  }

  private func configureCommandDeck() {
    model.endpointDidChange = { [weak self] endpoint in
      self?.webSession.apply(endpoint: endpoint)
      self?.tabs.apply(runtimeEndpoint: endpoint)
    }
    model.setStateChangeHandler { [weak self] _ in self?.updateDeckPresentation() }
    webSession.events.stateDidChange = { [weak self] state in self?.model.receiveWebState(state) }
    webSession.events.openExternally = { [weak self] url in self?.openExternalURL(url) }
    // A `target=_blank` page or a machine document (JSON endpoint) never
    // replaces the console document; it gets its own native tab.
    webSession.events.openInTab = { [weak self] url, role in
      guard let self else { return }
      if case .unavailable(let reason) = self.tabs.open(.url(url, role)) {
        self.showNativeMessage("Cannot open in a tab", reason)
      }
    }
    webSession.events.navigationBlocked = { [weak self] _, reason in
      self?.showNativeMessage("Navigation blocked", reason)
    }
    webSession.events.downloadFinished = { url in NSWorkspace.shared.activateFileViewerSelecting([url]) }
    webSession.events.downloadFailed = { [weak self] reason in self?.showNativeMessage("Download failed", reason) }
  }

  private func connectCommandDeck() {
    switch productUpdateStartupAdoption {
    case .waiting, .publishing, .restoring:
      return
    case .none, .retained:
      break
    }
    _ = try? loadSignedCarrierRevisions()
    model.beginConnecting()
    resolveInstalledRuntime { [weak self] resolution in
      guard let self else { return }
      // First onboarding and explicit repair remain in the existing installer.
      if case .absent = resolution {
        self.installCanonicalRuntime { [weak self] result in
          guard let self else { return }
          switch result {
          case .success(let install):
            self.cachedResolution = nil
            self.finishConnectingCommandDeck(with: .ready(install))
          case .failure(let error):
            self.applyResolution(resolution)
            if let conflict = error as? PreferenceConflictError {
              self.presentPreferenceConflict(conflict.envelope, afterOnboardingFailure: true)
              return
            }
            let reason = "Runtime onboarding failed: \(error.localizedDescription)"
            self.runtimeResolutionFailure = reason
            self.model.block(reason: reason)
          }
        }
        return
      }
      self.finishConnectingCommandDeck(with: resolution)
    }
  }

  private func finishConnectingCommandDeck(with adopted: RuntimeContract) {
      guard let install = self.applyResolution(adopted),
        let environment = self.canonicalRuntimeEnvironment else {
        self.renderServerStatus()
        return
      }
      self.reconcileControlPlaneEye(install: install, environment: environment) { [weak self] result in
        guard let self, self.eyeReconcileProcess == nil, let current = self.canonicalInstall,
          shouldOfferRuntimeCarrier(
            resolution: .ready(current.root.lastPathComponent),
            signedSourceRevision: self.signedCarrierRevisions?.source,
            alreadyOffered: self.startupCarrierChoiceOffered)
        else { return }
        let serviceFailure: String?
        if case .failure(let failure) = result { serviceFailure = failure.message }
        else { serviceFailure = nil }
        self.offerRuntimePackReinstall(
          configuration: "This App and the verified installed runtime come from different builds.",
          serviceFailure: serviceFailure, startup: true)
      }
      self.inspectConfigurationAtLaunch()
      self.ensureFrameWebClient(install: install, environment: environment)
      self.refreshServerStatus()
  }

  /// Start `vc-frame web` on the operator-named loopback origin.
  ///
  /// The port is never guessed: `[tools.vc-frame]` must already name the bind.
  /// Native tabs still never spawn a service; this is the App's connect path.
  /// Closing Frame does not terminate this process or any headless worker.
  private func ensureFrameWebClient(install: CanonicalRuntimeInstall, environment: [String: String]) {
    guard let destination = ToolDestination.named("vc-frame") else { return }
    guard case .available(let url, .service) = tabs.resolve(destination),
      let bind = FrameWebLaunch.bind(url: url)
    else { return }
    if let running = frameWebProcess, running.isRunning { return }
    let process = Process()
    process.executableURL = install.frame
    process.arguments = bind.startArguments
    process.environment = environment
    process.standardInput = FileHandle.nullDevice
    process.standardOutput = FileHandle.nullDevice
    process.standardError = FileHandle.nullDevice
    do {
      try process.run()
      frameWebProcess = process
    } catch {
      frameWebProcess = nil
    }
  }

  /// Read-only configuration check at launch.
  ///
  /// A plan writes nothing — not a merge, not a backup, not a receipt — so a
  /// valid configuration is untouched on the first launch and on every launch
  /// after it. The unconditional startup regeneration this replaces could not
  /// make that promise: it rewrote first and asked nothing. Drift now becomes a
  /// line in the tray and an offer behind Repair Runtime.
  private func inspectConfigurationAtLaunch() {
    let epoch = runtimeResolveEpoch
    runConfigRepair(plan: true) { [weak self] outcome in
      guard let self, epoch == self.runtimeResolveEpoch else { return }
      switch outcome {
      case .healthy(let envelope):
        self.lastConfigRepair = envelope
      case .repairable(let envelope), .conflict(let envelope), .repaired(let envelope):
        self.lastConfigRepair = envelope
        if let advisory = configRepairAdvisory(envelope) {
          self.surfaceRuntimeAdvisory(advisory)
        }
      case .absent, .unusable:
        // The runtime itself is what is wrong, and the resolver has already
        // said so in the place this would otherwise overwrite.
        break
      }
      self.renderServerStatus()
    }
  }

  /// Ask the configuration owner: the installed generation's own installer.
  ///
  /// Never this App's carrier copy. The generation that is running is the one
  /// entitled to say what its configuration should be, which is also what lets
  /// a repair work on an installation newer than this bundle.
  private func runConfigRepair(
    plan: Bool, completion: @escaping (ConfigRepairOutcome) -> Void
  ) {
    let runtimeHome = currentRuntimeHome()
    switch runtimeResolverBootstrap(runtimeHome: runtimeHome, probe: .live) {
    case .absent(let reason): completion(.absent(reason))
    case .unusable(let reason): completion(.unusable(reason))
    case .ask(let python, let installer):
      let process = Process()
      process.executableURL = python
      process.arguments = runtimeRepairArguments(
        installer: installer, runtimeHome: runtimeHome, plan: plan)
      process.environment = runtimeResolverEnvironment()
      do {
        try runBounded(
          process, timeout: plan ? 20 : 180,
          label: plan ? "runtime-repair --plan" : "runtime-repair"
        ) { [weak self] result in
          self?.configRepairProcess = nil
          completion(
            decodeConfigRepair(
              stdout: result.stdout, stderr: result.stderr,
              terminationStatus: result.terminationStatus, clean: result.clean))
        }
        configRepairProcess = process
      } catch {
        configRepairProcess = nil
        completion(
          .unusable(
            "the configuration owner could not be started: \(error.localizedDescription)"))
      }
    }
  }

  private var nativeBridge: NativeCommandBridge {
    NativeCommandBridge(allowedPathRoots: [FileManager.default.homeDirectoryForCurrentUser,
      craftedHomeURL()] + [canonicalInstall?.runtimeHome].compactMap { $0 }, actions: .init(
      openTerminal: { [unowned self] directory in
        guard self.canonicalInstall != nil else { throw NativeCommandError.pathNotAllowed }
        self.terminalWorkingDirectory = directory
        if self.terminalIsLive() { self.focusTerminal() }
        else { self.launchWorkspaceTerminal() }
      },
      openExternalURL: { url in NSWorkspace.shared.open(url) },
      revealPath: { url in NSWorkspace.shared.activateFileViewerSelecting([url]) },
      retryConnection: { [unowned self] in
        guard self.runtimeActionPreflight == nil, self.serverActionInFlight == nil else { return }
        self.webSession.retry()
        self.connectCommandDeck()
      },
      confirmRuntimeStop: { [unowned self] in self.confirmRuntimeStop() },
      stopRuntime: { [unowned self] in self.performServerAction(.stop) }))
  }

  /// Every hand-off to the system browser goes through the typed bridge, so a
  /// URL is validated the same way whichever tab asked.
  private func openExternalURL(_ url: URL) {
    do { try nativeBridge.perform(.openExternalURL(try .init(value: url.absoluteString))) }
    catch { reportWorkspaceLaunchFailure(error.localizedDescription) }
  }

  // MARK: - Tabs and history (selected window only)

  /// The navigation owner of the key window: the console or one tool tab.
  private func selectedNavigationHandler() -> (any CommandDeckNavigationHandling)? {
    let key = NSApp.keyWindow
    if let mainWindow, mainWindow.window === key { return mainWindow }
    if let tab = tabs.controller(for: key) { return tab }
    return mainWindow
  }

  private func selectedSession() -> WebConsoleSession? {
    let key = NSApp.keyWindow
    if let mainWindow, mainWindow.window === key { return webSession }
    return tabs.controller(for: key)?.session ?? (mainWindow == nil ? nil : webSession)
  }

  @objc private func goHome() { selectedNavigationHandler()?.navigate(.home) }
  @objc private func toggleCommandDeckSidebar() {
    NotificationCenter.default.post(name: .commandDeckToggleSidebar, object: nil)
  }
  @objc private func toggleCommandDeckInspector() {
    NotificationCenter.default.post(name: .commandDeckToggleInspector, object: nil)
  }
  @objc private func goBack() { selectedNavigationHandler()?.navigate(.back) }
  @objc private func goForward() { selectedNavigationHandler()?.navigate(.forward) }
  @objc private func openSelectedPageInBrowser() { selectedNavigationHandler()?.navigate(.openInBrowser) }

  @objc private func openDestinationInTab(_ sender: NSMenuItem) {
    guard let id = sender.representedObject as? String, let destination = ToolDestination.named(id) else { return }
    if case .unavailable(let reason) = tabs.open(.destination(destination)) {
      showNativeMessage("\(destination.title) is unavailable", reason)
    }
  }

  @objc private func openDestinationExternally(_ sender: NSMenuItem) {
    guard let id = sender.representedObject as? String, let destination = ToolDestination.named(id) else { return }
    switch tabs.resolve(destination) {
    case .available(let url, .runtime), .available(let url, .service): openExternalURL(url)
    case .available(let url, .localDocument): revealNativePath(url)
    case .unavailable(let reason): showNativeMessage("\(destination.title) is unavailable", reason)
    }
  }

  func validateMenuItem(_ item: NSMenuItem) -> Bool {
    switch item.action {
    case #selector(goBack): return selectedSession()?.navigation.canGoBack ?? false
    case #selector(goForward): return selectedSession()?.navigation.canGoForward ?? false
    case #selector(goHome): return selectedSession() != nil
    case #selector(openSelectedPageInBrowser):
      guard let url = selectedSession()?.navigation.currentURL else { return false }
      return url.scheme == "http" || url.scheme == "https"
    case #selector(openDestinationInTab(_:)), #selector(openDestinationExternally(_:)):
      guard let id = item.representedObject as? String, let destination = ToolDestination.named(id) else { return false }
      switch tabs.resolve(destination) {
      case .available: item.toolTip = nil; return true
      case .unavailable(let reason): item.toolTip = reason; return false
      }
    default: return true
    }
  }

  func handle(_ action: CommandDeckChromeAction) {
    do {
      switch action {
      case .openTerminal: openTerminalFromStatusItem()
      case .openProject: openProject()
      case .retryConnection: try nativeBridge.perform(.retryConnection)
      case .requestStopRuntime: try nativeBridge.perform(.requestRuntimeStop)
      case .repairRuntime: repairRuntime()
      case .showDiagnostics: showServerDiagnostics()
      }
    } catch { showNativeMessage("Native action failed", error.localizedDescription) }
  }

  private func handleTray(_ action: StatusItemAction) {
    switch action {
    case .showCommandDeck: showMainWindowIfNeeded()
    case .openTerminal: handle(.openTerminal)
    case .retryConnection: handle(.retryConnection)
    case .repairRuntime: handle(.repairRuntime)
    case .stopRuntime: handle(.requestStopRuntime)
    case .showDiagnostics: handle(.showDiagnostics)
    case .showServer: openServerFromStatusItem()
    case .showWorkspaces: openWorkspacesFromStatusItem()
    case .startServer: startServerFromStatusItem()
    case .restartServer: restartServerFromStatusItem()
    case .showLogs: openServerLogsFromStatusItem()
    case .revealRuntime: revealRuntimeHomeFromStatusItem()
    case .revealControlPlane: openControlPlaneFromStatusItem()
    case .copyRuntimeIdentity: copyRuntimeIdentityFromStatusItem()
    case .checkForUpdates: checkForUpdatesFromMenu()
    case .help: showStatusItemHelp()
    case .quitApp: requestQuit()
    }
  }

  private func confirmRuntimeStop() -> Bool {
    confirmedStopRoot = nil
    guard runtimeActionPreflight == nil, serverActionInFlight == nil, !repairInFlight,
      let install = canonicalInstall,
      deriveServerMenuState(caretakerData: lastCaretakerData,
        actionInFlight: nil, runtimeReady: true).canStop else { return false }
    let activity: String
    switch activeRunSummary() {
    case .available(let summary): activity = "\(summary.lanes) active or stalled lanes; \(summary.worktrees) use worktrees."
    case .unavailable: activity = "Active lane counts are unavailable."
    }
    let alert = NSAlert()
    alert.alertStyle = .warning
    alert.messageText = "Stop Runtime service?"
    alert.informativeText = "This stops the shared VC Server through its service owner. "
      + "The App loses its web canvas and other clients lose server access. "
      + "It does not stop terminal sessions or agents. \(activity) "
      + "Generation: \(install.root.lastPathComponent)."
    alert.addButton(withTitle: "Cancel")
    alert.addButton(withTitle: "Stop Runtime Service")
    guard alert.runModal() == .alertSecondButtonReturn else { return false }
    confirmedStopRoot = install.root
    return true
  }

  private func showNativeMessage(_ title: String, _ message: String) {
    let alert = NSAlert()
    alert.messageText = title
    alert.informativeText = message
    alert.addButton(withTitle: "OK")
    alert.runModal()
  }

  private func launchWorkspaceTerminal() {
    if terminalIsLive() || terminalLaunchInFlight {
      return
    }

    // Carrier identity is this bundle's own property, so the tray can compare
    // it against the live generation whether or not this open installs
    // anything. A malformed manifest must not block opening an installed
    // runtime; it degrades the drift line, which the policy reports honestly.
    _ = try? loadSignedCarrierRevisions()

    // Opening is not installing. The runtime of record is whatever generation
    // the Founder has installed, and the owner is the only thing entitled to
    // say which one that is. The bundled carrier is bootstrap and repair
    // material — republishing it for a window re-ran a full install and could
    // walk a newer runtime backwards.
    terminalLaunchInFlight = true
    resolveInstalledRuntime { [weak self] resolution in
      guard let self else { return }
      switch resolution {
      case .ready:
        guard let install = self.applyResolution(resolution) else {
          self.terminalLaunchInFlight = false
          return
        }
        self.openWorkspaceTerminal(install: install)
      case .absent(let reason):
        // Nothing is installed yet, so the bundled carrier is the only runtime
        // that can exist. Publishing it here is first onboarding.
        self.applyResolution(resolution)
        lifecycleLog("no installed runtime (\(reason)); bootstrapping the bundled carrier")
        self.installCanonicalRuntime { [weak self] result in
          guard let self else { return }
          switch result {
          case .success(let install):
            // The bootstrap just changed what is installed, so the cached answer is
            // stale by construction.
            self.cachedResolution = nil
            self.applyResolution(.ready(install))
            self.openWorkspaceTerminal(install: install)
          case .failure(let error):
            self.terminalLaunchInFlight = false
            self.reportWorkspaceLaunchFailure(
              "Cannot publish the canonical Vibecrafted runtime: \(error.localizedDescription)")
          }
        }
      case .unusable(let reason):
        // An installation exists but the owner refuses it. Overwriting it from
        // the bundled carrier would be an automatic downgrade of the Founder's
        // runtime, so repair stays a deliberate action in the tray.
        self.terminalLaunchInFlight = false
        self.applyResolution(resolution)
        self.renderServerStatus()
        self.reportWorkspaceLaunchFailure(
          "The installed Vibecrafted runtime cannot be used: \(reason). "
            + "Use Repair Runtime… to repair it.")
      }
    }
  }

  /// Open the workspace terminal on the generation the owner selected.
  ///
  /// The public wrapper is the entry point, not a terminal binary chosen here.
  /// The wrapper is where the selected generation's product config and native
  /// host are applied — it refuses a caller-supplied `--config-file` outright —
  /// and the host itself is the owner's choice, carried in the environment
  /// rather than substituted from this bundle. Pairing a newly resolved
  /// generation with the old App's helper binary was the ownership failure this
  /// replaces.
  private func openWorkspaceTerminal(install: CanonicalRuntimeInstall) {
    defer { terminalLaunchInFlight = false }
    guard let environment = canonicalRuntimeEnvironment else {
      reportWorkspaceLaunchFailure("The resolved runtime carries no launch environment")
      return
    }
    do {
      // No font registration happens here. The terminal family belongs to the
      // consuming process: vc-terminal.app declares ATSApplicationFontsPath and
      // resolves its own bundled Spot Mono. A CTFontManager `.session`
      // registration made here reached every process in the login session and
      // outranked the owner's own ~/Library/Fonts copy.
      let specification = try TerminalLauncher.Specification(
        generationRoot: install.root, terminal: install.terminal,
        terminalHost: install.terminalHost, primaryShell: install.primaryShell,
        start: install.start, workingDirectory: terminalWorkingDirectory,
        environment: environment)
      terminalLaunch = try TerminalLauncher.launch(specification)
      observeTerminalRegistration()
    } catch {
      reportWorkspaceLaunchFailure("Cannot open the generation-owned terminal: \(error.localizedDescription)")
    }
  }

  /// A native gesture selects the folder. Render and web scripts cannot launch work.
  private func openProject() {
    guard !terminalLaunchInFlight else { return }
    let panel = NSOpenPanel()
    panel.title = "Open project"
    panel.prompt = "Open project"
    panel.canChooseDirectories = true
    panel.canChooseFiles = false
    panel.allowsMultipleSelection = false
    guard panel.runModal() == .OK, let root = panel.url else { return }
    terminalLaunchInFlight = true
    updateDeckPresentation()
    resolveInstalledRuntime { [weak self] resolution in
      guard let self else { return }
      guard let install = self.applyResolution(resolution),
        let environment = self.canonicalRuntimeEnvironment else {
        self.terminalLaunchInFlight = false
        self.updateDeckPresentation()
        return
      }
      let process = Process()
      process.executableURL = install.launcher
      process.arguments = ["start", "resume", "--repo", root.path]
      process.currentDirectoryURL = root
      process.environment = environment
      do {
        try self.runBounded(process, timeout: 60, label: "open-project") { [weak self] result in
          guard let self else { return }
          self.terminalLaunchInFlight = false
          self.updateDeckPresentation()
          if !result.clean || result.terminationStatus != 0 {
            self.showNativeMessage("Project could not be opened",
              String(decoding: result.stderr, as: UTF8.self))
          }
        }
      } catch {
        self.terminalLaunchInFlight = false
        self.updateDeckPresentation()
        self.showNativeMessage("Project could not be opened", error.localizedDescription)
      }
    }
  }

  private func terminalIsLive() -> Bool {
    terminalLaunch?.isRunning == true || terminalApplication?.isTerminated == false
  }

  private func focusTerminal() {
    // An explicit Open Terminal retries focus for this exact live launch.
    observeTerminalRegistration()
  }

  private func observeTerminalRegistration() {
    terminalRegistrationTimer?.invalidate()
    guard let launch = terminalLaunch, launch.isRunning else { return }
    terminalRegistration = TerminalRegistrationObservation(
      receipt: launch.receipt, now: ProcessInfo.processInfo.systemUptime)
    checkTerminalRegistration()
    guard terminalRegistration != nil else { return }
    terminalRegistrationTimer = Timer.scheduledTimer(withTimeInterval: 0.1, repeats: true) { [weak self] _ in
      Task { @MainActor [weak self] in self?.checkTerminalRegistration() }
    }
  }

  private func checkTerminalRegistration() {
    guard let observation = terminalRegistration else { return }
    let launch = terminalLaunch
    // The wrapper's receipt names the host: the launcher itself (fresh) or the
    // single admitted host it delivered a window to (reused). The kernel start
    // token is revalidated on every tick; registration is never agent proof.
    let hostState = launch?.hostState
    let application = hostState?.hostProcessIdentifier.flatMap {
      NSRunningApplication(processIdentifier: $0)
    }
    let registered = application?.isTerminated == false
      && application?.executableURL?.resolvingSymlinksInPath()
        == launch?.receipt.specification.terminalHost.resolvingSymlinksInPath()
    let outcome = observation.observe(now: ProcessInfo.processInfo.systemUptime,
      currentLaunchID: launch?.receipt.launchID,
      isRunning: hostState?.hostProcessIdentifier != nil,
      isRegistered: registered)
    guard outcome != .waiting else { return }
    terminalRegistrationTimer?.invalidate()
    terminalRegistrationTimer = nil
    terminalRegistration = nil
    if outcome == .ready, let application {
      terminalApplication = application
      application.activate(options: [])
    } else if outcome == .ended, case .ended(let status?) = hostState, status != 0 {
      // Reported here once; the status poll must not report the same refusal.
      terminalLaunch = nil
      showNativeMessage("Terminal window unconfirmed",
        "The terminal launcher refused or could not confirm the window (status \(status)). "
          + "No second terminal host was started. Run vc-terminal --doctor, then Open Terminal again.")
    } else if outcome == .timedOut {
      showNativeMessage("Terminal is still starting",
        "The process started, but its macOS application registration was not observed within 10 seconds. "
          + "It remains running. Use Open Terminal to try focusing the same process again.")
    }
  }

  /// The environment every generation-owned subprocess inherits: the tray's
  /// caretaker poll, the service actions and the workspace terminal all run
  /// with exactly this, so they can never address different roots.
  ///
  /// Guest, not landlord: the base is the user's own environment — the app is
  /// launched from Finder/Dock, so this is the launchd user-session env, not a
  /// login shell. The shared contract recovers the user's login-shell PATH
  /// before adoption; `SSH_AUTH_SOCK` and every other user variable flow
  /// through. Only the explicit deny-list below is scrubbed, then the
  /// Vibecrafted pins overlay the result.
  private func composeRuntimeEnvironment(install: CanonicalRuntimeInstall) -> [String: String] {
    let host = ProcessInfo.processInfo.environment
    // The only variables scrubbed from the inherited environment, each with
    // the reason it must not cross into the child. Everything else survives.
    let denied: [String] = [
      // Repoints python children at a foreign runtime's or test harness's
      // module tree; the launched product must import its own generation.
      "PYTHONPATH",
      // Relocates the interpreter's stdlib and breaks any bundled python.
      "PYTHONHOME",
      // macOS framework-python breadcrumb pinning children to the invoking
      // interpreter's launcher instead of their own resolution.
      "__PYVENV_LAUNCHER__",
    ]
    var environment = host
    for name in denied {
      environment.removeValue(forKey: name)
    }
    // The workspace terminal spawns agent CLIs (codex, gh, claude, loct) whose
    // `#!/usr/bin/env` shebangs resolve against exactly this PATH. The
    // login-shell PATH is acquired asynchronously before runtime-ready delivery;
    // a failed probe preserves the inherited PATH. The generation's bin stays
    // first while Homebrew, ~/.local/bin and ~/.cargo/bin survive behind it.
    environment["PATH"] = composedPath(
      generation: install.root,
      inherited: userShellPath.cachedPath(generation: install.root, environment: host) ?? host["PATH"])
    environment["PYTHONNOUSERSITE"] = "1"
    environment["PYTHONDONTWRITEBYTECODE"] = "1"
    environment["XDG_CONFIG_HOME"] = install.configHome.path
    environment["VIBECRAFTED_HOME"] = install.craftedHome.path
    environment["VIBECRAFTED_RUNTIME_HOME"] = install.runtimeHome.path
    environment["VIBECRAFTED_RUNTIME_ROOT"] = install.root.path
    environment["VIBECRAFTED_ROOT"] = install.root.path
    environment["VIBECRAFTED_DECLARED_LAUNCHER"] = install.launcher.path
    environment["VIBECRAFTED_PYTHON"] = install.root.appendingPathComponent("bin/python3").path
    environment["VIBECRAFTED_VC_FRAME_BIN"] = install.frame.path
    environment["VC_FRAME_CONFIG_DIR"] = install.frameConfig.path
    // The public wrapper resolves its native host from this, defaulting to the
    // generation's own libexec. Carrying the owner's answer through is how the
    // App consumes a resolved host instead of imposing the one it ships.
    environment["VIBECRAFTED_TERMINAL_HOST"] = install.terminalHost.path
    // Keep Unix socket paths below macOS' 104-byte sockaddr_un limit. Preserve
    // the former TMPDIR namespace for one-way import into WES during startup.
    let socketRoot = "/tmp/vc-frame-\(getuid())"
    environment["VC_FRAME_SOCKET_DIR"] = socketRoot
    environment["ZELLIJ_SOCKET_DIR"] = socketRoot
    if let temp = host["TMPDIR"]?.trimmingCharacters(in: CharacterSet(charactersIn: "/")),
      !temp.isEmpty
    {
      environment["VIBECRAFTED_LEGACY_VC_FRAME_SOCKET_DIR"] =
        "/\(temp)/vc-frame-\(getuid())"
    }
    return environment
  }

  /// The owner is asked in a closed interpreter environment.
  ///
  /// No inherited `PYTHONPATH`/`PYTHONHOME` — the runtime exports a global
  /// `PYTHONPATH` that poisons unrelated Python tools, and the resolver must
  /// read the installation, not whatever the host session had loaded. No user
  /// site packages, and no bytecode written into the installation being
  /// inspected. Built from an allow-list so a new host variable cannot leak in.
  private func runtimeResolverEnvironment() -> [String: String] {
    let host = ProcessInfo.processInfo.environment
    let inherited = ["HOME", "USER", "LOGNAME", "LANG", "LC_ALL", "LC_CTYPE", "TMPDIR"]
    var environment = Dictionary(
      uniqueKeysWithValues: inherited.compactMap { key in host[key].map { (key, $0) } })
    // No PATH at all. Both the interpreter and the installer script are given
    // as absolute paths, so a read-only resolve that needed to look an
    // executable up in PATH would be doing something it is not allowed to do.
    environment["PYTHONNOUSERSITE"] = "1"
    environment["PYTHONDONTWRITEBYTECODE"] = "1"
    return environment
  }

  /// Where this process looks for an installation.
  private func currentRuntimeHome() -> URL {
    let host = ProcessInfo.processInfo.environment
    return resolvedRuntimeHome(
      environment: host,
      homeDirectory: host["HOME"] ?? FileManager.default.homeDirectoryForCurrentUser.path)
  }

  /// Ask the owner what is installed.
  ///
  /// Coalesced and cached: callers that arrive while a resolve is in flight
  /// join it rather than racing a second resolver, and an unchanged identity
  /// pair reuses the last answer, so a five-second tray poll does not spawn an
  /// interpreter it does not need. The call itself is read-only by contract —
  /// it installs, publishes, reconciles and repairs nothing.
  ///
  /// Every answer is bound to the identity that was read when it was asked for,
  /// and that identity is read again before the answer is believed. A generation
  /// published while the resolver runs therefore cannot be handed to a caller
  /// that is already looking at the new one.
  private func resolveInstalledRuntime(
    forceRefresh: Bool = false,
    completion: @escaping (RuntimeContract) -> Void
  ) {
    let preparedCompletion: (RuntimeContract) -> Void = { [weak self] resolution in
      self?.prepareLaunchEnvironment(resolution, completion: completion)
    }
    let runtimeHome = currentRuntimeHome()
    let fingerprint = identityFingerprint(runtimeHome: runtimeHome)
    if runtimeResolveProcess != nil {
      runtimeResolveWaiters.append(preparedCompletion)
      return
    }
    if !forceRefresh, let cached = cachedResolution,
      cached.reusable(for: fingerprint, now: ProcessInfo.processInfo.systemUptime) {
      preparedCompletion(cached.value)
      return
    }
    // Join first, then decide whether to ask. One serialization point means a
    // caller that arrives mid-flight is answered about the installation as it
    // stands when the answer lands, not about the one it happened to catch.
    runtimeResolveWaiters.append(preparedCompletion)
    guard runtimeResolveProcess == nil else { return }
    beginRuntimeResolve(runtimeHome: runtimeHome, fingerprint: fingerprint, attempt: 0)
  }

  /// Keep first-launch and later subprocesses on the same recovered PATH,
  /// without running an interactive login shell on the App's main thread.
  private func prepareLaunchEnvironment(
    _ resolution: RuntimeContract, completion: @escaping (RuntimeContract) -> Void
  ) {
    guard case .ready(let install) = resolution else {
      completion(resolution)
      return
    }
    let fingerprint = identityFingerprint(runtimeHome: install.runtimeHome)
    userShellPath.resolve(generation: install.root, environment: ProcessInfo.processInfo.environment) {
      [weak self] _ in
      guard let self else { return }
      // PATH discovery also takes time: publication during this probe must
      // not bypass the resolver's existing identity-drift protection.
      guard fingerprint == self.identityFingerprint(runtimeHome: install.runtimeHome) else {
        self.resolveInstalledRuntime(forceRefresh: true, completion: completion)
        return
      }
      completion(resolution)
    }
  }

  /// Ask the owner once, about one identity, for everyone currently waiting.
  private func beginRuntimeResolve(
    runtimeHome: URL,
    fingerprint: RuntimeIdentityFingerprint,
    attempt: Int
  ) {
    switch runtimeResolverBootstrap(runtimeHome: runtimeHome, probe: .live) {
    case .absent(let reason):
      let resolution: RuntimeContract = .absent(reason)
      cacheResolution(resolution, fingerprint: fingerprint)
      deliverResolution(resolution)
    case .unusable(let reason):
      let resolution: RuntimeContract = .unusable(reason)
      cacheResolution(resolution, fingerprint: fingerprint)
      deliverResolution(resolution)
    case .ask(let python, let installer):
      let process = Process()
      process.executableURL = python
      process.arguments = runtimeResolveArguments(installer: installer, runtimeHome: runtimeHome)
      process.environment = runtimeResolverEnvironment()
      do {
        try runBounded(process, timeout: 20, label: "runtime-resolve") { [weak self] result in
          guard let self else { return }
          self.runtimeResolveProcess = nil
          // The child ran while the installer was free to publish, so the pair
          // is read again: this answer is only about the identity it was asked
          // about.
          let delivery = runtimeResolveDelivery(
            invoked: fingerprint,
            observed: self.identityFingerprint(runtimeHome: runtimeHome),
            attempt: attempt)
          switch delivery {
          case .deliver:
            let resolution: RuntimeContract = decodeRuntimeResolution(
              stdout: result.stdout,
              stderr: result.stderr,
              terminationStatus: result.terminationStatus,
              clean: result.clean && !result.timedOut)
            self.cacheResolution(resolution, fingerprint: fingerprint)
            self.deliverResolution(resolution)
          case .reresolve:
            lifecycleLog(
              "runtime identity changed while resolving; discarding that answer and re-asking")
            // Cached under neither identity: it describes what was asked about,
            // which is no longer what is installed.
            self.cachedResolution = nil
            self.restartRuntimeResolve(attempt: attempt + 1)
          case .refuse(let reason):
            lifecycleLog("runtime identity kept changing while resolving; refusing")
            self.cachedResolution = nil
            self.deliverResolution(.unusable(reason))
          }
        }
        runtimeResolveProcess = process
      } catch {
        runtimeResolveProcess = nil
        let resolution: RuntimeContract = .unusable(
          "the runtime resolver could not be started: \(error.localizedDescription)")
        cacheResolution(resolution, fingerprint: fingerprint)
        deliverResolution(resolution)
      }
    }
  }

  /// Ask again, about the identity that is installed now, keeping the callers
  /// that are still waiting for an answer.
  private func restartRuntimeResolve(attempt: Int) {
    let runtimeHome = currentRuntimeHome()
    beginRuntimeResolve(
      runtimeHome: runtimeHome,
      fingerprint: identityFingerprint(runtimeHome: runtimeHome),
      attempt: attempt)
  }

  /// Hand one answer to everybody who asked, exactly once.
  private func deliverResolution(_ resolution: RuntimeContract) {
    let waiters = runtimeResolveWaiters
    runtimeResolveWaiters = []
    for waiter in waiters {
      waiter(resolution)
    }
  }

  private func cacheResolution(_ resolution: RuntimeContract, fingerprint: RuntimeIdentityFingerprint) {
    if cachedResolution?.fingerprint != fingerprint { runtimeResolveFailures = 0 }
    switch resolution {
    case .unusable: runtimeResolveFailures = min(5, runtimeResolveFailures + 1)
    case .ready, .absent: runtimeResolveFailures = 0
    }
    cachedResolution = RuntimeResolutionCache(fingerprint: fingerprint, value: resolution,
      expires: ProcessInfo.processInfo.systemUptime
        + runtimeResolutionCacheLifetime(resolution, consecutiveFailures: runtimeResolveFailures))
  }

  private func identityFingerprint(runtimeHome: URL) -> RuntimeIdentityFingerprint {
    RuntimeIdentityFingerprint(
      home: runtimeHome.path,
      pointer: fileStamp(activeRuntimePointerURL(runtimeHome: runtimeHome)),
      receipt: fileStamp(runtimeInstallReceiptURL(runtimeHome: runtimeHome)),
      selector: fileStamp(runtimeHome.appendingPathComponent("tools/vibecrafted-current")))
  }

  private func fileStamp(_ url: URL) -> FileStamp? {
    var metadata = stat()
    guard lstat(url.path, &metadata) == 0 else { return nil }
    return FileStamp(size: Int(metadata.st_size),
      modified: Date(timeIntervalSince1970: Double(metadata.st_mtimespec.tv_sec)
        + Double(metadata.st_mtimespec.tv_nsec) / 1_000_000_000),
      device: UInt64(metadata.st_dev), inode: UInt64(metadata.st_ino),
      changed: Date(timeIntervalSince1970: Double(metadata.st_ctimespec.tv_sec)
        + Double(metadata.st_ctimespec.tv_nsec) / 1_000_000_000))
  }

  /// The one place runtime truth changes.
  ///
  /// Adopting a generation, losing one and being refused one all bump the
  /// epoch, so a caretaker reading or a service action belonging to the
  /// previous generation is dropped instead of repopulating live controls.
  @discardableResult
  private func applyResolution(_ resolution: RuntimeContract) -> CanonicalRuntimeInstall? {
    switch resolution {
    case .ready(let install):
      let changed = install.root.standardizedFileURL.path
        != canonicalInstall?.root.standardizedFileURL.path
      if changed {
        runtimeResolveEpoch &+= 1
        lastCaretakerData = nil
        lastTrayWork = nil
        serverActionInFlight = nil
        runtimeAdvisory = nil
        // A newly adopted generation is allowed to report its own failures.
        workspaceLaunchFailureReported = false
      }
      canonicalInstall = install
      canonicalRuntimeEnvironment = composeRuntimeEnvironment(install: install)
      runtimeResolutionFailure = nil
      if changed {
        model.refreshEndpoint(caretakerData: nil, runtimeReady: true)
        lifecycleLog("adopted active generation at \(install.root.path)")
      }
      return install
    case .absent(let reason):
      discardRuntimeTruth(failure: nil, log: "no installed runtime (\(reason))")
      return nil
    case .unusable(let reason):
      discardRuntimeTruth(failure: reason, log: "runtime inspection refused: \(reason)")
      return nil
    }
  }

  /// Stop controlling a runtime this App can no longer resolve.
  ///
  /// A stale generation must not stay behind the tray as fallback truth: if the
  /// published pointer breaks, the honest reading is that there is nothing to
  /// control, so the actions go quiet and the reason is rendered in their place.
  private func discardRuntimeTruth(failure: String?, log: String) {
    let hadRuntime = canonicalInstall != nil
    let changed = hadRuntime || runtimeResolutionFailure != failure
    if changed { runtimeResolveEpoch &+= 1 }
    canonicalInstall = nil
    canonicalRuntimeEnvironment = nil
    lastCaretakerData = nil
    lastTrayWork = nil
    serverActionInFlight = nil
    runtimeAdvisory = nil
    runtimeResolutionFailure = failure
    model.refreshEndpoint(caretakerData: nil, runtimeReady: false)
    if changed {
      lifecycleLog(log)
    }
  }

  /// Attach bounded, continuously drained plumbing to a configured subprocess,
  /// start it, and deliver its outcome on the main thread exactly once.
  ///
  /// Every generation-owned verb the tray calls goes through here. Reading a
  /// pipe only after the child has exited deadlocks as soon as the child writes
  /// more than one pipe buffer, and an unbounded child leaves a tray control —
  /// or, from `applicationShouldTerminate`, the quit itself — waiting forever.
  /// Callers configure the process and own its lifetime reference; the pipes
  /// belong to this helper.
  private func runBounded(
    _ process: Process,
    timeout: TimeInterval,
    label: String,
    stdoutLimit: Int = 1 << 20,
    stderrLimit: Int = 1 << 16,
    completion: @escaping @MainActor @Sendable (BoundedProcessResult) -> Void
  ) throws {
    try NativeInstallerProcess.run(
      process, timeout: timeout, label: label, stdoutLimit: stdoutLimit, stderrLimit: stderrLimit,
      onTimeout: { lifecycleLog($0) }, completion: completion)
  }

  /// Ensure the canonical shared service exists.
  ///
  /// Keeping the shared caretaker available is the App's job and the canonical
  /// verb is idempotent, so asking for it on open is legitimate. Asking blindly
  /// is not: the previous version discarded stdout, stderr and the exit status,
  /// so a refused or leased reconcile was indistinguishable from a successful
  /// one. Recovery ownership stays with the supervisor; this asks once,
  /// observes the answer and reports it.
  private struct ControlPlaneReconcileError: Error, Equatable, Sendable {
    let message: String
  }

  private func reconcileControlPlaneEye(
    install: CanonicalRuntimeInstall,
    environment: [String: String],
    completion: (@MainActor (Result<Void, ControlPlaneReconcileError>) -> Void)? = nil
  ) {
    // One reconcile at a time: overlapping calls would race the supervisor's
    // install lease against itself.
    func finish(_ result: Result<Void, ControlPlaneReconcileError>) {
      completion?(result)
    }
    guard eyeReconcileProcess?.isRunning != true else {
      lifecycleLog("service reconcile already in flight; not starting a second")
      finish(.failure(ControlPlaneReconcileError(message: "LaunchAgent reconcile is already running.")))
      return
    }
    let deck = install.root.appendingPathComponent("bin/vibecrafted")
    guard FileManager.default.isExecutableFile(atPath: deck.path) else {
      let message = "The installed service owner is missing: \(deck.path)"
      surfaceRuntimeAdvisory(message)
      finish(.failure(ControlPlaneReconcileError(message: message)))
      return
    }
    let epoch = runtimeResolveEpoch
    let process = Process()
    process.executableURL = deck
    process.arguments = ["server", "service", "reconcile"]
    process.environment = environment
    do {
      try runBounded(process, timeout: 120, label: "server service reconcile") {
        [weak self] result in
        guard let self else { return }
        self.eyeReconcileProcess = nil
        guard epoch == self.runtimeResolveEpoch else {
          finish(.failure(ControlPlaneReconcileError(message: "Runtime identity changed while reconciling the LaunchAgent.")))
          return
        }
        guard result.clean, result.terminationStatus == 0 else {
          let detail = boundedResolverDiagnostic(stdout: result.stdout, stderr: result.stderr)
          let message = "The shared VC Server service could not be reconciled" + detail
          self.surfaceRuntimeAdvisory(message)
          self.renderServerStatus()
          finish(.failure(ControlPlaneReconcileError(message: message)))
          return
        }
        self.runtimeAdvisory = nil
        lifecycleLog("shared service reconciled on \(install.root.lastPathComponent)")
        self.renderServerStatus()
        finish(.success(()))
      }
      eyeReconcileProcess = process
    } catch {
      let message =
        "The shared VC Server service could not be reconciled: \(error.localizedDescription)"
      surfaceRuntimeAdvisory(message)
      finish(.failure(ControlPlaneReconcileError(message: message)))
    }
  }

  /// Report something about the shared service without interrupting the
  /// Founder: the log for post-mortem, the tray for the current truth.
  private func surfaceRuntimeAdvisory(_ message: String) {
    runtimeAdvisory = message
    installLog.error("\(message, privacy: .public)")
    lifecycleLog(message)
    applyRuntimePackMenuState()
  }

  /// Read the revision tuple this signed bundle ships and record it for the
  /// tray. Carrier identity is a property of the App, not of any installation,
  /// so drift supervision must not depend on having just run the installer.
  @discardableResult
  private func loadSignedCarrierRevisions() throws -> (
    source: String, terminal: String, frame: String
  ) {
    let resources = Bundle.main.bundleURL.appendingPathComponent(
      "Contents/Resources", isDirectory: true)
    let manifestData = try Data(
      contentsOf: resources.appendingPathComponent("product-manifest.json"))
    guard
      let manifest = try JSONSerialization.jsonObject(with: manifestData) as? [String: Any],
      let sourceRevision = manifest["git_sha"] as? String,
      let modules = manifest["modules"] as? [[String: Any]],
      let terminalRevision = modules.first(where: { $0["module"] as? String == "vc-terminal" })?[
        "git_sha"] as? String,
      let frameRevision = modules.first(where: { $0["module"] as? String == "vc-frame" })?[
        "git_sha"] as? String
    else {
      throw NSError(
        domain: "io.vetcoders.vibecrafted.install", code: 1,
        userInfo: [
          NSLocalizedDescriptionKey: "signed product manifest has no Runtime Pack source tuple"
        ])
    }
    signedCarrierRevisions = (sourceRevision, terminalRevision, frameRevision)
    return (sourceRevision, terminalRevision, frameRevision)
  }

  private func installCanonicalRuntime() throws -> CanonicalRuntimeInstall {
    try decodeCanonicalRuntimeInstall(from: runRuntimePackInstaller(arguments: try runtimePackInstallArguments()))
  }

  /// The UI form never waits on the main actor. All callers join the one
  /// carrier publication, which preserves the installer's lease/transaction
  /// boundary instead of introducing a second installer owner in the App.
  private func installCanonicalRuntime(
    preferenceChoice: PreferenceResolutionChoice? = nil,
    completion: @escaping (Result<CanonicalRuntimeInstall, Error>) -> Void
  ) {
    if runtimeInstallProcess != nil {
      runtimeInstallWaiters.append(completion)
      return
    }
    do {
      try runRuntimePackInstaller(arguments: runtimePackInstallArguments(preferenceChoice: preferenceChoice)) { [weak self] result in
        guard let self else { return }
        let outcome: Result<CanonicalRuntimeInstall, Error>
        switch result {
        case .success(let output):
          outcome = Result { try self.decodeCanonicalRuntimeInstall(from: output) }
        case .failure(let error): outcome = .failure(error)
        }
        self.runtimeInstallProcess = nil
        let waiters = self.runtimeInstallWaiters
        self.runtimeInstallWaiters.removeAll()
        if case .success(let install) = outcome {
          self.prepareLaunchEnvironment(.ready(install)) { prepared in
            let ready: Result<CanonicalRuntimeInstall, Error>
            if case .ready(let current) = prepared {
              ready = .success(current)
            } else {
              ready = .failure(NSError(domain: "io.vetcoders.vibecrafted.install", code: 3,
                userInfo: [NSLocalizedDescriptionKey: "runtime changed during PATH discovery"]))
            }
            completion(ready)
            waiters.forEach { $0(ready) }
          }
        } else {
          completion(outcome)
          waiters.forEach { $0(outcome) }
        }
      }
    } catch {
      completion(.failure(error))
    }
  }

  private func runtimePackInstallArguments(
    preferenceChoice: PreferenceResolutionChoice? = nil
  ) throws -> [String] {
    let appRoot = Bundle.main.bundleURL
    let resources = appRoot.appendingPathComponent("Contents/Resources", isDirectory: true)
    let carrierDirectory = resources.appendingPathComponent("runtime-pack", isDirectory: true)
    let carriers = try FileManager.default.contentsOfDirectory(
      at: carrierDirectory, includingPropertiesForKeys: nil
    ).filter {
      $0.lastPathComponent.hasPrefix("Vibecrafted_RuntimePack_") && $0.pathExtension == "gz"
    }
    guard carriers.count == 1 else {
      throw NSError(
        domain: "io.vetcoders.vibecrafted.install", code: 1,
        userInfo: [NSLocalizedDescriptionKey: "signed App must contain one Runtime Pack carrier"])
    }
    let (sourceRevision, terminalRevision, frameRevision) = try loadSignedCarrierRevisions()
    return try runtimePackInstallArguments(
      pack: carriers[0], appRoot: appRoot, sourceRevision: sourceRevision,
      terminalRevision: terminalRevision, frameRevision: frameRevision,
      preferenceChoice: preferenceChoice)
  }

  /// Same installer owner as onboarding/repair. A candidate pack still goes
  /// through expected-revision identity and the receipt transaction.
  private func runtimePackInstallArguments(
    pack: URL,
    appRoot: URL,
    sourceRevision: String,
    terminalRevision: String,
    frameRevision: String,
    preferenceChoice: PreferenceResolutionChoice? = nil
  ) throws -> [String] {
    let terminalHost = appRoot.appendingPathComponent(
      "Contents/MacOS/vc-terminal")
    let frameHelper = appRoot.appendingPathComponent("Contents/Helpers/vc-frame")
    var arguments = [
      "--pack", pack.path,
      "--app-root", appRoot.path,
      "--terminal-host", terminalHost.path,
      "--frame-helper", frameHelper.path,
      "--expected-source-revision", sourceRevision,
      "--expected-terminal-revision", terminalRevision,
      "--expected-frame-revision", frameRevision,
    ]
    if let choice = preferenceChoice {
      arguments += [
        "--resolve-preference", choice.action,
        "--preference-current-sha256", choice.currentSha256,
        "--preference-incoming-sha256", choice.incomingSha256,
        "--preference-path", choice.path,
      ]
    }
    return arguments
  }

  private func decodeCanonicalRuntimeInstall(from output: Data) throws -> CanonicalRuntimeInstall {
    do {
      return try JSONDecoder().decode(CanonicalRuntimeInstall.self, from: output)
    } catch {
      throw NSError(
        domain: "io.vetcoders.vibecrafted.install", code: 2,
        userInfo: [
          NSLocalizedDescriptionKey:
            "installer returned an invalid runtime result: \(error.localizedDescription)"
        ])
    }
  }

  private func uninstallCanonicalRuntime() throws {
    _ = try runRuntimePackInstaller(arguments: ["--uninstall"])
  }

  private func runRuntimePackInstaller(arguments: [String]) throws -> Data {
    let process = try runtimePackInstallerProcess(arguments: arguments)
    let output = Pipe()
    let errors = Pipe()
    let stdout = BoundedOutputSink(limit: 1 << 20)
    let stderr = BoundedOutputSink(limit: 1 << 16)
    process.standardOutput = output
    process.standardError = errors
    let readers = DispatchGroup()
    for (handle, sink) in [(output.fileHandleForReading, stdout), (errors.fileHandleForReading, stderr)] {
      readers.enter()
      DispatchQueue.global(qos: .userInitiated).async {
        defer { readers.leave() }
        while true {
          let chunk = handle.availableData
          guard !chunk.isEmpty else { return }
          sink.absorb(chunk)
        }
      }
    }
    try process.run()
    process.waitUntilExit()
    readers.wait()
    return try runtimePackInstallerResult(
      stdout: stdout.collected, stderr: stderr.collected,
      terminationStatus: process.terminationStatus, clean: process.terminationReason == .exit)
  }

  /// Asynchronous UI launch. `runBounded` drains both pipes from process start
  /// and reports its result on MainActor; its timeout only terminates this
  /// installer helper, never a discovered runtime/service process.
  private func runRuntimePackInstaller(
    arguments: [String], completion: @escaping (Result<Data, Error>) -> Void
  ) throws {
    let process = try runtimePackInstallerProcess(arguments: arguments)
    try runBounded(process, timeout: 300, label: "runtime pack install") { [weak self] result in
      guard let self else { return }
      completion(Result {
        try self.runtimePackInstallerResult(
          stdout: result.stdout, stderr: result.stderr,
          terminationStatus: result.terminationStatus, clean: result.clean,
          timedOut: result.timedOut)
      })
    }
    runtimeInstallProcess = process
  }

  private func runtimePackInstallerProcess(arguments: [String]) throws -> Process {
    let carrierDirectory = Bundle.main.bundleURL.appendingPathComponent(
      "Contents/Resources/runtime-pack", isDirectory: true)
    let installer = carrierDirectory.appendingPathComponent("install-runtime-pack.sh")
    let publicKey = carrierDirectory.appendingPathComponent("vibecrafted-signing-v1.pub")
    guard FileManager.default.isExecutableFile(atPath: installer.path),
      FileManager.default.fileExists(atPath: publicKey.path)
    else {
      throw NSError(
        domain: "io.vetcoders.vibecrafted.install", code: 1,
        userInfo: [
          NSLocalizedDescriptionKey:
            "signed Runtime Pack bootstrap or trust root is missing"
        ])
    }

    let process = Process()
    process.executableURL = URL(fileURLWithPath: "/bin/bash")
    process.arguments = [installer.path] + arguments
    var environment = ProcessInfo.processInfo.environment
    environment["PYTHONNOUSERSITE"] = "1"
    environment["PYTHONDONTWRITEBYTECODE"] = "1"
    environment["VIBECRAFTED_RUNTIME_PACK_PUBLIC_KEY"] = publicKey.path
    process.environment = environment
    return process
  }

  private func runtimePackInstallerResult(
    stdout: Data, stderr: Data, terminationStatus: Int32, clean: Bool,
    timedOut: Bool = false
  ) throws -> Data {
    if let envelope = decodePreferenceConflict(from: stdout) {
      throw PreferenceConflictError(envelope: envelope)
    }
    guard clean, terminationStatus == 0 else {
      // The installer is a Python program and prints a traceback when it
      // refuses. Reducing it to the owner's actual message is what keeps a
      // stack of interpreter frames out of a normal repair dialog.
      let diagnostic = boundedResolverDiagnostic(
        stdout: stdout, stderr: stderr, limit: 480)
      let detail =
        timedOut
        ? "the Runtime Pack installer timed out; its durable transaction will recover or report its lease state\(diagnostic)"
        : "the Runtime Pack installer exited \(terminationStatus)\(diagnostic)"
      throw NSError(
        domain: "io.vetcoders.vibecrafted.install",
        code: Int(terminationStatus),
        userInfo: [NSLocalizedDescriptionKey: detail])
    }
    return stdout
  }

  /// The generation's canonical bin is prepended to the inherited PATH so the
  /// runtime's own pinned tools resolve deterministically; every user entry
  /// survives behind it. Deduplicate the user's PATH and append the system
  /// floor for shells that intentionally expose only their custom tools.
  private func composedPath(generation: URL, inherited: String?) -> String {
    let generationBin = generation.appendingPathComponent("bin").path
    var seen: Set<String> = [generationBin]
    let entries = ((inherited ?? "").split(separator: ":").map(String.init)
      + ["/usr/bin", "/bin", "/usr/sbin", "/sbin"]).filter {
        $0.hasPrefix("/") && seen.insert($0).inserted
      }
    return ([generationBin] + entries).joined(separator: ":")
  }

  /// Surface a launch failure where the operator can actually see it: the unified
  /// log for post-mortem, plus one modal so a broken install is never silent.
  private func reportWorkspaceLaunchFailure(_ message: String) {
    installLog.error("\(message, privacy: .public)")
    fputs("Vibecrafted workspace launch failed: \(message)\n", stderr)
    guard !workspaceLaunchFailureReported else { return }
    workspaceLaunchFailureReported = true
    let alert = NSAlert()
    alert.alertStyle = .critical
    alert.messageText = "Vibecrafted cannot open its workspace terminal"
    alert.informativeText = message
    alert.addButton(withTitle: "OK")
    alert.runModal()
  }

  /// Process-wide single user-instance ownership. A later launch of a
  /// displaced updater capture must activate `/Applications/Vibecrafted.app`
  /// instead of installing a second menu icon. Special CLI flags are handled
  /// before this runs. Never kills another process and never deletes backups.
  @discardableResult
  private func claimUserAppInstanceOrHandoff() -> Bool {
    let identifier = Bundle.main.bundleIdentifier ?? AppInstanceOwnership.productBundleIdentifier
    let selfPid = Int32(getpid())
    let selfURL = Bundle.main.bundleURL
    let selfPeer = mainInstancePeer(NSRunningApplication.current, identifier: identifier)
    let peers = NSRunningApplication.runningApplications(withBundleIdentifier: identifier)
      .compactMap { app -> AppInstancePeer? in
        guard app.processIdentifier != selfPid else { return nil }
        return mainInstancePeer(app, identifier: identifier)
      }
    let lockURL = AppInstanceOwnership.lockFileURL(
      bundleIdentifier: identifier, home: FileManager.default.homeDirectoryForCurrentUser)
    let parsed = (try? String(contentsOf: lockURL, encoding: .utf8))
      .flatMap(AppInstanceOwnership.parseLockRecord)
    let lockOwner = (peers + [selfPeer].compactMap { $0 }).first { peer in
      peer.pid == parsed?.pid && peer.bundleURL.standardizedFileURL.path == parsed?.path
    }
    let decision = AppInstanceOwnership.decide(
      AppInstanceContext(
        selfPid: selfPid,
        selfBundleURL: selfURL,
        arguments: ProcessInfo.processInfo.arguments,
        peers: peers,
        lockOwnerPid: lockOwner?.pid,
        livePids: Set(peers.map(\.pid)).union([selfPid]),
        selfExecutableURL: selfPeer?.executableURL,
        selfSignedMainExecutableURL: selfPeer?.signedMainExecutableURL))
    switch decision {
    case .refuseOwnership:
      lifecycleLog("instance refused Main executable evidence pid=\(selfPid) path=\(selfURL.path)")
      exit(EXIT_FAILURE)
    case .becomeOwner:
      persistInstanceLock(lockURL, pid: Int32(selfPid), bundleURL: selfURL)
      lifecycleLog("instance owner pid=\(selfPid) path=\(selfURL.path)")
      return true
    case .activateExisting(let pid, let url):
      if let selected = peers.first(where: { $0.pid == pid }),
        let other = NSRunningApplication(processIdentifier: pid),
        mainInstancePeer(other, identifier: identifier) == selected
      {
        lifecycleLog("instance handoff pid=\(pid) path=\(url.path)")
        other.activate(options: [.activateAllWindows, .activateIgnoringOtherApps])
        exit(EXIT_SUCCESS)
      }
      persistInstanceLock(lockURL, pid: Int32(selfPid), bundleURL: selfURL)
      lifecycleLog("instance owner after stale peer pid=\(selfPid) path=\(selfURL.path)")
      return true
    }
  }

  private func mainInstancePeer(_ app: NSRunningApplication, identifier: String) -> AppInstancePeer? {
    guard !app.isTerminated, app.bundleIdentifier == identifier,
      let url = app.bundleURL, let executable = app.executableURL,
      let launchDate = app.launchDate,
      let main = AppInstanceOwnership.signedMainExecutableURL(
        bundleURL: url, bundleIdentifier: identifier)
    else { return nil }
    let peer = AppInstancePeer(
      pid: app.processIdentifier, bundleURL: url, executableURL: executable,
      signedMainExecutableURL: main, launchDate: launchDate)
    return AppInstanceOwnership.isMainHost(peer) ? peer : nil
  }

  /// Best-effort owner record. The installer owns Application Support layout;
  /// this host never creates that directory (unified-app contract).
  private func persistInstanceLock(_ lockURL: URL, pid: Int32, bundleURL: URL) {
    let parent = lockURL.deletingLastPathComponent()
    guard FileManager.default.fileExists(atPath: parent.path) else { return }
    try? AppInstanceOwnership.lockRecord(pid: pid, bundleURL: bundleURL)
      .write(to: lockURL, atomically: true, encoding: .utf8)
  }

  // MARK: - Main Menu

  private func buildStatusItem() {
    tray = StatusItemController { [weak self] action in self?.handleTray(action) }
    tray?.install()
    statusRefreshTimer = Timer.scheduledTimer(withTimeInterval: 5, repeats: true) { [weak self] _ in
      Task { @MainActor [weak self] in self?.refreshServerStatus() }
    }
  }

  private func refreshServerStatus() {
    if let launch = terminalLaunch, !launch.isRunning {
      terminalRegistrationTimer?.invalidate()
      terminalRegistration = nil
      terminalLaunch = nil
      terminalApplication = nil
      if let status = launch.exitStatus, status != 0 {
        showNativeMessage("Terminal exited", "The generation-owned terminal exited with status \(status). Open Terminal to try again.")
      }
    }
    // Render what is already known, then re-ask the owner. The active pointer
    // can move under a running App — a runtime-first upgrade republishes it
    // while the tray is open — so liveness and the service actions must follow
    // the generation the Founder is actually running rather than a root cached
    // at launch forever.
    renderServerStatus()
    resolveInstalledRuntime { [weak self] resolution in
      guard let self else { return }
      guard let install = self.applyResolution(resolution),
        let environment = self.canonicalRuntimeEnvironment
      else {
        self.renderServerStatus()
        return
      }
      self.renderServerStatus()
      self.pollCaretaker(install: install, environment: environment)
      self.pollTrayWork(install: install, environment: environment)
    }
  }

  /// Read the existing lifecycle owner through the same bounded async bridge.
  /// Only the additive running count drives motion. Service health, retained
  /// stalled lanes, CPU and mere terminal/process existence never do.
  private func pollTrayWork(install: CanonicalRuntimeInstall, environment: [String: String]) {
    guard trayWorkProcess == nil else { return }
    let epoch = runtimeResolveEpoch
    let process = Process()
    process.executableURL = install.root.appendingPathComponent("bin/vibecrafted")
    process.arguments = ["status", "--activity", "--json"]
    process.environment = environment
    do {
      try runBounded(process, timeout: 3, label: "tray work activity") { [weak self] result in
        guard let self else { return }
        self.trayWorkProcess = nil
        guard epoch == self.runtimeResolveEpoch else { return }
        let activity = result.clean && !result.timedOut
          ? decodeTrayWorkActivity(data: result.stdout, terminationStatus: result.terminationStatus)
          : .unavailable
        self.lastTrayWork = TrayWorkObservation(activity: activity,
          observedAt: ProcessInfo.processInfo.systemUptime)
        self.updateDeckPresentation()
      }
      trayWorkProcess = process
    } catch {
      lastTrayWork = nil
      updateDeckPresentation()
    }
  }

  /// Read the caretaker verdict of the resolved generation.
  ///
  /// One verb, one truth: the caretaker builds the envelope, publishes it for
  /// every other reader (the HTTP route serves the same bytes), and prints the
  /// already-derived verdict. The tray renders; it never re-derives.
  private func pollCaretaker(install: CanonicalRuntimeInstall, environment: [String: String]) {
    guard serverStatusProcess?.isRunning != true else { return }
    let deck = install.root.appendingPathComponent("bin/vibecrafted")
    guard FileManager.default.isExecutableFile(atPath: deck.path) else {
      lastCaretakerData = nil
      renderServerStatus()
      return
    }
    let epoch = runtimeResolveEpoch
    let process = Process()
    process.executableURL = deck
    process.arguments = serverCaretakerArguments()
    process.environment = environment
    do {
      try runBounded(process, timeout: 30, label: "server caretaker") { [weak self] result in
        guard let self else { return }
        self.serverStatusProcess = nil
        // A verdict about a generation this App no longer controls is not the
        // current truth, however recently it arrived.
        guard epoch == self.runtimeResolveEpoch else { return }
        self.lastCaretakerData = result.clean && result.terminationStatus == 0
          && !result.stdout.isEmpty ? result.stdout : nil
        self.renderServerStatus()
      }
      serverStatusProcess = process
    } catch {
      serverStatusProcess = nil
      lastCaretakerData = nil
      renderServerStatus()
    }
  }

  /// Paint the tray from cached truth alone. This spawns nothing, so it is safe
  /// to call from any completion handler.
  private func renderServerStatus() {
    if canonicalInstall == nil, let reason = runtimeResolutionFailure {
      model.block(reason: "Runtime inspection unavailable: \(reason). VC Server availability is unknown; inspection will retry automatically.")
    } else {
      model.refreshEndpoint(caretakerData: lastCaretakerData, runtimeReady: canonicalInstall != nil)
    }
    updateDeckPresentation()
  }

  private func applyRuntimePackMenuState() { updateDeckPresentation() }

  private func updateDeckPresentation() {
    let state = deriveServerMenuState(caretakerData: lastCaretakerData,
      actionInFlight: serverActionInFlight, runtimeReady: canonicalInstall != nil)
    var actions: Set<CommandDeckChromeAction> = [.showDiagnostics]
    if !repairInFlight { actions.insert(.repairRuntime) }
    if runtimeActionPreflight == nil && serverActionInFlight == nil && !repairInFlight {
      actions.insert(.retryConnection)
    }
    if canonicalInstall != nil && !terminalLaunchInFlight {
      actions.insert(.openTerminal)
      actions.insert(.openProject)
    }
    if state.canStop && runtimeActionPreflight == nil { actions.insert(.requestStopRuntime) }
    model.availableActions = actions
    let presentation = model.presentation
    let runtimePack = deriveRuntimePackMenuState(
      generation: canonicalInstall?.root.lastPathComponent,
      signedSourceRevision: signedCarrierRevisions?.source,
      runtimeReady: canonicalInstall != nil)
    let detail: String
    switch model.state {
    case .blocked(let reason), .recovering(let reason): detail = runtimeResolutionFailure ?? reason
    default: detail = runtimeAdvisory ?? state.detail
    }
    let statusLine: String
    switch presentation.phase {
    case .bootstrapping: statusLine = "Status: Starting…"
    case .connecting: statusLine = "Status: Connecting…"
    case .online: statusLine = "Status: Ready"
    case .recovering: statusLine = "Status: Recovering…"
    case .blocked: statusLine = runtimeResolutionFailure == nil
      ? "Status: Unavailable" : "Status: Runtime inspection unavailable"
    }
    var utilities: Set<StatusItemAction> = []
    if canonicalInstall != nil {
      utilities.formUnion([.revealRuntime, .revealControlPlane, .copyRuntimeIdentity])
      if serverUtilityProcess?.isRunning != true && runtimeActionPreflight == nil { utilities.insert(.showLogs) }
    }
    if state.canStart { utilities.insert(.startServer) }
    if state.canRestart { utilities.insert(.restartServer) }
    let health: TrayServerHealth
    switch presentation.phase {
    case .bootstrapping, .connecting: health = .checking
    case .online: health = state.health
    case .recovering, .blocked: health = runtimeResolutionFailure == nil ? .failed : .neutral
    }
    tray?.update(StatusItemPresentation(
      health: health,
      statusLine: statusLine, detailLine: detail,
      availability: StatusItemAvailability(canShowCommandDeck: true,
        canOpenTerminal: actions.contains(.openTerminal),
        canCheckForUpdates: productUpdate?.isBusy != true,
        canRetryConnection: actions.contains(.retryConnection),
        canRepairRuntime: actions.contains(.repairRuntime),
        canStopRuntime: actions.contains(.requestStopRuntime),
        canShowDiagnostics: true, canQuitApp: true, runtimeActions: utilities),
      toolTip: "Vibecrafted — \(presentation.phase.rawValue). \(detail). \(runtimePack.header). \(runtimePack.detail)",
      work: lastTrayWork))
    // The open server status window consumes the same derivation as the tray,
    // so a poll, a transition or a repair is reflected there immediately.
    renderServerStatusWindow()
  }

  private func revealNativePath(_ url: URL) {
    do { try nativeBridge.perform(.revealPath(try .init(path: url.path))) }
    catch { showNativeMessage("Cannot reveal path", error.localizedDescription) }
  }

  @objc private func revealRuntimeHomeFromStatusItem() {
    guard let install = canonicalInstall else { return }
    revealNativePath(install.runtimeHome)
  }

  @objc private func openControlPlaneFromStatusItem() {
    guard let install = canonicalInstall else { return }
    let controlPlane = install.craftedHome.appendingPathComponent(
      "control_plane", isDirectory: true)
    revealNativePath(
      FileManager.default.fileExists(atPath: controlPlane.path)
        ? controlPlane : install.craftedHome)
  }

  @objc private func copyRuntimeIdentityFromStatusItem() {
    guard let install = canonicalInstall else { return }
    let blob = runtimeIdentityBlob(
      generation: install.root.lastPathComponent,
      sourceRevision: signedCarrierRevisions?.source,
      terminalRevision: signedCarrierRevisions?.terminal,
      frameRevision: signedCarrierRevisions?.frame,
      runtimeHome: install.runtimeHome.path,
      xdgConfigHome: install.configHome.path)
    NSPasteboard.general.clearContents()
    NSPasteboard.general.setString(blob, forType: .string)
  }

  /// Explicit repair, proportionate to what is actually wrong.
  ///
  /// The owner is asked first, read-only. Configuration drift is then repaired
  /// *as configuration*, through the same merge, lease and transaction a
  /// reinstall uses — because republishing this App's carrier to fix a merge is
  /// both heavier than the problem and refused outright when the installation
  /// is newer than the carrier. That refusal is how a merge problem became a
  /// dead end. Reinstalling stays available, named, and the Founder's choice.
  @objc private func repairRuntime() {
    guard !repairInFlight, runtimeActionPreflight == nil, serverActionInFlight == nil
    else { return }
    repairInFlight = true
    updateDeckPresentation()
    runConfigRepair(plan: true) { [weak self] outcome in
      guard let self else { return }
      switch outcome {
      case .repairable(let envelope), .conflict(let envelope), .repaired(let envelope):
        self.repairInFlight = false
        self.updateDeckPresentation()
        self.lastConfigRepair = envelope
        self.offerConfigurationRepair(envelope)
      case .healthy(let envelope):
        self.lastConfigRepair = envelope
        self.reconcileLaunchAgentThenOfferReinstallIfNeeded(
          note: "Configuration inspection found no changes to make.")
      case .absent(let reason):
        self.repairInFlight = false
        self.updateDeckPresentation()
        self.offerRuntimePackReinstall(configuration: reason)
      case .unusable(let reason):
        self.repairInFlight = false
        self.updateDeckPresentation()
        self.offerRuntimePackReinstall(
          configuration: "Configuration could not be inspected: \(reason)")
      }
    }
  }

  /// Config is already right. Restart still fails when the public launcher's
  /// hash drifted from the installed LaunchAgent. Reconcile rewrites that
  /// identity; pack reinstall stays a named last resort.
  private func reconcileLaunchAgentThenOfferReinstallIfNeeded(note: String) {
    guard let install = canonicalInstall, let environment = canonicalRuntimeEnvironment else {
      repairInFlight = false
      updateDeckPresentation()
      offerRuntimePackReinstall(
        configuration: note,
        serviceFailure: runtimeResolutionFailure ?? "The runtime could not be confirmed for service repair.")
      return
    }
    reconcileControlPlaneEye(install: install, environment: environment) { [weak self] result in
      guard let self else { return }
      self.repairInFlight = false
      self.updateDeckPresentation()
      switch result {
      case .success:
        self.presentHealthyRepairResult(note: note)
      case .failure(let detail):
        self.offerRuntimePackReinstall(configuration: note, serviceFailure: detail.message)
      }
    }
  }

  private func presentHealthyRepairResult(note: String) {
    let identity = currentProductUpdateIdentity()
    if let installed = identity.packGeneration,
      shouldOfferRuntimeCarrier(
        resolution: .ready(installed), signedSourceRevision: signedCarrierRevisions?.source) {
      offerRuntimePackReinstall(configuration: note)
      return
    }
    runtimeAdvisory = (identity.packGeneration == identity.appGeneration
      ? "Runtime already current. " : "Configuration is current. ") + note
    applyRuntimePackMenuState()
  }

  @objc private func republishRuntimeAnyway() {
    offerRuntimePackReinstall(configuration: "Explicit republish requested from the App menu.", explicitRepublish: true)
  }

  @objc private func showRuntimeAbout() {
    let identity = currentProductUpdateIdentity()
    let current = identity.packGeneration == identity.appGeneration
    NSApp.orderFrontStandardAboutPanel(options: [
      .credits: NSAttributedString(string:
        (current ? "Runtime already current" : "Installed runtime: " + (identity.packGeneration ?? "unavailable"))
          + "\nCarrier: " + identity.appGeneration)
    ])
  }

  /// Put the small remedy first and the large one beside it, both named.
  private func offerConfigurationRepair(_ envelope: ConfigRepairEnvelope) {
    let alert = NSAlert()
    alert.alertStyle = .warning
    alert.messageText = "Repair Vibecrafted configuration?"
    alert.informativeText =
      configRepairSummary(envelope)
      + "\n\nRepairing keeps your settings and preserves a copy of anything it changes. "
      + "It does not replace the installed runtime."
    alert.addButton(withTitle: "Cancel")
    alert.addButton(withTitle: "Repair Configuration")
    alert.addButton(withTitle: "Reinstall Runtime…")
    switch alert.runModal() {
    case .alertSecondButtonReturn: applyConfigurationRepair()
    case .alertThirdButtonReturn:
      offerRuntimePackReinstall(configuration: configRepairSummary(envelope))
    default: return
    }
  }

  /// Run the owner for real, on the generation that is installed now.
  private func applyConfigurationRepair() {
    guard !repairInFlight, runtimeActionPreflight == nil, serverActionInFlight == nil
    else { return }
    repairInFlight = true
    updateDeckPresentation()
    runConfigRepair(plan: false) { [weak self] outcome in
      guard let self else { return }
      self.repairInFlight = false
      switch outcome {
      case .repaired(let envelope), .healthy(let envelope), .conflict(let envelope),
        .repairable(let envelope):
        self.lastConfigRepair = envelope
        // Configuration moved under the installation, so any cached answer
        // about it is stale by construction.
        self.cachedResolution = nil
        self.presentConfigRepairResult(envelope)
        self.refreshServerStatus()
      case .absent(let reason), .unusable(let reason):
        self.showNativeMessage("Vibecrafted could not repair its configuration", reason)
      }
      self.updateDeckPresentation()
    }
  }

  /// The visible typed outcome: counts, files, reasons, preserved copies.
  private func presentConfigRepairResult(_ envelope: ConfigRepairEnvelope) {
    lifecycleLog(
      "configuration repair: \(envelope.status ?? "unknown") "
        + "repaired=\(envelope.repaired ?? 0) conflicts=\(envelope.conflicts ?? 0)")
    runtimeAdvisory = configRepairAdvisory(envelope)
    let alert = NSAlert()
    alert.alertStyle = envelope.status == "conflict" ? .warning : .informational
    alert.messageText = "Vibecrafted configuration"
    alert.informativeText = configRepairSummary(envelope)
    alert.addButton(withTitle: "OK")
    alert.runModal()
  }

  /// Human upgrade-conflict dialog: conflicting settings, keep/use, diagnostics.
  private func presentPreferenceConflict(
    _ envelope: PreferenceConflictEnvelope,
    afterOnboardingFailure: Bool = false
  ) {
    lastPreferenceConflict = envelope
    runtimeAdvisory = envelope.message
    let alert = NSAlert()
    alert.alertStyle = .warning
    alert.messageText = "Update needs a settings choice"
    alert.informativeText = preferenceConflictSummary(envelope)
    alert.addButton(withTitle: "Cancel")
    alert.addButton(withTitle: "Keep Current")
    alert.addButton(withTitle: "Use Incoming")
    alert.addButton(withTitle: "Show Diagnostics")
    let response = alert.runModal()
    // AppKit names only the first three buttons; the fourth is
    // NSAlertThirdButtonReturn + 1 (raw 1003). `.alertFourthButtonReturn` is
    // not an NSApplication.ModalResponse case.
    let fourthButtonReturn = NSApplication.ModalResponse(
      rawValue: NSApplication.ModalResponse.alertThirdButtonReturn.rawValue + 1)
    switch response {
    case .alertSecondButtonReturn:
      retryPreferenceConflict(envelope, action: "keep-current")
    case .alertThirdButtonReturn:
      retryPreferenceConflict(envelope, action: "use-incoming")
    case fourthButtonReturn:
      showServerDiagnostics()
      presentPreferenceConflict(envelope, afterOnboardingFailure: afterOnboardingFailure)
    default:
      if afterOnboardingFailure, envelope.previousRuntimeAvailable != true {
        let reason = preferenceConflictSummary(envelope)
        runtimeResolutionFailure = reason
        model.block(reason: reason)
      } else {
        refreshServerStatus()
      }
    }
  }

  private func retryPreferenceConflict(_ envelope: PreferenceConflictEnvelope, action: String) {
    guard let choice = preferenceResolutionChoice(from: envelope, action: action) else {
      showNativeMessage(
        "Cannot retry the update",
        "The conflict is no longer bound to current and incoming hashes.")
      return
    }
    guard !repairInFlight, runtimeActionPreflight == nil, serverActionInFlight == nil else { return }
    repairInFlight = true
    updateDeckPresentation()
    installCanonicalRuntime(preferenceChoice: choice) { [weak self] result in
      guard let self else { return }
      self.repairInFlight = false
      defer { self.updateDeckPresentation() }
      switch result {
      case .failure(let error):
        if let conflict = error as? PreferenceConflictError {
          self.presentPreferenceConflict(conflict.envelope)
          return
        }
        self.showNativeMessage("Vibecrafted could not apply the settings choice", error.localizedDescription)
        self.refreshServerStatus()
      case .success(let install):
        self.lastPreferenceConflict = nil
        self.cachedResolution = nil
        guard let repaired = self.applyResolution(.ready(install)),
          let environment = self.canonicalRuntimeEnvironment
        else { return }
        self.workspaceLaunchFailureReported = false
        self.reconcileControlPlaneEye(install: repaired, environment: environment)
        self.applyRuntimePackMenuState()
        self.refreshServerStatus()
        self.webSession.retry()
      }
    }
  }

  /// Publish this App's signed carrier over the current installation.
  ///
  /// Normal opening never reaches here — it resolves whatever is installed —
  /// so replacing a runtime stays something the Founder asks for, with the
  /// generation that would be written named before the fact.
  private func offerRuntimePackReinstall(
    configuration: String, serviceFailure: String? = nil, explicitRepublish: Bool = false,
    startup: Bool = false
  ) {
    guard !repairInFlight, runtimeActionPreflight == nil, serverActionInFlight == nil
    else { return }
    // Reuse the owner's fingerprint-bound resolver. A missing or stale cached
    // launch contract cannot justify either an absence claim or an upgrade.
    repairInFlight = true
    updateDeckPresentation()
    resolveInstalledRuntime(forceRefresh: true) { [weak self] resolution in
      guard let self else { return }
      self.repairInFlight = false
      self.updateDeckPresentation()
      self.presentRuntimePackReinstall(
        resolution: resolution, configuration: configuration,
        serviceFailure: serviceFailure, explicitRepublish: explicitRepublish, startup: startup)
    }
  }

  private func presentRuntimePackReinstall(
    resolution: RuntimeContract, configuration: String,
    serviceFailure: String?, explicitRepublish: Bool, startup: Bool = false
  ) {
    guard !repairInFlight, runtimeActionPreflight == nil, serverActionInFlight == nil
    else { return }
    let identity = currentProductUpdateIdentity()
    let presentationResolution: RuntimeResolution<String>
    let canUpgrade: Bool
    switch resolution {
    case .ready(let install):
      let installed = install.root.lastPathComponent
      presentationResolution = .ready(installed)
      canUpgrade = shouldOfferRuntimeUpgrade(installed: installed, carrier: identity.appGeneration)
    case .absent(let reason):
      presentationResolution = .absent(reason)
      canUpgrade = false
    case .unusable(let reason):
      presentationResolution = .unusable(reason)
      canUpgrade = false
    }
    if startup {
      // The forced resolver may have observed a different generation since
      // startup. Recheck before presenting, then latch only an actual choice.
      guard shouldOfferRuntimeCarrier(
        resolution: presentationResolution, signedSourceRevision: signedCarrierRevisions?.source,
        alreadyOffered: startupCarrierChoiceOffered)
      else { return }
      startupCarrierChoiceOffered = true
    }
    let presentation = runtimeReinstallPresentation(
      resolution: presentationResolution, carrierGeneration: identity.appGeneration,
      configuration: configuration, serviceFailure: serviceFailure,
      canUpgrade: canUpgrade, explicitRepublish: explicitRepublish)
    let confirmation = NSAlert()
    confirmation.alertStyle = .warning
    confirmation.messageText = presentation.title
    confirmation.informativeText = presentation.detail
    guard let actionTitle = presentation.actionTitle else {
      confirmation.addButton(withTitle: "OK")
      confirmation.runModal()
      return
    }
    confirmation.addButton(withTitle: "Cancel")
    confirmation.addButton(withTitle: actionTitle)
    guard confirmation.runModal() == .alertSecondButtonReturn else { return }
    repairInFlight = true
    updateDeckPresentation()
    installCanonicalRuntime { [weak self] result in
      guard let self else { return }
      self.repairInFlight = false
      defer { self.updateDeckPresentation() }
      switch result {
      case .failure(let error):
        lifecycleLog("runtime repair failed: \(error.localizedDescription)")
        if let conflict = error as? PreferenceConflictError {
          self.presentPreferenceConflict(conflict.envelope)
          return
        }
        let failure = NSAlert()
        failure.alertStyle = .critical
        failure.messageText = "Vibecrafted could not reinstall its runtime"
        failure.informativeText = error.localizedDescription
        failure.addButton(withTitle: "OK")
        failure.runModal()
      case .success(let install):
        // Repair just republished the installation, so any cached resolution — and
        // any reading or action still in flight for the previous generation — is
        // stale by construction.
        self.cachedResolution = nil
        guard let repaired = self.applyResolution(.ready(install)),
          let environment = self.canonicalRuntimeEnvironment
        else { return }
        // A repaired install is allowed to report its launch failures again.
        self.workspaceLaunchFailureReported = false
        lifecycleLog("runtime repaired to generation \(repaired.root.lastPathComponent)")
        self.reconcileControlPlaneEye(install: repaired, environment: environment)
        self.applyRuntimePackMenuState()
        self.refreshServerStatus()
        self.webSession.retry()
      }
    }
  }

  @objc private func openConsoleFromStatusItem() { openRoute("/") }
  @objc private func openServerFromStatusItem() { openRoute("/") }
  @objc private func openWorkspacesFromStatusItem() { openRoute("/workspaces") }

  private func openRoute(_ path: String) {
    showMainWindowIfNeeded()
    webSession.navigate(path: path)
    refreshServerStatus()
  }

  @objc private func openTerminalFromStatusItem() {
    do {
      try nativeBridge.perform(.openTerminal(.init(
        workingDirectory: try .init(path: terminalWorkingDirectory.path))))
    } catch { reportWorkspaceLaunchFailure(error.localizedDescription) }
  }

  @objc private func startServerFromStatusItem() {
    performServerAction(.start)
  }

  @objc private func stopServerFromStatusItem() { handle(.requestStopRuntime) }

  @objc private func restartServerFromStatusItem() {
    performServerAction(.restart)
  }

  /// Start, stop or restart the shared service — on the generation that is
  /// installed now, never on one the tray merely remembers.
  ///
  /// The active pointer can move between the menu being drawn and an item being
  /// clicked, and the refresh that would notice it is asynchronous. So the owner
  /// is asked again here and the verb runs against whatever that answer adopts.
  /// An unchanged identity is answered from cache and spawns nothing, which
  /// leaves the ordinary click exactly as immediate as it was.
  private func performServerAction(_ action: ServerLifecycleAction) {
    guard serverActionProcess?.isRunning != true, runtimeActionPreflight == nil else { return }
    runtimeActionPreflight = "server \(action.rawValue)"
    // The transition is honest from the click rather than from the spawn: the
    // Founder asked for it and the App is already working on it.
    serverActionInFlight = action
    renderServerStatus()
    resolveInstalledRuntime { [weak self] resolution in
      guard let self else { return }
      self.runtimeActionPreflight = nil
      guard let install = self.applyResolution(resolution),
        let environment = self.canonicalRuntimeEnvironment
      else {
        // Adoption failed, so there is nothing to act on. Say why, instead of
        // running a service verb through a generation this App no longer
        // controls.
        self.serverActionInFlight = nil
        self.renderServerStatus()
        self.reportWorkspaceLaunchFailure(
          self.runtimeResolutionFailure.map {
            "Cannot \(action.rawValue) VC Server: \($0)"
          } ?? "Cannot \(action.rawValue) VC Server before runtime onboarding completes")
        return
      }
      if action == .stop {
        guard self.confirmedStopRoot == install.root,
          deriveServerMenuState(caretakerData: self.lastCaretakerData,
            actionInFlight: nil, runtimeReady: true).canStop else {
          self.confirmedStopRoot = nil
          self.serverActionInFlight = nil
          self.renderServerStatus()
          self.reportWorkspaceLaunchFailure("Runtime identity or stop availability changed; review Stop Runtime again.")
          return
        }
        self.confirmedStopRoot = nil
      }
      self.runServerAction(action, install: install, environment: environment)
    }
  }

  /// Run the canonical service verb against an identity that was just adopted.
  ///
  /// The epoch is read after that adoption, so this action belongs to the
  /// generation it addresses: if the pointer moves again while the verb runs,
  /// its completion is dropped rather than allowed to repaint the tray.
  private func runServerAction(
    _ action: ServerLifecycleAction,
    install: CanonicalRuntimeInstall,
    environment: [String: String]
  ) {
    let deck = install.root.appendingPathComponent("bin/vibecrafted")
    guard FileManager.default.isExecutableFile(atPath: deck.path) else {
      serverActionInFlight = nil
      renderServerStatus()
      reportWorkspaceLaunchFailure("Canonical server launcher is missing: \(deck.path)")
      return
    }

    let epoch = runtimeResolveEpoch
    let process = Process()
    process.executableURL = deck
    process.arguments = serverActionArguments(for: action)
    process.environment = environment
    do {
      try runBounded(process, timeout: 120, label: "server \(action.rawValue)") {
        [weak self] result in
        guard let self else { return }
        self.serverActionProcess = nil
        // An action that finished against a generation this App no longer
        // controls must not clear the current transition or repaint the tray.
        guard epoch == self.runtimeResolveEpoch else { return }
        self.serverActionInFlight = nil
        if !result.clean || result.terminationStatus != 0 {
          let detail = String(
            data: result.stderr.isEmpty ? result.stdout : result.stderr, encoding: .utf8)?
            .trimmingCharacters(in: .whitespacesAndNewlines)
            ?? "Canonical service owner exited \(result.terminationStatus)"
          if detail.contains("launcher hash differs from the installed LaunchAgent") {
            self.offerReconcileAfterServiceHashMismatch(action: action, detail: detail)
          } else {
            let alert = NSAlert()
            alert.alertStyle = .critical
            alert.messageText = "Vibecrafted could not \(action.rawValue) VC Server"
            alert.informativeText = detail
            alert.addButton(withTitle: "OK")
            alert.runModal()
          }
        }
        self.refreshServerStatus()
      }
      serverActionProcess = process
      // Adoption may have cleared the transition on the way here; the verb is
      // running, so it is true again.
      serverActionInFlight = action
      renderServerStatus()
    } catch {
      serverActionProcess = nil
      serverActionInFlight = nil
      renderServerStatus()
      let alert = NSAlert()
      alert.alertStyle = .critical
      alert.messageText = "Vibecrafted could not \(action.rawValue) VC Server"
      alert.informativeText = error.localizedDescription
      alert.runModal()
    }
  }

  /// Restart cannot rewrite the LaunchAgent. Hash drift is a reconcile job.
  private func offerReconcileAfterServiceHashMismatch(
    action: ServerLifecycleAction, detail: String
  ) {
    let alert = NSAlert()
    alert.alertStyle = .warning
    alert.messageText = "Vibecrafted could not \(action.rawValue) VC Server"
    alert.informativeText =
      detail
      + "\n\nRestart cannot rewrite the LaunchAgent. Reconcile updates it to the current launcher."
    alert.addButton(withTitle: "OK")
    alert.addButton(withTitle: "Reconcile LaunchAgent")
    guard alert.runModal() == .alertSecondButtonReturn else { return }
    guard let install = canonicalInstall, let environment = canonicalRuntimeEnvironment else {
      return
    }
    repairInFlight = true
    updateDeckPresentation()
    reconcileControlPlaneEye(install: install, environment: environment) { [weak self] result in
      guard let self else { return }
      self.repairInFlight = false
      self.updateDeckPresentation()
      if case .failure(let reconcileError) = result {
        self.offerRuntimePackReinstall(configuration: "", serviceFailure: reconcileError.message)
      }
    }
  }

  @objc private func openServerLogsFromStatusItem() {
    guard serverUtilityProcess?.isRunning != true, runtimeActionPreflight == nil else { return }
    // Same rule as the service verbs: the log location belongs to the
    // generation that is installed now, so the owner is asked before the deck
    // of a remembered one is executed.
    runtimeActionPreflight = "server logs"
    resolveInstalledRuntime { [weak self] resolution in
      guard let self else { return }
      self.runtimeActionPreflight = nil
      guard let install = self.applyResolution(resolution),
        let environment = self.canonicalRuntimeEnvironment
      else {
        self.renderServerStatus()
        self.reportWorkspaceLaunchFailure(
          self.runtimeResolutionFailure.map { "Cannot open VC Server logs: \($0)" }
            ?? "Cannot open VC Server logs before runtime onboarding completes")
        return
      }
      self.runServerLogs(install: install, environment: environment)
    }
  }

  /// Ask the canonical service owner where its logs are, on the generation that
  /// was just adopted. The epoch is read after that adoption, so a location
  /// belonging to a runtime this App no longer controls is never opened.
  private func runServerLogs(install: CanonicalRuntimeInstall, environment: [String: String]) {
    let deck = install.root.appendingPathComponent("bin/vibecrafted")
    guard FileManager.default.isExecutableFile(atPath: deck.path) else {
      renderServerStatus()
      reportWorkspaceLaunchFailure("Canonical server launcher is missing: \(deck.path)")
      return
    }

    let epoch = runtimeResolveEpoch
    let process = Process()
    process.executableURL = deck
    process.arguments = ["server", "service", "logs", "--json"]
    process.environment = environment
    do {
      try runBounded(process, timeout: 30, label: "server service logs") { [weak self] result in
        guard let self else { return }
        self.serverUtilityProcess = nil
        guard epoch == self.runtimeResolveEpoch else { return }
        if result.clean, result.terminationStatus == 0,
          let logs = decodeServerLogs(data: result.stdout)
        {
          self.revealNativePath(logs.directory)
        } else {
          let detail = String(
            data: result.stderr.isEmpty ? result.stdout : result.stderr, encoding: .utf8)?
            .trimmingCharacters(in: .whitespacesAndNewlines)
            ?? "Canonical service owner did not return its log location"
          let alert = NSAlert()
          alert.alertStyle = .critical
          alert.messageText = "Vibecrafted could not open VC Server logs"
          alert.informativeText = detail
          alert.addButton(withTitle: "OK")
          alert.runModal()
        }
        self.refreshServerStatus()
      }
      serverUtilityProcess = process
    } catch {
      serverUtilityProcess = nil
      renderServerStatus()
      let alert = NSAlert()
      alert.alertStyle = .critical
      alert.messageText = "Vibecrafted could not open VC Server logs"
      alert.informativeText = error.localizedDescription
      alert.runModal()
    }
  }

  @objc private func showServerDiagnostics() {
    if serverStatusWindow == nil {
      // A utility window, not a modal: titled and closable only, never
      // restorable, and sized by the SwiftUI content it hosts.
      let window = NSWindow(
        contentRect: NSRect(x: 0, y: 0, width: 480, height: 420),
        styleMask: [.titled, .closable],
        backing: .buffered, defer: false)
      window.title = "Vibecrafted Server"
      window.isReleasedWhenClosed = false
      window.isRestorable = false
      window.restorationClass = nil
      let hosting = NSHostingView(rootView: serverStatusRootView())
      window.contentView = hosting
      // The window hugs its content and is not user-resizable, so the App owns
      // the size: fit once here, and let AppKit track the hosting view's
      // preferred size from then on — a finding appearing or the last error
      // wrapping grows the panel instead of clipping it.
      hosting.sizingOptions = [.preferredContentSize]
      window.setContentSize(hosting.fittingSize)
      window.center()
      serverStatusWindow = window
      serverStatusHosting = hosting
    }
    renderServerStatusWindow()
    serverStatusWindow?.makeKeyAndOrderFront(nil)
    NSApp.activate(ignoringOtherApps: true)
  }

  /// The window renders the same reading as the tray: one caretaker envelope,
  /// one `deriveServerMenuState` call, plus the persisted configuration and
  /// upgrade-conflict envelopes. Buttons forward to the exact paths the menu
  /// items use, so no lifecycle flow exists twice.
  private func serverStatusRootView() -> ServerStatusView {
    let state = deriveServerMenuState(
      caretakerData: lastCaretakerData,
      actionInFlight: serverActionInFlight,
      runtimeReady: canonicalInstall != nil)
    return ServerStatusView(
      state: state,
      envelope: decodeCaretakerEnvelope(data: lastCaretakerData),
      configuration: lastConfigRepair,
      upgradeConflict: lastPreferenceConflict,
      canOpenLogs: canonicalInstall != nil
        && serverUtilityProcess?.isRunning != true
        && runtimeActionPreflight == nil,
      onStart: { [weak self] in self?.performServerAction(.start) },
      onStop: { [weak self] in self?.handle(.requestStopRuntime) },
      onRestart: { [weak self] in self?.performServerAction(.restart) },
      onOpenConsole: { [weak self] in self?.showMainWindowIfNeeded() },
      onOpenLogs: { [weak self] in self?.openServerLogsFromStatusItem() },
      onRevealPath: { [weak self] path in
        self?.revealNativePath(URL(fileURLWithPath: path))
      },
      onClose: { [weak self] in self?.serverStatusWindow?.close() })
  }

  private func renderServerStatusWindow() {
    // Assigning rootView re-runs SwiftUI layout; `.preferredContentSize` on
    // the hosting view carries any size change to the window.
    serverStatusHosting?.rootView = serverStatusRootView()
  }

  @objc private func showStatusItemHelp() {
    let alert = NSAlert()
    alert.alertStyle = .informational
    alert.messageText = "Help & Diagnostics"
    alert.informativeText =
      "Open Vibecrafted returns to the app. Check for Updates looks for a signed App and matching Runtime Pack; missing feed or helper is a finished unavailable state, not a spinner. Workspaces and Runtime Server use the configured live server only when it is available. Advanced contains runtime controls and support files. Quitting Vibecrafted leaves the runtime service, terminals, agents, and sessions running."
    alert.addButton(withTitle: "OK")
    alert.addButton(withTitle: "Open Diagnostics")
    if alert.runModal() == .alertSecondButtonReturn {
      showServerDiagnostics()
    }
  }

  private func activeRunSummary() -> RuntimeActivityTruth {
    guard let install = canonicalInstall, let environment = canonicalRuntimeEnvironment else {
      return .unavailable("canonical runtime onboarding is incomplete")
    }
    let deck = install.root.appendingPathComponent("bin/vibecrafted")
    guard FileManager.default.isExecutableFile(atPath: deck.path) else {
      return .unavailable("canonical lifecycle launcher is missing")
    }
    let output = Pipe()
    let process = Process()
    process.executableURL = deck
    process.arguments = ["status", "--activity", "--json"]
    process.environment = environment
    process.standardOutput = output
    process.standardError = FileHandle.nullDevice
    do {
      try process.run()
    } catch {
      return .unavailable(error.localizedDescription)
    }
    // Stop confirmation names the current activity. A bounded failure is
    // reported as unknown activity; Quit App never enters this read path.
    let deadline = Date().addingTimeInterval(activityTruthTimeout)
    while process.isRunning, Date() < deadline {
      usleep(50_000)
    }
    guard !process.isRunning else {
      process.terminate()
      usleep(200_000)
      if process.isRunning {
        kill(process.processIdentifier, SIGKILL)
      }
      lifecycleLog("lifecycle activity read exceeded \(Int(activityTruthTimeout))s; terminated")
      return .unavailable(
        "the canonical lifecycle launcher did not answer within \(Int(activityTruthTimeout))s")
    }
    let data = output.fileHandleForReading.readDataToEndOfFile()
    return decodeRuntimeActivityTruth(data: data, terminationStatus: process.terminationStatus)
  }

  @objc private func requestQuit() {
    NSApp.terminate(nil)
  }

  @objc private func checkForUpdatesFromMenu() {
    let coordinator = productUpdateCoordinator()
    showProductUpdatePanel()
    if !coordinator.isBusy {
      coordinator.checkForUpdates()
    }
  }

  private func productUpdateCoordinator() -> ProductUpdateCoordinator {
    if let productUpdate { return productUpdate }
    let coordinator = ProductUpdateCoordinator(
      dependencies: ProductUpdateCoordinator.Dependencies(
        channel: { [weak self] in
          self?.resolveLiveUpdateChannel() ?? resolveProductUpdateChannel(
            feedURLString: nil, publicKeyURL: nil, helperURL: nil)
        },
        installed: { [weak self] in
          self?.currentProductUpdateIdentity()
            ?? ProductUpdateIdentity(appGeneration: "unknown")
        },
        stagingRoot: {
          FileManager.default.temporaryDirectory.appendingPathComponent(
            "vibecrafted-product-update", isDirectory: true)
        },
        home: { [weak self] in
          self?.craftedHomeURL()
            ?? URL(fileURLWithPath: NSHomeDirectory() + "/.vibecrafted", isDirectory: true)
        },
        fetchBytes: { url, completion in
          productUpdateFetchBytes(url, completion: completion)
        },
        downloadFile: { url, destination, completion in
          productUpdateDownloadFile(url, to: destination, completion: completion)
        },
        verifyFeedSignature: { payload, signature, publicKey, completion in
          let cancelled = ProductUpdateCancelFlag()
          DispatchQueue.global(qos: .userInitiated).async {
            let result = verifyDetachedReleaseSignature(
              payload: payload, signature: signature, publicKeyPath: publicKey.path)
            Task { @MainActor in
              if !cancelled.marked {
                completion(result.mapError { $0 as Error })
              }
            }
          }
          return { cancelled.mark() }
        },
        verifyCandidate: { [weak self] candidate, staging, payload, completion in
          self?.verifyProductUpdateCandidate(
            candidate, staging: staging, payload: payload, completion: completion)
            ?? {}
        },
        installPack: { [weak self] candidate, pack, completion in
          self?.installProductUpdate(candidate, pack: pack, completion: completion) ?? {}
        },
        replaceApp: { [weak self] request, completion in
          self?.replaceProductUpdateAppBundle(request, completion: completion) ?? {}
        },
        extractApp: { dmg, destination, completion in
          productUpdateExtractApp(from: dmg, to: destination, completion: completion)
        },
        closeUIAfterHelperArmed: { [weak self] in self?.requestQuit() },
        checkTimeout: 180,
        settleCaptures: { [weak self] completion in
          guard let self else { return }
          let home = self.craftedHomeURL()
          let helper = self.resolveLiveUpdateChannel().helperURL
          let runtimeHome = self.currentRuntimeHome()
          let destination = Bundle.main.bundleURL
          DispatchQueue.global(qos: .utility).async {
            let result = settleProductUpdateLocalCaptures(
              home: home, destination: destination, helper: helper, runtimeHome: runtimeHome)
            Task { @MainActor in completion(result.mapError { $0 as Error }) }
          }
        }))
    coordinator.onProgress = { [weak self] _ in
      self?.renderProductUpdatePanel()
      self?.updateDeckPresentation()
    }
    productUpdate = coordinator
    return coordinator
  }

  private func resolveLiveUpdateChannel() -> ProductUpdateChannel {
    let feed = Bundle.main.object(forInfoDictionaryKey: "VCUpdateFeedURL") as? String
    let resources = Bundle.main.bundleURL.appendingPathComponent(
      "Contents/Resources/runtime-pack", isDirectory: true)
    let publicKey = resources.appendingPathComponent("vibecrafted-signing-v1.pub")
    let helper = Bundle.main.bundleURL.appendingPathComponent("Contents/Helpers/vc-app-update")
    return resolveProductUpdateChannel(
      feedURLString: feed,
      publicKeyURL: publicKey,
      helperURL: FileManager.default.isExecutableFile(atPath: helper.path) ? helper : nil,
      environment: ProcessInfo.processInfo.environment)
  }

  private func currentProductUpdateIdentity() -> ProductUpdateIdentity {
    let version =
      Bundle.main.object(forInfoDictionaryKey: "CFBundleShortVersionString") as? String ?? "unknown"
    let source = signedCarrierRevisions?.source
    let appGeneration =
      source.map { productUpdateGenerationLabel(version: version, sourceRevision: $0) } ?? version
    return ProductUpdateIdentity(
      appGeneration: appGeneration,
      packGeneration: canonicalInstall?.root.lastPathComponent,
      sourceRevision: source,
      terminalRevision: signedCarrierRevisions?.terminal,
      frameRevision: signedCarrierRevisions?.frame)
  }

  /// Same-generation pack repair, still through the existing installer identity
  /// flags. A newer App is replaced first; this process will not publish that
  /// pack. Receipts are not deleted, and conflict checks stay inside the installer.
  private func installProductUpdate(
    _ candidate: ProductUpdateCandidate,
    pack: URL,
    completion: @escaping @MainActor @Sendable (Result<ProductUpdateIdentity, Error>) -> Void
  ) -> () -> Void {
    let installed = currentProductUpdateIdentity()
    guard productUpdateRunningAppMatchesCandidate(installed: installed, candidate: candidate) else {
      completion(
        .failure(
          NSError(
            domain: "io.vetcoders.vibecrafted.update", code: 2,
            userInfo: [
              NSLocalizedDescriptionKey:
                "Refusing to publish a Runtime Pack that does not match this running App. The previous generation remains."
            ])))
      return {}
    }
    if runtimeInstallProcess != nil {
      completion(
        .failure(
          NSError(
            domain: "io.vetcoders.vibecrafted.update", code: 1,
            userInfo: [
              NSLocalizedDescriptionKey: "the Runtime Pack installer is already in flight"
            ])))
      return {}
    }
    do {
      try runRuntimePackInstaller(
        arguments: runtimePackInstallArguments(
          pack: pack,
          appRoot: Bundle.main.bundleURL,
          sourceRevision: candidate.sourceRevision,
          terminalRevision: candidate.terminalRevision,
          frameRevision: candidate.frameRevision)
      ) { [weak self] result in
        guard let self else { return }
        switch result {
        case .failure(let error): completion(.failure(error))
        case .success(let output):
          do {
            let install = try self.decodeCanonicalRuntimeInstall(from: output)
            self.cachedResolution = nil
            self.prepareLaunchEnvironment(.ready(install)) { prepared in
              guard self.applyResolution(prepared) != nil else {
                completion(.failure(NSError(domain: "io.vetcoders.vibecrafted.update", code: 3,
                  userInfo: [NSLocalizedDescriptionKey: "runtime changed during PATH discovery"])))
                return
              }
              completion(.success(self.currentProductUpdateIdentity()))
            }
          } catch { completion(.failure(error)) }
        }
      }
    } catch {
      completion(.failure(error))
    }
    return { [weak self] in self?.cancelRuntimePackInstaller() }
  }

  private func cancelRuntimePackInstaller() {
    guard let process = runtimeInstallProcess else { return }
    if process.isRunning {
      process.terminate()
    }
  }

  private func verifyProductUpdateCandidate(
    _ candidate: ProductUpdateCandidate,
    staging: URL,
    payload: Data,
    completion: @escaping @MainActor @Sendable (Result<ProductUpdateProof, Error>) -> Void
  ) -> () -> Void {
    let cancelled = ProductUpdateCancelFlag()
    DispatchQueue.global(qos: .userInitiated).async { [weak self] in
      let result = self?.observeVerifiedProductUpdateProof(
        candidate, staging: staging, payload: payload) ?? .failure(ProductUpdateTrustError.pythonMissing)
      DispatchQueue.main.async {
        if !cancelled.marked { completion(result) }
      }
    }
    return { cancelled.mark() }
  }

  private func observeVerifiedProductUpdateProof(
    _ candidate: ProductUpdateCandidate,
    staging: URL,
    payload: Data
  ) -> Result<ProductUpdateProof, Error> {
    guard let packRelative = productUpdateStagedRelativePath(candidate.packRelativePath),
      let appRelative = productUpdateStagedRelativePath(candidate.appRelativePath)
    else {
      return .failure(ProductUpdateTrustError.verifierFailed("signed artifact path is not relative"))
    }
    let pack = staging.appendingPathComponent(packRelative)
    let dmg = staging.appendingPathComponent(appRelative)
    if case .failure(let error) = verifyProductUpdatePayloadDigest(
      fileURL: pack, expectedSHA256: candidate.packSHA256, expectedSize: candidate.packSize)
    {
      return .failure(error)
    }
    if FileManager.default.fileExists(atPath: dmg.path),
      case .failure(let error) = verifyProductUpdatePayloadDigest(
        fileURL: dmg, expectedSHA256: candidate.appSHA256, expectedSize: candidate.appSize)
    {
      return .failure(error)
    }
    let releaseOutput = staging.appendingPathComponent("release-output.json")
    let signature = staging.appendingPathComponent("release-output.json.sig")
    guard let python = resolveInstalledProductContractPython() else {
      return .failure(ProductUpdateTrustError.pythonMissing)
    }
    switch invokeReleaseOutputVerifier(
      releaseOutput: releaseOutput, signature: signature, python: python)
    {
    case .failure(let error):
      return .failure(error)
    case .success:
      break
    }
    let observed = observeProductUpdateRevisions(from: payload)
    let app = staging.appendingPathComponent("Vibecrafted.app")
    guard FileManager.default.fileExists(atPath: app.path),
      let identity = observeProductUpdateCodesignIdentity(appURL: app)
    else {
      return .failure(ProductUpdateTrustError.codesignFailed)
    }
    guard identity.identifier == productUpdateExpectedBundleIdentifier,
      identity.teamID == productUpdateExpectedTeamID
    else {
      return .failure(ProductUpdateTrustError.codesignFailed)
    }
    guard observeProductUpdateStapledNotarization(appURL: app) else {
      return .failure(ProductUpdateTrustError.notarizationFailed)
    }
    let packMatches =
      runtimePackMatchesCarrier(
        generation: candidate.generation, signedSourceRevision: observed.source ?? "")
      && (observed.source?.lowercased() == candidate.sourceRevision.lowercased())
    return .success(
      ProductUpdateProof(
        signatureVerifiedOverExactBytes: true,
        verifierOwner: productUpdateExpectedVerifierOwner,
        payloadHashesMatch: true,
        codesignIdentifier: identity.identifier,
        codesignTeamID: identity.teamID,
        notarizedAndStapled: true,
        packIdentityMatches: packMatches,
        observedSourceRevision: observed.source,
        observedTerminalRevision: observed.terminal,
        observedFrameRevision: observed.frame))
  }

  private func resolveInstalledProductContractPython() -> URL? {
    resolveProductContractPython(installRoot: canonicalInstall?.root)
  }

  private func replaceProductUpdateAppBundle(
    _ request: ProductUpdateReplacementRequest,
    completion: @escaping @MainActor @Sendable (Result<ProductUpdateReplacementAdmission, Error>) -> Void
  ) -> () -> Void {
    var live = request
    if live.helperURL == nil {
      live.helperURL = resolveLiveUpdateChannel().helperURL
    }
    if live.waitStart == nil, let pid = live.waitPID {
      live.waitStart = captureProductUpdateProcessIdentity(pid: pid)?.startTime
    }
    if live.transactionID == nil {
      live.transactionID = UUID().uuidString.lowercased()
    }
    let cancelled = ProductUpdateCancelFlag()
    let processLock = NSLock()
    var spawned: Process?
    var helperAdmitted = false
    DispatchQueue.global(qos: .userInitiated).async {
      do {
        let process = try spawnProductUpdateHelper(live)
        processLock.lock()
        spawned = process
        processLock.unlock()
        if cancelled.marked {
          processLock.lock()
          let admitted = helperAdmitted
          processLock.unlock()
          if !admitted {
            terminateProductUpdateHelper(process)
            DispatchQueue.main.async {
              completion(.failure(ProductUpdateReplacementError.helperFailed("update cancelled")))
            }
          }
          return
        }
        let outcome = waitForProductUpdateHelperAdmission(process: process, request: live)
        if case .success = outcome {
          processLock.lock()
          helperAdmitted = true
          processLock.unlock()
        }
        DispatchQueue.main.async {
          switch outcome {
          case .success(let admission):
            completion(.success(admission))
          case .failure(let error):
            if cancelled.marked { return }
            completion(.failure(error))
          }
        }
      } catch {
        DispatchQueue.main.async {
          if !cancelled.marked {
            completion(.failure(error))
          }
        }
      }
    }
    return {
      cancelled.mark()
      processLock.lock()
      let process = spawned
      let admitted = helperAdmitted
      processLock.unlock()
      if admitted { return }
      if let process {
        terminateProductUpdateHelper(process)
      }
    }
  }

  @discardableResult
  private func adoptPendingProductUpdateIfNeeded() -> ProductUpdateHandoffAdoption {
    let pendingURL = productUpdatePendingHandoffURL(home: craftedHomeURL())
    guard FileManager.default.isReadableFile(atPath: pendingURL.path) else { return .none }
    guard let handoff = try? readProductUpdateHandoff(from: pendingURL) else {
      showNativeMessage(
        "Update did not finish",
        "A previous update left an unreadable recovery record. The current version was not treated as finished.")
      return .retained
    }
    return consumePendingProductUpdate(handoff, pendingURL: pendingURL, alreadyWaited: false)
  }

  private func consumePendingProductUpdate(
    _ handoff: ProductUpdateHandoffRecord,
    pendingURL: URL,
    alreadyWaited: Bool
  ) -> ProductUpdateHandoffAdoption {
    let receiptURL = URL(fileURLWithPath: handoff.receiptURL)
    let replacement = productUpdateObservedReplacementReceipt(at: receiptURL)
    let helperLive = productUpdateHelperIdentityLive(
      pid: handoff.helperPID, start: handoff.helperStart)
    let evidence = productUpdateObserveRuntimeEvidence(
      handoff: handoff,
      runningApp: Bundle.main.bundleURL,
      home: craftedHomeURL(),
      runtimeHome: currentRuntimeHome())
    let decision = decideProductUpdateHandoff(
      handoff: handoff,
      replacement: replacement,
      helperLive: helperLive,
      runningDestination: Bundle.main.bundleURL.path,
      evidence: evidence)
    switch decision {
    case .awaitReceipt:
      if alreadyWaited {
        retainProductUpdateEvidence(handoff, reason: "the replacement receipt is still missing")
        return .retained
      }
      showProductUpdatePanel()
      productUpdateCoordinator().presentFinishing(candidate: nil)
      DispatchQueue.global(qos: .userInitiated).async { [weak self] in
        let found = self?.awaitProductUpdateReceipt(handoff) ?? false
        DispatchQueue.main.async {
          guard let self else { return }
          if found {
            let next = self.consumePendingProductUpdate(
              handoff, pendingURL: pendingURL, alreadyWaited: true)
            self.productUpdateStartupAdoption = next
            if next == .none || next == .retained {
              self.connectCommandDeck()
            }
          } else {
            self.retainProductUpdateEvidence(
              handoff,
              reason: "the update helper is still working or stopped without a receipt")
            self.productUpdateStartupAdoption = .retained
            self.connectCommandDeck()
          }
        }
      }
      return .waiting
    case .publishPack(let receipt):
      return publishAdoptedProductUpdate(
        handoff, replacement: receipt, pendingURL: pendingURL)
    case .restorePrevious(let prior):
      return beginProductUpdateRecover(handoff: handoff, prior: prior)
    case .rolledBack(let reason):
      do {
        try writeProductUpdateRecovery(
          handoff: handoff, reason: reason,
          to: productUpdateRecoveryURL(home: craftedHomeURL()))
      } catch {
        retainProductUpdateEvidence(
          handoff,
          reason:
            "\(reason) Recovery record was not saved. \(error.localizedDescription)")
        return .retained
      }
      try? FileManager.default.removeItem(at: pendingURL)
      showNativeMessage("Previous version restored", reason)
      return .retained
    case .retain(let reason):
      retainProductUpdateEvidence(handoff, reason: reason)
      return .retained
    case .stale(let reason):
      retainProductUpdateEvidence(handoff, reason: reason)
      return .retained
    }
  }

  private func awaitProductUpdateReceipt(_ handoff: ProductUpdateHandoffRecord) -> Bool {
    let receiptURL = URL(fileURLWithPath: handoff.receiptURL)
    let deadline = Date().addingTimeInterval(20)
    while Date() < deadline {
      if let replacement = productUpdateObservedReplacementReceipt(at: receiptURL),
        replacement.replaced
      {
        return true
      }
      if !productUpdateHelperIdentityLive(pid: handoff.helperPID, start: handoff.helperStart) {
        return productUpdateObservedReplacementReceipt(at: receiptURL)?.replaced == true
      }
      Thread.sleep(forTimeInterval: 0.05)
    }
    return productUpdateObservedReplacementReceipt(at: receiptURL)?.replaced == true
  }

  private func retainProductUpdateEvidence(
    _ handoff: ProductUpdateHandoffRecord, reason: String
  ) {
    var message = reason
    do {
      try writeProductUpdateRecovery(
        handoff: handoff, reason: reason,
        to: productUpdateRecoveryURL(home: craftedHomeURL()))
    } catch {
      message =
        "\(reason) Recovery record was not saved. \(error.localizedDescription)"
    }
    showNativeMessage("Update did not finish", message)
  }

  private func publishAdoptedProductUpdate(
    _ handoff: ProductUpdateHandoffRecord,
    replacement: ProductUpdateReplacementReceipt,
    pendingURL: URL
  ) -> ProductUpdateHandoffAdoption {
    var bound = handoff
    bound.capturePath = replacement.capture ?? handoff.capturePath
    bound.phase = "app_replaced"
    do {
      try writeProductUpdateHandoff(bound, to: pendingURL)
    } catch {
      retainProductUpdateEvidence(
        bound,
        reason:
          "Could not save the replaced-app handoff. The Runtime Pack was not published. \(error.localizedDescription)")
      return .retained
    }
    guard let packPath = bound.packURL, FileManager.default.isReadableFile(atPath: packPath) else {
      retainProductUpdateEvidence(
        bound, reason: "the app was replaced, but the matching Runtime Pack was not found")
      return .retained
    }
    let pack = URL(fileURLWithPath: packPath)
    let candidate = ProductUpdateCandidate(
      generation: bound.candidateGeneration,
      sourceRevision: bound.sourceRevision,
      terminalRevision: bound.terminalRevision,
      frameRevision: bound.frameRevision,
      keyID: productUpdateExpectedKeyID,
      algorithm: productUpdateExpectedAlgorithm,
      spkiSHA256: productUpdateExpectedSPKI,
      packRelativePath: pack.lastPathComponent,
      appRelativePath: "Vibecrafted.app",
      packSHA256: String(repeating: "00", count: 32),
      appSHA256: String(repeating: "00", count: 32),
      packSize: 1,
      appSize: 1)
    let coordinator = productUpdateCoordinator()
    coordinator.presentFinishing(candidate: candidate)
    showProductUpdatePanel()
    _ = installProductUpdate(candidate, pack: pack) { [weak self] outcome in
      guard let self else { return }
      switch outcome {
      case .success:
        self.reconcileAdoptedPack(handoff: bound, pendingURL: pendingURL, installerFailed: false)
      case .failure:
        self.reconcileAdoptedPack(handoff: bound, pendingURL: pendingURL, installerFailed: true)
      }
    }
    return .publishing
  }

  /// Reconcile the App replace against the installer's own identity documents.
  /// A caller-written enum is not publication proof. App-only restore is not
  /// whole-tuple success.
  private func reconcileAdoptedPack(
    handoff: ProductUpdateHandoffRecord,
    pendingURL: URL,
    installerFailed: Bool
  ) {
    let observed = productUpdateObserveInstallerPublication(runtimeHome: currentRuntimeHome())
    let derived = productUpdateDerivePackPublication(
      observed,
      priorGeneration: handoff.installedGeneration,
      candidateGeneration: handoff.candidateGeneration)
    do {
      try writeProductUpdatePackEvidence(
        transaction: handoff.transactionID,
        observation: observed,
        derived: derived,
        priorGeneration: handoff.installedGeneration,
        candidateGeneration: handoff.candidateGeneration,
        to: productUpdatePackEvidenceURL(home: craftedHomeURL()))
    } catch {
      retainProductUpdateEvidence(
        handoff,
        reason:
          "Could not persist Runtime Pack observation. \(error.localizedDescription). \(observed.detail)")
      productUpdateStartupAdoption = .retained
      connectCommandDeck()
      return
    }
    switch derived {
    case .published:
      if installerFailed {
        if let prior = productUpdateOwnedPriorApp(at: handoff.capturePath) {
          _ = beginProductUpdateRecover(handoff: handoff, prior: prior)
        } else {
          retainProductUpdateEvidence(
            handoff,
            reason:
              "the installer published \(observed.generation) and then failed; historical rollback data is missing. \(observed.detail)")
          productUpdateStartupAdoption = .retained
          connectCommandDeck()
        }
        return
      }
      let helper = resolveLiveUpdateChannel().helperURL
      let runtimeHome = currentRuntimeHome()
      DispatchQueue.global(qos: .utility).async { [weak self] in
        let settlement = settleProductUpdateCapture(
          handoff: handoff, helper: helper, runtimeHome: runtimeHome)
        DispatchQueue.main.async {
          guard let self else { return }
          switch settlement {
          case .success:
            do {
              try FileManager.default.removeItem(at: pendingURL)
              self.productUpdateStartupAdoption = .none
            } catch {
              self.retainProductUpdateEvidence(
                handoff, reason: "The update completed, but its pending record could not be cleared. \(error.localizedDescription)")
              self.productUpdateStartupAdoption = .retained
            }
          case .failure(let error):
            self.retainProductUpdateEvidence(
              handoff, reason: "The update published, but capture cleanup did not finish. \(error.localizedDescription)")
            self.productUpdateStartupAdoption = .retained
          }
          self.connectCommandDeck()
        }
      }
    case .unpublished, .rolledBack:
      if let prior = productUpdateOwnedPriorApp(at: handoff.capturePath) {
        _ = beginProductUpdateRecover(handoff: handoff, prior: prior)
      } else {
        retainProductUpdateEvidence(
          handoff,
          reason:
            "the Runtime Pack did not stay published, and the previous app capture is missing. \(observed.detail)")
        productUpdateStartupAdoption = .retained
        connectCommandDeck()
      }
    case .unresolved:
      retainProductUpdateEvidence(
        handoff,
        reason:
          "the Runtime Pack installer did not leave a coherent generation. \(observed.detail)")
      productUpdateStartupAdoption = .retained
      connectCommandDeck()
    }
  }

  @discardableResult
  private func beginProductUpdateRestore(
    handoff: ProductUpdateHandoffRecord, prior: URL
  ) -> ProductUpdateHandoffAdoption {
    beginProductUpdateRecover(handoff: handoff, prior: prior)
  }

  /// Restore prior runtime/config/launchers through the installer owner, then
  /// the matching prior app. App-only restore is not treated as success.
  @discardableResult
  private func beginProductUpdateRecover(
    handoff: ProductUpdateHandoffRecord, prior: URL
  ) -> ProductUpdateHandoffAdoption {
    guard productUpdateOwnedPriorApp(at: prior.deletingLastPathComponent().path) != nil else {
      retainProductUpdateEvidence(
        handoff, reason: "the previous app capture is not an owned recovery path")
      return .retained
    }
    let identity = captureProductUpdateProcessIdentity(
      pid: ProcessInfo.processInfo.processIdentifier)
    let receiptURL = URL(fileURLWithPath: handoff.receiptURL)
      .deletingLastPathComponent()
      .appendingPathComponent("recover-receipt.json")
    let request = productUpdateRecoverRequest(
      handoff: handoff,
      priorApp: prior,
      waitPID: identity?.pid ?? ProcessInfo.processInfo.processIdentifier,
      waitStart: identity?.startTime,
      helperURL: resolveLiveUpdateChannel().helperURL,
      receiptURL: receiptURL)
    DispatchQueue.global(qos: .userInitiated).async { [weak self] in
      let outcome = admitProductUpdateHelper(request)
      DispatchQueue.main.async {
        guard let self else { return }
        switch outcome {
        case .success(let admission) where admission.ready:
          var restoring = handoff
          restoring.phase = "restoring"
          restoring.receiptURL = receiptURL.path
          restoring.admissionURL = admission.admissionURL.path
          restoring.journalURL = admission.journalURL?.path ?? handoff.journalURL
          restoring.helperPID = admission.helperPID
          restoring.helperStart =
            captureProductUpdateProcessIdentity(pid: admission.helperPID)?.startTime ?? ""
          restoring.mode = ProductUpdateHelperMode.recover.rawValue
          if !admission.candidateIdentity.isEmpty {
            restoring.priorIdentity = admission.candidateIdentity
          }
          do {
            try writeProductUpdateHandoff(
              restoring, to: productUpdatePendingHandoffURL(home: self.craftedHomeURL()))
          } catch {
            self.retainProductUpdateEvidence(
              restoring,
              reason:
                "Could not save the recover handoff. The window stays open so the helper is not abandoned. \(error.localizedDescription)")
            self.productUpdateStartupAdoption = .retained
            self.connectCommandDeck()
            return
          }
          self.productUpdate?.noteUIShutdownPreservingHandoff()
          self.requestQuit()
        case .success:
          self.retainProductUpdateEvidence(
            handoff, reason: "the recover helper started but did not admit the previous version")
          self.productUpdateStartupAdoption = .retained
          self.connectCommandDeck()
        case .failure(let error):
          self.retainProductUpdateEvidence(
            handoff,
            reason: "the previous app and Runtime Pack could not be restored. \(error.localizedDescription)")
          self.productUpdateStartupAdoption = .retained
          self.connectCommandDeck()
        }
      }
    }
    return .restoring
  }

  private func showProductUpdatePanel() {
    if productUpdatePanel == nil {
      let window = NSWindow(
        contentRect: NSRect(x: 0, y: 0, width: 480, height: 360),
        styleMask: [.titled, .closable],
        backing: .buffered, defer: false)
      window.title = "Check for Updates"
      window.isReleasedWhenClosed = false
      window.isRestorable = false
      window.restorationClass = nil
      window.center()
      productUpdatePanel = window
    }
    renderProductUpdatePanel()
    productUpdatePanel?.makeKeyAndOrderFront(nil)
    NSApp.activate(ignoringOtherApps: true)
  }

  private func renderProductUpdatePanel() {
    guard let window = productUpdatePanel, let coordinator = productUpdate else { return }
    let root = ProductUpdateView(
      progress: coordinator.progress,
      onRetry: { [weak self] in self?.productUpdate?.checkForUpdates() },
      onInstall: { [weak self] in self?.productUpdate?.installUpdate() },
      onClose: { [weak self] in self?.productUpdatePanel?.orderOut(nil) }
    )
    let hosting = NSHostingView(rootView: root)
    window.contentView = hosting
  }

  private func buildMainMenu() {
    let mainMenu = NSMenu()

    // Application menu
    let appMenu = NSMenu()
    appMenu.addItem(
      withTitle: "About Vibecrafted",
      action: #selector(showRuntimeAbout), keyEquivalent: "")
    let republish = appMenu.addItem(withTitle: "Republish anyway…", action: #selector(republishRuntimeAnyway), keyEquivalent: "")
    republish.target = self
    let checkUpdates = appMenu.addItem(
      withTitle: "Check for Updates…", action: #selector(checkForUpdatesFromMenu), keyEquivalent: "")
    checkUpdates.target = self
    checkUpdates.toolTip = "Sprawdź aktualizacje"
    appMenu.addItem(.separator())
    appMenu.addItem(
      withTitle: "Hide Vibecrafted", action: #selector(NSApplication.hide(_:)), keyEquivalent: "h")
    let hideOthers = appMenu.addItem(
      withTitle: "Hide Others", action: #selector(NSApplication.hideOtherApplications(_:)),
      keyEquivalent: "h")
    hideOthers.keyEquivalentModifierMask = [.command, .option]
    appMenu.addItem(
      withTitle: "Show All", action: #selector(NSApplication.unhideAllApplications(_:)),
      keyEquivalent: "")
    appMenu.addItem(.separator())
    let appQuit = appMenu.addItem(
      withTitle: "Quit Vibecrafted", action: #selector(requestQuit), keyEquivalent: "q")
    appQuit.target = self

    let appMenuItem = NSMenuItem()
    appMenuItem.submenu = appMenu
    mainMenu.addItem(appMenuItem)

    // File menu
    let fileMenu = NSMenu(title: "File")
    fileMenu.addItem(
      withTitle: "Close Window", action: #selector(NSWindow.performClose(_:)), keyEquivalent: "w")

    let fileMenuItem = NSMenuItem()
    fileMenuItem.submenu = fileMenu
    mainMenu.addItem(fileMenuItem)

    let viewMenu = NSMenu(title: "View")
    for (title, selector, key) in [
      ("Console", #selector(openConsoleFromStatusItem), "1"),
      ("Server", #selector(openServerFromStatusItem), "2"),
      ("Workspaces", #selector(openWorkspacesFromStatusItem), "3")
    ] {
      let item = viewMenu.addItem(withTitle: title, action: selector, keyEquivalent: key)
      item.target = self
    }
    viewMenu.addItem(.separator())
    let toggleSidebar = viewMenu.addItem(
      withTitle: "Toggle Sidebar", action: #selector(toggleCommandDeckSidebar), keyEquivalent: "s")
    toggleSidebar.keyEquivalentModifierMask = [.command, .control]
    toggleSidebar.target = self
    let toggleInspector = viewMenu.addItem(
      withTitle: "Toggle Inspector", action: #selector(toggleCommandDeckInspector), keyEquivalent: "i")
    toggleInspector.keyEquivalentModifierMask = [.command, .option]
    toggleInspector.target = self
    viewMenu.addItem(.separator())
    // History verbs act on the selected tab only; validation reads its state.
    let home = viewMenu.addItem(withTitle: "Home", action: #selector(goHome), keyEquivalent: "h")
    home.keyEquivalentModifierMask = [.command, .shift]
    home.target = self
    let back = viewMenu.addItem(withTitle: "Back", action: #selector(goBack), keyEquivalent: "[")
    back.target = self
    let forward = viewMenu.addItem(withTitle: "Forward", action: #selector(goForward), keyEquivalent: "]")
    forward.target = self
    let inBrowser = viewMenu.addItem(
      withTitle: "Open Page in Browser", action: #selector(openSelectedPageInBrowser), keyEquivalent: "")
    inBrowser.target = self
    viewMenu.addItem(.separator())
    let openInTab = NSMenu(title: "Open in Tab")
    let openExternal = NSMenu(title: "Open in Browser")
    for destination in ToolDestination.catalog {
      let tabItem = openInTab.addItem(
        withTitle: destination.title, action: #selector(openDestinationInTab(_:)), keyEquivalent: "")
      tabItem.target = self
      tabItem.representedObject = destination.id
      let externalItem = openExternal.addItem(
        withTitle: destination.title, action: #selector(openDestinationExternally(_:)), keyEquivalent: "")
      externalItem.target = self
      externalItem.representedObject = destination.id
    }
    let openInTabItem = viewMenu.addItem(withTitle: "Open in Tab", action: nil, keyEquivalent: "")
    openInTabItem.submenu = openInTab
    let openExternalItem = viewMenu.addItem(withTitle: "Open in Browser", action: nil, keyEquivalent: "")
    openExternalItem.submenu = openExternal
    let viewMenuItem = NSMenuItem()
    viewMenuItem.submenu = viewMenu
    mainMenu.addItem(viewMenuItem)

    let editMenu = NSMenu(title: "Edit")
    for (title, selector, key) in [
      ("Cut", "cut:", "x"), ("Copy", "copy:", "c"),
      ("Paste", "paste:", "v"), ("Select All", "selectAll:", "a")
    ] { editMenu.addItem(withTitle: title, action: NSSelectorFromString(selector), keyEquivalent: key) }
    let editItem = NSMenuItem()
    editItem.submenu = editMenu
    mainMenu.addItem(editItem)

    // Window menu
    let windowMenu = NSMenu(title: "Window")
    windowMenu.addItem(
      withTitle: "Minimize", action: #selector(NSWindow.performMiniaturize(_:)), keyEquivalent: "m")
    windowMenu.addItem(
      withTitle: "Zoom", action: #selector(NSWindow.performZoom(_:)), keyEquivalent: "")
    windowMenu.addItem(.separator())
    // Native tab verbs: AppKit implements them for any window in a tab group.
    let previousTab = windowMenu.addItem(
      withTitle: "Show Previous Tab", action: #selector(NSWindow.selectPreviousTab(_:)), keyEquivalent: "{")
    previousTab.keyEquivalentModifierMask = [.command, .shift]
    let nextTab = windowMenu.addItem(
      withTitle: "Show Next Tab", action: #selector(NSWindow.selectNextTab(_:)), keyEquivalent: "}")
    nextTab.keyEquivalentModifierMask = [.command, .shift]
    windowMenu.addItem(
      withTitle: "Merge All Windows", action: #selector(NSWindow.mergeAllWindows(_:)), keyEquivalent: "")

    let windowMenuItem = NSMenuItem()
    windowMenuItem.submenu = windowMenu
    mainMenu.addItem(windowMenuItem)
    NSApp.windowsMenu = windowMenu

    // Help menu
    let helpMenu = NSMenu(title: "Help")
    let helpMenuItem = NSMenuItem()
    helpMenuItem.submenu = helpMenu
    mainMenu.addItem(helpMenuItem)
    NSApp.helpMenu = helpMenu

    NSApp.mainMenu = mainMenu
  }
}
