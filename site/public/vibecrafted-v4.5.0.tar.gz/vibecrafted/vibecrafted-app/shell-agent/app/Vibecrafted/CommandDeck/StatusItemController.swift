// Vibecrafted — status item
// Created by Vetcoders
//
// Sole tray owner for the shell App. Lifecycle precision stays in
// AppKit (NSStatusItem). Actions are typed callbacks — this type never owns
// runtime processes and never treats Quit App as Stop Runtime.

import AppKit

/// Typed tray verbs. AppDelegate routes these to native bridges; this leaf only emits.
enum StatusItemAction: String, Sendable, CaseIterable {
  case showCommandDeck
  case openTerminal
  case checkForUpdates
  case retryConnection
  case repairRuntime
  case stopRuntime
  case showDiagnostics
  case showServer
  case showWorkspaces
  case startServer
  case restartServer
  case showLogs
  case revealRuntime
  case revealControlPlane
  case copyRuntimeIdentity
  case help
  case quitApp
}

/// Injected enablement for verbs that depend on session/runtime truth owned
/// elsewhere. Defaults deny process actions before runtime truth arrives.
struct StatusItemAvailability: Equatable, Sendable {
  var canShowCommandDeck: Bool
  var canOpenTerminal: Bool
  var canCheckForUpdates: Bool = true
  var canRetryConnection: Bool
  var canRepairRuntime: Bool
  var canStopRuntime: Bool
  var canShowDiagnostics: Bool
  var canQuitApp: Bool
  var runtimeActions: Set<StatusItemAction> = []

  static let `default` = StatusItemAvailability(
    canShowCommandDeck: true,
    canOpenTerminal: false,
    canCheckForUpdates: true,
    canRetryConnection: true,
    canRepairRuntime: true,
    canStopRuntime: false,
    canShowDiagnostics: true,
    canQuitApp: true
  )
}

/// Presentation snapshot for the tray chrome (not process truth).
struct StatusItemPresentation: Equatable, Sendable {
  var health: TrayServerHealth
  var statusLine: String
  var detailLine: String
  var availability: StatusItemAvailability
  var toolTip: String
  var work: TrayWorkObservation? = nil

  static let bootstrapping = StatusItemPresentation(
    health: .checking,
    statusLine: "Status: Starting…",
    detailLine: "Waiting for the runtime owner",
    availability: .default,
    toolTip: "Vibecrafted — preparing"
  )
}

/// AppKit menu-bar owner for Vibecrafted. Construct once, call `install()`,
/// push presentation updates; remove with `uninstall()`. Does not create a
/// second status item in mux-agent or tray-agent.
@MainActor
final class StatusItemController: NSObject, NSMenuDelegate {
  typealias Handler = (StatusItemAction) -> Void

  private let handler: Handler
  private let activityClock: () -> TimeInterval
  private let reduceMotion: () -> Bool
  private var statusItem: NSStatusItem?
  private var presentation: StatusItemPresentation
  private var activityExpiryTimer: Timer?
  private var activityTimer: Timer?
  private var activityFrame = TrayActivityFrame()

  var activityStep: Int { activityFrame.step }
  var isAnimatingActivity: Bool { activityTimer?.isValid == true }
  var isAwaitingActivityExpiry: Bool { activityExpiryTimer?.isValid == true }
  private static weak var installedController: StatusItemController?

  private weak var statusLineItem: NSMenuItem?
  private var actionItems: [StatusItemAction: NSMenuItem] = [:]

  /// Keep user-facing labels and their typed actions in one inspectable shape.
  /// AppDelegate remains the dispatch owner; this menu only emits these actions.
  static let primaryCommands: [StatusItemMenuCommand] = [
    .init(action: .showCommandDeck, title: "Open Vibecrafted", keyEquivalent: "o"),
    .init(action: .openTerminal, title: "Open Terminal", keyEquivalent: "t"),
    .init(action: .checkForUpdates, title: "Check for Updates…"),
    .init(action: .showWorkspaces, title: "Workspaces"),
    .init(action: .help, title: "Help & Diagnostics…")
  ]

  static let advancedCommands: [StatusItemMenuCommand] = [
    .init(action: .retryConnection, title: "Reconnect"),
    .init(action: .repairRuntime, title: "Reinitialize…"),
    .init(action: .showServer, title: "Open Server"),
    .init(action: .startServer, title: "Start Server"),
    .init(action: .restartServer, title: "Restart Server"),
    .init(action: .stopRuntime, title: "Stop Server…"),
    .init(action: .showLogs, title: "Open Logs"),
    .init(action: .revealRuntime, title: "Open Server Folder"),
    .init(action: .revealControlPlane, title: "Open State Folder"),
    .init(action: .copyRuntimeIdentity, title: "Copy Address")
  ]

  init(
    presentation: StatusItemPresentation = .bootstrapping,
    activityClock: @escaping () -> TimeInterval = { ProcessInfo.processInfo.systemUptime },
    reduceMotion: @escaping () -> Bool = { NSWorkspace.shared.accessibilityDisplayShouldReduceMotion },
    handler: @escaping Handler
  ) {
    self.presentation = presentation
    self.activityClock = activityClock
    self.reduceMotion = reduceMotion
    self.handler = handler
    super.init()
  }

  /// Install the one shell status item. Idempotent inside this object and
  /// across controllers in the same process. Process-wide ownership across
  /// alternate bundle paths is `AppInstanceOwnership` in AppDelegate.
  func install() {
    if let installed = Self.installedController, installed !== self {
      return
    }
    guard statusItem == nil else {
      applyPresentation()
      return
    }

    let item = NSStatusBar.system.statusItem(withLength: NSStatusItem.variableLength)
    item.button?.imagePosition = .imageOnly
    item.button?.imageScaling = .scaleProportionallyDown

    let menu = NSMenu(title: "Vibecrafted")
    menu.delegate = self
    menu.autoenablesItems = false

    let status = menu.addItem(withTitle: presentation.statusLine, action: nil, keyEquivalent: "")
    status.isEnabled = false
    statusLineItem = status

    menu.addItem(.separator())
    Self.primaryCommands.forEach { add($0, to: menu) }
    menu.addItem(.separator())

    let advanced = NSMenu(title: "Advanced")
    Self.advancedCommands.enumerated().forEach { index, command in
      if index == 2 || index == 6 || index == 7 { advanced.addItem(.separator()) }
      add(command, to: advanced)
    }
    let advancedItem = menu.addItem(withTitle: "Advanced", action: nil, keyEquivalent: "")
    advancedItem.submenu = advanced
    menu.addItem(.separator())

    // Quit App leaves server / PTYs / agents / sessions alive by contract.
    // AppDelegate routes this callback to App termination only — never Stop Runtime.
    let quit = menu.addItem(
      withTitle: "Quit Vibecrafted",
      action: #selector(emitQuitApp(_:)),
      keyEquivalent: "q"
    )
    quit.target = self
    actionItems[.quitApp] = quit

    item.menu = menu
    statusItem = item
    NSWorkspace.shared.notificationCenter.addObserver(self,
      selector: #selector(accessibilityOptionsChanged(_:)),
      name: NSWorkspace.accessibilityDisplayOptionsDidChangeNotification, object: nil)
    Self.installedController = self
    applyPresentation()
  }

  /// Remove the status item from the system status bar.
  func uninstall() {
    activityExpiryTimer?.invalidate()
    activityExpiryTimer = nil
    activityTimer?.invalidate()
    activityTimer = nil
    activityFrame.reset()
    NSWorkspace.shared.notificationCenter.removeObserver(self)
    guard let item = statusItem else { return }
    NSStatusBar.system.removeStatusItem(item)
    statusItem = nil
    statusLineItem = nil
    actionItems.removeAll()
    if Self.installedController === self {
      Self.installedController = nil
    }
  }

  func update(_ presentation: StatusItemPresentation) {
    self.presentation = presentation
    activityExpiryTimer?.invalidate()
    activityExpiryTimer = nil
    guard statusItem != nil else { return }
    applyPresentation()
  }

  func menuWillOpen(_ menu: NSMenu) {
    applyPresentation()
  }

  // MARK: - Presentation

  private func applyPresentation() {
    let activity = presentation.work?.current(at: activityClock())
      ?? .unavailable
    if let observation = presentation.work, activity != .unavailable, activityExpiryTimer == nil {
      let timer = Timer(timeInterval: max(0.01,
        observation.observedAt + 10 - activityClock()), repeats: false) { [weak self] _ in
        Task { @MainActor [weak self] in
          guard let self else { return }
          self.activityExpiryTimer = nil
          self.applyPresentation()
        }
      }
      RunLoop.main.add(timer, forMode: .common)
      activityExpiryTimer = timer
    }
    let reduceMotion = self.reduceMotion()
    if !activity.isRunning || reduceMotion { activityFrame.reset() }
    if activity.isRunning && !reduceMotion && activityTimer == nil {
      let timer = Timer(timeInterval: 0.6, repeats: true) { [weak self] _ in
        Task { @MainActor [weak self] in
          guard let self else { return }
          let current = self.presentation.work?.current(at: self.activityClock())
            ?? .unavailable
          self.activityFrame.advance(activity: current,
            reduceMotion: self.reduceMotion())
          self.applyPresentation()
        }
      }
      RunLoop.main.add(timer, forMode: .common)
      activityTimer = timer
    } else if !activity.isRunning || reduceMotion {
      activityTimer?.invalidate()
      activityTimer = nil
    }
    let glyph = TrayGlyph.statusImage(health: presentation.health,
      activity: activity, step: activityFrame.step)
    statusItem?.button?.image = glyph
    statusItem?.button?.toolTip = "\(presentation.toolTip). \(activity.description)"
    statusItem?.button?.setAccessibilityLabel(glyph.accessibilityDescription)

    statusLineItem?.title = presentation.statusLine

    let availability = presentation.availability
    for (action, item) in actionItems {
      item.isEnabled = Self.isEnabled(action, availability: availability)
    }
  }

  @objc private func accessibilityOptionsChanged(_ notification: Notification) {
    applyPresentation()
  }

  private func add(_ command: StatusItemMenuCommand, to menu: NSMenu) {
    let item = menu.addItem(
      withTitle: command.title, action: #selector(emitMenuAction(_:)), keyEquivalent: command.keyEquivalent)
    if !command.keyEquivalent.isEmpty { item.keyEquivalentModifierMask = [.command, .option] }
    item.target = self
    item.representedObject = command.action.rawValue
    if command.action == .checkForUpdates {
      item.toolTip = "Sprawdź aktualizacje"
    }
    actionItems[command.action] = item
  }

  static func isEnabled(_ action: StatusItemAction, availability: StatusItemAvailability) -> Bool {
    switch action {
    case .showCommandDeck: availability.canShowCommandDeck
    case .openTerminal: availability.canOpenTerminal
    case .checkForUpdates: availability.canCheckForUpdates
    case .retryConnection: availability.canRetryConnection
    case .repairRuntime: availability.canRepairRuntime
    case .stopRuntime: availability.canStopRuntime
    case .showDiagnostics: availability.canShowDiagnostics
    case .quitApp: availability.canQuitApp
    case .showServer, .showWorkspaces, .help: true
    case .startServer, .restartServer, .showLogs, .revealRuntime, .revealControlPlane, .copyRuntimeIdentity:
      availability.runtimeActions.contains(action)
    }
  }

  // MARK: - Actions

  private func emit(_ action: StatusItemAction) {
    handler(action)
  }

  @objc private func emitMenuAction(_ item: NSMenuItem) {
    guard let raw = item.representedObject as? String,
      let action = StatusItemAction(rawValue: raw) else { return }
    emit(action)
  }

  @objc private func emitQuitApp(_ sender: Any?) {
    emit(.quitApp)
  }
}

struct StatusItemMenuCommand: Equatable {
  let action: StatusItemAction
  let title: String
  let keyEquivalent: String

  init(action: StatusItemAction, title: String, keyEquivalent: String = "") {
    self.action = action
    self.title = title
    self.keyEquivalent = keyEquivalent
  }
}
