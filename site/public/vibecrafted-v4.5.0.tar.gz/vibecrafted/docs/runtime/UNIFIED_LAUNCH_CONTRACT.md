# Unified launch contract: source continuation

This document distinguishes implemented source behavior from integration and
installed acceptance. The original full launch contract remains open. The flag
syntax and catalog table below are implementation choices for review, not newly
attributed Founder decisions.

## Declaration and ownership

Execution skills use `cli.py` -> `workflow.normalize_launch_spec` ->
`launch_workflow`. Shell aliases enter the same core parser. `repo_selection.py`
owns path/ref/catalog resolution. `repository_claims.canonical_repo_identity`
owns repository identity, including validated managed-clone receipts;
`dispatch.worktrees.WorktreeManager` owns linked checkout admission. Provider
argument builders and `model_overrides.py` own exact model flags. `spawn.py` and
`control_plane.py` retain process and durable run-state ownership.

```sh
vibecrafted workflow codex --repo /path/to/repo --base HEAD \
  --execution-runtime local-worktrees --runtime headless --file plan.md
vc-workflow codex --repo team/project --worktree --file plan.md
```

`--repo` is the public spelling; `--root` is a conflict-checked alias. An existing
path wins over identity syntax. Explicit missing paths are errors. Public core
launches without either flag resolve the caller's Git top-level, never the build
root or ambient workspace. Subdirectories and symlinks resolve to that worktree.

`--base` defaults to local `HEAD` for paths (including unpushed commits), and the
source remote's current default branch for catalog identities. Branches and tags
with the same spelling require `refs/heads/...` or `refs/tags/...`. Local refs
stay local; remote refs require qualification. Resolution produces a commit SHA
before materialization. Linked worktrees use that SHA even if the parent moves.
Dirty parent files and index are preserved. A Living Tree request for another
commit refuses; it never checks out, stashes, resets or commits the parent.

The implementation separates `--execution-runtime living-tree|local-worktrees`
from `--runtime headless|visible|terminal` (legacy presentation names). `--worktree`
is the local-worktrees alias. VM/cloud and unknown runtime spellings refuse;
there is no local fallback. Visible/terminal lifecycle parity still requires
native acceptance and the reserved transport integration.

## Catalog identities

The existing `$XDG_CONFIG_HOME/vibecrafted/config.toml` (default
`~/.config/vibecrafted/config.toml`) can contain explicit source URLs:

```toml
[repositories."team/project"]
remote = "ssh://git@git.example.org/team/project.git"
```

There is no implicit GitHub host. Unknown entries refuse. Credential-bearing
HTTP URLs, passwords, query strings, fragments and unsupported transports
refuse before Git. Use the Git provider's existing authentication mechanism.
Local paths/file remotes support hermetic testing.

A managed clone lives under
`$VIBECRAFTED_HOME/repositories/<remote-digest>/<org>/<repo>`. A receipt in its
common Git directory binds identity and origin. Reuse checks both. Clone/fetch
mutations are locked by remote; preparation subprocesses have bounded timeouts.
Branches and tags refresh into separate remote namespaces with pruning; remote
HEAD is queried for every selection. A requested SHA must be reachable from a
refreshed source branch or tag; cache-only commit objects refuse. A partial clone or foreign cache without a
valid receipt refuses and is preserved for inspection. Worker checkouts retain
the standard `worktrees/<org>/<repo>/YYYY_MMDD/<cut>/` geometry.

Remote-host execution and transporting a local-only commit are unsupported.
The catalog is resolved on the execution host; this implementation only has a
local host adapter. A managed clone's local HEAD is not silently moved when the
remote default changes: use local-worktrees to launch from the refreshed SHA.

## Model and prompt

Launch selection is CLI model > plan-frontmatter model > provider default.
Dispatch TOML `model` is an explicit override at the same precedence as CLI.
Resume selection is CLI model > newly supplied plan model > previous effective
model (then previous requested model if effective observation is unavailable).
A plain continuation note and an old runtime prompt snapshot do not reselect a
model. Parent metadata and source plan files are never rewritten by overrides.

The existing frontmatter parser has a strict launch mode using the existing
PyYAML dependency. A model must be one nonempty string. Null, collections,
booleans, numbers, duplicate model/agent keys and provider conflicts refuse.
BOM/CRLF are accepted for metadata extraction without modifying source bytes.
Model identifiers pass unchanged to provider argument lists; no universal
`effort` exists. Catalog/account availability remains a provider rejection,
not proof from the local parser. A provider with no known model flag refuses
an explicit pin rather than silently ignoring it.

`--prompt TEXT` remains supported as one argument (including heredoc-equivalent
shell substitutions), with `--file` and `--prompt-stdin` alternatives. The deck
moves inline text to a private pipe before invoking Python. Core materializes
`plan-source.md` and `prompt.md` through the existing writer with exclusive
creation and mode 0600. Existing files and symlinks are not overwritten. The
source digest detects edits between selection and launch. Report-safe spec
serialization omits prompt text; receipts include source digest/reference and
model source. Snapshots stay with the run for historical attribution; no new
automatic cleanup deletes them or the input file.

The initial shell argv exposure and OS ARG_MAX cannot be undone. Use file/stdin
for inputs beyond ARG_MAX. This cut proves producer transport; it does not
certify every downstream provider or HTTP log viewer. The Agy adapter carries
the prompt as one stream-json user message on stdin (`agy --print=
--input-format stream-json --output-format stream-json < prompt.ndjson`); the
prompt never reaches argv, and the human pane / last message come from the
shared `agent_stream --agent agy` parser (`result.response`).
Supervised research lanes and native interactive prompt composition still need
end-to-end privacy admission.

## Public entry matrix

| Entry                                                                                                                                   | Parser and route                                                                                                                                                      | Repo/base/execution                                                    | Model/prompt                                                              | Evidence boundary                                                                                                                    |
| --------------------------------------------------------------------------------------------------------------------------------------- | --------------------------------------------------------------------------------------------------------------------------------------------------------------------- | ---------------------------------------------------------------------- | ------------------------------------------------------------------------- | ------------------------------------------------------------------------------------------------------------------------------------ |
| workflow, implement, review, research, marbles                                                                                          | public deck -> core CLI -> workflow; `--session` on a single-agent launcher is `manual_resume_session` (same path as resume --session). Research refuses `--session`. | shared core flags; session continuation stays in the selected checkout | strict selection, private core input                                      | focused source tests; live agy High `--conversation` resume is source-probed, not an installed-generation claim                      |
| audit, canary, decorate, delegate, dou, followup, guard, hydrate, intents, justdo, ownership, polarize, prune, release, scaffold, trust | same core execution route                                                                                                                                             | shared core flags                                                      | same selection                                                            | alias/parser route; skill semantics unchanged                                                                                        |
| vc-\* execution aliases                                                                                                                 | deck `run_wrapper` or Python wrappers -> core                                                                                                                         | same as corresponding skill                                            | same as corresponding skill                                               | native alias installation not changed                                                                                                |
| resume --run-id                                                                                                                         | shell shared parser -> core operator_continue_run                                                                                                                     | original root/baseline; conflicting overrides refuse                   | new CLI/plan/previous precedence                                          | canonical metadata provider wins over settlement author                                                                              |
| resume --session with explicit input                                                                                                    | shared parser -> resume-session                                                                                                                                       | explicit native session; no unrecorded baseline override               | whole plan or stdin, exact model                                          | native session exclusion/PTY acceptance remains open                                                                                 |
| bare resume, fork, init, partner, operator                                                                                              | shell -> spawn interactive-command -> normalize_launch_spec -> interactive-launch                                                                                     | canonical repo/base/execution; resume preserves recorded checkout      | immutable private admission/source, exact model; fresh child run identity | real PTY fixture cases cover normal and failed provider exits for init/partner/operator/resume; native Frame/fork acceptance pending |
| dispatch TOML                                                                                                                           | dispatch schema/supervisor -> workflow                                                                                                                                | existing dispatch substrate and baseline policy                        | TOML override / brief model; source and model frozen together             | dependency baseline policy needs final audit; no fleet launched by this worker                                                       |
| vc-start / vibecrafted start                                                                                                            | shared dashboard parser; enter live, restore EXITED, or create missing workspace                                                                                      | local path; default Git top-level name                                 | no work/model flags added                                                 | fake-engine and real-PTY fixtures; installed entry acceptance pending                                                                |
| VOC/App/MCP                                                                                                                             | their owned declarations -> core                                                                                                                                      | capability additions required below                                    | capability additions required below                                       | sibling integrations and installed acceptance pending                                                                                |
| observe/await/status and other read-only commands                                                                                       | existing observation owners                                                                                                                                           | no meaningless work flags                                              | no prompt launch contract                                                 | unchanged                                                                                                                            |

## Public `vc-*` / `vibecrafted <verb>` alias matrix

One semantic owner: the packaged deck (`vibecrafted-core/vibecrafted_core/deck/vibecrafted`, mirrored at `scripts/vibecrafted`). Python `cli.SHELL_WRAPPER_VERBS` only prepends the deck verb when the installed name is a symlink or hatch-less shim to `vibecrafted`. Runtime install writes that verb into the shim (`_RUNTIME_WRAPPER_VERBS`) because `#!` rebuilds argv. Interactive zsh uses `_vetcoders_vc_passthrough`. A PATH symlink alone is not enough: `run_wrapper` falls back to `_has_skill`, and fork/operator are not skills.

| Pair                                                                                                                  | Owner / route                                                   | Publication                                                                                                                                                                   | Evidence boundary                                                                                                                                                                                            |
| --------------------------------------------------------------------------------------------------------------------- | --------------------------------------------------------------- | ----------------------------------------------------------------------------------------------------------------------------------------------------------------------------- | ------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------ |
| `vc-workflow` ↔ `vibecrafted workflow` (and the other `LAUNCHERS` / `SKILL_WRAPPER_NAMES` skills, including `canary`) | deck `run_skill` / core `LAUNCHERS`                             | skill wrappers: `bin/vc-*` + wheel `[project.scripts]` when listed in `PYTHON_ENTRYPOINT_LAUNCHERS`; `canary` is a deck-verb shim (`SHELL_WRAPPER_VERBS`), not a hatch script | source tests compare both spellings at the same launch boundary; skill semantics unchanged                                                                                                                   |
| `vc-init` ↔ `vibecrafted init`                                                                                        | deck `cmd_init`                                                 | `LAUNCHER_WRAPPERS` + `SHELL_WRAPPER_VERBS` + `_RUNTIME_WRAPPER_VERBS` + `run_wrapper` + `dispatch.sh`                                                                        | existing resume/init wrapper tests                                                                                                                                                                           |
| `vc-resume` ↔ `vibecrafted resume`                                                                                    | deck `cmd_resume`                                               | same deck-verb family                                                                                                                                                         | existing wrapper tests; native session/PTY acceptance remains open                                                                                                                                           |
| `vc-fork` ↔ `vibecrafted fork`                                                                                        | deck `cmd_fork` only — no `fork_main`, no hatch script          | same deck-verb family (`vc-fork` added to the four coordinated maps + `run_wrapper` + `dispatch.sh`)                                                                          | authored source tests invoke both spellings; compare help, refusal rc/text, and normalized child/admission argv. No live provider. Installed PATH on a frozen generation is the next admission, not this cut |
| `vc-operator` ↔ `vibecrafted operator`                                                                                | deck `cmd_operator`                                             | same deck-verb family (shell `dispatch.sh` already passed through; installer/PATH now matches)                                                                                | help/refusal parity tests; live operator TTY is native acceptance                                                                                                                                            |
| `vc-start` ↔ `vibecrafted start`                                                                                      | shared start owner (not a full-arg passthrough — re-entry bomb) | `vc-start` binary / deck `cmd_start`                                                                                                                                          | existing start tests                                                                                                                                                                                         |
| `vc-dashboard` / `vc-dispatch` / `vc-help` / `vc-doctor` / `vc-status` / `vc-update` / `vc-receipt` / `telemetry`     | deck verbs via `SHELL_WRAPPER_VERBS`                            | deck-verb shims                                                                                                                                                               | existing catalog/set-equality tests                                                                                                                                                                          |
| `vc-justdo` ↔ `vibecrafted justdo`                                                                                    | deck `run_skill justdo` (not implement)                         | deck-verb shim                                                                                                                                                                | ADR-0001; existing justdo tests                                                                                                                                                                              |

Explicitly **not** equivalent — do not invent a silent twin:

| Name                                                                                  | Why it is not a 1:1 public pair                                                                        | What to use                                                                                        |
| ------------------------------------------------------------------------------------- | ------------------------------------------------------------------------------------------------------ | -------------------------------------------------------------------------------------------------- |
| `vc-partner` (wheel/`wrappers.partner_main`) vs `vibecrafted partner`                 | in-session skill wrapper vs TTY/frame launcher                                                         | `vibecrafted partner` / shell passthrough for the TTY face; `/vc-partner` inside a session         |
| `vc-observe` / `vc-await` / `vc-stop`                                                 | no public `vc-*` alias; read-only verbs stay on the deck/core owner and must not grow work/model flags | `vibecrafted observe\|await\|stop <agent>`                                                         |
| `vc-research-await` / `vc-research-synthesize` / `vc-sandbox` / `vc-paste` / `vc-git` | standalone or sidecar binaries (alias matrix `STANDALONE`)                                             | the named binary; no `vibecrafted <verb>` requirement                                              |
| `vc-frame` / `vc-terminal` / `voc` / `vc-server` / `vc-slack`                         | product binaries, not workflow aliases                                                                 | those binaries                                                                                     |
| Wheel `[project.scripts]`                                                             | publishes `PYTHON_ENTRYPOINT_LAUNCHERS` only                                                           | deck-verb aliases (`vc-fork`, `vc-init`, …) are installer/runtime shims, same as today's `vc-init` |

Help text may mention both spellings. Tests must compare actual normalized request/child semantics, help, and failure behavior — not merely that the strings `vc-fork` or `cmd_fork` exist. This cut does not certify every provider adapter or a live installed generation.

## Provider and presentation capability matrix

| Provider      | Model argument                                         | Private prompt mechanism in current source                    | Status                                                                                                                                                        |
| ------------- | ------------------------------------------------------ | ------------------------------------------------------------- | ------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| Codex         | `-m` after `exec`, including absolute executable paths | stdin                                                         | source tested; two live native Codex forks verified                                                                                                           |
| Claude        | `--model`                                              | print-mode stdin                                              | source tested; native session/account acceptance pending                                                                                                      |
| Grok          | `--model` (`-m` recognized)                            | `--prompt-file /dev/stdin`                                    | adapter inspected; runtime acceptance pending                                                                                                                 |
| Cursor        | `--model`                                              | existing stream/stdin contract                                | adapter admission retained; runtime acceptance pending                                                                                                        |
| Junie         | advertised `--model` is forwarded                      | existing text input                                           | native resume concurrency remains unverified                                                                                                                  |
| Agy           | `--model` after the binary                             | stream-json stdin (`--print=` + `--input-format stream-json`) | source tested; live `--conversation` resume probed 2026-09-11 on gemini-3.8-flash-high; native fork unsupported; installed generation is a separate admission |
| Gemini legacy | deprecated                                             | no supported launch                                           | rejected; no substitution of requested model                                                                                                                  |

Codex native fork acceptance uses an isolated live interactive source; other native provider concurrency remains unverified.

## Workspace creation and Frame dependency

The recovered START implementation uses one parser for the deck and shell.
It chooses the explicit workspace name or repository basename, validates it,
reads live/exited engine inventory, and refuses duplicate engine creation.
Worktree materialization currently precedes this check; that ordering remains open. No silent attach, replacement, suffix, kill or deletion.
Inventory failures refuse rather than treating uncertainty as an empty list.
Outside Frame, creation is exclusive; a no-TTY caller opens VC Terminal only
after successful creation, carrying the exact root and created-session marker.

Inside Frame, `vc-start` creates an ordinary project session from
`operator.kdl`, retaining its Launchpad, Agents and Shell tabs plus one
session canvas. Voc is not a project tab: its single entry is the global chip
beside Composer in the topbar. CLI entry uses the native action, subject to the source-client
restriction below:

```text
vc-frame --session <attached-session> --client-id <source-client-id> action switch-session <project>
```

The source session is the live attached owner (`VC_FRAME_SESSION_NAME`).
The launcher reads `list-clients` and forwards the sole observed numeric client ID
through the global `--client-id` argument. Frame validates that exact attached
frontend when admitting the action: a concurrent attach or input cannot redirect
it to the last active client, and a stale ID refuses without an untargeted retry.
Forwarding pane markers does not identify the caller because clients may share a
pane. Ambiguous, malformed or unreadable source inventory therefore refuses with
exit 4. The destination may already have any number of clients. With multiple
source clients, use the native Sessions rail or Cmd-Up/Down, which carry the actual
frontend identity. This shell-origin restriction does not constrain native keys
or rail navigation.

Outside Frame, entry uses
`attach <project>`; no-TTY entry delegates to VC Terminal with the exact created
session. Creation and entry are separate: an entry failure must leave the created
session available and report it honestly. Name collisions remain exit 3;
inventory, creation and ambiguous CLI source-client failures exit 4. Native entry propagates the engine's
exit status without a projection or terminal fallback.

Operator Frame is an ordinary standalone session, displayed as 00, with
Dashboard, Active runs, Config, Doctor and Projects. Its layout is embedded in
the Frame binary. The `frame_host` marker identifies that session's rail role;
it does not turn project sessions into guests. Project layouts carry neither
`frame_host` nor `workspace_surface`. The retained physical `vc-host` name does
not define the role. `--new-host` explicitly creates an additional Operator
Frame session for a generation transition while existing sessions remain intact.
For the fixed macOS product-host path, the one-shot handoff back into that exact
session is accepted only when bounded process ancestry passes the same
selected-generation static pair and live-code proof used by native host
admission. A shell receipt or same-user process is not substitute authority.
Generation-local developer and Linux hosts retain their physical ancestry
contract. If any created-host handoff cannot be proven, start exits before
creating another session or window, leaves the reported host intact, and prints
an explicit `vc-frame attach <host>` recovery command. It never allocates a
suffixed replacement for a rejected handoff.

Projects are displayed from 01 with their separate tabs. Cmd-Up/Down changes
the client's session; Cmd-Left/Right changes only that session's tabs. The active
session must be visible on the rail. Selected tab and focus belong to each
client and survive leaving and rejoining; another client's selection must not
replace them. There is no nested Frame terminal or guest readiness gate. A second
client on the destination never blocks entry; the temporary CLI restriction
applies only to identifying the source client.

The acceptance boundary is two projects and two clients of one project,
switching both ways while preserving state and exactly one chrome per client.
Close buttons, informational status/GitHub panels and arbitrary client counts
remain part of the contract. Configuration and launcher tests alone do not prove
this native multi-client behavior or installed runtime acceptance.

## Reserved integration interfaces

- **Admitted Live Runs (`071c24b8`):** exact scoped owner patches are reconciled. Preserve launch identity fields through all phases and
  settlement; event author (`guardian`) must not replace execution provider
  (`claude`). `control_plane._merge_event_stream` preserves admitted provider identity across
  Guardian events; the regression covers launch-Claude / complete-Guardian without
  rewriting historical events. Preserve `model_source`,
  source digest/reference, repo kind/request, baseline/ref, runtime class and
  presentation in durable projections. Native continuation metadata must retain
  parent linkage. Prove readiness/publication failure semantics at process launch.
- **Spawn:** Agy's `--print "$(cat)"` inner argv transport is retired. Every
  supervised lane (workflow, research, synthesis) hands agy one stream-json
  user turn on stdin, materialized by the async supervisor from the prompt file
  (`prompt_transport.materialize_stdin_file`, 0600 `prompt.ndjson`); the argv
  is `agy … --print= --input-format stream-json --output-format stream-json`.
  Verify provider transcript echo and HTTP log viewing cannot disclose raw
  prompt snapshots. Verify inherited runtime Python
  state is scrubbed at every provider boundary; no host interpreter repair.
- **VOC:** add base, execution-runtime, repo identity capability, model selector
  and model-source/source-reference fields without reordering the provider
  catalog or changing rendering. Display unsupported VM/cloud and Agy private
  transport explicitly. Existing `workflow-capabilities` region is reserved.
- **Frame:** entry uses native per-client session switching or external attach.
  Closing a client must not own the worker lifecycle.

Interactive admission now reserves a fresh run identity before a provider starts,
materializes the original source and admission at mode 0600, passes only private
references through command composition, and uses the existing control-plane owner
for prepared, active and terminal projections. The output capture keeps provider
TTY descriptors while recording a private, prompt-filtered transcript. Admission
replay refuses a second executor. Interactive native-session leases exclude another
interactive launch for the same native identity.

Init/partner/operator stay interactive even with explicit input. Bare resume stays
interactive; explicit prompt/file/stdin resume takes the tracked noninteractive
path. Shell command substitution may already have removed trailing newlines before
admission; the launcher preserves the bytes it actually receives, including CRLF.
Dispatch stores the admitted original source independently of its assembled runtime
instructions. Research model pins belong to the selected provider role, not swarm.

Remaining acceptance includes native Frame viewer detachment and cold-start Operator Frame
entry, supervised transcript echo filtering, other-provider native fork acceptance, complete native-
session mutual exclusion across interactive and noninteractive paths, and all-surface
idempotency/crash/cleanup. Explicit provider-session resume without a recorded run
still cannot accept an unrecorded baseline override. These are not passes.

Review and integrate the local commits before a clean signed build. The Operator
owns installation, notarization, live UI/provider acceptance and release.

## Shared session selection and native task forks

Resume, fork, and single-agent workflow launchers share `--session <session_id|current|last>`. `--run-id` is a
separate control-plane identity and cannot be combined with `--session`.
On a workflow launcher, `--session` continues the named provider session through
`manual_resume_session`; it does not start a fresh session and is not a run id,
PID, or workspace id. Research refuses `--session` because it is a multi-agent swarm.
`resume --last` and `--session previous` are retired and refuse explicitly.

`current` requires one explicit provider identity from parent process context;
it never means newest mtime. A recorded source must match the selected checkout.
`last` selects the newest timezone-aware start timestamp among **recorded native
sessions in the selected checkout and provider**. It includes the current session
if that session is newest. Equal timestamps for different sessions refuse as
ambiguous. Native sessions absent from control-plane records are outside this
selector's inventory; pass their exact native ID. This is a deliberate scoped
inventory rule, not provider-global history selection.

Bare fork remains interactive. `--prompt`, `--file` or `--prompt-stdin` selects
a tracked noninteractive fork; an explicit incompatible presentation refuses.
Codex uses `exec ... fork <source> -`, with parent exec flags before the fork
subcommand. Claude and Grok compose native resume with `--fork-session`.
The normal permission/model/repository/worktree owners still apply. Original
input is retained in a private byte-exact source snapshot; the provider receives
the runtime instruction envelope through stdin. Child metadata records
`native_fork`, `fork_source_session_id` and `parent_run_id`. The parent session ID
is never seeded as the child's identity. A successful process without a distinct
native child ID is a failed fork.

Bare interactive fork admission proves a provider process was started, not that
its pane displays a new native session. The receipt leaves `agent_session_id`
and `provider_session_id` empty with `native_identity_status: pending`.
`provider_session_requested`, when present, is only the UUID supplied to a
provider's `--session-id` option; Codex fork has no such option. Without an
attributable provider acknowledgement, an exit-zero interactive fork settles as
`native_fork_identity_unconfirmed`. Codex now implements the correlated
acknowledgement described below. No newest-file or inherited
parent-ID heuristic promotes it to success. Remote app-server/pane child identity
and continued source usability remain required native acceptance.

`session_selection` retains the original selector, resolved native source,
selection root and resolution provenance through admission and control-plane
projection. A handed-off `last` selection is pinned: admission revalidates its
exact target rather than selecting again after newer runs appear. Source selection
and child identity are separate evidence.

The installed help advertises no verified native fork mechanism for Agy, Junie
or Cursor. Their refusal describes this adapter limit; it is not exhaustive proof
that their product can never fork. Headless exact-session resume for Agy uses
`--conversation` composed onto the private stream-json stdin lane (agy 1.2.1
probed 2026-09-11). Interactive exact-session resume uses Agy's
`--conversation`, Junie's `--resume --session-id`, Cursor's `--resume`, and Grok's
`--resume`. Junie and Cursor headless resume remain unverified. These argv contracts have help evidence; their real live-source
concurrency is not certified by an installed generation.

Full launcher parity remains incomplete: all-entrypoint request idempotency,
prepared-admission failure recovery, workspace duplicate-before-materialization,
slow-display backpressure, supervised partial-echo/log-view privacy, and installed
Frame/VOC lifecycle acceptance retain their separate proof obligations. Output
capture follows terminal geometry during quiet periods; this is not full keyboard
or every-terminal SIGWINCH acceptance.

## Exact deck generation selection

Invoking a physical checkout `scripts/vibecrafted` (or its packaged deck copy)
selects that checkout's core and shell helpers, independently of cwd and inherited
`VIBECRAFTED_ROOT` / `VIBECRAFTED_RUNTIME_ROOT`. Those variables are context, not
development selectors. Select another checkout by invoking its deck explicitly.
`VIBECRAFTED_PYTHON` remains the explicit development interpreter override;
an override pointing into a receipted installed generation is rejected for source
selection. Otherwise the checkout's core `.venv` or host Python is used. Select
a receipted installed generation by invoking its physical deck: its adjacent
core and `bin/python3` are mandatory, with no foreign-generation/host fallback.
`--repo` / `--root` select the work repository and never the code generation.
VOC consumes the real selected deck catalog; absent provider/environment cells
remain unavailable, without a locally invented capability list.

## Runtime python pin

The pin belongs to the running runtime; shells only inherit it.

- **Entry pins.** A process entering the runtime -- a public `vc-*` /
  `vibecrafted` launcher, `bin/vc-terminal`, `bin/vc-frame`, the bash spawn
  launcher, the headless worker gate (`env_allowlist.filter_headless_worker_env`)
  -- exports `VIBECRAFTED_PYTHON`, the absolute `bin/python3` of its own
  generation, and puts that generation's door `config/runtime-pin/bin` first on
  PATH. A child keeps an inherited pin, so an update never moves a live session.
- **Door.** `config/runtime-pin/bin/{python,python3}` are one file that execs
  `$VIBECRAFTED_PYTHON`. A missing, relative, non-executable or self-referential
  pin (a door, or a script whose shebang finds python on PATH) exits 127 with the
  reason. There is no fallback to the host python or to the active generation.
  The door holds only those two names; every other lookup keeps the user's order.
- **Shells inherit.** zsh startup reorders PATH (`/etc/zprofile` path_helper,
  personal `~/.zshenv` / `~/.zshrc`). The headless gate and the spawn launcher
  point `ZDOTDIR` at the generation's guest directory `config/runtime-pin/zsh`,
  which runs the user's own startup files (`VIBECRAFTED_USER_ZDOTDIR`, default
  `$HOME`) and then puts the door back in front; product shells (vc-terminal,
  Frame panes, Quick cmd) get the same from their ZDOTDIR stage files. `zsh -c`,
  `zsh -l`, `zsh -i`, `sh -c`, `bash -c`, hooks and `#!/usr/bin/env python3`
  therefore reach one interpreter. `bash -l` reads only the user's own
  `~/.bash_profile` after path_helper and is not re-pinned.
- **Framework code never depends on PATH.** Launchers, hooks and pane runners
  name their interpreter by absolute path; the door is convenience for agents
  and scripts.
- **Outside the runtime** nothing changes: no door on PATH, no guest ZDOTDIR,
  nothing published in `~/.local/bin`, and `python3` stays the user's own.

Proof: `tests/tui/test_runtime_python_pin.py` crosses each boundary against a
personal profile that prepends a host python at every zsh stage.

## Correlated interactive Codex fork

The interactive spawn owner uses the selected Codex executable's app-server
`thread/fork`, correlating the response ID to the run. It requires a distinct
native child ID, exact `forkedFromId`, and admitted cwd, then independently calls
`thread/read` for that exact child and checks all three fields again. Only then
are the child IDs and `native_identity_evidence` published through the existing
control plane. The selected CLI opens that acknowledged child with `resume`;
the source is never the resume target. Permission/model selection is retained.
The public bare fork opens the child idle. Its synthetic shell skill marker is
not a user task and is not submitted to the provider; explicit task-bearing
forks continue through the private-input headless path.

Local native RPC uses that exact executable's `app-server --stdio` and its existing
Codex home. Explicit `CODEX_REMOTE=unix:///absolute/socket` uses that same remote
endpoint for the native fork and interactive CLI. Other remote transports refuse
before provider spawn; no fallback changes the selected endpoint or executable.
The acknowledgement deadline is bounded. Missing/mismatched replies leave the
receipt failed and identity unconfirmed, with no automatic retry of a possibly
completed native mutation. Process/window admission remains separate from native
identity and from terminal exit. Other providers retain their existing pending
identity semantics until a correlated acknowledgement adapter is implemented.
The Unix WebSocket adapter uses the maintained BSD-licensed `websockets` client
for framing, bounded reads and connection cleanup; it does not implement a
second session resolver or persist identities outside the control plane.
