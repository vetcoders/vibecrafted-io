---
status: accepted
kind: brief
layout_id: Layout-1
title: Warsztat
owner: grok
authored_by: grok <agents@vetcoders.io>
session_id: 01a00bfd-5efc-7bf0-883f-a5d096f5235d
date: 2026-08-17
grid: 120x36
source_cheat: 120x36-operator-vertical
studio_type: 12px/1.28
scope: agents-workshop
product: vibecrafted
next: layout-factory
---

# Layout-1 · Warsztat

Jedna twarz. Pasek talii w tytule, nie na Quick cmd. Rail zostaje. Zero nachodzących floatów.

```
0         1         2         3         4         5         6         7         8         9         0         1
012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789
 Vibecrafted. | L  ○ Launchpad  ◉ Agents  ○ shell                                                   Voc · Composer · cmd
SESSIONS 5          ┌ grok · vibecrafted ──────────────────────────────────────────────────────── [‹2/4›] [Voc] [Nowy] ┐
 ● Live 3           │ 4.1.0 · feat/resume-no-implicit-native-session                                                   │
01 ○ main           │                                                                                                  │
02 ○ lbrx-svc       │ Operator: floating, Ctrl+P, strzalki. hehe                                                           │
   · Shell          │ Jeden talerz. Host: float, rename, PANE, strzalki.                                               │
03 ○ w-c207         │                                                                                                  │
   · resume-grok    │ Pasek talii: [‹][›] [Voc] [Nowy]                                                                 │
   · resume-codex   │ New agent = interaktywny TTY na tym tabie.                                                       │
04 ◉ vc-release     │ Dispatch / headless = inne drzwi, pozniej.                                                       │
   · Launchpad      │                                                                                                  │
   ◉ Agents         │                                                                                                  │
   · shell          │                                                                                                  │
                    │                                                                                                  │
05 ○ vibecrafted-vc_│                                                                                                  │
   · resume-grok    │                                                                                                  │
   · Shell          │                                                                                                  │
   · grok           │                                                                                                  │
                    │                                                                                                  │
                    │                                                                                                  │
                    │                                                                                                  │
                    │                                                                                                  │
                    │                                                                                                  │
                    │                                                                                                  │
                    │                                                                                                  │
                    │                                                                                                  │
                    │                                                                                                  │
                    │                                                                                                  │
                    │                                                                                                  │
                    │                                                                                                  │
                    │                                                                                                  │
                    │ ╭──────────────────────────────────────────────────────────────────────────────────────────────╮ │
                    │ │ ❯                                                                                            │ │
                    │ ╰─ Grok 4.6 · always-approve ──────────────────────────────────────────────────────────────────╯ │
                    └──────────────────────────────────────────────────────────────────────────────────────────────────┘
 LOCK  PANE  TAB  MOVE                                                                                   LIVE 3 | HEALTH
```
