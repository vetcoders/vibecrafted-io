"""Async supervisor: spawns agent processes, streams output, and settles run state."""

from __future__ import annotations

import asyncio
import json
import math
import os
import signal
import stat
import sys
import time
from collections.abc import Callable, Mapping, Sequence
from dataclasses import dataclass, field
from datetime import UTC, datetime
from pathlib import Path

from .agent_stream import (
    AgentStreamParser,
    is_grok_ignorable_transport_error,
    resolve_default_model,
)
from .artifacts import ArtifactValidation, validate_artifacts
from .control_plane import (
    accepted_operator_stop_since,
    control_plane_home,
    ensure_session_id,
    event_resume_cursor,
    normalize_run_root,
)
from .env_allowlist import dispatcher_identity, filter_headless_worker_env
from .events import append_event
from .failure_attribution import attribute_failure
from .harness_usage import kimi_session_id_from_store
from .lifecycle import EventKind, RunState
from .model_overrides import _model_override_receipt
from .process_control import process_identity_receipt
from .prompt_transport import materialize_stdin_file, stdin_transport
from .report_contract import CLAIM_DIGEST_ENV
from .run_mutation import RunMetaMutationError, mutate_run_meta
from .telemetry import (
    CostRecord,
    RunTelemetry,
    Unknown,
    UsageRecord,
    build_run_telemetry,
    parent_session_ids,
    resolve_provider_session_id,
    tokens_total,
    usage_record,
)

STDIO_LIMIT_BYTES = 16 * 1024 * 1024
# Well under the reconciler's 120s staleness threshold, so an ordinary talking
# worker is never mistaken for a dead one, while a long tool call still emits
# at most a handful of pulse events.
_HEARTBEAT_INTERVAL_SECONDS = 20.0

# The heartbeat above tells "quiet" apart from "dead"; it never tells 20 seconds
# of quiet apart from three hours of it. Every pulse looks identical, so a worker
# blocked forever in `wait4` held the supervisor open forever — which made the
# RunState.STALLED transition in `run()` unreachable in production, because the
# only thing that could reach it was `--timeout` and no caller ever passed one.
#
# A wall-clock cap is the wrong instrument: it would also kill a worker that is
# legitimately long AND talking. Bound the SILENCE instead — the signal the
# watcher already measures — so productive runs are never touched and a mute one
# becomes a recorded stall with an exit code. Resolved at the watcher, not at the
# caller: a bound that has to be threaded is a bound nobody arms.
#
# 0 or negative disables it; VIBECRAFTED_SILENCE_TIMEOUT_SECONDS overrides.
_SILENCE_TIMEOUT_ENV = "VIBECRAFTED_SILENCE_TIMEOUT_SECONDS"
_DEFAULT_SILENCE_TIMEOUT_SECONDS = 1800.0


class _SilenceTimeout(asyncio.TimeoutError):
    """A live worker produced no output for longer than the silence bound.

    Subclasses ``asyncio.TimeoutError`` so the wall-clock ``wait_for`` handler in
    ``run()`` settles both stall kinds through one already-tested path, while the
    recorded reason still says which instrument fired.
    """


def _default_silence_timeout() -> float:
    """Seconds of unbroken stdout silence after which a live worker is stalled."""
    raw = os.environ.get(_SILENCE_TIMEOUT_ENV, "").strip()
    if not raw:
        return _DEFAULT_SILENCE_TIMEOUT_SECONDS
    try:
        return float(raw)
    except ValueError:
        # An unparseable override must not silently disable the bound.
        return _DEFAULT_SILENCE_TIMEOUT_SECONDS


def _utc_now() -> datetime:
    """Current UTC-aware datetime."""
    return datetime.now(UTC)


def _provider_store_home() -> Path:
    """User home holding provider session stores; overridable for hermetic tests."""
    override = str(os.environ.get("VIBECRAFTED_PROVIDER_STORE_HOME") or "").strip()
    return Path(override).expanduser() if override else Path.home()


# Sources whose session id the provider itself revealed for this child.
_PROVIDER_OBSERVED_SESSION_SOURCES = frozenset(
    {"provider_stream", "provider_session_store"}
)
# AgentStreamParser.resume_command placeholder while its stream has no id.
_RESUME_SESSION_PLACEHOLDER = "<session_id>"


def _with_adopted_session(handle: AsyncRunHandle, resume_command: str) -> str:
    """Fill the resume placeholder with a validated store-adopted identity.

    kimi names its session only in the trailing resume hint, so the parser's
    command still carries the placeholder after the store revealed the id.
    """
    if (
        handle.stream_session_source != "provider_session_store"
        or not handle.agent_session_id
        or handle.agent_session_id != handle.stream_session_id
    ):
        return resume_command
    return resume_command.replace(_RESUME_SESSION_PLACEHOLDER, handle.agent_session_id)


def _read_meta(handle: AsyncRunHandle) -> dict[str, object]:
    """Best-effort read of the run's meta.json for parent-identity refusal."""
    if handle.meta_path is None:
        return {}
    try:
        payload = json.loads(handle.meta_path.read_text(encoding="utf-8"))
    except (OSError, ValueError):
        return {}
    return payload if isinstance(payload, dict) else {}


def transcript_human_path(transcript_path: Path | None) -> Path | None:
    """Sibling human-readable rendering of the raw transcript.

    The raw file is a machine contract (await, session-id extraction, salvage)
    and must stay byte-exact provider output. Streaming-json providers such as
    grok are unreadable there, so the AgentStreamParser rendering that
    ``_watch_process`` already produces is persisted next to it instead of
    being discarded when no terminal tee is attached.
    """
    if transcript_path is None:
        return None
    return transcript_path.with_name(
        transcript_path.stem + ".human" + transcript_path.suffix
    )


def _infer_agent(command: Sequence[str]) -> str:
    """Guess the agent name from argv[0] when VIBECRAFTED_AGENT is not set."""
    if not command:
        return "agent"
    name = Path(str(command[0])).name
    # Fleet key is `cursor` but the spawned binary is `cursor-agent`
    # (spawn.AGENT_BINARY_NAMES); fold the binary back onto the fleet key.
    if name == "cursor-agent":
        return "cursor"
    if name in {
        "claude",
        "codex",
        "agy",
        "junie",
        "grok",
        "cursor",
        "kimi",
        "copilot",
        "omp",
    }:
        return name
    if name in {"python", "python3"}:
        return "python"
    return name or "agent"


def _json_text_fragment(event: dict[str, object]) -> str:
    """Select assistant evidence using the canonical agent_stream event shapes.

    Pane rendering also includes thinking and tool output, so its display text
    is not an attestation. Only explicit assistant/answer fields belong here.
    """
    if event.get("role") not in (None, "assistant") or event.get("parent_tool_use_id"):
        return ""

    def content_text(value: object) -> str:
        if isinstance(value, str):
            return value
        if isinstance(value, list):
            return "".join(
                block["text"]
                for block in value
                if isinstance(block, dict)
                and block.get("type") == "text"
                and isinstance(block.get("text"), str)
            )
        return ""

    event_type = str(event.get("type") or "")
    if event_type == "assistant.message" and isinstance(event.get("data"), dict):
        return content_text(event["data"].get("content"))
    if event_type == "assistant":
        message = event.get("message")
        if isinstance(message, dict) and message.get("role") in (None, "assistant"):
            return content_text(message.get("content"))
        return content_text(event.get("content")) if message is None else ""
    if event.get("role") == "assistant":
        return content_text(event.get("content"))
    if event_type == "item.completed":
        item = event.get("item")
        if isinstance(item, dict) and item.get("type") == "agent_message":
            text = item.get("text")
            return text if isinstance(text, str) else ""
    if event_type == "result" or event.get("event") == "result":
        if event.get("is_error"):
            return ""
        result = event.get("result")
        return content_text(
            result.get("response") if isinstance(result, dict) else result
        )
    if event_type == "text":
        return content_text(
            event.get("data") or event.get("text") or event.get("content")
        )
    if event_type == "content":
        content = event.get("content")
        if isinstance(content, dict) and content.get("type") == "text":
            return content_text(content.get("text"))
    return ""


def _fallback_report_body(transcript_text: str) -> str:
    """Reconstruct a readable report body from raw JSON/plain transcript lines.

    Used when a worker exits 0 without writing its own report; skips
    grok transport-noise lines via ``is_grok_ignorable_transport_error``.
    """
    text_fragments: list[str] = []
    plain_lines: list[str] = []
    json_transport = False
    fence = ""
    for line in transcript_text.splitlines():
        stripped = line.strip()
        if not stripped:
            plain_lines.append(line)
            continue
        if stripped.startswith(("```", "~~~")):
            marker = stripped[:3]
            fence = "" if fence == marker else marker
            plain_lines.append(line)
            continue
        if fence:
            plain_lines.append(line)
            continue
        if stripped.startswith("{"):
            json_transport = True
            try:
                loaded = json.loads(stripped)
            except json.JSONDecodeError:
                continue
            if isinstance(loaded, dict):
                fragment = _json_text_fragment(loaded)
                is_result = (
                    loaded.get("type") == "result" or loaded.get("event") == "result"
                )
                # Claude's terminal result repeats its final assistant message.
                # Suppress only that exact mirror; conflicting text stays visible
                # so reception can reject ambiguous blocks rather than hide them.
                if fragment and not (
                    is_result and text_fragments and fragment == text_fragments[-1]
                ):
                    if is_result and text_fragments:
                        text_fragments.append("\n")
                    text_fragments.append(fragment)
            continue
        if is_grok_ignorable_transport_error(line):
            continue
        plain_lines.append(line)
    body = "".join(text_fragments).strip()
    if body:
        return body + "\n"
    if json_transport:
        return ""
    return "\n".join(plain_lines).strip() + ("\n" if plain_lines else "")


def _is_workflow_parent(command: Sequence[str]) -> bool:
    return len(command) >= 3 and tuple(command[1:3]) == (
        "-m",
        "vibecrafted_core.workflow_runtime",
    )


def _run_telemetry(handle: AsyncRunHandle) -> RunTelemetry:
    """Usage, cost, failure cause and provider session of a closing run.

    Cached on the handle so meta, report and terminal footer tell one story.
    The provider session comes from the stream first, then from the launch
    contract; either is refused when it equals a parent/runtime session id.
    """
    if handle.telemetry is not None:
        return handle.telemetry
    usage = usage_record(
        handle.usage_events,
        tokens_input=handle.tokens_input,
        tokens_cached_input=handle.tokens_cached_input,
        tokens_cache_write=handle.tokens_cache_write,
        tokens_output=handle.tokens_output,
        source="provider_stream",
    )
    failure = None
    if not handle.operator_stopped:
        failure = attribute_failure(
            handle.transcript_path, handle.exit_code, agent=handle.agent
        )
    aggregate = _workflow_parent_telemetry(handle, failure)
    if aggregate is not None:
        handle.agent_model = "aggregated"
        handle.telemetry = aggregate
        return aggregate
    if handle.stream_session_id:
        candidate, candidate_source = (
            handle.stream_session_id,
            handle.stream_session_source,
        )
    else:
        candidate, candidate_source = handle.agent_session_id, "launch_contract"
    telemetry = build_run_telemetry(
        usage=usage,
        model=handle.agent_model,
        reported_cost=handle.cost_usd,
        reported_cost_source=handle.cost_source,
        session_candidate=candidate,
        session_source=candidate_source,
        parents=parent_session_ids(
            extra={"runtime_session_id": handle.session_id, **handle.parent_sessions}
        ),
        failure=failure,
        agent=handle.agent,
        started_at=handle.started_at.isoformat(),
        completed_at=handle.completed_at.isoformat() if handle.completed_at else None,
    )
    # A provider-observed identity that survived parent/runtime refusal is the
    # child's native session. The legacy aliases must not settle empty beside it.
    if (
        not handle.agent_session_id
        and candidate_source in _PROVIDER_OBSERVED_SESSION_SOURCES
        and isinstance(telemetry.provider_session_id, str)
    ):
        handle.agent_session_id = telemetry.provider_session_id
        handle.resume_command = _with_adopted_session(handle, handle.resume_command)
    handle.telemetry = telemetry
    return telemetry


def _workflow_parent_telemetry(handle: AsyncRunHandle, failure) -> RunTelemetry | None:
    """Reduce terminal child receipts, never the orchestration Python stream.

    Only the source-owned workflow module may publish this aggregate. Read
    each exact terminal child meta and cross-check identity/usage mirrors;
    arbitrary report prose or a precomputed parent sum is not evidence.
    """
    if not _is_workflow_parent(handle.command):
        return None
    if handle.meta_path is None:
        return None
    reason = "no terminal child receipts"
    events = 0
    totals = {
        key: 0
        for key in (
            "tokens_input",
            "tokens_cached_input",
            "tokens_output",
            "tokens_total",
        )
    }
    cache_write = 0
    cache_known = True
    cost = 0.0
    cost_known = True
    valid = False
    try:
        parent = json.loads(handle.meta_path.read_text())
        if not isinstance(parent, dict) or parent.get("run_id") != handle.run_id:
            raise ValueError("workflow_parent_identity_mismatch")
        children = parent.get("children")
        receivers = parent.get("receivers", [])
        if not isinstance(children, list) or not isinstance(receivers, list):
            raise TypeError("workflow_child_receipts_missing")
        rows = children + receivers
        if isinstance(parent.get("synthesis"), dict) and parent["synthesis"]:
            rows.append(parent["synthesis"])
        if not rows:
            raise ValueError("no terminal child receipts")
        seen: set[str] = set()
        all_known = True
        for row in rows:
            if not isinstance(row, dict) or not isinstance(row.get("run_id"), str):
                raise TypeError("invalid_workflow_child_receipt")
            run_id = row["run_id"]
            if not run_id.startswith(handle.run_id + "-") or run_id in seen:
                raise ValueError("workflow_child_identity_conflict")
            seen.add(run_id)
            report = Path(row["report"])
            child = json.loads(report.with_suffix(".meta.json").read_text())
            for key in ("run_id", "agent", "report", "transcript", "exit_code"):
                if child.get(key) != row.get(key):
                    raise ValueError(f"workflow_child_receipt_mismatch:{key}")
            if Path(
                str(child.get("root") or "")
            ).resolve() != handle.root.resolve() or not child.get("completed_at"):
                raise ValueError("workflow_child_not_terminal_on_assigned_root")
            usage = child.get("usage")
            if (
                not isinstance(usage, dict)
                or usage.get("schema") != "vibecrafted.usage.v1"
            ):
                raise ValueError("invalid_workflow_child_usage_schema")
            count = usage.get("events")
            if type(count) is not int or count < 0:
                raise ValueError("invalid_workflow_child_usage_events")
            events += count
            values = {key: usage.get(key) for key in totals}
            known = count > 0 and all(
                type(value) is int and value >= 0 for value in values.values()
            )
            if usage.get("unit") != "tokens" or (count > 0 and not known):
                raise ValueError("invalid_workflow_child_usage_values")
            if known:
                if values["tokens_total"] != tokens_total(
                    values["tokens_input"],
                    values["tokens_cached_input"],
                    values["tokens_output"],
                ):
                    raise ValueError("contradictory_workflow_child_usage")
                for key, value in values.items():
                    if child.get(key) != value or row.get(key) != value:
                        raise ValueError(f"contradictory_workflow_child_usage:{key}")
                    totals[key] += value
            else:
                if not all(
                    isinstance(value, dict)
                    and value.get("value") == "unknown"
                    and value.get("reason")
                    for value in values.values()
                ):
                    raise ValueError("unmeasured_workflow_child_claims_known_usage")
                if any(
                    child.get(key) != "unknown" or row.get(key) != "unknown"
                    for key in values
                ):
                    raise ValueError("contradictory_workflow_child_unknown_usage")
                all_known = False
            created = usage.get("tokens_cache_write")
            if type(created) is int and created >= 0:
                cache_write += created
            else:
                cache_known = False
            child_cost = child.get("cost")
            if not isinstance(child_cost, dict):
                raise TypeError("invalid_workflow_child_cost")
            amount = child_cost.get("amount")
            if (
                type(amount) in {int, float}
                and math.isfinite(amount)
                and amount >= 0
                and child_cost.get("currency") == "USD"
                and not child_cost.get("unit")
            ):
                if child_cost.get("source") != "provider_reported" and not str(
                    child_cost.get("source")
                ).startswith("estimated:"):
                    raise ValueError("unmeasured_workflow_child_claims_known_cost")
                if child.get("cost_usd") != amount or row.get("cost_usd") != amount:
                    raise ValueError("contradictory_workflow_child_cost")
                cost += amount
            else:
                cost_known = False
        valid = all_known
        reason = "one or more child phases have unmeasured usage"
    except (OSError, ValueError, TypeError, KeyError) as error:
        reason = f"workflow aggregate refused: {error}"
        cost_known = False
    missing = Unknown(reason=reason)
    usage = UsageRecord(
        **{key: value if valid else missing for key, value in totals.items()},
        tokens_cache_write=cache_write
        if valid and cache_known
        else Unknown(reason="child cache-write usage incomplete"),
        source="children_sum",
        events=events if valid else 0,
    )
    return RunTelemetry(
        usage=usage,
        cost=CostRecord(
            amount=round(cost, 6)
            if cost_known
            else Unknown(reason="child cost evidence incomplete or invalid"),
            source="children_sum" if cost_known else "unknown",
        ),
        failure=failure,
        provider_session_id=Unknown(reason="workflow parent has no provider session"),
        provider_session_source="none",
        model="aggregated",
    )


def _origin_fields_from_env(env: Mapping[str, str] | None = None) -> dict[str, str]:
    """Durable origin identity for post-run triage (dispatcher has no pane env)."""
    source = env if env is not None else os.environ

    def _get(*names: str) -> str:
        """Return the first non-empty stripped value found among *names* in the env source."""
        for name in names:
            value = str(source.get(name, "") or "").strip()
            if value:
                return value
        return ""

    fields: dict[str, str] = {}
    session = _get(
        "VIBECRAFTED_WORKER_SESSION",
        "VIBECRAFTED_OPERATOR_SESSION",
        "VC_FRAME_SESSION_NAME",
        "ZELLIJ_SESSION_NAME",
    )
    if session:
        fields["origin_session"] = session
        fields["operator_session"] = session
    # The run's tab is named by run id (spawn contract). A dispatcher's ambient
    # VC_FRAME_TAB_NAME instead names the *operator's* tab — stamping it would
    # hand triage a tab to capture and close that was never the run's. So the
    # tab comes only from the run-id envs, and the ambient tab claim serves one
    # purpose: proving this process sits in the run's own tab, which is the
    # only case where the ambient pane id is the run's pane. (2026-07-25:
    # dispatched runs stamped the operator's pane "1"; the scrollback dump
    # aimed at it found nothing and the tabs never reached their buckets.)
    tab = _get("VIBECRAFTED_RUN_ID", "SPAWN_RUN_ID")
    if session and tab:
        fields["origin_tab"] = tab
    pane = _get("VC_FRAME_PANE_ID", "ZELLIJ_PANE_ID")
    if session and pane and tab and _get("VC_FRAME_TAB_NAME") == tab:
        fields["origin_pane_id"] = pane
    dispatch_fields = {
        "resolved_worktree_path": "VIBECRAFTED_DISPATCH_WORKTREE",
        "branch": "VIBECRAFTED_DISPATCH_BRANCH",
        "baseline_sha": "VIBECRAFTED_DISPATCH_BASELINE_SHA",
        "target_path": "CARGO_TARGET_DIR",
        "artifact_path": "VIBECRAFTED_DISPATCH_ARTIFACT_PATH",
        "dependency_set": "VIBECRAFTED_DISPATCH_DEPENDENCIES",
        "scheduler_slot": "VIBECRAFTED_DISPATCH_SCHEDULER_SLOT",
        "integrator_exclusivity": "VIBECRAFTED_DISPATCH_INTEGRATOR",
        "cut_id": "VIBECRAFTED_DISPATCH_CUT_ID",
    }
    for metadata_field, variable in dispatch_fields.items():
        value = _get(variable)
        if value:
            fields[metadata_field] = value
    return fields


def _accepted_operator_stop(run_id: str, since_cursor: str) -> dict[str, object] | None:
    """Read the durable operator-stop authority after the worker exits."""

    try:
        run = accepted_operator_stop_since(run_id, since_cursor)
    except (OSError, RuntimeError, TypeError, ValueError):
        return None
    return run


def _cache_write_line(prefix: str, value: int | None) -> str:
    """Render a `tokens_cache_write:` frontmatter/footer line, or "" when value is None."""
    return f"{prefix}tokens_cache_write: {value}\n" if value is not None else ""


def _render_fallback_report(handle: AsyncRunHandle, transcript_text: str) -> str:
    """Build a complete salvaged markdown report (frontmatter + body) for a silent worker."""
    body = _fallback_report_body(transcript_text)
    if not body:
        body = (
            "Worker exited successfully without writing a standalone report and "
            "without captured transcript text.\n"
        )
    now = (
        handle.completed_at.isoformat()
        if handle.completed_at
        else _utc_now().isoformat()
    )
    from .report_contract import render_minimal_frontmatter

    skill = handle.skill or str(
        os.environ.get("VIBECRAFTED_SKILL_NAME")
        or os.environ.get("VIBECRAFTED_SKILL_CODE")
        or "unknown"
    )
    telemetry = _run_telemetry(handle)
    header = render_minimal_frontmatter(
        run_id=handle.run_id,
        agent=handle.agent or "unknown",
        skill=skill,
        status="completed",
        extra={
            "claim_status": "completed",
            "claim_kind": skill,
            "session_id": handle.agent_session_id or "unknown",
            **telemetry.usage.flat(),
            "cost_usd": telemetry.cost.flat()["cost_usd"],
            "completed_at": now,
            "fallback_report": "true",
        },
    )
    return (
        header
        + f"{body}\n"
        + "## Runtime fallback\n\n"
        + "The worker exited with code 0 but did not write "
        + "`VIBECRAFTED_REPORT_PATH`; Vibecrafted salvaged this report from the "
        + "captured transcript.\n"
    )


def _terminal_frontmatter(handle: AsyncRunHandle) -> str:
    """Render the launching-state frontmatter block written to stdout when tee_output is on."""
    model_requested = (
        f"model_requested: {handle.model_requested}\n" if handle.model_requested else ""
    )
    return (
        "---\n"
        "runner: vibecrafted\n"
        f"run_id: {handle.run_id}\n"
        f"agent: {handle.agent}\n"
        f"{model_requested}"
        f"root: {handle.root}\n"
        f"report: {handle.report_path or ''}\n"
        f"transcript: {handle.transcript_path or ''}\n"
        "status: launching\n"
        "---\n"
    )


def _terminal_footer(handle: AsyncRunHandle) -> str:
    """Render the terminal-state summary footer written to stdout when tee_output is on."""
    model_requested = (
        f"model_requested: {handle.model_requested}\n" if handle.model_requested else ""
    )
    override_skipped = (
        f"model_override_skipped: {str(handle.model_override_skipped).lower()}\n"
        if handle.model_requested
        else ""
    )
    telemetry = _run_telemetry(handle)
    tokens = telemetry.usage.flat()
    cost = telemetry.cost.flat()
    failure = (
        f"failure: {telemetry.failure.summary()}\n"
        if telemetry.failure is not None
        else ""
    )
    return (
        "\n---\n"
        "runner: vibecrafted\n"
        f"run_id: {handle.run_id}\n"
        f"status: {handle.state.value}\n"
        f"exit_code: {handle.exit_code if handle.exit_code is not None else 'unknown'}\n"
        f"{failure}"
        f"session_id: {handle.agent_session_id or 'unknown'}\n"
        f"model: {handle.agent_model or 'unknown'}\n"
        f"{model_requested}"
        f"{override_skipped}"
        f"tokens_input: {tokens['tokens_input']}\n"
        f"tokens_cached_input: {tokens['tokens_cached_input']}\n"
        f"{_cache_write_line('', handle.tokens_cache_write if telemetry.usage.known else None)}"
        f"tokens_output: {tokens['tokens_output']}\n"
        f"tokens_total: {tokens['tokens_total']}\n"
        f"cost_usd: {cost['cost_usd']}\n"
        f"cost_source: {cost['cost_source']}\n"
        f"resume: {handle.resume_command}\n"
        f"report: {handle.report_path or ''}\n"
        f"transcript: {handle.transcript_path or ''}\n"
        "---\n"
    )


def _write_terminal(text: str) -> None:
    """Write *text* to stdout and flush immediately (used for tee_output)."""
    sys.stdout.write(text)
    sys.stdout.flush()


@dataclass
class AsyncRunHandle:
    """Mutable state of one asynchronously supervised agent run, live or terminal."""

    run_id: str
    command: tuple[str, ...]
    root: Path
    process: asyncio.subprocess.Process
    started_at: datetime
    meta_path: Path | None = None
    report_path: Path | None = None
    transcript_path: Path | None = None
    transcript_identity: dict[str, int] | None = None
    pgid: int | None = None
    states: list[RunState] = field(default_factory=lambda: [RunState.CREATED])
    exit_code: int | None = None
    completed_at: datetime | None = None
    artifact_validation: ArtifactValidation | None = None
    first_output_seen: bool = False
    session_id: str = ""
    launch_session_id: str = ""
    agent: str = ""
    skill: str = ""
    agent_session_id: str = ""
    agent_model: str = ""
    claim_digest: str = ""
    model_requested: str = ""
    model_override_supported: bool = False
    model_override_skipped: bool = False
    model_override_skip_reason: str = ""
    tokens_input: int = 0
    tokens_cached_input: int = 0
    tokens_cache_write: int | None = None
    tokens_output: int = 0
    usage_events: int = 0
    cost_usd: float | None = None
    cost_source: str | None = None
    # Session id the provider stream itself reported (vs. the launch contract's).
    stream_session_id: str = ""
    # Where stream_session_id came from: the stream, or the provider's
    # on-disk session store adopted while the run was live.
    stream_session_source: str = "provider_stream"
    # Parent/fork session ids from meta that the provider id must never equal.
    parent_sessions: dict[str, str] = field(default_factory=dict)
    telemetry: RunTelemetry | None = None
    resume_command: str = ""
    heartbeat_monotonic: float = 0.0
    worker_identity: dict[str, object] | None = None
    workspace_fields: dict[str, object] = field(default_factory=dict)
    operator_stop_cursor: str = "0"
    operator_stopped: bool = False
    operator_stop_reason: str = ""

    @property
    def state(self) -> RunState:
        """Current (most recent) lifecycle state."""
        return self.states[-1]


class AsyncSupervisor:
    """Async orchestrator: spawns one agent process per run, streams and settles it."""

    def __init__(
        self,
        *,
        signal_sink: Callable[[str, str], None] | None = None,
    ) -> None:
        """Initialize an empty run-id -> AsyncRunHandle registry."""
        self._runs: dict[str, AsyncRunHandle] = {}
        self._signal_sink = signal_sink

    def get(self, run_id: str) -> AsyncRunHandle | None:
        """Look up a tracked run handle by id, or None if unknown to this instance."""
        return self._runs.get(run_id)

    async def spawn(
        self,
        *,
        run_id: str,
        command: Sequence[str],
        root: str | Path = ".",
        env: Mapping[str, str] | None = None,
        meta_path: str | Path | None = None,
        report_path: str | Path | None = None,
        transcript_path: str | Path | None = None,
        prompt_file_path: str | Path | None = None,
    ) -> AsyncRunHandle:
        """Start one agent subprocess and register it as a live AsyncRunHandle.

        Materializes the report template, merges the run's identity env vars,
        seeds durable origin metadata into meta.json, and emits the
        CREATED/PROCESS_SPAWNED lifecycle transitions before returning.
        """
        if not command:
            raise ValueError("command must not be empty")
        cwd = Path(normalize_run_root(root))
        transcript = Path(transcript_path) if transcript_path is not None else None
        if transcript is not None:
            transcript.parent.mkdir(parents=True, exist_ok=True)
        prompt_file = Path(prompt_file_path).expanduser() if prompt_file_path else None

        # Parent identity before the caller overlay replaces VIBECRAFTED_AGENT
        # with the worker. The child process must not see the parent bus.
        dispatcher = dispatcher_identity(os.environ)
        merged_env = os.environ.copy()
        if env:
            merged_env.update(env)
        session_id = ensure_session_id(merged_env.get("VIBECRAFTED_SESSION_ID"))
        # Retain the launcher's legacy correlation identity separately. The
        # workspace/runtime identity below is canonical for parent report/meta;
        # an orchestration parent has no provider stream to stamp its shell.
        launch_session_id = session_id if _is_workflow_parent(command) else ""
        merged_env["VIBECRAFTED_SESSION_ID"] = session_id
        workspace_fields: dict[str, object] = {}
        try:
            from .workspace_catalog import resolve_run_workspace_identity

            workspace_identity = resolve_run_workspace_identity(
                root=cwd,
                env=merged_env,
                create_if_missing=True,
            )
            workspace_fields = workspace_identity.to_meta_fields()
            merged_env.update(workspace_identity.to_env())
            session_id = workspace_identity.vibecrafted_session_id
            merged_env["VIBECRAFTED_SESSION_ID"] = session_id
        # Workspace identity projection is advisory to launch; any resolver exception must preserve
        # the existing environment without inventing a session identity or blocking launch.
        except Exception:  # noqa: BLE001, S110
            pass
        merged_env["VIBECRAFTED_RUN_ID"] = run_id
        merged_env["SPAWN_RUN_ID"] = run_id
        if meta_path is not None:
            merged_env["VIBECRAFTED_META_PATH"] = str(meta_path)
        if report_path is not None:
            merged_env["VIBECRAFTED_REPORT_PATH"] = str(report_path)
        if transcript_path is not None:
            merged_env["VIBECRAFTED_TRANSCRIPT_PATH"] = str(transcript_path)
        if prompt_file is not None:
            merged_env["VIBECRAFTED_PROMPT_PATH"] = str(prompt_file)
        agent = str(merged_env.get("VIBECRAFTED_AGENT") or _infer_agent(command))
        initial_agent_session_id = str(
            merged_env.get("VIBECRAFTED_AGENT_SESSION_ID") or ""
        ).strip()
        skill = str(
            merged_env.get("VIBECRAFTED_SKILL_NAME")
            or merged_env.get("VIBECRAFTED_SKILL_CODE")
            or merged_env.get("VIBECRAFTED_SKILL")
            or "unknown"
        )
        claim_digest = str(merged_env.get(CLAIM_DIGEST_ENV) or "").strip()
        # The prompt file stays the human-readable truth (VIBECRAFTED_PROMPT_PATH);
        # what the worker reads on stdin is the provider's private transport —
        # verbatim text for most, one stream-json user turn for agy.
        stdin_source = (
            materialize_stdin_file(agent, prompt_file)
            if prompt_file is not None
            else None
        )
        agent_model = resolve_default_model(agent, command=command, env=merged_env)
        launch_env = filter_headless_worker_env(merged_env)
        model_receipt = _model_override_receipt(
            agent, str(merged_env.get("VIBECRAFTED_MODEL_REQUESTED") or "")
        )
        started_at = _utc_now()
        operator_stop_cursor = event_resume_cursor()
        if report_path is not None:
            from .report_contract import materialize_launcher_report_template

            materialize_launcher_report_template(
                report_path,
                run_id=run_id,
                agent=agent,
                skill=skill,
                claim_digest=claim_digest,
            )
            if launch_session_id:
                from .report_contract import stamp_launcher_report_identity

                stamp_launcher_report_identity(
                    report_path,
                    run_id=run_id,
                    session_id=session_id,
                    agent=agent,
                    skill=skill,
                    status="pending",
                )

        await self._emit(
            run_id,
            RunState.CREATED,
            "async supervisor run created",
            payload={
                "root": str(cwd),
                "command": list(command),
                "meta": str(meta_path or ""),
                "report": str(report_path or ""),
                "transcript": str(transcript_path or ""),
                "prompt_file": str(prompt_file or ""),
                "stdin_transport": stdin_transport(agent),
                "stdin_source": str(stdin_source or ""),
                "started_at": started_at.isoformat(),
                "session_id": session_id,
                "identity_required": True,
                "agent": agent,
                **workspace_fields,
                **(
                    {
                        "agent_session_id": initial_agent_session_id,
                        "runtime_session_id": session_id,
                    }
                    if initial_agent_session_id
                    else {}
                ),
                "skill": skill,
                "agent_model": agent_model,
                **({"claim_digest": claim_digest} if claim_digest else {}),
                **model_receipt,
            },
        )

        stdin_handle = None
        try:
            if stdin_source is not None:
                stdin_handle = stdin_source.open("rb")
            process = await asyncio.create_subprocess_exec(
                *command,
                cwd=str(cwd),
                env=launch_env,
                stdin=stdin_handle,
                stdout=asyncio.subprocess.PIPE,
                stderr=asyncio.subprocess.STDOUT,
                start_new_session=True,
                limit=STDIO_LIMIT_BYTES,
            )
        finally:
            if stdin_handle is not None:
                stdin_handle.close()
        handle = AsyncRunHandle(
            run_id=run_id,
            command=tuple(command),
            root=cwd,
            process=process,
            started_at=started_at,
            meta_path=Path(meta_path) if meta_path is not None else None,
            report_path=Path(report_path) if report_path is not None else None,
            transcript_path=transcript,
            session_id=session_id,
            launch_session_id=launch_session_id,
            agent=agent,
            skill=skill,
            agent_session_id=initial_agent_session_id,
            agent_model=agent_model,
            claim_digest=claim_digest,
            model_requested=str(model_receipt.get("model_requested") or ""),
            model_override_supported=bool(
                model_receipt.get("model_override_supported")
            ),
            model_override_skipped=bool(model_receipt.get("model_override_skipped")),
            model_override_skip_reason=str(
                model_receipt.get("model_override_skip_reason") or ""
            ),
            parent_sessions={
                source: session
                for session, source in parent_session_ids(
                    merged_env,
                    extra={"runtime_session_id": session_id},
                ).items()
            },
            workspace_fields=dict(workspace_fields),
            operator_stop_cursor=operator_stop_cursor,
        )
        try:
            handle.pgid = os.getpgid(process.pid)
        except ProcessLookupError:
            handle.pgid = None
        handle.worker_identity = process_identity_receipt(
            process.pid,
            run_id=run_id,
        )
        self._runs[run_id] = handle
        # Seed durable origin identity as soon as the worker exists so triage
        # still works when the finisher has no ambient VC_FRAME pane env.
        if handle.meta_path is not None:
            try:
                origin = _origin_fields_from_env(merged_env)
                handle.meta_path.parent.mkdir(parents=True, exist_ok=True)

                def _seed(latest: dict[str, object]) -> dict[str, object]:
                    if (
                        origin.get("origin_session")
                        and not str(latest.get("origin_session") or "").strip()
                    ):
                        latest["origin_session"] = origin["origin_session"]
                        latest["operator_session"] = origin.get(
                            "operator_session", origin["origin_session"]
                        )
                    if (
                        origin.get("origin_session")
                        and origin.get("origin_tab")
                        and not str(latest.get("origin_tab") or "").strip()
                    ):
                        latest["origin_tab"] = origin["origin_tab"]
                    if (
                        origin.get("origin_pane_id")
                        and not str(latest.get("origin_pane_id") or "").strip()
                    ):
                        latest["origin_pane_id"] = origin["origin_pane_id"]
                    for field in (
                        "resolved_worktree_path",
                        "branch",
                        "baseline_sha",
                        "target_path",
                        "artifact_path",
                        "dependency_set",
                        "scheduler_slot",
                        "integrator_exclusivity",
                        "cut_id",
                    ):
                        if origin.get(field):
                            latest.setdefault(field, origin[field])
                    latest.setdefault("dispatcher", dict(dispatcher))
                    latest.setdefault("run_id", run_id)
                    if launch_session_id:
                        latest["launch_session_id"] = launch_session_id
                    latest.setdefault("root", str(cwd))
                    latest.setdefault("agent", agent)
                    latest.setdefault("skill", skill)
                    # These are live execution facts. Await/progress and exact
                    # child control need them before terminal summary writing.
                    if handle.report_path is not None:
                        latest["report"] = str(handle.report_path)
                    if handle.transcript_path is not None:
                        latest["transcript"] = str(handle.transcript_path)
                    for field, value in workspace_fields.items():
                        latest.setdefault(field, value)
                    latest["worker_pid"] = handle.process.pid
                    latest["worker_pgid"] = handle.pgid
                    if handle.worker_identity is not None:
                        latest["worker_identity"] = handle.worker_identity
                    if initial_agent_session_id:
                        latest.setdefault("agent_session_id", initial_agent_session_id)
                        latest.setdefault("runtime_session_id", session_id)
                    if claim_digest:
                        latest["claim_digest"] = claim_digest
                    # Persist the operator pin as soon as the worker exists.
                    # Completion summary also writes it, but callers (and
                    # tests) read meta at PROCESS_SPAWNED — before finish.
                    requested = str(model_receipt.get("model_requested") or "").strip()
                    if requested:
                        latest.setdefault("model_requested", requested)
                        if "model_override_supported" in model_receipt:
                            latest.setdefault(
                                "model_override_supported",
                                model_receipt["model_override_supported"],
                            )
                        if "model_override_skipped" in model_receipt:
                            latest.setdefault(
                                "model_override_skipped",
                                model_receipt["model_override_skipped"],
                            )
                        skip_reason = str(
                            model_receipt.get("model_override_skip_reason") or ""
                        ).strip()
                        if skip_reason:
                            latest.setdefault("model_override_skip_reason", skip_reason)
                    return latest

                mutate_run_meta(
                    control_plane_home(),
                    meta_path=handle.meta_path,
                    mutation_root=handle.meta_path.parent,
                    run_id=run_id,
                    mutator=_seed,
                    create=True,
                )
            except (OSError, RunMetaMutationError, TypeError):
                pass
        await self._transition(
            handle,
            RunState.PROCESS_SPAWNED,
            "process spawned",
            payload={
                "worker_pid": handle.process.pid,
                "worker_pgid": handle.pgid,
                **(
                    {"worker_identity": handle.worker_identity}
                    if handle.worker_identity is not None
                    else {}
                ),
                "meta": str(handle.meta_path or ""),
                "report": str(handle.report_path or ""),
                "transcript": str(handle.transcript_path or ""),
            },
        )
        return handle

    async def run(
        self,
        *,
        run_id: str,
        command: Sequence[str],
        root: str | Path = ".",
        env: Mapping[str, str] | None = None,
        meta_path: str | Path | None = None,
        report_path: str | Path | None = None,
        transcript_path: str | Path | None = None,
        prompt_file_path: str | Path | None = None,
        timeout: float | None = None,
        silence_timeout: float | None = None,
        require_report: bool = True,
        require_transcript_output: bool = False,
        tee_output: bool = False,
        salvage_report_from_stream: bool = False,
        on_output: Callable[[bytes], None] | None = None,
    ) -> AsyncRunHandle:
        """Spawn, watch to completion, validate artifacts, and settle a run end to end.

        Honors an accepted operator-stop by skipping completion-report
        manufacturing; otherwise writes a report fallback, meta summary, and
        the terminal lifecycle transition (COMPLETED/FAILED/STALLED).
        """
        try:
            handle = await self.spawn(
                run_id=run_id,
                command=command,
                root=root,
                env=env,
                meta_path=meta_path,
                report_path=report_path,
                transcript_path=transcript_path,
                prompt_file_path=prompt_file_path,
            )
        except asyncio.CancelledError:
            handle = self._runs.get(run_id)
            if handle is not None:
                await self._settle_cancelled(handle)
            raise
        if tee_output:
            _write_terminal(_terminal_frontmatter(handle))
        try:
            if timeout is None:
                await self._watch_process(
                    handle,
                    tee_output=tee_output,
                    silence_timeout=silence_timeout,
                    on_output=on_output,
                )
            else:
                await asyncio.wait_for(
                    self._watch_process(
                        handle,
                        tee_output=tee_output,
                        silence_timeout=silence_timeout,
                        on_output=on_output,
                    ),
                    timeout=timeout,
                )
        except TimeoutError as stall:
            await self._terminate(handle)
            handle.exit_code = handle.process.returncode
            handle.completed_at = _utc_now()
            # Persist terminal truth before waking await. A stall used to return
            # with only spawn metadata, so a dead parent looked perpetually live.
            self._write_meta_summary(handle)
            self._write_terminal_meta(
                handle,
                "timed_out",
                "silence" if isinstance(stall, _SilenceTimeout) else "wall_clock",
            )
            # Both stall kinds settle through this one path; the recorded reason
            # still names which instrument fired, so a triage never has to guess
            # whether the worker ran too long or went mute.
            silent = isinstance(stall, _SilenceTimeout)
            reason = str(stall) if silent else "process timed out"
            await self._transition(
                handle,
                RunState.STALLED,
                f"worker went silent: {reason}" if silent else reason,
                payload={
                    "exit_code": handle.exit_code,
                    "completed_at": handle.completed_at.isoformat(),
                    "liveness": "terminal",
                    "stall_kind": "silence" if silent else "wall_clock",
                },
            )
            return handle
        except asyncio.CancelledError:
            # Nested workflows own separate process groups. Cancellation must
            # reap their children before the outer dispatcher exits.
            await self._settle_cancelled(handle)
            raise

        except OSError as error:
            # A refused/nonregular raw target must not orphan its provider or
            # become an optimistic completion receipt.
            await self._terminate(handle)
            handle.exit_code = handle.process.returncode
            handle.completed_at = _utc_now()
            self._write_meta_summary(handle)
            self._write_terminal_meta(handle, "failed", "transcript_unavailable")
            await self._transition(
                handle,
                RunState.FAILED,
                "raw transcript unavailable",
                payload={"last_error": str(error), "liveness": "terminal"},
            )
            return handle

        handle.exit_code = handle.process.returncode
        if handle.meta_path is not None:
            try:
                fork_meta = json.loads(handle.meta_path.read_text())
            except (OSError, ValueError):
                fork_meta = {}
            if fork_meta.get("native_fork") and (
                not handle.agent_session_id
                or handle.agent_session_id == fork_meta.get("fork_source_session_id")
            ):
                handle.exit_code = 1
            # Add the fork parents; never drop the launch-time parents the
            # live publisher already refused against.
            handle.parent_sessions = {
                **handle.parent_sessions,
                **{
                    key: str(fork_meta[key])
                    for key in ("fork_source_session_id", "parent_provider_session_id")
                    if fork_meta.get(key)
                },
            }
        handle.completed_at = _utc_now()
        operator_stop = await asyncio.to_thread(
            _accepted_operator_stop,
            handle.run_id,
            handle.operator_stop_cursor,
        )
        if operator_stop is not None:
            handle.operator_stopped = True
            handle.operator_stop_reason = str(
                operator_stop.get("stop_reason") or "operator stop request"
            )
            self._write_meta_summary(handle)
            # A deliberately stopped run owes no completion report. Keep an
            # observational artifact receipt for dispatcher callers, but do
            # not manufacture lifecycle:failed/report_missing after the
            # durable stop authority already won.
            handle.artifact_validation = validate_artifacts(
                meta_path=handle.meta_path,
                report_path=handle.report_path,
                transcript_path=handle.transcript_path,
                require_report=False,
                require_transcript_output=False,
            )
            if tee_output:
                _write_terminal(_terminal_footer(handle))
            return handle
        self._write_report_fallback(
            handle,
            salvage_report_from_stream=salvage_report_from_stream,
        )
        self._write_meta_summary(handle)
        if handle.exit_code == 0:
            await self._transition(
                handle,
                RunState.COMPLETED,
                "process completed",
                payload={
                    "exit_code": handle.exit_code,
                    "completed_at": handle.completed_at.isoformat(),
                    "liveness": "terminal",
                },
            )
        else:
            await self._transition(
                handle,
                RunState.FAILED,
                f"process failed with exit code {handle.exit_code}",
                payload={
                    "exit_code": handle.exit_code,
                    "completed_at": handle.completed_at.isoformat(),
                    "liveness": "terminal",
                },
            )

        handle.artifact_validation = validate_artifacts(
            meta_path=handle.meta_path,
            report_path=handle.report_path,
            transcript_path=handle.transcript_path,
            require_report=require_report,
            require_transcript_output=require_transcript_output,
        )
        telemetry = _run_telemetry(handle)
        artifact_payload = {
            "event_kind": EventKind.ARTIFACT.value,
            "meta": str(handle.meta_path or ""),
            "report": str(handle.report_path or ""),
            "transcript": str(handle.transcript_path or ""),
            "agent": handle.agent,
            "agent_session_id": handle.agent_session_id,
            "agent_model": handle.agent_model,
            **telemetry.usage.flat(),
            **telemetry.cost.flat(),
            "resume_command": handle.resume_command,
            **handle.artifact_validation.as_payload(),
        }
        if telemetry.failure is not None:
            artifact_payload["failure"] = telemetry.failure.summary()
        await self._emit(
            handle.run_id,
            RunState.ARTIFACT_SEEN,
            "artifacts inspected",
            payload=artifact_payload,
        )
        if handle.artifact_validation.ok:
            await self._transition(
                handle, RunState.REPORT_VALIDATED, "artifact contract validated"
            )
        else:
            failed_state = (
                RunState.REPORT_MISSING
                if "report_missing" in handle.artifact_validation.errors
                else RunState.REPORT_INVALID
            )
            await self._transition(
                handle,
                failed_state,
                "artifact contract failed",
                payload={
                    **handle.artifact_validation.as_payload(),
                    "liveness": "terminal",
                },
            )
        if tee_output:
            _write_terminal(_terminal_footer(handle))
        return handle

    async def _watch_process(
        self,
        handle: AsyncRunHandle,
        *,
        tee_output: bool = False,
        silence_timeout: float | None = None,
        on_output: Callable[[bytes], None] | None = None,
    ) -> None:
        """Stream stdout lines to the transcript, parse usage, and emit heartbeats.

        Emits a synthetic heartbeat every ``_HEARTBEAT_INTERVAL_SECONDS`` of
        stdout silence so a long tool call is never mistaken for a dead worker,
        and raises ``_SilenceTimeout`` once that silence outlives
        ``silence_timeout`` so an unbroken quiet worker settles as STALLED
        instead of hanging the supervisor forever.
        """
        assert handle.process.stdout is not None
        silence_bound = (
            _default_silence_timeout() if silence_timeout is None else silence_timeout
        )
        last_output_monotonic = time.monotonic()
        parser = AgentStreamParser(handle.agent, default_model=handle.agent_model)
        human_path = transcript_human_path(handle.transcript_path)
        read_task = asyncio.create_task(handle.process.stdout.readline())
        raw_fd: int | None = None
        try:
            if handle.transcript_path is not None:
                raw_fd = os.open(
                    handle.transcript_path,
                    os.O_WRONLY
                    | os.O_APPEND
                    | os.O_CREAT
                    | getattr(os, "O_NOFOLLOW", 0)
                    | getattr(os, "O_NONBLOCK", 0),
                    0o600,
                )
                opened = os.fstat(raw_fd)
                visible = handle.transcript_path.lstat()
                if (
                    not stat.S_ISREG(opened.st_mode)
                    or not stat.S_ISREG(visible.st_mode)
                    or (opened.st_dev, opened.st_ino)
                    != (visible.st_dev, visible.st_ino)
                ):
                    raise OSError("raw transcript is not the opened regular file")
                handle.transcript_identity = {
                    "device": opened.st_dev,
                    "inode": opened.st_ino,
                }
                if handle.meta_path is not None:
                    try:
                        mutate_run_meta(
                            control_plane_home(),
                            meta_path=handle.meta_path,
                            mutation_root=handle.meta_path.parent,
                            run_id=handle.run_id,
                            mutator=lambda latest: {
                                **latest,
                                "transcript_identity": handle.transcript_identity,
                            },
                        )
                    except (OSError, RunMetaMutationError):
                        # Without the writer receipt, await refuses progress.
                        # Observational metadata loss cannot justify following
                        # an unqualified replacement stream.
                        pass
            while True:
                completed, _pending = await asyncio.wait(
                    {read_task},
                    timeout=min(_HEARTBEAT_INTERVAL_SECONDS, silence_bound)
                    if silence_bound > 0
                    else _HEARTBEAT_INTERVAL_SECONDS,
                )
                if not completed:
                    # stdout silence is normal while an agent waits inside a
                    # long build/test/install tool call. Drive liveness from
                    # the process clock so the exact quiet phase still pulses.
                    silent_for = time.monotonic() - last_output_monotonic
                    if silence_bound > 0 and silent_for >= silence_bound:
                        raise _SilenceTimeout(
                            f"no worker output for {silent_for:.0f}s"
                            f" (bound {silence_bound:.0f}s)"
                        )
                    self._adopt_provider_session_identity(handle)
                    if handle.process.returncode is None:
                        handle.heartbeat_monotonic = time.monotonic()
                        await self._emit(
                            handle.run_id,
                            handle.state,
                            "worker heartbeat",
                            payload={
                                "liveness": "pid_alive",
                                "heartbeat_at": _utc_now().isoformat(),
                            },
                        )
                    continue

                chunk = read_task.result()
                if not chunk:
                    break
                last_output_monotonic = time.monotonic()
                if on_output is not None:
                    on_output(chunk)
                read_task = asyncio.create_task(handle.process.stdout.readline())
                if raw_fd is not None:
                    # Retain the same actual writer object for the entire run;
                    # replacing its pathname cannot redirect output elsewhere.
                    pending = memoryview(chunk)
                    while pending:
                        written = os.write(raw_fd, pending)
                        if written <= 0:
                            raise OSError("raw transcript write made no progress")
                        pending = pending[written:]
                display_text = parser.feed_line(chunk)
                if human_path is not None and display_text:
                    with human_path.open("ab") as human:
                        human.write(display_text.encode("utf-8"))
                self._adopt_provider_session_identity(handle)
                previous_agent_session_id = handle.agent_session_id
                previous_stream_session_id = handle.stream_session_id
                self._sync_stream_summary(handle, parser)
                if (
                    handle.stream_session_id
                    and handle.stream_session_id != previous_stream_session_id
                ):
                    self._publish_stream_session_identity(handle)
                if (
                    handle.report_path is not None
                    and handle.agent_session_id
                    and handle.agent_session_id != previous_agent_session_id
                ):
                    from .report_contract import stamp_launcher_report_identity

                    stamp_launcher_report_identity(
                        handle.report_path,
                        run_id=handle.run_id,
                        session_id=handle.agent_session_id,
                        agent=handle.agent,
                        skill=handle.skill,
                        status="pending",
                        model=handle.agent_model,
                        claim_digest=handle.claim_digest,
                    )
                if tee_output and display_text:
                    sys.stdout.buffer.write(display_text.encode("utf-8"))
                    sys.stdout.buffer.flush()
                # Socket heartbeats are ephemeral flow-control signals, not
                # durable lifecycle events. Pulse on every output line so a
                # busy worker proves movement without inflating events.jsonl.
                if self._signal_sink is not None:
                    try:
                        self._signal_sink(handle.run_id, handle.state.value)
                    except (OSError, RuntimeError):
                        pass
                if not handle.first_output_seen:
                    handle.first_output_seen = True
                    handle.heartbeat_monotonic = time.monotonic()
                    await self._transition(
                        handle,
                        RunState.FIRST_OUTPUT_SEEN,
                        "first output observed",
                        payload={
                            "heartbeat_at": _utc_now().isoformat(),
                        },
                    )
                    await self._transition(
                        handle,
                        RunState.ACTIVE,
                        "process active",
                        payload={
                            "liveness": "pid_alive",
                            "heartbeat_at": _utc_now().isoformat(),
                        },
                    )
                    continue
                # Output movement is also a heartbeat, but use `_emit` rather
                # than `_transition`: a pulse must not mutate state history.
                now_monotonic = time.monotonic()
                if (
                    now_monotonic - handle.heartbeat_monotonic
                    >= _HEARTBEAT_INTERVAL_SECONDS
                ):
                    handle.heartbeat_monotonic = now_monotonic
                    await self._emit(
                        handle.run_id,
                        RunState.ACTIVE,
                        "worker heartbeat",
                        payload={
                            "liveness": "pid_alive",
                            "heartbeat_at": _utc_now().isoformat(),
                        },
                    )
            await handle.process.wait()
        finally:
            if not read_task.done():
                read_task.cancel()
                try:
                    await read_task
                except asyncio.CancelledError:
                    pass
            if raw_fd is not None:
                os.close(raw_fd)
        self._sync_stream_summary(handle, parser)

    def _write_report_fallback(
        self,
        handle: AsyncRunHandle,
        *,
        salvage_report_from_stream: bool = False,
    ) -> None:
        """Ensure the report file exists and carries stamped launcher identity.

        Salvages a report from the transcript when missing (grok, or when
        opted in), and re-renders any launcher-template placeholder report
        left behind by a worker that never overwrote it.
        """
        report = handle.report_path
        if report is None:
            return
        if not report.exists():
            if handle.exit_code != 0 or (
                handle.agent != "grok" and not salvage_report_from_stream
            ):
                return
            transcript_text = ""
            if handle.transcript_path is not None and handle.transcript_path.exists():
                try:
                    transcript_text = handle.transcript_path.read_text(
                        encoding="utf-8", errors="replace"
                    )
                except OSError:
                    transcript_text = ""
            rendered = _render_fallback_report(handle, transcript_text)
            report.parent.mkdir(parents=True, exist_ok=True)
            report.write_text(rendered, encoding="utf-8")
            return

        # Reports are worker-authored evidence, but the runtime owns their
        # transport contract. Normalize an existing substantive report before
        # strict validation so a good handoff cannot become report_invalid only
        # because the worker omitted the dashboard frontmatter. Preserve the
        # body and any explicit claim (blocked/partial/failed) verbatim.
        try:
            if report.stat().st_size == 0:
                return
            text = report.read_text(encoding="utf-8", errors="replace")
        except OSError:
            return
        from .report_contract import (
            parse_report_text,
            stamp_launcher_report_identity,
            worker_authored_report,
        )

        fields, body, has_frontmatter = parse_report_text(text)
        # `launcher_template` is a PRESERVED machine key: the worker contract
        # tells workers to keep seeded frontmatter, so its presence is not
        # evidence that the worker stayed silent. Only substance decides —
        # otherwise a fully authored report gets replaced by a transcript
        # salvage (observed: a complete review report destroyed on resume).
        if (
            handle.exit_code == 0
            and (handle.agent == "grok" or salvage_report_from_stream)
            and has_frontmatter
            and fields.get("launcher_template", "").strip().lower()
            in {"1", "true", "yes", "on"}
            and not worker_authored_report(fields, body)
        ):
            transcript_text = ""
            if handle.transcript_path is not None and handle.transcript_path.exists():
                try:
                    transcript_text = handle.transcript_path.read_text(
                        encoding="utf-8", errors="replace"
                    )
                except OSError:
                    transcript_text = ""
            report.write_text(
                _render_fallback_report(handle, transcript_text),
                encoding="utf-8",
            )

        status = "completed" if handle.exit_code == 0 else "failed"
        telemetry = _run_telemetry(handle)
        runtime_fields = telemetry.frontmatter_fields()
        if telemetry.usage.source == "children_sum" and not telemetry.usage.known:
            runtime_fields["usage_reason"] = telemetry.usage.tokens_input.reason
        stamp_launcher_report_identity(
            report,
            run_id=handle.run_id,
            session_id=handle.session_id
            if handle.launch_session_id
            else handle.agent_session_id,
            agent=handle.agent or "unknown",
            skill=handle.skill or "unknown",
            status=status,
            model=telemetry.model,
            claim_digest=handle.claim_digest,
            runtime_fields=runtime_fields,
        )

    def _sync_stream_summary(
        self, handle: AsyncRunHandle, parser: AgentStreamParser
    ) -> None:
        """Copy the parser's latest session/model/token/cost readings onto the handle."""
        if parser.session_id:
            handle.agent_session_id = parser.session_id
            handle.stream_session_id = parser.session_id
        handle.agent_model = parser.model_id
        handle.tokens_input = parser.tokens_input
        handle.tokens_cached_input = parser.tokens_cached_input
        handle.tokens_cache_write = parser.tokens_cache_write
        handle.tokens_output = parser.tokens_output
        handle.usage_events = parser.usage_events
        handle.cost_usd = parser.cost_usd
        handle.cost_source = parser.cost_source
        handle.resume_command = _with_adopted_session(
            handle, parser.resume_command(handle.root)
        )

    def _adopt_provider_session_identity(self, handle: AsyncRunHandle) -> None:
        """Adopt a session id the provider revealed on disk before its stream does.

        kimi's stream only carries the session id in the trailing
        ``session.resume_hint`` event, so a run killed before settlement
        historically froze meta.json with ``provider_session_id: None`` and
        ``vibecrafted resume`` was impossible. The provider's session store
        pins the id at spawn; adopt it into the live meta.json as soon as it
        appears (observed 2026-09-30: run impl-260930-210226-46946 timed out
        with ``session_0c31a2fe`` on disk from second one, meta id None).
        """
        if handle.stream_session_id:
            return
        discovered = ""
        if handle.agent == "kimi":
            discovered = kimi_session_id_from_store(
                handle.root,
                handle.started_at,
                home=_provider_store_home(),
            )
        if not discovered:
            return
        handle.stream_session_id = discovered
        handle.stream_session_source = "provider_session_store"
        # The store hit is a candidate until it clears the same parent/runtime/
        # fork refusal as stream identities. Only then does it become the
        # handle's native identity; a declared launch-contract session wins.
        validated = self._validated_stream_session_id(handle, _read_meta(handle))
        if validated and not handle.agent_session_id:
            handle.agent_session_id = validated
            handle.resume_command = _with_adopted_session(handle, handle.resume_command)
        self._publish_stream_session_identity(handle)

    def _validated_stream_session_id(
        self, handle: AsyncRunHandle, payload: Mapping[str, object]
    ) -> str:
        """The stream/store candidate when no launch/runtime/fork parent owns it."""
        parent_fields = dict(handle.parent_sessions)
        for key in (
            "runtime_session_id",
            "vibecrafted_session_id",
            "parent_provider_session_id",
            "fork_source_session_id",
        ):
            value = str(payload.get(key) or "").strip()
            if value:
                parent_fields.setdefault(key, value)
        resolved, _source = resolve_provider_session_id(
            handle.stream_session_id,
            source=handle.stream_session_source,
            parents=parent_session_ids({}, extra=parent_fields),
        )
        return resolved if isinstance(resolved, str) else ""

    def _publish_stream_session_identity(self, handle: AsyncRunHandle) -> None:
        """Publish a provider-reported child identity while its run is live.

        The stream parser is the first canonical owner to observe this value.
        Merge it under the shared run lock so routing readers never need to
        recover identity from a transcript or race a terminal summary. A value
        equal to any launch/runtime/fork parent is refused rather than guessed.
        """
        if handle.meta_path is None or not handle.stream_session_id.strip():
            return

        def _enrich(payload: dict[str, object]) -> dict[str, object] | None:
            resolved = self._validated_stream_session_id(handle, payload)
            if not resolved:
                return None
            payload.update(
                {
                    "session_id": resolved,
                    "agent_session_id": resolved,
                    "provider_session_id": resolved,
                    "provider_session_source": handle.stream_session_source,
                }
            )
            return payload

        try:
            mutate_run_meta(
                control_plane_home(),
                meta_path=handle.meta_path,
                mutation_root=handle.meta_path.parent,
                run_id=handle.run_id,
                mutator=_enrich,
            )
        except (OSError, RunMetaMutationError, TypeError):
            # Durable metadata is observational: losing it must not terminate
            # an otherwise healthy provider process. Terminal settlement gets
            # one final merge attempt through `_write_meta_summary`.
            pass

    def _write_meta_summary(self, handle: AsyncRunHandle) -> None:
        """Merge a full run-state summary (status, usage, cost, failure, origin) into meta.json."""
        if handle.meta_path is None:
            return
        telemetry = _run_telemetry(handle)
        summary = {
            "run_id": handle.run_id,
            "agent": handle.agent,
            "session_id": handle.session_id
            if handle.launch_session_id
            else handle.agent_session_id,
            **(
                {"launch_session_id": handle.launch_session_id}
                if handle.launch_session_id
                else {}
            ),
            "agent_session_id": handle.agent_session_id,
            "agent_model": handle.agent_model,
            "runtime_session_id": handle.session_id,
            "root": str(handle.root),
            "report": str(handle.report_path or ""),
            "transcript": str(handle.transcript_path or ""),
            **(
                {"transcript_identity": handle.transcript_identity}
                if handle.transcript_identity is not None
                else {}
            ),
            **telemetry.meta_fields(),
            "resume_command": handle.resume_command,
            "exit_code": handle.exit_code,
            "started_at": handle.started_at.isoformat(),
            "completed_at": handle.completed_at.isoformat()
            if handle.completed_at
            else "",
            "status": (
                "stopped"
                if handle.operator_stopped
                else (
                    "completed"
                    if handle.exit_code == 0
                    else ("failed" if handle.exit_code is not None else "running")
                )
            ),
            "worker_pid": handle.process.pid,
            "worker_pgid": handle.pgid,
        }
        if handle.worker_identity is not None:
            summary["worker_identity"] = handle.worker_identity
        if handle.operator_stopped:
            summary["operator_stop_accepted"] = True
            summary["stop_reason"] = handle.operator_stop_reason
            summary["recovery_required"] = False
        # Stamp origin for triage-run: dispatcher finishes outside the worker
        # pane, so ambient VC_FRAME_* is often empty at triage time. Prefer
        # values already in meta (launch path) over live env.
        origin = _origin_fields_from_env()
        if handle.model_requested:
            summary["model_requested"] = handle.model_requested
            summary["model_override_supported"] = handle.model_override_supported
            summary["model_override_skipped"] = handle.model_override_skipped
            if handle.model_override_skip_reason:
                summary["model_override_skip_reason"] = (
                    handle.model_override_skip_reason
                )
        handle.meta_path.parent.mkdir(parents=True, exist_ok=True)

        def _merge_summary(payload: dict[str, object]) -> dict[str, object]:
            """Merge the computed summary onto the mutator's current meta payload."""
            if isinstance(payload.get("reception"), dict) and payload.get("status") in {
                "completed",
                "blocked",
                "failed",
            }:
                # The parent workflow owns its semantic result. Artifact
                # validation and process exit are independent axes below.
                summary["status"] = payload["status"]
            if not str(payload.get("origin_session") or "").strip() and origin.get(
                "origin_session"
            ):
                summary["origin_session"] = origin["origin_session"]
                summary["operator_session"] = origin.get(
                    "operator_session", origin["origin_session"]
                )
            if (
                origin.get("origin_session")
                and origin.get("origin_tab")
                and not str(payload.get("origin_tab") or "").strip()
            ):
                summary["origin_tab"] = origin["origin_tab"]
            if (
                origin.get("origin_pane_id")
                and not str(payload.get("origin_pane_id") or "").strip()
            ):
                summary["origin_pane_id"] = origin["origin_pane_id"]
            # Keys this close does not assert must not survive from an earlier
            # close: a stale cache-write count or a previous run's failure.
            for stale in ("tokens_cache_write", "failure"):
                if stale not in summary:
                    payload.pop(stale, None)
            payload.update(summary)
            return payload

        mutate_run_meta(
            control_plane_home(),
            meta_path=handle.meta_path,
            mutation_root=handle.meta_path.parent,
            run_id=handle.run_id,
            mutator=_merge_summary,
            create=True,
        )

    async def _settle_cancelled(self, handle: AsyncRunHandle) -> None:
        await self._terminate(handle)
        handle.exit_code = handle.process.returncode
        handle.completed_at = _utc_now()
        self._write_meta_summary(handle)
        self._write_terminal_meta(handle, "failed", "supervisor_cancelled")
        await self._transition(
            handle,
            RunState.FAILED,
            "supervisor cancelled",
            payload={"exit_code": handle.exit_code, "liveness": "terminal"},
        )

    def _write_terminal_meta(
        self, handle: AsyncRunHandle, status: str, reason: str
    ) -> None:
        if handle.meta_path is None:
            return

        def settle(payload: dict[str, object]) -> dict[str, object]:
            payload.update(
                status=status,
                state=status,
                liveness="terminal",
                terminal_reason=reason,
                exit_code=handle.exit_code,
                completed_at=handle.completed_at.isoformat()
                if handle.completed_at
                else "",
            )
            return payload

        mutate_run_meta(
            control_plane_home(),
            meta_path=handle.meta_path,
            mutation_root=handle.meta_path.parent,
            run_id=handle.run_id,
            mutator=settle,
            create=True,
        )

    async def _terminate(self, handle: AsyncRunHandle) -> None:
        """SIGTERM the owned group, allowing up to 5s for nested cleanup, then reap it."""
        if handle.process.returncode is not None and handle.pgid is None:
            return
        try:
            if handle.pgid is not None:
                os.killpg(handle.pgid, signal.SIGTERM)
            else:
                handle.process.terminate()
        except ProcessLookupError:
            return
        try:
            await asyncio.wait_for(handle.process.wait(), timeout=5)
        except TimeoutError:
            try:
                if handle.pgid is not None:
                    os.killpg(handle.pgid, signal.SIGKILL)
                else:
                    handle.process.kill()
            except ProcessLookupError:
                pass
            await handle.process.wait()
        # An exited group leader does not imply its pipe-holding descendants
        # exited. Reap the owned remainder, including children ignoring TERM.
        if handle.pgid is not None:
            try:
                os.killpg(handle.pgid, signal.SIGKILL)
            except ProcessLookupError:
                pass

    async def _transition(
        self,
        handle: AsyncRunHandle,
        state: RunState,
        message: str,
        *,
        payload: dict[str, object] | None = None,
    ) -> None:
        """Append *state* to the handle's history and emit the corresponding event."""
        handle.states.append(state)
        event_payload: dict[str, object] = {
            "root": str(handle.root),
            "session_id": handle.session_id,
            "identity_required": True,
        }
        if payload:
            event_payload.update(payload)
        await self._emit(handle.run_id, state, message, payload=event_payload)

    async def _emit(
        self,
        run_id: str,
        state: RunState,
        message: str,
        *,
        payload: dict[str, object] | None = None,
    ) -> None:
        """Persist one lifecycle event to the durable event stream (off-thread)."""
        event_payload: dict[str, object] = {
            "event_kind": EventKind.LIFECYCLE.value,
            "state": state.value,
        }
        handle = self._runs.get(run_id)
        if handle is not None:
            event_payload.update(handle.workspace_fields)
        if payload:
            event_payload.update(payload)
        await asyncio.to_thread(
            append_event,
            kind=f"{EventKind.LIFECYCLE.value}:{state.value}",
            run_id=run_id,
            message=message,
            payload=event_payload,
        )
        if self._signal_sink is not None:
            try:
                self._signal_sink(run_id, state.value)
            except (OSError, RuntimeError):
                # Durable files own truth. A broken wake transport must never
                # corrupt or abort the supervised lifecycle.
                pass
