"""Provider continuity capability registry — the ONE declarative authority.

Continuity Kernel spec §7 (Provider capability contract): provider behavior
must be represented once and consumed everywhere. This module is that single
representation. Every later continuity surface (kernel resolver, deck, MCP,
TUI) imports THIS table; no other module may declare provider resume/fork
capability.

Two truth layers live here, deliberately separated:

* the **declarative table** (:data:`CAPABILITIES`) — current core truth
  (``spawn._stdin_command`` / ``workflow_runtime._resume_stdin_command``) merged with the
  operator-verified installed-CLI evidence (AICX 2026-07-12/13, host probes
  2026-07-18); a claim the runtime has not proven headless stays
  ``unverified``, never optimistically ``supported``;
* the **installed-CLI probe** (:func:`probe`) — live evidence from the binary
  actually on this host. Spec §7 rule 6: a probe failure makes autonomous
  recovery unavailable — it does NOT prove the provider incapable, so
  ``probe_failed`` is its own state, distinct from ``unsupported``.

Gemini is present as ``evidence_only``: deprecated sessions may contribute
historical evidence, but nothing may ever select or execute the gemini binary
(spec §7 rule 4).
"""

from __future__ import annotations

import os
import re
import shutil
import subprocess
from collections.abc import Callable, Mapping, Sequence
from dataclasses import dataclass, field, fields
from pathlib import Path
from typing import Any

from ..capabilities import ProbeResult as CliProbe
from ..clock import utc_now_iso
from ..runtime_paths import agent_tool_search_path

# Capability verdicts for the declarative table. ``unverified`` means the
# surface exists in the installed CLI but the runtime has not proven the
# headless contract — fail-closed until a later cut upgrades it with evidence.
SUPPORTED = "supported"
UNSUPPORTED = "unsupported"
UNVERIFIED = "unverified"
# Retained capability value for providers restricted to terminal execution.
TERMINAL_ONLY = "terminal_only"

# Execution classes. ``evidence_only`` providers contribute historical session
# evidence but must never be selected as an execution binary.
EXECUTABLE = "executable"
EVIDENCE_ONLY = "evidence_only"

# Probe states. ``probe_failed`` (binary missing/broken/timeout) is NOT
# ``unsupported`` (binary runs but the declared contract markers are absent).
PROBE_CONFIRMED = "confirmed"
PROBE_UNSUPPORTED = "unsupported"
PROBE_FAILED = "probe_failed"
PROBE_EVIDENCE_ONLY = "evidence_only"

Runner = Callable[[Sequence[str]], CliProbe]


@dataclass(frozen=True)
class ProbeRecipe:
    """How to interrogate one installed provider CLI, read-only."""

    cli: str
    version_args: tuple[str, ...] = ("--version",)
    help_args: tuple[str, ...] = ("--help",)
    # Literal tokens that must appear on the installed CLI help surface for
    # the declared continuity contract to be considered present.
    required_markers: tuple[str, ...] = ()


@dataclass(frozen=True)
class ProviderCapability:
    """Spec §7 record for one provider. Frozen: the table is data, not state."""

    agent: str
    execution: str  # EXECUTABLE | EVIDENCE_ONLY
    session_id_shape: str
    session_id_sources: tuple[str, ...]
    interactive_resume: str
    noninteractive_resume: str
    native_fork: str  # SUPPORTED | TERMINAL_ONLY | UNSUPPORTED
    fork_runtime_restrictions: str
    prompt_transport: str  # "stdin" | "file" | "flag_value" | "none"
    session_identity_event: str
    cwd_safety: str
    resume_preserves_cache: bool | None  # None = unknown/not established
    forbidden_flags: tuple[str, ...]
    probe_recipe: ProbeRecipe | None
    notes: str = ""

    def to_dict(self) -> dict[str, Any]:
        """Flatten this record to a JSON-serializable dict (tuples/nested recipe unpacked)."""
        payload: dict[str, Any] = {}
        for item in fields(self):
            value = getattr(self, item.name)
            if isinstance(value, ProbeRecipe):
                payload[item.name] = {
                    "cli": value.cli,
                    "version_args": list(value.version_args),
                    "help_args": list(value.help_args),
                    "required_markers": list(value.required_markers),
                }
            elif isinstance(value, tuple):
                payload[item.name] = list(value)
            else:
                payload[item.name] = value
        return payload


# The session-id token shape every dispatch surface already extracts
# (spawn.SESSION_PATTERNS / agent_dispatch._SESSION_PATTERNS).
_SESSION_TOKEN = "[A-Za-z0-9][A-Za-z0-9-]* (UUID in practice)"

CAPABILITIES: Mapping[str, ProviderCapability] = {
    "claude": ProviderCapability(
        agent="claude",
        execution=EXECUTABLE,
        session_id_shape=_SESSION_TOKEN,
        session_id_sources=(
            "stream_json_init_event",
            "transcript_session_line",
            "run_meta",
        ),
        interactive_resume=SUPPORTED,
        noninteractive_resume=SUPPORTED,
        native_fork=SUPPORTED,
        fork_runtime_restrictions=(
            "none — `--fork-session` composes with `-p --resume <id>` headless"
        ),
        prompt_transport="stdin",
        session_identity_event=(
            "stream-json `system`/`init` event carrying `session_id`"
        ),
        cwd_safety="runs in invocation cwd; no checkout-mutating flags",
        resume_preserves_cache=True,
        forbidden_flags=(),
        probe_recipe=ProbeRecipe(
            cli="claude",
            required_markers=("--resume", "--fork-session", "--print"),
        ),
        notes="claude 2.1.214 verified on host 2026-07-18",
    ),
    "codex": ProviderCapability(
        agent="codex",
        execution=EXECUTABLE,
        session_id_shape=_SESSION_TOKEN,
        session_id_sources=(
            "exec_json_thread_started_event",
            "transcript_session_line",
            "run_meta",
        ),
        interactive_resume=SUPPORTED,
        noninteractive_resume=SUPPORTED,
        native_fork=SUPPORTED,
        fork_runtime_restrictions=(
            "interactive `fork`; noninteractive `exec fork <id> -`; exec help is checked at admission"
        ),
        prompt_transport="stdin",
        session_identity_event=(
            "`codex exec --json` JSONL `thread.started` event (thread id)"
        ),
        cwd_safety="runs in invocation cwd; no checkout-mutating flags",
        resume_preserves_cache=True,
        forbidden_flags=(),
        probe_recipe=ProbeRecipe(
            cli="codex",
            required_markers=("exec", "resume"),
        ),
        notes="Installed help 2026-09-09 advertises exec fork; live-source concurrency requires separate acceptance",
    ),
    "copilot": ProviderCapability(
        agent="copilot",
        execution=EXECUTABLE,
        session_id_shape=_SESSION_TOKEN,
        session_id_sources=("jsonl_result", "run_meta"),
        interactive_resume=SUPPORTED,
        noninteractive_resume=SUPPORTED,
        native_fork=UNSUPPORTED,
        fork_runtime_restrictions="Copilot CLI exposes resume, but no native fork command",
        prompt_transport="stdin",
        session_identity_event="prompt-mode JSONL result.sessionId (top level)",
        cwd_safety="runs in invocation cwd; -C changes cwd and is not used by this adapter",
        resume_preserves_cache=None,
        forbidden_flags=("--worktree",),
        probe_recipe=ProbeRecipe(
            cli="copilot",
            required_markers=("--resume", "--session-id", "--output-format"),
        ),
        notes="GitHub Copilot CLI 1.0.89-7 prompt-mode and native --resume with piped stdin probed 2026-09-29; result.sessionId remained stable",
    ),
    "omp": ProviderCapability(
        agent="omp",
        execution=EXECUTABLE,
        session_id_shape=_SESSION_TOKEN,
        session_id_sources=("jsonl_session_event", "run_meta"),
        interactive_resume=SUPPORTED,
        noninteractive_resume=SUPPORTED,
        native_fork=UNSUPPORTED,
        fork_runtime_restrictions="omp exposes --resume but no native fork command",
        prompt_transport="stdin",
        session_identity_event=(
            "`omp -p --mode json` NDJSON leading `session` event (`id`)"
        ),
        cwd_safety="runs in invocation cwd; --cwd exists and the adapter does not use it",
        resume_preserves_cache=None,
        forbidden_flags=(),
        probe_recipe=ProbeRecipe(
            cli="omp",
            required_markers=("--resume", "--mode", "--approval-mode"),
        ),
        notes=(
            "omp is an interactive TUI client (`omp [flags] <prompt>`) with "
            "native interactive resume (`omp --resume <id> <prompt>`) and a "
            "headless JSON stream lane (`omp -p --mode json`). "
            "omp 18.11.0 probed 2026-10-15: stdin prompt lane (`echo … | omp -p` "
            "rc 0), --mode json NDJSON with a leading session event, "
            "--approval-mode/--tools combine with -p (rc 0), and an approval "
            "prompt in print mode fails closed with a model-visible refusal "
            "(no hang). No native fork surface found in --help"
        ),
    ),
    "gemini": ProviderCapability(
        agent="gemini",
        execution=EVIDENCE_ONLY,
        session_id_shape=_SESSION_TOKEN,
        session_id_sources=("legacy_artifacts",),
        interactive_resume=UNSUPPORTED,
        noninteractive_resume=UNSUPPORTED,
        native_fork=UNSUPPORTED,
        fork_runtime_restrictions="never executable",
        prompt_transport="none",
        session_identity_event="none — historical artifacts only",
        cwd_safety="not applicable — binary must never launch",
        resume_preserves_cache=None,
        forbidden_flags=(),
        probe_recipe=None,
        notes=(
            "spec §7 rule 4: deprecated gemini sessions may contribute "
            "historical evidence but may never select the gemini binary; "
            "agy is the execution replacement"
        ),
    ),
    "agy": ProviderCapability(
        agent="agy",
        execution=EXECUTABLE,
        session_id_shape=_SESSION_TOKEN,
        session_id_sources=(
            "stream_json_init_event",
            "transcript_session_line",
            "run_meta",
        ),
        interactive_resume=SUPPORTED,
        noninteractive_resume=SUPPORTED,
        native_fork=UNSUPPORTED,
        fork_runtime_restrictions=(
            "no native fork flag on agy 1.2.1 help; do not present resume as a fork"
        ),
        prompt_transport="stdin",
        session_identity_event=(
            "stream-json `init`/`result` events carrying `conversation_id`"
        ),
        cwd_safety=("workspace pinned via `--add-dir .`; no checkout-mutating flags"),
        resume_preserves_cache=None,
        forbidden_flags=(),
        probe_recipe=ProbeRecipe(
            cli="agy",
            required_markers=("--continue", "--conversation", "--print"),
        ),
        notes=(
            "agy 1.2.1 probed 2026-09-11 on gemini-3.8-flash-high: "
            "`--conversation <id> --print= --input-format stream-json "
            "--output-format stream-json` continues the same conversation_id "
            "and preserves prior-turn context. `--print <prompt>` also composes "
            "with `--conversation` (ARG_MAX; not the supervised lane). "
            "Native fork remains unsupported — no `--fork-session` equivalent. "
            "Interactive `-c/--continue` is most-recent, not exact-id."
        ),
    ),
    "junie": ProviderCapability(
        agent="junie",
        execution=EXECUTABLE,
        session_id_shape=_SESSION_TOKEN,
        session_id_sources=("json_stream_receipt", "run_meta"),
        interactive_resume=SUPPORTED,
        noninteractive_resume=UNVERIFIED,
        native_fork=UNSUPPORTED,
        fork_runtime_restrictions="no verified native fork adapter; top-level help is not exhaustive",
        prompt_transport="stdin",
        session_identity_event=(
            "`--output-format json-stream` telemetry receipt (session id)"
        ),
        cwd_safety=("project pinned via `--project .`; no checkout-mutating flags"),
        resume_preserves_cache=None,
        forbidden_flags=(),
        probe_recipe=ProbeRecipe(
            cli="junie",
            required_markers=("--resume", "--session-id"),
        ),
        notes=(
            "junie 26.7.13 verified on host 2026-07-18: `--resume` + "
            "`--session-id <id>` follow up a previous session; operator- "
            "verified 2026-07-12/13 that this opens an INTERACTIVE session. "
            "The headless resume combination (with `--input-format text "
            "--output-format json-stream`) is the F06 contract still to be "
            "proven — core spawn fails closed today"
        ),
    ),
    "grok": ProviderCapability(
        agent="grok",
        execution=EXECUTABLE,
        session_id_shape="UUID (grok `--session-id` requires a valid UUID)",
        session_id_sources=(
            "streaming_json_events",
            "transcript_session_line",
            "run_meta",
        ),
        interactive_resume=SUPPORTED,
        noninteractive_resume=SUPPORTED,
        native_fork=SUPPORTED,
        fork_runtime_restrictions=(
            "`--fork-session` composes with `--resume` headless; "
            "`--session-id` only names the forked session, never resumes"
        ),
        prompt_transport="file",
        session_identity_event=("`--output-format streaming-json` session events"),
        cwd_safety=(
            "cwd pinned via `--cwd .`; recovery must never restore code or "
            "leave the shared checkout"
        ),
        resume_preserves_cache=True,
        forbidden_flags=("--restore-code", "--worktree"),
        probe_recipe=ProbeRecipe(
            cli="grok",
            required_markers=("--resume", "--fork-session", "--prompt-file"),
        ),
        notes=(
            "grok 0.2.102 verified on host 2026-07-18. spec §7 rule 3: "
            "`--restore-code` checks out the original session's commit "
            "(checkout mutation) and `--worktree` moves execution out of the "
            "shared Living Tree — both forbidden for recovery"
        ),
    ),
    "kimi": ProviderCapability(
        agent="kimi",
        execution=EXECUTABLE,
        session_id_shape="session_<UUID> (kimi 2.x ids carry the session_ prefix)",
        session_id_sources=(
            "stream_json_resume_hint_event",
            "session_list_command",
            "run_meta",
        ),
        interactive_resume=SUPPORTED,
        noninteractive_resume=UNVERIFIED,
        native_fork=SUPPORTED,
        fork_runtime_restrictions=(
            "`kimi fork [sessionId] -y` forks headless and exits with the new "
            "session id (probed 2026-09-27); driving the fork headless still "
            "needs the `-p` argv prompt lane — kimi print mode has no stdin"
        ),
        prompt_transport="flag_value",
        session_identity_event=(
            "stream-json `session.resume_hint` meta event carrying "
            "`session_id` (with the `session_` prefix)"
        ),
        cwd_safety=(
            "runs in invocation cwd; `--add-dir` is additive only; no "
            "checkout-mutating flags"
        ),
        resume_preserves_cache=None,
        forbidden_flags=(),
        probe_recipe=ProbeRecipe(
            cli="kimi",
            required_markers=("--session", "--continue", "--prompt", "fork"),
        ),
        notes=(
            "kimi 2.1.1 probed 2026-09-27 on this host: `-S/--session [id]` "
            "(alias `-r`, emitted by the CLI's own resume_hint) resumes "
            "interactively; `-S <id> -p <prompt> --output-format stream-json` "
            "resumes headless with context preserved (PROBE1 recall, identical "
            "session_id echoed). `kimi fork <id> -y` forks non-interactively "
            "and exits 0 with the new id. The supervised runtime lane still "
            "cannot host kimi resume: print mode has no stdin prompt lane "
            "(`-p` takes the prompt as its argv value, ps-visible and "
            "ARG_MAX-bound — see spawn.py's kimi builder), while "
            "native_resume_argv builds stdin-transport argv. Stays UNVERIFIED "
            "until an argv-prompt resume transport lands."
        ),
    ),
    "cursor": ProviderCapability(
        agent="cursor",
        execution=EXECUTABLE,
        session_id_shape=_SESSION_TOKEN,
        session_id_sources=(
            "stream_json_init_event",
            "transcript_session_line",
            "run_meta",
        ),
        interactive_resume=SUPPORTED,
        noninteractive_resume=UNVERIFIED,
        native_fork=UNSUPPORTED,
        fork_runtime_restrictions="no verified native fork adapter; top-level help is not exhaustive",
        prompt_transport="stdin",
        session_identity_event=(
            "stream-json `system`/`init` event carrying `session_id`"
        ),
        cwd_safety=(
            "runs in invocation cwd; `--workspace` overrides; no "
            "checkout-mutating flags"
        ),
        resume_preserves_cache=None,
        forbidden_flags=("--best-of-n",),
        probe_recipe=ProbeRecipe(
            cli="cursor-agent",
            required_markers=("--resume", "--print", "--output-format"),
        ),
        notes=(
            "cursor-agent 2026.08.25-3e8eec8 probed on host 2026-08-29: "
            "agent key is `cursor`, binary is `cursor-agent`; `-p` accepts "
            "prompt on argv or stdin; `--output-format stream-json` emits "
            "claude-shaped init/assistant/result events. Interactive "
            "`--resume [chatId]` exists; headless `-p --resume <id>` is "
            "UNVERIFIED — core native resume fails closed until proven. "
            "`--best-of-n` is not a cursor-agent flag — never invent it. "
            "Permission flags (`--force`, `--trust`, `--mode`) are required "
            "semantics from the spawn contract and must be present on the "
            "selected binary; missing required flags fail closed (no silent "
            "downgrade)."
        ),
    ),
}

# Flags the launch path may need to verify against the selected cursor-agent
# --help surface. Presence is evidence; absence of a *required* contract flag
# is a hard refusal, never a silent drop.
CURSOR_TRACKED_FLAGS: tuple[str, ...] = (
    "--print",
    "--output-format",
    "--force",
    "--trust",
    "--yolo",
    "--mode",
    "--sandbox",
    "--resume",
    "--workspace",
    "--best-of-n",
)


def capability_for(agent: str) -> ProviderCapability:
    """Return the declarative capability record for one agent."""
    try:
        return CAPABILITIES[agent]
    except KeyError:
        raise ValueError(
            f"unknown agent {agent!r}; known: {', '.join(sorted(CAPABILITIES))}"
        ) from None


def capability_registry() -> dict[str, Any]:
    """Machine-diffable snapshot of the whole table (stable schema)."""
    return {
        "schema": "vibecrafted.continuity.capabilities.v1",
        "agents": {name: cap.to_dict() for name, cap in CAPABILITIES.items()},
    }


@dataclass(frozen=True)
class ProbeResult:
    """Installed-CLI evidence for one provider's continuity contract."""

    agent: str
    state: str  # confirmed | unsupported | probe_failed | evidence_only
    executable: str | None
    version: str | None
    markers: Mapping[str, bool] = field(default_factory=dict)
    detail: str = ""
    checked_at: str = ""

    def to_dict(self) -> dict[str, Any]:
        """Flatten this probe result to a JSON-serializable dict."""
        return {
            "agent": self.agent,
            "state": self.state,
            "executable": self.executable,
            "version": self.version,
            "markers": dict(self.markers),
            "detail": self.detail,
            "checked_at": self.checked_at,
        }


@dataclass(frozen=True)
class CursorCliSurface:
    """Installed cursor-agent flag surface — help truth for one selected binary."""

    executable: str | None
    version: str | None
    help_text: str
    flags: Mapping[str, bool] = field(default_factory=dict)
    state: str = PROBE_FAILED  # confirmed | unsupported | probe_failed
    detail: str = ""
    checked_at: str = ""

    def supports(self, flag: str) -> bool:
        """True when ``flag`` appears on the probed help surface."""
        return bool(self.flags.get(flag))

    def to_dict(self) -> dict[str, Any]:
        """Flatten this surface to a JSON-serializable dict."""
        return {
            "executable": self.executable,
            "version": self.version,
            "flags": dict(self.flags),
            "state": self.state,
            "detail": self.detail,
            "checked_at": self.checked_at,
            "help_chars": len(self.help_text),
        }


_PROBE_CACHE: dict[str, ProbeResult] = {}
# Path → (binary identity, surface). Identity invalidates when the file at the
# same path changes (provider upgrade/downgrade on a shared install location).
_CURSOR_SURFACE_CACHE: dict[str, tuple[str, CursorCliSurface]] = {}


def clear_cursor_surface_cache() -> None:
    """Drop cached cursor-agent help surfaces (tests + refresh)."""
    _CURSOR_SURFACE_CACHE.clear()


def clear_probe_cache() -> None:
    """Drop cached provider probes and cursor help surfaces."""
    _PROBE_CACHE.clear()
    clear_cursor_surface_cache()


def _executable_identity(path: str | None) -> str:
    """Stable identity for the file currently at ``path`` (content-sensitive).

    Uses device/inode/size/mtime so a binary replaced at the same PATH entry
    invalidates the surface cache without requiring ``refresh=True``.
    """
    if not path:
        return "missing"
    try:
        st = os.stat(path, follow_symlinks=True)
    except OSError:
        return "missing"
    return f"{st.st_dev}:{st.st_ino}:{st.st_size}:{st.st_mtime_ns}"


def _default_runner(timeout: float) -> Runner:
    """Build a subprocess-backed :data:`Runner` bound to a fixed timeout."""

    def run(cmd: Sequence[str]) -> CliProbe:
        """Execute one read-only CLI probe command and capture its result."""
        try:
            environment = dict(os.environ)
            environment["PATH"] = agent_tool_search_path(environment)
            completed = subprocess.run(
                list(cmd),
                capture_output=True,
                text=True,
                timeout=timeout,
                check=False,
                env=environment,
            )
        except FileNotFoundError:
            return CliProbe(ok=False, returncode=None, stderr="not found")
        except subprocess.TimeoutExpired:
            return CliProbe(ok=False, returncode=None, stderr="timeout")
        except OSError as exc:  # defensive
            return CliProbe(ok=False, returncode=None, stderr=str(exc))
        return CliProbe(
            ok=completed.returncode == 0,
            returncode=completed.returncode,
            stdout=completed.stdout or "",
            stderr=completed.stderr or "",
        )

    return run


def _first_line(text: str) -> str | None:
    """First non-blank line of ``text`` (e.g. a version banner), or None."""
    for line in text.splitlines():
        stripped = line.strip()
        if stripped:
            return stripped
    return None


def probe(
    agent: str,
    *,
    timeout: float = 10.0,
    runner: Runner | None = None,
    refresh: bool = False,
) -> ProbeResult:
    """Probe the installed provider CLI for its declared continuity contract.

    Read-only: only ``--version`` / ``--help`` style invocations, never a real
    session. Results are cached per agent; pass ``refresh=True`` to re-probe.

    States (spec §7 rule 6 — probe failure never proves incapability):

    * ``confirmed`` — binary runs and every declared marker is present;
    * ``unsupported`` — binary runs but declared markers are missing;
    * ``probe_failed`` — binary absent, broken, or timed out; autonomous
      recovery is unavailable, capability stays an open question;
    * ``evidence_only`` — provider must never be executed (gemini).
    """
    capability = capability_for(agent)
    if not refresh and agent in _PROBE_CACHE:
        return _PROBE_CACHE[agent]
    checked_at = utc_now_iso()

    if capability.execution == EVIDENCE_ONLY or capability.probe_recipe is None:
        result = ProbeResult(
            agent=agent,
            state=PROBE_EVIDENCE_ONLY,
            executable=None,
            version=None,
            markers={},
            detail=f"{agent} is evidence-only and is never executed",
            checked_at=checked_at,
        )
        _PROBE_CACHE[agent] = result
        return result

    recipe = capability.probe_recipe
    executable = shutil.which(recipe.cli, path=agent_tool_search_path())
    if executable is None:
        result = ProbeResult(
            agent=agent,
            state=PROBE_FAILED,
            executable=None,
            version=None,
            markers={},
            detail=(
                f"{recipe.cli} not found on $PATH — autonomous recovery "
                "unavailable; NOT proof the provider is incapable"
            ),
            checked_at=checked_at,
        )
        _PROBE_CACHE[agent] = result
        return result

    run = runner or _default_runner(timeout)
    version_probe = run([executable, *recipe.version_args])
    if not version_probe.ok:
        reason = (
            version_probe.stderr or version_probe.stdout or "non-zero exit"
        ).strip()
        result = ProbeResult(
            agent=agent,
            state=PROBE_FAILED,
            executable=executable,
            version=None,
            markers={},
            detail=(
                f"{recipe.cli} present at {executable} but failed to "
                f"execute: {reason} — NOT proof the provider is incapable"
            ),
            checked_at=checked_at,
        )
        _PROBE_CACHE[agent] = result
        return result

    version = _first_line(version_probe.stdout or version_probe.stderr)
    help_probe = run([executable, *recipe.help_args])
    surface = (help_probe.stdout or "") + "\n" + (help_probe.stderr or "")
    markers = {marker: marker in surface for marker in recipe.required_markers}
    missing = [marker for marker, found in markers.items() if not found]

    if missing:
        result = ProbeResult(
            agent=agent,
            state=PROBE_UNSUPPORTED,
            executable=executable,
            version=version,
            markers=markers,
            detail=(
                f"{recipe.cli} {version or '(unknown version)'} lacks "
                f"declared contract markers: {', '.join(missing)}"
            ),
            checked_at=checked_at,
        )
    else:
        result = ProbeResult(
            agent=agent,
            state=PROBE_CONFIRMED,
            executable=executable,
            version=version,
            markers=markers,
            detail=(
                f"{recipe.cli} {version or '(unknown version)'} exposes the "
                "full declared continuity contract"
            ),
            checked_at=checked_at,
        )
    _PROBE_CACHE[agent] = result
    return result


# Unambiguous alias for the package-root export (the foundation-tool probe is
# `probe_tool`; this one probes agent providers).
probe_provider = probe


def _help_mentions_flag(help_text: str, flag: str) -> bool:
    """True when ``flag`` appears as its own token on a help surface.

    Require an identifier boundary so ``--trust`` does not match
    ``--trusted-workspace`` by accident.
    """
    if not flag or flag not in help_text:
        return False
    pattern = re.compile(rf"(?<![A-Za-z0-9_-]){re.escape(flag)}(?![A-Za-z0-9_-])")
    return pattern.search(help_text) is not None


def probe_cursor_cli_surface(
    *,
    executable: str | None = None,
    timeout: float = 10.0,
    runner: Runner | None = None,
    refresh: bool = False,
    help_text: str | None = None,
    version: str | None = None,
) -> CursorCliSurface:
    """Probe the selected ``cursor-agent`` binary for launch-relevant flags.

    Read-only: ``--version`` / ``--help`` only (or an injected ``help_text`` for
    tests). Missing binaries are ``probe_failed`` — not proof of incapability,
    but enough to refuse a launch that would otherwise guess flags.

    Only a *successful* bounded ``--help`` may establish flags. Nonzero exit,
    timeout, or empty help stays ``probe_failed`` — error prose that happens to
    mention ``--force`` / ``--trust`` is never capability evidence.
    """
    checked_at = utc_now_iso()
    recipe = capability_for("cursor").probe_recipe
    assert recipe is not None  # cursor always declares a recipe
    resolved = executable or shutil.which(recipe.cli, path=agent_tool_search_path())
    cache_key = resolved or f"missing:{recipe.cli}"
    identity = _executable_identity(resolved)
    if not refresh and help_text is None:
        cached = _CURSOR_SURFACE_CACHE.get(cache_key)
        if cached is not None and cached[0] == identity:
            return cached[1]

    def _store(surface: CursorCliSurface) -> CursorCliSurface:
        if help_text is None:
            _CURSOR_SURFACE_CACHE[cache_key] = (identity, surface)
        return surface

    if help_text is not None:
        surface_text = help_text
        version_text = version
        state = PROBE_CONFIRMED
        detail = "injected help surface"
        exe = resolved
    else:
        if resolved is None:
            return _store(
                CursorCliSurface(
                    executable=None,
                    version=None,
                    help_text="",
                    flags={flag: False for flag in CURSOR_TRACKED_FLAGS},
                    state=PROBE_FAILED,
                    detail=(
                        f"{recipe.cli} not found on $PATH — cannot verify required "
                        "cursor flags; refusing to guess"
                    ),
                    checked_at=checked_at,
                )
            )

        run = runner or _default_runner(timeout)
        version_probe = run([resolved, *recipe.version_args])
        if not version_probe.ok:
            reason = (
                version_probe.stderr or version_probe.stdout or "non-zero exit"
            ).strip()
            return _store(
                CursorCliSurface(
                    executable=resolved,
                    version=None,
                    help_text="",
                    flags={flag: False for flag in CURSOR_TRACKED_FLAGS},
                    state=PROBE_FAILED,
                    detail=(
                        f"{recipe.cli} present at {resolved} but failed to execute: "
                        f"{reason} — cannot verify required cursor flags"
                    ),
                    checked_at=checked_at,
                )
            )

        version_text = _first_line(version_probe.stdout or version_probe.stderr)
        help_probe = run([resolved, *recipe.help_args])
        # Success-gated: never parse flag names out of failed --help stderr.
        if not help_probe.ok:
            reason = (help_probe.stderr or help_probe.stdout or "non-zero exit").strip()
            exit_bit = (
                "timed out"
                if reason == "timeout"
                else f"failed (exit {help_probe.returncode})"
            )
            return _store(
                CursorCliSurface(
                    executable=resolved,
                    version=version_text,
                    help_text="",
                    flags={flag: False for flag in CURSOR_TRACKED_FLAGS},
                    state=PROBE_FAILED,
                    detail=(
                        f"{recipe.cli} {version_text or '(unknown version)'} --help "
                        f"{exit_bit}: {reason} — cannot verify required cursor flags; "
                        "refusing to treat error prose as capability evidence"
                    ),
                    checked_at=checked_at,
                )
            )

        surface_text = (help_probe.stdout or "") + "\n" + (help_probe.stderr or "")
        if not surface_text.strip():
            return _store(
                CursorCliSurface(
                    executable=resolved,
                    version=version_text,
                    help_text="",
                    flags={flag: False for flag in CURSOR_TRACKED_FLAGS},
                    state=PROBE_FAILED,
                    detail=(
                        f"{recipe.cli} {version_text or '(unknown version)'} returned "
                        "empty --help — cannot verify required cursor flags"
                    ),
                    checked_at=checked_at,
                )
            )
        state = PROBE_CONFIRMED
        detail = (
            f"{recipe.cli} {version_text or '(unknown version)'} help surface "
            "captured for flag enforcement"
        )
        exe = resolved

    flags = {
        flag: _help_mentions_flag(surface_text, flag) for flag in CURSOR_TRACKED_FLAGS
    }
    return _store(
        CursorCliSurface(
            executable=exe,
            version=version_text,
            help_text=surface_text,
            flags=flags,
            state=state,
            detail=detail,
            checked_at=checked_at,
        )
    )


def require_cursor_flags(
    flags: Sequence[str],
    surface: CursorCliSurface,
    *,
    permissions: str = "",
) -> tuple[str, ...]:
    """Return ``flags`` unchanged when every required flag is on ``surface``.

    Never drops a missing flag. Missing required semantics fail with a clear
    reason naming the selected binary/version and the absent flag(s).
    """
    required = tuple(flag for flag in flags if flag.startswith("-"))
    if surface.state == PROBE_FAILED:
        raise ValueError(
            surface.detail
            or "cursor-agent flag probe failed — refusing to launch with guessed flags"
        )
    missing = [flag for flag in required if not surface.supports(flag)]
    if missing:
        version = surface.version or "(unknown version)"
        exe = surface.executable or "cursor-agent"
        policy = f" for permissions={permissions}" if permissions else ""
        raise ValueError(
            f"cursor-agent {version} at {exe} lacks required flag(s) "
            f"{', '.join(missing)}{policy}; refusing to launch "
            "(no silent downgrade). Update cursor-agent or select a binary "
            "that exposes these flags."
        )
    if "--best-of-n" in required:
        raise ValueError(
            "cursor-agent does not support --best-of-n; refusing to invent it"
        )
    return tuple(flags)


def validate_cursor_resume_chat_id(value: str) -> str:
    """Validate interactive ``--resume`` input: chatId only, never a brief path.

    ``cursor-agent --resume`` selects a session by chatId. Passing a brief
    markdown path (Founder incident 2026-09-08) is invalid and must fail
    before launch.
    """
    normalized = str(value or "").strip()
    if not normalized:
        raise ValueError("cursor --resume requires a non-empty chatId")
    if normalized.startswith("-"):
        raise ValueError(
            f"cursor --resume takes chatId, not a flag-shaped value: {normalized!r}"
        )
    # Path-shaped inputs: absolute/relative paths, existing files, brief suffixes.
    path_like = (
        "/" in normalized
        or "\\" in normalized
        or normalized.startswith("~")
        or normalized.endswith((".md", ".txt", ".markdown", ".prompt"))
    )
    if path_like:
        raise ValueError(
            "cursor --resume takes chatId, not a brief/file path; "
            f"refusing {normalized!r}"
        )
    expanded = Path(normalized).expanduser()
    try:
        exists = expanded.exists()
    except OSError:
        exists = False
    if exists:
        raise ValueError(
            "cursor --resume takes chatId, not a filesystem path; "
            f"refusing existing path {normalized!r}"
        )
    return normalized


def reject_unsupported_cursor_argv(argv: Sequence[str]) -> None:
    """Fail closed when argv invents flags cursor-agent does not expose."""
    if "--best-of-n" in argv:
        raise ValueError(
            "cursor-agent does not support --best-of-n; refusing to invent it"
        )
    for index, token in enumerate(argv):
        if token == "--resume" and index + 1 < len(argv):
            nxt = argv[index + 1]
            if nxt.startswith("-"):
                continue
            validate_cursor_resume_chat_id(nxt)
