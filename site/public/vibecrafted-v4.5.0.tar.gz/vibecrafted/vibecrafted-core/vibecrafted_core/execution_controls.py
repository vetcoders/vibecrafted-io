"""Public execution controls for skill launchers: ``--permissions`` / ``--sandbox``.

One owner for three things:

* the public words (``bypass|auto|accept-edits|read-only`` and ``true|false``),
  parsed identically by the core launcher and the shell contract;
* the per-provider sandbox contract, written from the installed provider CLIs
  (read-only ``--help`` and binary strings captured on 2026-09-08 — see
  ``SANDBOX_EVIDENCE``), never from an assumption that every agent sandboxes;
* the combined resolver that turns (provider, permissions, sandbox) into the
  exact provider argv, or refuses before any process launch with a supported
  alternative. A requested restriction is never downgraded silently:
  ``--permissions auto`` never becomes ``bypassPermissions`` and
  ``--sandbox true`` never becomes an unsandboxed run.

What ``--sandbox`` means is the *provider's own command sandbox* — the boundary
each provider draws around the shell commands its agent runs (for Claude: the
Bash tool and its child processes under macOS Seatbelt / Linux bubblewrap). It
is not whole-agent or VM isolation: file tools, web fetches and MCP servers
stay outside it. Every receipt names that boundary (``boundary``).

Two rules follow from "requested is never silently downgraded":

* ``sandbox_effective`` reports what the launcher *configured through the
  provider's supported interface*. The launcher never observes OS enforcement
  from argv, and says so in the behavior note.
* ``--sandbox false`` is emitted only where the provider has a verified explicit
  disable interface (Claude ``sandbox.enabled=false``, grok ``--sandbox off``,
  cursor ``--sandbox disabled``, codex bypass). Where the only surface is an
  opt-in flag (agy), "no flag" is *not* "disabled" — persistent provider
  settings may still enable the sandbox — so explicit ``false`` is refused with
  the supported alternative. Omission always stays ``provider-default``.

Permission semantics stay with :func:`vibecrafted_core.spawn.resolve_provider_policy`
(the ``_PERMISSION_CONTRACT`` owner); this module only composes the sandbox
axis on top of that decision and reports both requested and effective values.
"""

from __future__ import annotations

import json
from dataclasses import dataclass
from typing import Any

PERMISSION_POLICIES = ("bypass", "auto", "accept-edits", "read-only")
SANDBOX_TRUE_WORDS = frozenset({"1", "true", "yes", "on"})
SANDBOX_FALSE_WORDS = frozenset({"0", "false", "no", "off"})

# Supervised runtimes wrap their own provider launches; the public controls are
# not threaded through them in this cut and must be refused, not ignored.
SUPERVISED_RUNTIME_KINDS = frozenset({"supervised_research", "supervised_marbles"})

# Evidence for every sandbox cell below. Kept next to the contract so a receipt
# can name where a mapping came from; re-probe when a provider is upgraded.
SANDBOX_EVIDENCE: dict[str, str] = {
    "claude": (
        "claude 2.1.263 --help: no --sandbox flag; --settings <file-or-json> "
        "(command-line level: overrides user/project/local scalar keys, below "
        "managed settings; array keys such as sandbox.excludedCommands merge "
        "across scopes). Binary settings schema: sandbox.enabled; "
        "sandbox.failIfUnavailable ('when false (default), a warning is shown and "
        "commands run unsandboxed'); sandbox.allowUnsandboxedCommands ('when "
        "false, the dangerouslyDisableSandbox parameter is completely ignored and "
        "all commands must run sandboxed. Default: true'); "
        "sandbox.excludedCommands exempts listed commands; "
        "autoAllowBashIfSandboxed only decides prompting. Boundary per Claude Code "
        "docs: OS-level (Seatbelt / bubblewrap) for Bash commands and their child "
        "processes only"
    ),
    "codex": (
        "codex-cli 0.154.0-alpha.3 `codex exec --help`: -s/--sandbox "
        "read-only|workspace-write|danger-full-access, --approve-for-me "
        "(automatic review inside the workspace-write sandbox), "
        "--dangerously-bypass-approvals-and-sandbox; exec has no --ask-for-approval"
    ),
    "grok": (
        "grok 1.0.21 --help: --sandbox <PROFILE> [env: GROK_SANDBOX]; embedded docs: "
        "built-in profiles workspace|devbox|read-only|strict, 'off' disables"
    ),
    "cursor": "cursor-agent 2026.09.08 --help: --sandbox <mode> enabled|disabled",
    "agy": (
        "agy 1.1.27 --help: --sandbox is a boolean opt-in "
        "('Run in a sandbox with terminal restrictions enabled'); no opt-out flag. "
        "--sandbox=false and --sandbox=not-a-boolean both exit 0 with --help / "
        "--version, so argv parsing proves nothing about enforcement. The binary "
        "also carries persistent terminal-sandbox settings (sandboxMode, "
        "enableTerminalSandbox, GlobalSandboxEnabled, 'Sandbox Mode: Enable or "
        "disable terminal sandboxing per project'), so an omitted flag does not "
        "prove the sandbox is off"
    ),
    "junie": "junie 26.8.31 --help: no sandbox surface",
    "kimi": (
        "kimi 0.42.0 --help + binary option validation (probed 2026-09-13): no "
        "--sandbox surface. Permission modes are explicit startup flags, not a "
        "sandbox: -y/--yolo (Ask When Needed: routine edits and commands run "
        "automatically; risky actions, questions and plans still ask), --auto "
        "(Never Ask), --plan (plan mode). All three conflict with -p/--prompt "
        "(OptionConflictError: Cannot combine --prompt with --yolo/--auto/--plan), "
        "so print mode always runs under kimi's auto (never-ask) permission "
        "policy with static deny rules still in effect"
    ),
    "copilot": (
        "GitHub Copilot CLI 1.0.89-7 --help (2026-09-29): permission, path, "
        "URL and tool controls exist; no explicit shell sandbox on/off flag"
    ),
    "omp": (
        "omp 18.11.0 --help (probed 2026-10-15): no sandbox surface. "
        "Permission tiers via --approval-mode always-ask|write|yolo (combines "
        "with -p/--print), tool whitelist via --tools; neither is an OS "
        "confinement boundary"
    ),
}

# What each provider's sandbox actually confines. Named in every receipt so a
# reader never mistakes "sandbox enabled" for whole-agent or VM isolation.
SANDBOX_BOUNDARY: dict[str, str] = {
    "claude": (
        "Claude Code Bash-tool sandbox: OS-level (macOS Seatbelt / Linux "
        "bubblewrap) confinement of Bash commands and their child processes only; "
        "file tools, WebFetch and MCP servers run outside it. Configured through "
        "--settings; the launcher does not observe OS enforcement"
    ),
    "codex": (
        "codex exec sandbox policy for model-generated shell commands "
        "(read-only | workspace-write | danger-full-access)"
    ),
    "grok": "grok built-in sandbox profile for agent commands",
    "cursor": "cursor-agent sandbox mode for agent commands",
    "agy": "agy terminal sandbox ('terminal restrictions') for agent commands",
    "junie": "",
    "kimi": "",
    "copilot": "",
    "omp": "",
}

# Claude Code's documented hard-gate shape: the sandbox must be on, a missing
# backend fails the run instead of silently running unsandboxed, and the
# model's dangerouslyDisableSandbox escape hatch is ignored. Scalar keys passed
# through --settings win over user/project/local settings (not over managed).
_CLAUDE_SANDBOX_ON_SETTINGS: dict[str, Any] = {
    "sandbox": {
        "enabled": True,
        "failIfUnavailable": True,
        "allowUnsandboxedCommands": False,
    }
}
_CLAUDE_SANDBOX_OFF_SETTINGS: dict[str, Any] = {"sandbox": {"enabled": False}}
_CLAUDE_SANDBOX_ON = json.dumps(_CLAUDE_SANDBOX_ON_SETTINGS, separators=(",", ":"))
_CLAUDE_SANDBOX_OFF = json.dumps(_CLAUDE_SANDBOX_OFF_SETTINGS, separators=(",", ":"))


def claude_sandbox_settings(enabled: bool) -> dict[str, Any]:
    """The exact ``--settings`` document emitted for Claude ``--sandbox``."""
    settings = _CLAUDE_SANDBOX_ON_SETTINGS if enabled else _CLAUDE_SANDBOX_OFF_SETTINGS
    return json.loads(json.dumps(settings))


class ExecutionControlsError(ValueError):
    """A requested control cannot be enforced by the provider; refused pre-launch."""


def parse_permissions_word(value: Any, *, label: str = "--permissions") -> str:
    """Return one of :data:`PERMISSION_POLICIES` or ``""`` when omitted."""
    if value is None:
        return ""
    word = str(value).strip().lower()
    if not word:
        return ""
    if word not in PERMISSION_POLICIES:
        raise ExecutionControlsError(
            f"{label} expects {'|'.join(PERMISSION_POLICIES)}, got: {value}"
        )
    return word


def parse_sandbox_word(value: Any, *, label: str = "--sandbox") -> bool | None:
    """Return ``True``/``False`` for a sandbox word, ``None`` when omitted."""
    if value is None or isinstance(value, bool):
        return value
    word = str(value).strip().lower()
    if not word:
        return None
    if word in SANDBOX_TRUE_WORDS:
        return True
    if word in SANDBOX_FALSE_WORDS:
        return False
    raise ExecutionControlsError(f"{label} expects true or false, got: {value}")


def default_permissions(provider: str) -> str:
    """The policy a launcher applies when ``--permissions`` is omitted.

    Fleet doctrine (Founder decision 13716da4a2b8af7049ea1565, 2026-10-15):
    the default is ``auto`` for every provider; every other mode is a deliberate
    opt-in via durable config or an explicit dispatch selection. There is no
    per-provider bypass fallback here — an unsupported ``auto`` combination is
    refused by the caller with the named alternative, never downgraded.
    """
    return "auto"


def sandbox_word(value: bool | None) -> str:
    """Public spelling of a parsed sandbox value (``""`` when omitted)."""
    if value is None:
        return ""
    return "true" if value else "false"


@dataclass(frozen=True)
class ExecutionControls:
    """Requested and effective execution controls for one provider launch."""

    provider: str
    permissions_requested: str
    permissions_effective: str
    sandbox_requested: bool | None
    sandbox_effective: str
    provider_flags: tuple[str, ...]
    behavior: str
    evidence: str
    boundary: str = ""
    # Where the effective permission word came from: "dispatch" (explicit
    # --permissions), "config:agents.<provider>", "config:global", or "default".
    permissions_source: str = ""
    permissions_reason: str = ""

    @property
    def requested(self) -> bool:
        """True when dispatch or durable config selected at least one control."""
        return bool(self.permissions_requested) or self.sandbox_requested is not None

    def receipt(self) -> dict[str, Any]:
        """Launch-receipt / meta projection: requested next to effective."""
        return {
            "schema": "vibecrafted.execution_controls.v1",
            "provider": self.provider,
            "permissions_requested": self.permissions_requested,
            "permissions_effective": self.permissions_effective,
            "permissions_source": self.permissions_source or "default",
            "permissions_reason": self.permissions_reason,
            "sandbox_requested": sandbox_word(self.sandbox_requested),
            "sandbox_effective": self.sandbox_effective,
            "provider_flags": list(self.provider_flags),
            "behavior": self.behavior,
            "evidence": self.evidence,
            "boundary": self.boundary,
        }


def _refuse(provider: str, message: str) -> ExecutionControlsError:
    return ExecutionControlsError(f"{provider}: {message}")


def _apply_sandbox(
    provider: str,
    permissions: str,
    sandbox: bool | None,
    base_flags: tuple[str, ...],
) -> tuple[tuple[str, ...], str, str]:
    """Compose the sandbox axis onto the permission flags for one provider.

    Returns ``(flags, sandbox_effective, note)``. Raises
    :class:`ExecutionControlsError` with an exact alternative when the installed
    provider cannot enforce the requested value.
    """
    if provider == "claude":
        if sandbox is None:
            return (
                base_flags,
                "provider-default",
                "Bash-tool sandbox left to the inherited Claude settings",
            )
        if sandbox:
            return (
                (*base_flags, "--settings", _CLAUDE_SANDBOX_ON),
                "enabled",
                (
                    "Bash-tool sandbox required through --settings: "
                    "sandbox.enabled=true, failIfUnavailable=true (a missing "
                    "sandbox backend fails the run instead of running commands "
                    "unsandboxed), allowUnsandboxedCommands=false (the model's "
                    "dangerouslyDisableSandbox retry is ignored). Commands listed "
                    "in inherited sandbox.excludedCommands still run outside the "
                    "sandbox (array keys merge across settings scopes); managed "
                    "settings outrank --settings. Configured, not observed: the "
                    "launcher does not watch OS enforcement"
                ),
            )
        return (
            (*base_flags, "--settings", _CLAUDE_SANDBOX_OFF),
            "disabled",
            (
                "Bash-tool sandbox disabled through --settings "
                "(sandbox.enabled=false); managed settings outrank --settings"
            ),
        )

    if provider == "codex":
        if permissions == "bypass":
            if sandbox is True:
                # The bypass flag disables the sandbox; the only way to keep
                # approvals off AND the sandbox on is the plain sandbox policy
                # (`codex exec` never prompts).
                return (
                    ("--sandbox", "workspace-write"),
                    "enabled",
                    (
                        "codex exec runs non-interactively (no approval prompts); "
                        "workspace-write sandbox kept"
                    ),
                )
            return (
                base_flags,
                "disabled",
                "--dangerously-bypass-approvals-and-sandbox runs without a sandbox",
            )
        if permissions == "auto":
            if sandbox is False:
                raise _refuse(
                    provider,
                    "--permissions auto runs under --approve-for-me, which is bound "
                    "to the workspace-write sandbox, so --sandbox false cannot be "
                    "enforced. Use `--permissions bypass --sandbox false` or omit "
                    "--sandbox.",
                )
            return (
                base_flags,
                "enabled",
                "--approve-for-me reviews approvals inside the workspace-write sandbox",
            )
        if permissions == "read-only":
            if sandbox is False:
                raise _refuse(
                    provider,
                    "--permissions read-only is enforced by the read-only sandbox, "
                    "so --sandbox false cannot be enforced. Omit --sandbox or pass "
                    "--sandbox true.",
                )
            return base_flags, "enabled", "read-only sandbox enforces the policy"
        return base_flags, "provider-default", ""

    if provider == "grok":
        if sandbox is None:
            return base_flags, "provider-default", "sandbox left to grok config"
        if sandbox:
            profile = "read-only" if permissions == "read-only" else "workspace"
            return (
                (*base_flags, "--sandbox", profile),
                "enabled",
                f"grok built-in sandbox profile {profile}",
            )
        return (*base_flags, "--sandbox", "off"), "disabled", "grok --sandbox off"

    if provider == "cursor":
        if sandbox is None:
            return base_flags, "provider-default", "sandbox left to cursor config"
        mode = "enabled" if sandbox else "disabled"
        return (
            (*base_flags, "--sandbox", mode),
            mode,
            f"cursor-agent --sandbox {mode} (verified against the installed --help)",
        )

    if provider == "agy":
        if sandbox is None:
            return (
                base_flags,
                "provider-default",
                "terminal sandbox left to agy's own settings",
            )
        if sandbox:
            return (
                (*base_flags, "--sandbox"),
                "enabled",
                "agy --sandbox (terminal restrictions; configured, not observed)",
            )
        # agy 1.1.27 has only the opt-in flag. Omitting it does not prove the
        # sandbox is off: the binary carries persistent terminal-sandbox settings
        # (sandboxMode / enableTerminalSandbox). No verified disable interface
        # exists, so an explicit false fails closed instead of being receipted
        # as "disabled".
        raise _refuse(
            provider,
            "agy 1.1.27 exposes only the opt-in --sandbox flag and keeps its own "
            "persistent terminal-sandbox settings, so --sandbox false cannot be "
            "enforced from the launcher. Omit --sandbox to keep agy's own setting "
            "(receipted as provider-default) or pass --sandbox true.",
        )

    if provider == "junie":
        if sandbox is None:
            return base_flags, "provider-default", "junie exposes no sandbox control"
        raise _refuse(
            provider,
            "junie 26.8.31 exposes no sandbox control, so --sandbox "
            f"{sandbox_word(sandbox)} cannot be enforced. Omit --sandbox.",
        )

    if provider == "kimi":
        if sandbox is None:
            return base_flags, "provider-default", "kimi exposes no sandbox control"
        raise _refuse(
            provider,
            "kimi 0.42.0 exposes no sandbox control, so --sandbox "
            f"{sandbox_word(sandbox)} cannot be enforced. Omit --sandbox.",
        )
    if provider == "copilot":
        if sandbox is None:
            return (
                base_flags,
                "provider-default",
                "copilot exposes no explicit sandbox control",
            )
        raise _refuse(
            provider,
            "copilot exposes no explicit sandbox control, so --sandbox "
            f"{sandbox_word(sandbox)} cannot be enforced. Omit --sandbox.",
        )

    if provider == "omp":
        if sandbox is None:
            return (
                base_flags,
                "provider-default",
                "omp exposes no sandbox control",
            )
        raise _refuse(
            provider,
            "omp 18.11.0 exposes no sandbox control, so --sandbox "
            f"{sandbox_word(sandbox)} cannot be enforced. Omit --sandbox.",
        )

    if sandbox is None:
        return base_flags, "provider-default", ""
    raise _refuse(
        provider,
        "no sandbox contract is recorded for this provider; omit --sandbox",
    )


def controls_from_receipt(payload: dict[str, Any]) -> ExecutionControls | None:
    """Rebuild the frozen decision from a stored ``execution_controls`` receipt.

    Admission freezes the resolved controls into the run meta; argv builders and
    resume paths consume THIS reconstruction instead of re-resolving against
    live config (Founder decision 13716da4a2b8af7049ea1565: one frozen decision
    rides from admission to argv/meta and resume). ``None`` only when the
    payload carries no receipt at all; a malformed receipt raises.
    """
    if not payload:
        return None
    if payload.get("schema") != "vibecrafted.execution_controls.v1":
        raise ExecutionControlsError(
            f"unknown execution_controls receipt schema: {payload.get('schema')!r}"
        )
    provider = str(payload.get("provider") or "")
    effective = str(payload.get("permissions_effective") or "")
    if not provider or effective not in PERMISSION_POLICIES:
        raise ExecutionControlsError(
            "execution_controls receipt is missing provider/permissions_effective"
        )
    return ExecutionControls(
        provider=provider,
        permissions_requested=str(payload.get("permissions_requested") or ""),
        permissions_effective=effective,
        sandbox_requested=parse_sandbox_word(payload.get("sandbox_requested") or None),
        sandbox_effective=str(payload.get("sandbox_effective") or ""),
        provider_flags=tuple(str(flag) for flag in payload.get("provider_flags") or ()),
        behavior=str(payload.get("behavior") or ""),
        evidence=str(payload.get("evidence") or ""),
        boundary=str(payload.get("boundary") or ""),
        permissions_source=str(payload.get("permissions_source") or "default"),
        permissions_reason=str(payload.get("permissions_reason") or ""),
    )


def resolve_execution_controls(
    provider: str,
    *,
    permissions: str = "",
    sandbox: bool | None = None,
    mode: str = "headless",
    configured_permissions: str = "",
    permissions_source: str = "",
) -> ExecutionControls:
    """Resolve the exact provider argv for the requested controls, or refuse.

    ``permissions`` is one of :data:`PERMISSION_POLICIES` or ``""`` (explicit
    dispatch selection). ``configured_permissions`` is the durable config word
    (already loaded by the caller from ``server_config``), with
    ``permissions_source`` naming the config cell for receipts. Precedence:
    explicit dispatch > durable config > fleet default (``auto``). A malformed
    configured word refuses before launch, never silently reverts. Raises
    :class:`ExecutionControlsError` naming the provider and a supported
    alternative whenever the installed CLI cannot enforce the combination.
    """
    from .spawn import resolve_provider_policy

    requested = parse_permissions_word(permissions)
    configured = parse_permissions_word(
        configured_permissions, label="durable config permissions"
    )
    effective = requested or configured or default_permissions(provider)
    if requested:
        source = "dispatch"
    elif configured:
        source = permissions_source or "config"
    else:
        source = "default"
    reason = ""
    if provider == "junie" and mode == "headless" and effective == "bypass":
        effective = "auto"
        reason = "junie-headless-no-bypass"
    try:
        policy = resolve_provider_policy(provider, "local-native", effective, mode)
    except ValueError as exc:
        raise _refuse(
            provider, f"--permissions {effective} is not resolvable ({exc})"
        ) from exc
    if not policy.supported:
        supported = [
            word
            for word in PERMISSION_POLICIES
            if resolve_provider_policy(provider, "local-native", word, mode).supported
        ]
        raise _refuse(
            provider,
            f"cannot enforce --permissions {effective} ({policy.reason}); "
            f"supported: {', '.join(supported) or 'none'}",
        )
    flags, sandbox_effective, note = _apply_sandbox(
        provider, effective, sandbox, tuple(policy.flags)
    )
    behavior = policy.behavior
    if note:
        behavior = f"{behavior}; {note}" if behavior else note
    if reason:
        behavior = f"{behavior}; requested bypass adapted to auto: {reason}"
    return ExecutionControls(
        provider=provider,
        permissions_requested=requested or configured,
        permissions_effective=effective,
        sandbox_requested=sandbox,
        sandbox_effective=sandbox_effective,
        provider_flags=tuple(flags),
        behavior=behavior,
        evidence=SANDBOX_EVIDENCE.get(provider, ""),
        boundary=SANDBOX_BOUNDARY.get(provider, ""),
        permissions_source=source,
        permissions_reason=reason,
    )
