"""Legacy launcher supervisor: spawns agent CLIs, extracts usage, finalizes artifacts."""

from __future__ import annotations

import argparse
import datetime as dt
import glob
import hashlib
import inspect
import json
import logging
import os
import re
import shlex
import signal
import subprocess
import sys
import threading
import time
import uuid
from collections.abc import Callable, Mapping, Sequence
from dataclasses import dataclass, field
from functools import lru_cache
from pathlib import Path
from shutil import which
from typing import Any

from .agent_dispatch import extract_session_id, sandbox_supported
from .aicx_session_chain import SessionChain
from .clock import utc_now_iso
from .control_plane import (
    ControlPlaneLockBusy,
    ControlPlaneStorageError,
    control_plane_home,
    ensure_session_id,
    normalize_run_root,
    sync_state,
)
from .effort_overrides import _effort_override_receipt, _with_effort_override
from .env_allowlist import (
    dispatcher_identity,
    filter_headless_worker_env,
    managed_provider_environment,
    provider_launch_environment_receipt,
    provider_workspace_environment,
    visible_color_environment,
)
from .events import append_event
from .execution_controls import (
    PERMISSION_POLICIES,
    ExecutionControls,
    controls_from_receipt,
    resolve_execution_controls,
)
from .failure_attribution import attribute_failure
from .model_overrides import _with_model_override
from .package_resources import skills_path
from .report_contract import (
    CLAIM_DIGEST_ENV,
    materialize_launcher_report_template,
    stamp_launcher_report_identity,
)
from .runtime_paths import (
    agent_tool_search_path,
    is_owned_generation_path,
    read_version_file,
    selected_runtime_environment,
    version_is_stamped,
)
from .runtime_transcript import (
    InteractiveTranscriptCapture,
    write_runtime_transcript_manifest,
)
from .settlement import BareMarkdownError, require_bound_markdown
from .telemetry import (
    build_run_telemetry,
    coerce_exit_code,
    parent_session_ids,
    usage_record,
)
from .telemetry import tokens_total as _tokens_total

EventCallback = Callable[[dict[str, Any]], None]

POLICY_PROVIDERS = (
    "codex",
    "claude",
    "agy",
    "grok",
    "junie",
    "cursor",
    "kimi",
    "copilot",
    "omp",
)
# Fleet agent key → installed CLI binary when they differ (key stays the UX
# name: `vibecrafted implement cursor`, binary remains `cursor-agent`).
AGENT_BINARY_NAMES: dict[str, str] = {
    "cursor": "cursor-agent",
}
RUNTIME_POLICIES = ("local-native", "local-worktrees", "local-vm", "cloud-soon")
# Interactive environments whose Agent runs in a Frame tab the User watches.
USER_OBSERVED_RUNTIMES = ("local-native", "local-worktrees", "local-vm")
# The public permission words live in execution_controls (one owner for the
# core launcher and the shell contract); re-exported here for the policy API.
POLICY_MODES = ("interactive", "headless")
QUOTA_PRESET_TOKENS = 250_000
QUOTA_MAX_TOKENS = 10_000_000
QUOTA_EXHAUSTED_EXIT_CODE = 75
OPERATOR_POLICIES = ("none", "auto", "claude")
CONTINUITY_MODES = ("full-lineage", "fresh", "bare-fork")


def agent_cli_name(agent: str) -> str:
    """Return the PATH binary for a fleet agent key (identity when unset)."""
    return AGENT_BINARY_NAMES.get(agent, agent)


_CONTINUITY_ID = re.compile(r"^[A-Za-z0-9][A-Za-z0-9._:-]{0,127}$")
_INHERITED_CONTINUITY_ENV = (
    "AICX_CONTEXT_FILE",
    "AICX_CONTINUITY_FILE",
    "CLAUDE_CODE_SESSION_ID",
    "CODEX_SESSION_ID",
    "GROK_SESSION_ID",
    "VIBECRAFTED_AGENT_SESSION_ID",
    "VIBECRAFTED_OPERATOR_SESSION_ID",
    "VIBECRAFTED_PARENT_RUN_ID",
    "VIBECRAFTED_PARENT_SESSION_ID",
    "VIBECRAFTED_RESUME_CONTEXT",
    "VIBECRAFTED_RESUME_META",
    "VIBECRAFTED_SESSION_ID",
    "VIBECRAFTED_LOOP_STATE_FILE",
    "VIBECRAFTED_LOOP_NR",
    "SPAWN_LOOP_NR",
)
USER_OBSERVED_WARNING = (
    "User-observed only: no Operator Agent is supervising this Agent Workspace."
)

INTERACTIVE_LAUNCHERS = frozenset({"init", "operator", "partner", "resume", "fork"})
_SLASH_SKILL_TOKEN = re.compile(r"^/vc-([A-Za-z0-9][A-Za-z0-9-]{0,62})$")
_LAUNCHER_ROLE = {
    "init": (
        "orientation gate (vc-init). This is due diligence at session entry — "
        "map, intent, and ground truth — not an implementation mission. Do not "
        "invent a task."
    ),
    "operator": (
        "orchestration posture (vc-operator). Conduct a plan only if one is "
        "already in this session. Do not invent an autonomous implementation "
        "mission or become the worker."
    ),
    "partner": (
        "shared-steering posture (vc-partner). Preserve the operator's shape. "
        "Do not invent a mission or silently take ownership."
    ),
    "resume": (
        "launcher verb, not a skill-catalog entry. Continue the already-selected "
        "native session with the existing continuity policy. Do not start a new "
        "mission or equate settlement counts with recovered conversation."
    ),
    "fork": (
        "launcher verb, not a skill-catalog entry. Branch the already-selected "
        "native session. Do not invent a new implementation task unless the "
        "operator supplied one below."
    ),
}

UNKNOWN_NATIVE_IDENTITY = "unknown"
_AGENT_CONTEXT_SCHEMA = "vibecrafted.agent-context.v1"
_RESUME_CONTEXT_IS_NOT_NATIVE = (
    "Resume delta: unfinished-work / settlement context is not a native "
    "provider-conversation resume. Native resume requires a proven native "
    "session ID; recovering context alone must not claim one."
)
_SESSION_FIELDS_DISJOINT = (
    "Parent session ID and native child session ID are disjoint fields. "
    "Do not copy a parent ID onto a child. Unknown stays unknown until the "
    "provider proves an ID."
)
_MANDATE_NO_GRANT = (
    "This prompt delivers identity and task context. It does not grant extra "
    "permissions, credentials, or provider authority."
)


def _honest_identity(value: object) -> str:
    """Return a concrete identifier, or the honest unknown sentinel."""
    text = str(value or "").strip()
    return text if text else UNKNOWN_NATIVE_IDENTITY


def disjoint_session_identities(
    *,
    parent_session_id: str = "",
    native_child_session_id: str = "",
) -> tuple[str, str]:
    """Keep parent and native child IDs as separate fields.

    A missing native ID stays empty (unknown). A child field equal to the
    parent is treated as unproven, not as inherited identity.
    """
    parent = str(parent_session_id or "").strip()
    native = str(native_child_session_id or "").strip()
    if native and parent and native == parent:
        native = ""
    return parent, native


def _panel_identity(admission: Mapping[str, Any] | None = None) -> str:
    if admission:
        for key in ("panel_id", "pane_id", "destination_panel", "vc_frame_pane_id"):
            text = str(admission.get(key) or "").strip()
            if text:
                return text
    for key in ("VC_FRAME_PANE_ID", "ZELLIJ_PANE_ID"):
        text = str(os.environ.get(key) or "").strip()
        if text:
            return text
    return ""


def _workspace_identity_for_prompt(
    root: str | os.PathLike[str],
    admission: Mapping[str, Any] | None = None,
) -> str:
    if admission:
        existing = str(admission.get("workspace_id") or "").strip()
        if existing:
            return existing
    try:
        from .workspace_catalog import resolve_run_workspace_identity

        identity = resolve_run_workspace_identity(
            root=root, env={}, create_if_missing=True
        )
        return str(identity.workspace_id)
    # Workspace identity resolution crosses store helpers; unexpected faults must yield unknown
    # identity instead of blocking launch or attributing a fabricated workspace.
    except Exception:  # noqa: BLE001
        return ""


def agent_context_contract(
    *,
    skill: str,
    root: str | os.PathLike[str],
    admission: Mapping[str, Any] | None = None,
    parent_session_id: str = "",
    resume_block: str = "",
) -> dict[str, Any]:
    """Shared VC identity payload for init/partner/operator/resume (and fork).

    Team/launcher role never replaces the real provider or model. Unknown
    native identity stays unknown. Resume context is a delta, not a native
    conversation resume.
    """
    record = dict(admission or {})
    launcher = str(skill or record.get("skill") or "init").strip() or "init"
    role = _LAUNCHER_ROLE.get(
        launcher,
        "interactive launcher. Follow the role named above; do not invent a mission.",
    )
    parent, native = disjoint_session_identities(
        parent_session_id=parent_session_id
        or str(record.get("parent_session_id") or ""),
        native_child_session_id=str(record.get("agent_session_id") or ""),
    )
    provider = str(record.get("agent") or record.get("provider") or "").strip()
    model = str(
        record.get("model_effective") or record.get("model_requested") or ""
    ).strip()
    run_id = str(record.get("run_id") or "").strip()
    workspace_id = _workspace_identity_for_prompt(root, record)
    panel_id = _panel_identity(record)
    source_snapshot = str(record.get("source_snapshot") or "").strip()
    native_resume = bool(native) and launcher == "resume"
    return {
        "schema": _AGENT_CONTEXT_SCHEMA,
        "launcher": launcher,
        "vc_role": launcher,
        "mandate": role,
        "provider": provider,
        "model": model,
        "run_id": run_id,
        "workspace_id": workspace_id,
        "panel_id": panel_id,
        "parent_session_id": parent,
        "native_child_session_id": native,
        "native_identity_status": "proven" if native else "unknown",
        "native_conversation_resume": native_resume,
        "resume_delta": resume_block,
        "source_snapshot": source_snapshot,
        "root": str(root),
    }


def render_agent_context_block(contract: Mapping[str, Any]) -> list[str]:
    """Prefill lines for the shared identity contract. Never interpolates secrets."""
    provider = _honest_identity(contract.get("provider"))
    model = _honest_identity(contract.get("model"))
    if model == UNKNOWN_NATIVE_IDENTITY:
        model = "provider_default"
    lines = [
        "VC identity (delivered to this agent):",
        f"- VC role: {contract.get('vc_role') or contract.get('launcher') or UNKNOWN_NATIVE_IDENTITY}",
        f"- Mandate: {contract.get('mandate') or _LAUNCHER_ROLE.get('init', '')}",
        f"- {_MANDATE_NO_GRANT}",
        f"- Provider: {provider} (team/launcher role does not replace provider or model)",
        f"- Model: {model}",
        f"- Task/run: {_honest_identity(contract.get('run_id'))}",
        f"- Workspace: {_honest_identity(contract.get('workspace_id'))}",
        f"- Panel: {_honest_identity(contract.get('panel_id'))}",
        f"- Parent session ID: {_honest_identity(contract.get('parent_session_id'))}",
        (
            "- Native child session ID: "
            f"{_honest_identity(contract.get('native_child_session_id'))}"
        ),
        f"- {_SESSION_FIELDS_DISJOINT}",
        f"- {_RESUME_CONTEXT_IS_NOT_NATIVE}",
    ]
    snapshot = str(contract.get("source_snapshot") or "").strip()
    if snapshot:
        lines.append(
            f"- Sources: plan-source `{snapshot}` plus skill files named below."
        )
    else:
        lines.append("- Sources: skill files named below and this private task file.")
    lines.append("")
    return lines


def legacy_slash_interactive_prompt(skill: str, source: str) -> str:
    """Historical interactive-launch body: slash token plus plan-source.

    Kept as the regression contrast for the slash-only defect. Providers are
    not assumed to expand ``/vc-*`` from a Markdown task file.
    """
    return f"/vc-{skill}\n\n{source}"


def slash_skill_name(text: str) -> str | None:
    """Return the skill/launcher token inside a single ``/vc-name`` line, else None."""
    match = _SLASH_SKILL_TOKEN.fullmatch(text.strip())
    return match.group(1) if match else None


def canonical_skill_file(name: str) -> Path | None:
    """Resolve ``SKILL.md`` from the running package, never a hardcoded checkout.

    ``resume`` and ``fork`` are launcher verbs. They yield None unless a real
    catalog skill file exists in this runtime.
    """
    token = str(name or "").strip().removeprefix("vc-")
    if not token or "/" in token or "\\" in token or ".." in token:
        return None
    path = skills_path() / f"vc-{token}" / "SKILL.md"
    try:
        return path if path.is_file() else None
    except OSError:
        return None


def compose_interactive_task_prompt(
    *,
    skill: str,
    source: str,
    root: str | os.PathLike[str],
    resume_block: str | None = None,
    admission: Mapping[str, Any] | None = None,
    parent_session_id: str = "",
) -> str:
    """Build the private ``prompt.md`` body for interactive init/operator/partner/resume/fork.

    Explicit role, canonical skill files when they exist, preserved extra,
    the shared VC identity contract, and the existing ``init_resume_block``
    projection. Empty extra is not a license to invent work. Does not wrap
    headless ``_runtime_prompt``.
    """
    launcher = str(skill or "init").strip() or "init"
    extra = source if isinstance(source, str) else str(source or "")
    duplicate_slash = slash_skill_name(extra) == launcher
    requested: list[str] = [launcher]
    for line in extra.splitlines():
        name = slash_skill_name(line)
        if name and name not in requested:
            requested.append(name)
    skill_lines: list[str] = []
    for name in requested:
        path = canonical_skill_file(name)
        if path is None:
            if name != launcher:
                skill_lines.append(
                    f"- `/vc-{name}` is not a skill file in this runtime; treat it as "
                    "operator text, not a slash-command expansion."
                )
            elif name in INTERACTIVE_LAUNCHERS - {"init", "operator", "partner"}:
                skill_lines.append(
                    f"- `{name}` is a launcher verb. There is no `vc-{name}/SKILL.md` "
                    "in this runtime catalog; do not invent one."
                )
            else:
                skill_lines.append(
                    f"- No `vc-{name}/SKILL.md` in this runtime; keep the launcher "
                    "role below and do not assume a provider slash command."
                )
            continue
        skill_lines.append(f"- `{name}` → read `{path}`")
    if resume_block is None:
        from .init_resume import init_resume_block

        resume_block = init_resume_block(root)
    role = _LAUNCHER_ROLE.get(
        launcher,
        "interactive launcher. Follow the role named above; do not invent a mission.",
    )
    from .monitor_lane import startup_lane_paragraph

    lane_run = str((admission or {}).get("run_id") or "")
    contract = agent_context_contract(
        skill=launcher,
        root=root,
        admission=admission,
        parent_session_id=parent_session_id,
        resume_block=resume_block or "",
    )
    lines = [
        "You are in an interactive Vibecrafted session.",
        "",
        f"Repository root: {root}",
        f"Launcher: {launcher}",
        f"Role: {role}",
        "",
        *render_agent_context_block(contract),
        "Your message inbox is attached to this run. At useful checkpoints and",
        'before finishing, run `vibecrafted message --run-id "$VIBECRAFTED_RUN_ID" --receive`.',
        "Handle each pending message here, then use `vibecrafted message",
        '--run-id "$VIBECRAFTED_RUN_ID" --ack MESSAGE_ID`. The inbox receipt',
        "alone does not mean you saw or acted on the message.",
        startup_lane_paragraph(lane_run),
        "",
        "This private task file is the complete orientation payload. Do not assume",
        "provider-specific slash commands execute from Markdown. Read the skill",
        "files named below (when present) instead of treating `/vc-*` tokens as",
        "executable commands.",
        "",
        "Skill and launcher resolution:",
        *(skill_lines or ["- No catalog skill file applies to this launcher."]),
        "",
    ]
    if launcher in {"init", "operator", "partner"}:
        lines.extend(
            [
                "Orientation (not a ship mission):",
                f"- Map: materialize the Loctree context atlas for {root} and read it to the end.",
                "- Intent: recover AICX history for why this tree is shaped this way.",
                "- Ground truth + risk: git/security sanity, then grade blast radius.",
                "- Stop after orientation unless the operator supplied a task below.",
                "",
            ]
        )
    else:
        lines.extend(
            [
                "Continuity: native session identity and continuity policy are already",
                "selected by this launcher. Keep them. Settlement counts are unfinished-work",
                "projection, not recovered conversation.",
                "",
            ]
        )
    if resume_block:
        lines.extend([resume_block.rstrip(), ""])
    if extra.strip() and not duplicate_slash:
        lines.extend(
            [
                "Operator-supplied extra (verbatim; preserve it, do not replace it):",
                extra.rstrip(),
                "",
            ]
        )
    else:
        lines.extend(
            [
                "No operator-supplied implementation task. Do not invent one from",
                "journals, settlements, or prior sessions.",
                "",
            ]
        )
    return "\n".join(lines)


@dataclass(frozen=True)
class ProviderPolicy:
    """Canonical provider/runtime/permission decision shared by CLI and UI."""

    provider: str
    runtime: str
    permissions: str
    mode: str
    supported: bool
    flags: tuple[str, ...] = ()
    behavior: str = ""
    reason: str = ""

    def as_dict(self) -> dict[str, Any]:
        return {
            "provider": self.provider,
            "runtime": self.runtime,
            "permissions": self.permissions,
            "mode": self.mode,
            "supported": self.supported,
            "status": "SUPPORTED" if self.supported else "UNSUPPORTED",
            "flags": list(self.flags),
            "behavior": self.behavior,
            "reason": self.reason,
        }


@dataclass(frozen=True)
class QuotaPolicy:
    """Validated User-selected policy for one interactive provider session."""

    kind: str
    token_budget: int | None
    selection: str
    warning: str = ""

    def as_dict(self) -> dict[str, Any]:
        return {
            "kind": self.kind,
            "token_budget": self.token_budget,
            "selection": self.selection,
            "warning": self.warning,
        }


@dataclass(frozen=True)
class OperatorAgentPolicy:
    """Typed decision for a distinct Operator Agent supervising one child Agent."""

    selection: str
    provider: str | None
    permissions: str | None
    supported: bool
    warning: str = ""
    reason: str = ""

    def as_dict(self) -> dict[str, Any]:
        return {
            "selection": self.selection,
            "provider": self.provider,
            "permissions": self.permissions,
            "supported": self.supported,
            "status": "SUPPORTED" if self.supported else "UNSUPPORTED",
            "warning": self.warning,
            "reason": self.reason,
        }


@dataclass(frozen=True)
class ContinuityPolicy:
    """One fail-closed continuity decision resolved before runtime truth."""

    mode: str
    lineage_id: str
    parent_provider_session_id: str = ""
    supported: bool = True
    reason: str = ""

    def as_dict(self) -> dict[str, Any]:
        return {
            "mode": self.mode,
            "lineage_id": self.lineage_id,
            "parent_provider_session_id": self.parent_provider_session_id,
            "supported": self.supported,
            "status": "SUPPORTED" if self.supported else "UNSUPPORTED",
            "reason": self.reason,
        }


@dataclass(frozen=True)
class ContinuityMaterial:
    """Private bounded transport material; receipts project hashes, not bodies."""

    policy: ContinuityPolicy
    prompt: str
    context_path: str = ""
    loop_state_path: str = ""
    context_sha256: str = ""
    loop_sha256: str = ""

    def receipt(self) -> dict[str, Any]:
        return {
            **self.policy.as_dict(),
            "context_sha256": self.context_sha256,
            "loop_sha256": self.loop_sha256,
            "materialized": bool(self.context_sha256 and self.loop_sha256)
            if self.policy.mode == "full-lineage"
            else True,
        }


@dataclass(frozen=True)
class ProviderUsageCapability:
    """Provider-specific proof that live usage can be attributed to one child."""

    provider: str
    supported: bool
    source: str = ""
    provider_version: str = ""
    reason: str = ""

    def as_dict(self) -> dict[str, Any]:
        return {
            "provider": self.provider,
            "supported": self.supported,
            "status": "SUPPORTED" if self.supported else "UNSUPPORTED",
            "source": self.source,
            "provider_version": self.provider_version,
            "reason": self.reason,
        }


@dataclass(frozen=True)
class InteractiveWorkspaceLaunch:
    """Durable parent/effective-root truth for one interactive Agent launch."""

    run_id: str
    provider: str
    runtime: str
    permissions: str
    parent_root: str
    effective_root: str
    workspace_id: str
    vibecrafted_session_id: str
    meta_path: Path
    receipt: dict[str, Any]
    quota_policy: QuotaPolicy
    usage_capability: ProviderUsageCapability
    provider_session_id: str
    worktree_manager: Any | None = field(default=None, repr=False, compare=False)
    worktree_geometry: Any | None = field(default=None, repr=False, compare=False)


_PERMISSION_CONTRACT: dict[str, dict[str, tuple[tuple[str, ...], str] | None]] = {
    "codex": {
        "bypass": (
            ("--dangerously-bypass-approvals-and-sandbox",),
            "all actions bypass approval and sandbox",
        ),
        "auto": (
            ("--ask-for-approval", "on-request", "--sandbox", "workspace-write"),
            "provider requests approval when needed",
        ),
        "accept-edits": None,
        "read-only": (
            ("--ask-for-approval", "never", "--sandbox", "read-only"),
            "writes and escalations fail closed",
        ),
    },
    "claude": {
        "bypass": (
            ("--permission-mode", "bypassPermissions"),
            "all actions bypass permission prompts",
        ),
        "auto": (
            ("--permission-mode", "auto"),
            "provider selects when to request permission",
        ),
        "accept-edits": (
            ("--permission-mode", "acceptEdits"),
            "edits pass; other actions require permission and fail closed without an operator",
        ),
        "read-only": (
            ("--permission-mode", "plan"),
            "plan mode prevents edits and execution",
        ),
    },
    "agy": {
        "bypass": (
            ("--dangerously-skip-permissions",),
            "all actions bypass permission prompts",
        ),
        "auto": ((), "provider default permission prompts remain active"),
        "accept-edits": (
            ("--mode", "accept-edits"),
            "edits pass; other actions require permission and fail closed without an operator",
        ),
        "read-only": (("--mode", "plan"), "plan mode prevents edits and execution"),
    },
    "grok": {
        "bypass": (
            ("--permission-mode", "bypassPermissions"),
            "all actions bypass permission prompts",
        ),
        "auto": (
            ("--permission-mode", "auto"),
            "provider selects when to request permission",
        ),
        "accept-edits": (
            ("--permission-mode", "acceptEdits"),
            "edits pass; other actions require permission and fail closed without an operator",
        ),
        "read-only": (
            ("--permission-mode", "plan"),
            "plan mode prevents edits and execution",
        ),
    },
    "junie": {
        "bypass": (("--brave",), "interactive brave mode bypasses confirmations"),
        "auto": ((), "provider default permission prompts remain active"),
        "accept-edits": None,
        "read-only": (
            ("--plan",),
            "interactive plan mode prevents edits and execution",
        ),
    },
    "cursor": {
        "bypass": (
            ("--force", "--trust"),
            "force-allow commands and trust the workspace without prompts",
        ),
        "auto": (
            ("--trust",),
            "trust workspace; provider default permission prompts remain active",
        ),
        "accept-edits": None,
        "read-only": (
            ("--mode", "ask", "--trust"),
            "ask mode is read-only Q&A; no edits or execution",
        ),
    },
    # kimi 0.42.0: unlike agy's single opt-in flag, kimi exposes BOTH
    # directions as explicit startup modes — --auto (Never Ask) and --yolo
    # (Ask When Needed) — plus --plan for read-only. All three are
    # interactive-only: the binary rejects every one of them with -p/--prompt
    # (OptionConflictError), and print mode always runs under kimi's auto
    # (never-ask) policy. See the headless overlay below.
    "kimi": {
        "bypass": (
            ("--auto",),
            "Never Ask mode: everything runs and is decided automatically",
        ),
        "auto": (
            ("--yolo",),
            "Ask When Needed: routine actions run automatically; risky actions, questions and plans still ask",
        ),
        "accept-edits": None,
        "read-only": (("--plan",), "plan mode prevents edits and execution"),
    },
    "copilot": {
        "bypass": (("--allow-all",), "all tools, paths, and URLs run without prompts"),
        "auto": ((), "provider asks for permission when needed"),
        "accept-edits": (
            ("--allow-tool=write",),
            "file edits pass; other tools can ask",
        ),
        "read-only": (("--available-tools=read",), "only the read tool is available"),
    },
    # omp 18.11.0: --approval-mode takes always-ask|write|yolo and combines with
    # -p/--print (verified: both flags accepted, rc 0). Tiers are capability ranks
    # (read < write < exec): yolo auto-approves everything, write auto-approves
    # read+write tiers (file edits) while exec-tier tools prompt, always-ask
    # prompts for write and exec (pi-coding-agent tools/approval.ts:
    # APPROVAL_MODE_MAX_TIER + modeApprovesTier). read-only has no mode of its
    # own; it is enforced by the --tools whitelist (only read-tier tools exist
    # in the session, so there is nothing left to prompt for).
    "omp": {
        "bypass": (
            ("--approval-mode", "yolo"),
            "approval mode yolo: every tool tier runs without prompts",
        ),
        "auto": (
            ("--approval-mode", "write"),
            "read+write tiers (incl. file edits) run automatically; exec-tier tools (bash etc.) prompt the operator",
        ),
        "accept-edits": (
            ("--approval-mode", "write"),
            "edits and other write-tier tools pass; exec-tier tools prompt and fail closed without an operator",
        ),
        "read-only": (
            ("--tools", "read,grep,glob,find"),
            "only read-tier tools are enabled; mutating tools are absent from the session",
        ),
    },
}


# Headless overlay: `codex exec` (codex-cli 0.154.0-alpha.3 --help) has no
# --ask-for-approval, so the interactive cells above would be rejected by the
# binary. exec offers --approve-for-me (automatic review inside the
# workspace-write sandbox) and -s/--sandbox; these cells carry the same meaning
# in the headless shape. Evidence: execution_controls.SANDBOX_EVIDENCE["codex"].
_HEADLESS_PERMISSION_CONTRACT: dict[str, dict[str, tuple[tuple[str, ...], str]]] = {
    "codex": {
        "auto": (
            ("--approve-for-me",),
            "codex reviews approvals automatically inside the workspace-write sandbox",
        ),
        "read-only": (
            ("--sandbox", "read-only"),
            "read-only sandbox; writes and escalations fail closed",
        ),
    },
    # kimi print mode never prompts (it always runs under the provider's auto
    # / never-ask policy, with static deny rules still in effect), and the
    # binary rejects --yolo/--auto/--plan combined with -p. Headless bypass is
    # therefore the no-flag truth: nothing to emit, nothing downgraded.
    # Headless auto / read-only stay refused in resolve_provider_policy —
    # "Ask When Needed" and plan mode are interactive-only surfaces.
    "kimi": {
        "bypass": (
            (),
            (
                "kimi print mode never prompts: it always runs under the provider's "
                "auto (never-ask) permission policy; --yolo/--auto/--plan cannot "
                "combine with --prompt, so no flag is emitted"
            ),
        ),
    },
    "copilot": {
        "bypass": (("--allow-all",), "all tools, paths, and URLs run without prompts"),
        "read-only": (
            ("--available-tools=read", "--no-ask-user"),
            "only the read tool is available",
        ),
    },
    # omp print mode accepts --approval-mode/--tools with -p (verified rc 0 on
    # 18.11.0), so the interactive cells carry over verbatim; only the behavior
    # text differs: a prompt in headless has no one to answer it, and omp fails
    # closed with a model-visible refusal (verified: the run ends, no hang).
    "omp": {
        "auto": (
            ("--approval-mode", "write"),
            "read+write tiers run automatically; an exec-tier prompt fails closed headless with a model-visible refusal (no TUI to answer it)",
        ),
        "accept-edits": (
            ("--approval-mode", "write"),
            "edits and other write-tier tools pass; an exec-tier prompt fails closed headless with a model-visible refusal",
        ),
    },
}


def resolve_quota_policy(
    selection: str | int | None,
    *,
    runtime: str,
    mode: str = "interactive",
) -> QuotaPolicy:
    """Validate one bounded or explicitly User-observed unlimited policy."""
    raw = "safe" if selection is None else str(selection).strip().lower()
    if not raw or raw == "safe":
        return QuotaPolicy("bounded", QUOTA_PRESET_TOKENS, "safe")
    if raw in {"unlimited", "unmetered"}:
        # Every local interactive environment is a Frame tab the User watches;
        # a separate checkout or a container does not make usage metering a
        # precondition. Missing metering is reported as "no data", never as a
        # refusal of a working environment.
        if mode != "interactive" or runtime not in USER_OBSERVED_RUNTIMES:
            raise ValueError(
                f"{raw} quota is restricted to directly User-observed interactive "
                f"sessions ({', '.join(USER_OBSERVED_RUNTIMES)})"
            )
        return QuotaPolicy(
            raw,
            None,
            raw,
            f"User selected {raw} usage; Vibecrafted will not terminate on token usage",
        )
    try:
        budget = int(raw, 10)
    except ValueError as exc:
        raise ValueError(
            "token budget must be safe, unlimited, unmetered, or a positive integer"
        ) from exc
    if budget <= 0:
        raise ValueError("token budget must be a positive integer")
    if budget > QUOTA_MAX_TOKENS:
        raise ValueError(f"token budget must not exceed {QUOTA_MAX_TOKENS}")
    return QuotaPolicy("bounded", budget, raw)


def _validated_continuity_id(value: str, *, label: str) -> str:
    normalized = str(value or "").strip()
    if not normalized or not _CONTINUITY_ID.fullmatch(normalized):
        raise ValueError(f"{label} must be one explicit, well-formed identifier")
    return normalized


def _ambient_parent_lineage(env: dict[str, str]) -> str:
    for name in (
        "VIBECRAFTED_RUN_ID",
        "CODEX_SESSION_ID",
        "CLAUDE_CODE_SESSION_ID",
        "VIBECRAFTED_OPERATOR_SESSION_ID",
    ):
        candidate = str(env.get(name) or "").strip()
        if candidate and _CONTINUITY_ID.fullmatch(candidate):
            return candidate
    return ""


def resolve_continuity_policy(
    selection: str | None,
    *,
    provider: str,
    parent_session_id: str = "",
    parent_lineage_id: str = "",
    env: dict[str, str] | None = None,
) -> ContinuityPolicy:
    """Resolve one continuity mode without inferring a native session target."""
    mode = str(selection or "fresh").strip().lower()
    if mode not in CONTINUITY_MODES:
        raise ValueError(
            f"unknown continuity mode {mode!r}; choose {', '.join(CONTINUITY_MODES)}"
        )
    ambient = dict(os.environ if env is None else env)
    if mode == "fresh":
        if parent_session_id or parent_lineage_id:
            raise ValueError(
                "fresh continuity rejects parent session and lineage input"
            )
        return ContinuityPolicy(mode="fresh", lineage_id=f"fresh:{uuid.uuid4()}")
    if mode == "full-lineage":
        if parent_session_id:
            raise ValueError("full-lineage never accepts a native parent session")
        lineage = parent_lineage_id or _ambient_parent_lineage(ambient)
        if not str(lineage or "").strip():
            # Missing lineage is a choice the User has to make, not a malformed
            # identifier; never guess one and never downgrade to fresh.
            raise ValueError(
                "full-lineage needs a parent lineage: choose a parent session "
                "(--continuity-parent <session-or-run-id>) or start with fresh memory"
            )
        return ContinuityPolicy(
            mode=mode,
            lineage_id=_validated_continuity_id(lineage, label="parent lineage id"),
        )

    parent = _validated_continuity_id(
        parent_session_id, label="bare-fork parent provider-session id"
    )
    if parent_lineage_id:
        raise ValueError("bare-fork accepts only an explicit provider-session parent")
    from .continuity.capabilities import (
        PROBE_CONFIRMED,
        SUPPORTED,
        capability_for,
        probe,
    )

    capability = capability_for(provider)
    if capability.native_fork != SUPPORTED:
        raise ValueError(
            f"bare-fork unsupported for {provider}: {capability.fork_runtime_restrictions}"
        )
    evidence = probe(provider, refresh=True)
    if evidence.state != PROBE_CONFIRMED:
        raise ValueError(
            f"bare-fork capability probe did not confirm {provider}: {evidence.detail}"
        )
    return ContinuityPolicy(
        mode=mode,
        lineage_id=parent,
        parent_provider_session_id=parent,
    )


def _sha256_file(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def _materialize_continuity(
    policy: ContinuityPolicy,
    *,
    provider: str,
    root: Path,
    run_id: str,
    prompt: str,
) -> ContinuityMaterial:
    if policy.mode != "full-lineage":
        return ContinuityMaterial(policy=policy, prompt=prompt)
    from .aicx_session_chain import (
        DEFAULT_RESUME_AICX_HOURS,
        CliSessionChain,
        assemble_resume_continuity_pack,
        pack_contains_recover_instruction,
    )

    loop_path = Path(
        os.environ.get("VIBECRAFTED_LOOP_STATE_FILE", "").strip()
        or root / ".vibecrafted" / "operator-loop.local.md"
    ).expanduser()
    try:
        loop_text = loop_path.read_text(encoding="utf-8")
    except (FileNotFoundError, OSError) as exc:
        raise ValueError(
            f"full-lineage requires readable current LOOP state: {exc}"
        ) from exc
    lines = loop_text.splitlines()
    fields: dict[str, str] = {}
    prompt_start = 0
    if lines[:1] == ["---"]:
        for index, line in enumerate(lines[1:], start=1):
            if line == "---":
                prompt_start = index + 1
                break
            if ":" in line:
                key, raw = line.split(":", 1)
                fields[key.strip()] = raw.strip().strip('"')
    loop_prompt = "\n".join(lines[prompt_start:]).strip()
    if fields.get("active") != "true" or not loop_prompt:
        raise ValueError(
            "full-lineage requires an active LOOP with a non-empty durable goal"
        )
    aicx_bin = which("aicx", path=agent_tool_search_path())
    if not aicx_bin:
        raise ValueError("full-lineage requires the aicx executable")
    run_dir = control_plane_home() / "runtime_runs" / run_id
    context_path = run_dir / "continuity-pack.md"
    meta_path = run_dir / "continuity-pack.meta.json"
    pack = assemble_resume_continuity_pack(
        agent=provider,
        root=root,
        hours=DEFAULT_RESUME_AICX_HOURS,
        context_file=context_path,
        meta_file=meta_path,
        chain=CliSessionChain(aicx_bin),
    )
    required_sections = (
        "## Session catalog",
        "## Continuity",
        "## Operator instruction",
    )
    if (
        pack.mode != "new_session"
        or pack.empty_kind != "none"
        or pack.session_count < 1
        or pack.degradations
        or not all(section in pack.body for section in required_sections)
        or pack_contains_recover_instruction(pack.body)
    ):
        context_path.unlink(missing_ok=True)
        meta_path.unlink(missing_ok=True)
        raise ValueError(
            "full-lineage continuity pack is empty, stale, degraded, or not new-session safe"
        )
    loop_copy = run_dir / "current-loop.md"
    loop_copy.write_text(loop_text, encoding="utf-8")
    bounded_prompt = (
        f"{prompt}\n\n"
        "Continuity mode: full-lineage. Start a new provider session; never attach.\n"
        f"Read bounded AICX continuity: {context_path}\n"
        f"Read durable current goal/LOOP: {loop_copy}\n"
        f"Parent lineage evidence: {policy.lineage_id}\n"
    )
    return ContinuityMaterial(
        policy=policy,
        prompt=bounded_prompt,
        context_path=str(context_path),
        loop_state_path=str(loop_copy),
        context_sha256=_sha256_file(context_path),
        loop_sha256=_sha256_file(loop_copy),
    )


_BOOTSTRAP_FLAGS = ("PYTHONNOUSERSITE", "PYTHONDONTWRITEBYTECODE")


def _is_runtime_owned_import_root(entry: str, environment: Mapping[str, str]) -> bool:
    """A ``PYTHONPATH`` entry inside a generation the runtime owns: the selected
    root, an owned ``releases/<gen>`` tree, or the generation whose raw
    interpreter is running this very process (the bootstrap's exec target)."""
    if is_owned_generation_path(entry, environment):
        return True
    bootstrap = _generation_bootstrap_for(sys.executable)
    if bootstrap is None:
        return False
    generation = str(bootstrap.parent.parent).rstrip("/")
    candidate = entry.rstrip("/")
    return candidate == generation or candidate.startswith(generation + "/")


def _scrub_runtime_bootstrap(child: dict[str, str]) -> dict[str, str]:
    """Drop the generation bootstrap's process state at the provider boundary.

    ``bin/python3`` exports ``PYTHONPATH=<gen>/vibecrafted-core:<gen>/vibecrafted-mcp:
    <gen>/python-site`` plus ``PYTHONNOUSERSITE``/``PYTHONDONTWRITEBYTECODE`` for
    the runtime's own interpreter. A provider -- and any project Python it runs
    -- must not inherit the runtime's private import roots (HAK-32). Only
    runtime-owned entries go; a Founder's own ``PYTHONPATH`` entries stay, and
    the two flags go only when a runtime-owned root was actually present, since
    the bootstrap is the one thing that exports the three together.
    """
    raw = child.get("PYTHONPATH", "")
    if not raw:
        return child
    entries = [entry for entry in raw.split(os.pathsep) if entry]
    kept = [
        entry for entry in entries if not _is_runtime_owned_import_root(entry, child)
    ]
    if len(kept) == len(entries):
        return child
    if kept:
        child["PYTHONPATH"] = os.pathsep.join(kept)
    else:
        child.pop("PYTHONPATH", None)
    for flag in _BOOTSTRAP_FLAGS:
        child.pop(flag, None)
    return child


def _fresh_child_environment(
    env: dict[str, str], policy: ContinuityPolicy
) -> dict[str, str]:
    child = dict(env)
    if policy.mode == "bare-fork":
        # The source is already pinned in native argv. Inherited parent IDs
        # cannot describe the new child, including calls to --session current.
        for name in (
            "CODEX_THREAD_ID",
            "CODEX_SESSION_ID",
            "CLAUDE_CODE_SESSION_ID",
            "GROK_SESSION_ID",
            "VIBECRAFTED_AGENT_SESSION_ID",
            "VIBECRAFTED_SESSION_ID",
            "VIBECRAFTED_PARENT_SESSION_ID",
        ):
            child.pop(name, None)
    if policy.mode == "fresh":
        for name in _INHERITED_CONTINUITY_ENV:
            child.pop(name, None)
        for name in tuple(child):
            if name.startswith(("VIBECRAFTED_RESUME_", "AICX_CONTINUITY_")):
                child.pop(name, None)
    return visible_color_environment(
        _scrub_runtime_bootstrap(managed_provider_environment(child))
    )


def continuity_policy_capabilities(
    provider: str,
    *,
    root: str | os.PathLike[str],
    explicit_parent: str = "",
    env: dict[str, str] | None = None,
) -> dict[str, dict[str, Any]]:
    """Project exact selector availability without materializing or spawning."""
    ambient = dict(os.environ if env is None else env)
    root_path = Path(root).expanduser().resolve()
    parent_lineage = explicit_parent or _ambient_parent_lineage(ambient)
    loop_path = Path(
        ambient.get("VIBECRAFTED_LOOP_STATE_FILE", "").strip()
        or root_path / ".vibecrafted" / "operator-loop.local.md"
    ).expanduser()
    full_reason = ""
    if not parent_lineage:
        full_reason = "no explicit/current parent lineage id"
    elif not loop_path.is_file():
        full_reason = f"current LOOP state missing: {loop_path}"
    elif which("aicx", path=agent_tool_search_path(ambient)) is None:
        full_reason = "aicx executable not found"
    else:
        try:
            loop_text = loop_path.read_text(encoding="utf-8")
        except OSError as exc:
            full_reason = f"current LOOP unreadable: {exc}"
        else:
            if (
                "active: true" not in loop_text
                or not loop_text.split("---")[-1].strip()
            ):
                full_reason = "current LOOP is inactive or has no durable goal"
    bare_reason = ""
    if not explicit_parent:
        bare_reason = "expert-only: provide an explicit parent provider-session id"
    else:
        try:
            resolve_continuity_policy(
                "bare-fork",
                provider=provider,
                parent_session_id=explicit_parent,
                env=ambient,
            )
        except ValueError as exc:
            bare_reason = str(exc)
    return {
        "full-lineage": {
            "available": not full_reason,
            "recommended": True,
            "reason": full_reason,
        },
        "fresh": {
            "available": True,
            "recommended": False,
            "reason": "no inherited memory is supplied",
        },
        "bare-fork": {
            "available": not bare_reason,
            "recommended": False,
            "reason": bare_reason,
        },
    }


def resolve_provider_usage_capability(
    provider: str,
    *,
    executable: str | None = None,
) -> ProviderUsageCapability:
    """Probe the exact installed executable for an attributable live source."""
    resolved = executable or which(
        agent_cli_name(provider), path=agent_tool_search_path()
    )
    if not resolved:
        return ProviderUsageCapability(
            provider, False, reason=f"{provider} executable not found"
        )
    resolved_path = str(Path(resolved).expanduser().resolve())
    try:
        stat = Path(resolved_path).stat()
    except OSError as exc:
        return ProviderUsageCapability(
            provider, False, reason=f"cannot inspect {provider} executable: {exc}"
        )
    return _probe_provider_usage_capability(
        provider, resolved_path, stat.st_mtime_ns, stat.st_size
    )


@lru_cache(maxsize=32)
def _probe_provider_usage_capability(
    provider: str,
    executable: str,
    _mtime_ns: int,
    _size: int,
) -> ProviderUsageCapability:
    if provider != "claude":
        return ProviderUsageCapability(
            provider,
            False,
            reason=(
                f"{provider} exposes no verified live, child-attributable, monotonic "
                "usage side channel compatible with inherited interactive TTY"
            ),
        )
    try:
        version_result = subprocess.run(
            [executable, "--version"],
            check=False,
            capture_output=True,
            text=True,
            timeout=5,
        )
        help_result = subprocess.run(
            [executable, "--help"],
            check=False,
            capture_output=True,
            text=True,
            timeout=5,
        )
    except (OSError, subprocess.TimeoutExpired) as exc:
        return ProviderUsageCapability(
            provider, False, reason=f"Claude capability probe failed: {exc}"
        )
    version = (version_result.stdout or version_result.stderr).splitlines()
    version_text = version[0].strip() if version else ""
    help_text = f"{help_result.stdout}\n{help_result.stderr}"
    if version_result.returncode != 0 or not version_text:
        return ProviderUsageCapability(
            provider,
            False,
            reason="Claude version probe did not return exact version truth",
        )
    if help_result.returncode != 0 or "--session-id <uuid>" not in help_text:
        return ProviderUsageCapability(
            provider,
            False,
            provider_version=version_text,
            reason="installed Claude does not expose --session-id <uuid>",
        )
    return ProviderUsageCapability(
        provider,
        True,
        source="claude-transcript-jsonl-v1",
        provider_version=version_text.split()[0],
    )


def resolve_provider_policy(
    provider: str,
    runtime: str,
    permissions: str,
    mode: str,
) -> ProviderPolicy:
    """Resolve one policy cell without approximating unsupported semantics."""
    if provider not in POLICY_PROVIDERS:
        raise ValueError(f"unsupported provider: {provider}")
    if runtime not in RUNTIME_POLICIES:
        raise ValueError(f"unsupported runtime policy: {runtime}")
    if permissions not in PERMISSION_POLICIES:
        raise ValueError(f"unsupported permission policy: {permissions}")
    if mode not in POLICY_MODES:
        raise ValueError(f"unsupported policy mode: {mode}")
    if runtime == "cloud-soon":
        return ProviderPolicy(
            provider,
            runtime,
            permissions,
            mode,
            False,
            reason="cloud runtime is coming soon",
        )
    if runtime == "local-vm":
        # The key names a persistent local *container* (dev_container), not a
        # VM. Policy answers only semantics; engine readiness is a capability.
        from .dev_container import CONTAINER_PROVIDERS

        if mode != "interactive":
            return ProviderPolicy(
                provider,
                runtime,
                permissions,
                mode,
                False,
                reason="the local container serves interactive Agent Workspaces only",
            )
        if provider not in CONTAINER_PROVIDERS:
            return ProviderPolicy(
                provider,
                runtime,
                permissions,
                mode,
                False,
                reason=(
                    f"{provider} is not installed in the local container recipe "
                    f"(it carries {', '.join(sorted(CONTAINER_PROVIDERS))})"
                ),
            )
    if runtime == "local-worktrees" and mode != "interactive":
        return ProviderPolicy(
            provider,
            runtime,
            permissions,
            mode,
            False,
            reason="local worktrees are available only for interactive Agent Workspaces",
        )
    cell = _PERMISSION_CONTRACT[provider][permissions]
    if mode == "headless":
        cell = _HEADLESS_PERMISSION_CONTRACT.get(provider, {}).get(permissions, cell)
    if cell is None:
        return ProviderPolicy(
            provider,
            runtime,
            permissions,
            mode,
            False,
            reason=f"{provider} exposes no native {permissions} policy",
        )
    if (
        provider == "junie"
        and mode == "headless"
        and permissions in {"bypass", "read-only"}
    ):
        return ProviderPolicy(
            provider,
            runtime,
            permissions,
            mode,
            False,
            reason=f"junie {permissions} is interactive-only",
        )
    if (
        provider == "kimi"
        and mode == "headless"
        and permissions in {"auto", "read-only"}
    ):
        # kimi 0.42.0 rejects --yolo/--plan combined with -p/--prompt
        # (OptionConflictError); print mode never requests approval, so an
        # "Ask When Needed" or plan-mode promise would be a receipted lie.
        return ProviderPolicy(
            provider,
            runtime,
            permissions,
            mode,
            False,
            reason=(
                f"kimi {permissions} is interactive-only: --prompt rejects the "
                "flag and print mode never prompts; explicitly select "
                "--permissions bypass for never-ask print mode"
            ),
        )
    if (
        provider == "copilot"
        and mode == "headless"
        and permissions in {"auto", "accept-edits"}
    ):
        return ProviderPolicy(
            provider,
            runtime,
            permissions,
            mode,
            False,
            reason="copilot headless cannot answer permission prompts; use bypass or read-only",
        )
    flags, behavior = cell
    return ProviderPolicy(provider, runtime, permissions, mode, True, flags, behavior)


def _materialize_cursor_permission_flags(
    flags: Sequence[str],
    *,
    permissions: str,
    executable: str | None = None,
    surface: Any | None = None,
) -> tuple[str, ...]:
    """Enforce cursor permission flags against the selected binary's --help.

    Declared contract flags are required semantics. Missing flags fail closed;
    they are never dropped to approximate an older CLI.
    """
    from .continuity.capabilities import (
        probe_cursor_cli_surface,
        reject_unsupported_cursor_argv,
        require_cursor_flags,
    )

    cli_surface = surface or probe_cursor_cli_surface(executable=executable)
    verified = require_cursor_flags(flags, cli_surface, permissions=permissions)
    reject_unsupported_cursor_argv(verified)
    return verified


def host_substrate_capabilities() -> dict[str, bool]:
    """Host substrate facts every runtime-policy availability row derives from.

    One probe owner for the interactive picker (``runtime_policy_capabilities``)
    and the machine-readable launcher catalog (``workflow_capabilities``), so a
    GUI/TUI client and the ``init`` picker can never disagree about whether the
    host can cut worktrees or has a VM substrate.
    """
    git_found = which("git") is not None
    try:
        from .dispatch.supervisor import run_dispatch

        dispatch_manages_worktrees = (
            "manage_worktrees" in inspect.signature(run_dispatch).parameters
        )
    except (ImportError, ValueError):
        dispatch_manages_worktrees = False
    return {
        "git": git_found,
        "dispatch_manages_worktrees": dispatch_manages_worktrees,
        "worktree_substrate": git_found and dispatch_manages_worktrees,
        "vm": which("docker") is not None or which("colima") is not None,
    }


def usage_metering(usage: ProviderUsageCapability) -> dict[str, Any]:
    """User-facing usage truth: live metering, or honest "no data"."""
    if usage.supported:
        return {"state": "live", "source": usage.source, "note": "live usage metering"}
    return {
        "state": "unavailable",
        "source": "",
        "note": "usage: no data (not metered for this provider)",
        "reason": usage.reason,
    }


def runtime_policy_capabilities(provider: str) -> dict[str, dict[str, Any]]:
    """Environment readiness per runtime; usage metering is reported, not gating.

    A separate checkout or a local container is a working environment whether
    or not the provider exposes live usage. Only an explicitly selected token
    limit needs metering, and that refusal lives in the quota admission.
    """
    provider_executable = which(agent_cli_name(provider), path=agent_tool_search_path())
    provider_found = provider_executable is not None
    usage = resolve_provider_usage_capability(provider, executable=provider_executable)
    metering = usage_metering(usage)
    substrate = host_substrate_capabilities()
    worktree_substrate = substrate["worktree_substrate"]
    from .dev_container import container_capability

    container = container_capability(provider)
    container_usage = container_usage_capability(provider)
    return {
        "local-native": {
            "available": provider_found,
            "usage_capability": usage.as_dict(),
            "metering": metering,
            "reason": ("" if provider_found else f"{provider} executable not found"),
        },
        "local-worktrees": {
            "available": provider_found and worktree_substrate,
            "substrate": worktree_substrate,
            "usage_capability": usage.as_dict(),
            "metering": metering,
            "reason": ""
            if provider_found and worktree_substrate
            else (
                f"{provider} executable not found"
                if not provider_found
                else "git/dispatch manage_worktrees unavailable"
            ),
        },
        "local-vm": {
            **container,
            "label": "local container",
            "usage_capability": container_usage.as_dict(),
            "metering": usage_metering(container_usage),
        },
        "cloud-soon": {"available": False, "reason": "coming soon"},
    }


def container_usage_capability(provider: str) -> ProviderUsageCapability:
    """Usage inside the local container is not attributable from the host."""
    return ProviderUsageCapability(
        provider,
        False,
        reason=(
            "usage inside the local container is not attributable from the host; "
            "choose no token limit"
        ),
    )


# Providers whose interactive CLI can re-open one exact native conversation.
INTERACTIVE_RESUME_PROVIDERS = frozenset(
    {"codex", "claude", "grok", "agy", "junie", "cursor", "omp"}
)


def interactive_resume_support(provider: str, runtime: str) -> tuple[bool, str]:
    """Whether resume of an exact conversation exists for this cell."""
    if provider not in INTERACTIVE_RESUME_PROVIDERS:
        return False, f"{provider} has no interactive resume of an exact session"
    if runtime == "local-vm":
        from .dev_container import CONTAINER_PROVIDERS

        if provider not in CONTAINER_PROVIDERS:
            return False, f"{provider} is not installed in the local container recipe"
    if runtime == "cloud-soon":
        return False, "cloud runtime is coming soon"
    return True, ""


def interactive_run_environment(meta: Mapping[str, Any]) -> str:
    """The runtime policy a recorded interactive run actually executed in."""
    if str(meta.get("runtime_policy") or "") == "local-vm" or meta.get("container"):
        return "local-vm"
    if str(meta.get("runtime_class") or "") == "local-worktrees" or meta.get(
        "worktree_path"
    ):
        return "local-worktrees"
    return "local-native"


def provider_session_exists(
    provider: str, session_id: str, *, env: Mapping[str, str]
) -> bool:
    """Check known provider stores without trusting historical run metadata.

    Other providers retain their existing admission policy. This is existence,
    not proof that a particular run opened or created the conversation.
    """
    if provider not in {"claude", "codex"}:
        return True
    if not session_id or "/" in session_id or "\\" in session_id:
        return False
    home = Path(env.get("HOME") or str(Path.home())).expanduser()
    identity = glob.escape(session_id)
    if provider == "claude":
        configured = str(env.get("CLAUDE_CONFIG_DIR") or "").strip()
        base = Path(configured).expanduser() if configured else home / ".claude"
        store = base / "projects"
        pattern = f"*/{identity}.jsonl"
    else:
        configured = str(env.get("CODEX_HOME") or "").strip()
        base = Path(configured).expanduser() if configured else home / ".codex"
        store = base / "sessions"
        # Native filenames: rollout-YYYY-MM-DDTHH-MM-SS-<session-id>.jsonl.
        # Bound traversal to the provider's YYYY/MM/DD layout; no content read.
        pattern = (
            f"[0-9][0-9][0-9][0-9]/[0-9][0-9]/[0-9][0-9]/rollout-*-{identity}.jsonl"
        )
    try:
        return any(path.is_file() for path in store.glob(pattern))
    except OSError:
        return False


def native_catalog_session_candidates(
    provider: str,
    root: str | os.PathLike[str],
    *,
    chain: SessionChain | None = None,
    env: Mapping[str, str] | None = None,
    limit: int = 40,
) -> list[dict[str, Any]]:
    """Existing host conversations, independent of control-plane run proof.

    AICX's owner/repo catalog can include sibling worktrees. Native resume
    additionally requires this exact checkout, provider and existing provider
    file. An ID discovered here never proves that a historical run opened it.
    """
    from .aicx_session_chain import (
        CliSessionChain,
        SessionChainError,
        project_filter_for_root,
    )

    # These are the provider stores provider_session_exists actually verifies.
    if provider not in {"claude", "codex"}:
        return []
    selected_root = Path(root).expanduser().resolve()
    project = project_filter_for_root(selected_root)
    if not project:
        return []
    environment = os.environ if env is None else env
    if chain is None:
        aicx = which("aicx", path=environment.get("PATH"))
        if not aicx:
            raise ValueError(
                "native session catalog unavailable: aicx executable not found"
            )
        chain = CliSessionChain(aicx)
    try:
        listing = chain.list_sessions(
            project=project,
            root=selected_root,
            agent=provider,
            hours=24 * 30,
            limit=limit,
        )
    except SessionChainError as exc:
        raise ValueError(f"native session catalog unavailable: {exc.kind}") from exc
    except OSError as exc:
        raise ValueError(
            "native session catalog unavailable: transport failed"
        ) from exc
    if getattr(listing, "empty_kind", "none") == "retrieval_unavailable":
        raise ValueError("native session catalog unavailable: retrieval_unavailable")
    candidates: dict[str, dict[str, Any]] = {}
    for row in listing.sessions:
        native = row.session_id
        if (
            row.agent != provider
            or not row.repo_path
            or native in {"current", "last", "previous"}
            or re.fullmatch(r"[A-Za-z0-9][A-Za-z0-9_-]*", native) is None
        ):
            continue
        try:
            if Path(row.repo_path).expanduser().resolve() != selected_root:
                continue
        except (OSError, RuntimeError):
            continue
        if not provider_session_exists(provider, native, env=environment):
            continue
        timestamp = None
        try:
            instant = dt.datetime.fromisoformat(row.updated_at)
            if instant.tzinfo is not None:
                timestamp = instant.astimezone(dt.UTC).timestamp()
        except ValueError:
            pass
        candidate = {
            "run_id": "",
            "session_id": native,
            "environment": "local-native",
            "root": str(selected_root),
            "branch": "",
            "updated_at": row.updated_at,
            "timestamp": timestamp,
            "identity_source": "native_provider_catalog",
        }
        previous = candidates.get(native)
        if previous is None or (
            timestamp is not None
            and (previous["timestamp"] is None or timestamp > previous["timestamp"])
        ):
            candidates[native] = candidate
    return sorted(
        candidates.values(),
        key=lambda item: (
            item["timestamp"] if item["timestamp"] is not None else float("-inf")
        ),
        reverse=True,
    )


def resumable_interactive_runs(
    provider: str,
    root: str | os.PathLike[str],
    runtime: str,
    *,
    limit: int = 20,
) -> list[dict[str, Any]]:
    """Recorded, settled conversations this provider can re-open here.

    Only runs with a provider-proven native session qualify: a requested ID or
    an AICX guess never becomes a resume target. Known host provider stores
    must still contain the conversation; historical proof stamps alone are unsafe.
    Each candidate keeps the environment and checkout it ran in, so resume
    returns to the same place.
    """
    from .workflow import _provider_session_for_continue, _read_json_object

    try:
        project = Path(root).expanduser().resolve()
    except OSError:
        return []
    runs_root = control_plane_home() / "runtime_runs"
    try:
        metas = sorted(
            runs_root.glob("*/meta.json"),
            key=lambda path: path.stat().st_mtime,
            reverse=True,
        )
    except OSError:
        return []
    found: list[dict[str, Any]] = []
    seen: set[str] = set()
    for path in metas[:400]:
        meta = _read_json_object(path)
        if str(meta.get("agent") or "") != provider:
            continue
        if not (meta.get("mode") == "interactive" or meta.get("requires_pty")):
            continue
        if str(meta.get("status") or "") in {"active", "prepared"}:
            continue
        if interactive_run_environment(meta) != runtime:
            continue
        owner = str(meta.get("parent_root") or meta.get("root") or "")
        try:
            if not owner or Path(owner).resolve() != project:
                continue
            checkout = Path(str(meta.get("root") or owner)).resolve()
        except OSError:
            continue
        if not checkout.is_dir():
            continue
        session = _provider_session_for_continue(meta)
        if not session or session in seen:
            continue
        # local-vm owns a separate store in its container's named volume;
        # absence from host HOME cannot disprove that conversation.
        if runtime != "local-vm" and not provider_session_exists(
            provider, session, env=os.environ
        ):
            continue
        seen.add(session)
        found.append(
            {
                "run_id": str(meta.get("run_id") or path.parent.name),
                "session_id": session,
                "environment": runtime,
                "root": str(checkout),
                "branch": str(meta.get("worktree_branch") or meta.get("branch") or ""),
                "updated_at": str(
                    meta.get("completed_at") or meta.get("updated_at") or ""
                ),
            }
        )
        if len(found) >= limit:
            break
    return found


def interactive_policy_command(
    provider: str,
    prompt: str,
    runtime: str,
    permissions: str,
    *,
    provider_session_id: str | None = None,
    continuity_policy: ContinuityPolicy | None = None,
    controls: ExecutionControls | None = None,
) -> list[str]:
    """Build one interactive argv from the canonical policy decision."""
    if controls is not None:
        if controls.provider != provider:
            raise ValueError("admitted controls do not match interactive provider")
        permissions = controls.permissions_effective
    decision = resolve_provider_policy(provider, runtime, permissions, "interactive")
    if not decision.supported:
        raise ValueError(decision.reason)
    flags = list(controls.provider_flags if controls is not None else decision.flags)
    continuity = continuity_policy or ContinuityPolicy("fresh", "fresh:implicit")
    if provider == "claude":
        session_flags = (
            ["--session-id", provider_session_id] if provider_session_id else []
        )
        if continuity.mode == "bare-fork":
            session_flags = [
                "--resume",
                continuity.parent_provider_session_id,
                "--fork-session",
                *session_flags,
            ]
        return ["claude", "--verbose", *flags, *session_flags, prompt]
    if provider == "codex":
        if continuity.mode == "bare-fork":
            return [
                "codex",
                "fork",
                *flags,
                continuity.parent_provider_session_id,
                prompt,
            ]
        return ["codex", *flags, prompt]
    if provider == "agy":
        return ["agy", *flags, "--add-dir", ".", "--prompt-interactive", prompt]
    if provider == "junie":
        return [
            "junie",
            *flags,
            f"--prompt={prompt}",
            "--project=.",
            "--skip-update-check",
            "--use-local-cache",
        ]
    if provider == "cursor":
        from .continuity.capabilities import (
            reject_unsupported_cursor_argv,
            validate_cursor_resume_chat_id,
        )

        session_flags: list[str] = []
        if continuity.mode == "bare-fork":
            # Interactive resume exists; bare-fork is unsupported — fail closed
            # rather than invent a fork flag the CLI does not expose. Reject
            # before probing cursor-agent: missing CLI is not this decision.
            raise ValueError(
                "cursor native fork is unsupported; use fresh or interactive --resume"
            )
        flags = list(
            _materialize_cursor_permission_flags(flags, permissions=permissions)
        )
        if provider_session_id:
            chat_id = validate_cursor_resume_chat_id(provider_session_id)
            session_flags = ["--resume", chat_id]
        argv = ["cursor-agent", *flags, *session_flags, prompt]
        reject_unsupported_cursor_argv(argv)
        return argv
    if provider == "grok":
        session_flags = []
        if continuity.mode == "bare-fork":
            session_flags = [
                "--resume",
                continuity.parent_provider_session_id,
                "--fork-session",
            ]
            if provider_session_id:
                session_flags.extend(["--session-id", provider_session_id])
        return [
            "grok",
            "--cwd",
            ".",
            *flags,
            *session_flags,
            "--no-alt-screen",
            prompt,
        ]
    if provider == "kimi":
        # Interactive kimi starts the TUI with no prompt on argv (a prompt
        # exists only as -p, which is non-interactive and conflicts with
        # --auto/--yolo/--plan); the operator types the slash command inside.
        return ["kimi", *flags]
    if provider == "copilot":
        if continuity.mode == "bare-fork":
            raise ValueError("copilot native fork is unsupported; use fresh or resume")
        session_flags = (
            ["--session-id", provider_session_id] if provider_session_id else []
        )
        return ["copilot", *flags, *session_flags, "-i", prompt]
    if provider == "omp":
        if continuity.mode == "bare-fork":
            raise ValueError(
                "omp native fork is unsupported; use fresh or interactive --resume"
            )
        return ["omp", *flags, prompt]
    raise ValueError(f"unsupported provider: {provider}")


def _generation_bootstrap_for(executable: str | os.PathLike[str]) -> Path | None:
    """``<generation>/bin/python3`` when *executable* is the raw
    ``python/bin/pythonX.Y`` of a stamped Runtime Pack generation, else ``None``.

    The path is read as invoked, never resolved: a generation's raw interpreter
    is what the bootstrap wrapper execs, and its physical target is not the
    generation.
    """
    raw = Path(executable)
    if raw.parent.name != "bin" or raw.parent.parent.name != "python":
        return None
    generation = raw.parent.parent.parent
    bootstrap = generation / "bin" / "python3"
    if not version_is_stamped(read_version_file(generation)):
        return None
    if not bootstrap.is_file() or not os.access(bootstrap, os.X_OK):
        return None
    return bootstrap


def interactive_launch_interpreter(
    environment: Mapping[str, str] | None = None,
) -> tuple[str, bool]:
    """The interpreter a pane may invoke by path and still reach core.

    Returns ``(argv0, bootstraps)``. A pane command script runs in the Frame
    server's fresh login shell: no ``PYTHONPATH``, nothing exported by the
    process that composed it. In a Runtime Pack that composer itself runs under
    the generation's ``bin/python3`` -- the bootstrap wrapper that exports the
    generation-private ``PYTHONPATH`` and execs the raw ``python/bin/python3.N``
    -- so ``sys.executable`` is the raw interpreter, and raw is exactly what
    the 8177a33d candidate wrote into the pane (``ModuleNotFoundError: No module
    named 'vibecrafted_core'`` before any provider ran).

    Ownership, in order: the selected generation (``VIBECRAFTED_RUNTIME_ROOT``,
    the contract every public launcher and the deck export; validated by
    :func:`selected_runtime_environment`, which names the generation's own
    ``bin/python3``); a raw interpreter sitting inside a stamped generation
    names that generation's bootstrap; anything else is a source lane and keeps
    ``sys.executable``. A malformed selected root is an identity failure and
    raises, as everywhere else on this route.
    """
    env = selected_runtime_environment(environment)
    if env.get("VIBECRAFTED_RUNTIME_ROOT"):
        return env["VIBECRAFTED_PYTHON"], True
    bootstrap = _generation_bootstrap_for(sys.executable)
    if bootstrap is not None:
        return str(bootstrap), True
    return sys.executable, False


def interactive_workspace_command(
    provider: str,
    prompt: str,
    runtime: str,
    permissions: str,
    root: str | os.PathLike[str],
    token_budget: str | int | None = None,
    operator: str = "none",
    continuity: str = "fresh",
    parent_session_id: str = "",
    parent_lineage_id: str = "",
    *,
    model: str = "",
    effort: str = "",
    source_file: str = "",
    base: str = "",
    worktree: str | bool | None = None,
    execution_runtime: str = "",
    skill: str = "init",
    native_session: str = "",
    parent_run_id: str = "",
    resume_run_id: str = "",
    resume_last: bool = False,
    session_selection: dict[str, Any] | None = None,
) -> list[str]:
    """Build the portable wrapper argv used by the exact ``init`` route.

    ``argv[0]`` is :func:`interactive_launch_interpreter`: in an installed
    generation the generation's own bootstrap, so the pane reaches core without
    any exported ``PYTHONPATH``. The explicit source-lane import root
    (``VIBECRAFTED_INTERACTIVE_IMPORT_ROOT``) is prefixed only in front of a
    plain interpreter; a bootstrap carries its own import path and would
    override the prefix anyway.
    """
    from .server_config import durable_permission_selection

    configured, source = durable_permission_selection(provider)
    controls = resolve_execution_controls(
        provider,
        permissions=permissions,
        configured_permissions=configured,
        permissions_source=source,
        mode="interactive",
    )
    decision = resolve_provider_policy(
        provider, runtime, controls.permissions_effective, "interactive"
    )
    if not decision.supported:
        raise ValueError(decision.reason)
    quota = resolve_quota_policy(token_budget, runtime=runtime)
    capability = (
        container_usage_capability(provider)
        if runtime == "local-vm"
        else resolve_provider_usage_capability(provider)
    )
    if quota.kind in {"safe", "bounded"} and not capability.supported:
        raise ValueError(
            f"token limit {quota.selection} needs live usage metering: {capability.reason}"
        )
    if runtime == "local-vm" and worktree not in (None, ""):
        from .workflow import parse_worktree_flag

        if parse_worktree_flag(worktree):
            raise ValueError(
                "choose one environment: the local container mounts the project "
                "checkout; a separate worktree is local-worktrees"
            )
    if runtime == "local-vm" and continuity == "bare-fork":
        raise ValueError(
            "bare-fork is not available in the local container; use fresh or full-lineage"
        )
    operator_policy = resolve_operator_agent_policy(operator, runtime=runtime)
    if not operator_policy.supported:
        raise ValueError(operator_policy.reason)
    continuity_policy = resolve_continuity_policy(
        continuity,
        provider=provider,
        parent_session_id=parent_session_id,
        parent_lineage_id=parent_lineage_id,
    )
    from .workflow import (
        _prepare_launch_worktree,
        _source_prompt,
        _write_prompt_file,
        launch_selection_receipt,
        normalize_launch_spec,
        reserve_run_id,
    )

    if skill not in {"init", "partner", "operator", "resume", "fork"}:
        raise ValueError("unsupported interactive launcher")
    if skill != "resume" and (native_session or resume_run_id or resume_last):
        raise ValueError(
            "session/run selectors apply to resume; fork uses its source identity"
        )
    if native_session and (resume_run_id or resume_last):
        raise ValueError("choose one identity: --session or --run-id")
    if native_session or session_selection is not None:
        from .workflow import resolve_session_selection

        session_selection = resolve_session_selection(
            provider,
            native_session,
            root,
            selection=session_selection,
        )
        if native_session:
            native_session = session_selection["agent_session_id"]
    parent = {}
    selected_model_source = ""
    if resume_last:
        from .cli import _run_for_agent

        if resume_run_id or native_session:
            raise ValueError("choose one resume identity")
        previous = _run_for_agent(provider, "", last=True)
        if not previous:
            raise ValueError("no previous run for this provider; pass --run-id")
        resume_run_id = str(previous["run_id"])
    if resume_run_id:
        from .repo_selection import resolve_repository_base
        from .workflow import (
            _merge_run_and_meta,
            _native_resume_meta,
            _provider_session_for_continue,
            _worker_process_alive,
            lookup_run,
            select_plan_model,
        )

        record = lookup_run(resume_run_id)
        if not record:
            raise ValueError("resume run not found")
        parent = _merge_run_and_meta(record, _native_resume_meta(resume_run_id, record))
        if parent.get("agent") != provider:
            raise ValueError("resume provider conflicts with recorded agent")
        if _worker_process_alive(parent):
            raise ValueError("resume session already has an active executor")
        recorded_runtime = str(parent.get("runtime_class") or "living-tree")
        if execution_runtime and execution_runtime != recorded_runtime:
            raise ValueError("resume preserves execution runtime; use fork")
        if worktree not in (None, ""):
            from .workflow import parse_worktree_flag

            if parse_worktree_flag(worktree) != (recorded_runtime == "local-worktrees"):
                raise ValueError(
                    "resume worktree selector conflicts with recorded runtime"
                )
        # An existing run owns its checkout. Matching selectors validate that
        # ownership; they must never create a second checkout during resume.
        # A container run re-enters the same project container: its provider
        # history lives in that container's volumes, not on the host.
        recorded_policy = str(parent.get("runtime_policy") or "")
        resumed_runtime = (
            "local-vm"
            if recorded_policy == "local-vm" or parent.get("container")
            else "local-native"
        )
        recorded_environment = (
            "local-vm"
            if resumed_runtime == "local-vm"
            else (
                "local-worktrees"
                if recorded_runtime == "local-worktrees"
                else "local-native"
            )
        )
        # local-native is the shell default when no environment was named.
        if runtime not in {"local-native", recorded_environment}:
            raise ValueError(
                f"resume preserves its environment ({recorded_environment}); "
                "use fork for another one"
            )
        execution_runtime, runtime, worktree = "living-tree", resumed_runtime, None
        parent_root = str(parent.get("root") or "")
        if root and Path(root).resolve() != Path(parent_root).resolve():
            raise ValueError("resume preserves repository; use fork")
        root = parent_root
        if base and resolve_repository_base(root, base)[1] != parent.get(
            "baseline_sha"
        ):
            raise ValueError("resume preserves baseline; use fork")
        native_session = _provider_session_for_continue(parent)
        if not native_session:
            raise ValueError("resume run has no verified native session identity")
        text = Path(source_file).read_bytes().decode("utf-8") if source_file else ""
        model, selected_model_source = select_plan_model(
            provider,
            text,
            model=model,
            previous=str(
                parent.get("model_effective")
                or parent.get("agent_model")
                or parent.get("model_requested")
                or ""
            ),
        )
        parent_run_id = resume_run_id
        session_selection = {
            "agent": provider,
            "agent_session_id": native_session,
            "session_selector": "run-id",
            "identity_source": "run_meta",
            "source_run_id": resume_run_id,
            "selection_root": str(Path(root).resolve()),
        }
        base = ""  # validate current checkout without changing historical baseline
    execution = execution_runtime or (
        "living-tree" if runtime in {"local-native", "local-vm"} else runtime
    )
    spec = normalize_launch_spec(
        {
            "agent": provider,
            "skill": "workflow",
            "prompt": prompt or f"/vc-{skill}",
            "file": source_file,
            "repo": str(root),
            "repo_selector": True,
            "base": base,
            "runtime_class": execution,
            "worktree": worktree,
            "model": model,
            "effort": effort,
            "runtime": "terminal",
            "permissions": permissions,
        },
        Path(__file__).parent,
        admission_controls=controls,
    )
    if spec.effort_source == "cli" and _effort_override_receipt(
        provider, spec.effort
    ).get("effort_override_skipped"):
        raise ValueError(f"Effort is unavailable for provider {provider}")
    source = _source_prompt(spec)
    if native_session:
        native_session = _validated_continuity_id(
            native_session, label="native session"
        )
        if provider not in {"codex", "claude", "grok", "agy", "junie", "cursor", "omp"}:
            raise ValueError(f"interactive native resume unsupported for {provider}")
        from .workflow import _worker_process_alive, find_run_for_identity_token

        existing = find_run_for_identity_token(native_session)
        if existing and _worker_process_alive(existing):
            raise ValueError("native session already has an active executor")
    run_id = reserve_run_id("rsme" if skill == "resume" else "init")
    run_dir = control_plane_home() / "runtime_runs" / run_id
    source_path = _write_prompt_file(run_dir / "plan-source.md", source)
    worktree_receipt = {}
    if spec.worktree:
        spec, worktree_receipt = _prepare_launch_worktree(spec, run_id)
    admission = {
        "run_id": run_id,
        "agent": provider,
        "skill": skill,
        "status": "prepared",
        "root": spec.root,
        "parent_root": spec.parent_root or spec.root,
        "effective_worker_root": spec.root,
        "repo_requested": spec.repo_requested,
        "repo_kind": spec.repo_kind,
        "base_requested": spec.base,
        "baseline_sha": spec.baseline_sha,
        "resolved_ref": spec.resolved_ref,
        "runtime_class": spec.runtime_class,
        "runtime_policy": runtime,
        "execution_environment": (
            "local-container"
            if runtime == "local-vm"
            else ("worktree" if spec.worktree else "checkout")
        ),
        "presentation": "visible",
        "requires_pty": True,
        "execution_controls": controls.receipt(),
        **launch_selection_receipt(spec),
        "source_snapshot": str(source_path),
        "source_digest": spec.source_digest,
        "source_path": source_file,
        "source_origin": "file" if source_file else "inline",
        "parent_run_id": parent_run_id or os.environ.get("VIBECRAFTED_RUN_ID", ""),
        "parent_session_id": parent_session_id,
        "agent_session_id": native_session,
        "native_child_session_id": native_session,
        "native_identity_status": "proven" if native_session else "unknown",
        "panel_id": _panel_identity(None),
        "session_selection": session_selection or {},
        **worktree_receipt,
    }
    if selected_model_source:
        admission["model_source"] = (
            "plan"
            if selected_model_source == "plan_frontmatter"
            else selected_model_source
        )
    bound_parent, bound_native = disjoint_session_identities(
        parent_session_id=parent_session_id,
        native_child_session_id=native_session,
    )
    admission["parent_session_id"] = bound_parent
    admission["agent_session_id"] = bound_native
    admission["native_child_session_id"] = bound_native
    admission["native_identity_status"] = "proven" if bound_native else "unknown"
    from .workspace_catalog import resolve_run_workspace_identity

    # Bind the selected seat before continuity scrubbing or terminal handoff.
    # The catalog owner validates inherited context against the explicit root.
    identity = resolve_run_workspace_identity(
        root=spec.root, env=os.environ, create_if_missing=True
    )
    admission.update(identity.to_meta_fields())
    if parent:
        admission["baseline_sha"] = parent.get("baseline_sha", "")
        admission["runtime_class"] = parent.get("runtime_class", "living-tree")
        # The resumed conversation keeps its project, checkout and container.
        admission["parent_root"] = str(
            parent.get("parent_root") or admission["parent_root"]
        )
        admission["runtime_policy"] = interactive_run_environment(parent)
        if admission["runtime_policy"] == "local-vm":
            admission["execution_environment"] = "local-container"
        for key in (
            "worktree",
            "worktree_path",
            "worktree_branch",
            "worktree_baseline_sha",
        ):
            if parent.get(key):
                admission[key] = parent[key]
    admission_path = _write_prompt_file(
        run_dir / "admission.json", json.dumps(admission)
    )
    _write_meta(run_dir / "meta.json", admission)
    append_event(
        "lifecycle:prepared",
        run_id,
        "interactive declaration admitted",
        {**admission, "meta": str(run_dir / "meta.json")},
    )
    _project_interactive_snapshot(run_id)
    print(
        f"run_id: {run_id}  model: {spec.model or 'provider_default'}  "
        f"model_source: {admission['model_source']}  "
        f"effort: {spec.effort or 'provider_default'}  effort_source: {spec.effort_source}",
        file=sys.stderr,
    )
    interpreter, bootstraps = interactive_launch_interpreter()
    command = [
        interpreter,
        "-m",
        "vibecrafted_core.spawn",
        "interactive-launch",
        provider,
        "--runtime",
        # Worktree preparation already happened above (root is the worktree);
        # the container is prepared by the launch owner inside the Frame tab.
        "local-vm" if runtime == "local-vm" else "local-native",
        "--permissions",
        controls.permissions_effective,
        "--token-budget",
        quota.selection,
        "--operator",
        operator_policy.selection,
        "--continuity",
        continuity_policy.mode,
        "--root",
        spec.root,
        "--admission-file",
        str(admission_path),
    ]
    if continuity_policy.parent_provider_session_id:
        command[command.index("--root") : command.index("--root")] = [
            "--parent-session",
            continuity_policy.parent_provider_session_id,
        ]
    elif continuity_policy.mode == "full-lineage":
        command[command.index("--root") : command.index("--root")] = [
            "--continuity-parent",
            continuity_policy.lineage_id,
        ]
    import_root = os.environ.get("VIBECRAFTED_INTERACTIVE_IMPORT_ROOT", "").strip()
    if import_root and not bootstraps:
        pythonpath = import_root
        if os.environ.get("PYTHONPATH"):
            pythonpath = f"{pythonpath}{os.pathsep}{os.environ['PYTHONPATH']}"
        return ["env", f"PYTHONPATH={pythonpath}", *command]
    return command


def resolve_operator_agent_policy(
    selection: str | None,
    *,
    runtime: str,
) -> OperatorAgentPolicy:
    """Resolve the only supported supervision shape without silent fallback."""
    normalized = (selection or "none").strip().lower()
    if normalized not in OPERATOR_POLICIES:
        return OperatorAgentPolicy(
            selection=normalized,
            provider=None,
            permissions=None,
            supported=False,
            reason=(
                f"unknown Operator Agent policy {normalized!r}; choose "
                f"{', '.join(OPERATOR_POLICIES)}"
            ),
        )
    if normalized == "none":
        return OperatorAgentPolicy(
            selection="none",
            provider=None,
            permissions=None,
            supported=True,
            warning=USER_OBSERVED_WARNING,
        )
    if runtime not in {"local-native", "local-worktrees"}:
        return OperatorAgentPolicy(
            selection=normalized,
            provider=None,
            permissions=None,
            supported=False,
            reason=(
                f"Operator Agent supervision is unavailable for runtime {runtime}; "
                "use local-native or local-worktrees"
            ),
        )
    return OperatorAgentPolicy(
        selection=normalized,
        provider="claude",
        permissions="accept-edits",
        supported=True,
    )


def prepare_interactive_workspace_launch(
    *,
    provider: str,
    runtime: str,
    permissions: str,
    selected_root: str | os.PathLike[str],
    prompt: str,
    run_id: str | None = None,
    executable: str | None = None,
    worker_pid: int | None = None,
    publish: bool = True,
    quota_policy: QuotaPolicy | None = None,
    usage_capability: ProviderUsageCapability | None = None,
    provider_session_id: str | None = None,
    continuity_material: ContinuityMaterial | None = None,
    workspace_identity: Mapping[str, Any] | None = None,
) -> InteractiveWorkspaceLaunch:
    """Resolve identity/root and publish truth only after launch preparation succeeds."""
    decision = resolve_provider_policy(provider, runtime, permissions, "interactive")
    if not decision.supported:
        raise ValueError(decision.reason)
    parent = Path(selected_root).expanduser().resolve()
    if not parent.is_dir():
        raise ValueError(f"selected workspace does not exist: {parent}")
    resolved_executable = executable or which(provider, path=agent_tool_search_path())
    if not resolved_executable:
        raise ValueError(f"{provider} executable not found")
    capability = usage_capability or resolve_provider_usage_capability(
        provider, executable=resolved_executable
    )
    if quota_policy is not None:
        quota = quota_policy
    else:
        quota = resolve_quota_policy(None, runtime=runtime)
    if quota.kind in {"safe", "bounded"} and not capability.supported:
        raise ValueError(capability.reason)
    effective_provider_session_id = provider_session_id or str(uuid.uuid4())
    try:
        uuid.UUID(effective_provider_session_id)
    except ValueError as exc:
        raise ValueError("provider session id must be a valid UUID") from exc

    from .dispatch.worktrees import (
        WorktreeContractError,
        WorktreeGeometry,
        WorktreeManager,
    )
    from .workflow import reserve_run_id
    from .workspace_catalog import read_catalog, resolve_run_workspace_identity

    identity_fields = {
        "workspace_id": "VIBECRAFTED_WORKSPACE_ID",
        "vibecrafted_session_id": "VIBECRAFTED_SESSION_ID",
        "workspace_instance_id": "VIBECRAFTED_WORKSPACE_INSTANCE_ID",
    }
    selected_identity = dict(workspace_identity or {})
    exact_seat = any(
        selected_identity.get(key)
        for key in ("vibecrafted_session_id", "workspace_instance_id")
    )
    identity_env = {}
    if exact_seat:
        if not all(selected_identity.get(key) for key in identity_fields):
            raise ValueError("interactive workspace identity is incomplete")
        record = read_catalog().workspaces.get(selected_identity["workspace_id"])
        if record is None or Path(record.canonical_root).resolve() != parent:
            raise ValueError("interactive workspace identity belongs to another root")
        identity_env = {
            env_key: str(selected_identity[key])
            for key, env_key in identity_fields.items()
        }

    effective_run_id = run_id or reserve_run_id("init")
    geometry: WorktreeGeometry | None = None
    effective = parent
    manager: WorktreeManager | None = None
    if runtime == "local-worktrees":
        manager = WorktreeManager(parent)
        baseline = _git_output(parent, "rev-parse", "HEAD")
        if not baseline:
            raise ValueError(f"selected workspace is not a git repository: {parent}")
        geometry = manager.prepare_agent_launch(provider, effective_run_id, baseline)
        effective = Path(geometry.worktree_path).resolve()

    try:
        identity = resolve_run_workspace_identity(
            root=parent, env=identity_env, create_if_missing=True
        )
        if exact_seat and any(
            identity.to_meta_fields()[key] != selected_identity[key]
            for key in identity_fields
        ):
            raise ValueError("interactive workspace identity changed before launch")
        now_iso = dt.datetime.now(dt.UTC).isoformat()
        run_dir = control_plane_home() / "runtime_runs" / effective_run_id
        prompt_path = run_dir / "prompt.md"
        prompt_path.parent.mkdir(parents=True, exist_ok=True)
        from .workflow import _write_prompt_file

        _write_prompt_file(prompt_path, prompt)
        meta_path = run_dir / "meta.json"
        owner_pid = int(worker_pid or os.getpid())
        receipt: dict[str, Any] = {
            "created_at": now_iso,
            "updated_at": now_iso,
            "started_at": now_iso,
            "status": "active" if publish else "prepared",
            "run_id": effective_run_id,
            "agent": provider,
            "skill": "init",
            "mode": "interactive",
            "runtime_policy": runtime,
            "permission_policy": permissions,
            "quota_policy": quota.as_dict(),
            "quota_warning": quota.warning,
            "usage_capability": capability.as_dict(),
            "usage_measurement": {
                "source": capability.source or "unmetered",
                "attribution": (
                    "provider_session_id+cwd+provider_version+message_id"
                    if capability.supported
                    else "unmetered"
                ),
                "monotonic": capability.supported,
            },
            "measured_usage": _empty_measured_usage(),
            "provider_session_id": effective_provider_session_id,
            "continuity": (
                continuity_material.receipt()
                if continuity_material is not None
                else ContinuityPolicy("fresh", f"fresh:{uuid.uuid4()}").as_dict()
            ),
            "root": str(effective),
            "parent_root": str(parent),
            "effective_worktree_path": str(effective) if geometry else "",
            "input": str(prompt_path),
            "owner_pid": owner_pid,
            "launcher_pid": owner_pid,
            "liveness": "active" if publish else "prepared",
            "executable": str(Path(resolved_executable).expanduser()),
            **identity.to_meta_fields(),
        }
        if publish:
            # Compatibility for direct preparation callers. The real interactive
            # owner replaces this with the provider child PID after Popen succeeds.
            receipt["worker_pid"] = owner_pid
        if geometry is not None:
            receipt.update(
                branch=geometry.branch,
                baseline_sha=geometry.baseline_sha,
                artifact_path=geometry.artifact_path,
            )
        if publish:
            _write_meta(meta_path, receipt)
            append_event(
                "lifecycle:active",
                effective_run_id,
                "interactive Agent Workspace is live",
                {**receipt, "meta": str(meta_path), "identity_required": True},
            )
    except Exception:
        if manager is not None and geometry is not None:
            try:
                manager.cleanup(geometry, settled=True)
            except (OSError, WorktreeContractError) as cleanup_exc:
                import logging

                logging.getLogger(__name__).warning(
                    "failed to remove unlaunched interactive worktree %s: %s",
                    geometry.worktree_path,
                    cleanup_exc,
                )
        raise
    return InteractiveWorkspaceLaunch(
        run_id=effective_run_id,
        provider=provider,
        runtime=runtime,
        permissions=permissions,
        parent_root=str(parent),
        effective_root=str(effective),
        workspace_id=identity.workspace_id,
        vibecrafted_session_id=identity.vibecrafted_session_id,
        meta_path=meta_path,
        receipt=receipt,
        quota_policy=quota,
        usage_capability=capability,
        provider_session_id=effective_provider_session_id,
        worktree_manager=manager,
        worktree_geometry=geometry,
    )


def _git_output(root: Path, *args: str) -> str:
    completed = subprocess.run(
        ["git", *args], cwd=root, check=False, capture_output=True, text=True
    )
    return completed.stdout.strip() if completed.returncode == 0 else ""


def _empty_measured_usage() -> dict[str, int]:
    """Zeroed receipt shape shared by unmetered and Claude session readers."""
    return {
        "input_tokens": 0,
        "cache_creation_input_tokens": 0,
        "cache_read_input_tokens": 0,
        "output_tokens": 0,
        "total_tokens": 0,
        "messages": 0,
        "foreign_workspace_events": 0,
    }


def _path_is_within(candidate: Path, root: str) -> bool:
    if not root:
        return False
    try:
        return candidate.is_relative_to(Path(root))
    except (ValueError, OSError):
        return False


class _UnmeteredUsage:
    """Null usage reader for providers lacking an attributable live side channel."""

    def poll(self) -> dict[str, int]:
        return _empty_measured_usage()


class _ClaudeTranscriptUsage:
    """Incremental, exact-session reader for Claude's provider-owned JSONL."""

    _FIELDS = (
        "input_tokens",
        "cache_creation_input_tokens",
        "cache_read_input_tokens",
        "output_tokens",
    )

    def __init__(
        self,
        *,
        provider_session_id: str,
        effective_root: str,
        provider_version: str,
        env: dict[str, str],
        run_id: str = "",
        run_root: str = "",
        resume: bool = False,
        fork_parent_session_id: str = "",
    ) -> None:
        configured = env.get("CLAUDE_CONFIG_DIR", "").strip()
        base = (
            Path(configured).expanduser()
            if configured
            else Path(env.get("HOME", str(Path.home()))).expanduser() / ".claude"
        )
        self.projects_root = (base / "projects").resolve()
        self.provider_session_id = provider_session_id
        self.effective_root = str(Path(effective_root).resolve())
        self.provider_version = provider_version.split()[0]
        self.run_id = run_id
        if run_root:
            self.run_root = str(Path(run_root).resolve())
        elif run_id:
            self.run_root = str(
                (control_plane_home() / "runtime_runs" / run_id).resolve()
            )
        else:
            self.run_root = ""
        self.path: Path | None = None
        self.identity: tuple[int, int] | None = None
        self.offset = 0
        self.seen_message_ids: set[str] = set()
        self.totals = {field: 0 for field in self._FIELDS}
        self.foreign_workspace_events = 0
        self.baseline_size = 0
        self.baseline_digest = ""
        self.validated_source_state: tuple[int, int, int] | None = None
        self.inherited_events: dict[str, str] = {}
        self.fork_parent_session_id = fork_parent_session_id
        self.resume = resume
        self.confirmed_session_id = ""
        if resume and fork_parent_session_id:
            raise ValueError("resume and fork usage boundaries are mutually exclusive")
        if fork_parent_session_id:
            if fork_parent_session_id == provider_session_id:
                raise ValueError("fork child must differ from parent session")
            parent = self._source_path(fork_parent_session_id)
            if parent is None:
                raise ValueError("fork parent usage source is missing")
            for event in self._history(parent, fork_parent_session_id):
                if isinstance(event.get("message"), dict) and isinstance(
                    event["message"].get("usage"), dict
                ):
                    key = event.get("uuid")
                    if not isinstance(key, str) or not key:
                        raise ValueError("fork history has no attributable event UUID")
                    self.inherited_events[key] = self._inherited_digest(event)
        if resume:
            if not self._bind_path():
                raise ValueError("resume usage source is missing")
            assert self.path is not None
            data = self.path.read_bytes()
            for event in self._history(self.path, provider_session_id, data=data):
                message = event.get("message")
                if isinstance(message, dict) and isinstance(message.get("id"), str):
                    self.seen_message_ids.add(message["id"])
                    if isinstance(message.get("usage"), dict):
                        key = event.get("uuid")
                        if not isinstance(key, str) or not key:
                            raise ValueError(
                                "resume history has no attributable event UUID"
                            )
                        self.inherited_events[key] = self._inherited_digest(
                            event, include_usage=True
                        )
            # Historical message IDs prevent replay, but are not this run's usage.
            self.historical_message_ids = self.seen_message_ids
            self.seen_message_ids = set()
            self.offset = self.baseline_size = len(data)
            self.baseline_digest = hashlib.sha256(data).hexdigest()
        else:
            self.historical_message_ids: set[str] = set()
            self._reject_existing_source()

    def _matching_paths(self) -> list[Path]:
        if not self.projects_root.is_dir():
            return []
        return list(self.projects_root.rglob(f"{self.provider_session_id}.jsonl"))

    def _source_path(self, session_id: str) -> Path | None:
        matches = list(self.projects_root.rglob(f"{session_id}.jsonl"))
        if not matches:
            return None
        if len(matches) != 1:
            raise RuntimeError("multiple provider usage sources claim one session id")
        candidate = matches[0]
        if candidate.is_symlink():
            raise RuntimeError("provider usage source must not be a symlink")
        resolved = candidate.resolve(strict=True)
        if not resolved.is_relative_to(self.projects_root):
            raise RuntimeError("provider usage source escaped provider projects root")
        if not resolved.is_file():
            raise RuntimeError("provider usage source is not a regular file")
        return resolved

    @staticmethod
    def _history(
        path: Path, session_id: str, *, data: bytes | None = None
    ) -> list[dict[str, Any]]:
        data = path.read_bytes() if data is None else data
        if data and not data.endswith(b"\n"):
            raise ValueError(
                "continuation usage source has an incomplete JSONL boundary"
            )
        events = []
        for line in data.splitlines():
            event = json.loads(line)
            if not isinstance(event, dict):
                raise TypeError("continuation history must contain JSON objects")
            if event.get("sessionId") not in (None, session_id):
                raise ValueError("continuation history belongs to a foreign session")
            events.append(event)
        return events

    @staticmethod
    def _inherited_digest(event: dict[str, Any], *, include_usage: bool = False) -> str:
        # Claude rewrites sessionId/slug/parentUuid and may recompute historical
        # usage. UUID + immutable message content/version/cwd prove inheritance.
        message = {
            key: value
            for key, value in event["message"].items()
            if include_usage or key != "usage"
        }
        payload = {key: event.get(key) for key in ("uuid", "type", "version", "cwd")}
        payload["message"] = message
        return hashlib.sha256(json.dumps(payload, sort_keys=True).encode()).hexdigest()

    def _reject_existing_source(self) -> None:
        if self._matching_paths():
            raise ValueError(
                "provider session usage source already exists; refusing stale or reused session identity"
            )

    def _bind_path(self) -> bool:
        resolved = self._source_path(self.provider_session_id)
        if resolved is None:
            return False
        stat = resolved.stat()
        self.path = resolved
        self.identity = (stat.st_dev, stat.st_ino)
        return True

    def poll(self) -> dict[str, int]:
        if self.path is None and not self._bind_path():
            return self.as_dict()
        assert self.path is not None
        if self.path.is_symlink():
            raise RuntimeError("provider usage source must not be a symlink")
        stat = self.path.stat()
        if self.identity != (stat.st_dev, stat.st_ino):
            raise RuntimeError("provider usage source identity changed during the run")
        if stat.st_size < self.offset:
            raise RuntimeError("provider usage source was truncated during the run")
        with self.path.open("rb") as handle:
            opened = os.fstat(handle.fileno())
            if self.identity != (opened.st_dev, opened.st_ino):
                raise RuntimeError(
                    "provider usage source identity changed during the run"
                )
            if (
                self.baseline_digest
                and self.validated_source_state
                != (opened.st_size, opened.st_mtime_ns, opened.st_ctime_ns)
                and hashlib.sha256(handle.read(self.baseline_size)).hexdigest()
                != self.baseline_digest
            ):
                raise RuntimeError(
                    "provider usage source history changed during the run"
                )
            self.validated_source_state = (
                opened.st_size,
                opened.st_mtime_ns,
                opened.st_ctime_ns,
            )
            handle.seek(self.offset)
            while True:
                line_start = handle.tell()
                line = handle.readline()
                if not line:
                    break
                if not line.endswith(b"\n"):
                    handle.seek(line_start)
                    break
                self._consume_line(line.decode("utf-8"))
            self.offset = handle.tell()
        return self.as_dict()

    def _consume_line(self, line: str) -> None:
        try:
            event = json.loads(line)
        except json.JSONDecodeError as exc:
            raise RuntimeError("provider usage source contains invalid JSONL") from exc
        if not isinstance(event, dict):
            raise TypeError("provider usage event must be a JSON object")
        message = event.get("message")
        inherited = self.inherited_events.get(event.get("uuid"))
        if inherited is not None:
            if event.get("sessionId") != self.provider_session_id and not (
                self.fork_parent_session_id
                and event.get("sessionId") == self.fork_parent_session_id
            ):
                raise RuntimeError(
                    "provider inherited event belongs to a foreign session"
                )
            if (
                not isinstance(message, dict)
                or self._inherited_digest(event, include_usage=self.resume) != inherited
            ):
                raise RuntimeError(
                    "provider continuation inherited event content changed"
                )
            if event.get("sessionId") == self.provider_session_id:
                self.confirmed_session_id = self.provider_session_id
            return
        if not isinstance(message, dict) or not isinstance(message.get("usage"), dict):
            return
        if message.get("id") in self.historical_message_ids:
            raise RuntimeError(
                "provider historical message has an unverified replay identity"
            )
        if event.get("sessionId") != self.provider_session_id:
            raise RuntimeError("provider usage event belongs to a foreign session")
        event_cwd = event.get("cwd")
        if not isinstance(event_cwd, str) or not event_cwd.strip():
            self.foreign_workspace_events += 1
            return
        if not self._cwd_is_own(event_cwd):
            self.foreign_workspace_events += 1
            return
        if event.get("version") != self.provider_version:
            raise RuntimeError(
                "provider usage event version differs from probed executable"
            )
        message_id = message.get("id")
        if not isinstance(message_id, str) or not message_id:
            raise RuntimeError("provider usage event has no attributable message id")
        if message_id in self.seen_message_ids:
            return
        usage = message["usage"]
        values: dict[str, int] = {}
        for field_name in self._FIELDS:
            value = usage.get(field_name, 0)
            if isinstance(value, bool) or not isinstance(value, int) or value < 0:
                raise RuntimeError(f"provider usage field {field_name} is invalid")
            values[field_name] = value
        self.confirmed_session_id = self.provider_session_id
        self.seen_message_ids.add(message_id)
        for field_name, value in values.items():
            self.totals[field_name] += value

    def confirm_fork_receipt(self, receipt: dict[str, Any]) -> bool:
        if (
            not receipt.get("native_fork")
            or not self.confirmed_session_id
            or receipt.get("native_identity_status") == "confirmed"
        ):
            return False
        child_id = self.confirmed_session_id
        receipt.update(
            provider_session_id=child_id,
            agent_session_id=child_id,
            native_child_session_id=child_id,
            native_identity_status="confirmed",
            native_identity_source="provider-session-usage-event",
        )
        print(
            f"Native fork confirmed: run_id={self.run_id} "
            f"source_session_id={self.fork_parent_session_id} agent_session_id={child_id}",
            file=sys.stderr,
            flush=True,
        )
        return True

    def _cwd_is_own(self, event_cwd: str) -> bool:
        """Count cwd inside effective_root or this run's control-plane directory."""
        try:
            resolved = Path(event_cwd).expanduser().resolve()
        except (OSError, RuntimeError, ValueError):
            return False
        return _path_is_within(resolved, self.effective_root) or _path_is_within(
            resolved, self.run_root
        )

    def as_dict(self) -> dict[str, int]:
        return {
            **self.totals,
            "total_tokens": sum(self.totals.values()),
            "messages": len(self.seen_message_ids),
            "foreign_workspace_events": self.foreign_workspace_events,
        }


def launch_interactive_workspace(
    provider: str,
    prompt: str,
    runtime: str,
    permissions: str,
    root: str | os.PathLike[str],
    token_budget: str | int | None = None,
    operator: str = "none",
    continuity: str = "fresh",
    parent_session_id: str = "",
    parent_lineage_id: str = "",
    *,
    admission: dict[str, Any] | None = None,
) -> int:
    """Own one provider child while preserving the inherited interactive TTY."""
    operator_policy = resolve_operator_agent_policy(operator, runtime=runtime)
    if not operator_policy.supported:
        raise ValueError(operator_policy.reason)
    from .workflow import reserve_run_id

    admission = dict(admission or {})
    controls = controls_from_receipt(admission.get("execution_controls") or {})
    if controls is None:
        from .server_config import durable_permission_selection

        configured, source = durable_permission_selection(provider)
        controls = resolve_execution_controls(
            provider,
            permissions=permissions,
            configured_permissions=configured,
            permissions_source=source,
            mode="interactive",
        )
    if controls.provider != provider:
        raise ValueError("admitted controls do not match interactive provider")
    permissions = controls.permissions_effective
    admission["execution_controls"] = controls.receipt()
    run_id = str(admission.get("run_id") or reserve_run_id("init"))
    try:
        continuity_policy = resolve_continuity_policy(
            continuity,
            provider=provider,
            parent_session_id=parent_session_id,
            parent_lineage_id=parent_lineage_id,
        )
        continuity_material = _materialize_continuity(
            continuity_policy,
            provider=provider,
            root=Path(root).expanduser().resolve(),
            run_id=run_id,
            prompt=prompt,
        )
    except ValueError as exc:
        now_iso = dt.datetime.now(dt.UTC).isoformat()
        failed = {
            "created_at": now_iso,
            "updated_at": now_iso,
            "completed_at": now_iso,
            "status": "failed",
            "liveness": "terminal",
            "terminal_reason": "continuity_validation_failed",
            "reason": str(exc),
            "run_id": run_id,
            "agent": provider,
            "skill": "init",
            "mode": "interactive",
            "root": str(Path(root).expanduser().resolve()),
            "continuity": {
                "mode": str(continuity or "fresh"),
                "lineage_id": str(parent_lineage_id or parent_session_id),
                "supported": False,
                "status": "UNSUPPORTED",
                "reason": str(exc),
            },
        }
        meta_path = control_plane_home() / "runtime_runs" / run_id / "meta.json"
        meta_path.parent.mkdir(parents=True, exist_ok=True)
        _write_meta(meta_path, failed)
        append_event(
            "lifecycle:failed",
            run_id,
            "continuity validation failed before provider spawn",
            {**failed, "meta": str(meta_path)},
        )
        _flush_terminal_projection(run_id, failed, meta_path=meta_path)
        raise
    if operator_policy.provider is not None:
        return _launch_supervised_interactive_workspace(
            provider=provider,
            prompt=continuity_material.prompt,
            runtime=runtime,
            permissions=permissions,
            root=root,
            token_budget=token_budget,
            operator_policy=operator_policy,
            run_id=run_id,
            continuity_material=continuity_material,
            admission=admission,
        )
    quota = resolve_quota_policy(token_budget, runtime=runtime)
    child_env = provider_workspace_environment(
        _fresh_child_environment(os.environ.copy(), continuity_policy), provider
    )
    parent_id, proven_native = disjoint_session_identities(
        parent_session_id=str(
            continuity_policy.parent_provider_session_id
            or admission.get("parent_session_id")
            or parent_session_id
            or ""
        ),
        native_child_session_id=str(admission.get("agent_session_id") or ""),
    )
    native_session = proven_native
    # Requested --session-id is not a native acknowledgement.
    provider_session_id = native_session or str(uuid.uuid4())
    command = interactive_policy_command(
        provider,
        f"Read and follow the private task file: {control_plane_home() / 'runtime_runs' / run_id / 'prompt.md'}",
        runtime,
        permissions,
        provider_session_id=provider_session_id,
        continuity_policy=continuity_policy,
        controls=controls,
    )
    if (
        continuity_policy.mode == "bare-fork"
        and admission.get("skill") == "fork"
        and provider != "codex"
    ):
        # The public bare fork has no task input. Open the native child idle:
        # the task-file pointer would only carry the shell's synthetic /vc-fork
        # marker. Codex drops it after its acknowledged thread/fork below.
        command.pop()
    _, native_session = disjoint_session_identities(
        parent_session_id=parent_id,
        native_child_session_id=str(admission.get("agent_session_id") or ""),
    )
    if native_session:
        if provider == "claude":
            if "--session-id" in command:
                index = command.index("--session-id")
                del command[index : index + 2]
            command[1:1] = ["--resume", native_session]
        elif provider == "codex":
            command[1:1] = ["resume", native_session]
        elif provider == "grok":
            command[1:1] = ["--resume", native_session]
        elif provider == "agy":
            command[1:1] = ["--conversation", native_session]
        elif provider == "junie":
            command[1:1] = ["--resume", "--session-id", native_session]
        elif provider == "cursor":
            pass  # interactive_policy_command already supplied the exact chat ID
        elif provider == "omp":
            command[1:1] = ["--resume", native_session]
        else:
            raise ValueError(f"interactive native resume unsupported for {provider}")
        provider_session_id = native_session
    command = _with_effort_override(
        provider,
        _with_model_override(
            provider, command, str(admission.get("model_requested") or "")
        ),
        str(admission.get("effort_requested") or ""),
    )
    container_runtime = runtime == "local-vm"
    if container_runtime:
        from .dev_container import CONTAINER_PROVIDERS, docker_cli

        if continuity_policy.mode == "bare-fork":
            raise ValueError("bare-fork is not available in the local container")
        # The provider binary lives in the container; the host only needs the
        # container CLI. Engine/daemon truth is re-probed by the preparation.
        resolved = [CONTAINER_PROVIDERS[provider], *command[1:]]
        capability = container_usage_capability(provider)
        launch_executable = docker_cli(child_env) or "docker"
    else:
        resolved = _resolve_agent_command(provider, command, child_env)
        capability = resolve_provider_usage_capability(provider, executable=resolved[0])
        launch_executable = resolved[0]
    # The same admission the composer and the preparation apply (80742a4c): a
    # measured budget needs a usage side channel; an unmetered declaration does
    # not. This owner kept the unconditional refusal, so every non-Claude
    # ``interactive-launch`` died here -- unseen while the installed pane could
    # not even reach core.
    if quota.kind in {"safe", "bounded"} and not capability.supported:
        raise ValueError(capability.reason)
    launch = prepare_interactive_workspace_launch(
        provider=provider,
        runtime=runtime,
        permissions=permissions,
        selected_root=root,
        prompt=continuity_material.prompt,
        run_id=run_id,
        executable=launch_executable,
        publish=False,
        quota_policy=quota,
        usage_capability=capability,
        provider_session_id=provider_session_id,
        continuity_material=continuity_material,
        workspace_identity=admission,
    )
    launch.receipt.update(admission)
    # A requested ID is not a provider acknowledgement. Codex fork does not
    # even accept our generated ID; process admission must not invent one.
    native_fork = continuity_policy.mode == "bare-fork"
    launch.receipt["parent_session_id"] = parent_id
    launch.receipt["native_child_session_id"] = native_session
    launch.receipt["native_identity_status"] = (
        "pending" if native_fork else ("proven" if native_session else "unknown")
    )
    if native_fork:
        launch.receipt["provider_session_id"] = ""
        launch.receipt["agent_session_id"] = ""
        launch.receipt.update(
            native_fork=True,
            fork_source_session_id=continuity_policy.parent_provider_session_id,
            provider_session_requested=(
                provider_session_id if "--session-id" in command else ""
            ),
        )
    else:
        launch.receipt["provider_session_id"] = provider_session_id
        launch.receipt["agent_session_id"] = native_session
        if not native_session:
            launch.receipt["provider_session_requested"] = provider_session_id
    launch.receipt["status"] = "prepared"
    if capability.supported and provider == "claude":
        try:
            usage_reader: Any = _ClaudeTranscriptUsage(
                provider_session_id=provider_session_id,
                effective_root=launch.effective_root,
                provider_version=capability.provider_version,
                env=child_env,
                run_id=launch.run_id,
                resume=bool(native_session),
                fork_parent_session_id=(parent_id if native_fork else ""),
            )
        except Exception:
            _cleanup_unspawned_interactive_launch(launch)
            raise
    else:
        usage_reader = _UnmeteredUsage()
    child_env.update(
        {
            "VIBECRAFTED_RUN_ID": launch.run_id,
            "VIBECRAFTED_SESSION_ID": launch.vibecrafted_session_id,
            "VIBECRAFTED_WORKSPACE_ID": launch.workspace_id,
            "VIBECRAFTED_WORKSPACE_INSTANCE_ID": str(
                launch.receipt["workspace_instance_id"]
            ),
            "VIBECRAFTED_BUILD_ID": str(launch.receipt["build_id"]["rendered"]),
            "VIBECRAFTED_PARENT_ROOT": launch.parent_root,
            "VIBECRAFTED_EFFECTIVE_ROOT": launch.effective_root,
            "VIBECRAFTED_AGENT_ROLE": "agent",
            "VIBECRAFTED_PROMPT_ROLE": str(admission.get("skill") or "init"),
            "VIBECRAFTED_CONTINUITY_MODE": continuity_policy.mode,
            "VIBECRAFTED_CONTINUITY_LINEAGE_ID": continuity_policy.lineage_id,
        }
    )
    if parent_id:
        child_env["VIBECRAFTED_PARENT_SESSION_ID"] = parent_id
    if native_fork and provider == "codex":
        from .continuity.native_fork import confirm_codex_native_fork

        # Persist pending before the native mutation: a lost acknowledgement
        # never becomes an invented child or an automatic retry of thread/fork.
        _write_meta(launch.meta_path, launch.receipt)
        try:
            identity = confirm_codex_native_fork(
                executable=resolved[0],
                env=child_env,
                root=launch.effective_root,
                parent=continuity_policy.parent_provider_session_id,
                run_id=launch.run_id,
                model=str(admission.get("model_requested") or ""),
                permissions=permissions,
            )
        except (ValueError, OSError) as exc:
            _terminalize_interactive_launch(
                launch,
                launch.receipt,
                status="failed",
                exit_code=1,
                terminal_reason="native_fork_identity_unconfirmed",
                error=str(exc),
            )
            return 1
        launch.receipt.update(identity)
        # This is an exact acknowledged native fork, not resume of the source.
        # Keep the selected executable, permission/model flags and transport.
        child_id = identity["provider_session_id"]
        resume_command = interactive_policy_command(
            provider, command[-1], runtime, permissions, controls=controls
        )
        if admission.get("skill") == "fork":
            # The public bare fork has no task input. Open the native child
            # idle; do not send the shell's synthetic /vc-fork skill marker.
            resume_command.pop()
        resume_command[1:1] = ["resume", child_id]
        resume_command = _with_effort_override(
            provider,
            _with_model_override(
                provider, resume_command, str(admission.get("model_requested") or "")
            ),
            str(admission.get("effort_requested") or ""),
        )
        resolved = [resolved[0], *resume_command[1:]]
        resolved.extend(["--cd", launch.effective_root])
        if child_env.get("CODEX_REMOTE"):
            resolved.extend(["--remote", child_env["CODEX_REMOTE"]])
        _write_meta(launch.meta_path, launch.receipt)
        print(
            f"Native fork confirmed: run_id={launch.run_id} "
            f"source_session_id={continuity_policy.parent_provider_session_id} "
            f"agent_session_id={child_id}",
            file=sys.stderr,
            flush=True,
        )
    container_target = None
    if container_runtime:
        prepared = _prepare_container_launch(
            launch,
            provider=provider,
            permissions=permissions,
            command=resolved,
            child_env=child_env,
            continuity_material=continuity_material,
        )
        if isinstance(prepared, int):
            return prepared
        resolved, container_target = prepared
    source_secret = prompt
    if admission.get("source_snapshot"):
        source_secret = Path(admission["source_snapshot"]).read_bytes().decode("utf-8")
    transcript = launch.meta_path.with_name("transcript.log")
    capture = InteractiveTranscriptCapture(transcript, source_secret)
    launch.receipt["transcript"] = str(transcript)
    launch.receipt["latest_transcript"] = str(transcript)
    spawned_epoch = time.time()
    try:
        child = subprocess.Popen(
            resolved,
            cwd=launch.effective_root,
            env=child_env,
            stdout=capture.slave,
            stderr=capture.slave,
        )
        capture.start()
    except (OSError, ValueError) as exc:
        capture.close()
        cleanup = _cleanup_unspawned_interactive_launch(launch)
        _terminalize_interactive_launch(
            launch,
            launch.receipt,
            status="failed",
            exit_code=2,
            terminal_reason="child_spawn_failed",
            error=str(exc),
            extra={"prepared_worktree_cleanup": cleanup},
        )
        raise

    now_iso = dt.datetime.now(dt.UTC).isoformat()
    receipt = {
        **launch.receipt,
        "updated_at": now_iso,
        "spawned_at": now_iso,
        "status": "active",
        "liveness": "active",
        "owner_pid": os.getpid(),
        "launcher_pid": os.getpid(),
        "worker_pid": child.pid,
        "role": "agent",
        "prompt_role": str(admission.get("skill") or "init"),
        "operator_policy": operator_policy.as_dict(),
        "supervision": {
            "mode": "user_observed",
            "state": "not_configured",
            "warning": operator_policy.warning,
        },
    }
    print(
        f"provider started: run_id={launch.run_id} provider={provider} pid={child.pid}",
        file=sys.stderr,
        flush=True,
    )
    received_signal: list[int] = []
    previous_handlers: dict[int, Any] = {}

    def _forward_owner_signal(signum: int, _frame: Any) -> None:
        first = not received_signal
        if first:
            received_signal.append(signum)
        if child.poll() is None:
            try:
                child.send_signal(signum)
            except ProcessLookupError:
                pass
        if first and container_target is not None:
            from .dev_container import terminate_provider_detached

            # A closed tab kills this owner moments later; the provider in
            # the container must not depend on this process surviving.
            terminate_provider_detached(container_target, launch.run_id, env=child_env)

    if threading.current_thread() is threading.main_thread():
        for signum in (
            signal.SIGINT,
            signal.SIGTERM,
            getattr(signal, "SIGHUP", signal.SIGTERM),
        ):
            if signum in previous_handlers:
                continue
            previous_handlers[signum] = signal.getsignal(signum)
            signal.signal(signum, _forward_owner_signal)
        if container_runtime and hasattr(signal, "SIGWINCH"):
            # `docker exec -t` reads the size from its stdout (the capture
            # PTY) when SIGWINCH arrives; the capture copies the pane size on
            # its own clock. Copy first, then re-signal the CLI, so the
            # container never keeps a stale geometry after a resize.
            def _forward_resize(_signum: int, _frame: Any) -> None:
                capture.sync_size()
                if child.poll() is None:
                    try:
                        child.send_signal(signal.SIGWINCH)
                    except ProcessLookupError:
                        pass

            previous_handlers[signal.SIGWINCH] = signal.getsignal(signal.SIGWINCH)
            signal.signal(signal.SIGWINCH, _forward_resize)

    # Publish the mandatory roles immediately after successful child creation.
    # The qualified process fingerprints travel with that first publication:
    # the canonical snapshot folds the lifecycle event, never the runtime meta,
    # and an idle provider proves it is alive only through its identity
    # receipt. Capture stays best-effort — a deterministic fast-exit provider
    # may already be terminal — and never delays the mandatory PID + role truth.
    _attach_interactive_process_identity(
        receipt, run_id=launch.run_id, worker_pid=child.pid
    )
    _write_meta(launch.meta_path, receipt)
    append_event(
        "lifecycle:active",
        launch.run_id,
        "interactive Agent Workspace provider child is live",
        {**receipt, "meta": str(launch.meta_path), "identity_required": True},
    )
    projection = _InteractiveProjection(
        run_id=launch.run_id, meta_path=launch.meta_path, receipt=receipt
    )
    projection.publish()
    quota_exhausted = False
    provider_returncode: int
    try:
        while True:
            current_returncode = child.poll()
            measured_usage = usage_reader.poll()
            if isinstance(
                usage_reader, _ClaudeTranscriptUsage
            ) and usage_reader.confirm_fork_receipt(receipt):
                _write_meta(launch.meta_path, receipt)
            if measured_usage != receipt["measured_usage"]:
                receipt["measured_usage"] = measured_usage
                receipt["updated_at"] = dt.datetime.now(dt.UTC).isoformat()
                _write_meta(launch.meta_path, receipt)
            # Owned recovery of a deferred ACTIVE publication: same owner,
            # same poll loop, no observer required while the provider idles.
            projection.pump()
            if (
                current_returncode is None
                and not received_signal
                and quota.token_budget is not None
                and measured_usage["total_tokens"] >= quota.token_budget
            ):
                quota_exhausted = True
                child.terminate()
                try:
                    provider_returncode = child.wait(timeout=5)
                except subprocess.TimeoutExpired:
                    child.kill()
                    provider_returncode = child.wait()
                break
            if current_returncode is not None:
                provider_returncode = current_returncode
                break
            time.sleep(0.05)
    except Exception as exc:
        if child.poll() is None:
            child.terminate()
            try:
                child.wait(timeout=5)
            except subprocess.TimeoutExpired:
                child.kill()
                child.wait()
        if container_target is not None:
            from .dev_container import terminate_provider

            receipt["container_provider_teardown"] = terminate_provider(
                container_target, launch.run_id, env=child_env
            )
        _terminalize_interactive_launch(
            launch,
            receipt,
            status="failed",
            exit_code=1,
            terminal_reason="killed_after_start",
            error=str(exc),
        )
        raise
    finally:
        capture.close()
        if capture.error:
            receipt["transcript_error"] = capture.error
        for signum, handler in previous_handlers.items():
            signal.signal(signum, handler)

    shell_status = (
        128 + abs(provider_returncode)
        if provider_returncode < 0
        else provider_returncode
    )
    if quota_exhausted:
        status = "quota_exhausted"
        terminal_reason = "quota_exhausted"
        shell_status = QUOTA_EXHAUSTED_EXIT_CODE
    elif received_signal:
        owner_signal = received_signal[0]
        status = "cancelled"
        terminal_reason = f"owner_signal:{signal.Signals(owner_signal).name}"
        if shell_status == 0:
            shell_status = 128 + owner_signal
    elif provider_returncode < 0:
        status = "cancelled"
        terminal_reason = (
            f"provider_signal:{signal.Signals(abs(provider_returncode)).name}"
        )
    elif (
        provider_returncode == 0
        and native_fork
        and receipt.get("native_identity_status") != "confirmed"
    ):
        # No terminal success without a child identity from the provider.
        status = "failed"
        terminal_reason = "native_fork_identity_unconfirmed"
        shell_status = 1
    elif provider_returncode == 0:
        status = "completed"
        terminal_reason = "provider_exit_zero"
    else:
        status = "failed"
        terminal_reason = "provider_exit_nonzero"
    # A closed tab may hard-kill this owner shortly after its hangup: publish
    # the terminal state first, then end the container provider and bind the
    # provider's own session evidence as a follow-up write.
    terminal = _terminalize_interactive_launch(
        launch,
        receipt,
        status=status,
        exit_code=shell_status,
        terminal_reason=terminal_reason,
        exit_signal=abs(provider_returncode) if provider_returncode < 0 else None,
    )
    _settle_interactive_aftermath(
        launch,
        terminal,
        provider=provider,
        child_env=child_env,
        container_target=container_target,
        since=spawned_epoch,
    )
    return shell_status


def _ask_container_retry(stage: str) -> bool:
    """Ask the User in the Agent tab whether to retry a failed preparation."""
    stream = sys.stdin
    if stream is None or not stream.isatty():
        return False
    print(
        f"[r] retry {stage} · [q] cancel this Agent tab: ",
        end="",
        file=sys.stderr,
        flush=True,
    )
    try:
        answer = stream.readline()
    except (KeyboardInterrupt, OSError):
        return False
    return answer.strip().lower() in {"r", "retry", "y", "yes"}


def _interactive_run_owner_alive(run_id: str) -> bool:
    """Whether a recorded interactive run still has its owner process.

    The qualified owner receipt (start token, command hash, pgid) decides when
    present: a reused PID is not the owner. Without a usable receipt the
    numeric PID is the conservative answer -- a reused PID can keep an orphan
    alive until the next sweep, but never ends a live Agent.
    """
    meta = _read_meta(control_plane_home() / "runtime_runs" / run_id / "meta.json")
    if not meta or meta.get("liveness") == "terminal":
        return False
    try:
        owner = int(meta.get("owner_pid") or meta.get("launcher_pid") or 0)
    except (TypeError, ValueError):
        return False
    if owner <= 0:
        return False
    receipt = meta.get("owner_identity")
    if isinstance(receipt, Mapping):
        from .process_control import validate_process_identity

        try:
            current, reason, _identity = validate_process_identity(
                receipt,
                expected_pid=owner,
                expected_pgid=None,
                expected_run_id=run_id,
            )
        except (OSError, RuntimeError, ValueError):
            current, reason = False, "process_identity_unavailable"
        # The validator compares start token and command before the run-id
        # env evidence: a run-id mismatch is still the same process (a pane can
        # carry another ambient run id), so it is the owner, alive.
        if current or reason == "process_run_id_mismatch":
            return True
        if reason in {"process_identity_gone", "process_identity_mismatch"}:
            return False
    try:
        os.kill(owner, 0)
    except ProcessLookupError:
        return False
    except PermissionError:
        return True
    return True


def _prepare_container_launch(
    launch: InteractiveWorkspaceLaunch,
    *,
    provider: str,
    permissions: str,
    command: list[str],
    child_env: dict[str, str],
    continuity_material: ContinuityMaterial,
) -> tuple[list[str], Any] | int:
    """Ready the project's container in front of the User, then wrap the argv.

    Every stage prints into this Agent tab before the provider starts: the
    image (built only when the recipe digest changed), the container start, the
    workspace mount. A failure keeps its exact cause and offers retry or
    cancel; nothing falls back to running the provider on the host.
    """
    from . import dev_container

    def log(line: str) -> None:
        print(line, file=sys.stderr, flush=True)

    log(
        f"Preparing the local container for {provider} · "
        f"{Path(launch.parent_root).name} — a Docker container, not a VM; "
        f"the project is mounted at {dev_container.WORKDIR}."
    )
    while True:
        try:
            try:
                target = dev_container.ensure_container(
                    launch.effective_root, env=child_env, log=log
                )
            except KeyboardInterrupt as interrupt:
                raise dev_container.ContainerCancelled() from interrupt
            break
        except dev_container.ContainerCancelled as exc:
            _terminalize_interactive_launch(
                launch,
                launch.receipt,
                status="cancelled",
                exit_code=130,
                terminal_reason="container_prepare_cancelled",
                error=str(exc),
            )
            log("Local container preparation cancelled; nothing was started.")
            return 130
        except dev_container.ContainerError as exc:
            log(f"\nLocal container is not ready ({exc.stage}): {exc}")
            if _ask_container_retry(exc.stage):
                continue
            _terminalize_interactive_launch(
                launch,
                launch.receipt,
                status="failed",
                exit_code=1,
                terminal_reason=f"container_{exc.stage}_failed",
                error=str(exc),
            )
            return 1
    swept = dev_container.sweep_orphan_providers(
        target, is_live=_interactive_run_owner_alive, env=child_env
    )
    if swept:
        launch.receipt["container_orphans_ended"] = swept
        log(
            f"Ended {len(swept)} Agent(s) left running by closed tabs: {', '.join(swept)}"
        )
    host_prompt = str(launch.meta_path.with_name("prompt.md"))
    text = Path(host_prompt).read_text(encoding="utf-8")
    try:
        for host_file, name in (
            (continuity_material.context_path, "continuity-pack.md"),
            (continuity_material.loop_state_path, "current-loop.md"),
        ):
            if host_file:
                staged = dev_container.stage_text(
                    target,
                    launch.run_id,
                    name,
                    Path(host_file).read_text(encoding="utf-8"),
                    env=child_env,
                )
                text = text.replace(host_file, staged)
        text = text.replace(launch.effective_root, dev_container.WORKDIR)
        container_prompt = dev_container.stage_text(
            target, launch.run_id, "prompt.md", text, env=child_env
        )
    except (OSError, dev_container.ContainerError) as exc:
        _terminalize_interactive_launch(
            launch,
            launch.receipt,
            status="failed",
            exit_code=1,
            terminal_reason="container_stage_failed",
            error=str(exc),
        )
        log(f"Cannot hand the task to the container: {exc}")
        return 1
    argv = [arg.replace(host_prompt, container_prompt) for arg in command]
    extra = {"VIBECRAFTED_RUN_ID": launch.run_id}
    if provider == "claude" and permissions == "bypass":
        # Claude refuses its bypass flag as root outside a declared sandbox;
        # the container is that sandbox.
        extra["IS_SANDBOX"] = "1"
    wrapped = dev_container.exec_argv(
        target,
        argv,
        run_id=launch.run_id,
        pass_names=dev_container.credential_names(provider, child_env),
        extra_env=extra,
    )
    launch.receipt.update(
        container=target.receipt(),
        execution_environment="local-container",
        provider_cwd=dev_container.WORKDIR,
        container_prompt=container_prompt,
    )
    log(f"Starting {provider} in {target.container_name}…")
    return wrapped, target


def _prove_host_native_session(
    provider: str,
    *,
    requested: str,
    effective_root: str,
    env: Mapping[str, str],
    since: float,
) -> str:
    """Provider-owned on-disk evidence of the conversation this run created."""
    if provider == "claude" and requested:
        return (
            requested if provider_session_exists(provider, requested, env=env) else ""
        )
    if provider == "codex":
        from .compact_hooks import session_meta_from_jsonl

        home = Path(env.get("HOME") or str(Path.home())).expanduser()
        codex_home = Path(
            str(env.get("CODEX_HOME") or "").strip() or home / ".codex"
        ).expanduser()
        sessions = codex_home / "sessions"
        try:
            target_root = str(Path(effective_root).resolve())
        except OSError:
            return ""
        found: set[str] = set()
        day = dt.datetime.fromtimestamp(since - 86400, dt.UTC).date()
        today = dt.datetime.now(dt.UTC).date()
        while day <= today + dt.timedelta(days=1):
            folder = sessions / f"{day:%Y}" / f"{day:%m}" / f"{day:%d}"
            day += dt.timedelta(days=1)
            if not folder.is_dir():
                continue
            for path in folder.glob("rollout-*.jsonl"):
                try:
                    if path.stat().st_mtime < since - 1:
                        continue
                except OSError:
                    continue
                meta = session_meta_from_jsonl(path)
                if meta.get("cwd") == target_root and meta.get("id"):
                    found.add(meta["id"])
        return found.pop() if len(found) == 1 else ""
    return ""


def _record_native_identity_after_exit(
    receipt: dict[str, Any],
    *,
    provider: str,
    run_id: str,
    effective_root: str,
    child_env: Mapping[str, str],
    container_target: Any | None,
    since: float,
) -> None:
    """Bind the run to its provider conversation only on provider-owned evidence.

    A requested ``--session-id`` is not an acknowledgement; the provider's own
    session file is. Exactly one match or nothing -- never a guess -- so a
    later resume returns to the right conversation in the right environment.
    """
    if receipt.get("native_fork") or str(receipt.get("agent_session_id") or ""):
        return
    requested = str(
        receipt.get("provider_session_requested")
        or receipt.get("provider_session_id")
        or ""
    )
    try:
        if container_target is not None:
            from .dev_container import prove_native_session

            identity = prove_native_session(
                container_target,
                provider,
                run_id,
                requested=requested,
                env=child_env,
            )
            source = "container-provider-session-file"
        else:
            identity = _prove_host_native_session(
                provider,
                requested=requested,
                effective_root=effective_root,
                env=child_env,
                since=since,
            )
            source = "provider-session-file"
    except (OSError, ValueError, RuntimeError):
        return
    if not identity:
        return
    receipt.update(
        agent_session_id=identity,
        native_child_session_id=identity,
        provider_session_id=identity,
        native_identity_status="proven",
        native_identity_source=source,
    )


def _settle_interactive_aftermath(
    launch: InteractiveWorkspaceLaunch,
    terminal: dict[str, Any],
    *,
    provider: str,
    child_env: dict[str, str],
    container_target: Any | None,
    since: float,
) -> None:
    """Container teardown and native-session evidence after the terminal write."""
    settled = dict(terminal)
    if container_target is not None:
        from .dev_container import terminate_provider

        # The tab owns the provider: whatever ended the host-side client
        # (exit, closed tab, signal), nothing keeps running in the container.
        settled["container_provider_teardown"] = terminate_provider(
            container_target, launch.run_id, env=child_env
        )
    _record_native_identity_after_exit(
        settled,
        provider=provider,
        run_id=launch.run_id,
        effective_root=launch.effective_root,
        child_env=child_env,
        container_target=container_target,
        since=since,
    )
    if settled != terminal:
        _write_meta(launch.meta_path, settled)


def _launch_supervised_interactive_workspace(
    *,
    provider: str,
    prompt: str,
    runtime: str,
    permissions: str,
    root: str | os.PathLike[str],
    token_budget: str | int | None,
    operator_policy: OperatorAgentPolicy,
    run_id: str,
    continuity_material: ContinuityMaterial,
    admission: dict[str, Any] | None = None,
) -> int:
    """Own one child and one distinct supervisor on the existing lifecycle throne."""
    assert operator_policy.provider is not None
    admission = admission or {}
    quota = resolve_quota_policy(token_budget, runtime=runtime)
    continuity_policy = continuity_material.policy
    base_env = _fresh_child_environment(os.environ.copy(), continuity_policy)
    parent_id, proven_native = disjoint_session_identities(
        parent_session_id=str(
            continuity_policy.parent_provider_session_id
            or admission.get("parent_session_id")
            or ""
        ),
        native_child_session_id=str(admission.get("agent_session_id") or ""),
    )
    native_session = proven_native if provider == "claude" else ""
    native_fork = provider == "claude" and continuity_policy.mode == "bare-fork"
    child_session_id = native_session or str(uuid.uuid4())
    child_command = interactive_policy_command(
        provider,
        f"Read and follow the private task file: {control_plane_home() / 'runtime_runs' / run_id / 'prompt.md'}",
        runtime,
        permissions,
        provider_session_id=child_session_id,
        continuity_policy=continuity_policy,
    )
    if native_session:
        if "--session-id" in child_command:
            index = child_command.index("--session-id")
            del child_command[index : index + 2]
        child_command[1:1] = ["--resume", native_session]
    if native_fork and admission.get("skill") == "fork":
        child_command.pop()
    child_command = _with_model_override(
        provider, child_command, str(admission.get("model_effective") or "")
    )
    child_resolved = _resolve_agent_command(provider, child_command, base_env)
    child_capability = resolve_provider_usage_capability(
        provider, executable=child_resolved[0]
    )
    # Same admission as the direct owner: measured budgets need the side
    # channel, an unmetered declaration does not.
    if quota.kind in {"safe", "bounded"} and not child_capability.supported:
        raise ValueError(child_capability.reason)
    launch = prepare_interactive_workspace_launch(
        provider=provider,
        runtime=runtime,
        permissions=permissions,
        selected_root=root,
        prompt=prompt,
        run_id=run_id,
        executable=child_resolved[0],
        publish=False,
        quota_policy=quota,
        usage_capability=child_capability,
        provider_session_id=child_session_id,
        continuity_material=continuity_material,
        workspace_identity=admission,
    )
    if child_capability.supported and provider == "claude":
        try:
            usage_reader: Any = _ClaudeTranscriptUsage(
                provider_session_id=child_session_id,
                effective_root=launch.effective_root,
                provider_version=child_capability.provider_version,
                env=base_env,
                run_id=launch.run_id,
                resume=bool(native_session),
                fork_parent_session_id=(
                    continuity_policy.parent_provider_session_id if native_fork else ""
                ),
            )
        except Exception:
            _cleanup_unspawned_interactive_launch(launch)
            raise
    else:
        usage_reader = _UnmeteredUsage()

    try:
        from .workflow import reserve_run_id

        operator_run_id = reserve_run_id("oper")
        operator_session_id = str(uuid.uuid4())
        relation_id = str(uuid.uuid4())
        operator_run_dir = control_plane_home() / "runtime_runs" / operator_run_id
        operator_run_dir.mkdir(parents=True, exist_ok=True)
        operator_meta_path = operator_run_dir / "meta.json"
        operator_prompt_path = operator_run_dir / "prompt.md"
        protocol_path = operator_run_dir / "operator-protocol.jsonl"
        operator_prompt = _operator_supervision_prompt(
            child_run_id=launch.run_id,
            child_meta_path=launch.meta_path,
            relation_id=relation_id,
            protocol_path=protocol_path,
        )
        from .workflow import _write_prompt_file

        _write_prompt_file(operator_prompt_path, operator_prompt)
    except Exception:
        _cleanup_unspawned_interactive_launch(launch)
        raise

    now_iso = dt.datetime.now(dt.UTC).isoformat()
    relation = {
        "relation_id": relation_id,
        "operator_run_id": operator_run_id,
        "child_run_id": launch.run_id,
        "state": "reserved",
        "protocol": "operator-protocol-jsonl-v1",
    }
    child_receipt = {
        **launch.receipt,
        **admission,
        "updated_at": now_iso,
        "status": "reserved",
        "liveness": "reserved",
        "role": "agent",
        "prompt_role": str(admission.get("skill") or "init"),
        "operator_policy": operator_policy.as_dict(),
        "supervision": dict(relation),
        "parent_session_id": parent_id,
        "native_child_session_id": proven_native,
        "agent_session_id": proven_native,
        "native_identity_status": "proven" if proven_native else "unknown",
        "provider_session_requested": child_session_id,
    }
    if native_fork:
        child_receipt.update(
            native_fork=True,
            fork_source_session_id=continuity_policy.parent_provider_session_id,
            native_identity_status="pending",
            provider_session_id="",
            agent_session_id="",
            native_child_session_id="",
        )
    operator_receipt = {
        **launch.receipt,
        "created_at": now_iso,
        "updated_at": now_iso,
        "started_at": now_iso,
        "status": "reserved",
        "liveness": "reserved",
        "run_id": operator_run_id,
        "agent": operator_policy.provider,
        "skill": "operator",
        "permission_policy": operator_policy.permissions,
        "role": "operator",
        "prompt_role": "/vc-operator",
        "input": str(operator_prompt_path),
        "provider_session_id": operator_session_id,
        "operator_policy": operator_policy.as_dict(),
        "supervision": dict(relation),
        "measured_usage": _empty_measured_usage(),
    }
    operator_command = interactive_policy_command(
        operator_policy.provider,
        f"Read and follow the private task file: {operator_prompt_path}",
        runtime,
        operator_policy.permissions or "accept-edits",
        provider_session_id=operator_session_id,
        continuity_policy=ContinuityPolicy(
            mode="fresh", lineage_id=continuity_policy.lineage_id
        ),
    )
    operator_resolved = _resolve_agent_command(
        operator_policy.provider, operator_command, base_env
    )
    operator_capability = resolve_provider_usage_capability(
        operator_policy.provider, executable=operator_resolved[0]
    )
    if not operator_capability.supported:
        _cleanup_unspawned_interactive_launch(launch)
        raise ValueError(operator_capability.reason)
    operator_receipt["usage_capability"] = operator_capability.as_dict()
    # The pair is durably reserved and bidirectionally bound before either
    # provider can become ACTIVE. There is no second relationship database.
    try:
        _write_meta(launch.meta_path, child_receipt)
        _write_meta(operator_meta_path, operator_receipt)
    except Exception:
        launch.meta_path.unlink(missing_ok=True)
        operator_meta_path.unlink(missing_ok=True)
        _cleanup_unspawned_interactive_launch(launch)
        raise
    append_event(
        "lifecycle:reserved",
        launch.run_id,
        "Agent reserved with Operator Agent relation",
        {**child_receipt, "meta": str(launch.meta_path)},
    )
    append_event(
        "lifecycle:reserved",
        operator_run_id,
        "Operator Agent reserved with child relation",
        {**operator_receipt, "meta": str(operator_meta_path)},
    )

    operator_env = {
        **base_env,
        "VIBECRAFTED_RUN_ID": operator_run_id,
        "VIBECRAFTED_SESSION_ID": launch.vibecrafted_session_id,
        "VIBECRAFTED_WORKSPACE_ID": launch.workspace_id,
        "VIBECRAFTED_WORKSPACE_INSTANCE_ID": str(
            launch.receipt["workspace_instance_id"]
        ),
        "VIBECRAFTED_PARENT_ROOT": launch.parent_root,
        "VIBECRAFTED_EFFECTIVE_ROOT": launch.effective_root,
        "VIBECRAFTED_AGENT_ROLE": "operator",
        "VIBECRAFTED_PROMPT_ROLE": "/vc-operator",
        "VIBECRAFTED_SUPERVISION_RELATION_ID": relation_id,
        "VIBECRAFTED_SUPERVISION_PEER_RUN_ID": launch.run_id,
        "VIBECRAFTED_SUPERVISED_CHILD_META": str(launch.meta_path),
        "VIBECRAFTED_OPERATOR_PROTOCOL": str(protocol_path),
        "VIBECRAFTED_CONTINUITY_MODE": continuity_policy.mode,
        "VIBECRAFTED_CONTINUITY_LINEAGE_ID": continuity_policy.lineage_id,
    }
    try:
        operator_log = (operator_run_dir / "provider.log").open("ab")
        operator_child = subprocess.Popen(
            operator_resolved,
            cwd=launch.effective_root,
            env=operator_env,
            stdin=subprocess.DEVNULL,
            stdout=operator_log,
            stderr=subprocess.STDOUT,
        )
    except (OSError, ValueError) as exc:
        if "operator_log" in locals():
            operator_log.close()
        cleanup = _cleanup_unspawned_interactive_launch(launch)
        _terminalize_interactive_launch(
            launch,
            child_receipt,
            status="failed",
            exit_code=2,
            terminal_reason="operator_spawn_failed",
            error=str(exc),
            extra={"prepared_worktree_cleanup": cleanup},
        )
        _terminalize_related_receipt(
            operator_run_id,
            operator_meta_path,
            operator_receipt,
            status="failed",
            exit_code=2,
            terminal_reason="operator_spawn_failed",
            error=str(exc),
        )
        raise

    child_env = {
        **base_env,
        "VIBECRAFTED_RUN_ID": launch.run_id,
        "VIBECRAFTED_SESSION_ID": launch.vibecrafted_session_id,
        "VIBECRAFTED_WORKSPACE_ID": launch.workspace_id,
        "VIBECRAFTED_WORKSPACE_INSTANCE_ID": str(
            launch.receipt["workspace_instance_id"]
        ),
        "VIBECRAFTED_BUILD_ID": str(launch.receipt["build_id"]["rendered"]),
        "VIBECRAFTED_PARENT_ROOT": launch.parent_root,
        "VIBECRAFTED_EFFECTIVE_ROOT": launch.effective_root,
        "VIBECRAFTED_AGENT_ROLE": "agent",
        "VIBECRAFTED_PROMPT_ROLE": str(admission.get("skill") or "init"),
        "VIBECRAFTED_SUPERVISION_RELATION_ID": relation_id,
        "VIBECRAFTED_SUPERVISION_PEER_RUN_ID": operator_run_id,
        "VIBECRAFTED_CONTINUITY_MODE": continuity_policy.mode,
        "VIBECRAFTED_CONTINUITY_LINEAGE_ID": continuity_policy.lineage_id,
    }
    child_env = provider_workspace_environment(child_env, provider)
    try:
        # The User-facing child keeps the exact inherited descriptors and TTY.
        child = subprocess.Popen(
            child_resolved,
            cwd=launch.effective_root,
            env=child_env,
        )
        print(
            f"provider started: run_id={launch.run_id} provider={provider} pid={child.pid}",
            file=sys.stderr,
            flush=True,
        )
    except (OSError, ValueError) as exc:
        operator_code = _stop_owned_process(operator_child)
        operator_log.close()
        cleanup = _cleanup_unspawned_interactive_launch(launch)
        _terminalize_interactive_launch(
            launch,
            child_receipt,
            status="failed",
            exit_code=2,
            terminal_reason="child_spawn_failed",
            error=str(exc),
            extra={"prepared_worktree_cleanup": cleanup},
        )
        _terminalize_related_receipt(
            operator_run_id,
            operator_meta_path,
            operator_receipt,
            status="failed",
            exit_code=_shell_status(operator_code),
            terminal_reason="child_spawn_failed",
            error=str(exc),
        )
        raise

    if operator_child.poll() is not None:
        child_code = _stop_owned_process(child)
        operator_code = operator_child.returncode or 0
        operator_log.close()
        _terminalize_interactive_launch(
            launch,
            child_receipt,
            status="failed",
            exit_code=1,
            terminal_reason="supervision_lost_before_active",
            extra={"provider_exit_code": _shell_status(child_code)},
        )
        _terminalize_related_receipt(
            operator_run_id,
            operator_meta_path,
            operator_receipt,
            status="failed",
            exit_code=_shell_status(operator_code),
            terminal_reason="supervision_lost_before_active",
        )
        return 1

    active_at = dt.datetime.now(dt.UTC).isoformat()
    active_relation = {**relation, "state": "active"}
    child_receipt.update(
        updated_at=active_at,
        spawned_at=active_at,
        status="active",
        liveness="active",
        owner_pid=os.getpid(),
        launcher_pid=os.getpid(),
        worker_pid=child.pid,
        supervision=active_relation,
    )
    operator_receipt.update(
        updated_at=active_at,
        spawned_at=active_at,
        status="active",
        liveness="active",
        owner_pid=os.getpid(),
        launcher_pid=os.getpid(),
        worker_pid=operator_child.pid,
        supervision=active_relation,
    )
    received_signal: list[int] = []
    previous_handlers: dict[int, Any] = {}

    def _forward_owner_signal(signum: int, _frame: Any) -> None:
        if not received_signal:
            received_signal.append(signum)
        for owned_process in (child, operator_child):
            if owned_process.poll() is None:
                try:
                    owned_process.send_signal(signum)
                except ProcessLookupError:
                    pass

    # Own the pair's signals before publishing, exactly like the direct owner:
    # both providers already exist, and a SIGINT/SIGTERM landing during the
    # publication window used to hit the default handler — the owner died
    # unsettled and left two orphaned providers behind.
    if threading.current_thread() is threading.main_thread():
        for signum in (
            signal.SIGINT,
            signal.SIGTERM,
            getattr(signal, "SIGHUP", signal.SIGTERM),
        ):
            if signum in previous_handlers:
                continue
            previous_handlers[signum] = signal.getsignal(signum)
            signal.signal(signum, _forward_owner_signal)

    # Same publication contract as the direct owner: identity receipts ride the
    # first ACTIVE publication so the snapshot can prove an idle pair alive.
    identity_table = _process_table_or_none()
    _attach_interactive_process_identity(
        child_receipt,
        run_id=launch.run_id,
        worker_pid=child.pid,
        table=identity_table,
    )
    _attach_interactive_process_identity(
        operator_receipt,
        run_id=operator_run_id,
        worker_pid=operator_child.pid,
        table=identity_table,
    )
    child_projection = _InteractiveProjection(
        run_id=launch.run_id, meta_path=launch.meta_path, receipt=child_receipt
    )
    operator_projection = _InteractiveProjection(
        run_id=operator_run_id, meta_path=operator_meta_path, receipt=operator_receipt
    )
    try:
        _write_meta(launch.meta_path, child_receipt)
        _write_meta(operator_meta_path, operator_receipt)
        append_event(
            "lifecycle:active",
            launch.run_id,
            "supervised interactive Agent Workspace child is live",
            {
                **child_receipt,
                "meta": str(launch.meta_path),
                "identity_required": True,
            },
        )
        append_event(
            "lifecycle:active",
            operator_run_id,
            "Operator Agent is supervising exact child",
            {
                **operator_receipt,
                "meta": str(operator_meta_path),
                "identity_required": True,
            },
        )
        child_projection.publish()
        operator_projection.publish()
    except Exception as exc:
        for signum, handler in previous_handlers.items():
            signal.signal(signum, handler)
        child_code = _stop_owned_process(child)
        operator_code = _stop_owned_process(operator_child)
        operator_log.close()
        _terminalize_interactive_launch(
            launch,
            child_receipt,
            status="failed",
            exit_code=1,
            terminal_reason="active_publish_failed",
            error=str(exc),
            extra={"provider_exit_code": _shell_status(child_code)},
        )
        _terminalize_related_receipt(
            operator_run_id,
            operator_meta_path,
            operator_receipt,
            status="failed",
            exit_code=_shell_status(operator_code),
            terminal_reason="active_publish_failed",
            error=str(exc),
        )
        raise

    quota_exhausted = False
    supervision_lost = False
    stop_actor_run_id = ""
    protocol_offset = 0
    provider_returncode = 0
    try:
        while True:
            current_returncode = child.poll()
            measured_usage = usage_reader.poll()
            if isinstance(
                usage_reader, _ClaudeTranscriptUsage
            ) and usage_reader.confirm_fork_receipt(child_receipt):
                _write_meta(launch.meta_path, child_receipt)
            if measured_usage != child_receipt["measured_usage"]:
                child_receipt["measured_usage"] = measured_usage
                child_receipt["updated_at"] = dt.datetime.now(dt.UTC).isoformat()
                _write_meta(launch.meta_path, child_receipt)
            child_projection.pump()
            operator_projection.pump()
            events, protocol_offset = _poll_operator_protocol(
                protocol_path, protocol_offset
            )
            for event in events:
                _validate_operator_protocol_event(
                    event,
                    relation_id=relation_id,
                    operator_run_id=operator_run_id,
                    child_receipt=child_receipt,
                )
                if event["kind"] == "observation":
                    operator_receipt["supervision"] = {
                        **active_relation,
                        "observation": {
                            "child_run_id": launch.run_id,
                            "child_status": child_receipt["status"],
                            "child_worker_pid": child.pid,
                            "measured_usage": child_receipt["measured_usage"],
                            "observed_at": dt.datetime.now(dt.UTC).isoformat(),
                        },
                    }
                    operator_receipt["updated_at"] = dt.datetime.now(dt.UTC).isoformat()
                    _write_meta(operator_meta_path, operator_receipt)
                elif current_returncode is None:
                    stop_actor_run_id = operator_run_id
                    append_event(
                        "operator:stop-requested",
                        launch.run_id,
                        "Operator Agent requested bounded child stop",
                        {
                            "run_id": launch.run_id,
                            "actor_run_id": operator_run_id,
                            "relation_id": relation_id,
                            "reason": event["reason"],
                        },
                    )
                    provider_returncode = _stop_owned_process(child)
                    break
            if stop_actor_run_id:
                break
            if current_returncode is not None:
                provider_returncode = current_returncode
                break
            operator_returncode = operator_child.poll()
            if operator_returncode is not None:
                provider_returncode = _stop_owned_process(child)
                supervision_lost = not received_signal
                break
            if (
                not received_signal
                and quota.token_budget is not None
                and measured_usage["total_tokens"] >= quota.token_budget
            ):
                quota_exhausted = True
                provider_returncode = _stop_owned_process(child)
                break
            time.sleep(0.05)
    except Exception as exc:
        child_code = _stop_owned_process(child)
        operator_code = _stop_owned_process(operator_child)
        _terminalize_interactive_launch(
            launch,
            child_receipt,
            status="failed",
            exit_code=1,
            terminal_reason="killed_after_start",
            error=str(exc),
            extra={"provider_exit_code": _shell_status(child_code)},
        )
        _terminalize_related_receipt(
            operator_run_id,
            operator_meta_path,
            operator_receipt,
            status="failed",
            exit_code=_shell_status(operator_code),
            terminal_reason="killed_after_start",
            error=str(exc),
        )
        raise
    finally:
        for signum, handler in previous_handlers.items():
            signal.signal(signum, handler)

    shell_status = _shell_status(provider_returncode)
    if quota_exhausted:
        status = "quota_exhausted"
        terminal_reason = "quota_exhausted"
        shell_status = QUOTA_EXHAUSTED_EXIT_CODE
    elif received_signal:
        owner_signal = received_signal[0]
        status = "cancelled"
        terminal_reason = f"owner_signal:{signal.Signals(owner_signal).name}"
        shell_status = 128 + owner_signal
    elif stop_actor_run_id:
        status = "cancelled"
        terminal_reason = "operator_policy_stop"
        shell_status = 128 + signal.SIGTERM
    elif supervision_lost:
        status = "failed"
        terminal_reason = "supervision_lost"
        shell_status = 1
    elif provider_returncode < 0:
        status = "cancelled"
        terminal_reason = (
            f"provider_signal:{signal.Signals(abs(provider_returncode)).name}"
        )
    elif (
        provider_returncode == 0
        and native_fork
        and child_receipt.get("native_identity_status") != "confirmed"
    ):
        status = "failed"
        terminal_reason = "native_fork_identity_unconfirmed"
        shell_status = 1
    elif provider_returncode == 0:
        status = "completed"
        terminal_reason = "provider_exit_zero"
    else:
        status = "failed"
        terminal_reason = "provider_exit_nonzero"
    terminal_extra = {
        "supervision": {**child_receipt["supervision"], "state": "terminal"}
    }
    if stop_actor_run_id:
        terminal_extra["stop_actor_run_id"] = stop_actor_run_id
    child_terminal = _terminalize_interactive_launch(
        launch,
        child_receipt,
        status=status,
        exit_code=shell_status,
        terminal_reason=terminal_reason,
        exit_signal=abs(provider_returncode) if provider_returncode < 0 else None,
        extra=terminal_extra,
    )
    terminal_observation_confirmed = False
    settlement_error = ""
    if not supervision_lost and not received_signal:
        deadline = time.monotonic() + 1.0
        try:
            while True:
                # Sample the Operator Agent's exit BEFORE reading: the protocol
                # file outlives its writer, so an Operator that appends its
                # terminal observation and exits at once is still read on this
                # pass. Gating the whole window on a live operator skipped a
                # fast operator's final truth whenever the child's terminal
                # publication took longer than the operator's last write.
                operator_exited = operator_child.poll() is not None
                events, protocol_offset = _poll_operator_protocol(
                    protocol_path, protocol_offset
                )
                for event in events:
                    _validate_operator_protocol_event(
                        event,
                        relation_id=relation_id,
                        operator_run_id=operator_run_id,
                        child_receipt=child_terminal,
                    )
                    if event["kind"] == "observation":
                        terminal_observation_confirmed = True
                        operator_receipt["supervision"] = {
                            **active_relation,
                            "observation": {
                                "child_run_id": launch.run_id,
                                "child_status": child_terminal["status"],
                                "child_worker_pid": child.pid,
                                "measured_usage": child_terminal["measured_usage"],
                                "observed_at": dt.datetime.now(dt.UTC).isoformat(),
                            },
                        }
                        _write_meta(operator_meta_path, operator_receipt)
                if (
                    terminal_observation_confirmed
                    or operator_exited
                    or time.monotonic() >= deadline
                ):
                    break
                time.sleep(0.05)
        except (OSError, RuntimeError, TypeError, ValueError) as exc:
            settlement_error = str(exc)
    operator_code = _stop_owned_process(operator_child)
    operator_log.close()
    settled_worktree_cleanup = _cleanup_settled_interactive_launch(launch)
    child_terminal["settled_worktree_cleanup"] = settled_worktree_cleanup
    child_terminal["updated_at"] = dt.datetime.now(dt.UTC).isoformat()
    _write_meta(launch.meta_path, child_terminal)
    if settled_worktree_cleanup != "not-applicable":
        append_event(
            "lifecycle:worktree-cleanup",
            launch.run_id,
            f"settled interactive worktree cleanup: {settled_worktree_cleanup}",
            {
                "run_id": launch.run_id,
                "result": settled_worktree_cleanup,
                "meta": str(launch.meta_path),
            },
        )
    operator_failed = supervision_lost or bool(settlement_error)
    _terminalize_related_receipt(
        operator_run_id,
        operator_meta_path,
        operator_receipt,
        status="failed" if operator_failed else "completed",
        exit_code=_shell_status(operator_code) if operator_failed else 0,
        terminal_reason=(
            "supervision_lost"
            if supervision_lost
            else "operator_protocol_failed"
            if settlement_error
            else "child_settled"
        ),
        error=settlement_error,
        extra={
            "supervision": {
                **operator_receipt["supervision"],
                "state": "terminal",
                "terminal_observation_confirmed": terminal_observation_confirmed,
            }
        },
    )
    return shell_status


def _operator_supervision_prompt(
    *, child_run_id: str, child_meta_path: Path, relation_id: str, protocol_path: Path
) -> str:
    return (
        "/vc-operator\n"
        "Supervise exactly one child Agent through structured lifecycle truth.\n"
        f"child_run_id: {child_run_id}\n"
        f"child_meta: {child_meta_path}\n"
        f"relation_id: {relation_id}\n"
        f"protocol_jsonl: {protocol_path}\n"
        "Observe child status and measured_usage from child_meta. Write only typed "
        "observation or bounded stop action JSON objects to protocol_jsonl. Remain "
        "live until the child reaches terminal state. Never signal or reap the child.\n"
    )


def _poll_operator_protocol(
    path: Path, offset: int
) -> tuple[list[dict[str, Any]], int]:
    if not path.exists():
        return [], offset
    if path.is_symlink() or not path.is_file():
        raise RuntimeError("Operator Agent protocol must be a regular non-symlink file")
    if path.stat().st_size < offset:
        raise RuntimeError("Operator Agent protocol was truncated")
    events: list[dict[str, Any]] = []
    with path.open("r", encoding="utf-8") as handle:
        handle.seek(offset)
        while True:
            line_start = handle.tell()
            line = handle.readline()
            if not line:
                break
            if not line.endswith("\n"):
                handle.seek(line_start)
                break
            try:
                event = json.loads(line)
            except json.JSONDecodeError as exc:
                raise RuntimeError(
                    "Operator Agent protocol contains invalid JSONL"
                ) from exc
            if not isinstance(event, dict):
                raise TypeError("Operator Agent protocol event must be an object")
            events.append(event)
        return events, handle.tell()


def _validate_operator_protocol_event(
    event: dict[str, Any],
    *,
    relation_id: str,
    operator_run_id: str,
    child_receipt: dict[str, Any],
) -> None:
    if event.get("kind") not in {"observation", "action"}:
        raise RuntimeError("Operator Agent protocol kind is unsupported")
    if event.get("actor_run_id") != operator_run_id:
        raise RuntimeError("Operator Agent protocol actor identity mismatch")
    if event.get("child_run_id") != child_receipt["run_id"]:
        raise RuntimeError("Operator Agent protocol child identity mismatch")
    if event.get("relation_id") != relation_id:
        raise RuntimeError("Operator Agent protocol relation identity mismatch")
    if event["kind"] == "observation":
        if event.get("child_status") != child_receipt["status"]:
            raise RuntimeError("Operator Agent observation is not current child truth")
        if event.get("child_worker_pid") != child_receipt["worker_pid"]:
            raise RuntimeError(
                "Operator Agent observation names a foreign child process"
            )
        if event.get("measured_usage") != child_receipt["measured_usage"]:
            raise RuntimeError(
                "Operator Agent observation usage is not exact child truth"
            )
        return
    if event.get("action") not in {"stop", "cancel"}:
        raise RuntimeError("Operator Agent action is outside the bounded policy")
    if event.get("reason") not in {"operator_policy_stop", "operator_policy_cancel"}:
        raise RuntimeError("Operator Agent action reason is outside the bounded policy")


def _stop_owned_process(process: subprocess.Popen[Any]) -> int:
    """Stop and reap one process from the existing wrapper owner only."""
    current = process.poll()
    if current is not None:
        return current
    process.terminate()
    try:
        return process.wait(timeout=5)
    except subprocess.TimeoutExpired:
        process.kill()
        return process.wait()


def _shell_status(returncode: int) -> int:
    return 128 + abs(returncode) if returncode < 0 else returncode


def _terminalize_related_receipt(
    run_id: str,
    meta_path: Path,
    receipt: dict[str, Any],
    *,
    status: str,
    exit_code: int,
    terminal_reason: str,
    error: str = "",
    extra: dict[str, Any] | None = None,
) -> dict[str, Any]:
    completed_at = dt.datetime.now(dt.UTC).isoformat()
    terminal = {
        **receipt,
        "updated_at": completed_at,
        "completed_at": completed_at,
        "status": status,
        "liveness": "terminal",
        "exit_code": int(exit_code),
        "terminal_reason": terminal_reason,
        **(extra or {}),
    }
    if error:
        terminal["error"] = error
    _write_meta(meta_path, terminal)
    append_event(
        f"lifecycle:{status}",
        run_id,
        f"Operator Agent terminal: {terminal_reason}",
        {**terminal, "meta": str(meta_path), "identity_required": True},
    )
    _flush_terminal_projection(run_id, terminal, meta_path=meta_path)
    return terminal


def _process_table_or_none() -> Sequence[Any] | None:
    """One process-table capture shared by several identity receipts."""
    try:
        from .process_control import build_process_table

        return build_process_table()
    except (OSError, RuntimeError, ValueError):
        return None


def _attach_interactive_process_identity(
    receipt: dict[str, Any],
    *,
    run_id: str,
    worker_pid: int,
    owner_pid: int | None = None,
    table: Sequence[Any] | None = None,
) -> None:
    """Stamp best-effort owner/worker identity receipts onto *receipt*.

    Deliberately publishes no top-level ``worker_pgid``: an interactive
    provider inherits the terminal pane's process group, and ``worker_pgid``
    is the first stop-signal target (``killpg``). The receipts still carry the
    captured group, which is all the liveness reconciler needs.
    """
    try:
        from .process_control import process_identity_receipt

        shared_table = table if table is not None else _process_table_or_none()
        owner_identity = process_identity_receipt(
            int(owner_pid or os.getpid()), run_id=run_id, table=shared_table
        )
        worker_identity = process_identity_receipt(
            int(worker_pid), run_id=run_id, table=shared_table
        )
    except (OSError, RuntimeError, ValueError):
        # PID + role truth remains mandatory; stronger identity is best-effort
        # because a deterministic fast-exit provider may already be terminal.
        return
    if owner_identity is not None:
        receipt["owner_identity"] = owner_identity
    if worker_identity is not None:
        receipt["worker_identity"] = worker_identity


# --- Canonical snapshot publication: owned, bounded recovery -----------------
#
# Lifecycle ownership. The interactive owner process (the pane launcher that
# holds the provider child) owns its run's ``runs/<id>.json`` publication for
# exactly as long as it lives. Recovery after a transient failure therefore
# runs on the owner's own poll loop (no thread, no helper process, nothing to
# reap or leak at exit) and, at terminalization, as one synchronous bounded
# flush before the owner returns. The snapshot authority stays single and the
# scope stays exact: every attempt is the same ``sync_state(only_run_id=...)``.
# Persistent terminal failure is abandoned loudly — stderr, a durable
# ``projection:abandoned`` event and the meta receipt — while meta.json plus the
# lifecycle event remain the durable truth a later full board sync re-projects.
#
# Retry bound. ACTIVE phase retries for the lifetime of its still-live owner,
# with exponential backoff 0.5s·2^(n-1) capped at 30s. The cap constrains
# frequency rather than declaring a healthy owner permanently invisible after
# an arbitrary number of transient storage failures.
# TERMINAL phase (owner exit): a bounded retry-scheduling/sleep budget of
# _PROJECTION_TERMINAL_BUDGET_SECONDS and _PROJECTION_TERMINAL_ATTEMPT_LIMIT
# attempts, interrupt-safe. A blocking filesystem syscall remains outside that
# budget.
_PROJECTION_RETRY_INITIAL_SECONDS = 0.5
_PROJECTION_RETRY_MAX_SECONDS = 30.0
# The first power that reaches the 30-second ceiling: 0.5 * 2**6 == 32.
# Clamp the exponent before calculating the power so an arbitrarily long
# storage outage cannot make retry scheduling itself overflow.
_PROJECTION_RETRY_MAX_EXPONENT = 6
_PROJECTION_TERMINAL_BUDGET_SECONDS = 5.0
_PROJECTION_TERMINAL_ATTEMPT_LIMIT = 6
# ControlPlaneLockBusy is kept for completeness: the scoped projection takes no
# global sync lock, so the live failure classes here are storage/OS errors and
# a refused run-meta mutation (ValueError), not the board-sync lock.
_PROJECTION_ERRORS: tuple[type[BaseException], ...] = (
    ControlPlaneLockBusy,
    ControlPlaneStorageError,
    OSError,
    RuntimeError,
    ValueError,
)
_projection_log = logging.getLogger(__name__)


def _project_interactive_snapshot(run_id: str) -> str:
    """One scoped canonical projection attempt: '' on success, else the error."""
    try:
        sync_state(only_run_id=run_id)
    except _PROJECTION_ERRORS as exc:
        return f"{type(exc).__name__}: {exc}"
    return ""


def _projection_backoff_seconds(failures: int) -> float:
    exponent = min(max(int(failures) - 1, 0), _PROJECTION_RETRY_MAX_EXPONENT)
    return min(
        _PROJECTION_RETRY_MAX_SECONDS,
        _PROJECTION_RETRY_INITIAL_SECONDS * (2.0**exponent),
    )


def _record_projection_abandoned(
    run_id: str,
    *,
    phase: str,
    attempts: int,
    last_error: str,
    receipt: Mapping[str, Any],
) -> None:
    """Make a persistent projection failure observable without inventing truth."""
    _projection_log.error(
        "interactive run %s canonical snapshot projection abandoned after %d %s "
        "attempt(s); meta.json and the lifecycle event remain the durable truth "
        "(run `vibecrafted control-plane sync` once the cause is fixed): %s",
        run_id,
        attempts,
        phase,
        last_error,
    )
    try:
        append_event(
            "projection:abandoned",
            run_id,
            f"canonical snapshot projection abandoned ({phase})",
            {
                "run_id": run_id,
                "phase": phase,
                "attempts": int(attempts),
                "last_error": last_error,
                "state": str(receipt.get("status") or ""),
                "liveness": str(receipt.get("liveness") or ""),
            },
        )
    except _PROJECTION_ERRORS as exc:
        _projection_log.error(
            "interactive run %s projection abandonment event not durable: %s",
            run_id,
            exc,
        )


@dataclass
class _InteractiveProjection:
    """Owner-side ACTIVE publication of one run's canonical snapshot.

    ``publish`` is the first attempt right after the ``lifecycle:active``
    event; ``pump`` is called from the owner's existing provider poll loop and
    retries a pending publication when its backoff is due. No thread, no
    timer: the retry lives and dies with the owner, and a terminalization
    supersedes any pending ACTIVE publication with its own bounded flush.
    """

    run_id: str
    meta_path: Path
    receipt: dict[str, Any]
    clock: Callable[[], float] = time.monotonic
    attempts: int = 0
    failures: int = 0
    next_attempt_at: float = 0.0
    status: str = "unpublished"
    last_error: str = ""
    first_failed_at: str = ""

    def publish(self) -> str:
        return self._attempt()

    def pump(self) -> str:
        if self.status != "pending" or self.clock() < self.next_attempt_at:
            return self.status
        return self._attempt()

    def _attempt(self) -> str:
        self.attempts += 1
        error = _project_interactive_snapshot(self.run_id)
        if not error:
            if self.failures:
                _projection_log.warning(
                    "interactive run %s snapshot projection recovered on attempt %d",
                    self.run_id,
                    self.attempts,
                )
            self.status = "published"
            self.last_error = ""
            self._stamp(published_at=utc_now_iso())
            return self.status
        self.failures += 1
        self.last_error = error
        if not self.first_failed_at:
            self.first_failed_at = utc_now_iso()
        delay = _projection_backoff_seconds(self.failures)
        self.next_attempt_at = self.clock() + delay
        self.status = "pending"
        # A live owner may legitimately outlast an outage. Log the first
        # defer only, so recovery does not become an unbounded log stream.
        if self.attempts == 1:
            _projection_log.warning(
                "interactive run %s snapshot projection deferred; owner retries "
                "with capped %.1fs backoff: %s",
                self.run_id,
                _PROJECTION_RETRY_MAX_SECONDS,
                error,
            )
        self._stamp()
        return self.status

    def _stamp(self, **extra: Any) -> None:
        """Mirror the publication state into the owner's meta receipt (best-effort)."""
        self.receipt["projection"] = {
            "status": self.status,
            "attempts": self.attempts,
            "last_error": self.last_error,
            "first_failed_at": self.first_failed_at,
            **extra,
        }
        try:
            _write_meta(self.meta_path, self.receipt)
        except OSError:
            # The same storage fault that blocks the snapshot may block meta;
            # the log line above already carries the truth.
            pass


def _flush_terminal_projection(
    run_id: str,
    receipt: dict[str, Any],
    *,
    meta_path: Path | None = None,
    clock: Callable[[], float] = time.monotonic,
    sleep: Callable[[float], None] = time.sleep,
) -> str:
    """Bounded synchronous recovery of the terminal snapshot before owner exit.

    Runs after the terminal meta and lifecycle event are durable, so the
    retained terminal truth is never at stake — only its visibility. The retry
    budget limits scheduling and sleep; it cannot bound a blocking filesystem
    syscall inside the canonical writer. It never spawns anything, and a
    Ctrl-C during the flush abandons it instead of unwinding the owner's exit
    path.
    """
    deadline = clock() + _PROJECTION_TERMINAL_BUDGET_SECONDS
    attempts = 0
    last_error = ""
    while True:
        attempts += 1
        try:
            last_error = _project_interactive_snapshot(run_id)
        except KeyboardInterrupt:
            last_error = "KeyboardInterrupt: terminal projection interrupted"
            break
        if not last_error:
            if attempts > 1:
                _projection_log.warning(
                    "interactive run %s terminal snapshot projection recovered "
                    "on attempt %d",
                    run_id,
                    attempts,
                )
            _stamp_terminal_projection(
                receipt, meta_path, status="published", attempts=attempts
            )
            return "published"
        remaining = deadline - clock()
        if attempts >= _PROJECTION_TERMINAL_ATTEMPT_LIMIT or remaining <= 0:
            break
        delay = min(_projection_backoff_seconds(attempts), remaining)
        _projection_log.warning(
            "interactive run %s terminal snapshot projection deferred (attempt "
            "%d/%d, owner retries in %.1fs within a %.0fs exit budget): %s",
            run_id,
            attempts,
            _PROJECTION_TERMINAL_ATTEMPT_LIMIT,
            delay,
            _PROJECTION_TERMINAL_BUDGET_SECONDS,
            last_error,
        )
        try:
            sleep(delay)
        except KeyboardInterrupt:
            last_error = "KeyboardInterrupt: terminal projection interrupted"
            break
    _record_projection_abandoned(
        run_id,
        phase="terminal",
        attempts=attempts,
        last_error=last_error,
        receipt=receipt,
    )
    _stamp_terminal_projection(
        receipt,
        meta_path,
        status="abandoned",
        attempts=attempts,
        last_error=last_error,
    )
    return "abandoned"


def _stamp_terminal_projection(
    receipt: dict[str, Any],
    meta_path: Path | None,
    *,
    status: str,
    attempts: int,
    last_error: str = "",
) -> None:
    """Retain terminal publication outcome without creating another writer."""
    receipt["projection"] = {
        "phase": "terminal",
        "status": status,
        "attempts": attempts,
        "last_error": last_error,
        "published_at": utc_now_iso() if status == "published" else "",
    }
    if meta_path is None:
        return
    try:
        _write_meta(meta_path, receipt)
    except OSError:
        # The terminal lifecycle receipt remains durable from before this flush.
        pass


def _cleanup_unspawned_interactive_launch(launch: InteractiveWorkspaceLaunch) -> str:
    """Remove only the clean worktree prepared for a child that never existed."""
    if launch.worktree_manager is None or launch.worktree_geometry is None:
        return "not-applicable"
    try:
        return str(
            launch.worktree_manager.cleanup(launch.worktree_geometry, settled=True)
        )
    except (OSError, RuntimeError, ValueError) as exc:
        return f"preserved:{exc}"


def _cleanup_settled_interactive_launch(launch: InteractiveWorkspaceLaunch) -> str:
    """Delegate clean terminal worktree cleanup to the canonical manager."""
    if launch.worktree_manager is None or launch.worktree_geometry is None:
        return "not-applicable"
    try:
        return str(
            launch.worktree_manager.cleanup(launch.worktree_geometry, settled=True)
        )
    except (OSError, RuntimeError, ValueError) as exc:
        return f"preserved:{exc}"


def interactive_child_had_started(meta: Mapping[str, Any] | None) -> bool:
    """True when the provider child was published before the failure."""
    if not meta:
        return False
    if str(meta.get("spawned_at") or "").strip():
        return True
    if str(meta.get("terminal_reason") or "") in {
        "killed_after_start",
        "wrapper_exception",
    }:
        return True
    return meta.get("status") == "active" and bool(meta.get("worker_pid"))


def classify_interactive_failure_reason(existing_meta: Mapping[str, Any] | None) -> str:
    """Distinguish a failed start from a live session that supervision then killed."""
    if interactive_child_had_started(existing_meta):
        return "killed_after_start"
    return "interactive_start_failed"


def format_interactive_launch_failure(
    *,
    run_id: str,
    reason: str,
    agent_session_id: str = "",
    started: bool = False,
    provider: str = "claude",
) -> str:
    """Panel text for an interactive-launch failure: run_id, reason, resume."""
    verb = "was stopped after it had already started" if started else "failed to start"
    lines = [f"Session {run_id} {verb}.", f"Reason: {reason}"]
    session = str(agent_session_id or "").strip()
    if session:
        lines.append(f"{agent_cli_name(provider)} --resume {session}")
    return "\n".join(lines)


def record_interactive_launch_cli_failure(
    *,
    admission: Mapping[str, Any],
    exc: BaseException,
    provider: str = "claude",
) -> tuple[str, dict[str, Any]]:
    """Settle interactive-launch CLI failure without wiping a live receipt."""
    run_id = str(admission.get("run_id") or "")
    meta_path = control_plane_home() / "runtime_runs" / run_id / "meta.json"
    existing = _read_meta(meta_path)
    started = interactive_child_had_started(existing)
    session = str(
        existing.get("provider_session_id")
        or existing.get("agent_session_id")
        or admission.get("provider_session_id")
        or admission.get("agent_session_id")
        or ""
    )
    agent = str(existing.get("agent") or admission.get("agent") or provider)
    if existing.get("liveness") == "terminal":
        failed = dict(existing)
        if failed.get("terminal_reason") == "wrapper_exception":
            failed["terminal_reason"] = "killed_after_start"
            failed.setdefault("error", str(exc))
            _write_meta(meta_path, failed)
        message = format_interactive_launch_failure(
            run_id=str(failed.get("run_id") or run_id),
            reason=str(failed.get("error") or exc),
            agent_session_id=str(
                failed.get("provider_session_id")
                or failed.get("agent_session_id")
                or session
            ),
            started=interactive_child_had_started(failed),
            provider=agent,
        )
        return message, failed

    if started:
        failed = {
            **existing,
            "status": "failed",
            "state": "failed",
            "liveness": "terminal",
            "terminal_reason": "killed_after_start",
            "error": str(exc),
            "completed_at": utc_now_iso(),
        }
        event_detail = "interactive session killed after start"
    else:
        failed = {
            **admission,
            "status": "failed",
            "state": "failed",
            "liveness": "terminal",
            "terminal_reason": "interactive_start_failed",
            "error": str(exc),
            "completed_at": utc_now_iso(),
        }
        event_detail = "interactive start failed"
    meta_path.parent.mkdir(parents=True, exist_ok=True)
    _write_meta(meta_path, failed)
    append_event(
        "lifecycle:failed",
        run_id,
        event_detail,
        {**failed, "meta": str(meta_path)},
    )
    _project_interactive_snapshot(run_id)
    message = format_interactive_launch_failure(
        run_id=run_id,
        reason=str(exc),
        agent_session_id=str(
            failed.get("provider_session_id")
            or failed.get("agent_session_id")
            or session
        ),
        started=started,
        provider=agent,
    )
    return message, failed


def _terminalize_interactive_launch(
    launch: InteractiveWorkspaceLaunch,
    receipt: dict[str, Any],
    *,
    status: str,
    exit_code: int,
    terminal_reason: str,
    exit_signal: int | None = None,
    error: str = "",
    extra: dict[str, Any] | None = None,
) -> dict[str, Any]:
    """Atomically terminalize the same interactive receipt and event identity."""
    completed_at = dt.datetime.now(dt.UTC).isoformat()
    terminal = {
        **receipt,
        "updated_at": completed_at,
        "completed_at": completed_at,
        "status": status,
        "liveness": "terminal",
        "exit_code": int(exit_code),
        "terminal_reason": terminal_reason,
        **(extra or {}),
    }
    if exit_signal is not None:
        terminal["exit_signal"] = signal.Signals(exit_signal).name
    if error:
        terminal["error"] = error
    _write_meta(launch.meta_path, terminal)
    append_event(
        f"lifecycle:{status}",
        launch.run_id,
        f"interactive Agent Workspace terminal: {terminal_reason}",
        {**terminal, "meta": str(launch.meta_path), "identity_required": True},
    )
    _flush_terminal_projection(launch.run_id, terminal, meta_path=launch.meta_path)
    return terminal


ANSI_PATTERN = re.compile(r"\x1b\[[0-9;?]*[A-Za-z]")
SESSION_PATTERNS = (
    re.compile(
        r"(?:^|\[[0-9]{2}:[0-9]{2}:[0-9]{2}\]\s+)session:\s*([A-Za-z0-9][A-Za-z0-9._:-]*)",
        re.MULTILINE,
    ),
    re.compile(
        r"\b(?:thread|conversation|session)[_-]?id['\"]?\s*[:=]\s*['\"]?([A-Za-z0-9][A-Za-z0-9._:-]*)",
        re.IGNORECASE,
    ),
)
TOKEN_PATTERN = re.compile(
    r"tokens:\s*([0-9]+)\s+in(?:\s*\(([0-9]+)\s+cached\))?\s*/\s*([0-9]+)\s+out",
    re.IGNORECASE,
)
# Authoritative per-run totals emitted by the run-closure footer
# (supervisor_async writes these for EVERY agent). Preferred over the
# per-event `tokens: N in / N out` lines, which only some provider
# formatters render and which would otherwise sum partial streaming usage.
FOOTER_TOKEN_PATTERNS = {
    "input": re.compile(r"^\s*tokens_input:\s*([0-9]+)", re.IGNORECASE | re.MULTILINE),
    "cached_input": re.compile(
        r"^\s*tokens_cached_input:\s*([0-9]+)", re.IGNORECASE | re.MULTILINE
    ),
    "cache_write": re.compile(
        r"^\s*tokens_cache_write:\s*([0-9]+)", re.IGNORECASE | re.MULTILINE
    ),
    "output": re.compile(
        r"^\s*tokens_output:\s*([0-9]+)", re.IGNORECASE | re.MULTILINE
    ),
}
JSON_TOKEN_PATTERNS = {
    "input": re.compile(r'"(?:input_tokens|inputTokens|prompt_tokens)"\s*:\s*([0-9]+)'),
    "cached_input": re.compile(
        r'"(?:cached_input_tokens|cached_prompt_tokens|cache_read_input_tokens|cacheReadInputTokens|cacheInputTokens)"\s*:\s*([0-9]+)'
    ),
    "cache_write": re.compile(
        r'"(?:cache_creation_input_tokens|cacheCreateTokens)"\s*:\s*([0-9]+)'
    ),
    "output": re.compile(
        r'"(?:output_tokens|outputTokens|completion_tokens)"\s*:\s*([0-9]+)'
    ),
}
COST_PATTERNS = (
    re.compile(
        r"cost(?:_usd)?['\"]?\s*[:=]\s*\$?([0-9]+(?:\.[0-9]+)?)",
        re.IGNORECASE,
    ),
    re.compile(r"\$([0-9]+\.[0-9]+)\s*(?:usd)?", re.IGNORECASE),
)
MODEL_ENV_VARS = (
    "VIBECRAFTED_PARENT_MODEL",
    "CLAUDE_MODEL",
    "CODEX_MODEL",
    "GEMINI_MODEL",
    "GROK_MODEL",
    "OMP_MODEL",
)
MODEL_PLACEHOLDERS = {"", "none", "null", "unknown", "pending"}


@dataclass
class SpawnHandle:
    """Live/completed handle to one spawned agent process and its artifact paths."""

    run_id: str
    agent: str
    skill: str
    mode: str
    root: Path
    process: Any
    pgid: int | None
    started_at: str
    command: list[str]
    meta_path: Path | None = None
    transcript_path: Path | None = None
    exit_code: int | None = None
    completed_at: str = ""
    session_id: str = ""
    _done: threading.Event = field(default_factory=threading.Event, repr=False)
    _thread: threading.Thread | None = field(default=None, repr=False)

    @property
    def pid(self) -> int:
        """Underlying child process id."""
        return self.process.pid

    def wait(self, timeout: float | None = None) -> int:
        """Block until the spawned process finishes; raise TimeoutError if it doesn't."""
        if not self._done.wait(timeout):
            raise TimeoutError(f"spawn {self.run_id} still running")
        return int(self.exit_code if self.exit_code is not None else 1)


class _SandboxProcess:
    """Process-like stand-in used when a run executes inside the sandbox adapter."""

    def __init__(self) -> None:
        """Adopt the current process's own pid as the stand-in "child" pid."""
        self.pid = os.getpid()

    def wait(self) -> int:
        """Sandbox execution is synchronous by the time this is called; always exit 0."""
        return 0


def _set_child_pgid() -> None:
    """Put the current (child) process into its own process group; best-effort."""
    try:
        os.setpgid(0, 0)
    except OSError:
        pass


def _headless_policy_flags(
    agent: str, controls: ExecutionControls | None
) -> tuple[list[str], str]:
    """Provider flags + effective permission word for one headless launch.

    With explicit controls, the resolved argv from execution_controls is used
    verbatim — the resolver already refused anything the provider cannot
    enforce, so nothing here approximates a requested restriction. Without
    controls this consumes the same shared decision as the typed lane: durable
    config opt-in (server_config.durable_permission_selection) over the fleet
    default ``auto`` (Founder decision 13716da4a2b8af7049ea1565) — never a
    per-provider bypass fallback.
    """
    if controls is not None:
        if controls.provider != agent:
            raise ValueError(
                f"execution controls resolved for {controls.provider}, not {agent}"
            )
        return list(controls.provider_flags), controls.permissions_effective
    from .execution_controls import default_permissions
    from .server_config import durable_permission_selection

    configured_word, _source = durable_permission_selection(agent)
    policy = resolve_provider_policy(
        agent, "local-native", configured_word or default_permissions(agent), "headless"
    )
    if not policy.supported:
        raise ValueError(policy.reason)
    return list(policy.flags), policy.permissions


def _default_command(
    agent: str, prompt: str, controls: ExecutionControls | None = None
) -> list[str]:
    """Build the argv for launching *agent* with *prompt* passed inline (ARG_MAX risk).

    Raises ValueError for the deprecated gemini CLI and any unsupported agent.
    """
    if agent == "gemini":
        raise ValueError(
            "gemini CLI is deprecated. Google Antigravity CLI (agy) is the replacement. "
            "Use 'vibecrafted workflow agy --prompt ...' (or agy in other launchers). "
            "No execution path may launch the gemini binary."
        )
    flags, permissions = _headless_policy_flags(agent, controls)
    if agent == "claude":
        return [
            "claude",
            "--print",
            "--verbose",
            *flags,
            prompt,
        ]
    if agent == "codex":
        return ["codex", "exec", *flags, prompt]
    if agent == "agy":
        # Inline lane only: --print takes the prompt as its value (Go flags), so
        # the prompt is on argv here like every other provider in this builder.
        # Every supervised launch uses _stdin_command (private stream-json).
        return [
            "agy",
            *flags,
            "--add-dir",
            ".",
            "--print-timeout",
            "30m",
            "--print",
            prompt,
        ]
    if agent == "junie":
        return [
            "junie",
            *flags,
            "--task",
            prompt,
            "--project",
            ".",
            "--skip-update-check",
        ]
    if agent == "grok":
        return [
            "grok",
            "--cwd",
            ".",
            *flags,
            "--no-alt-screen",
            "--single",
            prompt,
        ]
    if agent == "cursor":
        flags = list(
            _materialize_cursor_permission_flags(flags, permissions=permissions)
        )
        return [
            "cursor-agent",
            "-p",
            "--output-format",
            "stream-json",
            *flags,
            prompt,
        ]
    if agent == "kimi":
        # kimi print mode has no stdin prompt lane (0.42.0): ``-p`` takes the
        # prompt as its argv value — the only headless input kimi offers.
        # ps-visible and ARG_MAX-bound by construction; documented in
        # prompt_transport (ARGV_TRANSPORT).
        return [
            "kimi",
            *flags,
            "-p",
            prompt,
            "--output-format",
            "stream-json",
        ]
    if agent == "copilot":
        return [
            "copilot",
            *flags,
            "--no-ask-user",
            "--no-auto-update",
            "--output-format",
            "json",
            "-p",
            prompt,
        ]
    if agent == "omp":
        # omp accepts the prompt as a positional argv message too; the stdin
        # lane (_stdin_command) stays primary so prompts never hit ps(1).
        return ["omp", "-p", "--mode", "json", *flags, prompt]
    raise ValueError(f"unsupported agent: {agent}")


def _stdin_command(agent: str, controls: ExecutionControls | None = None) -> list[str]:
    """Build an agent command that receives the full prompt on stdin.

    The command argv must carry flags and paths only; large prompt bodies belong
    on stdin so they do not leak through ps(1) or hit ARG_MAX. ``controls``
    (execution_controls.resolve_execution_controls) replaces the default
    permission flags with the caller's resolved ``--permissions`` /
    ``--sandbox`` argv.
    """

    if agent == "gemini":
        raise ValueError(
            "gemini CLI is deprecated. Google Antigravity CLI (agy) is the replacement. "
            "Use 'vibecrafted workflow agy --prompt ...' (or agy in other launchers). "
            "No execution path may launch the gemini binary."
        )
    flags, permissions = _headless_policy_flags(agent, controls)
    if agent == "claude":
        return [
            "claude",
            "-p",
            "--output-format",
            "stream-json",
            "--verbose",
            *flags,
        ]
    if agent == "codex":
        return [
            "codex",
            "exec",
            "--json",
            *flags,
            "-",
        ]
    if agent == "agy":
        # agy >= 1.2 print mode has exactly one stdin lane: stream-json (one
        # NDJSON user turn per line, requires stream-json output). ``--print=``
        # enters print mode with an empty positional so the prompt never
        # touches argv; the supervisor materializes the NDJSON turn from the
        # prompt file (prompt_transport.materialize_stdin_file) and the
        # AgentStreamParser reads model/session/tokens from the result event.
        return [
            "agy",
            *flags,
            "--add-dir",
            ".",
            "--print-timeout",
            "30m",
            "--print=",
            "--input-format",
            "stream-json",
            "--output-format",
            "stream-json",
        ]
    if agent == "junie":
        return [
            "junie",
            "--project",
            ".",
            "--skip-update-check",
            "--input-format",
            "text",
            "--output-format",
            "json-stream",
        ]
    if agent == "grok":
        return [
            "grok",
            "--cwd",
            ".",
            *flags,
            "--no-alt-screen",
            "--output-format",
            "streaming-json",
            "--prompt-file",
            "/dev/stdin",
        ]
    if agent == "cursor":
        flags = list(
            _materialize_cursor_permission_flags(flags, permissions=permissions)
        )
        return [
            "cursor-agent",
            "-p",
            "--output-format",
            "stream-json",
            *flags,
        ]
    if agent == "kimi":
        # kimi print mode cannot consume a prompt from stdin (0.42.0: ``-p``
        # requires its value on argv; a bare ``-p`` is a parse error). The
        # private stdin contract has no kimi shape — refusing here keeps the
        # argv-inline builder (``_default_command`` via
        # ``workflow.build_launch_command``) as the only kimi lane instead of
        # launching a TUI that silently ignores the wired prompt.
        raise ValueError(
            "kimi print mode has no stdin prompt lane: -p takes the prompt "
            "as its argv value. Supervised kimi launches inline the prompt "
            "from the materialized prompt file (workflow.build_launch_command "
            "kimi branch); the stdin contract cannot carry kimi."
        )
    if agent == "copilot":
        return [
            "copilot",
            *flags,
            "--no-ask-user",
            "--no-auto-update",
            "--output-format",
            "json",
        ]
    if agent == "omp":
        # omp print mode consumes the prompt from stdin when no positional
        # message is given (verified 18.11.0: `echo … | omp -p` rc 0), so the
        # private stdin contract fits natively — argv carries flags only.
        return [
            "omp",
            "-p",
            "--mode",
            "json",
            *flags,
        ]
    raise ValueError(f"unsupported agent: {agent}")


def _resolve_agent_command(
    agent: str,
    command: Sequence[str],
    environment: dict[str, str] | None = None,
) -> list[str]:
    """Pin a provider argv to the executable found on the canonical tool PATH.

    Commands owned by another runtime (for example ``python -m`` supervisors or
    test fixtures) pass through unchanged.  A provider command embedded in
    ``bash -c`` (``agy …``/``cli …`` as the first word) is pinned inside that
    script; today every supervised provider, agy included, is a direct argv.
    """

    resolved = list(command)
    if not resolved:
        raise ValueError("agent command must not be empty")
    cli_name = agent_cli_name(agent)
    argv0_name = Path(resolved[0]).name
    direct_provider = argv0_name in {agent, cli_name}
    shell_provider = (
        len(resolved) >= 3
        and Path(resolved[0]).name == "bash"
        and resolved[1] == "-c"
        and (
            re.match(rf"^{re.escape(agent)}(?=\s)", resolved[2]) is not None
            or re.match(rf"^{re.escape(cli_name)}(?=\s)", resolved[2]) is not None
        )
    )
    if not direct_provider and not shell_provider:
        return resolved
    search_path = agent_tool_search_path(environment)
    executable = which(cli_name, path=search_path)
    if executable is None:
        raise FileNotFoundError(
            f"provider executable '{cli_name}' (agent key '{agent}') not found "
            "on canonical agent tool PATH"
        )
    if direct_provider:
        resolved[0] = executable
    else:
        pattern = rf"^({re.escape(agent)}|{re.escape(cli_name)})(?=\s)"
        resolved[2] = re.sub(
            pattern,
            shlex.quote(executable),
            resolved[2],
            count=1,
        )
    return resolved


def _parse_launcher_assignment(path: Path, key: str) -> str:
    """Extract the shell-quoted value assigned to *key* (e.g. ``meta=...``) in a launcher script."""
    if not path.is_file():
        return ""
    prefix = f"{key}="
    for line in path.read_text(encoding="utf-8", errors="replace").splitlines():
        if not line.startswith(prefix):
            continue
        raw = line.split("=", 1)[1].strip()
        try:
            parts = shlex.split(raw)
        except ValueError:
            return raw.strip("'\"")
        return parts[0] if parts else ""
    return ""


def _read_meta(path: Path | None) -> dict[str, Any]:
    """Read a launcher meta.json; return {} on missing path, missing file, or bad JSON."""
    if path is None or not path.is_file():
        return {}
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError):
        return {}


def _write_meta(path: Path, payload: dict[str, Any]) -> None:
    """Write *payload* as pretty JSON, published atomically via tmp + rename.

    meta.json is read concurrently by the launcher, the startup watcher, the
    control-plane sync and dashboards; an in-place write truncates first, so
    a concurrent reader could observe an empty file. os.replace guarantees a
    reader sees the previous document or the new one, never a torn one.
    """
    tmp_path = path.with_name(f"{path.name}.tmp.{os.getpid()}")
    tmp_path.write_text(
        json.dumps(payload, indent=2, ensure_ascii=False) + "\n", encoding="utf-8"
    )
    os.replace(tmp_path, path)


def _read_text(path: Path) -> str:
    """Best-effort UTF-8 read of *path*; returns "" on any OSError."""
    try:
        return path.read_text(encoding="utf-8", errors="replace")
    except OSError:
        return ""


def _write_text(path: Path, text: str) -> None:
    """Write *text* to *path* as UTF-8, creating parent directories as needed."""
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(text, encoding="utf-8")


def _clean_text(text: str) -> str:
    """Strip ANSI escape sequences from terminal-captured transcript text."""
    return ANSI_PATTERN.sub("", text)


def _extract_session(text: str) -> str:
    """Find the last session/thread/conversation id mentioned in transcript text."""
    clean = _clean_text(text)
    for pattern in SESSION_PATTERNS:
        matches = pattern.findall(clean)
        if matches:
            return str(matches[-1])
    return ""


def _extract_tokens(text: str) -> dict[str, int | None]:
    """Parse token usage from combined transcript/report text.

    Prefers the authoritative run-closure footer, then JSON usage fields,
    then per-event ``tokens: N in / N out`` lines, in that priority order.
    ``events`` counts the provider usage evidence found; 0 means the text
    carries none (a seeded ``tokens_input: 0`` template is not evidence).
    """
    clean = _clean_text(text)
    found = TOKEN_PATTERN.findall(clean)
    json_tokens = {
        key: sum(int(match) for match in pattern.findall(clean))
        for key, pattern in JSON_TOKEN_PATTERNS.items()
    }
    # Prefer the authoritative run-closure footer totals when present: they are
    # written for every agent and carry the final per-run usage, so they work
    # uniformly across providers and never sum partial streaming deltas.
    footer_in = FOOTER_TOKEN_PATTERNS["input"].findall(clean)
    footer_out = FOOTER_TOKEN_PATTERNS["output"].findall(clean)
    if footer_in or footer_out:
        footer_cached = FOOTER_TOKEN_PATTERNS["cached_input"].findall(clean)
        footer_cache_write = FOOTER_TOKEN_PATTERNS["cache_write"].findall(clean)
        input_tokens = int(footer_in[-1]) if footer_in else 0
        cached_tokens = int(footer_cached[-1]) if footer_cached else 0
        cache_write_tokens = int(footer_cache_write[-1]) if footer_cache_write else None
        output_tokens = int(footer_out[-1]) if footer_out else 0
        total_tokens = _tokens_total(input_tokens, cached_tokens, output_tokens)
        if total_tokens or (not found and not any(json_tokens.values())):
            return {
                "input": input_tokens,
                "cached_input": cached_tokens,
                "cache_write": cache_write_tokens,
                "output": output_tokens,
                "total": total_tokens,
                # A zero footer is a seeded template or a pre-telemetry close,
                # not a provider measurement.
                "events": 1 if total_tokens else 0,
            }
    if any(json_tokens.values()):
        return {
            "input": json_tokens["input"],
            "cached_input": json_tokens["cached_input"],
            "cache_write": json_tokens["cache_write"]
            if json_tokens["cache_write"]
            else None,
            "output": json_tokens["output"],
            "total": _tokens_total(
                json_tokens["input"],
                json_tokens["cached_input"],
                json_tokens["output"],
            ),
            "events": max(
                len(JSON_TOKEN_PATTERNS["input"].findall(clean)),
                len(JSON_TOKEN_PATTERNS["output"].findall(clean)),
            ),
        }
    if not found:
        return {
            "input": 0,
            "cached_input": 0,
            "cache_write": None,
            "output": 0,
            "total": 0,
            "events": 0,
        }
    input_tokens = cached_tokens = output_tokens = 0
    for raw_in, raw_cached, raw_out in found:
        input_tokens += int(raw_in)
        cached_tokens += int(raw_cached or 0)
        output_tokens += int(raw_out)
    return {
        "input": input_tokens,
        "cached_input": cached_tokens,
        "cache_write": None,
        "output": output_tokens,
        "total": _tokens_total(input_tokens, cached_tokens, output_tokens),
        "events": len(found),
    }


def _extract_cost(text: str) -> float | None:
    """Parse a USD cost from combined transcript/report text, preferring the footer."""
    clean = _clean_text(text)
    footer = re.findall(
        r"^\s*cost_usd:\s*\$?([0-9]+(?:\.[0-9]+)?)\s*$",
        clean,
        re.IGNORECASE | re.MULTILINE,
    )
    if footer:
        return round(float(footer[-1]), 6)
    totals = re.findall(
        r'"(?:total_cost_usd|totalCostUsd|total_cost)"\s*:\s*([0-9]+(?:\.[0-9]+)?)',
        clean,
        re.IGNORECASE,
    )
    if totals:
        return round(float(totals[-1]), 6)
    item_costs = re.findall(r'"cost"\s*:\s*([0-9]+(?:\.[0-9]+)?)', clean, re.IGNORECASE)
    if item_costs:
        return round(sum(float(value) for value in item_costs), 6)
    for pattern in COST_PATTERNS:
        matches = pattern.findall(clean)
        if not matches:
            continue
        try:
            return round(float(matches[-1]), 6)
        except ValueError:
            pass
    return None


def _clean_model(value: object) -> str:
    """Normalize a candidate model value; return "" for known placeholder strings."""
    raw = str(value or "").strip()
    return "" if raw.lower() in MODEL_PLACEHOLDERS else raw


def _fallback_model(agent: object) -> str:
    """Synthesize a `<agent>-cli-default` model label when no real model is known."""
    agent_name = str(agent or "agent").strip() or "agent"
    if agent_name == "agy":
        return "gemini-cli-default"
    return f"{agent_name}-cli-default"


def _extract_model_from_text(text: str) -> str:
    """Find a model identifier in transcript/report text via footer, JSON, or usage-map fields."""
    clean = _clean_text(text)
    for match in reversed(re.findall(r"^model:\s*(.+?)\s*$", clean, re.MULTILINE)):
        model = _clean_model(match)
        if model:
            return model
    json_models = re.findall(
        r'"(?:model|model_id|modelId|model_name|modelName)"\s*:\s*"([^"]+)"',
        clean,
    )
    for match in json_models:
        model = _clean_model(match)
        if model:
            return model
    model_usage_maps = re.findall(r'"modelUsage"\s*:\s*\{\s*"([^"]+)"', clean)
    if model_usage_maps:
        return _clean_model(model_usage_maps[-1])
    return ""


def _resolve_model(payload: dict[str, Any], combined_text: str) -> str:
    """Resolve the effective model: payload, then env vars, then text, then fallback."""
    model = _clean_model(payload.get("model"))
    if model:
        return model
    for env_name in MODEL_ENV_VARS:
        model = _clean_model(os.environ.get(env_name))
        if model:
            return model
    model = _extract_model_from_text(combined_text)
    if model:
        return model
    return _fallback_model(payload.get("agent"))


def _parse_dt(value: object) -> dt.datetime | None:
    """Parse an ISO-ish timestamp string to a UTC-aware datetime, or None if unparsable."""
    if not isinstance(value, str) or not value:
        return None
    try:
        # Keep legacy date-only parsing and embedded-Z rejection.
        normalized_timestamp = value.replace("Z", "+00:00")
        parsed = dt.datetime.fromisoformat(normalized_timestamp)
    except ValueError:
        return None
    if parsed.tzinfo is None:
        parsed = parsed.replace(tzinfo=dt.UTC)
    return parsed.astimezone(dt.UTC)


def _resolve_duration(
    payload: dict[str, Any], completed_at_iso: str
) -> float | int | None:
    """Resolve run duration: an existing valid value wins, else derive from timestamps."""
    current = payload.get("duration_s")
    if isinstance(current, (int, float)):
        return current
    if (
        isinstance(current, str)
        and current.strip()
        and current.lower()
        not in {
            "none",
            "null",
        }
    ):
        try:
            return round(float(current), 3)
        except ValueError:
            pass
    completed_dt = _parse_dt(completed_at_iso)
    started_dt = _parse_dt(payload.get("created_at") or payload.get("updated_at"))
    if completed_dt is None or started_dt is None:
        return None
    return round((completed_dt - started_dt).total_seconds(), 3)


def write_meta(
    meta_path: str | os.PathLike[str],
    status: str,
    agent: str,
    mode: str,
    root: str | os.PathLike[str],
    input_ref: str,
    report: str,
    transcript: str,
    launcher: str,
    model: str = "",
    model_requested: str = "",
    prompt_id: str = "",
    run_id: str = "",
    loop_nr: str | int = 0,
    skill_code: str = "",
    framework_version: str = "",
    execution_controls: str = "",
) -> Path:
    """Write initial launcher meta.json."""
    meta = Path(meta_path)
    meta.parent.mkdir(parents=True, exist_ok=True)

    loop_nr_value: str | int
    try:
        loop_nr_value = int(loop_nr)
    except (ValueError, TypeError):
        loop_nr_value = loop_nr

    now_iso = dt.datetime.now(dt.UTC).isoformat()
    payload: dict[str, Any] = {
        "created_at": now_iso,
        "updated_at": now_iso,
        "status": status,
        "agent": agent,
        "mode": mode,
        "root": str(root),
        "input": input_ref,
        "report": report,
        "transcript": transcript,
        "launcher": launcher,
        "prompt_id": prompt_id,
        "run_id": run_id,
        "loop_nr": loop_nr_value,
        "skill_code": skill_code,
        "framework_version": framework_version,
        "dispatcher": dispatcher_identity(),
        "exit_code": None,
        "launcher_pid": None,
        "liveness": "pid_pending",
        "model": model,
    }
    payload.update(provider_launch_environment_receipt(agent, os.environ))
    requested = str(model_requested or model or "").strip()
    if requested:
        payload["model_requested"] = requested

    if execution_controls:
        controls = controls_from_receipt(json.loads(execution_controls))
        if controls is None or controls.provider != agent:
            raise ValueError(
                "execution controls receipt does not match launcher provider"
            )
        payload["execution_controls"] = controls.receipt()
    # Cut A: durable workspace identity on every new run meta (best-effort).
    try:
        from .workspace_catalog import resolve_run_workspace_identity

        identity = resolve_run_workspace_identity(root=root, create_if_missing=True)
        payload.update(identity.to_meta_fields())
    # Catalog metadata identity is advisory at this boundary; any resolver exception must retain the
    # original catalog and debug diagnostic instead of aborting its write.
    except Exception as exc:  # noqa: BLE001
        import logging

        logging.getLogger(__name__).debug(
            "workspace identity stamp skipped: %s", exc, exc_info=False
        )

    _write_meta(meta, payload)
    if run_id:
        append_event(
            "lifecycle:active",
            run_id,
            "legacy shell launcher metadata is live",
            {
                "state": "active",
                "agent": agent,
                "skill": skill_code,
                "mode": mode,
                "root": normalize_run_root(str(root), Path.cwd()),
                "report": report,
                "transcript": transcript,
                "launcher": launcher,
                "model": model,
                **(
                    {"model_requested": str(model_requested).strip()}
                    if str(model_requested or "").strip()
                    else {}
                ),
                "prompt_id": prompt_id,
                "started_at": now_iso,
                "liveness": "active",
                "identity_required": True,
                "meta": str(meta),
                "runtime": "shell",
            },
        )
    return meta


def finish_meta(
    meta_path: str | os.PathLike[str],
    status: str,
    exit_code: int | str = 0,
) -> Path | None:
    """Mark a launcher meta.json terminal and persist completion telemetry."""
    meta = Path(meta_path)
    if not meta.is_file():
        return None

    try:
        payload = json.loads(_read_text(meta))
    except json.JSONDecodeError:
        return None
    launcher_claim_digest = str(
        payload.get("claim_digest") or os.environ.get(CLAIM_DIGEST_ENV, "")
    ).strip()
    if launcher_claim_digest:
        payload["claim_digest"] = launcher_claim_digest

    completed_at = dt.datetime.now(dt.UTC)
    started_dt = _parse_dt(payload.get("created_at") or payload.get("updated_at"))
    duration_s = (
        round((completed_at - started_dt).total_seconds(), 3)
        if started_dt is not None
        else None
    )

    payload["updated_at"] = completed_at.isoformat()
    payload["completed_at"] = completed_at.isoformat()
    payload["duration_s"] = duration_s
    payload["status"] = status
    payload["exit_code"] = int(exit_code)
    payload["liveness"] = "terminal"

    transcript_raw = str(payload.get("transcript") or "")
    transcript_text = (
        _read_text(Path(transcript_raw))[: 64 * 1024] if transcript_raw else ""
    )
    session_id = _extract_session(transcript_text)
    if session_id:
        payload["session_id"] = session_id

    _write_meta(meta, payload)
    run_id = str(payload.get("run_id") or "").strip()
    if run_id:
        append_event(
            f"lifecycle:{status}",
            run_id,
            f"legacy shell launcher finished with status {status}",
            {
                "state": status,
                "exit_code": int(exit_code),
                "completed_at": completed_at.isoformat(),
                "liveness": "terminal",
                "root": str(payload.get("root") or ""),
                "agent": str(payload.get("agent") or ""),
                "skill": str(payload.get("skill_code") or payload.get("skill") or ""),
                "identity_required": True,
                "runtime": "shell",
            },
        )
    return meta


def _parse_frontmatter(text: str) -> tuple[dict[str, str], str]:
    """Split a markdown document into its ``---`` frontmatter dict and body."""
    lines = text.splitlines()
    if not lines or lines[0].strip() != "---":
        return {}, text
    end = None
    for index, line in enumerate(lines[1:], start=1):
        if line.strip() == "---":
            end = index
            break
    if end is None:
        return {}, text
    data: dict[str, str] = {}
    for line in lines[1:end]:
        if ":" not in line:
            continue
        key, value = line.split(":", 1)
        data[key.strip()] = value.strip()
    body = "\n".join(lines[end + 1 :]).lstrip("\n")
    return data, body


def _render_frontmatter(data: dict[str, object]) -> str:
    """Render *data* as ``---``-delimited YAML-ish frontmatter in a fixed key order."""
    order = [
        "run_id",
        "prompt_id",
        "agent",
        "skill",
        "project",
        "model",
        "model_requested",
        "status",
        "claim_status",
        "claim_kind",
        "date",
        "session_id",
        "artifact_stem",
        "artifact_kind",
        "repo_path",
        "tokens_input",
        "tokens_cached_input",
        "tokens_cache_write",
        "tokens_output",
        "tokens_total",
        "cost_usd",
        "cost_source",
    ]
    lines = ["---"]
    emitted = set()
    for key in order:
        if key in data:
            value = data.get(key)
            lines.append(f"{key}: {value if value not in (None, '') else 'unknown'}")
            emitted.add(key)
    for key in sorted(k for k in data if k not in emitted):
        value = data.get(key)
        lines.append(f"{key}: {value if value not in (None, '') else 'unknown'}")
    lines.extend(["---", ""])
    return "\n".join(lines)


def _slug_component(value: object, fallback: str) -> str:
    """Sanitize *value* into a filename-safe slug, falling back to *fallback* if empty."""
    raw = str(value or fallback)
    raw = re.sub(r"[^A-Za-z0-9._-]+", "-", raw).strip("-")
    return raw or fallback


def _same_file(left: Path, right: Path) -> bool:
    """True when both paths resolve to the same inode, falling back to path equality."""
    try:
        return left.samefile(right)
    except OSError:
        return left == right


def _infer_artifact_store(meta: Path) -> dict[str, object] | None:
    """Infer the org/repo/day artifact-store location from a meta.json's directory shape.

    Returns None unless meta lives at ``.../<org>/<repo>/<YYYY_MMDD>/reports/``.
    """
    reports_dir = meta.parent
    if reports_dir.name != "reports":
        return None
    day_dir = reports_dir.parent
    if not re.fullmatch(r"[0-9]{4}_[0-9]{4}", day_dir.name):
        return None
    repo_dir = day_dir.parent
    org_dir = repo_dir.parent
    if not org_dir.name or not repo_dir.name:
        return None
    yyyy, mmdd = day_dir.name.split("_", 1)
    return {
        "reports_dir": reports_dir,
        "day": f"{yyyy}-{mmdd[:2]}-{mmdd[2:]}",
        "org": org_dir.name,
        "repo": repo_dir.name,
    }


def _unique_stem(
    reports_dir: Path, stem: str, sources: list[Path], disambiguator: str
) -> str:
    """Find a collision-free artifact stem, treating *sources* themselves as non-blocking."""
    candidates = [stem]
    if disambiguator:
        candidates.append(f"{stem}-{_slug_component(disambiguator, 'run')}")
    for index in range(2, 100):
        candidates.append(f"{stem}-{index}")

    suffixes = [".md", ".transcript.log", ".meta.json"]
    for candidate in candidates:
        blocked = False
        for suffix in suffixes:
            target = reports_dir / f"{candidate}{suffix}"
            if not target.exists():
                continue
            if any(
                source and source.exists() and _same_file(target, source)
                for source in sources
            ):
                continue
            blocked = True
            break
        if not blocked:
            return candidate
    return candidates[-1]


def _move_artifact(source: Path, target: Path) -> Path:
    """Rename *source* to *target*; no-op (returns source) if already identical or missing."""
    if not str(source) or not source.is_file() or _same_file(source, target):
        return source
    target.parent.mkdir(parents=True, exist_ok=True)
    source.rename(target)
    return target


def _leave_compat_link(announced: Path, final: Path) -> None:
    """Symlink the originally-announced artifact path to its relocated *final* path.

    Best-effort: never overwrites an existing path and swallows OSError.
    """
    if not str(announced) or not final.is_file():
        return
    if announced == final or _same_file(announced, final):
        return
    if announced.is_symlink() or announced.exists():
        return
    try:
        announced.parent.mkdir(parents=True, exist_ok=True)
        link_target: str | Path = (
            final.name if announced.parent == final.parent else final
        )
        announced.symlink_to(link_target)
    except OSError:
        pass


def _footer(marker: str, payload: dict[str, object]) -> str:
    """Render the `<!-- vibecrafted-artifact-footer:MARKER -->` run-closure YAML block."""
    lines = [
        "",
        f"<!-- vibecrafted-artifact-footer:{marker} -->",
        "---",
        "run_closure:",
        f"  run_id: {payload.get('run_id', 'unknown')}",
        f"  session_id: {payload.get('session_id') or 'unknown'}",
        f"  tokens_input: {payload.get('tokens_input', 0)}",
        f"  tokens_cached_input: {payload.get('tokens_cached_input', 0)}",
    ]
    if payload.get("tokens_cache_write") is not None:
        lines.append(f"  tokens_cache_write: {payload.get('tokens_cache_write')}")
    lines.extend(
        [
            f"  tokens_output: {payload.get('tokens_output', 0)}",
            f"  tokens_total: {payload.get('tokens_total', 0)}",
            f"  cost_usd: {payload.get('cost_usd') if payload.get('cost_usd') is not None else 'unknown'}",
        ]
    )
    if payload.get("cost_source"):
        lines.append(f"  cost_source: {payload.get('cost_source')}")
    if payload.get("model_requested"):
        lines.append(f"  model_requested: {payload.get('model_requested')}")
    lines.extend(
        [
            f"  status: {payload.get('status', 'unknown')}",
            f"  completed_at: {payload.get('completed_at', 'unknown')}",
            f'  resume_hint: "{payload.get("resume_hint", "")}"',
            "---",
            "",
        ]
    )
    return "\n".join(lines)


def _normalize_markdown_artifact(
    path: Path,
    payload: dict[str, object],
    *,
    fallback_body: str = "",
    extra_frontmatter: Mapping[str, str] | None = None,
) -> None:
    """Stamp/refresh frontmatter and append the run-closure footer on a markdown artifact.

    ``extra_frontmatter`` carries run-close telemetry for the report only; the
    transcript never gets it, so a re-close cannot mistake its own failure
    summary for a provider line.
    """
    text = _read_text(path)
    if not text and fallback_body:
        text = fallback_body
    if not text:
        return
    fm, body = _parse_frontmatter(text)
    frontmatter: dict[str, object] = dict(fm)
    skill_value = payload.get("skill_code") or payload.get("skill") or "unknown"
    status_value = payload.get("status", "unknown")
    frontmatter_update = {
        "run_id": payload.get("run_id", "unknown"),
        "prompt_id": payload.get("prompt_id", "unknown"),
        "agent": payload.get("agent", "unknown"),
        "skill": skill_value,
        "model": payload.get("model", "unknown"),
        "status": status_value,
        # claim_status mirrors status for board triangulation; agent may have
        # set a more specific claim already in frontmatter — only fill if empty.
        "claim_status": frontmatter.get("claim_status") or status_value,
        "claim_kind": frontmatter.get("claim_kind") or skill_value,
        "date": payload.get("date", "unknown"),
        "session_id": payload.get("session_id") or "unknown",
        "artifact_stem": payload.get("artifact_stem", "unknown"),
        "artifact_kind": payload.get("artifact_kind", "unknown"),
        "repo_path": payload.get("root", "unknown"),
        "tokens_input": payload.get("tokens_input", 0),
        "tokens_cached_input": payload.get("tokens_cached_input", 0),
        "tokens_output": payload.get("tokens_output", 0),
        "tokens_total": payload.get("tokens_total", 0),
        "cost_usd": payload.get("cost_usd")
        if payload.get("cost_usd") is not None
        else "unknown",
    }
    if payload.get("model_requested"):
        frontmatter_update["model_requested"] = payload.get("model_requested")
    else:
        frontmatter.pop("model_requested", None)
    if payload.get("tokens_cache_write") is not None:
        frontmatter_update["tokens_cache_write"] = payload.get("tokens_cache_write")
    else:
        frontmatter.pop("tokens_cache_write", None)
    if payload.get("cost_source"):
        frontmatter_update["cost_source"] = payload.get("cost_source")
    else:
        frontmatter.pop("cost_source", None)
    frontmatter_update.update(extra_frontmatter or {})
    frontmatter.update(frontmatter_update)
    marker = str(payload.get("run_id") or "unknown")
    new_text = _render_frontmatter(frontmatter) + body.rstrip() + "\n"
    if f"vibecrafted-artifact-footer:{marker}" not in new_text:
        new_text += _footer(marker, payload)
    _write_text(path, new_text)


def finalize_artifacts(
    meta_path: str | os.PathLike[str],
    report_path: str | os.PathLike[str] | None = None,
    transcript_path: str | os.PathLike[str] | None = None,
) -> Path | None:
    """Finalize a launcher run's report/transcript/meta artifact contract."""
    meta = Path(meta_path)
    if not meta.is_file():
        return None

    try:
        payload = json.loads(_read_text(meta))
    except json.JSONDecodeError:
        return None
    launcher_claim_digest = str(
        payload.get("claim_digest") or os.environ.get(CLAIM_DIGEST_ENV, "")
    ).strip()
    if launcher_claim_digest:
        payload["claim_digest"] = launcher_claim_digest

    report = Path(str(report_path or payload.get("report", "")))
    transcript = Path(str(transcript_path or payload.get("transcript", "")))
    announced_report = report
    announced_transcript = transcript
    transcript_text = _read_text(transcript) if str(transcript) else ""
    report_text = _read_text(report) if str(report) else ""
    combined_text = f"{transcript_text}\n{report_text}"

    recorded_session = str(payload.get("session_id") or "")
    session_id = recorded_session or _extract_session(combined_text)
    tokens = _extract_tokens(combined_text)
    usage = usage_record(
        int(tokens.get("events") or 0),
        tokens_input=int(tokens["input"] or 0),
        tokens_cached_input=int(tokens["cached_input"] or 0),
        tokens_cache_write=tokens["cache_write"],
        tokens_output=int(tokens["output"] or 0),
        source="transcript",
    )
    flat_tokens = usage.flat()
    cost = _extract_cost(combined_text)
    completed_at = payload.get("completed_at") or dt.datetime.now(dt.UTC).isoformat()
    artifact_time = dt.datetime.now().astimezone().isoformat(timespec="seconds")
    root = payload.get("root") or os.getcwd()
    resume_hint = (
        f"Use `cd {root} && vc-resume --session {session_id}` to continue work with this Agent."
        if session_id
        else f"Use `cd {root} && vc-resume --session <session_id>` to continue work with this Agent."
    )

    payload["session_id"] = session_id or payload.get("session_id") or ""
    payload["model"] = _resolve_model(payload, combined_text)
    telemetry = build_run_telemetry(
        usage=usage,
        model=str(payload["model"] or ""),
        reported_cost=cost,
        reported_cost_source="provider_reported" if cost is not None else None,
        session_candidate=str(payload["session_id"]),
        session_source="meta" if recorded_session else "transcript",
        parents=parent_session_ids(
            extra={
                key: payload.get(key)
                for key in (
                    "runtime_session_id",
                    "vibecrafted_session_id",
                    "parent_provider_session_id",
                    "fork_source_session_id",
                )
            }
        ),
        failure=None,
        agent=str(payload.get("agent") or ""),
        started_at=payload.get("started_at") or payload.get("created_at"),
        completed_at=completed_at,
    )
    flat_tokens = telemetry.usage.flat()
    payload["duration_s"] = _resolve_duration(payload, str(completed_at))
    if "tokens_cache_write" not in flat_tokens:
        payload.pop("tokens_cache_write", None)
    payload.pop("failure", None)
    payload.update(telemetry.meta_fields())
    payload["token_usage"] = {
        key.removeprefix("tokens_"): value for key, value in flat_tokens.items()
    }
    payload["resume_hint"] = resume_hint
    payload["artifact_contract"] = "vibecrafted.agent-artifact.v1"
    payload["date"] = payload.get("date") or artifact_time

    store = _infer_artifact_store(meta)
    if store:
        reports_dir = Path(str(store["reports_dir"]))
        session_for_name = (
            session_id
            or payload.get("session_id")
            or payload.get("run_id")
            or "unknown-session"
        )
        stem = (
            f"{store['day']}_"
            f"{_slug_component(store['org'], 'org')}_"
            f"{_slug_component(store['repo'], 'repo')}_"
            f"{_slug_component(session_for_name, 'session')}-report"
        )
        stem = _unique_stem(
            reports_dir,
            stem,
            [report, transcript, meta],
            str(payload.get("run_id") or ""),
        )
        final_report = reports_dir / f"{stem}.md"
        final_transcript = reports_dir / f"{stem}.transcript.log"
        final_meta = reports_dir / f"{stem}.meta.json"
        # Contract rule 6: refuse bare Untitled*.md and unbound report paths.
        require_bound_markdown(
            final_report,
            run_id=str(payload.get("run_id") or ""),
            claim_digest=str(payload.get("claim_digest") or ""),
        )

        report = _move_artifact(report, final_report)
        transcript = _move_artifact(transcript, final_transcript)
        _leave_compat_link(announced_report, report)
        _leave_compat_link(announced_transcript, transcript)
        # The worker writes its final handoff next to the announced transcript as
        # `<transcript>.last-message.md` (codex --output-last-message, claude/gemini
        # salvage). Relocate it alongside the transcript so consumers that derive it
        # from meta["transcript"] (resume, aicx, the spawn smokes) still find it;
        # otherwise it is orphaned at the pre-finalize path.
        announced_last_message = announced_transcript.with_suffix(".last-message.md")
        final_last_message = transcript.with_suffix(".last-message.md")
        if announced_last_message.is_file() and not _same_file(
            announced_last_message, final_last_message
        ):
            final_last_message = _move_artifact(
                announced_last_message, final_last_message
            )
            _leave_compat_link(announced_last_message, final_last_message)
        payload["report"] = str(report)
        payload["transcript"] = str(transcript)
        payload["meta"] = str(final_meta)
        payload["artifact_stem"] = stem
        payload["artifact_kind"] = "report"

    payload["artifact_footer"] = {
        "run_id": payload.get("run_id", "unknown"),
        "session_id": payload.get("session_id") or "",
        **flat_tokens,
        **telemetry.cost.flat(),
        "resume_hint": resume_hint,
    }
    if payload.get("model_requested"):
        payload["artifact_footer"]["model_requested"] = payload.get("model_requested")
    payload.setdefault("completed_at", completed_at)
    payload["updated_at"] = dt.datetime.now(dt.UTC).isoformat()

    target_meta = Path(str(payload.get("meta") or meta))
    target_meta.write_text(
        json.dumps(payload, indent=2, ensure_ascii=False) + "\n", encoding="utf-8"
    )
    if not _same_file(meta, target_meta) and meta.exists():
        meta.unlink()
        _leave_compat_link(meta, target_meta)
    meta = target_meta

    footer_payload = {**payload, **flat_tokens, **telemetry.cost.flat()}
    if "tokens_cache_write" not in flat_tokens:
        footer_payload.pop("tokens_cache_write", None)

    if str(transcript):
        _normalize_markdown_artifact(transcript, footer_payload)
        write_runtime_transcript_manifest(
            transcript,
            run_id=str(payload.get("run_id") or ""),
        )
    report_frontmatter = telemetry.frontmatter_fields()
    # Attribute against the transcript as it now sits on disk (moved and
    # normalized), so the evidence line number is the one a reader will open.
    failure = (
        None
        if str(payload.get("status") or "") == "stopped"
        else attribute_failure(
            transcript if str(transcript) else None,
            coerce_exit_code(payload.get("exit_code")),
            agent=str(payload.get("agent") or ""),
        )
    )
    if failure is not None:
        payload["failure"] = failure.as_dict()
        report_frontmatter.update(failure.frontmatter())
        meta.write_text(
            json.dumps(payload, indent=2, ensure_ascii=False) + "\n", encoding="utf-8"
        )
    if (
        str(report)
        and report.exists()
        and report.suffix.lower() in {".md", ".markdown"}
    ):
        stamp_launcher_report_identity(
            report,
            run_id=str(payload.get("run_id") or ""),
            session_id=str(payload.get("session_id") or ""),
            agent=str(payload.get("agent") or ""),
            skill=str(payload.get("skill_code") or payload.get("skill") or ""),
            status=str(payload.get("status") or ""),
            model=str(payload.get("model") or ""),
            claim_digest=launcher_claim_digest,
        )
        _normalize_markdown_artifact(
            report, footer_payload, extra_frontmatter=report_frontmatter
        )
    return meta


def _ensure_failed_report_artifact(
    handle: SpawnHandle, exit_code: int, completed_at: str
) -> None:
    """Manufacture a minimal failed-run report if the worker never wrote one, then finalize."""
    if handle.meta_path is None or not handle.meta_path.is_file():
        return
    payload = _read_meta(handle.meta_path)
    report_value = str(payload.get("report") or "")
    if not report_value:
        return

    report = Path(report_value)
    transcript = handle.transcript_path
    if transcript is None and payload.get("transcript"):
        transcript = Path(str(payload["transcript"]))

    payload["status"] = "failed"
    payload["exit_code"] = exit_code
    payload["completed_at"] = completed_at
    if transcript is not None:
        payload["transcript"] = str(transcript)
    payload["report"] = str(report)
    _write_meta(handle.meta_path, payload)

    if not report.exists():
        report.parent.mkdir(parents=True, exist_ok=True)
        try:
            require_bound_markdown(
                report,
                run_id=str(payload.get("run_id") or handle.run_id or ""),
            )
        except BareMarkdownError:
            # Fall back to a bound name rather than writing Untitled*.md.
            report = report.with_name(
                f"{payload.get('run_id') or handle.run_id or 'run'}-failed-report.md"
            )
            payload["report"] = str(report)
            _write_meta(handle.meta_path, payload)
        transcript_ref = str(transcript or payload.get("transcript") or "")
        report.write_text(
            "\n".join(
                [
                    "---",
                    f"run_id: {payload.get('run_id') or handle.run_id}",
                    "status: failed",
                    f"exit_code: {exit_code}",
                    f"completed_at: {completed_at}",
                    f"transcript: {transcript_ref}",
                    "---",
                    "",
                    "# Agent run failed",
                    "",
                    "The supervised agent process exited before writing its final report.",
                    "",
                    f"Transcript: {transcript_ref or '-'}",
                    "",
                ]
            ),
            encoding="utf-8",
        )
    finalize_artifacts(handle.meta_path, report, transcript)


def _maybe_extract_session_id(handle: SpawnHandle) -> str:
    """Return the agent session id, reading meta first, else scraping the transcript."""
    meta = _read_meta(handle.meta_path)
    if meta.get("session_id"):
        return str(meta["session_id"])

    transcript = handle.transcript_path
    if transcript is None and meta.get("transcript"):
        transcript = Path(str(meta["transcript"]))
    if transcript is None or not transcript.is_file():
        return ""

    text = transcript.read_text(encoding="utf-8", errors="replace")
    session_id = extract_session_id(handle.agent, text) or ""
    if session_id and handle.meta_path is not None and handle.meta_path.is_file():
        meta["session_id"] = session_id
        _write_meta(handle.meta_path, meta)
    return session_id


class Supervisor:
    """Small UNIX process supervisor for Vibecrafted agent launchers."""

    def spawn(
        self,
        agent: str,
        prompt: str,
        *,
        skill: str,
        mode: str,
        root: str | os.PathLike[str],
        on_event: EventCallback | None = None,
        command: Sequence[str] | None = None,
        env: dict[str, str] | None = None,
        run_id: str | None = None,
        meta_path: str | os.PathLike[str] | None = None,
        transcript_path: str | os.PathLike[str] | None = None,
        sandbox: bool = False,
        sandbox_policy: str | os.PathLike[str] | None = None,
        sandbox_config: dict[str, Any] | None = None,
    ) -> SpawnHandle:
        """Launch *agent* (subprocess or sandbox), returning a live SpawnHandle.

        Starts a background watcher thread that fills in exit_code/session_id
        and emits spawn-* lifecycle events as the child completes.
        """
        root_path = Path(normalize_run_root(os.fspath(root)))
        command_list = (
            list(command) if command is not None else _default_command(agent, prompt)
        )
        effective_run_id = (
            run_id or os.environ.get("VIBECRAFTED_RUN_ID") or f"{skill}-manual"
        )

        launcher = Path(command_list[-1]).expanduser() if command_list else Path()
        inferred_meta = Path(meta_path).expanduser() if meta_path is not None else None
        inferred_transcript = (
            Path(transcript_path).expanduser() if transcript_path is not None else None
        )
        if inferred_meta is None and launcher.suffix == ".sh":
            parsed = _parse_launcher_assignment(launcher, "meta")
            inferred_meta = Path(parsed).expanduser() if parsed else None
        if inferred_transcript is None and launcher.suffix == ".sh":
            parsed = _parse_launcher_assignment(launcher, "transcript")
            inferred_transcript = Path(parsed).expanduser() if parsed else None

        child_env = os.environ.copy()
        if env:
            child_env.update(env)
        session_id = ensure_session_id(child_env.get("VIBECRAFTED_SESSION_ID"))
        child_env.setdefault("VIBECRAFTED_RUN_ID", effective_run_id)
        child_env["VIBECRAFTED_SESSION_ID"] = session_id
        # This supervisor launches workers, not interactive workspaces.
        # Interactive sessions use _fresh_child_environment and stay unfiltered.
        child_env = filter_headless_worker_env(child_env)

        if sandbox:
            if not sandbox_supported(agent):
                raise ValueError(f"agent does not support sandbox dispatch: {agent}")
            sandbox_process = _SandboxProcess()
            handle = SpawnHandle(
                run_id=effective_run_id,
                agent=agent,
                skill=skill,
                mode=mode,
                root=root_path,
                process=sandbox_process,
                pgid=None,
                started_at=utc_now_iso(),
                command=command_list,
                meta_path=inferred_meta,
                transcript_path=inferred_transcript,
                session_id=session_id,
            )
            self._emit(
                "spawn-started",
                handle,
                "supervisor spawned sandbox child",
                {"pid": sandbox_process.pid, "pgid": None, "command": command_list},
                on_event,
            )
            thread = threading.Thread(
                target=self._run_sandbox,
                args=(
                    handle,
                    child_env,
                    sandbox_policy,
                    sandbox_config or {},
                    on_event,
                ),
                daemon=True,
            )
            handle._thread = thread
            thread.start()
            return handle

        # start_new_session puts the child in its own process group (same intent
        # as setpgid) without the PLW1509 preexec_fn hazard in threaded hosts.
        process = subprocess.Popen(
            command_list,
            cwd=str(root_path),
            env=child_env,
            text=True,
            start_new_session=hasattr(os, "setpgid"),
        )
        try:
            pgid = os.getpgid(process.pid)
        except OSError:
            pgid = None

        handle = SpawnHandle(
            run_id=effective_run_id,
            agent=agent,
            skill=skill,
            mode=mode,
            root=root_path,
            process=process,
            pgid=pgid,
            started_at=utc_now_iso(),
            command=command_list,
            meta_path=inferred_meta,
            transcript_path=inferred_transcript,
            session_id=session_id,
        )
        self._emit(
            "spawn-started",
            handle,
            "supervisor spawned child",
            {"pid": process.pid, "pgid": pgid, "command": command_list},
            on_event,
        )
        thread = threading.Thread(
            target=self._wait_owner, args=(handle, on_event), daemon=True
        )
        handle._thread = thread
        thread.start()
        return handle

    def _run_sandbox(
        self,
        handle: SpawnHandle,
        env: dict[str, str],
        sandbox_policy: str | os.PathLike[str] | None,
        sandbox_config: dict[str, Any],
        on_event: EventCallback | None,
    ) -> None:
        """Background-thread target: run the sandbox adapter and emit its terminal event."""
        try:
            from .sandbox import SandboxAdapter, SandboxPolicy

            policy = SandboxPolicy.load(sandbox_policy, root=handle.root)
            adapter = SandboxAdapter(
                policy=policy,
                server_url=sandbox_config.get("server_url"),
                api_key_path=sandbox_config.get("api_key_path"),
            )
            result = adapter.execute_sync(
                handle.command,
                env=env,
                cwd=handle.root,
                timeout=sandbox_config.get("timeout"),
                run_id=handle.run_id,
                agent=handle.agent,
                skill=handle.skill,
                mode=handle.mode,
                on_event=on_event,
            )
            handle.exit_code = result.exit_code
        # Sandbox implementations are injected; any execution exception must emit spawn-failed and
        # exit_code=1 before callbacks can observe a false successful execution.
        except Exception as exc:  # noqa: BLE001
            handle.exit_code = 1
            self._emit(
                "spawn-failed",
                handle,
                f"sandbox execution failed: {exc}",
                {"pid": handle.pid, "pgid": handle.pgid, "exit_code": 1},
                on_event,
            )
            handle._done.set()
            return

        handle.completed_at = utc_now_iso()
        extracted_session_id = _maybe_extract_session_id(handle)
        if extracted_session_id:
            handle.session_id = extracted_session_id
        kind = "spawn-completed" if handle.exit_code == 0 else "spawn-failed"
        self._emit(
            kind,
            handle,
            f"sandbox child exited with {handle.exit_code}",
            {
                "pid": handle.pid,
                "pgid": handle.pgid,
                "exit_code": handle.exit_code,
                "session_id": handle.session_id,
                "meta": str(handle.meta_path or ""),
                "transcript": str(handle.transcript_path or ""),
                "substrate": "microsandbox",
            },
            on_event,
        )
        handle._done.set()

    def _wait_owner(self, handle: SpawnHandle, on_event: EventCallback | None) -> None:
        """Background-thread target: block on subprocess exit, finalize state and events."""
        exit_code = handle.process.wait()
        handle.exit_code = exit_code
        handle.completed_at = utc_now_iso()
        extracted_session_id = _maybe_extract_session_id(handle)
        if extracted_session_id:
            handle.session_id = extracted_session_id
        if exit_code != 0:
            _ensure_failed_report_artifact(handle, exit_code, handle.completed_at)
        kind = "spawn-completed" if exit_code == 0 else "spawn-failed"
        self._emit(
            kind,
            handle,
            f"supervisor child exited with {exit_code}",
            {
                "pid": handle.pid,
                "pgid": handle.pgid,
                "exit_code": exit_code,
                "session_id": handle.session_id,
                "meta": str(handle.meta_path or ""),
                "transcript": str(handle.transcript_path or ""),
            },
            on_event,
        )
        if handle.transcript_path and not handle.session_id:
            self._emit(
                "session_id_extraction_failed",
                handle,
                "could not extract agent session_id from transcript",
                {"agent": handle.agent, "transcript": str(handle.transcript_path)},
                on_event,
            )
        handle._done.set()

    def _emit(
        self,
        kind: str,
        handle: SpawnHandle,
        message: str,
        payload: dict[str, Any],
        on_event: EventCallback | None,
    ) -> None:
        """Append a durable lifecycle event and forward it to the caller's callback."""
        event = append_event(
            kind,
            handle.run_id,
            message,
            {
                "agent": handle.agent,
                "skill": handle.skill,
                "mode": handle.mode,
                "root": str(handle.root),
                "session_id": handle.session_id,
                "identity_required": True,
                **payload,
            },
        )
        if on_event is not None:
            on_event(event)


def _build_parser() -> argparse.ArgumentParser:
    """Build the argparse CLI: write-meta/finalize-artifacts/prepare-report/finish-meta."""
    parser = argparse.ArgumentParser(description="Vibecrafted launcher helpers.")
    sub = parser.add_subparsers(dest="command", required=True)
    write = sub.add_parser(
        "write-meta",
        help="Write initial launcher meta.json.",
    )
    write.add_argument("meta")
    write.add_argument("status")
    write.add_argument("agent")
    write.add_argument("mode")
    write.add_argument("root")
    write.add_argument("input")
    write.add_argument("report")
    write.add_argument("transcript")
    write.add_argument("launcher")
    write.add_argument("--model", default="")
    write.add_argument("--model-requested", default="")
    write.add_argument("--prompt-id", default="")
    write.add_argument("--run-id", default="")
    write.add_argument("--loop-nr", default="0")
    write.add_argument("--skill-code", default="")
    write.add_argument("--framework-version", default="")
    write.add_argument("--execution-controls", default="")

    finalize = sub.add_parser(
        "finalize-artifacts",
        help="Finalize launcher meta/report/transcript artifacts.",
    )
    finalize.add_argument("meta")
    finalize.add_argument("report", nargs="?")
    finalize.add_argument("transcript", nargs="?")
    prepare = sub.add_parser(
        "prepare-report",
        help="Materialize the launcher-owned report identity template.",
    )
    prepare.add_argument("report")
    prepare.add_argument("run_id")
    prepare.add_argument("agent")
    prepare.add_argument("skill")
    finish = sub.add_parser(
        "finish-meta",
        help="Mark launcher meta terminal and persist completion telemetry.",
    )
    finish.add_argument("meta")
    finish.add_argument("status")
    finish.add_argument("exit_code", nargs="?", default="0")
    policy = sub.add_parser(
        "policy-command", help="Resolve the canonical interactive provider policy."
    )
    policy.add_argument("provider", choices=POLICY_PROVIDERS)
    policy.add_argument("--runtime", choices=RUNTIME_POLICIES, default="local-native")
    policy.add_argument("--permissions", choices=PERMISSION_POLICIES, default="bypass")
    interactive_command = sub.add_parser(
        "interactive-command", help="Build the canonical interactive workspace wrapper."
    )
    interactive_command.add_argument("provider", choices=POLICY_PROVIDERS)
    interactive_command.add_argument(
        "--runtime", choices=RUNTIME_POLICIES, default="local-native"
    )
    interactive_command.add_argument(
        "--permissions", choices=PERMISSION_POLICIES, default=""
    )
    interactive_command.add_argument("--token-budget", default="safe")
    interactive_command.add_argument(
        "--operator", choices=OPERATOR_POLICIES, default="none"
    )
    interactive_command.add_argument(
        "--continuity", choices=CONTINUITY_MODES, default="fresh"
    )
    interactive_command.add_argument("--parent-session", default="")
    interactive_command.add_argument("--continuity-parent", default="")
    interactive_command.add_argument("--root", required=True)
    interactive_command.add_argument("--file", default="")
    interactive_command.add_argument("--model", default="")
    interactive_command.add_argument("--effort", default="")
    interactive_command.add_argument("--base", default="")
    interactive_command.add_argument("--execution-runtime", default="")
    interactive_command.add_argument("--worktree", default="")
    interactive_command.add_argument("--skill", default="init")
    interactive_command.add_argument("--session", default="")
    interactive_command.add_argument(
        "--session-selection", type=json.loads, default=None
    )
    interactive_command.add_argument("--parent-run-id", default="")
    interactive_command.add_argument("--resume-run-id", default="")
    interactive_command.add_argument("--resume-last", action="store_true")
    interactive_launch = sub.add_parser(
        "interactive-launch", help="Prepare and exec an interactive Agent Workspace."
    )
    interactive_launch.add_argument("provider", choices=POLICY_PROVIDERS)
    interactive_launch.add_argument(
        "--runtime", choices=RUNTIME_POLICIES, default="local-native"
    )
    interactive_launch.add_argument(
        "--permissions", choices=PERMISSION_POLICIES, default=""
    )
    interactive_launch.add_argument("--root", required=True)
    interactive_launch.add_argument("--prompt", default="")
    interactive_launch.add_argument("--admission-file", default="")
    interactive_launch.add_argument("--token-budget", default="safe")
    interactive_launch.add_argument(
        "--operator", choices=OPERATOR_POLICIES, default="none"
    )
    interactive_launch.add_argument(
        "--continuity", choices=CONTINUITY_MODES, default="fresh"
    )
    interactive_launch.add_argument("--parent-session", default="")
    interactive_launch.add_argument("--continuity-parent", default="")
    handoff = sub.add_parser(
        "interactive-handoff", help="Enter an admitted interactive execution"
    )
    handoff.add_argument("--command", dest="launch_command", required=True)
    handoff.add_argument("--root-only", action="store_true")
    handoff.add_argument("--run-id-only", action="store_true")
    sub.add_parser(
        "policy-matrix", help="Print the complete provider policy matrix as JSON."
    )
    return parser


def main(argv: Sequence[str] | None = None) -> int:
    """CLI entry point dispatching to the launcher helper subcommands."""
    args = _build_parser().parse_args(argv)
    if args.command == "interactive-handoff":
        command = shlex.split(args.launch_command)
        if (
            "vibecrafted_core.spawn" not in command
            or "interactive-launch" not in command
            or "--admission-file" not in command
        ):
            raise ValueError("expected a canonical admitted interactive command")
        launch_args = command[command.index("interactive-launch") :]
        selected = _build_parser().parse_args(launch_args)
        if args.root_only:
            print(selected.root)
            return 0
        if args.run_id_only:
            admission = json.loads(
                Path(selected.admission_file).read_text(encoding="utf-8")
            )
            run_id = str(admission.get("run_id") or "")
            if not run_id:
                raise ValueError("admitted interactive command has no run id")
            print(run_id)
            return 0
        # Re-enter the canonical owner in this interpreter. The command's
        # executable/environment prefix is descriptive, never executable input.
        return main(launch_args)
    if args.command == "write-meta":
        write_meta(
            args.meta,
            args.status,
            args.agent,
            args.mode,
            args.root,
            args.input,
            args.report,
            args.transcript,
            args.launcher,
            model=args.model,
            model_requested=args.model_requested,
            prompt_id=args.prompt_id,
            run_id=args.run_id,
            loop_nr=args.loop_nr,
            skill_code=args.skill_code,
            framework_version=args.framework_version,
            execution_controls=args.execution_controls,
        )
        return 0
    if args.command == "finish-meta":
        finish_meta(args.meta, args.status, args.exit_code)
        return 0
    if args.command == "finalize-artifacts":
        final_meta = finalize_artifacts(args.meta, args.report, args.transcript)
        if final_meta is None:
            return 1
        print(final_meta.resolve(strict=True))
        return 0
    if args.command == "prepare-report":
        materialize_launcher_report_template(
            args.report,
            run_id=args.run_id,
            agent=args.agent,
            skill=args.skill,
            claim_digest=os.environ.get(CLAIM_DIGEST_ENV, ""),
        )
        return 0
    if args.command == "policy-command":
        try:
            command = interactive_policy_command(
                args.provider, sys.stdin.read(), args.runtime, args.permissions
            )
        except ValueError as exc:
            print(f"UNSUPPORTED: {exc}", file=sys.stderr)
            return 2
        print(shlex.join(command))
        return 0
    if args.command == "interactive-command":
        from .workflow import read_prompt_stream
        from .workspace_catalog import WorkspaceCatalogError

        prompt = read_prompt_stream(sys.stdin)
        try:
            command = interactive_workspace_command(
                args.provider,
                prompt,
                args.runtime,
                args.permissions,
                args.root,
                args.token_budget,
                args.operator,
                args.continuity,
                args.parent_session,
                args.continuity_parent,
                model=args.model,
                effort=args.effort,
                source_file=args.file,
                base=args.base,
                execution_runtime=args.execution_runtime,
                worktree=args.worktree,
                skill=args.skill,
                native_session=args.session,
                parent_run_id=args.parent_run_id,
                resume_run_id=args.resume_run_id,
                resume_last=args.resume_last,
                session_selection=args.session_selection,
            )
        except (ValueError, WorkspaceCatalogError) as exc:
            print(str(exc), file=sys.stderr)
            return 2
        print(shlex.join(command))
        return 0
    if args.command == "interactive-launch":
        admission = {}
        claimed = False
        native_lease = None
        try:
            if args.admission_file:
                path = Path(args.admission_file)
                if path.is_symlink() or path.stat().st_mode & 0o077:
                    raise ValueError("unsafe interactive admission file")
                admission = json.loads(path.read_bytes())
                expected = (
                    control_plane_home() / "runtime_runs" / str(admission["run_id"])
                )
                if path.resolve() != (expected / "admission.json").resolve():
                    raise ValueError(
                        "interactive admission does not belong to this run"
                    )
                source_path = Path(admission["source_snapshot"])
                if (
                    source_path.is_symlink()
                    or source_path.resolve() != (expected / "plan-source.md").resolve()
                    or source_path.stat().st_mode & 0o077
                ):
                    raise ValueError("unsafe interactive source snapshot")
                source = source_path.read_bytes()
                if hashlib.sha256(source).hexdigest() != admission["source_digest"]:
                    raise ValueError("interactive source digest mismatch")
                if (
                    args.provider != admission["agent"]
                    or args.root != admission["root"]
                ):
                    raise ValueError("interactive admission target mismatch")
                args.prompt = compose_interactive_task_prompt(
                    skill=str(admission["skill"]),
                    source=source.decode("utf-8"),
                    root=admission["root"],
                    admission=admission,
                    parent_session_id=str(
                        getattr(args, "parent_session", "")
                        or admission.get("parent_session_id")
                        or ""
                    ),
                )
                # Exclusive execution claim: reopening a view cannot run the provider twice.
                claim_fd = os.open(
                    expected / "execution.claim",
                    os.O_CREAT | os.O_EXCL | os.O_WRONLY,
                    0o600,
                )
                os.close(claim_fd)
                claimed = True
                native_id = str(admission.get("agent_session_id") or "")
                if native_id:
                    import fcntl

                    leases = control_plane_home() / "native_session_leases"
                    leases.mkdir(mode=0o700, parents=True, exist_ok=True)
                    key = hashlib.sha256(
                        f"{args.provider}:{native_id}".encode()
                    ).hexdigest()
                    native_lease = os.open(leases / key, os.O_CREAT | os.O_RDWR, 0o600)
                    try:
                        fcntl.flock(native_lease, fcntl.LOCK_EX | fcntl.LOCK_NB)
                    except BlockingIOError as exc:
                        raise ValueError(
                            "native session already has an active executor"
                        ) from exc
            return launch_interactive_workspace(
                args.provider,
                args.prompt,
                args.runtime,
                args.permissions,
                args.root,
                args.token_budget,
                args.operator,
                args.continuity,
                args.parent_session,
                args.continuity_parent,
                admission=admission,
            )
        except (OSError, RuntimeError, ValueError) as exc:
            if claimed:
                message, _failed = record_interactive_launch_cli_failure(
                    admission=admission,
                    exc=exc,
                    provider=str(args.provider),
                )
                print(message, file=sys.stderr)
            else:
                print(str(exc), file=sys.stderr)
            return 2
        finally:
            if native_lease is not None:
                os.close(native_lease)
    if args.command == "policy-matrix":
        print(
            json.dumps(
                [
                    resolve_provider_policy(p, r, q, m).as_dict()
                    for p in POLICY_PROVIDERS
                    for r in RUNTIME_POLICIES
                    for q in PERMISSION_POLICIES
                    for m in POLICY_MODES
                ],
                indent=2,
            )
        )
        return 0
    return 2


if __name__ == "__main__":  # CLI entry point.
    raise SystemExit(main())
