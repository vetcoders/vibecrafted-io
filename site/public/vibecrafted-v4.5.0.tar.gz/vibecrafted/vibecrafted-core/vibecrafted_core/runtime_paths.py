"""Filesystem layout for vibecrafted's runtime homes, staged tools, and launchers.

Every path here is env-overridable (``VIBECRAFTED_HOME`` / ``XDG_*`` / etc.) so
callers never hardcode a user's layout; ``resolve_env_path`` is the shared knob.
"""

from __future__ import annotations

import hashlib
import json
import os
import sys
from collections.abc import Mapping
from pathlib import Path

# Direct children of ``vibecrafted_home()`` have one product-wide ownership
# class.  Keep this grammar here: the host-Python installer loads this module by
# file, while the runtime imports it normally.  Unknown names are intentionally
# absent and therefore preserved by uninstall discovery.
VIBECRAFTED_HOME_RUNTIME_STATE = frozenset(
    {
        "control_plane",
        "server",
        "foundation",
        "locks",
        "runtime",
        "install-transactions",
        "recovery",
        "tmp",
        "logs",
        ".vc-install.json",
        "START_HERE.md",
        "install.log",
        ".DS_Store",
    }
)

VIBECRAFTED_HOME_FOUNDER_DATA = frozenset(
    {
        "artifacts",
        "inbox",
        "reports",
        "plans",
        "prompts",
        "specs",
        "backups",
        "worktrees",
        "monitor",
        "charter",
        "trust",
        "loctree",
        "vibecrafted",
        "store",
        ".git",
        ".loctree",
    }
)

ACTIVE_RUNTIME_SCHEMA = "vibecrafted.active-runtime.v1"


class GenerationResolutionError(RuntimeError):
    """Raised when active.json and vibecrafted-current disagree or neither exists."""


def classify_vibecrafted_home_child(child: str | Path) -> str:
    """Classify one direct state-home child for product uninstall.

    ``runtime-state`` is reproducible process/control state and is removed.
    ``founder-data`` is durable human/generated work and is preserved.
    Every unrecognized name is ``unknown`` and is preserved visibly.
    """

    name = Path(child).name
    if name in VIBECRAFTED_HOME_RUNTIME_STATE:
        return "runtime-state"
    if name in VIBECRAFTED_HOME_FOUNDER_DATA:
        return "founder-data"
    return "unknown"


def is_windows() -> bool:
    """True on native Windows."""
    return sys.platform == "win32"


def windows_profile_home() -> Path:
    """Operator profile root: ``USERPROFILE``, then ``HOME``, then ``Path.home()``."""
    for name in ("USERPROFILE", "HOME"):
        raw = str(os.environ.get(name, "")).strip()
        if raw:
            return Path(raw).expanduser()
    return Path.home()


def windows_local_app_data() -> Path:
    """``LOCALAPPDATA`` or ``<profile>\\AppData\\Local`` — never a hardcoded user."""
    raw = str(os.environ.get("LOCALAPPDATA", "")).strip()
    if raw:
        return Path(raw).expanduser()
    return windows_profile_home() / "AppData" / "Local"


def windows_roaming_app_data() -> Path:
    """``APPDATA`` or ``<profile>\\AppData\\Roaming``."""
    raw = str(os.environ.get("APPDATA", "")).strip()
    if raw:
        return Path(raw).expanduser()
    return windows_profile_home() / "AppData" / "Roaming"


def canonical_vibecrafted_runtime_home() -> Path:
    """OS default runtime home, ignoring ``VIBECRAFTED_RUNTIME_HOME`` / ``XDG_*``."""
    if is_windows():
        return windows_local_app_data() / "Vibecrafted"
    return Path.home() / ".local" / "share" / "vibecrafted"


def canonical_vibecrafted_home() -> Path:
    """OS default control-plane root, ignoring ``VIBECRAFTED_HOME``."""
    if is_windows():
        return canonical_vibecrafted_runtime_home() / "home"
    return Path.home() / ".vibecrafted"


def canonical_vibecrafted_launcher_bin() -> Path:
    """OS default launcher bin, ignoring ``VIBECRAFTED_LAUNCHER_BIN``."""
    if is_windows():
        return canonical_vibecrafted_runtime_home() / "bin"
    return Path.home() / ".local" / "bin"


def canonical_vibecrafted_product_config_home() -> Path:
    """OS default product config directory."""
    if is_windows():
        return windows_roaming_app_data() / "Vibecrafted"
    return Path.home() / ".config" / "vibecrafted"


def vibecrafted_product_config_home() -> Path:
    """Native product config home.

    Windows always uses ``%APPDATA%\\Vibecrafted`` — Runtime Pack launchers may
    export ``XDG_CONFIG_HOME`` as the roaming parent for child tools, but that
    must not redirect the product tree to ``%APPDATA%\\vibecrafted``.
    POSIX keeps ``$XDG_CONFIG_HOME/vibecrafted`` (else ``~/.config/vibecrafted``).
    """
    if is_windows():
        return canonical_vibecrafted_product_config_home()
    if os.environ.get("XDG_CONFIG_HOME"):
        return xdg_config_home() / "vibecrafted"
    return xdg_config_home() / "vibecrafted"


def read_version_file(root: str | Path) -> str:
    """Read ``<root>/VERSION`` verbatim, or ``"unknown"`` when it is absent."""
    version_file = Path(root) / "VERSION"
    if version_file.exists():
        return version_file.read_text(encoding="utf-8").strip()
    return "unknown"


def version_is_stamped(version: str) -> bool:
    """Install contract: ``X.Y.Z+gSHORTSHA`` (see docs/INSTALL.md).

    Bare ``X.Y.Z`` is not an install identity — it is either an unstamped
    living-tree checkout or a broken editable install that must not win PATH.
    """
    if not version or version == "unknown":
        return False
    # Accept +gabc1234 style only (not arbitrary local labels).
    plus = version.find("+g")
    if plus < 0:
        return False
    sha = version[plus + 2 :]
    return bool(sha) and all(c in "0123456789abcdefABCDEF" for c in sha)


def read_staged_tools_version() -> str:
    """VERSION stamped into the active generation (active.json, then current)."""
    try:
        generation = resolve_active_generation()
    except GenerationResolutionError:
        generation = vibecrafted_tools_home() / "vibecrafted-current"
    for candidate in (
        generation / "VERSION",
        generation / "vibecrafted-core" / "vibecrafted_core" / "VERSION",
        generation / "vibecrafted-core" / "VERSION",
    ):
        if candidate.is_file():
            text = candidate.read_text(encoding="utf-8").strip()
            if text:
                return text
    return "unknown"


def resolve_env_path(name: str, default: Path) -> Path:
    """Return ``$name`` expanded to a ``Path`` if set, else the expanded default."""
    raw = os.environ.get(name)
    if raw:
        return Path(raw).expanduser()
    return default.expanduser()


def xdg_config_home() -> Path:
    """``$XDG_CONFIG_HOME``, else native config home (``APPDATA`` on Windows)."""
    raw = os.environ.get("XDG_CONFIG_HOME")
    if raw:
        return Path(raw).expanduser()
    if is_windows():
        return windows_roaming_app_data()
    return (Path.home() / ".config").expanduser()


def xdg_data_home() -> Path:
    """``$XDG_DATA_HOME``, else native data home (``LOCALAPPDATA`` on Windows)."""
    raw = os.environ.get("XDG_DATA_HOME")
    if raw:
        return Path(raw).expanduser()
    if is_windows():
        return windows_local_app_data()
    return (Path.home() / ".local" / "share").expanduser()


def vibecrafted_home() -> Path:
    """``$VIBECRAFTED_HOME`` or the platform control-plane root."""
    if os.environ.get("VIBECRAFTED_HOME"):
        return Path(os.environ["VIBECRAFTED_HOME"]).expanduser()
    return canonical_vibecrafted_home()


def run_signal_socket_path(run_id: str) -> Path:
    """Short, home-scoped Unix socket path for one dispatcher run.

    Darwin limits ``sun_path`` to 104 bytes.  Hashing both the configured
    Vibecrafted home and run id keeps isolated test/operator homes distinct
    without leaking long workspace paths into the socket address.
    """
    identity = f"{vibecrafted_home().resolve()}\0{run_id}".encode()
    digest = hashlib.sha256(identity).hexdigest()[:24]
    uid = getattr(os, "getuid", lambda: 0)()
    return Path("/tmp") / f"vc-cp-{uid}" / f"{digest}.sock"


def vibecrafted_backups_home() -> Path:
    """Where the installer stashes pre-install backups, under the home root."""
    return vibecrafted_home() / "backups" / "installer"


def vibecrafted_runtime_home() -> Path:
    """``$VIBECRAFTED_RUNTIME_HOME`` or the platform runtime home."""
    if os.environ.get("VIBECRAFTED_RUNTIME_HOME"):
        return Path(os.environ["VIBECRAFTED_RUNTIME_HOME"]).expanduser()
    if os.environ.get("XDG_DATA_HOME"):
        return xdg_data_home() / "vibecrafted"
    if is_windows():
        return canonical_vibecrafted_runtime_home()
    return xdg_data_home() / "vibecrafted"


def vibecrafted_tools_home() -> Path:
    """``$VIBECRAFTED_TOOLS_HOME`` or ``<runtime_home>/tools`` — staged installs."""
    return resolve_env_path(
        "VIBECRAFTED_TOOLS_HOME",
        vibecrafted_runtime_home() / "tools",
    )


def vibecrafted_runtime_bin() -> Path:
    """``$VIBECRAFTED_RUNTIME_BIN`` or ``<runtime_home>/bin``."""
    return resolve_env_path(
        "VIBECRAFTED_RUNTIME_BIN", vibecrafted_runtime_home() / "bin"
    )


def selected_runtime_environment(
    environment: Mapping[str, str] | None = None,
) -> dict[str, str]:
    """Return an environment coherent with an explicitly selected runtime.

    A public runtime launcher selects an immutable generation by exporting
    ``VIBECRAFTED_RUNTIME_ROOT``.  That selection owns its executable bin and
    interpreter; inherited ``VIBECRAFTED_RUNTIME_BIN`` / ``VIBECRAFTED_PYTHON``
    values are merely legacy process state and must not split a child across
    generations.  A runtime-bin override without a selected root remains
    supported for source and test lanes.

    Do not replace a selected root with the mutable runtime-home pointer.  A
    malformed selected root is an identity failure, not permission to fall
    back to whichever generation happens to be active.
    """

    env = dict(os.environ if environment is None else environment)
    raw_root = str(env.get("VIBECRAFTED_RUNTIME_ROOT", "")).strip()
    if not raw_root:
        return env

    root = Path(raw_root).expanduser()
    if not root.is_absolute():
        raise ValueError(
            "selected runtime root must be an absolute immutable generation path: "
            f"{raw_root}"
        )
    try:
        root = root.resolve(strict=True)
    except OSError as exc:
        raise ValueError(f"selected runtime root is unavailable: {raw_root}") from exc

    version = read_version_file(root)
    runtime_bin = root / "bin"
    if is_windows():
        runtime_python = runtime_bin / "python.exe"
        if not runtime_python.is_file():
            runtime_python = runtime_bin / "python3.exe"
        python_ok = runtime_python.is_file()
    else:
        runtime_python = runtime_bin / "python3"
        python_ok = runtime_python.is_file() and os.access(runtime_python, os.X_OK)
    if not root.is_dir() or not version_is_stamped(version):
        raise ValueError(
            f"selected runtime root is not an immutable stamped generation: {root}"
        )
    if not runtime_bin.is_dir() or not python_ok:
        raise ValueError(
            "selected runtime generation is incomplete; expected executable "
            f"{runtime_python}"
        )

    selected = str(root)
    env["VIBECRAFTED_RUNTIME_ROOT"] = selected
    env["VIBECRAFTED_RUNTIME_BIN"] = str(runtime_bin)
    env["VIBECRAFTED_PYTHON"] = str(runtime_python)
    env["VIBECRAFTED_ROOT"] = selected
    env["VIBECRAFTED_CORE_DIR"] = str(root / "vibecrafted-core")
    return env


def resolve_operator_launch_root(
    *,
    cwd: Path | None = None,
    env: Mapping[str, str] | None = None,
) -> Path:
    """Root for `vibecrafted review` and siblings when the operator is at $HOME.

    App shells often start in the home directory. A selected WES workspace is
    the product root; reviewing `$HOME` is never a useful default.
    """

    environ = os.environ if env is None else env
    here = (cwd or Path.cwd()).expanduser().resolve()
    raw_home = str(environ.get("HOME") or "").strip()
    home = Path(raw_home).expanduser().resolve() if raw_home else Path.home().resolve()
    workspace = str(environ.get("VIBECRAFTED_WORKSPACE_ROOT") or "").strip()
    in_git = (here / ".git").exists() or any(
        (parent / ".git").exists() for parent in here.parents
    )
    if workspace and (here == home or not in_git):
        selected = Path(workspace).expanduser().resolve()
        if selected.is_dir():
            return selected
    return here


def is_operator_home_root(
    root: str | Path,
    *,
    env: Mapping[str, str] | None = None,
) -> bool:
    """True when ``root`` is the operator home directory (never a useful launch)."""

    environ = os.environ if env is None else env
    raw_home = str(environ.get("HOME") or "").strip()
    home = Path(raw_home).expanduser().resolve() if raw_home else Path.home().resolve()
    try:
        return Path(root).expanduser().resolve() == home
    except OSError:
        return False


def vibecrafted_launcher_bin() -> Path:
    """``$VIBECRAFTED_LAUNCHER_BIN`` or the platform launcher directory."""
    if os.environ.get("VIBECRAFTED_LAUNCHER_BIN"):
        return Path(os.environ["VIBECRAFTED_LAUNCHER_BIN"]).expanduser()
    return canonical_vibecrafted_launcher_bin()


def _owned_runtime_homes(environment: Mapping[str, str]) -> list[str]:
    """Owned runtime roots whose generation bins are private carriers.

    Anchoring on real owned roots — rather than a floating
    ``*/vibecrafted/releases/*/bin`` glob — is what lets a custom
    ``VIBECRAFTED_RUNTIME_HOME`` sanitize correctly while an unrelated
    lookalike user directory is preserved.
    """

    raw_home = str(environment.get("HOME", "")).strip()
    home = Path(raw_home).expanduser() if raw_home else Path.home()
    raw_xdg_data = str(environment.get("XDG_DATA_HOME", "")).strip()
    raw_runtime_home = str(environment.get("VIBECRAFTED_RUNTIME_HOME", "")).strip()

    homes: list[str] = []
    if raw_runtime_home:
        homes.append(str(Path(raw_runtime_home).expanduser()))
    if raw_xdg_data:
        homes.append(str(Path(raw_xdg_data).expanduser() / "vibecrafted"))
    elif is_windows():
        raw_local = str(environment.get("LOCALAPPDATA", "")).strip()
        if raw_local:
            homes.append(str(Path(raw_local).expanduser() / "Vibecrafted"))
        else:
            profile = str(
                environment.get("USERPROFILE") or environment.get("HOME") or ""
            ).strip()
            root = Path(profile).expanduser() if profile else Path.home()
            homes.append(str(root / "AppData" / "Local" / "Vibecrafted"))
    else:
        homes.append(str(home / ".local/share" / "vibecrafted"))
    return homes


def _is_owned_generation_bin(entry: str, environment: Mapping[str, str]) -> bool:
    """True for the selected root's bin or ``<owned home>/releases/<gen>/bin``."""

    candidate = Path(entry)
    if candidate.name != "bin":
        return False
    generation = candidate.parent

    selected = str(environment.get("VIBECRAFTED_RUNTIME_ROOT", "")).strip()
    if selected and generation == Path(selected).expanduser():
        return True

    for runtime_home in _owned_runtime_homes(environment):
        releases = Path(runtime_home) / "releases"
        if generation.parent == releases and generation.name:
            return True
    return False


def is_owned_generation_path(entry: str, environment: Mapping[str, str]) -> bool:
    """True when *entry* lies inside the selected root or an owned
    ``<runtime home>/releases/<generation>`` tree.

    Same anchoring as :func:`_is_owned_generation_bin`, for whole subtrees: the
    generation's private import roots (``vibecrafted-core``, ``vibecrafted-mcp``,
    ``python-site``) are what its ``bin/python3`` bootstrap exports, and a
    provider spawned by the runtime must not inherit them (HAK-32).
    """

    if not str(entry).strip():
        return False
    candidate = Path(entry)

    selected = str(environment.get("VIBECRAFTED_RUNTIME_ROOT", "")).strip()
    if selected:
        selected_root = Path(selected).expanduser()
        if candidate == selected_root or selected_root in candidate.parents:
            return True

    for runtime_home in _owned_runtime_homes(environment):
        releases = Path(runtime_home) / "releases"
        try:
            relative = candidate.relative_to(releases)
        except ValueError:
            continue
        if relative.parts:
            return True
    return False


def _host_agent_bin_dirs(environment: Mapping[str, str]) -> list[Path]:
    """Host CLI + public launcher directories, appended for minimal PATHs.

    Keep this list in lockstep with
    ``runtime/shell/lib/core.sh:_vetcoders_host_agent_bin_dirs`` and
    ``runtime/scripts/lib/util.sh:spawn_host_agent_bin_dirs``.
    """

    raw_home = str(environment.get("HOME", "")).strip()
    home = Path(raw_home).expanduser() if raw_home else Path.home()
    if is_windows():
        system_root = Path(
            environment.get("SystemRoot")
            or os.environ.get("SystemRoot")
            or r"C:\Windows"
        )
        launcher = (
            Path(environment["VIBECRAFTED_LAUNCHER_BIN"]).expanduser()
            if str(environment.get("VIBECRAFTED_LAUNCHER_BIN", "")).strip()
            else Path(environment.get("LOCALAPPDATA", "")).expanduser()
            / "Vibecrafted"
            / "bin"
            if str(environment.get("LOCALAPPDATA", "")).strip()
            else home / "AppData" / "Local" / "Vibecrafted" / "bin"
        )
        return [
            launcher,
            home / ".cargo" / "bin",
            system_root / "System32",
            system_root,
        ]
    return [
        home / ".local/bin",
        home / ".cargo/bin",
        home / ".kimi-code/bin",
        home / "tools/scripts",
        Path("/opt/homebrew/bin"),
        Path("/opt/homebrew/sbin"),
        Path("/usr/local/bin"),
        Path("/usr/bin"),
        Path("/bin"),
        Path("/usr/sbin"),
        Path("/sbin"),
    ]


def agent_tool_search_path(environment: Mapping[str, str] | None = None) -> str:
    """PATH for a detached provider process: Founder order, no private carrier.

    Launchd and other supervisors intentionally provide a minimal environment,
    so provider discovery must not depend on interactive shell startup — the
    host directories above are therefore APPENDED as a discovery suffix.  The
    inherited PATH is not discarded: a public child resolves the Founder's own
    ``aicx`` / ``loct`` / ``prview`` / ``screenscribe`` and any unrelated custom
    entry from user paths, in the user's own order.

    Removed is exactly one class: a Vibecrafted-owned generation bin.  Internal
    dependencies reach the private carrier through explicit owner paths
    (``VIBECRAFTED_RUNTIME_BIN`` / ``VIBECRAFTED_PYTHON``), so a missing host
    tool stays missing instead of silently resolving a bundled — possibly
    stale — private copy.

    Keep this in lockstep with
    ``runtime/scripts/lib/util.sh:spawn_prepend_agent_tool_paths`` and
    ``runtime/shell/lib/core.sh:_vetcoders_path_with_bundled_bin_priority``.
    """

    env = selected_runtime_environment(environment)
    inherited = str(env.get("PATH", os.defpath))

    resolved: list[str] = []
    seen: set[str] = set()
    for entry in inherited.split(os.pathsep):
        if not entry or entry in seen:
            continue
        if _is_owned_generation_bin(entry, env):
            continue
        seen.add(entry)
        resolved.append(entry)

    for candidate in _host_agent_bin_dirs(env):
        text = str(candidate)
        if text in seen or not candidate.is_dir():
            continue
        if _is_owned_generation_bin(text, env):
            continue
        seen.add(text)
        resolved.append(text)

    door = _selected_python_door(env)
    if door is not None:
        resolved = [door, *(entry for entry in resolved if entry != door)]
    return os.pathsep.join(resolved)


# The runtime python pin. A process entering the runtime pins one interpreter,
# VIBECRAFTED_PYTHON (the absolute bin/python3 of the selected generation), and
# puts the generation's python door first on PATH. The door forwards python and
# python3 to the pin and refuses without one; the guest ZDOTDIR keeps the door
# first in nested zsh. Bash twins: runtime/scripts/lib/util.sh
# (spawn_prepend_agent_tool_paths, spawn_pin_runtime_python).
RUNTIME_PIN_DIRECTORY = "config/runtime-pin"


def runtime_python_door(runtime_root: Path) -> Path:
    """The generation's private directory holding only ``python`` and ``python3``."""
    return runtime_root / RUNTIME_PIN_DIRECTORY / "bin"


def runtime_guest_zdotdir(runtime_root: Path) -> Path:
    """The generation's guest ZDOTDIR: the user's zsh startup, then the door."""
    return runtime_root / RUNTIME_PIN_DIRECTORY / "zsh"


def _selected_python_door(environment: Mapping[str, str]) -> str | None:
    if is_windows():
        return None
    raw_root = str(environment.get("VIBECRAFTED_RUNTIME_ROOT", "")).strip()
    if not raw_root or not Path(raw_root).is_absolute():
        return None
    door = runtime_python_door(Path(raw_root))
    if not (door / "python3").is_file():
        return None
    return str(door)


def pin_runtime_python(environment: Mapping[str, str]) -> dict[str, str]:
    """Carry the runtime python pin into a child environment.

    An inherited ``VIBECRAFTED_PYTHON`` stays: an update never moves a live
    session to another interpreter. A child without one gets the selected
    generation's ``bin/python3``, the same generation as its runtime root. The
    door goes first on PATH, so ``python``, ``python3`` and
    ``#!/usr/bin/env python3`` reach the pin. ``ZDOTDIR`` names the guest
    directory, which runs the user's own zsh startup (``VIBECRAFTED_USER_ZDOTDIR``,
    default HOME) and then puts the door back in front of what path_helper
    and personal dotfiles prepended.

    Without a selected generation that carries the door (source and test
    lanes, Windows, older generations) the environment is returned unchanged:
    outside the runtime ``python3`` stays the user's own.
    """

    env = dict(environment)
    door = _selected_python_door(env)
    if door is None:
        return env
    root = Path(str(env["VIBECRAFTED_RUNTIME_ROOT"]).strip())
    if not str(env.get("VIBECRAFTED_PYTHON", "")).strip():
        env["VIBECRAFTED_PYTHON"] = str(root / "bin" / "python3")
    entries = [
        entry
        for entry in str(env.get("PATH", "")).split(os.pathsep)
        if entry and entry != door
    ]
    env["PATH"] = os.pathsep.join([door, *entries])

    guest = runtime_guest_zdotdir(root)
    if guest.is_dir():
        current = str(env.get("ZDOTDIR", "")).strip()
        home = str(env.get("HOME") or Path.home())
        crafted = str(env.get("VIBECRAFTED_HOME") or f"{home}/.vibecrafted")
        # A product shell ZDOTDIR (vc-terminal, Quick cmd) restores the door
        # itself; keep it, as the bash twin does.
        product = {
            f"{home}/.config/vibecrafted/vc-terminal",
            f"{crafted}/shell/quick-cmd",
        }
        if current != str(guest) and current not in product:
            if current and not current.endswith(f"/{RUNTIME_PIN_DIRECTORY}/zsh"):
                env["VIBECRAFTED_USER_ZDOTDIR"] = current
            elif not str(env.get("VIBECRAFTED_USER_ZDOTDIR", "")).strip():
                env["VIBECRAFTED_USER_ZDOTDIR"] = home
            env["ZDOTDIR"] = str(guest)
    return env


def active_runtime_pointer(runtime_home: Path | None = None) -> Path:
    """Path to the one active-generation JSON pointer."""
    return (runtime_home or vibecrafted_runtime_home()) / "active.json"


def current_generation_projection(runtime_home: Path | None = None) -> Path:
    """Filesystem projection of the active generation (symlink or junction)."""
    tools = (
        vibecrafted_tools_home()
        if runtime_home is None
        else resolve_env_path("VIBECRAFTED_TOOLS_HOME", runtime_home / "tools")
    )
    return tools / "vibecrafted-current"


def _read_active_runtime_root(pointer: Path, runtime_home: Path) -> Path | None:
    if pointer.is_symlink():
        raise GenerationResolutionError("active.json must not be a symlink")
    if not pointer.is_file():
        return None
    try:
        payload = json.loads(pointer.read_text(encoding="utf-8"))
    except (OSError, UnicodeError, json.JSONDecodeError) as exc:
        raise GenerationResolutionError(
            f"active runtime pointer is unreadable: {pointer}"
        ) from exc
    if (
        not isinstance(payload, dict)
        or payload.get("schema") != ACTIVE_RUNTIME_SCHEMA
        or not isinstance(payload.get("runtime_root"), str)
        or not payload["runtime_root"]
    ):
        raise GenerationResolutionError(f"active runtime pointer is invalid: {pointer}")
    generation = Path(payload["runtime_root"]).expanduser()
    if not generation.is_absolute():
        raise GenerationResolutionError("active runtime_root must be absolute")
    try:
        resolved = generation.resolve(strict=True)
        home = runtime_home.resolve(strict=False)
    except (OSError, RuntimeError) as exc:
        # pathlib re-raises ELOOP as RuntimeError, not OSError.
        raise GenerationResolutionError(
            f"active runtime_root cannot be resolved: {exc}"
        ) from exc
    if resolved != home and home not in resolved.parents:
        raise GenerationResolutionError(
            f"active runtime_root escapes runtime home: {resolved}"
        )
    return resolved


def _is_generation_pointer(path: Path) -> bool:
    """True for a unix symlink or a Windows directory junction."""
    if path.is_symlink():
        return True
    junction = getattr(path, "is_junction", None)
    if junction is None:
        return False
    try:
        return bool(junction())
    except OSError:
        return False


def resolve_active_generation(runtime_home: Path | None = None) -> Path:
    """Return the one installed generation. ``active.json`` is authority.

    ``tools/vibecrafted-current`` is a projection. When both exist they must
    name the same directory; disagreement is split-brain and fail-closed.
    """
    home = (runtime_home or vibecrafted_runtime_home()).expanduser()
    pointer = active_runtime_pointer(home)
    current = current_generation_projection(home)
    active_root = _read_active_runtime_root(pointer, home) if pointer.exists() else None
    current_root: Path | None = None
    pointer_present = (
        current.exists() or current.is_symlink() or _is_generation_pointer(current)
    )
    if pointer_present:
        if not _is_generation_pointer(current):
            raise GenerationResolutionError(
                f"{current} is not an atomic generation pointer"
            )
        try:
            current_root = current.resolve(strict=True)
        except (OSError, RuntimeError) as exc:
            # pathlib re-raises ELOOP (symlink loop) as RuntimeError, not
            # OSError; a corrupt pointer must fail closed, never crash.
            raise GenerationResolutionError(
                f"cannot resolve current runtime generation: {exc}"
            ) from exc
    if active_root is not None and current_root is not None:
        if active_root != current_root:
            raise GenerationResolutionError(
                f"split-brain: active.json names {active_root} but "
                f"vibecrafted-current names {current_root}"
            )
        return active_root
    if active_root is not None:
        return active_root
    if current_root is not None:
        if is_windows():
            raise GenerationResolutionError(
                "vibecrafted-current exists without active.json"
            )
        return current_root
    raise GenerationResolutionError("no active Runtime Pack generation")


def launcher_name(name: str) -> str:
    """Public launcher filename on this platform (``.cmd`` on Windows)."""
    if is_windows() and not name.lower().endswith((".cmd", ".bat", ".exe")):
        return f"{name}.cmd"
    return name
