"""Closed identity contract for the immutable Vibecrafted Runtime Pack."""

from __future__ import annotations

import argparse
import hashlib
import json
import re
import stat
from collections.abc import Mapping
from pathlib import Path
from typing import Any

SCHEMA = "io.vetcoders.vibecrafted.runtime-pack-provenance.v1"
PROVENANCE_NAME = "runtime-pack-provenance.json"
SOURCE_PROVENANCE_NAME = "source-provenance.json"
INVENTORY_NAME = "runtime-inventory.json"
FOUNDATIONS_NAME = "runtime-foundations.json"
SOURCE_PROVENANCE_SCHEMA = "vibecrafted.source-provenance.v2"
FOUNDATIONS_SCHEMA = "io.vetcoders.vibecrafted.runtime-foundations.v1"
GIT_SHA = re.compile(r"[0-9a-f]{40}")
SHA256 = re.compile(r"[0-9a-f]{64}")
LINUX_EXECUTABLES = frozenset(
    {
        "vibecrafted",
        "vc-server",
        "vc-frame",
        "vc-terminal",
        "voc",
        "vc-o",
        "vc-admin",
        "vc-procs",
    }
)
WINDOWS_X64_MANDATORY_EXECUTABLES = frozenset(
    {
        "python",
        "vc-server",
        "vc-frame",
        "vc-terminal",
    }
)
WINDOWS_X64_OPTIONAL_EXECUTABLES = frozenset(
    {
        "voc",
        "vc-start",
        "vc-server-supervisor",
    }
)
WINDOWS_X64_CLASSIFICATIONS = {
    "voc": "limited-platform-scope",
    "vc-start": "limited-platform-scope",
    "vc-server-supervisor": "limited-platform-scope",
}
WINDOWS_X64_TARGET = "x86_64-pc-windows-msvc"
WINDOWS_PACK_PLATFORM = "win32-x64"
WINDOWS_INSTALLER_PAYLOAD = frozenset(
    {
        "scripts/vetcoders_install.py",
        "scripts/install-runtime-pack.ps1",
        "bin/python.exe",
        "bin/vibecrafted.cmd",
    }
)
RUNTIME_INSTALLER_EXECUTABLES = frozenset(
    {
        "bin/vc-start",
        "scripts/vibecrafted",
    }
)
REQUIRED_FOUNDATION_EXECUTABLES = frozenset(
    {
        "vc-server",
        "vc-start",
        "vibecrafted-server-web",
    }
)
# Tools with their own public channel: npm (@loctree/loctree, @loctree/aicx),
# PyPI (screenscribe) and GitHub releases (vetcoders/prview-rs). Agents reach
# the host copies by design (runtime_paths.agent_tool_search_path strips the
# generation bin), so a carried copy is dead weight that lags its channel.
# The pack refuses to carry them on every platform.
CHANNEL_FOUNDATION_EXECUTABLES = frozenset(
    {
        "aicx",
        "aicx-mcp",
        "loct",
        "loctree",
        "loctree-lsp",
        "loctree-mcp",
        "prview",
        "screenscribe",
    }
)
FORBIDDEN_PAYLOAD_NAMES = frozenset({".DS_Store"})
VC_FRAME_CONFIG_ROOT = Path("vibecrafted-core/vibecrafted_core/config/vc-frame")


class RuntimePackContractError(RuntimeError):
    """Raised when Runtime Pack identity or payload evidence is not closed."""


def _sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def _canonical_json(payload: Mapping[str, Any]) -> str:
    return json.dumps(payload, ensure_ascii=True, sort_keys=True, indent=2) + "\n"


def _is_windows_pack_platform(platform: str) -> bool:
    return platform == WINDOWS_PACK_PLATFORM or platform in {"win32", "windows"}


def _runtime_installer_payload(root: Path, *, platform: str = "") -> None:
    if _is_windows_pack_platform(platform):
        for relative in WINDOWS_INSTALLER_PAYLOAD:
            path = root / relative
            if not path.is_file() or path.is_symlink():
                raise RuntimePackContractError(
                    f"Runtime Pack installer payload is missing {relative}"
                )
        return
    for relative in RUNTIME_INSTALLER_EXECUTABLES:
        path = root / relative
        try:
            mode = path.lstat().st_mode
        except OSError as exc:
            raise RuntimePackContractError(
                f"Runtime Pack installer payload is missing {relative}"
            ) from exc
        if not stat.S_ISREG(mode) or stat.S_IMODE(mode) & 0o111 == 0:
            raise RuntimePackContractError(
                f"Runtime Pack installer payload is not executable: {relative}"
            )


def _native_executable(path: Path) -> bool:
    try:
        mode = path.lstat().st_mode
        magic = path.read_bytes()[:4]
    except OSError:
        return False
    return (
        stat.S_ISREG(mode)
        and stat.S_IMODE(mode) & 0o111 != 0
        and (
            magic == b"\x7fELF"
            or magic
            in {
                b"\xca\xfe\xba\xbe",
                b"\xbe\xba\xfe\xca",
                b"\xfe\xed\xfa\xce",
                b"\xce\xfa\xed\xfe",
                b"\xfe\xed\xfa\xcf",
                b"\xcf\xfa\xed\xfe",
            }
        )
    )


def _runtime_product_payload(root: Path) -> None:
    """Close the carrier: a product wrapper without its frame is not a pack."""
    native_frame = root / "libexec/vc-frame"
    if not _native_executable(native_frame):
        raise RuntimePackContractError(
            "Runtime Pack native vc-frame is missing or is not Mach-O/ELF: "
            "libexec/vc-frame"
        )
    wrapper = root / "bin/vc-frame"
    try:
        wrapper_mode = wrapper.lstat().st_mode
    except OSError as exc:
        raise RuntimePackContractError(
            "Runtime Pack product wrapper is missing bin/vc-frame"
        ) from exc
    if not stat.S_ISREG(wrapper_mode) or stat.S_IMODE(wrapper_mode) & 0o111 == 0:
        raise RuntimePackContractError(
            "Runtime Pack product wrapper is not executable: bin/vc-frame"
        )
    native_terminal = root / "libexec/vc-terminal"
    if not _native_executable(native_terminal):
        raise RuntimePackContractError(
            "Runtime Pack native vc-terminal is missing or is not Mach-O/ELF: "
            "libexec/vc-terminal"
        )
    terminal_wrapper = root / "bin/vc-terminal"
    try:
        terminal_wrapper_mode = terminal_wrapper.lstat().st_mode
    except OSError as exc:
        raise RuntimePackContractError(
            "Runtime Pack product wrapper is missing bin/vc-terminal"
        ) from exc
    if (
        not stat.S_ISREG(terminal_wrapper_mode)
        or stat.S_IMODE(terminal_wrapper_mode) & 0o111 == 0
    ):
        raise RuntimePackContractError(
            "Runtime Pack product wrapper is not executable: bin/vc-terminal"
        )
    if _native_executable(terminal_wrapper):
        raise RuntimePackContractError(
            "Runtime Pack bin/vc-terminal must be the product wrapper, not the Alacritty host"
        )
    try:
        terminal_wrapper_text = terminal_wrapper.read_text(encoding="utf-8")
    except OSError as exc:
        raise RuntimePackContractError(
            "Runtime Pack bin/vc-terminal is unreadable"
        ) from exc
    if "--config-file" not in terminal_wrapper_text:
        raise RuntimePackContractError(
            "Runtime Pack bin/vc-terminal does not pin --config-file"
        )
    if "vc-terminal.toml" not in terminal_wrapper_text:
        raise RuntimePackContractError(
            "Runtime Pack bin/vc-terminal does not pin vc-terminal.toml"
        )
    if "libexec/vc-terminal" not in terminal_wrapper_text:
        raise RuntimePackContractError(
            "Runtime Pack bin/vc-terminal does not exec libexec/vc-terminal"
        )
    config = root / VC_FRAME_CONFIG_ROOT
    required = (config / "config.kdl", config / "layouts", config / "themes")
    if not required[0].is_file() or not all(path.is_dir() for path in required[1:]):
        raise RuntimePackContractError(
            "Runtime Pack canonical vc-frame config is incomplete under "
            f"{VC_FRAME_CONFIG_ROOT.as_posix()}"
        )


def _no_channel_foundations(root: Path) -> None:
    """Refuse a payload that carries a tool its own channel publishes."""
    carried = sorted(
        relative
        for name in CHANNEL_FOUNDATION_EXECUTABLES
        for relative in (
            f"bin/{name}",
            f"bin/{name}.exe",
            f"bin/{name}.cmd",
            f"libexec/{name}",
            f"python-site/{name}",
        )
        if (root / relative).exists() or (root / relative).is_symlink()
    )
    if carried:
        raise RuntimePackContractError(
            "Runtime Pack carries tools that ship through their own channel "
            "(npm / PyPI / GitHub releases): " + ", ".join(carried)
        )


def write_runtime_foundations(root: str | Path) -> dict[str, Any]:
    """Write the closed executable manifest for everything already in bin/."""
    payload_root = Path(root).resolve(strict=True)
    _no_channel_foundations(payload_root)
    files = {
        path.name: _sha256(path)
        for path in sorted((payload_root / "bin").iterdir())
        if path.is_file()
        and not path.is_symlink()
        and stat.S_IMODE(path.stat().st_mode) & 0o111
    }
    payload = {
        "schema": FOUNDATIONS_SCHEMA,
        "versions": {},
        "source_revisions": {},
        "source_archives": {},
        "licenses": {},
        "files": files,
    }
    (payload_root / FOUNDATIONS_NAME).write_text(
        _canonical_json(payload), encoding="utf-8"
    )
    return _runtime_foundations(payload_root)


def _runtime_foundations(root: Path, *, verify_hashes: bool = True) -> dict[str, Any]:
    """Load the closed foundation manifest and bind it to final shipped bytes."""
    path = root / FOUNDATIONS_NAME
    try:
        raw = path.read_text(encoding="utf-8")
        payload = json.loads(raw)
    except (OSError, UnicodeError, json.JSONDecodeError) as exc:
        raise RuntimePackContractError(
            "Runtime Pack foundation manifest is invalid"
        ) from exc
    files = payload.get("files") if isinstance(payload, dict) else None
    required_fields = {
        "schema",
        "versions",
        "source_revisions",
        "source_archives",
        "licenses",
        "files",
    }
    if (
        not isinstance(payload, dict)
        or set(payload) != required_fields
        or payload.get("schema") != FOUNDATIONS_SCHEMA
        or raw != _canonical_json(payload)
        or not all(
            isinstance(payload.get(field), dict)
            for field in required_fields - {"schema", "files"}
        )
        or not isinstance(files, dict)
        or not REQUIRED_FOUNDATION_EXECUTABLES.issubset(files)
        or any(
            not isinstance(name, str)
            or not name
            or Path(name).name != name
            or not isinstance(digest, str)
            or SHA256.fullmatch(digest) is None
            for name, digest in files.items()
        )
    ):
        raise RuntimePackContractError(
            "Runtime Pack foundation manifest violates the closed schema"
        )
    for name, digest in files.items():
        executable = root / "bin" / name
        try:
            mode = executable.lstat().st_mode
        except OSError as exc:
            raise RuntimePackContractError(
                f"Runtime Pack foundation is missing bin/{name}"
            ) from exc
        if not stat.S_ISREG(mode) or stat.S_IMODE(mode) & 0o111 == 0:
            raise RuntimePackContractError(
                f"Runtime Pack foundation is not executable: bin/{name}"
            )
        if verify_hashes and _sha256(executable) != digest:
            raise RuntimePackContractError(
                f"Runtime Pack foundation digest does not match final bytes: bin/{name}"
            )
    return payload


def refresh_runtime_foundations(root: str | Path) -> dict[str, Any]:
    """Rebind the staged manifest after the final signing/mutation boundary."""
    payload_root = Path(root).resolve(strict=True)
    payload = _runtime_foundations(payload_root, verify_hashes=False)
    files = payload["files"]
    payload["files"] = {
        name: _sha256(payload_root / "bin" / name) for name in sorted(files)
    }
    (payload_root / FOUNDATIONS_NAME).write_text(
        _canonical_json(payload), encoding="utf-8"
    )
    return _runtime_foundations(payload_root)


def _validate_revision(value: str, *, field: str) -> str:
    if GIT_SHA.fullmatch(value) is None:
        raise RuntimePackContractError(f"{field} must be a full Git revision")
    return value


def _payload_files(root: Path, *, allow_empty: bool = False) -> list[dict[str, Any]]:
    records: list[dict[str, Any]] = []
    for path in sorted(root.rglob("*")):
        relative = path.relative_to(root).as_posix()
        if path.name in FORBIDDEN_PAYLOAD_NAMES:
            # Host metadata services stamp .DS_Store into live trees faster
            # than any pre-walk sweep can win the race. The carrier tar
            # excludes these names, so they can never ship and never carry
            # signed bytes: skip them instead of failing an otherwise valid
            # payload, and never record them in provenance.
            continue
        if path.is_symlink():
            raise RuntimePackContractError(
                f"Runtime Pack payload contains a symlink: {relative}"
            )
        if path.is_dir():
            continue
        mode = path.lstat().st_mode
        if not stat.S_ISREG(mode):
            raise RuntimePackContractError(
                f"Runtime Pack payload contains a non-regular file: {relative}"
            )
        if relative == PROVENANCE_NAME:
            continue
        records.append(
            {
                "path": relative,
                "sha256": _sha256(path),
                "size": path.stat().st_size,
                "mode": f"{stat.S_IMODE(mode):04o}",
            }
        )
    if not records and not allow_empty:
        raise RuntimePackContractError("Runtime Pack payload is empty")
    return records


def _source_provenance(root: Path, *, expected_revision: str) -> dict[str, Any]:
    path = root / SOURCE_PROVENANCE_NAME
    try:
        raw = path.read_text(encoding="utf-8")
        payload = json.loads(raw)
    except (OSError, UnicodeError, json.JSONDecodeError) as exc:
        raise RuntimePackContractError(
            "Runtime Pack source provenance is invalid"
        ) from exc
    if (
        not isinstance(payload, dict)
        or set(payload) != {"schema", "owner_repo", "source_revision", "payload"}
        or payload.get("schema") != SOURCE_PROVENANCE_SCHEMA
        or payload.get("owner_repo") != "vetcoders/vibecrafted"
        or payload.get("source_revision") != expected_revision
        or raw != _canonical_json(payload)
    ):
        raise RuntimePackContractError(
            "Runtime Pack source provenance disagrees with the expected source revision"
        )
    return payload


def _linux_inventory(root: Path, *, platform: str, architecture: str) -> dict[str, Any]:
    target = {
        "arm64": "aarch64-unknown-linux-gnu",
        "x64": "x86_64-unknown-linux-gnu",
    }.get(architecture)
    if platform != f"linux-{architecture}" or target is None:
        raise RuntimePackContractError("unsupported Linux Runtime Pack target")
    path = root / INVENTORY_NAME
    try:
        raw = path.read_text(encoding="utf-8")
        inventory = json.loads(raw)
    except (OSError, UnicodeError, json.JSONDecodeError) as exc:
        raise RuntimePackContractError(
            "Linux Runtime Pack inventory is invalid"
        ) from exc
    executables = inventory.get("executables") if isinstance(inventory, dict) else None
    required_record = {
        "name",
        "path",
        "sha256",
        "version_argv",
        "version_output",
        "source_url",
        "source_revision",
        "source_archive_sha256",
        "target",
        "license",
    }
    if (
        not isinstance(inventory, dict)
        or set(inventory) != {"schema", "platform", "architecture", "executables"}
        or inventory.get("schema") != "io.vetcoders.vibecrafted.runtime-inventory.v1"
        or inventory.get("platform") != platform
        or inventory.get("architecture") != architecture
        or raw != _canonical_json(inventory)
        or not isinstance(executables, list)
        or {record.get("name") for record in executables if isinstance(record, dict)}
        != LINUX_EXECUTABLES
    ):
        raise RuntimePackContractError(
            "Linux Runtime Pack inventory violates the closed schema"
        )
    for record in executables:
        if (
            not isinstance(record, dict)
            or set(record) != required_record
            or not all(
                isinstance(record[field], str) and record[field]
                for field in required_record - {"version_argv"}
            )
            or not isinstance(record["version_argv"], list)
            or not all(
                isinstance(item, str) and item for item in record["version_argv"]
            )
            or SHA256.fullmatch(record["sha256"]) is None
            or SHA256.fullmatch(record["source_archive_sha256"]) is None
            or record["target"] != target
            or record["path"] != f"bin/{record['name']}"
            or _sha256(root / record["path"]) != record["sha256"]
        ):
            raise RuntimePackContractError(
                "Linux Runtime Pack executable inventory is invalid"
            )
    return inventory


def _windows_executable_path(name: str) -> str:
    if name == "python":
        return "bin/python.exe"
    if name in {"screenscribe", "vc-terminal", "vc-frame"}:
        return f"bin/{name}.cmd"
    return f"bin/{name}.exe"


def _windows_x64_inventory(root: Path) -> dict[str, Any]:
    path = root / INVENTORY_NAME
    try:
        raw = path.read_text(encoding="utf-8")
        inventory = json.loads(raw)
    except (OSError, UnicodeError, json.JSONDecodeError) as exc:
        raise RuntimePackContractError(
            "Windows x64 Runtime Pack inventory is invalid"
        ) from exc
    executables = inventory.get("executables") if isinstance(inventory, dict) else None
    unsupported = inventory.get("unsupported") if isinstance(inventory, dict) else None
    required_record = {
        "name",
        "path",
        "sha256",
        "version_argv",
        "version_output",
        "source_url",
        "source_revision",
        "source_archive_sha256",
        "target",
        "license",
    }
    unsupported_record = {"name", "classification", "reason"}
    allowed_classifications = {"limited-platform-scope", "release-blocker"}
    if (
        not isinstance(inventory, dict)
        or set(inventory)
        != {"schema", "platform", "architecture", "executables", "unsupported"}
        or inventory.get("schema") != "io.vetcoders.vibecrafted.runtime-inventory.v1"
        or inventory.get("platform") != WINDOWS_PACK_PLATFORM
        or inventory.get("architecture") != "x64"
        or raw != _canonical_json(inventory)
        or not isinstance(executables, list)
        or not isinstance(unsupported, list)
        or any(
            not isinstance(record, dict)
            or record.get("classification") not in allowed_classifications
            for record in unsupported
        )
    ):
        raise RuntimePackContractError(
            "Windows x64 Runtime Pack inventory violates the closed schema"
        )
    present = {record.get("name") for record in executables if isinstance(record, dict)}
    missing_declared = {
        record.get("name") for record in unsupported if isinstance(record, dict)
    }
    if not WINDOWS_X64_MANDATORY_EXECUTABLES <= present:
        raise RuntimePackContractError(
            "Windows x64 Runtime Pack inventory is missing mandatory executables"
        )
    if present & missing_declared:
        raise RuntimePackContractError(
            "Windows x64 Runtime Pack inventory lists a binary as both present and unsupported"
        )
    if present - (WINDOWS_X64_MANDATORY_EXECUTABLES | WINDOWS_X64_OPTIONAL_EXECUTABLES):
        raise RuntimePackContractError(
            "Windows x64 Runtime Pack inventory contains an undeclared executable"
        )
    expected_unsupported = WINDOWS_X64_OPTIONAL_EXECUTABLES - present
    if missing_declared != expected_unsupported:
        raise RuntimePackContractError(
            "Windows x64 Runtime Pack unsupported set does not match missing optional tools"
        )
    for record in executables:
        if (
            not isinstance(record, dict)
            or set(record) != required_record
            or not all(
                isinstance(record[field], str) and record[field]
                for field in required_record - {"version_argv"}
            )
            or not isinstance(record["version_argv"], list)
            or not all(
                isinstance(item, str) and item for item in record["version_argv"]
            )
            or SHA256.fullmatch(record["sha256"]) is None
            or SHA256.fullmatch(record["source_archive_sha256"]) is None
            or record["target"] != WINDOWS_X64_TARGET
            or record["path"] != _windows_executable_path(record["name"])
            or _sha256(root / record["path"]) != record["sha256"]
        ):
            raise RuntimePackContractError(
                "Windows x64 Runtime Pack executable inventory is invalid"
            )
    for record in unsupported:
        name = record.get("name") if isinstance(record, dict) else None
        expected_class = WINDOWS_X64_CLASSIFICATIONS.get(str(name), "")
        if (
            not isinstance(record, dict)
            or set(record) != unsupported_record
            or not isinstance(name, str)
            or name not in WINDOWS_X64_OPTIONAL_EXECUTABLES
            or record.get("classification") != expected_class
            or not isinstance(record.get("reason"), str)
            or not record["reason"]
        ):
            raise RuntimePackContractError(
                "Windows x64 Runtime Pack unsupported inventory is invalid"
            )
    return inventory


def write_provenance(
    root: str | Path,
    *,
    carrier_basename: str,
    version: str,
    platform: str,
    architecture: str,
    source_revision: str,
    terminal_revision: str,
    frame_revision: str,
) -> dict[str, Any]:
    payload_root = Path(root).resolve(strict=True)
    revisions = {
        "vibecrafted": _validate_revision(source_revision, field="source_revision"),
        "vc-terminal": _validate_revision(terminal_revision, field="terminal_revision"),
        "vc-frame": _validate_revision(frame_revision, field="frame_revision"),
    }
    if Path(carrier_basename).name != carrier_basename or not carrier_basename.endswith(
        ".tar.gz"
    ):
        raise RuntimePackContractError("carrier basename must be a .tar.gz basename")
    if not version or version != version.strip():
        raise RuntimePackContractError("Runtime Pack version is invalid")
    _runtime_installer_payload(payload_root, platform=platform)
    _source_provenance(payload_root, expected_revision=source_revision)
    if platform != f"{platform.rsplit('-', 1)[0]}-{architecture}":
        raise RuntimePackContractError(
            "Runtime Pack platform must be the canonical <os>-<architecture> target slug"
        )
    _no_channel_foundations(payload_root)
    if _is_windows_pack_platform(platform):
        if platform == WINDOWS_PACK_PLATFORM and architecture == "x64":
            _windows_x64_inventory(payload_root)
        else:
            raise RuntimePackContractError(
                "Windows Runtime Pack must be the win32-x64 target slug"
            )
    else:
        _runtime_product_payload(payload_root)
        _runtime_foundations(payload_root)
        if platform.startswith("linux-"):
            _linux_inventory(payload_root, platform=platform, architecture=architecture)
    provenance = {
        "schema": SCHEMA,
        "carrier_basename": carrier_basename,
        "version": version,
        "platform": platform,
        "architecture": architecture,
        "source_revisions": revisions,
        "payload": {
            "algorithm": "sha256",
            "files": _payload_files(payload_root),
        },
    }
    (payload_root / PROVENANCE_NAME).write_text(
        _canonical_json(provenance), encoding="utf-8"
    )
    return provenance


def verify_provenance(
    root: str | Path,
    *,
    carrier_basename: str,
    expected_source_revision: str | None = None,
    expected_terminal_revision: str | None = None,
    expected_frame_revision: str | None = None,
    expected_version: str | None = None,
    expected_platform: str | None = None,
    expected_architecture: str | None = None,
) -> dict[str, Any]:
    payload_root = Path(root).resolve(strict=True)
    path = payload_root / PROVENANCE_NAME
    try:
        raw = path.read_text(encoding="utf-8")
        provenance = json.loads(raw)
    except (OSError, UnicodeError, json.JSONDecodeError) as exc:
        raise RuntimePackContractError("Runtime Pack provenance is invalid") from exc
    required = {
        "schema",
        "carrier_basename",
        "version",
        "platform",
        "architecture",
        "source_revisions",
        "payload",
    }
    revisions = (
        provenance.get("source_revisions") if isinstance(provenance, dict) else None
    )
    payload = provenance.get("payload") if isinstance(provenance, dict) else None
    files = payload.get("files") if isinstance(payload, dict) else None
    if (
        not isinstance(provenance, dict)
        or set(provenance) != required
        or provenance.get("schema") != SCHEMA
        or raw != _canonical_json(provenance)
        or provenance.get("carrier_basename") != carrier_basename
        or not isinstance(provenance.get("version"), str)
        or not provenance["version"]
        or not isinstance(provenance.get("platform"), str)
        or not provenance["platform"]
        or not isinstance(provenance.get("architecture"), str)
        or not provenance["architecture"]
        or not isinstance(revisions, dict)
        or set(revisions) != {"vibecrafted", "vc-terminal", "vc-frame"}
        or any(
            not isinstance(value, str) or GIT_SHA.fullmatch(value) is None
            for value in revisions.values()
        )
        or not isinstance(payload, dict)
        or set(payload) != {"algorithm", "files"}
        or payload.get("algorithm") != "sha256"
        or not isinstance(files, list)
        or not files
    ):
        raise RuntimePackContractError(
            "Runtime Pack provenance violates the closed schema"
        )
    expected_revisions = {
        "vibecrafted": expected_source_revision,
        "vc-terminal": expected_terminal_revision,
        "vc-frame": expected_frame_revision,
    }
    for name, expected in expected_revisions.items():
        if expected is not None and revisions[name] != _validate_revision(
            expected, field=f"expected_{name}_revision"
        ):
            raise RuntimePackContractError(
                f"Runtime Pack {name} revision disagrees with the expected release tuple"
            )
    expected_identity = {
        "version": expected_version,
        "platform": expected_platform,
        "architecture": expected_architecture,
    }
    for field, expected in expected_identity.items():
        if expected is not None and provenance[field] != expected:
            raise RuntimePackContractError(
                f"Runtime Pack {field} disagrees with the selected release asset"
            )
    _runtime_installer_payload(payload_root, platform=str(provenance["platform"]))
    _source_provenance(payload_root, expected_revision=revisions["vibecrafted"])
    if provenance["platform"] != (
        f"{provenance['platform'].rsplit('-', 1)[0]}-{provenance['architecture']}"
    ):
        raise RuntimePackContractError(
            "Runtime Pack platform must be the canonical <os>-<architecture> target slug"
        )
    _no_channel_foundations(payload_root)
    if _is_windows_pack_platform(str(provenance["platform"])):
        if (
            provenance["platform"] == WINDOWS_PACK_PLATFORM
            and provenance["architecture"] == "x64"
        ):
            _windows_x64_inventory(payload_root)
        else:
            raise RuntimePackContractError(
                "Windows Runtime Pack must be the win32-x64 target slug"
            )
    else:
        _runtime_product_payload(payload_root)
        _runtime_foundations(payload_root)
        if provenance["platform"].startswith("linux-"):
            _linux_inventory(
                payload_root,
                platform=provenance["platform"],
                architecture=provenance["architecture"],
            )
    observed = _payload_files(payload_root)
    if files != observed:
        raise RuntimePackContractError(
            "Runtime Pack payload digests do not match provenance"
        )
    version = (payload_root / "VERSION").read_text(encoding="utf-8").strip()
    if version != provenance["version"]:
        raise RuntimePackContractError("Runtime Pack VERSION disagrees with provenance")
    return provenance


def _macho_uuid(path: Path) -> str | None:
    """LC_UUID of a thin 64-bit little-endian Mach-O, or None.

    The UUID identifies the compilation product and is never rewritten by
    codesign, so two differently-signed copies of the same build share it.
    """
    import struct

    try:
        with path.open("rb") as fh:
            header = fh.read(32)
            if len(header) < 32:
                return None
            if struct.unpack("<I", header[:4])[0] != 0xFEEDFACF:
                return None
            ncmds = struct.unpack("<I", header[16:20])[0]
            for _ in range(ncmds):
                cmd_header = fh.read(8)
                if len(cmd_header) < 8:
                    return None
                cmd, cmdsize = struct.unpack("<II", cmd_header)
                if cmdsize < 8:
                    return None
                body = fh.read(cmdsize - 8)
                if cmd == 0x1B:  # LC_UUID
                    return body[:16].hex()
    except OSError:
        return None
    return None


def helpers_agree(app_copy: Path, pack_copy: Path) -> bool:
    """True when the App helper and the pack binary are the same product.

    Byte equality stopped being possible once the pack's binaries gained
    their own Developer ID signatures (the App helper is bundle-signed, the
    pack copy bare-signed — different CodeDirectories, same code), so equal
    bytes pass fastest and otherwise both files must be Mach-O sharing one
    LC_UUID. A non-Mach-O impostor has no UUID and fails closed.
    """
    try:
        if app_copy.read_bytes() == pack_copy.read_bytes():
            return True
    except OSError:
        return False
    app_uuid = _macho_uuid(app_copy)
    return app_uuid is not None and app_uuid == _macho_uuid(pack_copy)


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser()
    commands = parser.add_subparsers(dest="command", required=True)
    write = commands.add_parser("write")
    verify = commands.add_parser("verify")
    write_foundations = commands.add_parser("write-foundations")
    write_foundations.add_argument("--root", type=Path, required=True)
    refresh_foundations = commands.add_parser("refresh-foundations")
    refresh_foundations.add_argument("--root", type=Path, required=True)
    agree = commands.add_parser("helpers-agree")
    agree.add_argument("--app-copy", type=Path, required=True)
    agree.add_argument("--pack-copy", type=Path, required=True)
    for command in (write, verify):
        command.add_argument("--root", type=Path, required=True)
        command.add_argument("--carrier-basename", required=True)
    write.add_argument("--version", required=True)
    write.add_argument("--platform", required=True)
    write.add_argument("--architecture", required=True)
    write.add_argument("--source-revision", required=True)
    write.add_argument("--terminal-revision", required=True)
    write.add_argument("--frame-revision", required=True)
    verify.add_argument("--expected-source-revision")
    verify.add_argument("--expected-terminal-revision")
    verify.add_argument("--expected-frame-revision")
    verify.add_argument("--expected-version")
    verify.add_argument("--expected-platform")
    verify.add_argument("--expected-architecture")
    args = parser.parse_args(argv)
    if args.command == "helpers-agree":
        return 0 if helpers_agree(args.app_copy, args.pack_copy) else 1
    if args.command == "write-foundations":
        payload = write_runtime_foundations(args.root)
    elif args.command == "refresh-foundations":
        payload = refresh_runtime_foundations(args.root)
    elif args.command == "write":
        payload = write_provenance(
            args.root,
            carrier_basename=args.carrier_basename,
            version=args.version,
            platform=args.platform,
            architecture=args.architecture,
            source_revision=args.source_revision,
            terminal_revision=args.terminal_revision,
            frame_revision=args.frame_revision,
        )
    else:
        payload = verify_provenance(
            args.root,
            carrier_basename=args.carrier_basename,
            expected_source_revision=args.expected_source_revision,
            expected_terminal_revision=args.expected_terminal_revision,
            expected_frame_revision=args.expected_frame_revision,
            expected_version=args.expected_version,
            expected_platform=args.expected_platform,
            expected_architecture=args.expected_architecture,
        )
    print(json.dumps(payload, sort_keys=True, separators=(",", ":")))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
