# Structural Map

Project: `/Users/polyversai/Libraxis/vc-runtime/vibecrafted`
Snapshot: `release/v2.0.0@659756e`

This card contains dependency and symbol topology for the selected scope.

```json
{
  "consumers": [],
  "entrypoints": [],
  "files": [
    {
      "authority": "repo_verified",
      "depth": 0,
      "language": "make",
      "loc": 495,
      "path": "Makefile",
      "role": "target"
    },
    {
      "authority": "repo_verified",
      "depth": 0,
      "language": "shell",
      "loc": 2816,
      "path": "skills/vc-agents/shell/vetcoders.sh",
      "role": "target"
    },
    {
      "authority": "repo_verified",
      "depth": 0,
      "language": "py",
      "loc": 189,
      "path": "tests/tui/test_await_observe_contract.py",
      "role": "target"
    },
    {
      "authority": "repo_verified",
      "depth": 0,
      "language": "py",
      "loc": 655,
      "path": "tests/tui/test_operator_mode.py",
      "role": "target"
    },
    {
      "authority": "repo_verified",
      "depth": 0,
      "language": "py",
      "loc": 1764,
      "path": "tests/tui/test_vibecrafted_launcher.py",
      "role": "target"
    }
  ],
  "imports": [
    {
      "authority": "repo_verified",
      "file": "skills/vc-agents/shell/vetcoders.sh",
      "is_bare": true,
      "kind": "static",
      "line": 49,
      "resolution": "unknown",
      "resolved_path": null,
      "source": "$helper",
      "source_raw": "$helper",
      "symbols": []
    },
    {
      "authority": "repo_verified",
      "file": "tests/tui/test_await_observe_contract.py",
      "is_bare": true,
      "kind": "static",
      "line": 1,
      "resolution": "unknown",
      "resolved_path": null,
      "source": "__future__",
      "source_raw": "from __future__ import annotations",
      "symbols": [
        "annotations"
      ]
    },
    {
      "authority": "repo_verified",
      "file": "tests/tui/test_await_observe_contract.py",
      "is_bare": true,
      "kind": "static",
      "line": 7,
      "resolution": "stdlib",
      "resolved_path": null,
      "source": "pathlib",
      "source_raw": "from pathlib import Path",
      "symbols": [
        "Path"
      ]
    },
    {
      "authority": "repo_verified",
      "file": "tests/tui/test_await_observe_contract.py",
      "is_bare": true,
      "kind": "static",
      "line": 3,
      "resolution": "stdlib",
      "resolved_path": null,
      "source": "json",
      "source_raw": "json",
      "symbols": []
    },
    {
      "authority": "repo_verified",
      "file": "tests/tui/test_await_observe_contract.py",
      "is_bare": true,
      "kind": "static",
      "line": 4,
      "resolution": "stdlib",
      "resolved_path": null,
      "source": "os",
      "source_raw": "os",
      "symbols": []
    },
    {
      "authority": "repo_verified",
      "file": "tests/tui/test_await_observe_contract.py",
      "is_bare": true,
      "kind": "static",
      "line": 5,
      "resolution": "stdlib",
      "resolved_path": null,
      "source": "subprocess",
      "source_raw": "subprocess",
      "symbols": []
    },
    {
      "authority": "repo_verified",
      "file": "tests/tui/test_await_observe_contract.py",
      "is_bare": true,
      "kind": "static",
      "line": 6,
      "resolution": "stdlib",
      "resolved_path": null,
      "source": "time",
      "source_raw": "time",
      "symbols": []
    },
    {
      "authority": "repo_verified",
      "file": "tests/tui/test_operator_mode.py",
      "is_bare": true,
      "kind": "static",
      "line": 1,
      "resolution": "unknown",
      "resolved_path": null,
      "source": "__future__",
      "source_raw": "from __future__ import annotations",
      "symbols": [
        "annotations"
      ]
    },
    {
      "authority": "repo_verified",
      "file": "tests/tui/test_operator_mode.py",
      "is_bare": true,
      "kind": "static",
      "line": 7,
      "resolution": "stdlib",
      "resolved_path": null,
      "source": "datetime",
      "source_raw": "from datetime import datetime",
      "symbols": [
        "datetime"
      ]
    },
    {
      "authority": "repo_verified",
      "file": "tests/tui/test_operator_mode.py",
      "is_bare": true,
      "kind": "static",
      "line": 8,
      "resolution": "stdlib",
      "resolved_path": null,
      "source": "pathlib",
      "source_raw": "from pathlib import Path",
      "symbols": [
        "Path"
      ]
    },
    {
      "authority": "repo_verified",
      "file": "tests/tui/test_operator_mode.py",
      "is_bare": true,
      "kind": "static",
      "line": 3,
      "resolution": "stdlib",
      "resolved_path": null,
      "source": "json",
      "source_raw": "json",
      "symbols": []
    },
    {
      "authority": "repo_verified",
      "file": "tests/tui/test_operator_mode.py",
      "is_bare": true,
      "kind": "static",
      "line": 4,
      "resolution": "stdlib",
      "resolved_path": null,
      "source": "os",
      "source_raw": "os",
      "symbols": []
    },
    {
      "authority": "repo_verified",
      "file": "tests/tui/test_operator_mode.py",
      "is_bare": true,
      "kind": "static",
      "line": 5,
      "resolution": "stdlib",
      "resolved_path": null,
      "source": "re",
      "source_raw": "re",
      "symbols": []
    },
    {
      "authority": "repo_verified",
      "file": "tests/tui/test_operator_mode.py",
      "is_bare": true,
      "kind": "static",
      "line": 6,
      "resolution": "stdlib",
      "resolved_path": null,
      "source": "subprocess",
      "source_raw": "subprocess",
      "symbols": []
    },
    {
      "authority": "repo_verified",
      "file": "tests/tui/test_vibecrafted_launcher.py",
      "is_bare": true,
      "kind": "static",
      "line": 1,
      "resolution": "unknown",
      "resolved_path": null,
      "source": "__future__",
      "source_raw": "from __future__ import annotations",
      "symbols": [
        "annotations"
      ]
    },
    {
      "authority": "repo_verified",
      "file": "tests/tui/test_vibecrafted_launcher.py",
      "is_bare": true,
      "kind": "static",
      "line": 8,
      "resolution": "stdlib",
      "resolved_path": null,
      "source": "pathlib",
      "source_raw": "from pathlib import Path",
      "symbols": [
        "Path"
      ]
    },
    {
      "authority": "repo_verified",
      "file": "tests/tui/test_vibecrafted_launcher.py",
      "is_bare": true,
      "kind": "static",
      "line": 3,
      "resolution": "stdlib",
      "resolved_path": null,
      "source": "hashlib",
      "source_raw": "hashlib",
      "symbols": []
    },
    {
      "authority": "repo_verified",
      "file": "tests/tui/test_vibecrafted_launcher.py",
      "is_bare": true,
      "kind": "static",
      "line": 4,
      "resolution": "stdlib",
      "resolved_path": null,
      "source": "json",
      "source_raw": "json",
      "symbols": []
    },
    {
      "authority": "repo_verified",
      "file": "tests/tui/test_vibecrafted_launcher.py",
      "is_bare": true,
      "kind": "static",
      "line": 5,
      "resolution": "stdlib",
      "resolved_path": null,
      "source": "os",
      "source_raw": "os",
      "symbols": []
    },
    {
      "authority": "repo_verified",
      "file": "tests/tui/test_vibecrafted_launcher.py",
      "is_bare": true,
      "kind": "static",
      "line": 10,
      "resolution": "unknown",
      "resolved_path": null,
      "source": "pytest",
      "source_raw": "pytest",
      "symbols": []
    },
    {
      "authority": "repo_verified",
      "file": "tests/tui/test_vibecrafted_launcher.py",
      "is_bare": true,
      "kind": "static",
      "line": 6,
      "resolution": "stdlib",
      "resolved_path": null,
      "source": "re",
      "source_raw": "re",
      "symbols": []
    },
    {
      "authority": "repo_verified",
      "file": "tests/tui/test_vibecrafted_launcher.py",
      "is_bare": true,
      "kind": "static",
      "line": 7,
      "resolution": "stdlib",
      "resolved_path": null,
      "source": "subprocess",
      "source_raw": "subprocess",
      "symbols": []
    }
  ],
  "symbols": [
    {
      "authority": "repo_verified",
      "export_type": "named",
      "file": "Makefile",
      "kind": "special_target",
      "line": 13,
      "name": ".PHONY"
    },
    {
      "authority": "repo_verified",
      "export_type": "named",
      "file": "Makefile",
      "kind": "var",
      "line": 10,
      "name": "BRANCH"
    },
    {
      "authority": "repo_verified",
      "export_type": "named",
      "file": "Makefile",
      "kind": "var",
      "line": 90,
      "name": "BUNDLE_DIR"
    },
    {
      "authority": "repo_verified",
      "export_type": "named",
      "file": "Makefile",
      "kind": "var",
      "line": 5,
      "name": "GUI_INSTALLER"
    },
    {
      "authority": "repo_verified",
      "export_type": "named",
      "file": "Makefile",
      "kind": "var",
      "line": 4,
      "name": "INSTALLER"
    },
    {
      "authority": "repo_verified",
      "export_type": "named",
      "file": "Makefile",
      "kind": "var",
      "line": 7,
      "name": "INSTALLER_DIR"
    },
    {
      "authority": "repo_verified",
      "export_type": "named",
      "file": "Makefile",
      "kind": "var",
      "line": 6,
      "name": "MANIFEST"
    },
    {
      "authority": "repo_verified",
      "export_type": "named",
      "file": "Makefile",
      "kind": "var",
      "line": 3,
      "name": "PYTHON"
    },
    {
      "authority": "repo_verified",
      "export_type": "named",
      "file": "Makefile",
      "kind": "var",
      "line": 8,
      "name": "SHELL_INSTALLER"
    },
    {
      "authority": "repo_verified",
      "export_type": "named",
      "file": "Makefile",
      "kind": "var",
      "line": 9,
      "name": "SOURCE"
    },
    {
      "authority": "repo_verified",
      "export_type": "named",
      "file": "Makefile",
      "kind": "var",
      "line": 11,
      "name": "VERSION_FILE"
    },
    {
      "authority": "repo_verified",
      "export_type": "named",
      "file": "Makefile",
      "kind": "target",
      "line": 197,
      "name": "bump-major"
    },
    {
      "authority": "repo_verified",
      "export_type": "named",
      "file": "Makefile",
      "kind": "target",
      "line": 194,
      "name": "bump-minor"
    },
    {
      "authority": "repo_verified",
      "export_type": "named",
      "file": "Makefile",
      "kind": "target",
      "line": 191,
      "name": "bump-patch"
    },
    {
      "authority": "repo_verified",
      "export_type": "named",
      "file": "Makefile",
      "kind": "target",
      "line": 158,
      "name": "bundle"
    },
    {
      "authority": "repo_verified",
      "export_type": "named",
      "file": "Makefile",
      "kind": "target",
      "line": 161,
      "name": "bundle-check"
    },
    {
      "authority": "repo_verified",
      "export_type": "named",
      "file": "Makefile",
      "kind": "target",
      "line": 247,
      "name": "check"
    },
    {
      "authority": "repo_verified",
      "export_type": "named",
      "file": "Makefile",
      "kind": "target",
      "line": 313,
      "name": "commit-safe"
    },
    {
      "authority": "repo_verified",
      "export_type": "named",
      "file": "Makefile",
      "kind": "target",
      "line": 270,
      "name": "demo"
    },
    {
      "authority": "repo_verified",
      "export_type": "named",
      "file": "Makefile",
      "kind": "target",
      "line": 273,
      "name": "demo-full"
    },
    {
      "authority": "repo_verified",
      "export_type": "named",
      "file": "Makefile",
      "kind": "target",
      "line": 152,
      "name": "doctor"
    },
    {
      "authority": "repo_verified",
      "export_type": "named",
      "file": "Makefile",
      "kind": "target",
      "line": 149,
      "name": "dry-run"
    },
    {
      "authority": "repo_verified",
      "export_type": "named",
      "file": "Makefile",
      "kind": "target",
      "line": 140,
      "name": "foundations"
    },
    {
      "authority": "repo_verified",
      "export_type": "named",
      "file": "Makefile",
      "kind": "target",
      "line": 143,
      "name": "foundations-check"
    },
    {
      "authority": "repo_verified",
      "export_type": "named",
      "file": "Makefile",
      "kind": "target",
      "line": 120,
      "name": "gui-install"
    },
    {
      "authority": "repo_verified",
      "export_type": "named",
      "file": "Makefile",
      "kind": "target",
      "line": 15,
      "name": "help"
    },
    {
      "authority": "repo_verified",
      "export_type": "named",
      "file": "Makefile",
      "kind": "target",
      "line": 137,
      "name": "helpers"
    },
    {
      "authority": "repo_verified",
      "export_type": "named",
      "file": "Makefile",
      "kind": "target",
      "line": 276,
      "name": "init-hooks"
    },
    {
      "authority": "repo_verified",
      "export_type": "named",
      "file": "Makefile",
      "kind": "target",
      "line": 126,
      "name": "install"
    },
    {
      "authority": "repo_verified",
      "export_type": "named",
      "file": "Makefile",
      "kind": "target",
      "line": 491,
      "name": "install-hammerspoon"
    },
    {
      "authority": "repo_verified",
      "export_type": "named",
      "file": "Makefile",
      "kind": "target",
      "line": 251,
      "name": "iterm-plugin"
    },
    {
      "authority": "repo_verified",
      "export_type": "named",
      "file": "Makefile",
      "kind": "target",
      "line": 267,
      "name": "iterm-plugin-migrate"
    },
    {
      "authority": "repo_verified",
      "export_type": "named",
      "file": "Makefile",
      "kind": "target",
      "line": 254,
      "name": "iterm-plugin-refresh"
    },
    {
      "authority": "repo_verified",
      "export_type": "named",
      "file": "Makefile",
      "kind": "target",
      "line": 257,
      "name": "iterm-plugin-show"
    },
    {
      "authority": "repo_verified",
      "export_type": "named",
      "file": "Makefile",
      "kind": "target",
      "line": 260,
      "name": "iterm-plugin-uninstall"
    },
    {
      "authority": "repo_verified",
      "export_type": "named",
      "file": "Makefile",
      "kind": "target",
      "line": 155,
      "name": "list"
    },
    {
      "authority": "repo_verified",
      "export_type": "named",
      "file": "Makefile",
      "kind": "target",
      "line": 241,
      "name": "migrate"
    },
    {
      "authority": "repo_verified",
      "export_type": "named",
      "file": "Makefile",
      "kind": "target",
      "line": 244,
      "name": "migrate-dry"
    },
    {
      "authority": "repo_verified",
      "export_type": "named",
      "file": "Makefile",
      "kind": "target",
      "line": 238,
      "name": "restore"
    },
    {
      "authority": "repo_verified",
      "export_type": "named",
      "file": "Makefile",
      "kind": "target",
      "line": 200,
      "name": "semgrep"
    },
    {
      "authority": "repo_verified",
      "export_type": "named",
      "file": "Makefile",
      "kind": "target",
      "line": 146,
      "name": "setup-dev"
    },
    {
      "authority": "repo_verified",
      "export_type": "named",
      "file": "Makefile",
      "kind": "target",
      "line": 367,
      "name": "skill-new"
    },
    {
      "authority": "repo_verified",
      "export_type": "named",
      "file": "Makefile",
      "kind": "target",
      "line": 134,
      "name": "skills"
    },
    {
      "authority": "repo_verified",
      "export_type": "named",
      "file": "Makefile",
      "kind": "target",
      "line": 207,
      "name": "test"
    },
    {
      "authority": "repo_verified",
      "export_type": "named",
      "file": "Makefile",
      "kind": "target",
      "line": 464,
      "name": "test-aicx-sync"
    },
    {
      "authority": "repo_verified",
      "export_type": "named",
      "file": "Makefile",
      "kind": "target",
      "line": 494,
      "name": "test-hammerspoon"
    },
    {
      "authority": "repo_verified",
      "export_type": "named",
      "file": "Makefile",
      "kind": "target",
      "line": 220,
      "name": "test-install"
    },
    {
      "authority": "repo_verified",
      "export_type": "named",
      "file": "Makefile",
      "kind": "target",
      "line": 412,
      "name": "test-iterm2-migrate"
    },
    {
      "authority": "repo_verified",
      "export_type": "named",
      "file": "Makefile",
      "kind": "target",
      "line": 433,
      "name": "test-memex"
    },
    {
      "authority": "repo_verified",
      "export_type": "named",
      "file": "Makefile",
      "kind": "target",
      "line": 350,
      "name": "test-parity"
    },
    {
      "authority": "repo_verified",
      "export_type": "named",
      "file": "Makefile",
      "kind": "target",
      "line": 337,
      "name": "test-race-protection"
    },
    {
      "authority": "repo_verified",
      "export_type": "named",
      "file": "Makefile",
      "kind": "target",
      "line": 214,
      "name": "test-skills"
    },
    {
      "authority": "repo_verified",
      "export_type": "named",
      "file": "Makefile",
      "kind": "target",
      "line": 393,
      "name": "test-zellij"
    },
    {
      "authority": "repo_verified",
      "export_type": "named",
      "file": "Makefile",
      "kind": "target",
      "line": 235,
      "name": "uninstall"
    },
    {
      "authority": "repo_verified",
      "export_type": "named",
      "file": "Makefile",
      "kind": "target",
      "line": 223,
      "name": "update"
    },
    {
      "authority": "repo_verified",
      "export_type": "named",
      "file": "Makefile",
      "kind": "target",
      "line": 184,
      "name": "version-bump"
    },
    {
      "authority": "repo_verified",
      "export_type": "named",
      "file": "Makefile",
      "kind": "target",
      "line": 77,
      "name": "vibecrafted"
    },
    {
      "authority": "repo_verified",
      "export_type": "named",
      "file": "Makefile",
      "kind": "target",
      "line": 92,
      "name": "wizard"
    },
    {
      "authority": "repo_verified",
      "export_type": "named",
      "file": "Makefile",
      "kind": "target",
      "line": 124,
      "name": "wizard-dev"
    },
    {
      "authority": "repo_verified",
      "export_type": "named",
      "file": "skills/vc-agents/shell/vetcoders.sh",
      "kind": "env",
      "line": 578,
      "name": "ATUIN_CONFIG"
    },
    {
      "authority": "repo_verified",
      "export_type": "named",
      "file": "skills/vc-agents/shell/vetcoders.sh",
      "kind": "env",
      "line": 574,
      "name": "STARSHIP_CONFIG"
    },
    {
      "authority": "repo_verified",
      "export_type": "named",
      "file": "skills/vc-agents/shell/vetcoders.sh",
      "kind": "env",
      "line": 1593,
      "name": "VIBECRAFTED_LOOP_NR"
    },
    {
      "authority": "repo_verified",
      "export_type": "named",
      "file": "skills/vc-agents/shell/vetcoders.sh",
      "kind": "env",
      "line": 2222,
      "name": "VIBECRAFTED_MARBLES_TAB_NAME"
    },
    {
      "authority": "repo_verified",
      "export_type": "named",
      "file": "skills/vc-agents/shell/vetcoders.sh",
      "kind": "env",
      "line": 415,
      "name": "VIBECRAFTED_OPERATOR_SESSION"
    },
    {
      "authority": "repo_verified",
      "export_type": "named",
      "file": "skills/vc-agents/shell/vetcoders.sh",
      "kind": "env",
      "line": 2040,
      "name": "VIBECRAFTED_RESEARCH_MODE"
    },
    {
      "authority": "repo_verified",
      "export_type": "named",
      "file": "skills/vc-agents/shell/vetcoders.sh",
      "kind": "env",
      "line": 2046,
      "name": "VIBECRAFTED_RESEARCH_RUN_DIR"
    },
    {
      "authority": "repo_verified",
      "export_type": "named",
      "file": "skills/vc-agents/shell/vetcoders.sh",
      "kind": "env",
      "line": 1587,
      "name": "VIBECRAFTED_RUN_ID"
    },
    {
      "authority": "repo_verified",
      "export_type": "named",
      "file": "skills/vc-agents/shell/vetcoders.sh",
      "kind": "env",
      "line": 1589,
      "name": "VIBECRAFTED_RUN_LOCK"
    },
    {
      "authority": "repo_verified",
      "export_type": "named",
      "file": "skills/vc-agents/shell/vetcoders.sh",
      "kind": "env",
      "line": 1591,
      "name": "VIBECRAFTED_SKILL_CODE"
    },
    {
      "authority": "repo_verified",
      "export_type": "named",
      "file": "skills/vc-agents/shell/vetcoders.sh",
      "kind": "env",
      "line": 1595,
      "name": "VIBECRAFTED_SKILL_NAME"
    },
    {
      "authority": "repo_verified",
      "export_type": "named",
      "file": "skills/vc-agents/shell/vetcoders.sh",
      "kind": "env",
      "line": 2042,
      "name": "VIBECRAFTED_STORE_DIR"
    },
    {
      "authority": "repo_verified",
      "export_type": "named",
      "file": "skills/vc-agents/shell/vetcoders.sh",
      "kind": "env",
      "line": 2044,
      "name": "VIBECRAFTED_STORE_ROOT"
    },
    {
      "authority": "repo_verified",
      "export_type": "named",
      "file": "skills/vc-agents/shell/vetcoders.sh",
      "kind": "env",
      "line": 583,
      "name": "ZELLIJ_CONFIG_DIR"
    },
    {
      "authority": "repo_verified",
      "export_type": "named",
      "file": "skills/vc-agents/shell/vetcoders.sh",
      "kind": "function",
      "line": 2645,
      "name": "_repo_full_compare_ref"
    },
    {
      "authority": "repo_verified",
      "export_type": "named",
      "file": "skills/vc-agents/shell/vetcoders.sh",
      "kind": "function",
      "line": 901,
      "name": "_vetcoders_append_tail"
    },
    {
      "authority": "repo_verified",
      "export_type": "named",
      "file": "skills/vc-agents/shell/vetcoders.sh",
      "kind": "function",
      "line": 157,
      "name": "_vetcoders_atuin_bin"
    },
    {
      "authority": "repo_verified",
      "export_type": "named",
      "file": "skills/vc-agents/shell/vetcoders.sh",
      "kind": "function",
      "line": 597,
      "name": "_vetcoders_atuin_home_fallback_cwd"
    },
    {
      "authority": "repo_verified",
      "export_type": "named",
      "file": "skills/vc-agents/shell/vetcoders.sh",
      "kind": "function",
      "line": 593,
      "name": "_vetcoders_atuin_home_fallback_enabled"
    },
    {
      "authority": "repo_verified",
      "export_type": "named",
      "file": "skills/vc-agents/shell/vetcoders.sh",
      "kind": "function",
      "line": 659,
      "name": "_vetcoders_atuin_probe_current_scope"
    },
    {
      "authority": "repo_verified",
      "export_type": "named",
      "file": "skills/vc-agents/shell/vetcoders.sh",
      "kind": "function",
      "line": 641,
      "name": "_vetcoders_atuin_run"
    },
    {
      "authority": "repo_verified",
      "export_type": "named",
      "file": "skills/vc-agents/shell/vetcoders.sh",
      "kind": "function",
      "line": 647,
      "name": "_vetcoders_atuin_run_with_home_scope"
    },
    {
      "authority": "repo_verified",
      "export_type": "named",
      "file": "skills/vc-agents/shell/vetcoders.sh",
      "kind": "function",
      "line": 612,
      "name": "_vetcoders_atuin_search_can_fallback"
    },
    {
      "authority": "repo_verified",
      "export_type": "named",
      "file": "skills/vc-agents/shell/vetcoders.sh",
      "kind": "function",
      "line": 628,
      "name": "_vetcoders_atuin_search_is_interactive"
    },
    {
      "authority": "repo_verified",
      "export_type": "named",
      "file": "skills/vc-agents/shell/vetcoders.sh",
      "kind": "function",
      "line": 291,
      "name": "_vetcoders_auto_gc_dead_zellij_sessions"
    },
    {
      "authority": "repo_verified",
      "export_type": "named",
      "file": "skills/vc-agents/shell/vetcoders.sh",
      "kind": "function",
      "line": 1608,
      "name": "_vetcoders_await"
    },
    {
      "authority": "repo_verified",
      "export_type": "named",
      "file": "skills/vc-agents/shell/vetcoders.sh",
      "kind": "function",
      "line": 1202,
      "name": "_vetcoders_capture_session_uuid"
    },
    {
      "authority": "repo_verified",
      "export_type": "named",
      "file": "skills/vc-agents/shell/vetcoders.sh",
      "kind": "function",
      "line": 1438,
      "name": "_vetcoders_compose_init_prompt"
    },
    {
      "authority": "repo_verified",
      "export_type": "named",
      "file": "skills/vc-agents/shell/vetcoders.sh",
      "kind": "function",
      "line": 1055,
      "name": "_vetcoders_compose_input_context"
    },
    {
      "authority": "repo_verified",
      "export_type": "named",
      "file": "skills/vc-agents/shell/vetcoders.sh",
      "kind": "function",
      "line": 1495,
      "name": "_vetcoders_compose_operator_prompt"
    },
    {
      "authority": "repo_verified",
      "export_type": "named",
      "file": "skills/vc-agents/shell/vetcoders.sh",
      "kind": "function",
      "line": 1342,
      "name": "_vetcoders_compose_polarize_prompt"
    },
    {
      "authority": "repo_verified",
      "export_type": "named",
      "file": "skills/vc-agents/shell/vetcoders.sh",
      "kind": "function",
      "line": 1403,
      "name": "_vetcoders_compose_research_worker_prompt"
    },
    {
      "authority": "repo_verified",
      "export_type": "named",
      "file": "skills/vc-agents/shell/vetcoders.sh",
      "kind": "function",
      "line": 1078,
      "name": "_vetcoders_compose_skill_prompt"
    },
    {
      "authority": "repo_verified",
      "export_type": "named",
      "file": "skills/vc-agents/shell/vetcoders.sh",
      "kind": "function",
      "line": 887,
      "name": "_vetcoders_contract_reset"
    },
    {
      "authority": "repo_verified",
      "export_type": "named",
      "file": "skills/vc-agents/shell/vetcoders.sh",
      "kind": "function",
      "line": 153,
      "name": "_vetcoders_current_zellij_session_name"
    },
    {
      "authority": "repo_verified",
      "export_type": "named",
      "file": "skills/vc-agents/shell/vetcoders.sh",
      "kind": "function",
      "line": 732,
      "name": "_vetcoders_dashboard_layout_file"
    },
    {
      "authority": "repo_verified",
      "export_type": "named",
      "file": "skills/vc-agents/shell/vetcoders.sh",
      "kind": "function",
      "line": 715,
      "name": "_vetcoders_dashboard_layout_name"
    },
    {
      "authority": "repo_verified",
      "export_type": "named",
      "file": "skills/vc-agents/shell/vetcoders.sh",
      "kind": "function",
      "line": 738,
      "name": "_vetcoders_dashboard_session_name"
    },
    {
      "authority": "repo_verified",
      "export_type": "named",
      "file": "skills/vc-agents/shell/vetcoders.sh",
      "kind": "function",
      "line": 75,
      "name": "_vetcoders_default_runtime"
    },
    {
      "authority": "repo_verified",
      "export_type": "named",
      "file": "skills/vc-agents/shell/vetcoders.sh",
      "kind": "function",
      "line": 1575,
      "name": "_vetcoders_dispatch_skill_prompt"
    },
    {
      "authority": "repo_verified",
      "export_type": "named",
      "file": "skills/vc-agents/shell/vetcoders.sh",
      "kind": "function",
      "line": 983,
      "name": "_vetcoders_effective_runtime"
    },
    {
      "authority": "repo_verified",
      "export_type": "named",
      "file": "skills/vc-agents/shell/vetcoders.sh",
      "kind": "function",
      "line": 314,
      "name": "_vetcoders_ensure_zellij_session"
    },
    {
      "authority": "repo_verified",
      "export_type": "named",
      "file": "skills/vc-agents/shell/vetcoders.sh",
      "kind": "function",
      "line": 493,
      "name": "_vetcoders_frontier_candidates"
    },
    {
      "authority": "repo_verified",
      "export_type": "named",
      "file": "skills/vc-agents/shell/vetcoders.sh",
      "kind": "function",
      "line": 528,
      "name": "_vetcoders_frontier_file"
    },
    {
      "authority": "repo_verified",
      "export_type": "named",
      "file": "skills/vc-agents/shell/vetcoders.sh",
      "kind": "function",
      "line": 513,
      "name": "_vetcoders_frontier_root"
    },
    {
      "authority": "repo_verified",
      "export_type": "named",
      "file": "skills/vc-agents/shell/vetcoders.sh",
      "kind": "function",
      "line": 540,
      "name": "_vetcoders_frontier_source_root"
    },
    {
      "authority": "repo_verified",
      "export_type": "named",
      "file": "skills/vc-agents/shell/vetcoders.sh",
      "kind": "function",
      "line": 146,
      "name": "_vetcoders_guess_active_zellij_session"
    },
    {
      "authority": "repo_verified",
      "export_type": "named",
      "file": "skills/vc-agents/shell/vetcoders.sh",
      "kind": "function",
      "line": 2464,
      "name": "_vetcoders_has_agent"
    },
    {
      "authority": "repo_verified",
      "export_type": "named",
      "file": "skills/vc-agents/shell/vetcoders.sh",
      "kind": "function",
      "line": 140,
      "name": "_vetcoders_in_zellij"
    },
    {
      "authority": "repo_verified",
      "export_type": "named",
      "file": "skills/vc-agents/shell/vetcoders.sh",
      "kind": "function",
      "line": 1453,
      "name": "_vetcoders_init_command_text"
    },
    {
      "authority": "repo_verified",
      "export_type": "named",
      "file": "skills/vc-agents/shell/vetcoders.sh",
      "kind": "function",
      "line": 1425,
      "name": "_vetcoders_init_runtime"
    },
    {
      "authority": "repo_verified",
      "export_type": "named",
      "file": "skills/vc-agents/shell/vetcoders.sh",
      "kind": "function",
      "line": 2469,
      "name": "_vetcoders_is_help_flag"
    },
    {
      "authority": "repo_verified",
      "export_type": "named",
      "file": "skills/vc-agents/shell/vetcoders.sh",
      "kind": "function",
      "line": 746,
      "name": "_vetcoders_launch_dashboard"
    },
    {
      "authority": "repo_verified",
      "export_type": "named",
      "file": "skills/vc-agents/shell/vetcoders.sh",
      "kind": "function",
      "line": 88,
      "name": "_vetcoders_load_bundled_bin_path"
    },
    {
      "authority": "repo_verified",
      "export_type": "named",
      "file": "skills/vc-agents/shell/vetcoders.sh",
      "kind": "function",
      "line": 564,
      "name": "_vetcoders_load_frontier_sidecars"
    },
    {
      "authority": "repo_verified",
      "export_type": "named",
      "file": "skills/vc-agents/shell/vetcoders.sh",
      "kind": "function",
      "line": 2140,
      "name": "_vetcoders_marbles"
    },
    {
      "authority": "repo_verified",
      "export_type": "named",
      "file": "skills/vc-agents/shell/vetcoders.sh",
      "kind": "function",
      "line": 1813,
      "name": "_vetcoders_maybe_spawn_await_pane"
    },
    {
      "authority": "repo_verified",
      "export_type": "named",
      "file": "skills/vc-agents/shell/vetcoders.sh",
      "kind": "function",
      "line": 1600,
      "name": "_vetcoders_observe"
    },
    {
      "authority": "repo_verified",
      "export_type": "named",
      "file": "skills/vc-agents/shell/vetcoders.sh",
      "kind": "function",
      "line": 229,
      "name": "_vetcoders_open_iterm_command"
    },
    {
      "authority": "repo_verified",
      "export_type": "named",
      "file": "skills/vc-agents/shell/vetcoders.sh",
      "kind": "function",
      "line": 255,
      "name": "_vetcoders_open_terminal_command"
    },
    {
      "authority": "repo_verified",
      "export_type": "named",
      "file": "skills/vc-agents/shell/vetcoders.sh",
      "kind": "function",
      "line": 1510,
      "name": "_vetcoders_operator_command_text"
    },
    {
      "authority": "repo_verified",
      "export_type": "named",
      "file": "skills/vc-agents/shell/vetcoders.sh",
      "kind": "function",
      "line": 276,
      "name": "_vetcoders_operator_layout_file"
    },
    {
      "authority": "repo_verified",
      "export_type": "named",
      "file": "skills/vc-agents/shell/vetcoders.sh",
      "kind": "function",
      "line": 1482,
      "name": "_vetcoders_operator_runtime"
    },
    {
      "authority": "repo_verified",
      "export_type": "named",
      "file": "skills/vc-agents/shell/vetcoders.sh",
      "kind": "function",
      "line": 280,
      "name": "_vetcoders_operator_session_name"
    },
    {
      "authority": "repo_verified",
      "export_type": "named",
      "file": "skills/vc-agents/shell/vetcoders.sh",
      "kind": "function",
      "line": 176,
      "name": "_vetcoders_osascript_bin"
    },
    {
      "authority": "repo_verified",
      "export_type": "named",
      "file": "skills/vc-agents/shell/vetcoders.sh",
      "kind": "function",
      "line": 910,
      "name": "_vetcoders_parse_contract"
    },
    {
      "authority": "repo_verified",
      "export_type": "named",
      "file": "skills/vc-agents/shell/vetcoders.sh",
      "kind": "function",
      "line": 1192,
      "name": "_vetcoders_polarize_band_range"
    },
    {
      "authority": "repo_verified",
      "export_type": "named",
      "file": "skills/vc-agents/shell/vetcoders.sh",
      "kind": "function",
      "line": 1168,
      "name": "_vetcoders_polarize_band_select"
    },
    {
      "authority": "repo_verified",
      "export_type": "named",
      "file": "skills/vc-agents/shell/vetcoders.sh",
      "kind": "function",
      "line": 1230,
      "name": "_vetcoders_polarize_emit_context_pack"
    },
    {
      "authority": "repo_verified",
      "export_type": "named",
      "file": "skills/vc-agents/shell/vetcoders.sh",
      "kind": "function",
      "line": 1092,
      "name": "_vetcoders_polarize_prism_axes"
    },
    {
      "authority": "repo_verified",
      "export_type": "named",
      "file": "skills/vc-agents/shell/vetcoders.sh",
      "kind": "function",
      "line": 1099,
      "name": "_vetcoders_polarize_prism_command_text"
    },
    {
      "authority": "repo_verified",
      "export_type": "named",
      "file": "skills/vc-agents/shell/vetcoders.sh",
      "kind": "function",
      "line": 1156,
      "name": "_vetcoders_polarize_score"
    },
    {
      "authority": "repo_verified",
      "export_type": "named",
      "file": "skills/vc-agents/shell/vetcoders.sh",
      "kind": "function",
      "line": 186,
      "name": "_vetcoders_preferred_terminal"
    },
    {
      "authority": "repo_verified",
      "export_type": "named",
      "file": "skills/vc-agents/shell/vetcoders.sh",
      "kind": "function",
      "line": 401,
      "name": "_vetcoders_prepare_operator_runtime"
    },
    {
      "authority": "repo_verified",
      "export_type": "named",
      "file": "skills/vc-agents/shell/vetcoders.sh",
      "kind": "function",
      "line": 79,
      "name": "_vetcoders_prepend_path_dir"
    },
    {
      "authority": "repo_verified",
      "export_type": "named",
      "file": "skills/vc-agents/shell/vetcoders.sh",
      "kind": "function",
      "line": 1566,
      "name": "_vetcoders_prompt"
    },
    {
      "authority": "repo_verified",
      "export_type": "named",
      "file": "skills/vc-agents/shell/vetcoders.sh",
      "kind": "function",
      "line": 866,
      "name": "_vetcoders_prompt_file"
    },
    {
      "authority": "repo_verified",
      "export_type": "named",
      "file": "skills/vc-agents/shell/vetcoders.sh",
      "kind": "function",
      "line": 1556,
      "name": "_vetcoders_prompt_text"
    },
    {
      "authority": "repo_verified",
      "export_type": "named",
      "file": "skills/vc-agents/shell/vetcoders.sh",
      "kind": "function",
      "line": 1000,
      "name": "_vetcoders_require_file"
    },
    {
      "authority": "repo_verified",
      "export_type": "named",
      "file": "skills/vc-agents/shell/vetcoders.sh",
      "kind": "function",
      "line": 991,
      "name": "_vetcoders_require_positive_int"
    },
    {
      "authority": "repo_verified",
      "export_type": "named",
      "file": "skills/vc-agents/shell/vetcoders.sh",
      "kind": "function",
      "line": 116,
      "name": "_vetcoders_require_tty"
    },
    {
      "authority": "repo_verified",
      "export_type": "named",
      "file": "skills/vc-agents/shell/vetcoders.sh",
      "kind": "function",
      "line": 104,
      "name": "_vetcoders_require_zellij"
    },
    {
      "authority": "repo_verified",
      "export_type": "named",
      "file": "skills/vc-agents/shell/vetcoders.sh",
      "kind": "function",
      "line": 1942,
      "name": "_vetcoders_research"
    },
    {
      "authority": "repo_verified",
      "export_type": "named",
      "file": "skills/vc-agents/shell/vetcoders.sh",
      "kind": "function",
      "line": 1379,
      "name": "_vetcoders_research_file_body"
    },
    {
      "authority": "repo_verified",
      "export_type": "named",
      "file": "skills/vc-agents/shell/vetcoders.sh",
      "kind": "function",
      "line": 1916,
      "name": "_vetcoders_research_help"
    },
    {
      "authority": "repo_verified",
      "export_type": "named",
      "file": "skills/vc-agents/shell/vetcoders.sh",
      "kind": "function",
      "line": 1842,
      "name": "_vetcoders_research_launcher_path"
    },
    {
      "authority": "repo_verified",
      "export_type": "named",
      "file": "skills/vc-agents/shell/vetcoders.sh",
      "kind": "function",
      "line": 2263,
      "name": "_vetcoders_resume_agent"
    },
    {
      "authority": "repo_verified",
      "export_type": "named",
      "file": "skills/vc-agents/shell/vetcoders.sh",
      "kind": "function",
      "line": 857,
      "name": "_vetcoders_resume_operator_session"
    },
    {
      "authority": "repo_verified",
      "export_type": "named",
      "file": "skills/vc-agents/shell/vetcoders.sh",
      "kind": "function",
      "line": 32,
      "name": "_vetcoders_runtime_helper_candidates"
    },
    {
      "authority": "repo_verified",
      "export_type": "named",
      "file": "skills/vc-agents/shell/vetcoders.sh",
      "kind": "function",
      "line": 17,
      "name": "_vetcoders_runtime_repo_root"
    },
    {
      "authority": "repo_verified",
      "export_type": "named",
      "file": "skills/vc-agents/shell/vetcoders.sh",
      "kind": "function",
      "line": 601,
      "name": "_vetcoders_same_physical_dir"
    },
    {
      "authority": "repo_verified",
      "export_type": "named",
      "file": "skills/vc-agents/shell/vetcoders.sh",
      "kind": "function",
      "line": 10,
      "name": "_vetcoders_script_dir"
    },
    {
      "authority": "repo_verified",
      "export_type": "named",
      "file": "skills/vc-agents/shell/vetcoders.sh",
      "kind": "function",
      "line": 1012,
      "name": "_vetcoders_shell_quote"
    },
    {
      "authority": "repo_verified",
      "export_type": "named",
      "file": "skills/vc-agents/shell/vetcoders.sh",
      "kind": "function",
      "line": 1023,
      "name": "_vetcoders_shell_quote_join"
    },
    {
      "authority": "repo_verified",
      "export_type": "named",
      "file": "skills/vc-agents/shell/vetcoders.sh",
      "kind": "function",
      "line": 1704,
      "name": "_vetcoders_skill"
    },
    {
      "authority": "repo_verified",
      "export_type": "named",
      "file": "skills/vc-agents/shell/vetcoders.sh",
      "kind": "function",
      "line": 1835,
      "name": "_vetcoders_skill_entry"
    },
    {
      "authority": "repo_verified",
      "export_type": "named",
      "file": "skills/vc-agents/shell/vetcoders.sh",
      "kind": "function",
      "line": 2070,
      "name": "_vetcoders_skill_init"
    },
    {
      "authority": "repo_verified",
      "export_type": "named",
      "file": "skills/vc-agents/shell/vetcoders.sh",
      "kind": "function",
      "line": 2103,
      "name": "_vetcoders_skill_operator"
    },
    {
      "authority": "repo_verified",
      "export_type": "named",
      "file": "skills/vc-agents/shell/vetcoders.sh",
      "kind": "function",
      "line": 2474,
      "name": "_vetcoders_skill_wrapper"
    },
    {
      "authority": "repo_verified",
      "export_type": "named",
      "file": "skills/vc-agents/shell/vetcoders.sh",
      "kind": "function",
      "line": 2444,
      "name": "_vetcoders_skill_wrapper_usage"
    },
    {
      "authority": "repo_verified",
      "export_type": "named",
      "file": "skills/vc-agents/shell/vetcoders.sh",
      "kind": "function",
      "line": 44,
      "name": "_vetcoders_source_runtime_helpers"
    },
    {
      "authority": "repo_verified",
      "export_type": "named",
      "file": "skills/vc-agents/shell/vetcoders.sh",
      "kind": "function",
      "line": 464,
      "name": "_vetcoders_spawn_into_operator_session"
    },
    {
      "authority": "repo_verified",
      "export_type": "named",
      "file": "skills/vc-agents/shell/vetcoders.sh",
      "kind": "function",
      "line": 1533,
      "name": "_vetcoders_spawn_plan"
    },
    {
      "authority": "repo_verified",
      "export_type": "named",
      "file": "skills/vc-agents/shell/vetcoders.sh",
      "kind": "function",
      "line": 172,
      "name": "_vetcoders_strip_ansi"
    },
    {
      "authority": "repo_verified",
      "export_type": "named",
      "file": "skills/vc-agents/shell/vetcoders.sh",
      "kind": "function",
      "line": 299,
      "name": "_vetcoders_wait_for_zellij_session"
    },
    {
      "authority": "repo_verified",
      "export_type": "named",
      "file": "skills/vc-agents/shell/vetcoders.sh",
      "kind": "function",
      "line": 681,
      "name": "_vetcoders_wrap_atuin"
    },
    {
      "authority": "repo_verified",
      "export_type": "named",
      "file": "skills/vc-agents/shell/vetcoders.sh",
      "kind": "function",
      "line": 1032,
      "name": "_vetcoders_write_command_script"
    },
    {
      "authority": "repo_verified",
      "export_type": "named",
      "file": "skills/vc-agents/shell/vetcoders.sh",
      "kind": "function",
      "line": 1208,
      "name": "_vetcoders_write_polarize_memo"
    },
    {
      "authority": "repo_verified",
      "export_type": "named",
      "file": "skills/vc-agents/shell/vetcoders.sh",
      "kind": "function",
      "line": 1117,
      "name": "_vetcoders_write_polarize_prism_payload"
    },
    {
      "authority": "repo_verified",
      "export_type": "named",
      "file": "skills/vc-agents/shell/vetcoders.sh",
      "kind": "function",
      "line": 1878,
      "name": "_vetcoders_write_research_layout"
    },
    {
      "authority": "repo_verified",
      "export_type": "named",
      "file": "skills/vc-agents/shell/vetcoders.sh",
      "kind": "function",
      "line": 287,
      "name": "_vetcoders_zellij_gc_script"
    },
    {
      "authority": "repo_verified",
      "export_type": "named",
      "file": "skills/vc-agents/shell/vetcoders.sh",
      "kind": "function",
      "line": 96,
      "name": "_vetcoders_zellij_missing_message"
    },
    {
      "authority": "repo_verified",
      "export_type": "named",
      "file": "skills/vc-agents/shell/vetcoders.sh",
      "kind": "function",
      "line": 202,
      "name": "_vetcoders_zellij_session_state"
    },
    {
      "authority": "repo_verified",
      "export_type": "named",
      "file": "skills/vc-agents/shell/vetcoders.sh",
      "kind": "function",
      "line": 687,
      "name": "atuin"
    },
    {
      "authority": "repo_verified",
      "export_type": "named",
      "file": "skills/vc-agents/shell/vetcoders.sh",
      "kind": "function",
      "line": 2656,
      "name": "human"
    },
    {
      "authority": "repo_verified",
      "export_type": "named",
      "file": "tests/tui/test_await_observe_contract.py",
      "kind": "def",
      "line": 143,
      "name": "test_await_detects_false_launched_pid_pending_meta"
    },
    {
      "authority": "repo_verified",
      "export_type": "named",
      "file": "tests/tui/test_await_observe_contract.py",
      "kind": "def",
      "line": 96,
      "name": "test_await_exits_nonzero_for_failed_meta"
    },
    {
      "authority": "repo_verified",
      "export_type": "named",
      "file": "tests/tui/test_await_observe_contract.py",
      "kind": "def",
      "line": 75,
      "name": "test_await_exits_zero_for_completed_meta"
    },
    {
      "authority": "repo_verified",
      "export_type": "named",
      "file": "tests/tui/test_await_observe_contract.py",
      "kind": "def",
      "line": 114,
      "name": "test_await_heartbeat_for_running_pid_alive_meta"
    },
    {
      "authority": "repo_verified",
      "export_type": "named",
      "file": "tests/tui/test_await_observe_contract.py",
      "kind": "def",
      "line": 171,
      "name": "test_observe_resolves_run_id"
    },
    {
      "authority": "repo_verified",
      "export_type": "named",
      "file": "tests/tui/test_operator_mode.py",
      "kind": "def",
      "line": 618,
      "name": "test_dashboard_alt_layout_reuses_live_repo_session_instead_of_layout_session"
    },
    {
      "authority": "repo_verified",
      "export_type": "named",
      "file": "tests/tui/test_operator_mode.py",
      "kind": "def",
      "line": 168,
      "name": "test_helper_exports_vc_skill_wrappers"
    },
    {
      "authority": "repo_verified",
      "export_type": "named",
      "file": "tests/tui/test_operator_mode.py",
      "kind": "def",
      "line": 292,
      "name": "test_marbles_from_operator_mode_spawns_launcher_in_fresh_tab_and_loops_right"
    },
    {
      "authority": "repo_verified",
      "export_type": "named",
      "file": "tests/tui/test_operator_mode.py",
      "kind": "def",
      "line": 330,
      "name": "test_marbles_manual_spawn_emits_probe_without_l1_transcript_tail"
    },
    {
      "authority": "repo_verified",
      "export_type": "named",
      "file": "tests/tui/test_operator_mode.py",
      "kind": "def",
      "line": 562,
      "name": "test_skill_bootstraps_fresh_operator_session_when_existing_one_is_dead"
    },
    {
      "authority": "repo_verified",
      "export_type": "named",
      "file": "tests/tui/test_operator_mode.py",
      "kind": "def",
      "line": 519,
      "name": "test_skill_bootstraps_operator_session_before_spawning"
    },
    {
      "authority": "repo_verified",
      "export_type": "named",
      "file": "tests/tui/test_operator_mode.py",
      "kind": "def",
      "line": 404,
      "name": "test_spawn_script_prefers_repo_runtime_over_installed_copy"
    },
    {
      "authority": "repo_verified",
      "export_type": "named",
      "file": "tests/tui/test_operator_mode.py",
      "kind": "def",
      "line": 477,
      "name": "test_vc_dashboard_recreates_dead_run_id_session_without_layout_suffix"
    },
    {
      "authority": "repo_verified",
      "export_type": "named",
      "file": "tests/tui/test_operator_mode.py",
      "kind": "def",
      "line": 204,
      "name": "test_vc_init_finds_bundled_zellij_and_creates_missing_operator_session"
    },
    {
      "authority": "repo_verified",
      "export_type": "named",
      "file": "tests/tui/test_operator_mode.py",
      "kind": "def",
      "line": 257,
      "name": "test_vc_init_missing_zellij_message_has_fresh_install_path_hint"
    },
    {
      "authority": "repo_verified",
      "export_type": "named",
      "file": "tests/tui/test_operator_mode.py",
      "kind": "def",
      "line": 134,
      "name": "test_vc_start_launches_operator_entrypoint_layout"
    },
    {
      "authority": "repo_verified",
      "export_type": "named",
      "file": "tests/tui/test_operator_mode.py",
      "kind": "def",
      "line": 439,
      "name": "test_vc_start_resume_resurrects_dead_session"
    },
    {
      "authority": "repo_verified",
      "export_type": "named",
      "file": "tests/tui/test_vibecrafted_launcher.py",
      "kind": "def",
      "line": 1303,
      "name": "test_agent_subcommand_help_lists_modes"
    },
    {
      "authority": "repo_verified",
      "export_type": "named",
      "file": "tests/tui/test_vibecrafted_launcher.py",
      "kind": "def",
      "line": 1041,
      "name": "test_compact_help_teaches_implement_before_alias"
    },
    {
      "authority": "repo_verified",
      "export_type": "named",
      "file": "tests/tui/test_vibecrafted_launcher.py",
      "kind": "def",
      "line": 1564,
      "name": "test_dashboard_attach_inside_zellij_uses_switch_session"
    },
    {
      "authority": "repo_verified",
      "export_type": "named",
      "file": "tests/tui/test_vibecrafted_launcher.py",
      "kind": "def",
      "line": 1677,
      "name": "test_dashboard_gc_include_live_prunes_only_stale_detached_sessions"
    },
    {
      "authority": "repo_verified",
      "export_type": "named",
      "file": "tests/tui/test_vibecrafted_launcher.py",
      "kind": "def",
      "line": 1628,
      "name": "test_dashboard_gc_prunes_dead_sessions"
    },
    {
      "authority": "repo_verified",
      "export_type": "named",
      "file": "tests/tui/test_vibecrafted_launcher.py",
      "kind": "def",
      "line": 1498,
      "name": "test_dashboard_ls_delegates_to_zellij_list_sessions"
    },
    {
      "authority": "repo_verified",
      "export_type": "named",
      "file": "tests/tui/test_vibecrafted_launcher.py",
      "kind": "def",
      "line": 1318,
      "name": "test_dashboard_subcommand_launches_repo_owned_zellij_layout"
    },
    {
      "authority": "repo_verified",
      "export_type": "named",
      "file": "tests/tui/test_vibecrafted_launcher.py",
      "kind": "def",
      "line": 1529,
      "name": "test_dashboard_switch_inside_zellij_uses_switch_session"
    },
    {
      "authority": "repo_verified",
      "export_type": "named",
      "file": "tests/tui/test_vibecrafted_launcher.py",
      "kind": "def",
      "line": 1597,
      "name": "test_dashboard_switch_outside_zellij_uses_attach"
    },
    {
      "authority": "repo_verified",
      "export_type": "named",
      "file": "tests/tui/test_vibecrafted_launcher.py",
      "kind": "def",
      "line": 1189,
      "name": "test_generic_skill_fallback_routes_skill_wrappers"
    },
    {
      "authority": "repo_verified",
      "export_type": "named",
      "file": "tests/tui/test_vibecrafted_launcher.py",
      "kind": "def",
      "line": 1142,
      "name": "test_generic_skill_fallback_routes_unwrapped_skills"
    },
    {
      "authority": "repo_verified",
      "export_type": "named",
      "file": "tests/tui/test_vibecrafted_launcher.py",
      "kind": "def",
      "line": 944,
      "name": "test_gui_help_exposes_local_server_flags"
    },
    {
      "authority": "repo_verified",
      "export_type": "named",
      "file": "tests/tui/test_vibecrafted_launcher.py",
      "kind": "def",
      "line": 968,
      "name": "test_help_topics_route_to_specific_command_or_skill_help"
    },
    {
      "authority": "repo_verified",
      "export_type": "named",
      "file": "tests/tui/test_vibecrafted_launcher.py",
      "kind": "def",
      "line": 1009,
      "name": "test_implement_help_is_the_canonical_autonomous_delivery_surface"
    },
    {
      "authority": "repo_verified",
      "export_type": "named",
      "file": "tests/tui/test_vibecrafted_launcher.py",
      "kind": "def",
      "line": 301,
      "name": "test_init_claude_uses_interactive_tab_without_print_mode"
    },
    {
      "authority": "repo_verified",
      "export_type": "named",
      "file": "tests/tui/test_vibecrafted_launcher.py",
      "kind": "def",
      "line": 349,
      "name": "test_init_codex_uses_interactive_tab_without_exec_mode"
    },
    {
      "authority": "repo_verified",
      "export_type": "named",
      "file": "tests/tui/test_vibecrafted_launcher.py",
      "kind": "def",
      "line": 786,
      "name": "test_installed_launcher_gui_uses_python_control_plane_surface"
    },
    {
      "authority": "repo_verified",
      "export_type": "named",
      "file": "tests/tui/test_vibecrafted_launcher.py",
      "kind": "def",
      "line": 566,
      "name": "test_installed_launcher_prefers_current_control_plane_helper_over_home_store"
    },
    {
      "authority": "repo_verified",
      "export_type": "named",
      "file": "tests/tui/test_vibecrafted_launcher.py",
      "kind": "def",
      "line": 835,
      "name": "test_installed_launcher_tui_uses_shared_state_and_operator_binary"
    },
    {
      "authority": "repo_verified",
      "export_type": "named",
      "file": "tests/tui/test_vibecrafted_launcher.py",
      "kind": "def",
      "line": 1025,
      "name": "test_justdo_help_points_back_to_implement"
    },
    {
      "authority": "repo_verified",
      "export_type": "named",
      "file": "tests/tui/test_vibecrafted_launcher.py",
      "kind": "def",
      "line": 1258,
      "name": "test_marbles_delete_control_subcommand_routes_to_helper"
    },
    {
      "authority": "repo_verified",
      "export_type": "named",
      "file": "tests/tui/test_vibecrafted_launcher.py",
      "kind": "def",
      "line": 1243,
      "name": "test_marbles_flags_without_agent_get_actionable_error"
    },
    {
      "authority": "repo_verified",
      "export_type": "named",
      "file": "tests/tui/test_vibecrafted_launcher.py",
      "kind": "def",
      "line": 1225,
      "name": "test_marbles_help_lists_delete_control_subcommand"
    },
    {
      "authority": "repo_verified",
      "export_type": "named",
      "file": "tests/tui/test_vibecrafted_launcher.py",
      "kind": "def",
      "line": 647,
      "name": "test_repo_launcher_is_directly_executable"
    },
    {
      "authority": "repo_verified",
      "export_type": "named",
      "file": "tests/tui/test_vibecrafted_launcher.py",
      "kind": "def",
      "line": 1387,
      "name": "test_resume_subcommand_forwards_session_and_prompt_to_agent"
    },
    {
      "authority": "repo_verified",
      "export_type": "named",
      "file": "tests/tui/test_vibecrafted_launcher.py",
      "kind": "def",
      "line": 1425,
      "name": "test_resume_wrapper_symlink_forwards_session_and_prompt_to_agent"
    },
    {
      "authority": "repo_verified",
      "export_type": "named",
      "file": "tests/tui/test_vibecrafted_launcher.py",
      "kind": "def",
      "line": 1065,
      "name": "test_review_and_followup_help_separate_bounded_review_from_direction_audit"
    },
    {
      "authority": "repo_verified",
      "export_type": "named",
      "file": "tests/tui/test_vibecrafted_launcher.py",
      "kind": "def",
      "line": 1736,
      "name": "test_run_helper_blocks_self_looping_path_resolution"
    },
    {
      "authority": "repo_verified",
      "export_type": "named",
      "file": "tests/tui/test_vibecrafted_launcher.py",
      "kind": "def",
      "line": 1116,
      "name": "test_skill_wrapper_help_is_human_readable_without_agent"
    },
    {
      "authority": "repo_verified",
      "export_type": "named",
      "file": "tests/tui/test_vibecrafted_launcher.py",
      "kind": "def",
      "line": 1353,
      "name": "test_start_subcommand_launches_operator_entrypoint_layout"
    },
    {
      "authority": "repo_verified",
      "export_type": "named",
      "file": "tests/tui/test_vibecrafted_launcher.py",
      "kind": "def",
      "line": 983,
      "name": "test_status_empty_state_is_explicit_when_artifact_dirs_exist"
    },
    {
      "authority": "repo_verified",
      "export_type": "named",
      "file": "tests/tui/test_vibecrafted_launcher.py",
      "kind": "def",
      "line": 489,
      "name": "test_telemetry_wrapper_clears_ambient_marbles_context"
    },
    {
      "authority": "repo_verified",
      "export_type": "named",
      "file": "tests/tui/test_vibecrafted_launcher.py",
      "kind": "def",
      "line": 432,
      "name": "test_telemetry_wrapper_smokes_headless_marbles_runtime"
    },
    {
      "authority": "repo_verified",
      "export_type": "named",
      "file": "tests/tui/test_vibecrafted_launcher.py",
      "kind": "def",
      "line": 894,
      "name": "test_tui_uses_vc_operator_from_path_when_local_build_missing"
    },
    {
      "authority": "repo_verified",
      "export_type": "named",
      "file": "tests/tui/test_vibecrafted_launcher.py",
      "kind": "def",
      "line": 730,
      "name": "test_update_web_fallback_aborts_on_install_sh_sha256_mismatch"
    },
    {
      "authority": "repo_verified",
      "export_type": "named",
      "file": "tests/tui/test_vibecrafted_launcher.py",
      "kind": "def",
      "line": 666,
      "name": "test_update_web_fallback_verifies_install_sh_against_sha256sums"
    },
    {
      "authority": "repo_verified",
      "export_type": "named",
      "file": "tests/tui/test_vibecrafted_launcher.py",
      "kind": "def",
      "line": 1464,
      "name": "test_vc_dashboard_wrapper_dispatches_to_dashboard"
    },
    {
      "authority": "repo_verified",
      "export_type": "named",
      "file": "tests/tui/test_vibecrafted_launcher.py",
      "kind": "def",
      "line": 415,
      "name": "test_vc_help_wrapper_forwards_topic_help"
    },
    {
      "authority": "repo_verified",
      "export_type": "named",
      "file": "tests/tui/test_vibecrafted_launcher.py",
      "kind": "def",
      "line": 395,
      "name": "test_vc_help_wrapper_symlink_renders_main_help"
    }
  ]
}
```

## What this card does not cover

This Structural Map does not include runtime behavior, env contracts, or verification gates. Read `02-runtime-map.md` and `04-verification-gates.md` before changing behavior.
