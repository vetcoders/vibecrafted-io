# Risk Register

Project: `/Users/polyversai/Libraxis/vc-runtime/vibecrafted`
Snapshot: `release/v2.0.0@659756e`

This card collects risk signals and recommended actions for the current context scope.

```json
{
  "action": {
    "likely_tests": [
      "tests/agent_dispatch_test.py",
      "tests/aicx_sync_smoke.sh",
      "tests/conftest.py",
      "tests/fixtures/corrupt_skill/SKILL.md",
      "tests/hammerspoon_smoke.sh",
      "tests/install_smoke.sh",
      "tests/iterm2_migration_test.sh",
      "tests/memex_integration_test.sh",
      "tests/portable/run.sh",
      "tests/race_protection_test.sh",
      "tests/skill_loader_smoke.sh",
      "tests/spawn_parity_test.sh",
      "tests/tui/test_atuin_fallback.py",
      "tests/tui/test_await_observe_contract.py",
      "tests/tui/test_bundle.py",
      "tests/tui/test_codex_stream_bridge.py",
      "tests/tui/test_control_plane_state.py",
      "tests/tui/test_docs_links.py",
      "tests/tui/test_frontier_env_pinning.py",
      "tests/tui/test_frontier_resolution.py",
      "tests/tui/test_install_bootstrap.py",
      "tests/tui/test_installer_branding.py",
      "tests/tui/test_installer_doctor.py",
      "tests/tui/test_installer_gui.py",
      "tests/tui/test_installer_manifest.py",
      "tests/tui/test_installer_uninstall.py",
      "tests/tui/test_keys.py",
      "tests/tui/test_launcher_surface.py",
      "tests/tui/test_makefile_installer_contract.py",
      "tests/tui/test_marbles_ctl.py",
      "tests/tui/test_marbles_env.py",
      "tests/tui/test_marbles_probe.py",
      "tests/tui/test_marbles_runtime.py",
      "tests/tui/test_menu.py",
      "tests/tui/test_operator_mode.py",
      "tests/tui/test_portable_env_fallbacks.py",
      "tests/tui/test_release_contract.py",
      "tests/tui/test_research_launcher.py",
      "tests/tui/test_runtime_helpers.py",
      "tests/tui/test_security_helpers.py",
      "tests/tui/test_shell_check.py",
      "tests/tui/test_skill_contracts.py",
      "tests/tui/test_skills_sync.py",
      "tests/tui/test_spawn_common.py",
      "tests/tui/test_staged_tools_sync.py",
      "tests/tui/test_uv_bootstrap.py",
      "tests/tui/test_vibecrafted_launcher.py",
      "tests/tui/test_workflow_telemetry.py",
      "tests/tui/test_zellij_config.py",
      "tests/zellij_layouts_smoke.sh",
      "vibecrafted-core/tests/__init__.py",
      "vibecrafted-core/tests/conftest.py",
      "vibecrafted-core/tests/test_aicx_sync.py",
      "vibecrafted-core/tests/test_control_plane.py",
      "vibecrafted-core/tests/test_doctor.py",
      "vibecrafted-core/tests/test_git.py",
      "vibecrafted-core/tests/test_iterm2_osc.py",
      "vibecrafted-core/tests/test_iterm2_profiles.py",
      "vibecrafted-core/tests/test_memex_client.py",
      "vibecrafted-core/tests/test_workflow.py",
      "vibecrafted-mcp/tests/__init__.py",
      "vibecrafted-mcp/tests/conftest.py",
      "vibecrafted-mcp/tests/test_server.py"
    ],
    "next_safe_commands": [
      "loct slice vibecrafted-core/vibecrafted_core/__init__.py",
      "loct impact vibecrafted-core/vibecrafted_core/__init__.py",
      "loct context --file vibecrafted-core/vibecrafted_core/__init__.py"
    ],
    "verification_gates": [
      "make test",
      "make check",
      "mypy .",
      "python -m pytest"
    ]
  },
  "authority": {
    "aicx_agent": [],
    "aicx_failure": [],
    "aicx_operator": [],
    "loctree_derived": [
      "risk.hotspots.vibecrafted-core/vibecrafted_core/__init__.py",
      "risk.hotspots.vibecrafted-core/vibecrafted_core/runtime_paths.py",
      "risk.hotspots.scripts/runtime_paths.py",
      "risk.hotspots.vibecrafted-core/vibecrafted_core/control_plane.py",
      "risk.hotspots.scripts/installer_brand.py",
      "risk.high_fan_in.vibecrafted-core/vibecrafted_core/__init__.py",
      "action.likely_tests.tests/agent_dispatch_test.py",
      "action.likely_tests.tests/aicx_sync_smoke.sh",
      "action.likely_tests.tests/conftest.py",
      "action.likely_tests.tests/fixtures/corrupt_skill/SKILL.md",
      "action.likely_tests.tests/hammerspoon_smoke.sh",
      "action.likely_tests.tests/install_smoke.sh",
      "action.likely_tests.tests/iterm2_migration_test.sh",
      "action.likely_tests.tests/memex_integration_test.sh",
      "action.likely_tests.tests/portable/run.sh",
      "action.likely_tests.tests/race_protection_test.sh",
      "action.likely_tests.tests/skill_loader_smoke.sh",
      "action.likely_tests.tests/spawn_parity_test.sh",
      "action.likely_tests.tests/tui/test_atuin_fallback.py",
      "action.likely_tests.tests/tui/test_await_observe_contract.py",
      "action.likely_tests.tests/tui/test_bundle.py",
      "action.likely_tests.tests/tui/test_codex_stream_bridge.py",
      "action.likely_tests.tests/tui/test_control_plane_state.py",
      "action.likely_tests.tests/tui/test_docs_links.py",
      "action.likely_tests.tests/tui/test_frontier_env_pinning.py",
      "action.likely_tests.tests/tui/test_frontier_resolution.py",
      "action.likely_tests.tests/tui/test_install_bootstrap.py",
      "action.likely_tests.tests/tui/test_installer_branding.py",
      "action.likely_tests.tests/tui/test_installer_doctor.py",
      "action.likely_tests.tests/tui/test_installer_gui.py",
      "action.likely_tests.tests/tui/test_installer_manifest.py",
      "action.likely_tests.tests/tui/test_installer_uninstall.py",
      "action.likely_tests.tests/tui/test_keys.py",
      "action.likely_tests.tests/tui/test_launcher_surface.py",
      "action.likely_tests.tests/tui/test_makefile_installer_contract.py",
      "action.likely_tests.tests/tui/test_marbles_ctl.py",
      "action.likely_tests.tests/tui/test_marbles_env.py",
      "action.likely_tests.tests/tui/test_marbles_probe.py",
      "action.likely_tests.tests/tui/test_marbles_runtime.py",
      "action.likely_tests.tests/tui/test_menu.py",
      "action.likely_tests.tests/tui/test_operator_mode.py",
      "action.likely_tests.tests/tui/test_portable_env_fallbacks.py",
      "action.likely_tests.tests/tui/test_release_contract.py",
      "action.likely_tests.tests/tui/test_research_launcher.py",
      "action.likely_tests.tests/tui/test_runtime_helpers.py",
      "action.likely_tests.tests/tui/test_security_helpers.py",
      "action.likely_tests.tests/tui/test_shell_check.py",
      "action.likely_tests.tests/tui/test_skill_contracts.py",
      "action.likely_tests.tests/tui/test_skills_sync.py",
      "action.likely_tests.tests/tui/test_spawn_common.py",
      "action.likely_tests.tests/tui/test_staged_tools_sync.py",
      "action.likely_tests.tests/tui/test_uv_bootstrap.py",
      "action.likely_tests.tests/tui/test_vibecrafted_launcher.py",
      "action.likely_tests.tests/tui/test_workflow_telemetry.py",
      "action.likely_tests.tests/tui/test_zellij_config.py",
      "action.likely_tests.tests/zellij_layouts_smoke.sh",
      "action.likely_tests.vibecrafted-core/tests/__init__.py",
      "action.likely_tests.vibecrafted-core/tests/conftest.py",
      "action.likely_tests.vibecrafted-core/tests/test_aicx_sync.py",
      "action.likely_tests.vibecrafted-core/tests/test_control_plane.py",
      "action.likely_tests.vibecrafted-core/tests/test_doctor.py",
      "action.likely_tests.vibecrafted-core/tests/test_git.py",
      "action.likely_tests.vibecrafted-core/tests/test_iterm2_osc.py",
      "action.likely_tests.vibecrafted-core/tests/test_iterm2_profiles.py",
      "action.likely_tests.vibecrafted-core/tests/test_memex_client.py",
      "action.likely_tests.vibecrafted-core/tests/test_workflow.py",
      "action.likely_tests.vibecrafted-mcp/tests/__init__.py",
      "action.likely_tests.vibecrafted-mcp/tests/conftest.py",
      "action.likely_tests.vibecrafted-mcp/tests/test_server.py",
      "action.next_safe_commands.loct slice vibecrafted-core/vibecrafted_core/__init__.py",
      "action.next_safe_commands.loct impact vibecrafted-core/vibecrafted_core/__init__.py",
      "action.next_safe_commands.loct context --file vibecrafted-core/vibecrafted_core/__init__.py",
      "action.verification_gates.make test",
      "action.verification_gates.make check",
      "action.verification_gates.mypy .",
      "action.verification_gates.python -m pytest"
    ],
    "repo_verified": [
      "risk.cache_scope"
    ],
    "semantic_guess": [],
    "stale_or_unknown": []
  },
  "risk": {
    "cache_scope": "DirtyWorktree",
    "cache_scope_authority": "repo_verified",
    "dirty_worktree": true,
    "high_fan_in": [
      {
        "authority": "loctree_derived",
        "file": "vibecrafted-core/vibecrafted_core/__init__.py",
        "importers": 11,
        "threshold": 10
      }
    ],
    "hotspots": [
      {
        "authority": "loctree_derived",
        "file": "vibecrafted-core/vibecrafted_core/__init__.py",
        "importers": 11
      },
      {
        "authority": "loctree_derived",
        "file": "vibecrafted-core/vibecrafted_core/runtime_paths.py",
        "importers": 4
      },
      {
        "authority": "loctree_derived",
        "file": "scripts/runtime_paths.py",
        "importers": 3
      },
      {
        "authority": "loctree_derived",
        "file": "vibecrafted-core/vibecrafted_core/control_plane.py",
        "importers": 3
      },
      {
        "authority": "loctree_derived",
        "file": "scripts/installer_brand.py",
        "importers": 2
      }
    ],
    "snapshot_health": "dirty",
    "stale_snapshot": false
  }
}
```

## What this card does not cover

This Risk Register does not include full source content. Use `loct slice`/`loct impact` for exact file-level surgery.
