# Runtime Map

Project: `/Users/polyversai/Libraxis/vc-runtime/vibecrafted`
Snapshot: `release/v2.0.0@659756e`

This card contains runtime signals derived from semantic facts and framework bridges.

```json
{
  "dispatch_edges": [],
  "env_contracts": [],
  "framework_hints": [],
  "idiom_tags": [],
  "reachability": [],
  "tauri_commands": [],
  "tauri_events": []
}
```

## What this card does not cover

This Runtime Map does not include prior decisions or full risk history. Read `03-memory-trail.md` when continuing work and `05-risk-register.md` before release decisions.
