# Runtime Map

Project: `/Users/polyversai/Libraxis/vc-runtime/vibecrafted`
Snapshot: `release/v2.0.0@659756e`

This card contains runtime signals derived from semantic facts and framework bridges.

```json
{
  "dispatch_edges": [
    {
      "authority": "loctree_derived",
      "dispatch_kind": "recipe_shell_call",
      "from_file": "Makefile",
      "from_line": 17,
      "handler_file": null,
      "handler_symbol": "173m⚒"
    },
    {
      "authority": "loctree_derived",
      "dispatch_kind": "recipe_shell_call",
      "from_file": "Makefile",
      "from_line": 17,
      "handler_file": null,
      "handler_symbol": "5"
    },
    {
      "authority": "loctree_derived",
      "dispatch_kind": "recipe_shell_call",
      "from_file": "Makefile",
      "from_line": 138,
      "handler_file": null,
      "handler_symbol": "bash"
    },
    {
      "authority": "loctree_derived",
      "dispatch_kind": "recipe_shell_call",
      "from_file": "Makefile",
      "from_line": 93,
      "handler_file": null,
      "handler_symbol": "break"
    },
    {
      "authority": "loctree_derived",
      "dispatch_kind": "recipe_shell_call",
      "from_file": "Makefile",
      "from_line": 277,
      "handler_file": null,
      "handler_symbol": "chmod"
    },
    {
      "authority": "loctree_derived",
      "dispatch_kind": "recipe_shell_call",
      "from_file": "Makefile",
      "from_line": 277,
      "handler_file": null,
      "handler_symbol": "command"
    },
    {
      "authority": "loctree_derived",
      "dispatch_kind": "recipe_shell_call",
      "from_file": "Makefile",
      "from_line": 78,
      "handler_file": null,
      "handler_symbol": "curl"
    },
    {
      "authority": "loctree_derived",
      "dispatch_kind": "recipe_shell_call",
      "from_file": "Makefile",
      "from_line": 78,
      "handler_file": null,
      "handler_symbol": "echo"
    },
    {
      "authority": "loctree_derived",
      "dispatch_kind": "recipe_shell_call",
      "from_file": "Makefile",
      "from_line": 93,
      "handler_file": null,
      "handler_symbol": "exit"
    },
    {
      "authority": "loctree_derived",
      "dispatch_kind": "recipe_shell_call",
      "from_file": "Makefile",
      "from_line": 78,
      "handler_file": null,
      "handler_symbol": "export"
    },
    {
      "authority": "loctree_derived",
      "dispatch_kind": "recipe_shell_call",
      "from_file": "Makefile",
      "from_line": 224,
      "handler_file": null,
      "handler_symbol": "git"
    },
    {
      "authority": "loctree_derived",
      "dispatch_kind": "recipe_shell_call",
      "from_file": "Makefile",
      "from_line": 52,
      "handler_file": null,
      "handler_symbol": "major"
    },
    {
      "authority": "loctree_derived",
      "dispatch_kind": "recipe_shell_call",
      "from_file": "Makefile",
      "from_line": 52,
      "handler_file": null,
      "handler_symbol": "minor"
    },
    {
      "authority": "loctree_derived",
      "dispatch_kind": "recipe_shell_call",
      "from_file": "Makefile",
      "from_line": 277,
      "handler_file": null,
      "handler_symbol": "npx"
    },
    {
      "authority": "loctree_derived",
      "dispatch_kind": "recipe_shell_call",
      "from_file": "Makefile",
      "from_line": 93,
      "handler_file": null,
      "handler_symbol": "pnpm"
    },
    {
      "authority": "loctree_derived",
      "dispatch_kind": "recipe_shell_call",
      "from_file": "Makefile",
      "from_line": 16,
      "handler_file": null,
      "handler_symbol": "printf"
    },
    {
      "authority": "loctree_derived",
      "dispatch_kind": "recipe_shell_call",
      "from_file": "Makefile",
      "from_line": 201,
      "handler_file": null,
      "handler_symbol": "semgrep"
    },
    {
      "authority": "loctree_derived",
      "dispatch_kind": "recipe_shell_call",
      "from_file": "Makefile",
      "from_line": 78,
      "handler_file": null,
      "handler_symbol": "sh"
    },
    {
      "authority": "loctree_derived",
      "dispatch_kind": "recipe_shell_call",
      "from_file": "Makefile",
      "from_line": 174,
      "handler_file": null,
      "handler_symbol": "tr"
    },
    {
      "authority": "loctree_derived",
      "dispatch_kind": "recipe_shell_call",
      "from_file": "Makefile",
      "from_line": 162,
      "handler_file": null,
      "handler_symbol": "trap"
    },
    {
      "authority": "loctree_derived",
      "dispatch_kind": "recipe_shell_call",
      "from_file": "Makefile",
      "from_line": 78,
      "handler_file": null,
      "handler_symbol": "uv"
    },
    {
      "authority": "loctree_derived",
      "dispatch_kind": "recipe_shell_call",
      "from_file": "Makefile",
      "from_line": 201,
      "handler_file": null,
      "handler_symbol": "uvx"
    },
    {
      "authority": "loctree_derived",
      "dispatch_kind": "recipe_shell_call",
      "from_file": "Makefile",
      "from_line": 52,
      "handler_file": null,
      "handler_symbol": "x.y.z}\\033[0m\\n"
    }
  ],
  "env_contracts": [
    {
      "authority": "loctree_derived",
      "name": "BASH_SOURCE",
      "required_for": [],
      "used_in_files": [
        "scripts/aicx-sync.sh",
        "scripts/check-portable.sh",
        "scripts/install-foundations.sh",
        "scripts/install-hammerspoon.sh",
        "scripts/vibecrafted",
        "skills/vc-agents/scripts/await.sh",
        "skills/vc-agents/scripts/claude_spawn.sh",
        "skills/vc-agents/scripts/codex_spawn.sh",
        "skills/vc-agents/scripts/common.sh",
        "skills/vc-agents/scripts/gemini_spawn.sh",
        "skills/vc-agents/scripts/install-frontier-config.sh",
        "skills/vc-agents/scripts/install-shell.sh",
        "skills/vc-agents/scripts/install.sh",
        "skills/vc-agents/scripts/lib/frontier.sh",
        "skills/vc-agents/scripts/lib/util.sh",
        "skills/vc-agents/scripts/marbles_ctl.sh",
        "skills/vc-agents/scripts/marbles_next.sh",
        "skills/vc-agents/scripts/marbles_plan.sh",
        "skills/vc-agents/scripts/marbles_spawn.sh",
        "skills/vc-agents/scripts/marbles_watcher.sh",
        "skills/vc-agents/scripts/mission-control/active-agents.sh",
        "skills/vc-agents/scripts/mission-control/convergence-trend.sh",
        "skills/vc-agents/scripts/mission-control/live-transcript.sh",
        "skills/vc-agents/scripts/mission-control/operator-console.sh",
        "skills/vc-agents/scripts/mission-control/recent-sessions.sh",
        "skills/vc-agents/scripts/observe.sh",
        "skills/vc-agents/scripts/skills_sync.sh",
        "skills/vc-agents/shell/vetcoders.sh",
        "skills/vc-workflow/scripts/pipeline-init.sh",
        "templates/hooks/hooks/commit-msg",
        "templates/hooks/hooks/post-commit",
        "templates/hooks/hooks/pre-commit",
        "templates/hooks/hooks/pre-merge-commit",
        "templates/hooks/hooks/pre-push",
        "templates/hooks/hooks/prepare-commit-msg",
        "templates/hooks/install.sh",
        "tests/aicx_sync_smoke.sh",
        "tests/hammerspoon_smoke.sh",
        "tests/install_smoke.sh",
        "tests/iterm2_migration_test.sh",
        "tests/memex_integration_test.sh",
        "tests/portable/run.sh",
        "tests/race_protection_test.sh",
        "tests/skill_loader_smoke.sh",
        "tests/spawn_parity_test.sh",
        "tests/zellij_layouts_smoke.sh",
        "tools/vc-skill-new.sh"
      ]
    },
    {
      "authority": "loctree_derived",
      "name": "BRANCH",
      "required_for": [
        "Makefile variable assignment"
      ],
      "used_in_files": [
        "Makefile"
      ]
    },
    {
      "authority": "loctree_derived",
      "name": "BUNDLE_DIR",
      "required_for": [
        "Makefile variable assignment"
      ],
      "used_in_files": [
        "Makefile"
      ]
    },
    {
      "authority": "loctree_derived",
      "name": "CAPTURE_FILE",
      "required_for": [],
      "used_in_files": [
        "tests/tui/test_atuin_fallback.py",
        "tests/tui/test_operator_mode.py",
        "tests/tui/test_vibecrafted_launcher.py"
      ]
    },
    {
      "authority": "loctree_derived",
      "name": "CURL_CAPTURE_FILE",
      "required_for": [],
      "used_in_files": [
        "tests/tui/test_vibecrafted_launcher.py"
      ]
    },
    {
      "authority": "loctree_derived",
      "name": "FAKE_CURL_ROUTES",
      "required_for": [],
      "used_in_files": [
        "tests/tui/test_vibecrafted_launcher.py"
      ]
    },
    {
      "authority": "loctree_derived",
      "name": "FAKE_ZELLIJ_LISTING",
      "required_for": [],
      "used_in_files": [
        "tests/tui/test_vibecrafted_launcher.py"
      ]
    },
    {
      "authority": "loctree_derived",
      "name": "FAKE_ZELLIJ_SESSION",
      "required_for": [],
      "used_in_files": [
        "tests/tui/test_operator_mode.py",
        "tests/tui/test_vibecrafted_launcher.py"
      ]
    },
    {
      "authority": "loctree_derived",
      "name": "GUI_INSTALLER",
      "required_for": [
        "Makefile variable assignment"
      ],
      "used_in_files": [
        "Makefile"
      ]
    },
    {
      "authority": "loctree_derived",
      "name": "HOME",
      "required_for": [],
      "used_in_files": [
        "config/zellij/aicx-status.sh",
        "config/zellij/loctree-drift.sh",
        "install.sh",
        "runtime/helpers/vetcoders-runtime-core.sh",
        "scripts/aicx-sync.sh",
        "scripts/install-foundations.sh",
        "scripts/install-hammerspoon.sh",
        "scripts/migrate_agents_workspace.sh",
        "scripts/vibecrafted",
        "skills/vc-agents/scripts/gemini_spawn.sh",
        "skills/vc-agents/scripts/install-frontier-config.sh",
        "skills/vc-agents/scripts/install-shell.sh",
        "skills/vc-agents/scripts/lib/frontier.sh",
        "skills/vc-agents/scripts/lib/meta.sh",
        "skills/vc-agents/scripts/lib/paths.sh",
        "skills/vc-agents/scripts/lib/session.sh",
        "skills/vc-agents/scripts/lib/util.sh",
        "skills/vc-agents/scripts/marbles_ctl.sh",
        "skills/vc-agents/scripts/marbles_spawn.sh",
        "skills/vc-agents/scripts/mission-control/common.sh",
        "skills/vc-agents/scripts/skills_sync.sh",
        "skills/vc-agents/scripts/vibecrafted-await-watch.sh",
        "skills/vc-agents/shell/vetcoders.sh",
        "tests/portable/run.sh",
        "tests/skill_loader_smoke.sh",
        "tools/hooks/loct-edit-warning.sh",
        "tests/tui/test_atuin_fallback.py"
      ]
    },
    {
      "authority": "loctree_derived",
      "name": "INSTALLER",
      "required_for": [
        "Makefile variable assignment"
      ],
      "used_in_files": [
        "Makefile"
      ]
    },
    {
      "authority": "loctree_derived",
      "name": "INSTALLER_DIR",
      "required_for": [
        "Makefile variable assignment"
      ],
      "used_in_files": [
        "Makefile"
      ]
    },
    {
      "authority": "loctree_derived",
      "name": "MANIFEST",
      "required_for": [
        "Makefile variable assignment"
      ],
      "used_in_files": [
        "Makefile"
      ]
    },
    {
      "authority": "loctree_derived",
      "name": "PATH",
      "required_for": [],
      "used_in_files": [
        "docker/entrypoint.sh",
        "install.sh",
        "scripts/install-foundations.sh",
        "skills/vc-agents/shell/vetcoders.sh",
        "tests/portable/run.sh",
        "tools/hooks/loct-edit-warning.sh",
        "tests/tui/test_runtime_helpers.py",
        "tests/tui/test_spawn_common.py"
      ]
    },
    {
      "authority": "loctree_derived",
      "name": "PYTHON",
      "required_for": [
        "Makefile variable assignment"
      ],
      "used_in_files": [
        "Makefile"
      ]
    },
    {
      "authority": "loctree_derived",
      "name": "SESSION_STATE_FILE",
      "required_for": [],
      "used_in_files": [
        "tests/tui/test_operator_mode.py",
        "tests/tui/test_vibecrafted_launcher.py"
      ]
    },
    {
      "authority": "loctree_derived",
      "name": "SHELL_INSTALLER",
      "required_for": [
        "Makefile variable assignment"
      ],
      "used_in_files": [
        "Makefile"
      ]
    },
    {
      "authority": "loctree_derived",
      "name": "SOURCE",
      "required_for": [
        "Makefile variable assignment"
      ],
      "used_in_files": [
        "Makefile"
      ]
    },
    {
      "authority": "loctree_derived",
      "name": "TERM_PROGRAM",
      "required_for": [],
      "used_in_files": [
        "skills/vc-agents/scripts/lib/launcher_terminal.sh",
        "skills/vc-agents/shell/vetcoders.sh"
      ]
    },
    {
      "authority": "loctree_derived",
      "name": "VERSION_FILE",
      "required_for": [
        "Makefile variable assignment"
      ],
      "used_in_files": [
        "Makefile"
      ]
    },
    {
      "authority": "loctree_derived",
      "name": "VETCODERS_SPAWN_RUNTIME",
      "required_for": [],
      "used_in_files": [
        "skills/vc-agents/shell/vetcoders.sh"
      ]
    },
    {
      "authority": "loctree_derived",
      "name": "VIBECRAFTED_ATUIN_BIN",
      "required_for": [],
      "used_in_files": [
        "skills/vc-agents/shell/vetcoders.sh"
      ]
    },
    {
      "authority": "loctree_derived",
      "name": "VIBECRAFTED_HOME",
      "required_for": [],
      "used_in_files": [
        "docker/entrypoint.sh",
        "install.sh",
        "runtime/helpers/vetcoders-runtime-core.sh",
        "scripts/install-foundations.sh",
        "scripts/migrate_agents_workspace.sh",
        "scripts/vibecrafted",
        "skills/vc-agents/scripts/gemini_spawn.sh",
        "skills/vc-agents/scripts/lib/frontier.sh",
        "skills/vc-agents/scripts/lib/lock.sh",
        "skills/vc-agents/scripts/lib/paths.sh",
        "skills/vc-agents/scripts/lib/session.sh",
        "skills/vc-agents/scripts/lib/util.sh",
        "skills/vc-agents/scripts/marbles_ctl.sh",
        "skills/vc-agents/scripts/marbles_spawn.sh",
        "skills/vc-agents/scripts/mission-control/common.sh",
        "skills/vc-agents/scripts/vibecrafted-await-watch.sh",
        "skills/vc-agents/shell/vetcoders.sh",
        "vibecrafted-core/vibecrafted_core/runtime_paths.py",
        "vibecrafted-mcp/tests/test_server.py",
        "vibecrafted-mcp/vibecrafted_mcp/server.py"
      ]
    },
    {
      "authority": "loctree_derived",
      "name": "VIBECRAFTED_OSASCRIPT_BIN",
      "required_for": [],
      "used_in_files": [
        "skills/vc-agents/scripts/lib/launcher_terminal.sh",
        "skills/vc-agents/shell/vetcoders.sh"
      ]
    },
    {
      "authority": "loctree_derived",
      "name": "VIBECRAFTED_ROOT",
      "required_for": [],
      "used_in_files": [
        "docker/entrypoint.sh",
        "runtime/helpers/vetcoders-runtime-core.sh",
        "scripts/install-foundations.sh",
        "scripts/migrate_agents_workspace.sh",
        "scripts/vibecrafted",
        "skills/vc-agents/scripts/await.sh",
        "skills/vc-agents/scripts/lib/frontier.sh",
        "skills/vc-agents/scripts/lib/meta.sh",
        "skills/vc-agents/scripts/lib/util.sh",
        "skills/vc-agents/shell/vetcoders.sh",
        "tests/portable/run.sh",
        "scripts/installer/vetcoders_installer/__init__.py"
      ]
    },
    {
      "authority": "loctree_derived",
      "name": "VIBECRAFTED_TERMINAL",
      "required_for": [],
      "used_in_files": [
        "skills/vc-agents/scripts/lib/launcher_terminal.sh",
        "skills/vc-agents/shell/vetcoders.sh"
      ]
    },
    {
      "authority": "loctree_derived",
      "name": "ZELLIJ",
      "required_for": [],
      "used_in_files": [
        "scripts/vibecrafted",
        "skills/vc-agents/scripts/lib/zellij.sh",
        "skills/vc-agents/shell/vetcoders.sh"
      ]
    },
    {
      "authority": "loctree_derived",
      "name": "ZELLIJ_PANE_ID",
      "required_for": [],
      "used_in_files": [
        "skills/vc-agents/scripts/lib/zellij.sh",
        "skills/vc-agents/shell/vetcoders.sh"
      ]
    },
    {
      "authority": "loctree_derived",
      "name": "ZELLIJ_SESSION_NAME",
      "required_for": [],
      "used_in_files": [
        "skills/vc-agents/scripts/lib/zellij.sh",
        "skills/vc-agents/shell/vetcoders.sh"
      ]
    },
    {
      "authority": "loctree_derived",
      "name": "_VETCODERS_ATUIN_BIN",
      "required_for": [],
      "used_in_files": [
        "skills/vc-agents/shell/vetcoders.sh"
      ]
    }
  ],
  "framework_hints": [],
  "idiom_tags": [
    {
      "authority": "loctree_derived",
      "classifier": "metadata",
      "name": ".PHONY",
      "reasoning": "GNU Make directive marking targets that are not files; targets listed after .PHONY are public entrypoints.",
      "runtime_role": "metadata",
      "source": "embedded_default",
      "symbol": "Makefile::.PHONY"
    },
    {
      "authority": "semantic_guess",
      "classifier": "public_entrypoint",
      "name": ".PHONY",
      "reasoning": "Target 'bump-major' is listed in a .PHONY directive; operator-invoked make target.",
      "runtime_role": "public_entrypoint",
      "source": "inferred_from_code",
      "symbol": "Makefile::bump-major"
    },
    {
      "authority": "semantic_guess",
      "classifier": "public_entrypoint",
      "name": ".PHONY",
      "reasoning": "Target 'bump-minor' is listed in a .PHONY directive; operator-invoked make target.",
      "runtime_role": "public_entrypoint",
      "source": "inferred_from_code",
      "symbol": "Makefile::bump-minor"
    },
    {
      "authority": "semantic_guess",
      "classifier": "public_entrypoint",
      "name": ".PHONY",
      "reasoning": "Target 'bump-patch' is listed in a .PHONY directive; operator-invoked make target.",
      "runtime_role": "public_entrypoint",
      "source": "inferred_from_code",
      "symbol": "Makefile::bump-patch"
    },
    {
      "authority": "semantic_guess",
      "classifier": "public_entrypoint",
      "name": ".PHONY",
      "reasoning": "Target 'bundle' is listed in a .PHONY directive; operator-invoked make target.",
      "runtime_role": "public_entrypoint",
      "source": "inferred_from_code",
      "symbol": "Makefile::bundle"
    },
    {
      "authority": "semantic_guess",
      "classifier": "public_entrypoint",
      "name": ".PHONY",
      "reasoning": "Target 'bundle-check' is listed in a .PHONY directive; operator-invoked make target.",
      "runtime_role": "public_entrypoint",
      "source": "inferred_from_code",
      "symbol": "Makefile::bundle-check"
    },
    {
      "authority": "semantic_guess",
      "classifier": "public_entrypoint",
      "name": ".PHONY",
      "reasoning": "Target 'check' is listed in a .PHONY directive; operator-invoked make target.",
      "runtime_role": "public_entrypoint",
      "source": "inferred_from_code",
      "symbol": "Makefile::check"
    },
    {
      "authority": "semantic_guess",
      "classifier": "public_entrypoint",
      "name": ".PHONY",
      "reasoning": "Target 'commit-safe' is listed in a .PHONY directive; operator-invoked make target.",
      "runtime_role": "public_entrypoint",
      "source": "inferred_from_code",
      "symbol": "Makefile::commit-safe"
    },
    {
      "authority": "semantic_guess",
      "classifier": "public_entrypoint",
      "name": ".PHONY",
      "reasoning": "Target 'demo' is listed in a .PHONY directive; operator-invoked make target.",
      "runtime_role": "public_entrypoint",
      "source": "inferred_from_code",
      "symbol": "Makefile::demo"
    },
    {
      "authority": "semantic_guess",
      "classifier": "public_entrypoint",
      "name": ".PHONY",
      "reasoning": "Target 'demo-full' is listed in a .PHONY directive; operator-invoked make target.",
      "runtime_role": "public_entrypoint",
      "source": "inferred_from_code",
      "symbol": "Makefile::demo-full"
    },
    {
      "authority": "semantic_guess",
      "classifier": "public_entrypoint",
      "name": ".PHONY",
      "reasoning": "Target 'doctor' is listed in a .PHONY directive; operator-invoked make target.",
      "runtime_role": "public_entrypoint",
      "source": "inferred_from_code",
      "symbol": "Makefile::doctor"
    },
    {
      "authority": "semantic_guess",
      "classifier": "public_entrypoint",
      "name": ".PHONY",
      "reasoning": "Target 'dry-run' is listed in a .PHONY directive; operator-invoked make target.",
      "runtime_role": "public_entrypoint",
      "source": "inferred_from_code",
      "symbol": "Makefile::dry-run"
    },
    {
      "authority": "semantic_guess",
      "classifier": "public_entrypoint",
      "name": ".PHONY",
      "reasoning": "Target 'foundations' is listed in a .PHONY directive; operator-invoked make target.",
      "runtime_role": "public_entrypoint",
      "source": "inferred_from_code",
      "symbol": "Makefile::foundations"
    },
    {
      "authority": "semantic_guess",
      "classifier": "public_entrypoint",
      "name": ".PHONY",
      "reasoning": "Target 'foundations-check' is listed in a .PHONY directive; operator-invoked make target.",
      "runtime_role": "public_entrypoint",
      "source": "inferred_from_code",
      "symbol": "Makefile::foundations-check"
    },
    {
      "authority": "semantic_guess",
      "classifier": "public_entrypoint",
      "name": ".PHONY",
      "reasoning": "Target 'gui-install' is listed in a .PHONY directive; operator-invoked make target.",
      "runtime_role": "public_entrypoint",
      "source": "inferred_from_code",
      "symbol": "Makefile::gui-install"
    },
    {
      "authority": "semantic_guess",
      "classifier": "public_entrypoint",
      "name": ".PHONY",
      "reasoning": "Target 'help' is listed in a .PHONY directive; operator-invoked make target.",
      "runtime_role": "public_entrypoint",
      "source": "inferred_from_code",
      "symbol": "Makefile::help"
    },
    {
      "authority": "semantic_guess",
      "classifier": "public_entrypoint",
      "name": ".PHONY",
      "reasoning": "Target 'helpers' is listed in a .PHONY directive; operator-invoked make target.",
      "runtime_role": "public_entrypoint",
      "source": "inferred_from_code",
      "symbol": "Makefile::helpers"
    },
    {
      "authority": "semantic_guess",
      "classifier": "public_entrypoint",
      "name": ".PHONY",
      "reasoning": "Target 'init-hooks' is listed in a .PHONY directive; operator-invoked make target.",
      "runtime_role": "public_entrypoint",
      "source": "inferred_from_code",
      "symbol": "Makefile::init-hooks"
    },
    {
      "authority": "semantic_guess",
      "classifier": "public_entrypoint",
      "name": ".PHONY",
      "reasoning": "Target 'install' is listed in a .PHONY directive; operator-invoked make target.",
      "runtime_role": "public_entrypoint",
      "source": "inferred_from_code",
      "symbol": "Makefile::install"
    },
    {
      "authority": "semantic_guess",
      "classifier": "public_entrypoint",
      "name": ".PHONY",
      "reasoning": "Target 'install-hammerspoon' is listed in a .PHONY directive; operator-invoked make target.",
      "runtime_role": "public_entrypoint",
      "source": "inferred_from_code",
      "symbol": "Makefile::install-hammerspoon"
    },
    {
      "authority": "semantic_guess",
      "classifier": "public_entrypoint",
      "name": ".PHONY",
      "reasoning": "Target 'iterm-plugin' is listed in a .PHONY directive; operator-invoked make target.",
      "runtime_role": "public_entrypoint",
      "source": "inferred_from_code",
      "symbol": "Makefile::iterm-plugin"
    },
    {
      "authority": "semantic_guess",
      "classifier": "public_entrypoint",
      "name": ".PHONY",
      "reasoning": "Target 'iterm-plugin-migrate' is listed in a .PHONY directive; operator-invoked make target.",
      "runtime_role": "public_entrypoint",
      "source": "inferred_from_code",
      "symbol": "Makefile::iterm-plugin-migrate"
    },
    {
      "authority": "semantic_guess",
      "classifier": "public_entrypoint",
      "name": ".PHONY",
      "reasoning": "Target 'iterm-plugin-refresh' is listed in a .PHONY directive; operator-invoked make target.",
      "runtime_role": "public_entrypoint",
      "source": "inferred_from_code",
      "symbol": "Makefile::iterm-plugin-refresh"
    },
    {
      "authority": "semantic_guess",
      "classifier": "public_entrypoint",
      "name": ".PHONY",
      "reasoning": "Target 'iterm-plugin-show' is listed in a .PHONY directive; operator-invoked make target.",
      "runtime_role": "public_entrypoint",
      "source": "inferred_from_code",
      "symbol": "Makefile::iterm-plugin-show"
    },
    {
      "authority": "semantic_guess",
      "classifier": "public_entrypoint",
      "name": ".PHONY",
      "reasoning": "Target 'iterm-plugin-uninstall' is listed in a .PHONY directive; operator-invoked make target.",
      "runtime_role": "public_entrypoint",
      "source": "inferred_from_code",
      "symbol": "Makefile::iterm-plugin-uninstall"
    },
    {
      "authority": "semantic_guess",
      "classifier": "public_entrypoint",
      "name": ".PHONY",
      "reasoning": "Target 'list' is listed in a .PHONY directive; operator-invoked make target.",
      "runtime_role": "public_entrypoint",
      "source": "inferred_from_code",
      "symbol": "Makefile::list"
    },
    {
      "authority": "semantic_guess",
      "classifier": "public_entrypoint",
      "name": ".PHONY",
      "reasoning": "Target 'migrate' is listed in a .PHONY directive; operator-invoked make target.",
      "runtime_role": "public_entrypoint",
      "source": "inferred_from_code",
      "symbol": "Makefile::migrate"
    },
    {
      "authority": "semantic_guess",
      "classifier": "public_entrypoint",
      "name": ".PHONY",
      "reasoning": "Target 'migrate-dry' is listed in a .PHONY directive; operator-invoked make target.",
      "runtime_role": "public_entrypoint",
      "source": "inferred_from_code",
      "symbol": "Makefile::migrate-dry"
    },
    {
      "authority": "semantic_guess",
      "classifier": "public_entrypoint",
      "name": ".PHONY",
      "reasoning": "Target 'restore' is listed in a .PHONY directive; operator-invoked make target.",
      "runtime_role": "public_entrypoint",
      "source": "inferred_from_code",
      "symbol": "Makefile::restore"
    },
    {
      "authority": "semantic_guess",
      "classifier": "public_entrypoint",
      "name": ".PHONY",
      "reasoning": "Target 'semgrep' is listed in a .PHONY directive; operator-invoked make target.",
      "runtime_role": "public_entrypoint",
      "source": "inferred_from_code",
      "symbol": "Makefile::semgrep"
    },
    {
      "authority": "semantic_guess",
      "classifier": "public_entrypoint",
      "name": ".PHONY",
      "reasoning": "Target 'setup-dev' is listed in a .PHONY directive; operator-invoked make target.",
      "runtime_role": "public_entrypoint",
      "source": "inferred_from_code",
      "symbol": "Makefile::setup-dev"
    },
    {
      "authority": "semantic_guess",
      "classifier": "public_entrypoint",
      "name": ".PHONY",
      "reasoning": "Target 'skill-new' is listed in a .PHONY directive; operator-invoked make target.",
      "runtime_role": "public_entrypoint",
      "source": "inferred_from_code",
      "symbol": "Makefile::skill-new"
    },
    {
      "authority": "semantic_guess",
      "classifier": "public_entrypoint",
      "name": ".PHONY",
      "reasoning": "Target 'skills' is listed in a .PHONY directive; operator-invoked make target.",
      "runtime_role": "public_entrypoint",
      "source": "inferred_from_code",
      "symbol": "Makefile::skills"
    },
    {
      "authority": "semantic_guess",
      "classifier": "public_entrypoint",
      "name": ".PHONY",
      "reasoning": "Target 'test' is listed in a .PHONY directive; operator-invoked make target.",
      "runtime_role": "public_entrypoint",
      "source": "inferred_from_code",
      "symbol": "Makefile::test"
    },
    {
      "authority": "semantic_guess",
      "classifier": "public_entrypoint",
      "name": ".PHONY",
      "reasoning": "Target 'test-aicx-sync' is listed in a .PHONY directive; operator-invoked make target.",
      "runtime_role": "public_entrypoint",
      "source": "inferred_from_code",
      "symbol": "Makefile::test-aicx-sync"
    },
    {
      "authority": "semantic_guess",
      "classifier": "public_entrypoint",
      "name": ".PHONY",
      "reasoning": "Target 'test-hammerspoon' is listed in a .PHONY directive; operator-invoked make target.",
      "runtime_role": "public_entrypoint",
      "source": "inferred_from_code",
      "symbol": "Makefile::test-hammerspoon"
    },
    {
      "authority": "semantic_guess",
      "classifier": "public_entrypoint",
      "name": ".PHONY",
      "reasoning": "Target 'test-install' is listed in a .PHONY directive; operator-invoked make target.",
      "runtime_role": "public_entrypoint",
      "source": "inferred_from_code",
      "symbol": "Makefile::test-install"
    },
    {
      "authority": "semantic_guess",
      "classifier": "public_entrypoint",
      "name": ".PHONY",
      "reasoning": "Target 'test-iterm2-migrate' is listed in a .PHONY directive; operator-invoked make target.",
      "runtime_role": "public_entrypoint",
      "source": "inferred_from_code",
      "symbol": "Makefile::test-iterm2-migrate"
    },
    {
      "authority": "semantic_guess",
      "classifier": "public_entrypoint",
      "name": ".PHONY",
      "reasoning": "Target 'test-memex' is listed in a .PHONY directive; operator-invoked make target.",
      "runtime_role": "public_entrypoint",
      "source": "inferred_from_code",
      "symbol": "Makefile::test-memex"
    },
    {
      "authority": "semantic_guess",
      "classifier": "public_entrypoint",
      "name": ".PHONY",
      "reasoning": "Target 'test-parity' is listed in a .PHONY directive; operator-invoked make target.",
      "runtime_role": "public_entrypoint",
      "source": "inferred_from_code",
      "symbol": "Makefile::test-parity"
    },
    {
      "authority": "semantic_guess",
      "classifier": "public_entrypoint",
      "name": ".PHONY",
      "reasoning": "Target 'test-race-protection' is listed in a .PHONY directive; operator-invoked make target.",
      "runtime_role": "public_entrypoint",
      "source": "inferred_from_code",
      "symbol": "Makefile::test-race-protection"
    },
    {
      "authority": "semantic_guess",
      "classifier": "public_entrypoint",
      "name": ".PHONY",
      "reasoning": "Target 'test-skills' is listed in a .PHONY directive; operator-invoked make target.",
      "runtime_role": "public_entrypoint",
      "source": "inferred_from_code",
      "symbol": "Makefile::test-skills"
    },
    {
      "authority": "semantic_guess",
      "classifier": "public_entrypoint",
      "name": ".PHONY",
      "reasoning": "Target 'test-zellij' is listed in a .PHONY directive; operator-invoked make target.",
      "runtime_role": "public_entrypoint",
      "source": "inferred_from_code",
      "symbol": "Makefile::test-zellij"
    },
    {
      "authority": "semantic_guess",
      "classifier": "public_entrypoint",
      "name": ".PHONY",
      "reasoning": "Target 'uninstall' is listed in a .PHONY directive; operator-invoked make target.",
      "runtime_role": "public_entrypoint",
      "source": "inferred_from_code",
      "symbol": "Makefile::uninstall"
    },
    {
      "authority": "semantic_guess",
      "classifier": "public_entrypoint",
      "name": ".PHONY",
      "reasoning": "Target 'update' is listed in a .PHONY directive; operator-invoked make target.",
      "runtime_role": "public_entrypoint",
      "source": "inferred_from_code",
      "symbol": "Makefile::update"
    },
    {
      "authority": "semantic_guess",
      "classifier": "public_entrypoint",
      "name": ".PHONY",
      "reasoning": "Target 'version-bump' is listed in a .PHONY directive; operator-invoked make target.",
      "runtime_role": "public_entrypoint",
      "source": "inferred_from_code",
      "symbol": "Makefile::version-bump"
    },
    {
      "authority": "semantic_guess",
      "classifier": "public_entrypoint",
      "name": ".PHONY",
      "reasoning": "Target 'vibecrafted' is listed in a .PHONY directive; operator-invoked make target.",
      "runtime_role": "public_entrypoint",
      "source": "inferred_from_code",
      "symbol": "Makefile::vibecrafted"
    },
    {
      "authority": "semantic_guess",
      "classifier": "public_entrypoint",
      "name": ".PHONY",
      "reasoning": "Target 'wizard' is listed in a .PHONY directive; operator-invoked make target.",
      "runtime_role": "public_entrypoint",
      "source": "inferred_from_code",
      "symbol": "Makefile::wizard"
    },
    {
      "authority": "semantic_guess",
      "classifier": "public_entrypoint",
      "name": ".PHONY",
      "reasoning": "Target 'wizard-dev' is listed in a .PHONY directive; operator-invoked make target.",
      "runtime_role": "public_entrypoint",
      "source": "inferred_from_code",
      "symbol": "Makefile::wizard-dev"
    }
  ],
  "reachability": [
    {
      "authority": "loctree_derived",
      "reached": true,
      "reason": "phony_make_target",
      "symbol": "Makefile::bump-major"
    },
    {
      "authority": "loctree_derived",
      "reached": true,
      "reason": "phony_make_target",
      "symbol": "Makefile::bump-minor"
    },
    {
      "authority": "loctree_derived",
      "reached": true,
      "reason": "phony_make_target",
      "symbol": "Makefile::bump-patch"
    },
    {
      "authority": "loctree_derived",
      "reached": true,
      "reason": "phony_make_target",
      "symbol": "Makefile::bundle"
    },
    {
      "authority": "loctree_derived",
      "reached": true,
      "reason": "phony_make_target",
      "symbol": "Makefile::bundle-check"
    },
    {
      "authority": "loctree_derived",
      "reached": true,
      "reason": "phony_make_target",
      "symbol": "Makefile::check"
    },
    {
      "authority": "loctree_derived",
      "reached": true,
      "reason": "phony_make_target",
      "symbol": "Makefile::commit-safe"
    },
    {
      "authority": "loctree_derived",
      "reached": true,
      "reason": "phony_make_target",
      "symbol": "Makefile::demo"
    },
    {
      "authority": "loctree_derived",
      "reached": true,
      "reason": "phony_make_target",
      "symbol": "Makefile::demo-full"
    },
    {
      "authority": "loctree_derived",
      "reached": true,
      "reason": "phony_make_target",
      "symbol": "Makefile::doctor"
    },
    {
      "authority": "loctree_derived",
      "reached": true,
      "reason": "phony_make_target",
      "symbol": "Makefile::dry-run"
    },
    {
      "authority": "loctree_derived",
      "reached": true,
      "reason": "phony_make_target",
      "symbol": "Makefile::foundations"
    },
    {
      "authority": "loctree_derived",
      "reached": true,
      "reason": "phony_make_target",
      "symbol": "Makefile::foundations-check"
    },
    {
      "authority": "loctree_derived",
      "reached": true,
      "reason": "phony_make_target",
      "symbol": "Makefile::gui-install"
    },
    {
      "authority": "loctree_derived",
      "reached": true,
      "reason": "phony_make_target",
      "symbol": "Makefile::help"
    },
    {
      "authority": "loctree_derived",
      "reached": true,
      "reason": "phony_make_target",
      "symbol": "Makefile::helpers"
    },
    {
      "authority": "loctree_derived",
      "reached": true,
      "reason": "phony_make_target",
      "symbol": "Makefile::init-hooks"
    },
    {
      "authority": "loctree_derived",
      "reached": true,
      "reason": "phony_make_target",
      "symbol": "Makefile::install"
    },
    {
      "authority": "loctree_derived",
      "reached": true,
      "reason": "phony_make_target",
      "symbol": "Makefile::install-hammerspoon"
    },
    {
      "authority": "loctree_derived",
      "reached": true,
      "reason": "phony_make_target",
      "symbol": "Makefile::iterm-plugin"
    },
    {
      "authority": "loctree_derived",
      "reached": true,
      "reason": "phony_make_target",
      "symbol": "Makefile::iterm-plugin-migrate"
    },
    {
      "authority": "loctree_derived",
      "reached": true,
      "reason": "phony_make_target",
      "symbol": "Makefile::iterm-plugin-refresh"
    },
    {
      "authority": "loctree_derived",
      "reached": true,
      "reason": "phony_make_target",
      "symbol": "Makefile::iterm-plugin-show"
    },
    {
      "authority": "loctree_derived",
      "reached": true,
      "reason": "phony_make_target",
      "symbol": "Makefile::iterm-plugin-uninstall"
    },
    {
      "authority": "loctree_derived",
      "reached": true,
      "reason": "phony_make_target",
      "symbol": "Makefile::list"
    },
    {
      "authority": "loctree_derived",
      "reached": true,
      "reason": "phony_make_target",
      "symbol": "Makefile::migrate"
    },
    {
      "authority": "loctree_derived",
      "reached": true,
      "reason": "phony_make_target",
      "symbol": "Makefile::migrate-dry"
    },
    {
      "authority": "loctree_derived",
      "reached": true,
      "reason": "phony_make_target",
      "symbol": "Makefile::restore"
    },
    {
      "authority": "loctree_derived",
      "reached": true,
      "reason": "phony_make_target",
      "symbol": "Makefile::semgrep"
    },
    {
      "authority": "loctree_derived",
      "reached": true,
      "reason": "phony_make_target",
      "symbol": "Makefile::setup-dev"
    },
    {
      "authority": "loctree_derived",
      "reached": true,
      "reason": "phony_make_target",
      "symbol": "Makefile::skill-new"
    },
    {
      "authority": "loctree_derived",
      "reached": true,
      "reason": "phony_make_target",
      "symbol": "Makefile::skills"
    },
    {
      "authority": "loctree_derived",
      "reached": true,
      "reason": "phony_make_target",
      "symbol": "Makefile::test"
    },
    {
      "authority": "loctree_derived",
      "reached": true,
      "reason": "phony_make_target",
      "symbol": "Makefile::test-aicx-sync"
    },
    {
      "authority": "loctree_derived",
      "reached": true,
      "reason": "phony_make_target",
      "symbol": "Makefile::test-hammerspoon"
    },
    {
      "authority": "loctree_derived",
      "reached": true,
      "reason": "phony_make_target",
      "symbol": "Makefile::test-install"
    },
    {
      "authority": "loctree_derived",
      "reached": true,
      "reason": "phony_make_target",
      "symbol": "Makefile::test-iterm2-migrate"
    },
    {
      "authority": "loctree_derived",
      "reached": true,
      "reason": "phony_make_target",
      "symbol": "Makefile::test-memex"
    },
    {
      "authority": "loctree_derived",
      "reached": true,
      "reason": "phony_make_target",
      "symbol": "Makefile::test-parity"
    },
    {
      "authority": "loctree_derived",
      "reached": true,
      "reason": "phony_make_target",
      "symbol": "Makefile::test-race-protection"
    },
    {
      "authority": "loctree_derived",
      "reached": true,
      "reason": "phony_make_target",
      "symbol": "Makefile::test-skills"
    },
    {
      "authority": "loctree_derived",
      "reached": true,
      "reason": "phony_make_target",
      "symbol": "Makefile::test-zellij"
    },
    {
      "authority": "loctree_derived",
      "reached": true,
      "reason": "phony_make_target",
      "symbol": "Makefile::uninstall"
    },
    {
      "authority": "loctree_derived",
      "reached": true,
      "reason": "phony_make_target",
      "symbol": "Makefile::update"
    },
    {
      "authority": "loctree_derived",
      "reached": true,
      "reason": "phony_make_target",
      "symbol": "Makefile::version-bump"
    },
    {
      "authority": "loctree_derived",
      "reached": true,
      "reason": "phony_make_target",
      "symbol": "Makefile::vibecrafted"
    },
    {
      "authority": "loctree_derived",
      "reached": true,
      "reason": "phony_make_target",
      "symbol": "Makefile::wizard"
    },
    {
      "authority": "loctree_derived",
      "reached": true,
      "reason": "phony_make_target",
      "symbol": "Makefile::wizard-dev"
    }
  ],
  "tauri_commands": [],
  "tauri_events": []
}
```

## What this card does not cover

This Runtime Map does not include prior decisions or full risk history. Read `03-memory-trail.md` when continuing work and `05-risk-register.md` before release decisions.
