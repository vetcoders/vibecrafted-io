# Verification Gates

Project: `/Users/polyversai/Libraxis/vc-runtime/vibecrafted`
Snapshot: `release/v2.0.0@659756e`

This card lists likely verification commands and tests derived from the current context.

```json
{
  "likely_tests": [
    "tests/tui/test_await_observe_contract.py",
    "tests/tui/test_operator_mode.py",
    "tests/tui/test_vibecrafted_launcher.py"
  ],
  "next_safe_commands": [
    "loct slice Makefile",
    "loct impact Makefile",
    "loct context --file Makefile",
    "loct slice skills/vc-agents/shell/vetcoders.sh",
    "loct impact skills/vc-agents/shell/vetcoders.sh",
    "loct context --file skills/vc-agents/shell/vetcoders.sh",
    "loct slice tests/tui/test_await_observe_contract.py",
    "loct impact tests/tui/test_await_observe_contract.py",
    "loct context --file tests/tui/test_await_observe_contract.py",
    "loct slice tests/tui/test_vibecrafted_launcher.py",
    "loct impact tests/tui/test_vibecrafted_launcher.py",
    "loct context --file tests/tui/test_vibecrafted_launcher.py",
    "loct slice tests/tui/test_operator_mode.py",
    "loct impact tests/tui/test_operator_mode.py",
    "loct context --file tests/tui/test_operator_mode.py"
  ],
  "risk": {
    "cache_scope": "DirtyWorktree",
    "cache_scope_authority": "repo_verified",
    "dirty_worktree": true,
    "high_fan_in": [],
    "hotspots": [],
    "snapshot_health": "dirty",
    "stale_snapshot": false
  }
}
```

## What this card does not cover

This Verification Gates card does not prove correctness by itself. Run the commands before release or submit.
