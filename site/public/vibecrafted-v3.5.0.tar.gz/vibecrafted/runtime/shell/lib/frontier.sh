# shellcheck shell=bash
# Extracted from vetcoders.sh; sourced only by the compatibility facade.

_vetcoders_frontier_candidates() {
  local repo_root crafted_sidecar candidate seen=""
  repo_root="$(_vetcoders_repo_root)"
  crafted_sidecar="${VIBECRAFTED_TOOLS_HOME:-${XDG_DATA_HOME:-$HOME/.local/share}/vibecrafted/tools}/vibecrafted-current/config"

  for candidate in \
    "${XDG_CONFIG_HOME:-$HOME/.config}/vetcoders/frontier" \
    "$crafted_sidecar" \
    "${VIBECRAFTED_ROOT:+$VIBECRAFTED_ROOT/config}" \
    "$repo_root/config"
  do
    [[ -n "$candidate" && -d "$candidate" ]] || continue
    case ":$seen:" in
      *":$candidate:"*) continue ;;
    esac
    seen="${seen:+$seen:}$candidate"
    printf '%s\n' "$candidate"
  done
}

_vetcoders_frontier_root() {
  local candidate
  while IFS= read -r candidate; do
    if [[ -f "$candidate/starship.toml" ]]; then
      printf '%s' "$candidate"
      return 0
    fi
  done < <(_vetcoders_frontier_candidates)

  echo "𝚅𝚒𝚋𝚎𝚌𝚛𝚊𝚏𝚝𝚎𝚍. frontier config not found. Run vc-frontier-install from the repo checkout." >&2
  return 1
}

# Resolve each frontier asset independently so repo-owned prompt/history presets
# can coexist with an external session companion repo.
_vetcoders_frontier_file() {
  local relative_path="$1"
  local candidate
  while IFS= read -r candidate; do
    if [[ -f "$candidate/$relative_path" ]]; then
      printf '%s/%s\n' "$candidate" "$relative_path"
      return 0
    fi
  done < <(_vetcoders_frontier_candidates)
  return 1
}

_vetcoders_frontier_source_root() {
  local repo_root crafted_root candidate seen=""
  repo_root="$(_vetcoders_repo_root)"
  crafted_root="${VIBECRAFTED_TOOLS_HOME:-${XDG_DATA_HOME:-$HOME/.local/share}/vibecrafted/tools}/vibecrafted-current"

  for candidate in \
    "${VIBECRAFTED_ROOT:-}" \
    "$repo_root" \
    "$crafted_root"
  do
    [[ -n "$candidate" ]] || continue
    case ":$seen:" in
      *":$candidate:"*) continue ;;
    esac
    seen="${seen:+$seen:}$candidate"
    if [[ -f "$candidate/config/starship.toml" ]]; then
      printf '%s\n' "$candidate"
      return 0
    fi
  done

  return 1
}

_vetcoders_vc_frame_config_dir() {
  local vc_frame_config
  vc_frame_config="$(_vetcoders_frontier_file "vc-frame/config.kdl" 2>/dev/null || true)"
  [[ -n "$vc_frame_config" ]] || return 1
  dirname "$vc_frame_config"
}

_vetcoders_pin_vc_frame_config_dir() {
  local config_dir
  config_dir="$(_vetcoders_vc_frame_config_dir 2>/dev/null || true)"
  [[ -n "$config_dir" ]] || return 0
  # Self-heal: keep an already-exported VC_FRAME_CONFIG_DIR only if it actually
  # resolves to a config.kdl. A stale value — e.g. a removed zellij-named sidecar
  # left by an earlier rebrand — is re-pointed at the resolved vc-frame dir, so
  # the frame loads the real config instead of falling back to a Ctrl-q=Quit default.
  if [[ -n "${VC_FRAME_CONFIG_DIR:-}" && -f "${VC_FRAME_CONFIG_DIR%/}/config.kdl" ]]; then
    return 0
  fi
  export VC_FRAME_CONFIG_DIR="$config_dir"
}

_vetcoders_load_frontier_sidecars() {
  local starship_config atuin_config
  local xdg_config_home="${XDG_CONFIG_HOME:-$HOME/.config}"
  starship_config="$(_vetcoders_frontier_file "starship.toml" 2>/dev/null || true)"
  atuin_config="$(_vetcoders_frontier_file "atuin/config.toml" 2>/dev/null || true)"

  # Frontier tools (starship, atuin, vc-frame) are suggested for the runtime,
  # not required. Never override a user's existing config — only set env vars
  # when the user has no config of their own. Users opt in explicitly.
  if command -v starship >/dev/null 2>&1 \
    && [[ -n "$starship_config" && -z "${STARSHIP_CONFIG:-}" ]] \
    && [[ ! -e "$xdg_config_home/starship.toml" ]]; then
    export STARSHIP_CONFIG="$starship_config"
  fi

  if command -v atuin >/dev/null 2>&1 \
    && [[ -n "$atuin_config" && -z "${ATUIN_CONFIG:-}" ]] \
    && [[ ! -e "$xdg_config_home/atuin/config.toml" ]]; then
    export ATUIN_CONFIG="$atuin_config"
  fi

  # vc-frame must never inherit the user's stock ~/.config/vc-frame namespace.
  _vetcoders_pin_vc_frame_config_dir
}

_vetcoders_load_frontier_sidecars

_vetcoders_normalize_ambient_context

_VETCODERS_ATUIN_BIN="$(_vetcoders_atuin_bin 2>/dev/null || true)"
